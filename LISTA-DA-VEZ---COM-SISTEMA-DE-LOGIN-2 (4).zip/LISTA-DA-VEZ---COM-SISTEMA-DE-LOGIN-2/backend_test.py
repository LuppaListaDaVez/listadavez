"""Backend API Testing for Lista da Vez - Branch 2 Fixes Testing"""
import requests
import json
import sys

# Base URL from review request
BASE_URL = "https://queue-mgmt-3.preview.emergentagent.com"
API_URL = f"{BASE_URL}/api"

# Test credentials from review request
SUPER_ADMIN_EMAIL = "admin@listadavez.com"
SUPER_ADMIN_PASSWORD = "Admin@123456"

TENANT_DEMO_SLUG = "demo"
TENANT_ADMIN_EMAIL = "admin@demo.com"
TENANT_ADMIN_PASSWORD = "Admin@123456"

SELLER_EMAIL = "joao@demo.com"
SELLER_PASSWORD = "Admin@123456"

# Color codes for output
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
BLUE = '\033[94m'
RESET = '\033[0m'

def print_test_header(test_name):
    print(f"\n{'='*80}")
    print(f"{BLUE}Testing: {test_name}{RESET}")
    print(f"{'='*80}")

def print_success(message):
    print(f"{GREEN}✅ SUCCESS: {message}{RESET}")

def print_error(message):
    print(f"{RED}❌ FAILED: {message}{RESET}")

def print_info(message):
    print(f"{YELLOW}ℹ️  INFO: {message}{RESET}")

def print_detail(message):
    print(f"   {message}")

def get_admin_token():
    """Helper: Get admin token for demo tenant"""
    try:
        url = f"{API_URL}/tenants/{TENANT_DEMO_SLUG}/auth/login"
        payload = {
            "email": TENANT_ADMIN_EMAIL,
            "password": TENANT_ADMIN_PASSWORD
        }
        response = requests.post(url, json=payload, headers={"Content-Type": "application/json"}, timeout=10)
        if response.status_code == 200:
            return response.json().get("access_token")
        return None
    except Exception:
        return None

def get_seller_token():
    """Helper: Get seller token (João Silva)"""
    try:
        url = f"{API_URL}/tenants/{TENANT_DEMO_SLUG}/auth/login"
        payload = {
            "email": SELLER_EMAIL,
            "password": SELLER_PASSWORD
        }
        response = requests.post(url, json=payload, headers={"Content-Type": "application/json"}, timeout=10)
        if response.status_code == 200:
            return response.json().get("access_token")
        return None
    except Exception:
        return None

def test_ranking_items_sold():
    """TEST 1: Ranking ITEMS_SOLD - Produtos vendidos calculado corretamente
    
    Expected: João Silva should have value=9 (Bolsa x3 + Camiseta x2 + Tênis x4)
              Maria Oliveira should have value=6 (Camiseta x6)
    """
    print_test_header("TEST 1: Ranking ITEMS_SOLD (Produtos vendidos)")
    
    try:
        # Get admin token
        token = get_admin_token()
        if not token:
            print_error("Failed to get admin token")
            return False
        
        # Test ranking endpoint
        url = f"{API_URL}/tenants/{TENANT_DEMO_SLUG}/rankings"
        params = {
            "criteria": "ITEMS_SOLD",
            "period_start": "2026-08-01",
            "period_end": "2026-08-03"
        }
        
        print_info(f"GET {url}")
        print_detail(f"Params: {params}")
        
        response = requests.get(
            url,
            params=params,
            headers={"Authorization": f"Bearer {token}"},
            timeout=10
        )
        
        print_info(f"Status Code: {response.status_code}")
        
        if response.status_code != 200:
            print_error(f"Expected 200, got {response.status_code}")
            print_detail(f"Response: {response.text}")
            return False
        
        data = response.json()
        
        # Verify response structure
        if "criteria" not in data or "items" not in data:
            print_error("Response missing 'criteria' or 'items' field")
            print_detail(f"Response keys: {list(data.keys())}")
            return False
        
        if data["criteria"] != "ITEMS_SOLD":
            print_error(f"Expected criteria 'ITEMS_SOLD', got '{data['criteria']}'")
            return False
        
        items = data.get("items", [])
        print_info(f"Found {len(items)} sellers in ranking")
        
        # Find João Silva and Maria Oliveira
        joao_found = False
        maria_found = False
        
        for item in items:
            seller_name = item.get("seller_name", "")
            value = item.get("value", 0)
            print_detail(f"  {seller_name}: {value} produtos vendidos")
            
            if "João" in seller_name or "Joao" in seller_name:
                joao_found = True
                if value == 9:
                    print_success(f"João Silva has correct value: 9 produtos (Bolsa x3 + Camiseta x2 + Tênis x4)")
                else:
                    print_error(f"João Silva has incorrect value: {value} (expected 9)")
                    return False
            
            if "Maria" in seller_name:
                maria_found = True
                if value == 6:
                    print_success(f"Maria Oliveira has correct value: 6 produtos (Camiseta x6)")
                else:
                    print_error(f"Maria Oliveira has incorrect value: {value} (expected 6)")
                    return False
        
        if not joao_found:
            print_error("João Silva not found in ranking")
            return False
        
        if not maria_found:
            print_error("Maria Oliveira not found in ranking")
            return False
        
        print_success("Ranking ITEMS_SOLD calculation is correct")
        return True
        
    except requests.exceptions.RequestException as e:
        print_error(f"Request failed: {str(e)}")
        return False
    except Exception as e:
        print_error(f"Unexpected error: {str(e)}")
        return False

def test_goals_in_my_performance():
    """TEST 2: Goals visible for seller in my-performance
    
    Expected: response.goals should contain at least 2 goals:
              1. One with scope="STORE" (store unit goal)
              2. One with scope="SELLER" (individual goal for João)
    """
    print_test_header("TEST 2: Goals visible for seller in my-performance")
    
    try:
        # Get seller token (João)
        token = get_seller_token()
        if not token:
            print_error("Failed to get seller token for joao@demo.com")
            return False
        
        print_success("Logged in as João Silva (SELLER role)")
        
        # Test my-performance endpoint
        url = f"{API_URL}/tenants/{TENANT_DEMO_SLUG}/my-performance"
        params = {"period": "month"}
        
        print_info(f"GET {url}")
        print_detail(f"Params: {params}")
        
        response = requests.get(
            url,
            params=params,
            headers={"Authorization": f"Bearer {token}"},
            timeout=10
        )
        
        print_info(f"Status Code: {response.status_code}")
        
        if response.status_code != 200:
            print_error(f"Expected 200, got {response.status_code}")
            print_detail(f"Response: {response.text}")
            return False
        
        data = response.json()
        
        # Verify response structure
        if "goals" not in data:
            print_error("Response missing 'goals' field")
            print_detail(f"Response keys: {list(data.keys())}")
            return False
        
        goals = data.get("goals", [])
        print_info(f"Found {len(goals)} goals for seller")
        
        # Check for STORE and SELLER scope goals
        store_goal_found = False
        seller_goal_found = False
        team_goal_found = False
        
        for goal in goals:
            scope = goal.get("scope", "")
            title = goal.get("title", "")
            print_detail(f"  Goal: '{title}' (scope={scope})")
            
            if scope == "STORE":
                store_goal_found = True
                print_success(f"Found STORE scope goal: '{title}'")
            elif scope == "SELLER":
                seller_goal_found = True
                print_success(f"Found SELLER scope goal: '{title}'")
            elif scope == "TEAM":
                team_goal_found = True
                print_success(f"Found TEAM scope goal: '{title}'")
        
        if not store_goal_found:
            print_error("STORE scope goal not found (expected: store unit goal should be visible to seller)")
            return False
        
        if not seller_goal_found:
            print_error("SELLER scope goal not found (expected: individual goal for João)")
            return False
        
        print_success("Seller can see both STORE and SELLER scope goals in my-performance")
        return True
        
    except requests.exceptions.RequestException as e:
        print_error(f"Request failed: {str(e)}")
        return False
    except Exception as e:
        print_error(f"Unexpected error: {str(e)}")
        return False

def test_goals_endpoint_for_seller():
    """TEST 3: Goals visible for seller via /goals endpoint
    
    Expected: should see the store unit goal "Meta mensal da Unidade Centro" (STORE scope)
    """
    print_test_header("TEST 3: Goals visible for seller via /goals endpoint")
    
    try:
        # Get seller token (João)
        token = get_seller_token()
        if not token:
            print_error("Failed to get seller token for joao@demo.com")
            return False
        
        print_success("Logged in as João Silva (SELLER role)")
        
        # Test goals endpoint
        url = f"{API_URL}/tenants/{TENANT_DEMO_SLUG}/goals"
        params = {"status": "ACTIVE"}
        
        print_info(f"GET {url}")
        print_detail(f"Params: {params}")
        
        response = requests.get(
            url,
            params=params,
            headers={"Authorization": f"Bearer {token}"},
            timeout=10
        )
        
        print_info(f"Status Code: {response.status_code}")
        
        if response.status_code != 200:
            print_error(f"Expected 200, got {response.status_code}")
            print_detail(f"Response: {response.text}")
            return False
        
        goals = response.json()
        
        if not isinstance(goals, list):
            print_error("Expected response to be a list of goals")
            return False
        
        print_info(f"Found {len(goals)} active goals")
        
        # Check for store unit goal
        store_goal_found = False
        
        for goal in goals:
            scope = goal.get("scope", "")
            title = goal.get("title", "")
            print_detail(f"  Goal: '{title}' (scope={scope})")
            
            if scope == "STORE":
                store_goal_found = True
                print_success(f"Found STORE scope goal: '{title}'")
                
                # Check if it's the expected goal
                if "Unidade Centro" in title or "unidade" in title.lower():
                    print_success(f"Found expected store unit goal: '{title}'")
        
        if not store_goal_found:
            print_error("STORE scope goal not found in /goals endpoint")
            return False
        
        print_success("Seller can see STORE scope goals via /goals endpoint")
        return True
        
    except requests.exceptions.RequestException as e:
        print_error(f"Request failed: {str(e)}")
        return False
    except Exception as e:
        print_error(f"Unexpected error: {str(e)}")
        return False

def test_store_goal_filter():
    """TEST 4: Store goal filter isolation
    
    Expected: GET /goals?scope=STORE should show STORE scope goals
    """
    print_test_header("TEST 4: Store goal filter isolation")
    
    try:
        # Get admin token
        token = get_admin_token()
        if not token:
            print_error("Failed to get admin token")
            return False
        
        print_success("Logged in as admin@demo.com (TENANT_ADMIN role)")
        
        # Test goals endpoint with scope filter
        url = f"{API_URL}/tenants/{TENANT_DEMO_SLUG}/goals"
        params = {"scope": "STORE"}
        
        print_info(f"GET {url}")
        print_detail(f"Params: {params}")
        
        response = requests.get(
            url,
            params=params,
            headers={"Authorization": f"Bearer {token}"},
            timeout=10
        )
        
        print_info(f"Status Code: {response.status_code}")
        
        if response.status_code != 200:
            print_error(f"Expected 200, got {response.status_code}")
            print_detail(f"Response: {response.text}")
            return False
        
        goals = response.json()
        
        if not isinstance(goals, list):
            print_error("Expected response to be a list of goals")
            return False
        
        print_info(f"Found {len(goals)} STORE scope goals")
        
        # Verify all goals have STORE scope
        all_store_scope = True
        for goal in goals:
            scope = goal.get("scope", "")
            title = goal.get("title", "")
            print_detail(f"  Goal: '{title}' (scope={scope})")
            
            if scope != "STORE":
                print_error(f"Found non-STORE goal in filtered results: '{title}' (scope={scope})")
                all_store_scope = False
        
        if not all_store_scope:
            print_error("Filter returned goals with non-STORE scope")
            return False
        
        if len(goals) == 0:
            print_error("No STORE scope goals found (expected at least one)")
            return False
        
        print_success("Store goal filter working correctly - only STORE scope goals returned")
        return True
        
    except requests.exceptions.RequestException as e:
        print_error(f"Request failed: {str(e)}")
        return False
    except Exception as e:
        print_error(f"Unexpected error: {str(e)}")
        return False

def test_ranking_consistency():
    """TEST 5: Ranking consistency check
    
    Expected: All ranking criteria should return 200 OK with proper structure
    """
    print_test_header("TEST 5: Ranking consistency check")
    
    try:
        # Get admin token
        token = get_admin_token()
        if not token:
            print_error("Failed to get admin token")
            return False
        
        criteria_list = ["REVENUE", "SALES_COUNT", "ITEMS_SOLD"]
        all_passed = True
        
        for criteria in criteria_list:
            print_info(f"Testing criteria: {criteria}")
            
            url = f"{API_URL}/tenants/{TENANT_DEMO_SLUG}/rankings"
            params = {
                "criteria": criteria,
                "period_start": "2026-08-01",
                "period_end": "2026-08-03"
            }
            
            response = requests.get(
                url,
                params=params,
                headers={"Authorization": f"Bearer {token}"},
                timeout=10
            )
            
            print_detail(f"  Status Code: {response.status_code}")
            
            if response.status_code != 200:
                print_error(f"  {criteria}: Expected 200, got {response.status_code}")
                print_detail(f"  Response: {response.text}")
                all_passed = False
                continue
            
            data = response.json()
            
            # Verify response structure
            if "criteria" not in data:
                print_error(f"  {criteria}: Response missing 'criteria' field")
                all_passed = False
                continue
            
            if "items" not in data:
                print_error(f"  {criteria}: Response missing 'items' field")
                all_passed = False
                continue
            
            if data["criteria"] != criteria:
                print_error(f"  {criteria}: Expected criteria '{criteria}', got '{data['criteria']}'")
                all_passed = False
                continue
            
            items = data.get("items", [])
            print_success(f"  {criteria}: OK ({len(items)} items)")
        
        if not all_passed:
            print_error("Some ranking criteria failed")
            return False
        
        print_success("All ranking criteria working consistently")
        return True
        
    except requests.exceptions.RequestException as e:
        print_error(f"Request failed: {str(e)}")
        return False
    except Exception as e:
        print_error(f"Unexpected error: {str(e)}")
        return False

def test_health_endpoint():
    """Test GET /api/health endpoint"""
    print_test_header("Health Endpoint")
    
    try:
        url = f"{API_URL}/health"
        print_info(f"GET {url}")
        
        response = requests.get(url, timeout=10)
        
        print_info(f"Status Code: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            if data.get("status") == "ok":
                print_success("Health endpoint returned 200 OK")
                return True
            else:
                print_error(f"Health endpoint returned unexpected status: {data.get('status')}")
                return False
        else:
            print_error(f"Health endpoint returned status code {response.status_code}")
            return False
            
    except requests.exceptions.RequestException as e:
        print_error(f"Request failed: {str(e)}")
        return False
    except Exception as e:
        print_error(f"Unexpected error: {str(e)}")
        return False

def test_super_admin_login():
    """Test POST /api/auth/login for Super Admin"""
    print_test_header("Super Admin Login")
    
    try:
        url = f"{API_URL}/auth/login"
        print_info(f"POST {url}")
        print_detail(f"Email: {SUPER_ADMIN_EMAIL}")
        
        payload = {
            "email": SUPER_ADMIN_EMAIL,
            "password": SUPER_ADMIN_PASSWORD
        }
        
        response = requests.post(
            url,
            json=payload,
            headers={"Content-Type": "application/json"},
            timeout=10
        )
        
        print_info(f"Status Code: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            
            # Verify response structure
            required_fields = ["access_token", "refresh_token", "token_type", "auth_context", "user"]
            missing_fields = [field for field in required_fields if field not in data]
            
            if missing_fields:
                print_error(f"Missing required fields in response: {missing_fields}")
                return False
            
            if data.get("auth_context") != "SUPER_ADMIN":
                print_error(f"Expected auth_context 'SUPER_ADMIN', got '{data.get('auth_context')}'")
                return False
            
            user = data.get("user", {})
            if not user.get("is_super_admin"):
                print_error("User is not marked as super admin")
                return False
            
            print_success("Super Admin login successful")
            print_detail(f"User: {user.get('name')} ({user.get('email')})")
            return True
        else:
            print_error(f"Login failed with status code {response.status_code}")
            print_detail(f"Response: {response.text}")
            return False
            
    except requests.exceptions.RequestException as e:
        print_error(f"Request failed: {str(e)}")
        return False
    except Exception as e:
        print_error(f"Unexpected error: {str(e)}")
        return False

def test_tenant_demo_login():
    """Test POST /api/tenants/demo/auth/login for Tenant Demo"""
    print_test_header("Tenant Demo Admin Login")
    
    try:
        url = f"{API_URL}/tenants/{TENANT_DEMO_SLUG}/auth/login"
        print_info(f"POST {url}")
        print_detail(f"Email: {TENANT_ADMIN_EMAIL}")
        
        payload = {
            "email": TENANT_ADMIN_EMAIL,
            "password": TENANT_ADMIN_PASSWORD
        }
        
        response = requests.post(
            url,
            json=payload,
            headers={"Content-Type": "application/json"},
            timeout=10
        )
        
        print_info(f"Status Code: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            
            # Verify response structure
            required_fields = ["access_token", "refresh_token", "token_type", "auth_context", "user", "membership"]
            missing_fields = [field for field in required_fields if field not in data]
            
            if missing_fields:
                print_error(f"Missing required fields in response: {missing_fields}")
                return False
            
            if data.get("auth_context") != "TENANT":
                print_error(f"Expected auth_context 'TENANT', got '{data.get('auth_context')}'")
                return False
            
            user = data.get("user", {})
            membership = data.get("membership", {})
            
            print_success("Tenant Demo login successful")
            print_detail(f"User: {user.get('name')} ({user.get('email')})")
            print_detail(f"Role: {membership.get('role')}")
            return True
        else:
            print_error(f"Login failed with status code {response.status_code}")
            print_detail(f"Response: {response.text}")
            return False
            
    except requests.exceptions.RequestException as e:
        print_error(f"Request failed: {str(e)}")
        return False
    except Exception as e:
        print_error(f"Unexpected error: {str(e)}")
        return False

def test_seller_login():
    """Test POST /api/tenants/demo/auth/login for Seller (João)"""
    print_test_header("Seller Login (João Silva)")
    
    try:
        url = f"{API_URL}/tenants/{TENANT_DEMO_SLUG}/auth/login"
        print_info(f"POST {url}")
        print_detail(f"Email: {SELLER_EMAIL}")
        
        payload = {
            "email": SELLER_EMAIL,
            "password": SELLER_PASSWORD
        }
        
        response = requests.post(
            url,
            json=payload,
            headers={"Content-Type": "application/json"},
            timeout=10
        )
        
        print_info(f"Status Code: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            
            # Verify response structure
            required_fields = ["access_token", "refresh_token", "token_type", "auth_context", "user", "membership"]
            missing_fields = [field for field in required_fields if field not in data]
            
            if missing_fields:
                print_error(f"Missing required fields in response: {missing_fields}")
                return False
            
            user = data.get("user", {})
            membership = data.get("membership", {})
            
            if membership.get("role") != "SELLER":
                print_error(f"Expected role 'SELLER', got '{membership.get('role')}'")
                return False
            
            print_success("Seller login successful")
            print_detail(f"User: {user.get('name')} ({user.get('email')})")
            print_detail(f"Role: {membership.get('role')}")
            return True
        else:
            print_error(f"Login failed with status code {response.status_code}")
            print_detail(f"Response: {response.text}")
            return False
            
    except requests.exceptions.RequestException as e:
        print_error(f"Request failed: {str(e)}")
        return False
    except Exception as e:
        print_error(f"Unexpected error: {str(e)}")
        return False

def main():
    """Run all backend tests"""
    print("\n" + "="*80)
    print(f"{BLUE}BACKEND API TESTING - Lista da Vez Branch 2 Fixes{RESET}")
    print("="*80)
    print_info(f"Base URL: {BASE_URL}")
    print_info(f"API URL: {API_URL}")
    print_info(f"Tenant: {TENANT_DEMO_SLUG}")
    
    results = {}
    
    # Basic tests
    print("\n" + "="*80)
    print(f"{BLUE}BASIC TESTS{RESET}")
    print("="*80)
    
    results["Health Check"] = test_health_endpoint()
    results["Super Admin Login"] = test_super_admin_login()
    results["Tenant Demo Admin Login"] = test_tenant_demo_login()
    results["Seller Login (João)"] = test_seller_login()
    
    # Branch 2 fix tests
    print("\n" + "="*80)
    print(f"{BLUE}BRANCH 2 FIX TESTS{RESET}")
    print("="*80)
    
    results["TEST 1: Ranking ITEMS_SOLD"] = test_ranking_items_sold()
    results["TEST 2: Goals in my-performance"] = test_goals_in_my_performance()
    results["TEST 3: Goals endpoint for seller"] = test_goals_endpoint_for_seller()
    results["TEST 4: Store goal filter"] = test_store_goal_filter()
    results["TEST 5: Ranking consistency"] = test_ranking_consistency()
    
    # Summary
    print("\n" + "="*80)
    print(f"{BLUE}TEST SUMMARY{RESET}")
    print("="*80)
    
    for test_name, passed in results.items():
        status = f"{GREEN}✅ PASSED{RESET}" if passed else f"{RED}❌ FAILED{RESET}"
        print(f"{test_name}: {status}")
    
    total_tests = len(results)
    passed_tests = sum(1 for result in results.values() if result)
    
    print(f"\n{BLUE}Total: {passed_tests}/{total_tests} tests passed{RESET}")
    
    if passed_tests == total_tests:
        print(f"\n{GREEN}{'='*80}")
        print(f"✅ ALL TESTS PASSED")
        print(f"{'='*80}{RESET}")
        return 0
    else:
        print(f"\n{RED}{'='*80}")
        print(f"❌ SOME TESTS FAILED")
        print(f"{'='*80}{RESET}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
