"""Configuração centralizada de e-mail.

Suporta os novos nomes canônicos (SMTP_PASSWORD, SMTP_TLS, SMTP_SSL)
e mantém aliases de compatibilidade (SMTP_PASS → SMTP_PASSWORD, SMTP_SECURE → SMTP_TLS)
para não quebrar configurações existentes nem os testes legados que patcham email_service.SMTP_PASS.

Ordem de prioridade: novo nome > alias antigo > default.
"""
import os

# ── Habilitação ────────────────────────────────────────────────────────────────
EMAIL_ENABLED  = os.environ.get("EMAIL_ENABLED", "true").lower() in ("true", "1", "yes")
EMAIL_PROVIDER = os.environ.get("EMAIL_PROVIDER", "log").lower()

# ── Remetente ──────────────────────────────────────────────────────────────────
EMAIL_FROM = (
    os.environ.get("EMAIL_FROM")
    or os.environ.get("SMTP_FROM")          # alias
    or "noreply@listadavez.com"
)
EMAIL_FROM_NAME = os.environ.get("EMAIL_FROM_NAME", "Lista da Vez")

# ── SMTP ───────────────────────────────────────────────────────────────────────
SMTP_HOST     = os.environ.get("SMTP_HOST", "")
SMTP_PORT     = int(os.environ.get("SMTP_PORT", "587"))
SMTP_USER     = os.environ.get("SMTP_USER", "")

# SMTP_PASSWORD (novo) > SMTP_PASS (alias deprecated)
SMTP_PASSWORD = os.environ.get("SMTP_PASSWORD") or os.environ.get("SMTP_PASS") or ""

# SMTP_TLS (novo) > SMTP_SECURE (alias deprecated)
_tls_raw  = os.environ.get("SMTP_TLS") or os.environ.get("SMTP_SECURE") or "false"
SMTP_TLS  = _tls_raw.lower() in ("true", "1", "yes")
SMTP_SSL  = os.environ.get("SMTP_SSL", "false").lower() in ("true", "1", "yes")

SMTP_TIMEOUT      = int(os.environ.get("SMTP_TIMEOUT", "15"))
EMAIL_MAX_RETRIES = int(os.environ.get("EMAIL_MAX_RETRIES", "3"))

# ── AWS SES (legado) ───────────────────────────────────────────────────────────
AWS_REGION     = os.environ.get("AWS_REGION", "us-east-1")
SES_FROM_EMAIL = os.environ.get("SES_FROM_EMAIL") or EMAIL_FROM


def is_smtp_configured() -> bool:
    """True somente quando todos os campos obrigatórios estão presentes."""
    return bool(SMTP_HOST and SMTP_USER and SMTP_PASSWORD)


def is_ses_configured() -> bool:
    return bool(AWS_REGION and SES_FROM_EMAIL)


def is_email_configured() -> bool:
    """True quando e-mail está habilitado E configurado."""
    if not EMAIL_ENABLED:
        return False
    if EMAIL_PROVIDER == "smtp":
        return is_smtp_configured()
    if EMAIL_PROVIDER == "ses":
        return is_ses_configured()
    return False  # log mode: não "configurado" para envio real


def load_from_db_doc(doc: dict) -> dict:
    """Normaliza um documento do banco (smtp_host, smtp_pass, …) para o formato canônico.

    Retorna dict com chaves: host, port, user, password, tls, ssl, from_, from_name, timeout
    Retorna {} se doc for inválido/incompleto.
    """
    if not doc:
        return {}
    host = doc.get("smtp_host", "")
    pwd  = doc.get("smtp_password") or doc.get("smtp_pass") or ""  # compat
    if not (host and pwd):
        return {}
    tls_raw  = doc.get("smtp_tls") or doc.get("smtp_secure")  # compat
    tls_flag = str(tls_raw).lower() in ("true", "1", "yes") if tls_raw is not None else False
    return {
        "host":      host,
        "port":      int(doc.get("smtp_port", 587)),
        "user":      doc.get("smtp_user", ""),
        "password":  pwd,
        "tls":       tls_flag,
        "ssl":       str(doc.get("smtp_ssl", False)).lower() in ("true", "1", "yes"),
        "from_":     doc.get("smtp_from") or doc.get("smtp_user", ""),
        "from_name": doc.get("smtp_from_name", EMAIL_FROM_NAME),
        "timeout":   int(doc.get("smtp_timeout", SMTP_TIMEOUT)),
    }
