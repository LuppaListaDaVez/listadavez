"""ConsentService — Gerenciamento de consentimentos e base legal (Etapa 14)."""
from typing import Optional
from db import db
from models import new_id, utcnow_iso
from audit import log_audit


async def create_consent(tenant_id: str, data: dict, actor_id: str, request=None) -> dict:
    now = utcnow_iso()
    doc = {
        "id": new_id(),
        "tenant_id": tenant_id,
        "subject_type": data.get("subject_type", "USER"),
        "subject_user_id": data.get("subject_user_id"),
        "subject_customer_ref": data.get("subject_customer_ref"),
        "purpose": data.get("purpose", "ACCOUNT_ACCESS"),
        "legal_basis": data.get("legal_basis", "CONSENT"),
        "status": "GRANTED",
        "version": data.get("version", "1.0"),
        "source": data.get("source", "SYSTEM"),
        "collected_at": now,
        "withdrawn_at": None,
        "expires_at": data.get("expires_at"),
        "created_at": now,
        "updated_at": now,
    }
    await db.consents.insert_one(doc)
    doc.pop("_id", None)
    await _log_event(tenant_id, doc["id"], "CONSENT_GRANTED", None, "GRANTED", actor_id, request)
    await log_audit(action="CONSENT_GRANTED", entity="consent", entity_id=doc["id"],
                    tenant_id=tenant_id, user_id=actor_id, request=request)
    return doc


async def withdraw_consent(tenant_id: str, consent_id: str, actor_id: str, request=None) -> Optional[dict]:
    doc = await db.consents.find_one({"id": consent_id, "tenant_id": tenant_id})
    if not doc:
        return None
    now = utcnow_iso()
    await db.consents.update_one(
        {"id": consent_id},
        {"$set": {"status": "WITHDRAWN", "withdrawn_at": now, "updated_at": now}}
    )
    await _log_event(tenant_id, consent_id, "CONSENT_WITHDRAWN", doc.get("status"), "WITHDRAWN", actor_id, request)
    await log_audit(action="CONSENT_WITHDRAWN", entity="consent", entity_id=consent_id,
                    tenant_id=tenant_id, user_id=actor_id, request=request)
    doc.update({"status": "WITHDRAWN", "withdrawn_at": now})
    doc.pop("_id", None)
    return doc


async def list_consents(tenant_id: str, subject_user_id: Optional[str] = None,
                        status: Optional[str] = None) -> list:
    filt = {"tenant_id": tenant_id}
    if subject_user_id:
        filt["subject_user_id"] = subject_user_id
    if status:
        filt["status"] = status
    cursor = db.consents.find(filt, {"_id": 0}).sort("created_at", -1).limit(100)
    return await cursor.to_list(length=100)


async def list_consent_events(tenant_id: str, limit: int = 50) -> list:
    cursor = db.consent_events.find({"tenant_id": tenant_id}, {"_id": 0}).sort("created_at", -1).limit(limit)
    return await cursor.to_list(length=limit)


async def _log_event(tenant_id, consent_id, event_type, old_status, new_status, actor_id, request):
    ip = None
    ua = None
    if request:
        ip = request.client.host if request.client else None
        ua = request.headers.get("user-agent")
    await db.consent_events.insert_one({
        "id": new_id(), "tenant_id": tenant_id, "consent_id": consent_id,
        "event_type": event_type, "old_status": old_status, "new_status": new_status,
        "actor_user_id": actor_id, "ip": ip, "user_agent": ua,
        "created_at": utcnow_iso(),
    })
