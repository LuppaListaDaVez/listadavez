"""Exportação CSV (Etapas 7/8) — /api/tenants/{slug}/reports/export/csv."""
import csv
import io
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse

from db import db
from security import resolve_tenant_context
from feature_guard import require_feature
from permission_service import get_accessible_store_ids
from permissions import P_REPORTS_EXPORT

router = APIRouter(prefix="/tenants/{tenant_slug}/reports/export", tags=["export"])

REPORT_TYPES = {"attendances", "conversion", "loss-reasons", "seller-performance", "products", "proactivity"}


def _has_export_perm(role: str) -> bool:
    from permissions import ROLE_PERMISSIONS
    return P_REPORTS_EXPORT in ROLE_PERMISSIONS.get(role, [])


def _make_csv_response(rows: list[dict], filename: str) -> StreamingResponse:
    """Gera StreamingResponse CSV com UTF-8+BOM (compatível com Excel PT-BR)."""
    if not rows:
        output = io.StringIO()
        output.write("Sem dados para exportar\n")
        content = "\ufeff" + output.getvalue()
    else:
        output = io.StringIO()
        writer = csv.DictWriter(output, fieldnames=list(rows[0].keys()), extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
        content = "\ufeff" + output.getvalue()

    return StreamingResponse(
        iter([content.encode("utf-8")]),
        media_type="text/csv; charset=utf-8",
        headers={
            "Content-Disposition": f"attachment; filename={filename}",
            "Access-Control-Expose-Headers": "Content-Disposition",
        },
    )


def _fmt_cents(cents: int) -> str:
    return f"R$ {cents / 100:.2f}".replace(".", ",")


def _fmt_date(iso: Optional[str]) -> str:
    if not iso:
        return ""
    try:
        dt = datetime.fromisoformat(iso.replace("Z", "+00:00"))
        return dt.strftime("%d/%m/%Y %H:%M")
    except Exception:
        return iso


def _fmt_duration(seconds: int) -> str:
    if not seconds:
        return "0 min"
    m, s = divmod(seconds, 60)
    if m < 60:
        return f"{m}m {s}s"
    h, m = divmod(m, 60)
    return f"{h}h {m}m"


async def _get_seller_name_map(seller_ids: list[str]) -> dict:
    names: dict = {}
    async for s in db.seller_profiles.find({"id": {"$in": seller_ids}}):
        user = await db.users.find_one({"id": s.get("user_id", "")})
        names[s["id"]] = user.get("name", "—") if user else "—"
    return names


async def _get_store_name_map(store_ids: list[str]) -> dict:
    names: dict = {}
    async for s in db.stores.find({"id": {"$in": store_ids}}):
        names[s["id"]] = s.get("name", "—")
    return names


@router.get("/csv")
async def export_csv(
    report_type: str,
    date_start: Optional[str] = None,
    date_end: Optional[str] = None,
    store_id: Optional[str] = None,
    seller_id: Optional[str] = None,
    result: Optional[str] = None,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "exportacao")
    role = ctx["membership"]["role"]
    if not _has_export_perm(role):
        raise HTTPException(status_code=403, detail="Sem permissão para exportar relatórios.")
    if report_type not in REPORT_TYPES:
        raise HTTPException(status_code=400, detail=f"Tipo de relatório inválido. Use: {', '.join(REPORT_TYPES)}")

    tenant_id = ctx["tenant"]["id"]
    accessible_store_ids = await get_accessible_store_ids(ctx["membership"], tenant_id)

    if store_id and store_id not in accessible_store_ids:
        raise HTTPException(status_code=403, detail="Sem acesso a esta unidade.")

    effective_store_ids = [store_id] if store_id else accessible_store_ids

    # Filtro de data base
    date_filter: dict = {}
    if date_start:
        date_filter["$gte"] = date_start
    if date_end:
        date_filter["$lte"] = date_end + "T23:59:59.999999+00:00"

    # ─── SELLER scoping ───────────────────────────────────────────────────────
    seller_filter_id = None
    if role == "SELLER":
        profile = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": ctx["user"]["id"]})
        seller_filter_id = profile["id"] if profile else "__none__"

    now_str = datetime.now().strftime("%Y%m%d_%H%M")

    # ═══════════════════════════════════════════════════════════════════════════
    if report_type == "attendances":
        q: dict = {"tenant_id": tenant_id, "store_id": {"$in": effective_store_ids}}
        if date_filter:
            q["created_at"] = date_filter
        if seller_filter_id:
            q["seller_id"] = seller_filter_id
        elif seller_id:
            q["seller_id"] = seller_id
        if result:
            q["result"] = result

        raw = await db.attendances.find(q).sort("created_at", -1).limit(5000).to_list(5000)
        sid_list = list({a["seller_id"] for a in raw})
        st_list = list({a["store_id"] for a in raw})
        seller_names = await _get_seller_name_map(sid_list)
        store_names = await _get_store_name_map(st_list)

        lr_ids = [a.get("loss_reason_id") for a in raw if a.get("loss_reason_id")]
        lr_names: dict = {}
        if lr_ids:
            async for lr in db.loss_reasons.find({"id": {"$in": lr_ids}}):
                lr_names[lr["id"]] = lr.get("name", "—")

        rows = []
        for a in raw:
            dur_secs = 0
            if a.get("started_at") and a.get("finished_at"):
                try:
                    s_dt = datetime.fromisoformat(a["started_at"].replace("Z", "+00:00"))
                    f_dt = datetime.fromisoformat(a["finished_at"].replace("Z", "+00:00"))
                    dur_secs = int((f_dt - s_dt).total_seconds())
                except Exception:
                    pass
            rows.append({
                "ID": a["id"],
                "Unidade": store_names.get(a["store_id"], "—"),
                "Vendedor": seller_names.get(a["seller_id"], "—"),
                "Status": a.get("status", ""),
                "Resultado": a.get("result", ""),
                "Valor Venda": _fmt_cents(a.get("sale_amount_cents") or 0),
                "Motivo Perda": lr_names.get(a.get("loss_reason_id", ""), a.get("loss_reason_text") or ""),
                "Obs": a.get("notes", ""),
                "Inicio": _fmt_date(a.get("created_at")),
                "Atendimento Iniciado": _fmt_date(a.get("started_at")),
                "Finalizado": _fmt_date(a.get("finished_at")),
                "Duracao (min)": f"{dur_secs // 60}m {dur_secs % 60}s" if dur_secs else "",
            })
        return _make_csv_response(rows, f"atendimentos_{now_str}.csv")

    # ═══════════════════════════════════════════════════════════════════════════
    elif report_type == "conversion":
        q = {"tenant_id": tenant_id, "store_id": {"$in": effective_store_ids}, "status": "FINISHED"}
        if date_filter:
            q["created_at"] = date_filter
        if seller_filter_id:
            q["seller_id"] = seller_filter_id

        raw = await db.attendances.find(q).to_list(5000)
        sid_list = list({a["seller_id"] for a in raw})
        seller_names = await _get_seller_name_map(sid_list)

        perf: dict = {}
        for a in raw:
            sid = a["seller_id"]
            if sid not in perf:
                perf[sid] = {"Vendedor": seller_names.get(sid, "—"), "Atendimentos": 0, "Vendas": 0, "Total Vendido": 0}
            perf[sid]["Atendimentos"] += 1
            if a.get("result") == "SALE":
                perf[sid]["Vendas"] += 1
                perf[sid]["Total Vendido"] += a.get("sale_amount_cents") or 0

        rows = []
        for d in sorted(perf.values(), key=lambda x: x["Vendas"], reverse=True):
            rows.append({
                "Vendedor": d["Vendedor"],
                "Atendimentos": d["Atendimentos"],
                "Vendas": d["Vendas"],
                "Conversao (%)": f"{round(d['Vendas'] / d['Atendimentos'] * 100)}%" if d["Atendimentos"] else "0%",
                "Total Vendido": _fmt_cents(d["Total Vendido"]),
                "Ticket Medio": _fmt_cents(round(d["Total Vendido"] / d["Vendas"])) if d["Vendas"] else "R$ 0,00",
            })
        return _make_csv_response(rows, f"conversao_{now_str}.csv")

    # ═══════════════════════════════════════════════════════════════════════════
    elif report_type == "loss-reasons":
        q = {"tenant_id": tenant_id, "store_id": {"$in": effective_store_ids}, "result": "NO_SALE", "status": "FINISHED"}
        if date_filter:
            q["created_at"] = date_filter
        if seller_filter_id:
            q["seller_id"] = seller_filter_id

        raw = await db.attendances.find(q).to_list(5000)
        counts: dict = {}
        for a in raw:
            lr_id = a.get("loss_reason_id")
            if lr_id:
                counts[lr_id] = counts.get(lr_id, 0) + 1
            else:
                key = a.get("loss_reason_text") or a.get("notes") or "Sem motivo"
                counts[f"__t__{key}"] = counts.get(f"__t__{key}", 0) + 1

        lr_ids = [k for k in counts if not k.startswith("__t__")]
        lr_names: dict = {}
        if lr_ids:
            async for lr in db.loss_reasons.find({"id": {"$in": lr_ids}}):
                lr_names[lr["id"]] = lr.get("name", "—")

        total = sum(counts.values())
        rows = []
        for key, count in sorted(counts.items(), key=lambda x: -x[1]):
            name = key[5:] if key.startswith("__t__") else lr_names.get(key, "—")
            rows.append({
                "Motivo": name,
                "Ocorrencias": count,
                "Percentual (%)": f"{round(count / total * 100)}%" if total else "0%",
            })
        return _make_csv_response(rows, f"motivos_perda_{now_str}.csv")

    # ═══════════════════════════════════════════════════════════════════════════
    elif report_type == "seller-performance":
        q = {"tenant_id": tenant_id, "store_id": {"$in": effective_store_ids}, "status": "FINISHED"}
        if date_filter:
            q["created_at"] = date_filter
        if seller_filter_id:
            q["seller_id"] = seller_filter_id

        raw = await db.attendances.find(q).to_list(5000)
        sid_list = list({a["seller_id"] for a in raw})
        seller_names = await _get_seller_name_map(sid_list)

        perf: dict = {}
        for a in raw:
            sid = a["seller_id"]
            if sid not in perf:
                perf[sid] = {"Vendedor": seller_names.get(sid, "—"), "Atendimentos": 0, "Vendas": 0, "Total Vendido": 0, "_durs": []}
            perf[sid]["Atendimentos"] += 1
            if a.get("result") == "SALE":
                perf[sid]["Vendas"] += 1
                perf[sid]["Total Vendido"] += a.get("sale_amount_cents") or 0
            if a.get("started_at") and a.get("finished_at"):
                try:
                    s_dt = datetime.fromisoformat(a["started_at"].replace("Z", "+00:00"))
                    f_dt = datetime.fromisoformat(a["finished_at"].replace("Z", "+00:00"))
                    d = (f_dt - s_dt).total_seconds()
                    if d > 0:
                        perf[sid]["_durs"].append(d)
                except Exception:
                    pass

        rows = []
        for d in sorted(perf.values(), key=lambda x: x["Vendas"], reverse=True):
            durs = d.pop("_durs")
            rows.append({
                "Vendedor": d["Vendedor"],
                "Atendimentos": d["Atendimentos"],
                "Vendas": d["Vendas"],
                "Conversao (%)": f"{round(d['Vendas'] / d['Atendimentos'] * 100)}%" if d["Atendimentos"] else "0%",
                "Total Vendido": _fmt_cents(d["Total Vendido"]),
                "Ticket Medio": _fmt_cents(round(d["Total Vendido"] / d["Vendas"])) if d["Vendas"] else "R$ 0,00",
                "Tempo Medio Atendimento": _fmt_duration(round(sum(durs) / len(durs))) if durs else "—",
            })
        return _make_csv_response(rows, f"performance_vendedores_{now_str}.csv")

    # ═══════════════════════════════════════════════════════════════════════════
    elif report_type == "products":
        sales_q: dict = {"tenant_id": tenant_id, "store_id": {"$in": effective_store_ids}, "status": "COMPLETED"}
        if date_filter:
            sales_q["created_at"] = date_filter

        sales_raw = await db.sales.find(sales_q).to_list(5000)
        sale_ids = [s["id"] for s in sales_raw]
        if not sale_ids:
            return _make_csv_response([], f"produtos_{now_str}.csv")

        sale_items = await db.sale_items.find({"sale_id": {"$in": sale_ids}}).to_list(20000)
        product_ids = list({i["product_id"] for i in sale_items if i.get("product_id")})
        prod_names: dict = {}
        if product_ids:
            async for p in db.products.find({"id": {"$in": product_ids}}):
                prod_names[p["id"]] = p.get("name", "—")

        agg: dict = {}
        for item in sale_items:
            pid = item.get("product_id") or f"__t_{item.get('name', '?')}"
            name = item.get("name") or prod_names.get(item.get("product_id", ""), "—")
            if pid not in agg:
                agg[pid] = {"Produto": name, "Quantidade Vendida": 0, "Total Arrecadado": 0}
            agg[pid]["Quantidade Vendida"] += item.get("quantity", 1)
            net = (item.get("unit_price_cents") or 0) * item.get("quantity", 1) - (item.get("discount_cents") or 0)
            agg[pid]["Total Arrecadado"] += net

        rows = []
        for d in sorted(agg.values(), key=lambda x: x["Quantidade Vendida"], reverse=True):
            rows.append({
                "Produto": d["Produto"],
                "Quantidade Vendida": d["Quantidade Vendida"],
                "Total Arrecadado": _fmt_cents(d["Total Arrecadado"]),
            })
        return _make_csv_response(rows, f"produtos_{now_str}.csv")


    # ═══════════════════════════════════════════════════════════════════════════
    elif report_type == "proactivity":
        await require_feature(ctx["tenant"]["id"], "abordagem_proativa")
        q: dict = {"tenant_id": tenant_id, "store_id": {"$in": effective_store_ids}}
        if date_filter:
            q["started_at"] = date_filter
        if seller_filter_id:
            q["seller_id"] = seller_filter_id
        elif seller_id:
            q["seller_id"] = seller_id

        raw = await db.proactive_approaches.find(q).sort("created_at", -1).limit(5000).to_list(5000)
        sid_list = list({a["seller_id"] for a in raw})
        st_list = list({a.get("store_id") for a in raw if a.get("store_id")})
        seller_names_map = await _get_seller_name_map(sid_list)
        store_names_map = await _get_store_name_map(st_list)
        lr_ids = [a.get("loss_reason_id") for a in raw if a.get("loss_reason_id")]
        lr_names: dict = {}
        if lr_ids:
            async for lr in db.loss_reasons.find({"id": {"$in": lr_ids}}):
                lr_names[lr["id"]] = lr.get("name", "—")

        STATUS_PT = {
            "OPEN": "Aberta",
            "CONVERTED_TO_ATTENDANCE": "Convertida p/ Atendimento",
            "CONVERTED_TO_SALE": "Convertida p/ Venda",
            "NO_SALE": "Sem Venda",
            "CANCELLED": "Cancelada",
        }
        rows = []
        for a in raw:
            rows.append({
                "ID": a["id"],
                "Vendedor": seller_names_map.get(a["seller_id"], "—"),
                "Unidade": store_names_map.get(a.get("store_id", ""), "—"),
                "Status": STATUS_PT.get(a.get("status", ""), a.get("status", "")),
                "Resultado": a.get("result", ""),
                "Fonte": a.get("source", ""),
                "Tipo": a.get("approach_type", ""),
                "Cliente": a.get("customer_name") or "",
                "Motivo Perda": lr_names.get(a.get("loss_reason_id", ""), ""),
                "Obs": a.get("notes") or "",
                "Iniciada em": _fmt_date(a.get("started_at")),
                "Convertida em": _fmt_date(a.get("converted_at")),
                "Encerrada em": _fmt_date(a.get("closed_at")),
            })
        return _make_csv_response(rows, f"proatividade_{now_str}.csv")
