"""Endpoints de Automações — Etapa 12."""
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from security import resolve_tenant_context
from feature_guard import require_feature
from permissions import ROLE_PERMISSIONS, P_AUTOMATION_VIEW, P_AUTOMATION_CREATE, P_AUTOMATION_UPDATE, P_AUTOMATION_DELETE, P_AUTOMATION_ENABLE_DISABLE, P_AUTOMATION_EXECUTE, P_AUTOMATION_LOGS
import automation_service as svc

router = APIRouter(prefix="/tenants/{tenant_slug}", tags=["automations"])


def _has(role, *perms):
    rp = ROLE_PERMISSIONS.get(role, [])
    return any(p in rp for p in perms)


class RuleCreate(BaseModel):
    name: str
    description: Optional[str] = None
    trigger_type: str
    conditions: Optional[list] = []
    actions: Optional[list] = []
    is_active: bool = True


class RuleUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    conditions: Optional[list] = None
    actions: Optional[list] = None
    is_active: Optional[bool] = None


@router.get("/automation-rules")
async def list_rules(is_active: Optional[bool] = None, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "automacoes")
    if not _has(ctx["membership"]["role"], P_AUTOMATION_VIEW):
        raise HTTPException(status_code=403, detail="Sem permissão.")
    return await svc.list_rules(ctx["tenant"]["id"], {"is_active": is_active})


@router.post("/automation-rules")
async def create_rule(payload: RuleCreate, request: Request, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "automacoes")
    if not _has(ctx["membership"]["role"], P_AUTOMATION_CREATE):
        raise HTTPException(status_code=403, detail="Sem permissão.")
    try:
        return await svc.create_rule(ctx["tenant"]["id"], ctx["user"]["id"], payload.model_dump(), request)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/automation-rules/{rule_id}")
async def get_rule(rule_id: str, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "automacoes")
    if not _has(ctx["membership"]["role"], P_AUTOMATION_VIEW):
        raise HTTPException(status_code=403, detail="Sem permissão.")
    doc = await svc.list_rules(ctx["tenant"]["id"])
    found = next((r for r in doc if r["id"] == rule_id), None)
    if not found:
        raise HTTPException(status_code=404, detail="Regra não encontrada.")
    return found


@router.put("/automation-rules/{rule_id}")
async def update_rule(rule_id: str, payload: RuleUpdate, request: Request, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "automacoes")
    if not _has(ctx["membership"]["role"], P_AUTOMATION_UPDATE):
        raise HTTPException(status_code=403, detail="Sem permissão.")
    result = await svc.update_rule(ctx["tenant"]["id"], rule_id, ctx["user"]["id"], payload.model_dump(exclude_none=True), request)
    if not result:
        raise HTTPException(status_code=404, detail="Regra não encontrada.")
    return result


@router.post("/automation-rules/{rule_id}/enable")
async def enable_rule(rule_id: str, request: Request, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "automacoes")
    if not _has(ctx["membership"]["role"], P_AUTOMATION_ENABLE_DISABLE):
        raise HTTPException(status_code=403, detail="Sem permissão.")
    return await svc.set_active(ctx["tenant"]["id"], rule_id, ctx["user"]["id"], True, request)


@router.post("/automation-rules/{rule_id}/disable")
async def disable_rule(rule_id: str, request: Request, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "automacoes")
    if not _has(ctx["membership"]["role"], P_AUTOMATION_ENABLE_DISABLE):
        raise HTTPException(status_code=403, detail="Sem permissão.")
    return await svc.set_active(ctx["tenant"]["id"], rule_id, ctx["user"]["id"], False, request)


@router.post("/automation-rules/{rule_id}/run")
async def run_rule(rule_id: str, request: Request, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "automacoes")
    if not _has(ctx["membership"]["role"], P_AUTOMATION_EXECUTE):
        raise HTTPException(status_code=403, detail="Sem permissão.")
    return await svc.execute_rule(ctx["tenant"]["id"], rule_id, ctx["user"]["id"], {}, request)


@router.delete("/automation-rules/{rule_id}")
async def delete_rule(rule_id: str, request: Request, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "automacoes")
    if not _has(ctx["membership"]["role"], P_AUTOMATION_DELETE):
        raise HTTPException(status_code=403, detail="Sem permissão.")
    await svc.delete_rule(ctx["tenant"]["id"], rule_id, ctx["user"]["id"], request)
    return {"deleted": True}


@router.get("/automation-executions")
async def list_executions(rule_id: Optional[str] = None, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "automacoes")
    if not _has(ctx["membership"]["role"], P_AUTOMATION_LOGS):
        raise HTTPException(status_code=403, detail="Sem permissão.")
    return await svc.list_executions(ctx["tenant"]["id"], rule_id)
