"""Loss reasons — depende de motivos_nao_venda."""
from fastapi import APIRouter, Depends, HTTPException, Request

from db import db
from models import LossReasonCreate, LossReasonUpdate, LossReasonStatusUpdate, new_id, utcnow_iso
from security import resolve_tenant_context, require_roles
from feature_guard import require_feature
from audit import log_audit

router = APIRouter(prefix="/tenants/{tenant_slug}/loss-reasons", tags=["loss-reasons"])


def _store_allowed(membership, store_id):
    if store_id is None:
        return membership["role"] in {"TENANT_ADMIN", "REGIONAL_MANAGER"}
    if membership["role"] in {"TENANT_ADMIN", "REGIONAL_MANAGER"}:
        return True
    return store_id in (membership.get("store_ids") or [])


async def _clean(cursor):
    items = await cursor.to_list(length=500)
    for it in items:
        it.pop("_id", None)
    return items


@router.get("")
async def list_reasons(ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "motivos_nao_venda")
    q = {"tenant_id": ctx["tenant"]["id"]}
    if ctx["membership"]["role"] == "STORE_MANAGER":
        ids = ctx["membership"].get("store_ids") or []
        q["$or"] = [{"store_id": None}, {"store_id": {"$in": ids}}]
    return await _clean(db.loss_reasons.find(q).sort("name", 1))


@router.post("", status_code=201)
async def create_reason(payload: LossReasonCreate, request: Request,
    ctx: dict = Depends(require_roles("TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER"))):
    tenant = ctx["tenant"]
    await require_feature(tenant["id"], "motivos_nao_venda")
    if not _store_allowed(ctx["membership"], payload.store_id):
        raise HTTPException(status_code=403, detail="Sem acesso para este escopo.")
    if payload.store_id:
        store = await db.stores.find_one({"tenant_id": tenant["id"], "id": payload.store_id})
        if not store:
            raise HTTPException(status_code=404, detail="Unidade não encontrada.")
    now = utcnow_iso()
    reason = {
        "id": new_id(), "tenant_id": tenant["id"], "store_id": payload.store_id,
        "name": payload.name, "description": payload.description,
        "active": payload.active if payload.active is not None else True,
        "created_at": now, "updated_at": now,
    }
    await db.loss_reasons.insert_one(reason)
    await log_audit(action="LOSS_REASON_CREATED", entity="loss_reason", entity_id=reason["id"],
        tenant_id=tenant["id"], store_id=payload.store_id, user_id=ctx["user"]["id"],
        new_value={"name": reason["name"]}, request=request)
    reason.pop("_id", None)
    return reason


@router.get("/{reason_id}")
async def get_reason(reason_id: str, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "motivos_nao_venda")
    r = await db.loss_reasons.find_one({"tenant_id": ctx["tenant"]["id"], "id": reason_id})
    if not r:
        raise HTTPException(status_code=404, detail="Motivo não encontrado.")
    r.pop("_id", None)
    return r


@router.put("/{reason_id}")
async def update_reason(reason_id: str, payload: LossReasonUpdate, request: Request,
    ctx: dict = Depends(require_roles("TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER"))):
    await require_feature(ctx["tenant"]["id"], "motivos_nao_venda")
    r = await db.loss_reasons.find_one({"tenant_id": ctx["tenant"]["id"], "id": reason_id})
    if not r:
        raise HTTPException(status_code=404, detail="Motivo não encontrado.")
    if not _store_allowed(ctx["membership"], r.get("store_id")):
        raise HTTPException(status_code=403, detail="Sem acesso.")
    updates = {k: v for k, v in payload.model_dump(exclude_none=True).items()}
    if updates:
        updates["updated_at"] = utcnow_iso()
        await db.loss_reasons.update_one(
            {"id": reason_id, "tenant_id": ctx["tenant"]["id"]}, {"$set": updates})
    await log_audit(action="LOSS_REASON_UPDATED", entity="loss_reason", entity_id=reason_id,
        tenant_id=ctx["tenant"]["id"], store_id=r.get("store_id"), user_id=ctx["user"]["id"],
        new_value=updates, request=request)
    updated = await db.loss_reasons.find_one({"id": reason_id, "tenant_id": ctx["tenant"]["id"]})
    updated.pop("_id", None)
    return updated


@router.patch("/{reason_id}/status")
async def status_reason(reason_id: str, payload: LossReasonStatusUpdate, request: Request,
    ctx: dict = Depends(require_roles("TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER"))):
    await require_feature(ctx["tenant"]["id"], "motivos_nao_venda")
    r = await db.loss_reasons.find_one({"tenant_id": ctx["tenant"]["id"], "id": reason_id})
    if not r:
        raise HTTPException(status_code=404, detail="Motivo não encontrado.")
    if not _store_allowed(ctx["membership"], r.get("store_id")):
        raise HTTPException(status_code=403, detail="Sem acesso.")
    await db.loss_reasons.update_one({"id": reason_id, "tenant_id": ctx["tenant"]["id"]},
        {"$set": {"active": payload.active, "updated_at": utcnow_iso()}})
    await log_audit(action="LOSS_REASON_STATUS_CHANGED", entity="loss_reason", entity_id=reason_id,
        tenant_id=ctx["tenant"]["id"], store_id=r.get("store_id"), user_id=ctx["user"]["id"],
        old_value={"active": r.get("active")}, new_value={"active": payload.active}, request=request)
    return {"id": reason_id, "active": payload.active}
