"""Serviço de eventos de segurança — Etapa 13."""
import logging
from typing import Any, Dict, Optional

from fastapi import Request

from db import db
from models import new_id, utcnow_iso

logger = logging.getLogger("lista-da-vez.security")


class SecurityEventType:
    LOGIN_SUCCESS = "LOGIN_SUCCESS"
    LOGIN_FAILED = "LOGIN_FAILED"
    LOGIN_LOCKED = "LOGIN_LOCKED"
    LOGOUT = "LOGOUT"
    LOGOUT_ALL = "LOGOUT_ALL"
    TOKEN_REFRESHED = "TOKEN_REFRESHED"
    REFRESH_TOKEN_REUSE_DETECTED = "REFRESH_TOKEN_REUSE_DETECTED"
    MFA_REQUIRED = "MFA_REQUIRED"
    MFA_SUCCESS = "MFA_SUCCESS"
    MFA_FAILED = "MFA_FAILED"
    ACCESS_DENIED = "ACCESS_DENIED"
    TENANT_SESSION_MISMATCH = "TENANT_SESSION_MISMATCH"
    STORE_ACCESS_DENIED = "STORE_ACCESS_DENIED"
    FEATURE_ACCESS_DENIED = "FEATURE_ACCESS_DENIED"
    RATE_LIMIT_EXCEEDED = "RATE_LIMIT_EXCEEDED"
    IDEMPOTENCY_CONFLICT = "IDEMPOTENCY_CONFLICT"
    SESSION_REVOKED = "SESSION_REVOKED"
    ROLE_CHANGED = "ROLE_CHANGED"
    TENANT_SUSPENDED_ACCESS_ATTEMPT = "TENANT_SUSPENDED_ACCESS_ATTEMPT"
    SUPER_ADMIN_LOGIN_SUCCESS = "SUPER_ADMIN_LOGIN_SUCCESS"
    SUPER_ADMIN_LOGIN_FAILED = "SUPER_ADMIN_LOGIN_FAILED"
    SUPER_ADMIN_SECURITY_SETTING_CHANGED = "SUPER_ADMIN_SECURITY_SETTING_CHANGED"
    EXPORT_STARTED = "EXPORT_STARTED"
    EXPORT_FINISHED = "EXPORT_FINISHED"
    EXPORT_FAILED = "EXPORT_FAILED"
    INVITE_SENT = "INVITE_SENT"
    INVITE_ACCEPTED = "INVITE_ACCEPTED"
    INVITE_INVALID = "INVITE_INVALID"


class SecuritySeverity:
    INFO = "INFO"
    WARNING = "WARNING"
    CRITICAL = "CRITICAL"


_SEVERITY_MAP: Dict[str, str] = {
    SecurityEventType.LOGIN_SUCCESS: SecuritySeverity.INFO,
    SecurityEventType.LOGIN_FAILED: SecuritySeverity.WARNING,
    SecurityEventType.LOGIN_LOCKED: SecuritySeverity.CRITICAL,
    SecurityEventType.LOGOUT: SecuritySeverity.INFO,
    SecurityEventType.LOGOUT_ALL: SecuritySeverity.WARNING,
    SecurityEventType.TOKEN_REFRESHED: SecuritySeverity.INFO,
    SecurityEventType.REFRESH_TOKEN_REUSE_DETECTED: SecuritySeverity.CRITICAL,
    SecurityEventType.MFA_REQUIRED: SecuritySeverity.INFO,
    SecurityEventType.MFA_SUCCESS: SecuritySeverity.INFO,
    SecurityEventType.MFA_FAILED: SecuritySeverity.WARNING,
    SecurityEventType.ACCESS_DENIED: SecuritySeverity.WARNING,
    SecurityEventType.TENANT_SESSION_MISMATCH: SecuritySeverity.CRITICAL,
    SecurityEventType.STORE_ACCESS_DENIED: SecuritySeverity.WARNING,
    SecurityEventType.FEATURE_ACCESS_DENIED: SecuritySeverity.INFO,
    SecurityEventType.RATE_LIMIT_EXCEEDED: SecuritySeverity.WARNING,
    SecurityEventType.IDEMPOTENCY_CONFLICT: SecuritySeverity.WARNING,
    SecurityEventType.SESSION_REVOKED: SecuritySeverity.WARNING,
    SecurityEventType.ROLE_CHANGED: SecuritySeverity.WARNING,
    SecurityEventType.TENANT_SUSPENDED_ACCESS_ATTEMPT: SecuritySeverity.CRITICAL,
    SecurityEventType.SUPER_ADMIN_LOGIN_SUCCESS: SecuritySeverity.INFO,
    SecurityEventType.SUPER_ADMIN_LOGIN_FAILED: SecuritySeverity.CRITICAL,
    SecurityEventType.SUPER_ADMIN_SECURITY_SETTING_CHANGED: SecuritySeverity.WARNING,
    SecurityEventType.EXPORT_STARTED: SecuritySeverity.INFO,
    SecurityEventType.EXPORT_FINISHED: SecuritySeverity.INFO,
    SecurityEventType.EXPORT_FAILED: SecuritySeverity.WARNING,
    SecurityEventType.INVITE_SENT: SecuritySeverity.INFO,
    SecurityEventType.INVITE_ACCEPTED: SecuritySeverity.INFO,
    SecurityEventType.INVITE_INVALID: SecuritySeverity.WARNING,
}


async def log_security_event(
    *,
    event_type: str,
    tenant_id: Optional[str] = None,
    tenant_slug: Optional[str] = None,
    user_id: Optional[str] = None,
    session_id: Optional[str] = None,
    ip: Optional[str] = None,
    user_agent: Optional[str] = None,
    request_id: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
    request: Optional[Request] = None,
):
    if request is not None:
        if not ip:
            ip = request.client.host if request.client else None
        if not user_agent:
            user_agent = request.headers.get("user-agent")
        if not request_id:
            request_id = getattr(request.state, "request_id", None)

    severity = _SEVERITY_MAP.get(event_type, SecuritySeverity.INFO)

    logger.info("SECURITY_EVENT type=%s severity=%s tenant=%s user=%s", event_type, severity, tenant_slug, user_id)

    try:
        await db.security_events.insert_one({
            "id": new_id(),
            "tenant_id": tenant_id,
            "tenant_slug": tenant_slug,
            "user_id": user_id,
            "session_id": session_id,
            "event_type": event_type,
            "severity": severity,
            "ip": ip,
            "user_agent": user_agent,
            "request_id": request_id,
            "metadata": metadata or {},
            "created_at": utcnow_iso(),
        })
    except Exception as exc:
        logger.error("Falha ao salvar security_event: %s", exc)
