"""Vendas (P0) — paginação, projeção segura, rate limit."""
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request

from db import db
from rate_limit_service import make_rate_limit_dep
from security import resolve_tenant_context
from feature_guard import require_feature
import sales_service

router = APIRouter(prefix="/tenants/{tenant_slug}/sales", tags=["sales"])

_rl_sales = make_rate_limit_dep("SALES_CREATE")


def _store_allowed(membership, store_id):
    if membership["role"] in {"TENANT_ADMIN", "REGIONAL_MANAGER"}:
        return True
    return store_id in (membership.get("store_ids") or [])


async def _enrich(items):
    seller_ids = [s["seller_id"] for s in items]
    sellers = {}
    if seller_ids:
        async for s in db.seller_profiles.find({"id": {"$in": seller_ids}}):
            sellers[s["id"]] = s
    users = {}
    if sellers:
        async for u in db.users.find({"id": {"$in": [s["user_id"] for s in sellers.values()]}}):
            users[u["id"]] = u
    stores = {}
    store_ids = list({s["store_id"] for s in items})
    if store_ids:
        async for st in db.stores.find({"id": {"$in": store_ids}}):
            stores[st["id"]] = st
    out = []
    for s in items:
        s.pop("_id", None)
        prof = sellers.get(s["seller_id"], {})
        u = users.get(prof.get("user_id"), {}) if prof else {}
        out.append({
            **s,
            "seller_name": u.get("name"),
            "seller_avatar_url": u.get("avatar_url") or prof.get("avatar_url"),
            "store_name": stores.get(s["store_id"], {}).get("name"),
        })
    return out


@router.get("")
async def list_sales(
    status: Optional[str] = None,
    store_id: Optional[str] = None,
    seller_id: Optional[str] = None,
    page: int = 1,
    page_size: int = 50,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "vendas_detalhadas")
    tenant_id = ctx["tenant"]["id"]
    role = ctx["membership"]["role"]

    page = max(1, page)
    page_size = min(max(1, page_size), 100)  # máximo 100 por página (P0)
    skip = (page - 1) * page_size

    q: dict = {"tenant_id": tenant_id}
    if status:
        q["status"] = status
    if store_id:
        q["store_id"] = store_id
    if seller_id:
        q["seller_id"] = seller_id
    if role in {"STORE_MANAGER", "SUPERVISOR"}:
        q["store_id"] = {"$in": ctx["membership"].get("store_ids") or []}
    elif role == "SELLER":
        own = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": ctx["user"]["id"]})
        q["seller_id"] = own["id"] if own else "__none__"

    total = await db.sales.count_documents(q)
    raw = await db.sales.find(q).sort("created_at", -1).skip(skip).limit(page_size).to_list(page_size)
    items = await _enrich(raw)
    return {
        "items": items,
        "pagination": {
            "page": page,
            "page_size": page_size,
            "total": total,
            "has_next": (skip + page_size) < total,
        },
    }


@router.get("/{sale_id}")
async def get_sale(sale_id: str, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "vendas_detalhadas")
    sale = await sales_service.get_sale_with_items(ctx["tenant"]["id"], sale_id)
    role = ctx["membership"]["role"]
    if role in {"STORE_MANAGER", "SUPERVISOR"} and not _store_allowed(ctx["membership"], sale["store_id"]):
        raise HTTPException(status_code=403, detail="Sem acesso.")
    if role == "SELLER":
        own = await db.seller_profiles.find_one({"tenant_id": ctx["tenant"]["id"], "user_id": ctx["user"]["id"]})
        if not own or sale["seller_id"] != own["id"]:
            raise HTTPException(status_code=403, detail="Sem acesso.")
    enriched = await _enrich([dict(sale)])
    enriched[0]["items"] = sale["items"]
    return enriched[0]
