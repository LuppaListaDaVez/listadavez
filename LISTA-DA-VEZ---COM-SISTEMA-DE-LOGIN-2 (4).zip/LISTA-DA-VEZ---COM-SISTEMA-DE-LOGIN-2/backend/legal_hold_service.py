"""LegalHoldService — Bloqueio de exclusão/anonimização (Etapa 14)."""
from typing import Optional
from db import db
from models import new_id, utcnow_iso
from audit import log_audit


async def create_hold(tenant_id: str, data: dict, created_by: str, request=None) -> dict:
    now = utcnow_iso()
    doc = {
        "id": new_id(), "tenant_id": tenant_id,
        "name": data.get("name", "Legal Hold"),
        "description": data.get("description", ""),
        "entity_type": data.get("entity_type", "USER"),
        "entity_id": data.get("entity_id"),
        "data_category": data.get("data_category"),
        "status": "ACTIVE",
        "created_by": created_by, "released_by": None,
        "created_at": now, "released_at": None,
        "reason": data.get("reason", ""),
    }
    await db.legal_holds.insert_one(doc)
    doc.pop("_id", None)
    await log_audit(action="LEGAL_HOLD_CREATED", entity="legal_hold", entity_id=doc["id"],
                    tenant_id=tenant_id, user_id=created_by, new_value=doc, request=request)
    return doc


async def release_hold(tenant_id: str, hold_id: str, released_by: str, request=None) -> Optional[dict]:
    doc = await db.legal_holds.find_one({"id": hold_id, "tenant_id": tenant_id})
    if not doc:
        return None
    now = utcnow_iso()
    await db.legal_holds.update_one(
        {"id": hold_id},
        {"$set": {"status": "RELEASED", "released_by": released_by, "released_at": now}}
    )
    await log_audit(action="LEGAL_HOLD_RELEASED", entity="legal_hold", entity_id=hold_id,
                    tenant_id=tenant_id, user_id=released_by, request=request)
    doc.update({"status": "RELEASED", "released_by": released_by, "released_at": now})
    doc.pop("_id", None)
    return doc


async def list_holds(tenant_id: str, status: Optional[str] = None) -> list:
    filt = {"tenant_id": tenant_id}
    if status:
        filt["status"] = status
    cursor = db.legal_holds.find(filt, {"_id": 0}).sort("created_at", -1).limit(100)
    return await cursor.to_list(length=100)


async def is_on_hold(tenant_id: str, entity_id: str) -> bool:
    hold = await db.legal_holds.find_one(
        {"tenant_id": tenant_id, "entity_id": entity_id, "status": "ACTIVE"}
    )
    return hold is not None
