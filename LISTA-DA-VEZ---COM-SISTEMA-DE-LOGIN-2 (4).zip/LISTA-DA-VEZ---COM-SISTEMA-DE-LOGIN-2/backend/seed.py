"""Seed initial data: super admin, plans, features, demo tenant + admin + store.

P0 — Guard de ambiente:
  SEED_DEMO_DATA=true  (padrão)  → Cria tenant demo, usuários demo e dados de exemplo.
  SEED_DEMO_DATA=false           → Pula dados demo. Use em produção.

Dados essenciais (features, planos, super admin) são SEMPRE criados independentemente.
"""
import os
import logging

from db import db
from features import FEATURE_CATALOG, set_tenant_feature
from models import new_id, utcnow_iso
from security import hash_password, verify_password

logger = logging.getLogger("lista-da-vez.seed")

_SEED_DEMO = os.environ.get("SEED_DEMO_DATA", "true").lower() == "true"


async def seed_features():
    now = utcnow_iso()
    for f in FEATURE_CATALOG:
        existing = await db.features.find_one({"key": f["key"]})
        if existing:
            continue
        await db.features.insert_one(
            {
                "id": new_id(),
                "key": f["key"],
                "name": f["name"],
                "description": f["description"],
                "created_at": now,
                "updated_at": now,
            }
        )


async def seed_plans():
    now = utcnow_iso()
    plans = [
        {"name": "Essencial", "description": "Plano básico para começar.", "limits": {"max_stores": 1, "max_users": 5}},
        {"name": "Performance", "description": "Plano intermediário.", "limits": {"max_stores": 5, "max_users": 25}},
        {"name": "Enterprise", "description": "Plano sem limites.", "limits": {}},
    ]
    for p in plans:
        existing = await db.plans.find_one({"name": p["name"]})
        if existing:
            continue
        await db.plans.insert_one(
            {
                "id": new_id(),
                "name": p["name"],
                "description": p["description"],
                "status": "ACTIVE",
                "limits": p["limits"],
                "created_at": now,
                "updated_at": now,
            }
        )


async def _get_or_create_user(*, name, email, password, is_super_admin=False) -> dict:
    existing = await db.users.find_one({"email": email})
    if existing:
        updates = {"name": name, "status": "ACTIVE", "is_super_admin": bool(existing.get("is_super_admin") or is_super_admin)}
        if password and not verify_password(password, existing.get("password_hash") or ""):
            updates["password_hash"] = hash_password(password)
        await db.users.update_one({"id": existing["id"]}, {"$set": {**updates, "updated_at": utcnow_iso()}})
        existing.update(updates)
        existing.pop("_id", None)
        return existing
    now = utcnow_iso()
    user = {
        "id": new_id(),
        "name": name,
        "email": email,
        "phone": None,
        "password_hash": hash_password(password),
        "avatar_url": None,
        "is_super_admin": is_super_admin,
        "status": "ACTIVE",
        "last_login_at": None,
        "created_at": now,
        "updated_at": now,
    }
    await db.users.insert_one(user)
    return user


async def seed_super_admin():
    email = os.environ.get("SUPER_ADMIN_EMAIL", "superadmin@sistema.com")
    password = os.environ.get("SUPER_ADMIN_PASSWORD", "Admin@123456")
    await _get_or_create_user(
        name="Super Admin",
        email=email,
        password=password,
        is_super_admin=True,
    )


async def seed_demo_tenant():
    slug = "demo"
    now = utcnow_iso()
    existing = await db.tenants.find_one({"slug": slug})
    if existing:
        tenant = existing
    else:
        enterprise_plan = await db.plans.find_one({"name": "Enterprise"})
        tenant = {
            "id": new_id(),
            "name": "Loja Demonstração",
            "slug": slug,
            "cnpj": None,
            "email": "contato@demo.com",
            "phone": None,
            "status": "ACTIVE",
            "plan_id": enterprise_plan["id"] if enterprise_plan else None,
            "logo_url": None,
            "primary_color": None,
            "created_at": now,
            "updated_at": now,
        }
        await db.tenants.insert_one(tenant)

    # Tenant admin user
    admin_email = os.environ.get("TENANT_ADMIN_EMAIL", "admin@demo.com")
    admin_password = os.environ.get("TENANT_ADMIN_PASSWORD", "Admin@123456")
    admin_user = await _get_or_create_user(
        name="Administrador Demo",
        email=admin_email,
        password=admin_password,
        is_super_admin=False,
    )

    # Membership
    membership = await db.tenant_memberships.find_one(
        {"tenant_id": tenant["id"], "user_id": admin_user["id"]}
    )
    if not membership:
        await db.tenant_memberships.insert_one(
            {
                "id": new_id(),
                "tenant_id": tenant["id"],
                "user_id": admin_user["id"],
                "role": "TENANT_ADMIN",
                "store_ids": [],
                "status": "ACTIVE",
                "created_at": now,
                "updated_at": now,
            }
        )

    # Store
    store_exists = await db.stores.find_one(
        {"tenant_id": tenant["id"], "code": "CENTRO"}
    )
    if not store_exists:
        await db.stores.insert_one(
            {
                "id": new_id(),
                "tenant_id": tenant["id"],
                "name": "Unidade Centro",
                "code": "CENTRO",
                "address": None,
                "city": "São Paulo",
                "state": "SP",
                "country": "Brasil",
                "timezone": "America/Sao_Paulo",
                "phone": None,
                "status": "ACTIVE",
                "created_at": now,
                "updated_at": now,
            }
        )

    # Activate all features for demo
    for f in FEATURE_CATALOG:
        await set_tenant_feature(
            tenant_id=tenant["id"],
            feature_key=f["key"],
            enabled=True,
            updated_by="seed",
        )

    # Default settings
    settings_exists = await db.tenant_settings.find_one({"tenant_id": tenant["id"]})
    if not settings_exists:
        await db.tenant_settings.insert_one(
            {
                "id": new_id(),
                "tenant_id": tenant["id"],
                "general_settings": {},
                "created_at": now,
                "updated_at": now,
            }
        )


DEFAULT_LOSS_REASONS = [
    "Preço alto", "Produto indisponível", "Sem estoque", "Só pesquisando",
    "Comprou no concorrente", "Faltou tamanho", "Faltou cor",
    "Cliente sem crédito", "Atendimento demorado", "Outro",
]


async def seed_etapa2():
    """Idempotent — adds teams, sellers, loss_reasons, store_settings for demo."""
    tenant = await db.tenants.find_one({"slug": "demo"})
    if not tenant:
        return
    tenant_id = tenant["id"]
    store = await db.stores.find_one({"tenant_id": tenant_id, "code": "CENTRO"})
    if not store:
        return
    store_id = store["id"]
    now = utcnow_iso()

    # Store settings
    from routes_store_settings import ensure_settings
    await ensure_settings(tenant_id, store_id)

    # Teams
    teams = {}
    for tname in ["Equipe Manhã", "Equipe Tarde"]:
        existing = await db.teams.find_one({"tenant_id": tenant_id, "store_id": store_id, "name": tname})
        if existing:
            teams[tname] = existing["id"]
        else:
            tid = new_id()
            await db.teams.insert_one({
                "id": tid, "tenant_id": tenant_id, "store_id": store_id,
                "name": tname, "description": None, "status": "ACTIVE",
                "created_at": now, "updated_at": now,
            })
            teams[tname] = tid

    # Loss reasons
    for name in DEFAULT_LOSS_REASONS:
        if not await db.loss_reasons.find_one({"tenant_id": tenant_id, "store_id": None, "name": name}):
            await db.loss_reasons.insert_one({
                "id": new_id(), "tenant_id": tenant_id, "store_id": None,
                "name": name, "description": None, "active": True,
                "created_at": now, "updated_at": now,
            })

    # Sellers
    sellers_data = [
        ("João Silva", "joao@demo.com", "V001", "Equipe Manhã", "AVAILABLE"),
        ("Maria Oliveira", "maria@demo.com", "V002", "Equipe Manhã", "AVAILABLE"),
        ("Carlos Souza", "carlos@demo.com", "V003", "Equipe Tarde", "OFFLINE"),
        ("Ana Lima", "ana@demo.com", "V004", "Equipe Tarde", "BREAK"),
    ]
    for name, email, code, team_name, status in sellers_data:
        user = await _get_or_create_user(name=name, email=email, password="Admin@123456")
        # ensure membership
        mem = await db.tenant_memberships.find_one({"tenant_id": tenant_id, "user_id": user["id"]})
        if not mem:
            await db.tenant_memberships.insert_one({
                "id": new_id(), "tenant_id": tenant_id, "user_id": user["id"],
                "role": "SELLER", "store_ids": [store_id], "status": "ACTIVE",
                "created_at": now, "updated_at": now,
            })
        existing = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": user["id"]})
        if existing:
            continue
        await db.seller_profiles.insert_one({
            "id": new_id(), "tenant_id": tenant_id, "user_id": user["id"],
            "store_id": store_id, "team_id": teams.get(team_name),
            "employee_code": code, "hire_date": "2026-01-01",
            "status": "ACTIVE", "current_status": status, "avatar_url": None,
            "created_at": now, "updated_at": now,
        })


async def seed_presentation_demo():
    """Seed idempotente para apresentação: 3 unidades, 7 vendedores e 7 dias de histórico."""
    from datetime import datetime, timezone, timedelta
    from queue_engine import ensure_default_queue, recalculate_positions, QUEUE_DEFAULT_SETTINGS
    from routes_store_settings import ensure_settings

    tenant = await db.tenants.find_one({"slug": "demo"})
    if not tenant:
        return
    tenant_id = tenant["id"]
    now = utcnow_iso()
    now_dt = datetime.now(timezone.utc)
    admin_user = await db.users.find_one({"email": "admin@demo.com"})
    actor_id = admin_user["id"] if admin_user else "seed"

    await db.tenants.update_one(
        {"id": tenant_id},
        {"$set": {"name": "Loja Demonstração", "status": "ACTIVE", "updated_at": now}},
    )

    async def ensure_store(code, name, city):
        existing = await db.stores.find_one({"tenant_id": tenant_id, "code": code})
        payload = {
            "tenant_id": tenant_id,
            "name": name,
            "code": code,
            "address": None,
            "city": city,
            "state": "SP",
            "country": "Brasil",
            "timezone": "America/Sao_Paulo",
            "phone": None,
            "status": "ACTIVE",
            "updated_at": now,
        }
        if existing:
            await db.stores.update_one({"id": existing["id"]}, {"$set": payload})
            existing.update(payload)
            return existing
        doc = {"id": new_id(), "created_at": now, **payload}
        await db.stores.insert_one(doc)
        return doc

    stores = {
        "CENTRO": await ensure_store("CENTRO", "Unidade Centro", "São Paulo"),
        "NORTE": await ensure_store("NORTE", "Unidade Norte", "São Paulo"),
        "SUL": await ensure_store("SUL", "Unidade Sul", "São Paulo"),
    }

    for store in stores.values():
        await ensure_settings(tenant_id, store["id"])
        queue = await ensure_default_queue(tenant_id, store["id"])
        await db.queues.update_one(
            {"id": queue["id"]},
            {"$set": {"name": "Fila Geral", "type": "GENERAL", "settings": {**QUEUE_DEFAULT_SETTINGS, **(queue.get("settings") or {})}, "updated_at": now}},
        )

    teams = {}
    for code, store in stores.items():
        team_name = f"Equipe {store['name'].replace('Unidade ', '')}"
        existing = await db.teams.find_one({"tenant_id": tenant_id, "store_id": store["id"], "name": team_name})
        if existing:
            teams[code] = existing["id"]
            await db.teams.update_one({"id": existing["id"]}, {"$set": {"status": "ACTIVE", "updated_at": now}})
        else:
            team_id = new_id()
            await db.teams.insert_one({
                "id": team_id, "tenant_id": tenant_id, "store_id": store["id"],
                "name": team_name, "description": None, "status": "ACTIVE",
                "created_at": now, "updated_at": now,
            })
            teams[code] = team_id

    seller_specs = [
        ("João Silva", "joao@demo.com", "V001", "CENTRO", "WAITING_IN_QUEUE", False, False, None),
        ("Maria Oliveira", "maria@demo.com", "V002", "CENTRO", "WAITING_IN_QUEUE", False, False, None),
        ("Ana Lima", "ana@demo.com", "V004", "CENTRO", "BREAK", False, False, "LANCHE_OU_ALMOCO"),
        ("Carlos Souza", "carlos@demo.com", "V003", "NORTE", "AVAILABLE", False, False, None),
        ("Beatriz Costa", "beatriz@demo.com", "V005", "NORTE", "SERVING", False, False, None),
        ("Rafael Mendes", "rafael@demo.com", "V006", "SUL", "AVAILABLE", False, False, None),
        ("Paula Rocha", "paula@demo.com", "V007", "SUL", "OFFLINE", False, True, "ENCERRAR_DIA"),
    ]
    sellers_by_email = {}
    sellers_by_store = {code: [] for code in stores}
    for name, email, code, store_code, current_status, em_operacao, jornada_encerrada, motivo_saida in seller_specs:
        store = stores[store_code]
        user = await _get_or_create_user(name=name, email=email, password="Admin@123456")
        await db.users.update_one({"id": user["id"]}, {"$set": {"name": name, "status": "ACTIVE", "updated_at": now}})
        mem = await db.tenant_memberships.find_one({"tenant_id": tenant_id, "user_id": user["id"]})
        mem_payload = {"role": "SELLER", "store_ids": [store["id"]], "status": "ACTIVE", "updated_at": now}
        if mem:
            await db.tenant_memberships.update_one({"id": mem["id"]}, {"$set": mem_payload})
        else:
            await db.tenant_memberships.insert_one({"id": new_id(), "tenant_id": tenant_id, "user_id": user["id"], "created_at": now, **mem_payload})
        seller = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": user["id"]})
        seller_payload = {
            "tenant_id": tenant_id, "user_id": user["id"], "store_id": store["id"],
            "team_id": teams[store_code], "employee_code": code, "hire_date": "2026-01-01",
            "status": "ACTIVE", "current_status": current_status, "avatar_url": None,
            "em_atividade_operacional": em_operacao, "jornada_encerrada": jornada_encerrada,
            "motivo_saida": motivo_saida, "updated_at": now,
        }
        if seller:
            await db.seller_profiles.update_one({"id": seller["id"]}, {"$set": seller_payload})
            seller.update(seller_payload)
        else:
            seller = {"id": new_id(), "created_at": now, **seller_payload}
            await db.seller_profiles.insert_one(seller)
        sellers_by_email[email] = seller
        sellers_by_store[store_code].append(seller)

    all_demo_seller_ids = [s["id"] for s in sellers_by_email.values()]
    await db.queue_entries.delete_many({"tenant_id": tenant_id, "seller_id": {"$in": all_demo_seller_ids}, "status": "WAITING"})
    for store_code, store_sellers in sellers_by_store.items():
        queue = await ensure_default_queue(tenant_id, stores[store_code]["id"])
        pos = 1
        for seller in store_sellers:
            if seller.get("current_status") != "WAITING_IN_QUEUE":
                continue
            await db.queue_entries.insert_one({
                "id": new_id(), "tenant_id": tenant_id, "store_id": stores[store_code]["id"],
                "queue_id": queue["id"], "seller_id": seller["id"], "user_id": seller["user_id"],
                "position": pos, "status": "WAITING", "entered_at": (now_dt - timedelta(minutes=35 - pos * 5)).isoformat(),
                "updated_at": now,
            })
            pos += 1
        await recalculate_positions(tenant_id, queue["id"])

    manager_updates = [
        ("gerente@demo.com", "STORE_MANAGER", [stores["CENTRO"]["id"]]),
        ("regional@demo.com", "REGIONAL_MANAGER", []),
        ("supervisor@demo.com", "SUPERVISOR", [s["id"] for s in stores.values()]),
    ]
    for email, role, store_ids in manager_updates:
        user = await db.users.find_one({"email": email})
        if not user:
            continue
        await db.tenant_memberships.update_one(
            {"tenant_id": tenant_id, "user_id": user["id"]},
            {"$set": {"role": role, "store_ids": store_ids, "status": "ACTIVE", "updated_at": now}},
        )

    beatriz = sellers_by_email.get("beatriz@demo.com")
    if beatriz:
        store = stores["NORTE"]
        queue = await ensure_default_queue(tenant_id, store["id"])
        visit_id = "seed-presentation-active-visit"
        att_id = "seed-presentation-active-attendance"
        started = (now_dt - timedelta(minutes=18)).isoformat()
        await db.customer_visits.replace_one(
            {"id": visit_id},
            {
                "id": visit_id, "tenant_id": tenant_id, "store_id": store["id"], "queue_id": queue["id"],
                "seller_id": beatriz["id"], "customer_name": "Cliente em atendimento", "customer_phone": None,
                "source": "QUEUE", "arrival_time": started, "start_time": started, "end_time": None,
                "status": "IN_PROGRESS", "notes": "Atendimento ativo para demonstração.",
                "seed_key": "presentation-active", "created_at": started, "updated_at": now,
            },
            upsert=True,
        )
        await db.attendances.replace_one(
            {"id": att_id},
            {
                "id": att_id, "tenant_id": tenant_id, "store_id": store["id"], "queue_id": queue["id"],
                "customer_visit_id": visit_id, "seller_id": beatriz["id"], "started_at": started,
                "finished_at": None, "status": "IN_PROGRESS", "source": "QUEUE", "origin": "QUEUE",
                "attendance_type": "QUEUE", "result": None, "sale_amount_cents": None,
                "loss_reason_id": None, "notes": "Atendimento ativo para demonstração.",
                "created_by": actor_id, "seed_key": "presentation-active", "created_at": started, "updated_at": now,
            },
            upsert=True,
        )

    loss_reason = await db.loss_reasons.find_one({"tenant_id": tenant_id, "name": "Preço alto"})
    loss_reason_id = loss_reason["id"] if loss_reason else None
    customer_names = ["Marina", "Felipe", "Renata", "Gustavo", "Camila", "Eduardo", "Larissa", "Bruno", "Patrícia", "André"]
    type_cycle = ["QUEUE", "QUEUE", "PREFERENCE", "QUICK", "MULTIPLE"]
    result_cycle = ["SALE", "NO_SALE", "SALE", "FOLLOW_UP", "SALE", "NO_SALE", "INVALID", "SALE"]
    store_codes = ["CENTRO", "NORTE", "SUL"]

    for day_ago in range(0, 7):
        for store_index, store_code in enumerate(store_codes):
            store = stores[store_code]
            queue = await ensure_default_queue(tenant_id, store["id"])
            store_sellers = sellers_by_store[store_code]
            for idx in range(5):
                seller = store_sellers[(idx + day_ago) % len(store_sellers)]
                seed_key = f"presentation-{day_ago}-{store_code}-{idx}"
                if day_ago == 0:
                    started_dt = now_dt - timedelta(hours=idx + store_index + 1, minutes=7 * idx)
                else:
                    started_dt = (now_dt - timedelta(days=day_ago)).replace(hour=10 + idx * 2, minute=10 + store_index * 7, second=0, microsecond=0)
                if started_dt > now_dt:
                    started_dt = now_dt - timedelta(hours=idx + 1)
                finished_dt = started_dt + timedelta(minutes=12 + ((idx + day_ago + store_index) % 4) * 8)
                result = result_cycle[(idx + day_ago + store_index) % len(result_cycle)]
                attendance_type = type_cycle[(idx + store_index + day_ago) % len(type_cycle)]
                amount = 0
                product_qty = 0
                if result == "SALE":
                    amount = 12990 + ((idx + day_ago + store_index) % 6) * 7490
                    product_qty = 1 + ((idx + day_ago) % 4)
                visit_id = f"seed-visit-{seed_key}"
                att_id = f"seed-att-{seed_key}"
                sale_id = f"seed-sale-{seed_key}"
                customer_name = f"{customer_names[(idx + day_ago + store_index) % len(customer_names)]} Demo"
                started_iso = started_dt.isoformat()
                finished_iso = finished_dt.isoformat()
                visit_status = {"SALE": "CONVERTED", "NO_SALE": "LOST", "FOLLOW_UP": "ABANDONED", "INVALID": "INVALID"}.get(result, "LOST")
                await db.customer_visits.replace_one(
                    {"id": visit_id},
                    {
                        "id": visit_id, "tenant_id": tenant_id, "store_id": store["id"], "queue_id": queue["id"],
                        "seller_id": seller["id"], "customer_name": customer_name, "customer_phone": None,
                        "source": attendance_type, "arrival_time": started_iso, "start_time": started_iso,
                        "end_time": finished_iso, "status": visit_status, "notes": "Histórico realista de apresentação.",
                        "seed_key": seed_key, "created_at": started_iso, "updated_at": now,
                    },
                    upsert=True,
                )
                attendance_doc = {
                    "id": att_id, "tenant_id": tenant_id, "store_id": store["id"], "queue_id": queue["id"],
                    "customer_visit_id": visit_id, "seller_id": seller["id"], "started_at": started_iso,
                    "finished_at": finished_iso, "status": "FINISHED", "source": attendance_type,
                    "origin": attendance_type, "attendance_type": attendance_type, "result": result,
                    "sale_amount_cents": amount if result == "SALE" else None,
                    "sale_id": sale_id if result == "SALE" else None,
                    "loss_reason_id": loss_reason_id if result == "NO_SALE" else None,
                    "notes": "Seed de apresentação" if result != "INVALID" else "Atendimento inválido para demonstrar filtro.",
                    "product_quantity": product_qty if result == "SALE" else None,
                    "is_multiple": attendance_type == "MULTIPLE",
                    "multiple_batch_id": f"seed-batch-{day_ago}-{store_code}" if attendance_type == "MULTIPLE" else None,
                    "created_by": actor_id, "seed_key": seed_key, "created_at": started_iso, "updated_at": now,
                }
                await db.attendances.replace_one({"id": att_id}, attendance_doc, upsert=True)
                if result == "SALE":
                    sale_doc = {
                        "id": sale_id, "tenant_id": tenant_id, "store_id": store["id"], "attendance_id": att_id,
                        "seller_id": seller["id"], "customer_visit_id": visit_id, "gross_amount_cents": amount,
                        "discount_amount_cents": 0, "net_amount_cents": amount,
                        "payment_methods": [{"method": "CREDIT", "amount_cents": amount}],
                        "item_count": product_qty, "notes": "Venda de apresentação", "status": "COMPLETED",
                        "created_by": actor_id, "seed_key": seed_key, "created_at": finished_iso, "updated_at": now,
                    }
                    await db.sales.replace_one({"id": sale_id}, sale_doc, upsert=True)
                    await db.sale_items.replace_one(
                        {"id": f"seed-sale-item-{seed_key}"},
                        {
                            "id": f"seed-sale-item-{seed_key}", "tenant_id": tenant_id, "store_id": store["id"],
                            "sale_id": sale_id, "attendance_id": att_id, "product_id": None,
                            "name": "Mix de produtos demo", "sku": "DEMO-MIX", "quantity": product_qty,
                            "unit_price_cents": max(1, amount // max(product_qty, 1)), "discount_cents": 0,
                            "line_total_cents": amount, "seed_key": seed_key, "created_at": finished_iso,
                        },
                        upsert=True,
                    )
                else:
                    await db.sales.delete_one({"id": sale_id})
                    await db.sale_items.delete_one({"id": f"seed-sale-item-{seed_key}"})

    for store_code in store_codes:
        for day_ago in range(0, 7):
            batch_id = f"seed-batch-{day_ago}-{store_code}"
            if not await db.multiple_attendance_batches.find_one({"id": batch_id}):
                await db.multiple_attendance_batches.insert_one({
                    "id": batch_id, "tenant_id": tenant_id, "store_id": stores[store_code]["id"],
                    "queue_id": (await ensure_default_queue(tenant_id, stores[store_code]["id"]))["id"],
                    "seller_id": sellers_by_store[store_code][0]["id"], "mode": "AGGREGATED",
                    "total_customers": 2, "total_successes": 1, "total_no_sales": 1,
                    "total_amount_cents": 29990, "total_product_quantity": 2,
                    "notes": "Lote múltiplo de apresentação", "status": "COMPLETED",
                    "created_by": actor_id, "seed_key": batch_id, "created_at": now, "updated_at": now,
                })


async def run_seed():
    # Dados essenciais — sempre executados
    await seed_features()
    await seed_plans()
    await seed_super_admin()

    if not _SEED_DEMO:
        logger.info("SEED_DEMO_DATA=false — pulando dados demo (produção).")
        return

    # Dados demo — apenas quando SEED_DEMO_DATA=true
    logger.info("SEED_DEMO_DATA=true — criando dados demo...")
    await seed_demo_tenant()
    await seed_etapa2()
    await seed_etapa3()
    await seed_etapa4()
    await seed_etapa5()
    await seed_etapa6()
    await seed_etapa7_features()
    await seed_etapa9()
    await seed_etapa10()
    await seed_etapa13()
    await seed_etapa11()
    await seed_etapa12()
    await seed_presentation_demo()


async def seed_etapa7_features():
    """Idempotente — ativa features de dashboards e relatórios."""
    tenant = await db.tenants.find_one({"slug": "demo"})
    if not tenant:
        return
    tenant_id = tenant["id"]
    for key in ("dashboards", "relatorios_basicos", "relatorios_avancados", "exportacao",
                "motivos_nao_venda"):
        await set_tenant_feature(tenant_id=tenant_id, feature_key=key, enabled=True, updated_by="seed")


async def seed_etapa9():
    """Idempotente — ativa features Etapa 9 e cria metas/badges demo."""
    tenant = await db.tenants.find_one({"slug": "demo"})
    if not tenant:
        return
    tenant_id = tenant["id"]

    # Ativar features
    for key in ("metas", "rankings", "gamificacao"):
        await set_tenant_feature(tenant_id=tenant_id, feature_key=key, enabled=True, updated_by="seed")

    store = await db.stores.find_one({"tenant_id": tenant_id, "code": "CENTRO"})
    if not store:
        return
    store_id = store["id"]

    # Sellers demo
    joao_user = await db.users.find_one({"email": "joao@demo.com"})
    maria_user = await db.users.find_one({"email": "maria@demo.com"})
    joao_seller = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": joao_user["id"]}) if joao_user else None
    maria_seller = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": maria_user["id"]}) if maria_user else None

    from datetime import date
    today = date.today()
    month_start = date(today.year, today.month, 1).isoformat()
    month_end = date(today.year, today.month, 28).isoformat()
    now = utcnow_iso()
    admin_user = await db.users.find_one({"email": "admin@demo.com"})
    actor_id = admin_user["id"] if admin_user else "seed"

    def _make_goal(title, gtype, scope, store_id=None, seller_id=None, target=0):
        return {
            "id": new_id(), "tenant_id": tenant_id,
            "store_id": store_id, "team_id": None, "seller_id": seller_id,
            "created_by": actor_id, "title": title, "description": None,
            "type": gtype, "scope": scope, "period": "MONTHLY",
            "target_value": target, "current_value": 0, "progress_percent": 0,
            "status": "ACTIVE",
            "period_start": month_start, "period_end": month_end,
            "created_at": now, "updated_at": now,
            "completed_at": None, "cancelled_at": None,
        }

    demo_goals = [
        _make_goal("Meta mensal da Unidade Centro", "REVENUE", "STORE", store_id=store_id, target=1000000),
        _make_goal("Meta de vendas João", "SALES_COUNT", "SELLER",
                   store_id=store_id, seller_id=joao_seller["id"] if joao_seller else None, target=20),
        _make_goal("Conversão Maria", "CONVERSION", "SELLER",
                   store_id=store_id, seller_id=maria_seller["id"] if maria_seller else None, target=7000),
    ]

    for g in demo_goals:
        if g.get("seller_id") is None and g["scope"] == "SELLER":
            continue
        if not await db.goals.find_one({"tenant_id": tenant_id, "title": g["title"]}):
            await db.goals.insert_one(g)

    # Badge demo para João
    if joao_seller:
        from gamification_service import award_badge
        await award_badge(
            tenant_id=tenant_id, seller_id=joao_seller["id"], store_id=store_id,
            badge_key="FIRST_SALE_OF_DAY",
            period_start=month_start, period_end=month_start,
            metadata={"seeded": True},
        )


async def seed_etapa10():
    """Idempotente — ativa features Etapa 10 e cria feedbacks demo."""
    tenant = await db.tenants.find_one({"slug": "demo"})
    if not tenant:
        return
    tenant_id = tenant["id"]

    # Ativar features
    for key in ("feedbacks", "notificacoes"):
        await set_tenant_feature(tenant_id=tenant_id, feature_key=key, enabled=True, updated_by="seed")

    store = await db.stores.find_one({"tenant_id": tenant_id, "code": "CENTRO"})
    if not store:
        return
    store_id = store["id"]

    admin_user = await db.users.find_one({"email": "admin@demo.com"})
    gerente_user = await db.users.find_one({"email": "gerente@demo.com"})
    joao_user = await db.users.find_one({"email": "joao@demo.com"})
    maria_user = await db.users.find_one({"email": "maria@demo.com"})
    if not (admin_user and joao_user and maria_user):
        return

    joao_seller = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": joao_user["id"]})
    maria_seller = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": maria_user["id"]})
    if not (joao_seller and maria_seller):
        return

    now = utcnow_iso()

    demo_feedbacks = [
        {
            "title": "Ótimo desempenho em março!",
            "content": "Você superou as expectativas esse mês. Continue assim e busque sempre o melhor para o cliente.",
            "type": "POSITIVE",
            "seller_id": joao_seller["id"],
            "seller_user_id": joao_user["id"],
            "author_id": admin_user["id"],
            "author_name": "Administrador Demo",
            "action_plan": None,
        },
        {
            "title": "Melhore a abordagem inicial",
            "content": "Percebi que você está demorando para abordar os clientes ao entrar na loja. Trabalhe nisso.",
            "type": "ACTION_PLAN",
            "seller_id": joao_seller["id"],
            "seller_user_id": joao_user["id"],
            "author_id": gerente_user["id"] if gerente_user else admin_user["id"],
            "author_name": "Gerente Demo",
            "action_plan": {
                "description": "Abordar o cliente em até 30 segundos após a entrada na loja.",
                "due_date": "2026-03-31",
                "status": "PENDING",
            },
        },
        {
            "title": "Foco nos produtos premium",
            "content": "Você tem potencial para vender mais produtos de alta margem. Explore o catálogo premium.",
            "type": "CONSTRUCTIVE",
            "seller_id": maria_seller["id"],
            "seller_user_id": maria_user["id"],
            "author_id": admin_user["id"],
            "author_name": "Administrador Demo",
            "action_plan": None,
        },
    ]

    for fb in demo_feedbacks:
        if await db.feedbacks.find_one({"tenant_id": tenant_id, "title": fb["title"], "seller_id": fb["seller_id"]}):
            continue
        doc = {
            "id": new_id(),
            "tenant_id": tenant_id,
            "store_id": store_id,
            "is_acknowledged": False,
            "acknowledged_at": None,
            "created_at": now,
            "updated_at": now,
            **fb,
        }
        await db.feedbacks.insert_one(doc)

    # Notificações demo para João
    demo_notifications = [
        {
            "user_id": joao_user["id"],
            "type": "FEEDBACK_RECEIVED",
            "title": "Novo feedback: Feedback Positivo",
            "body": 'Administrador Demo enviou um feedback: "Ótimo desempenho em março!"',
            "entity_type": "feedback",
        },
        {
            "user_id": joao_user["id"],
            "type": "BADGE_EARNED",
            "title": "Conquista desbloqueada!",
            "body": 'Você ganhou o badge "Primeira Venda do Dia".',
            "entity_type": "badge",
        },
    ]
    for notif in demo_notifications:
        if await db.notifications.find_one({"tenant_id": tenant_id, "user_id": notif["user_id"], "title": notif["title"]}):
            continue
        await db.notifications.insert_one({
            "id": new_id(),
            "tenant_id": tenant_id,
            "entity_id": None,
            "is_read": False,
            "read_at": None,
            "created_at": now,
            **notif,
        })


async def seed_etapa6():
    """Idempotente — cria usuários demo para cada role: gerente, supervisor, regional."""
    tenant = await db.tenants.find_one({"slug": "demo"})
    if not tenant:
        return
    tenant_id = tenant["id"]
    store = await db.stores.find_one({"tenant_id": tenant_id, "code": "CENTRO"})
    if not store:
        return
    store_id = store["id"]
    now = utcnow_iso()

    demo_users = [
        ("Gerente Demo", "gerente@demo.com", "STORE_MANAGER", [store_id]),
        ("Supervisor Demo", "supervisor@demo.com", "SUPERVISOR", [store_id]),
        ("Regional Demo", "regional@demo.com", "REGIONAL_MANAGER", [store_id]),
    ]
    for name, email, role, store_ids in demo_users:
        user = await _get_or_create_user(name=name, email=email, password="Admin@123456")
        mem = await db.tenant_memberships.find_one({"tenant_id": tenant_id, "user_id": user["id"]})
        if not mem:
            await db.tenant_memberships.insert_one({
                "id": new_id(), "tenant_id": tenant_id, "user_id": user["id"],
                "role": role, "store_ids": store_ids, "status": "ACTIVE",
                "created_at": now, "updated_at": now,
            })
        else:
            # Update role/store_ids if changed
            if mem.get("role") != role or mem.get("store_ids") != store_ids:
                await db.tenant_memberships.update_one(
                    {"id": mem["id"]},
                    {"$set": {"role": role, "store_ids": store_ids, "updated_at": now}},
                )


async def seed_etapa5():
    """Idempotente — ativa features comerciais e cria produtos demo."""
    tenant = await db.tenants.find_one({"slug": "demo"})
    if not tenant:
        return
    tenant_id = tenant["id"]
    for key in ("produtos", "vendas_detalhadas", "registro_rapido"):
        await set_tenant_feature(tenant_id=tenant_id, feature_key=key, enabled=True, updated_by="seed")
    now = utcnow_iso()
    products = [
        ("TENIS-001", "Tênis Esportivo", 29990, "Calçados"),
        ("CAMISETA-001", "Camiseta Básica", 7990, "Vestuário"),
        ("BOLSA-001", "Bolsa Casual", 15990, "Acessórios"),
    ]
    for sku, name, price_cents, category in products:
        if await db.products.find_one({"tenant_id": tenant_id, "sku": sku}):
            continue
        await db.products.insert_one({
            "id": new_id(), "tenant_id": tenant_id, "store_id": None,
            "sku": sku, "name": name, "description": None,
            "price_cents": price_cents, "category": category, "active": True,
            "created_at": now, "updated_at": now,
        })


async def seed_etapa4():
    """Idempotente — garante features de tempo real ativas para o tenant demo."""
    tenant = await db.tenants.find_one({"slug": "demo"})
    if not tenant:
        return
    for key in ("lista_da_vez", "tempo_real"):
        await set_tenant_feature(tenant_id=tenant["id"], feature_key=key, enabled=True, updated_by="seed")


async def seed_etapa3():
    """Idempotente — cria a fila padrão e coloca João e Maria na fila para demo."""
    tenant = await db.tenants.find_one({"slug": "demo"})
    if not tenant:
        return
    tenant_id = tenant["id"]
    store = await db.stores.find_one({"tenant_id": tenant_id, "code": "CENTRO"})
    if not store:
        return
    store_id = store["id"]

    from queue_engine import ensure_default_queue, _insert_at_end, recalculate_positions, _emit_event

    queue = await ensure_default_queue(tenant_id, store_id)

    for email in ["joao@demo.com", "maria@demo.com"]:
        user = await db.users.find_one({"email": email})
        if not user:
            continue
        seller = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": user["id"]})
        if not seller:
            continue
        if await db.queue_entries.find_one({"tenant_id": tenant_id, "queue_id": queue["id"], "seller_id": seller["id"], "status": "WAITING"}):
            continue
        if seller.get("current_status") not in ("AVAILABLE", "WAITING_IN_QUEUE"):
            continue
        await db.seller_profiles.update_one(
            {"id": seller["id"]},
            {"$set": {"current_status": "WAITING_IN_QUEUE", "updated_at": utcnow_iso()}},
        )
        await _insert_at_end(tenant_id, store_id, queue["id"], seller)
        await _emit_event(tenant_id, store_id, queue["id"], seller["id"], "SELLER_JOINED", "seed")

    await recalculate_positions(tenant_id, queue["id"])


async def seed_etapa13():
    """Etapa 13 — Cria segundo tenant 'demo-b' para testar isolamento cross-tenant.
    Também garante que joao@demo.com exista em ambos os tenants (mesmo e-mail, dois tenants).
    """
    now = utcnow_iso()

    # Garantir que o tenant demo-b existe
    demo_b = await db.tenants.find_one({"slug": "demo-b"})
    if not demo_b:
        enterprise_plan = await db.plans.find_one({"name": "Enterprise"})
        demo_b = {
            "id": new_id(),
            "name": "Loja Demo B (Isolamento)",
            "slug": "demo-b",
            "cnpj": None,
            "email": "contato@demo-b.com",
            "phone": None,
            "status": "ACTIVE",
            "plan_id": enterprise_plan["id"] if enterprise_plan else None,
            "logo_url": None,
            "primary_color": None,
            "created_at": now,
            "updated_at": now,
        }
        await db.tenants.insert_one(demo_b)
    demo_b.pop("_id", None)
    tenant_b_id = demo_b["id"]

    # Admin do tenant B
    admin_b = await _get_or_create_user(
        name="Admin Demo B",
        email="admin@demo-b.com",
        password="Admin@123456",
    )
    mem_b = await db.tenant_memberships.find_one(
        {"tenant_id": tenant_b_id, "user_id": admin_b["id"]}
    )
    if not mem_b:
        await db.tenant_memberships.insert_one({
            "id": new_id(), "tenant_id": tenant_b_id, "user_id": admin_b["id"],
            "role": "TENANT_ADMIN", "store_ids": [], "status": "ACTIVE",
            "created_at": now, "updated_at": now,
        })

    # Loja no tenant B
    if not await db.stores.find_one({"tenant_id": tenant_b_id, "code": "STORE-B"}):
        store_b = {
            "id": new_id(), "tenant_id": tenant_b_id,
            "name": "Filial B Centro", "code": "STORE-B",
            "address": None, "city": "Rio de Janeiro", "state": "RJ",
            "country": "Brasil", "timezone": "America/Sao_Paulo",
            "phone": None, "status": "ACTIVE",
            "created_at": now, "updated_at": now,
        }
        await db.stores.insert_one(store_b)

    # Ativar features básicas no tenant B
    for key in ("lista_da_vez", "tempo_real", "dashboards", "relatorios_basicos"):
        await set_tenant_feature(tenant_id=tenant_b_id, feature_key=key, enabled=True, updated_by="seed")

    # Vendedor João também no tenant B (mesmo email, dois tenants = testa isolamento)
    joao = await db.users.find_one({"email": "joao@demo.com"})
    if joao:
        mem_joao_b = await db.tenant_memberships.find_one(
            {"tenant_id": tenant_b_id, "user_id": joao["id"]}
        )
        if not mem_joao_b:
            await db.tenant_memberships.insert_one({
                "id": new_id(), "tenant_id": tenant_b_id, "user_id": joao["id"],
                "role": "SELLER", "store_ids": [], "status": "ACTIVE",
                "created_at": now, "updated_at": now,
            })



async def seed_etapa11():
    """Idempotente — cria dados demo de abordagem proativa."""
    from datetime import datetime, timezone, timedelta

    tenant = await db.tenants.find_one({"slug": "demo"})
    if not tenant:
        return
    tenant_id = tenant["id"]

    # Ativar feature
    await set_tenant_feature(tenant_id=tenant_id, feature_key="abordagem_proativa", enabled=True, updated_by="seed")

    store = await db.stores.find_one({"tenant_id": tenant_id, "code": "CENTRO"})
    if not store:
        return
    store_id = store["id"]

    joao_user = await db.users.find_one({"email": "joao@demo.com"})
    maria_user = await db.users.find_one({"email": "maria@demo.com"})
    carlos_user = await db.users.find_one({"email": "carlos@demo.com"})
    ana_user = await db.users.find_one({"email": "ana@demo.com"})
    if not (joao_user and maria_user):
        return

    joao_seller = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": joao_user["id"]})
    maria_seller = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": maria_user["id"]})
    carlos_seller = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": carlos_user["id"]}) if carlos_user else None
    ana_seller = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": ana_user["id"]}) if ana_user else None

    if not (joao_seller and maria_seller):
        return

    # Loss reasons
    loss_reason = await db.loss_reasons.find_one({"tenant_id": tenant_id, "name": "Preço alto"})
    lr_id = loss_reason["id"] if loss_reason else None

    now_dt = datetime.now(timezone.utc)
    now = now_dt.isoformat()

    def _dt(days_ago=0, hours_ago=0):
        return (now_dt - timedelta(days=days_ago, hours=hours_ago)).isoformat()

    SOURCES = ["STORE_FLOOR", "WINDOW", "RETURNING_CUSTOMER", "STORE_FLOOR", "PHONE"]
    TYPES = ["ACTIVE_APPROACH", "CUSTOMER_REENGAGEMENT", "PRODUCT_INTEREST", "ACTIVE_APPROACH", "POST_VISIT_FOLLOWUP"]

    demo_approaches = [
        # João — CONVERTED_TO_SALE
        {
            "seller_id": joao_seller["id"],
            "customer_name": "Roberto Carvalho",
            "source": "STORE_FLOOR",
            "approach_type": "ACTIVE_APPROACH",
            "status": "CONVERTED_TO_SALE",
            "result": "SALE",
            "notes": "Abordou cliente na entrada, demonstrou tênis novo.",
            "started_at": _dt(days_ago=1, hours_ago=2),
            "converted_at": _dt(days_ago=1, hours_ago=1),
            "closed_at": _dt(days_ago=1, hours_ago=1),
        },
        # João — OPEN
        {
            "seller_id": joao_seller["id"],
            "customer_name": "Fernanda Santos",
            "source": "WINDOW",
            "approach_type": "PRODUCT_INTEREST",
            "status": "OPEN",
            "result": "PENDING",
            "notes": "Cliente olhando vitrine, abordei para mostrar promoções.",
            "started_at": _dt(hours_ago=1),
        },
        # João — NO_SALE
        {
            "seller_id": joao_seller["id"],
            "customer_name": "Pedro Alves",
            "source": "STORE_FLOOR",
            "approach_type": "ACTIVE_APPROACH",
            "status": "NO_SALE",
            "result": "NO_SALE",
            "loss_reason_id": lr_id,
            "notes": "Achou caro, não fechou.",
            "started_at": _dt(days_ago=2),
            "closed_at": _dt(days_ago=2),
        },
        # Maria — CONVERTED_TO_SALE
        {
            "seller_id": maria_seller["id"],
            "customer_name": "Lucia Ferreira",
            "source": "RETURNING_CUSTOMER",
            "approach_type": "CUSTOMER_REENGAGEMENT",
            "status": "CONVERTED_TO_SALE",
            "result": "SALE",
            "notes": "Cliente voltou indecisa, reabordei e fechou compra.",
            "started_at": _dt(days_ago=1, hours_ago=4),
            "converted_at": _dt(days_ago=1, hours_ago=3),
            "closed_at": _dt(days_ago=1, hours_ago=3),
        },
        # Maria — OPEN
        {
            "seller_id": maria_seller["id"],
            "customer_name": None,
            "source": "STORE_FLOOR",
            "approach_type": "ACTIVE_APPROACH",
            "status": "OPEN",
            "result": "PENDING",
            "notes": "Cliente circulando, aguardando retorno.",
            "started_at": _dt(hours_ago=0),
        },
        # Maria — CONVERTED_TO_ATTENDANCE
        {
            "seller_id": maria_seller["id"],
            "customer_name": "Bruno Lima",
            "source": "PHONE",
            "approach_type": "POST_VISIT_FOLLOWUP",
            "status": "CONVERTED_TO_ATTENDANCE",
            "result": "PENDING",
            "notes": "Cliente que visitou semana passada, retornou e estamos atendendo.",
            "started_at": _dt(days_ago=0, hours_ago=3),
            "converted_at": _dt(days_ago=0, hours_ago=2),
        },
    ]

    if carlos_seller:
        demo_approaches.append({
            "seller_id": carlos_seller["id"],
            "customer_name": "Marcos Pereira",
            "source": "WINDOW",
            "approach_type": "PRODUCT_INTEREST",
            "status": "NO_SALE",
            "result": "NO_SALE",
            "loss_reason_id": lr_id,
            "notes": "Só estava olhando, sem intenção de compra.",
            "started_at": _dt(days_ago=3),
            "closed_at": _dt(days_ago=3),
        })

    if ana_seller:
        demo_approaches.append({
            "seller_id": ana_seller["id"],
            "customer_name": "Carla Rodrigues",
            "source": "STORE_FLOOR",
            "approach_type": "ACTIVE_APPROACH",
            "status": "CONVERTED_TO_SALE",
            "result": "SALE",
            "notes": "Abordagem na seção de acessórios resultou em venda.",
            "started_at": _dt(days_ago=2, hours_ago=1),
            "converted_at": _dt(days_ago=2),
            "closed_at": _dt(days_ago=2),
        })

    admin_user = await db.users.find_one({"email": "admin@demo.com"})
    actor_id = admin_user["id"] if admin_user else "seed"

    for approach_data in demo_approaches:
        seller_id_v = approach_data["seller_id"]
        # Idempotency: check by seller_id + customer_name + started_at
        existing = await db.proactive_approaches.find_one({
            "tenant_id": tenant_id,
            "seller_id": seller_id_v,
            "customer_name": approach_data.get("customer_name"),
            "started_at": approach_data.get("started_at"),
        })
        if existing:
            continue

        sp = await db.seller_profiles.find_one({"id": seller_id_v})
        team_id_v = sp.get("team_id") if sp else None
        approach_id = new_id()

        doc = {
            "id": approach_id,
            "tenant_id": tenant_id,
            "store_id": store_id,
            "seller_id": seller_id_v,
            "team_id": team_id_v,
            "created_by": actor_id,
            "customer_name": approach_data.get("customer_name"),
            "customer_phone": None,
            "customer_note": None,
            "source": approach_data.get("source", "STORE_FLOOR"),
            "approach_type": approach_data.get("approach_type", "ACTIVE_APPROACH"),
            "status": approach_data.get("status", "OPEN"),
            "result": approach_data.get("result", "PENDING"),
            "loss_reason_id": approach_data.get("loss_reason_id"),
            "linked_attendance_id": None,
            "linked_sale_id": None,
            "notes": approach_data.get("notes"),
            "started_at": approach_data.get("started_at", now),
            "converted_at": approach_data.get("converted_at"),
            "closed_at": approach_data.get("closed_at"),
            "cancelled_at": None,
            "created_at": approach_data.get("started_at", now),
            "updated_at": now,
        }

        # If converted to sale, create a sale record
        if approach_data.get("status") == "CONVERTED_TO_SALE":
            sale_id = new_id()
            sale = {
                "id": sale_id,
                "tenant_id": tenant_id,
                "store_id": store_id,
                "seller_id": seller_id_v,
                "attendance_id": None,
                "proactive_approach_id": approach_id,
                "source": "PROACTIVE",
                "status": "COMPLETED",
                "gross_amount_cents": 19990,
                "discount_amount_cents": 0,
                "net_amount_cents": 19990,
                "payment_methods": [{"method": "CREDIT_CARD", "amount_cents": 19990}],
                "notes": approach_data.get("notes"),
                "created_at": approach_data.get("converted_at", now),
                "updated_at": now,
            }
            await db.sales.insert_one(sale)
            doc["linked_sale_id"] = sale_id

        await db.proactive_approaches.insert_one(doc)



async def seed_etapa12():
    """Idempotente — cria dados demo para Etapa 12 (Automações, Alertas, Motivação)."""
    from datetime import datetime, timezone, timedelta

    tenant = await db.tenants.find_one({"slug": "demo"})
    if not tenant:
        return
    tenant_id = tenant["id"]
    now_dt = datetime.now(timezone.utc)
    now = now_dt.isoformat()

    def _dt(days_ago=0, hours_ago=0):
        return (now_dt - timedelta(days=days_ago, hours=hours_ago)).isoformat()

    # ─── Ativar features de Etapa 12 ────────────────────────────────────────
    for key in [
        "automacoes", "alertas_inteligentes", "notificacoes_externas",
        "email_transacional", "push_notifications", "motivacao_publica",
        "templates_notificacao", "preferencias_notificacao",
    ]:
        await set_tenant_feature(tenant_id=tenant_id, feature_key=key, enabled=True, updated_by="seed")

    store = await db.stores.find_one({"tenant_id": tenant_id, "code": "CENTRO"})
    store_id = store["id"] if store else None
    admin_user = await db.users.find_one({"email": "admin@demo.com"})
    actor_id = admin_user["id"] if admin_user else "seed"

    joao_user = await db.users.find_one({"email": "joao@demo.com"})
    maria_user = await db.users.find_one({"email": "maria@demo.com"})

    joao_seller = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": joao_user["id"]}) if joao_user else None
    maria_seller = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": maria_user["id"]}) if maria_user else None

    # ─── Notification Templates ───────────────────────────────────────────────
    templates = [
        {
            "key": "goal_achieved_daily", "name": "Meta Diária Batida",
            "channel": "IN_APP", "event_type": "GOAL_DAILY_ACHIEVED",
            "title_template": "Meta diária batida!",
            "body_template": "{{seller_name}} bateu a meta diária de vendas da unidade {{store_name}}!",
            "severity": "INFO", "is_public": True, "is_active": True,
        },
        {
            "key": "badge_earned", "name": "Nova Conquista",
            "channel": "IN_APP", "event_type": "BADGE_EARNED",
            "title_template": "Nova conquista desbloqueada!",
            "body_template": "{{seller_name}} desbloqueou a conquista {{badge_name}}.",
            "severity": "INFO", "is_public": True, "is_active": True,
        },
        {
            "key": "ranking_top_1", "name": "Líder do Ranking",
            "channel": "IN_APP", "event_type": "RANKING_TOP_1",
            "title_template": "Novo líder no ranking!",
            "body_template": "{{seller_name}} assumiu a posição 1 no ranking!",
            "severity": "INFO", "is_public": True, "is_active": True,
        },
        {
            "key": "low_conversion_alert", "name": "Alerta de Baixa Conversão",
            "channel": "IN_APP", "event_type": "ALERT_TRIGGERED",
            "title_template": "Atenção: baixa conversão",
            "body_template": "A taxa de conversão da unidade {{store_name}} está abaixo do esperado.",
            "severity": "WARNING", "is_public": False, "is_active": True,
        },
    ]
    for tmpl in templates:
        existing = await db.notification_templates.find_one(
            {"tenant_id": tenant_id, "key": tmpl["key"]}
        )
        if not existing:
            doc = {
                "id": new_id(), "tenant_id": tenant_id,
                **tmpl,
                "description": None,
                "created_by": actor_id,
                "created_at": now, "updated_at": now,
            }
            await db.notification_templates.insert_one(doc)

    # ─── Automation Rules ─────────────────────────────────────────────────────
    auto_rules = [
        {
            "name": "Notificar meta batida",
            "description": "Quando vendedor bate meta diária, enviar notificação interna e evento motivacional.",
            "trigger_type": "GOAL_ACHIEVED",
            "conditions": [],
            "actions": [
                {"type": "CREATE_NOTIFICATION", "title": "Meta batida!", "message": "Você bateu sua meta! Parabéns!"},
                {"type": "CREATE_MOTIVATION_EVENT", "event_type": "GOAL_DAILY_ACHIEVED"},
            ],
            "is_active": True,
        },
        {
            "name": "Alerta de atendimento parado",
            "description": "Se atendimento ficar parado por mais de 30 min, criar alerta.",
            "trigger_type": "ATTENDANCE_STALLED",
            "conditions": [{"field": "duration_minutes", "operator": "gte", "value": 30}],
            "actions": [{"type": "CREATE_ALERT", "title": "Atendimento parado", "message": "Atendimento em andamento há mais de 30 minutos.", "severity": "WARNING"}],
            "is_active": True,
        },
        {
            "name": "Destaque de venda proativa",
            "description": "Quando vendedor fecha venda via abordagem proativa, criar evento motivacional.",
            "trigger_type": "PROACTIVE_SALE_CREATED",
            "conditions": [],
            "actions": [
                {"type": "CREATE_MOTIVATION_EVENT", "event_type": "PROACTIVE_SALE_CREATED"},
            ],
            "is_active": True,
        },
    ]
    for rule_data in auto_rules:
        existing = await db.automation_rules.find_one(
            {"tenant_id": tenant_id, "name": rule_data["name"]}
        )
        if not existing:
            doc = {
                "id": new_id(), "tenant_id": tenant_id,
                **rule_data,
                "created_by": actor_id,
                "last_run_at": None,
                "created_at": now, "updated_at": now,
            }
            await db.automation_rules.insert_one(doc)

    # ─── Alert Events demo ────────────────────────────────────────────────────
    alert_demos = [
        {
            "alert_type": "LOW_CONVERSION",
            "title": "Baixa conversão hoje",
            "message": "Taxa de conversão está em 15% na unidade Centro.",
            "severity": "WARNING",
            "status": "OPEN",
            "store_id": store_id,
        },
        {
            "alert_type": "GOAL_AT_RISK",
            "title": "Meta semanal em risco",
            "message": "Apenas 40% da meta semanal foi atingida com 80% do período.",
            "severity": "CRITICAL",
            "status": "ACKNOWLEDGED",
            "store_id": store_id,
            "acknowledged_by": actor_id,
            "acknowledged_at": _dt(hours_ago=2),
        },
        {
            "alert_type": "SELLER_INACTIVE",
            "title": "Vendedor inativo",
            "message": "João Silva está inativo há 2 horas.",
            "severity": "INFO",
            "status": "RESOLVED",
            "store_id": store_id,
            "seller_id": joao_seller["id"] if joao_seller else None,
            "resolved_by": actor_id,
            "resolved_at": _dt(hours_ago=1),
        },
    ]
    for alert_data in alert_demos:
        existing = await db.alert_events.find_one(
            {"tenant_id": tenant_id, "alert_type": alert_data["alert_type"], "status": alert_data["status"]}
        )
        if not existing:
            doc = {
                "id": new_id(), "tenant_id": tenant_id,
                "team_id": None,
                "alert_rule_id": None,
                "acknowledged_by": alert_data.get("acknowledged_by"),
                "acknowledged_at": alert_data.get("acknowledged_at"),
                "resolved_by": alert_data.get("resolved_by"),
                "resolved_at": alert_data.get("resolved_at"),
                "seller_id": alert_data.get("seller_id"),
                "metadata": {},
                **{k: v for k, v in alert_data.items() if k not in ("acknowledged_by", "acknowledged_at", "resolved_by", "resolved_at", "seller_id")},
                "created_at": _dt(hours_ago=4),
                "updated_at": now,
            }
            await db.alert_events.insert_one(doc)

    # ─── Motivation Events demo ────────────────────────────────────────────────
    from public_motivation_event_service import TEMPLATES as MOT_TEMPLATES
    motivation_demos = [
        {
            "event_type": "GOAL_DAILY_ACHIEVED",
            "seller_id": joao_seller["id"] if joao_seller else None,
            "seller_name": "João Silva",
            "created_ago": _dt(hours_ago=3),
        },
        {
            "event_type": "RANKING_TOP_1",
            "seller_id": maria_seller["id"] if maria_seller else None,
            "seller_name": "Maria Santos",
            "created_ago": _dt(hours_ago=5),
        },
        {
            "event_type": "BADGE_EARNED",
            "seller_id": joao_seller["id"] if joao_seller else None,
            "seller_name": "João Silva",
            "badge_name": "Primeira Venda Proativa",
            "created_ago": _dt(days_ago=1),
        },
        {
            "event_type": "PROACTIVE_SALE_CREATED",
            "seller_id": maria_seller["id"] if maria_seller else None,
            "seller_name": "Maria Santos",
            "created_ago": _dt(days_ago=1, hours_ago=2),
        },
    ]

    import hashlib
    for mot in motivation_demos:
        sid = mot["seller_id"] or ""
        dedup_key = hashlib.md5(f"{tenant_id}:{mot['event_type']}:{sid}:seed".encode()).hexdigest()
        existing = await db.motivation_events.find_one({"dedup_key": dedup_key})
        if existing:
            continue

        tmpl = MOT_TEMPLATES.get(mot["event_type"], {"title": "Destaque!", "msg": "{seller_name} se destacou!"})
        ctx = {"seller_name": mot["seller_name"], "badge_name": mot.get("badge_name", ""), "positions": 1, "team_name": ""}
        title = tmpl["title"]
        message = tmpl["msg"].format(**ctx)

        doc = {
            "id": new_id(), "tenant_id": tenant_id,
            "store_id": store_id,
            "team_id": None,
            "seller_id": mot["seller_id"],
            "event_type": mot["event_type"],
            "title": title,
            "message": message,
            "visibility_scope": "TENANT",
            "ranking_id": None, "goal_id": None, "badge_id": None,
            "sale_id": None, "proactive_approach_id": None,
            "metadata": {},
            "dedup_key": dedup_key,
            "created_at": mot["created_ago"],
            "expires_at": None,
            "created_by_system": True,
        }
        await db.motivation_events.insert_one(doc)




async def seed_etapa14():
    """Seed idempotente — Etapa 14: LGPD, Privacidade, Retenção, Backup.
    Respeita SEED_DEMO_DATA: se false, cria apenas políticas padrão (sem dados demo).
    """
    tenant = await db.tenants.find_one({"slug": "demo"})
    if not tenant:
        return
    tenant_id = tenant["id"]

    # Ativar features Etapa 14
    for feature_key in ("lgpd", "retencao_dados", "backup_restore", "anonimizacao_dados"):
        await set_tenant_feature(tenant_id=tenant_id, feature_key=feature_key, enabled=True, updated_by="seed")

    # ── Privacy Settings ───────────────────────────────────────────────────────
    import privacy_settings_service as ps_svc
    await ps_svc.seed_default(tenant_id, created_by="seed")

    # ── Políticas de Retenção padrão ──────────────────────────────────────────
    import retention_policy_service as rp_svc
    await rp_svc.seed_default_policies(tenant_id, created_by="seed")

    # ── Mapa de Dados (Data Processing Records) ───────────────────────────────
    data_map_records = [
        {"data_category": "USER_ACCOUNT", "purpose": "Autenticação e gerenciamento de acesso.", "legal_basis": "CONTRACT", "data_subject_type": "USER", "systems": ["auth_service", "tenant_membership"], "contains_sensitive_data": False, "sharing_description": "Não compartilhado externamente."},
        {"data_category": "SELLER_PROFILE", "purpose": "Gerenciamento de vendedores e fila.", "legal_basis": "CONTRACT", "data_subject_type": "SELLER", "systems": ["queue_engine", "sales_service"], "contains_sensitive_data": False, "sharing_description": "Não compartilhado externamente."},
        {"data_category": "CUSTOMER_VISIT", "purpose": "Rastreamento de visitas para fins operacionais.", "legal_basis": "LEGITIMATE_INTEREST", "data_subject_type": "CUSTOMER", "systems": ["queue_engine"], "contains_sensitive_data": True, "sharing_description": "Não compartilhado externamente."},
        {"data_category": "ATTENDANCE", "purpose": "Registro de atendimentos comerciais.", "legal_basis": "CONTRACT", "data_subject_type": "CUSTOMER", "systems": ["attendance_service"], "contains_sensitive_data": True, "sharing_description": "Não compartilhado externamente."},
        {"data_category": "SALE", "purpose": "Registro de vendas para relatórios e metas.", "legal_basis": "CONTRACT", "data_subject_type": "CUSTOMER", "systems": ["sales_service", "report_service"], "contains_sensitive_data": False, "sharing_description": "Não compartilhado externamente."},
        {"data_category": "AUDIT_LOG", "purpose": "Rastreabilidade de ações no sistema.", "legal_basis": "LEGAL_OBLIGATION", "data_subject_type": "USER", "systems": ["audit_service"], "contains_sensitive_data": False, "sharing_description": "Apenas reguladores quando aplicável."},
    ]
    now = utcnow_iso()
    for rec in data_map_records:
        existing = await db.data_processing_records.find_one(
            {"tenant_id": tenant_id, "data_category": rec["data_category"]}
        )
        if not existing:
            await db.data_processing_records.insert_one({
                "id": new_id(), "tenant_id": tenant_id,
                **rec, "retention_policy_id": None,
                "created_at": now, "updated_at": now,
            })

    # Buscar usuário admin para seed de requests
    admin_user = await db.users.find_one({"email": "admin@demo.com"})
    admin_id = admin_user["id"] if admin_user else "system"

    # ── Consentimentos Demo ────────────────────────────────────────────────────
    consent_demos = [
        {"subject_type": "USER", "subject_user_id": admin_id, "purpose": "ACCOUNT_ACCESS", "legal_basis": "CONTRACT", "version": "1.0", "source": "SYSTEM", "status": "GRANTED"},
        {"subject_type": "USER", "subject_user_id": admin_id, "purpose": "NOTIFICATIONS", "legal_basis": "CONSENT", "version": "1.0", "source": "SYSTEM", "status": "GRANTED"},
    ]
    for c in consent_demos:
        existing = await db.consents.find_one(
            {"tenant_id": tenant_id, "subject_user_id": c["subject_user_id"], "purpose": c["purpose"]}
        )
        if not existing:
            await db.consents.insert_one({
                "id": new_id(), "tenant_id": tenant_id, **c,
                "collected_at": now, "withdrawn_at": None,
                "expires_at": None, "created_at": now, "updated_at": now,
            })

    # ── Solicitações LGPD Demo ────────────────────────────────────────────────
    seller_user = await db.users.find_one({"email": "joao@demo.com"})
    seller_id = seller_user["id"] if seller_user else admin_id

    request_demos = [
        {"request_type": "ACCESS", "status": "OPEN", "priority": "HIGH", "description": "Solicitação de acesso a todos os dados pessoais armazenados.", "requester_user_id": seller_id, "requester_type": "SELF", "data_subject_type": "USER", "data_subject_user_id": seller_id, "data_subject_name": "João Silva", "data_subject_email": "joao@demo.com"},
        {"request_type": "CORRECTION", "status": "IN_REVIEW", "priority": "NORMAL", "description": "Correção de dados cadastrais desatualizados.", "requester_user_id": admin_id, "requester_type": "TENANT_ADMIN", "data_subject_type": "USER", "data_subject_user_id": admin_id, "data_subject_name": "Admin Demo", "data_subject_email": "admin@demo.com"},
        {"request_type": "PORTABILITY", "status": "RESOLVED", "priority": "NORMAL", "description": "Exportação de dados no formato portátil.", "requester_user_id": admin_id, "requester_type": "TENANT_ADMIN", "data_subject_type": "USER", "data_subject_user_id": admin_id, "data_subject_name": "Admin Demo", "data_subject_email": "admin@demo.com", "resolution_notes": "Exportação concluída e enviada ao solicitante."},
    ]
    for req in request_demos:
        existing = await db.privacy_requests.find_one(
            {"tenant_id": tenant_id, "request_type": req["request_type"],
             "data_subject_user_id": req.get("data_subject_user_id"), "status": req["status"]}
        )
        if not existing:
            await db.privacy_requests.insert_one({
                "id": new_id(), "tenant_id": tenant_id,
                "created_by": req["requester_user_id"],
                "assigned_to": None, "rejected_reason": None,
                "resolved_at": now if req["status"] == "RESOLVED" else None,
                "due_at": None, "created_at": now, "updated_at": now,
                **{k: v for k, v in req.items()},
            })

    # ── Legal Hold Demo ───────────────────────────────────────────────────────
    existing_hold = await db.legal_holds.find_one({"tenant_id": tenant_id, "status": "ACTIVE"})
    if not existing_hold:
        await db.legal_holds.insert_one({
            "id": new_id(), "tenant_id": tenant_id,
            "name": "Legal Hold Demo — Investigação Interna",
            "description": "Hold aplicado para fins de demonstração do sistema.",
            "entity_type": "USER", "entity_id": admin_id,
            "data_category": "AUDIT_LOGS", "status": "ACTIVE",
            "created_by": "seed", "released_by": None,
            "created_at": now, "released_at": None,
            "reason": "Demonstração de legal hold ativo.",
        })

    # ── Backup Snapshot Demo (leve) ────────────────────────────────────────────
    import json, hashlib
    existing_backup = await db.backup_snapshots.find_one({"tenant_id": tenant_id, "status": "COMPLETED"})
    if not existing_backup:
        demo_content = json.dumps({
            "tenant_id": tenant_id, "backup_type": "TENANT_CONFIG",
            "created_at": now, "note": "Backup de demonstração — Etapa 14.",
            "collections": {"privacy_settings": [], "data_retention_policies": []},
        })
        checksum = hashlib.sha256(demo_content.encode()).hexdigest()
        snap_id = new_id()
        await db.backup_snapshots.insert_one({
            "id": snap_id, "tenant_id": tenant_id,
            "backup_type": "TENANT_CONFIG", "status": "COMPLETED",
            "scope": "TENANT", "storage_provider": "mongodb_internal",
            "file_path": f"backups/{tenant_id}/{snap_id}.json",
            "checksum": checksum, "size_bytes": len(demo_content.encode()),
            "created_by": "seed", "created_at": now, "expires_at": None,
            "completed_at": now, "error_code": None, "error_message": None,
            "metadata": {"note": "Backup demo Etapa 14"},
            "_content": demo_content,
        })
        await db.backup_jobs.insert_one({
            "id": new_id(), "tenant_id": tenant_id,
            "backup_type": "TENANT_CONFIG", "status": "COMPLETED",
            "started_at": now, "finished_at": now, "created_by": "seed",
            "records_included": 0, "collections_included": ["privacy_settings"],
            "error_code": None, "error_message": None, "snapshot_id": snap_id,
            "created_at": now,
        })
