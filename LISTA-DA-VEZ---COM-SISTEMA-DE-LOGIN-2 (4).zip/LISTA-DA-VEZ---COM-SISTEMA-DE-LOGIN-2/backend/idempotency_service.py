"""Serviço de idempotência para operações críticas — Etapa 13."""
import hashlib
import json
import logging
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, Optional

from fastapi import HTTPException

from db import db
from models import new_id, utcnow_iso

logger = logging.getLogger("lista-da-vez.idempotency")

IDEMPOTENCY_TTL_HOURS = 24


def _hash_payload(payload: Any) -> str:
    if payload is None:
        return ""
    try:
        serialized = json.dumps(payload, sort_keys=True, default=str)
        return hashlib.sha256(serialized.encode()).hexdigest()
    except Exception:
        return ""


async def check_idempotency(
    *,
    idempotency_key: Optional[str],
    tenant_id: str,
    user_id: str,
    endpoint: str,
    method: str,
    payload: Any = None,
) -> Optional[Dict[str, Any]]:
    """
    Retorna resposta existente se a chave já foi processada.
    Retorna None se a chave é nova.
    Lança HTTPException 409 se a chave existe com payload diferente.
    """
    if not idempotency_key:
        return None

    scoped_key = f"{tenant_id}:{user_id}:{endpoint}:{method}:{idempotency_key}"
    payload_hash = _hash_payload(payload)

    existing = await db.idempotency_keys.find_one({"scoped_key": scoped_key})

    if existing:
        existing.pop("_id", None)
        if existing.get("payload_hash") and existing["payload_hash"] != payload_hash:
            raise HTTPException(
                status_code=409,
                detail={
                    "error": "IDEMPOTENCY_KEY_CONFLICT",
                    "message": "Esta chave de idempotência já foi usada com outro conteúdo.",
                },
            )
        if existing.get("status") == "completed" and existing.get("response"):
            return existing["response"]
        if existing.get("status") == "in_progress":
            raise HTTPException(
                status_code=409,
                detail={
                    "error": "IDEMPOTENCY_IN_PROGRESS",
                    "message": "Esta operação já está em andamento.",
                },
            )
    return None


async def register_idempotency(
    *,
    idempotency_key: Optional[str],
    tenant_id: str,
    user_id: str,
    endpoint: str,
    method: str,
    payload: Any = None,
) -> Optional[str]:
    """Cria registro de idempotência em_andamento. Retorna o record_id ou None."""
    if not idempotency_key:
        return None

    scoped_key = f"{tenant_id}:{user_id}:{endpoint}:{method}:{idempotency_key}"
    payload_hash = _hash_payload(payload)
    expires_at = (
        datetime.now(timezone.utc) + timedelta(hours=IDEMPOTENCY_TTL_HOURS)
    ).isoformat()

    record_id = new_id()
    try:
        await db.idempotency_keys.insert_one(
            {
                "id": record_id,
                "scoped_key": scoped_key,
                "key": idempotency_key,
                "idempotency_key": idempotency_key,
                "tenant_id": tenant_id,
                "user_id": user_id,
                "endpoint": endpoint,
                "method": method,
                "payload_hash": payload_hash,
                "status": "in_progress",
                "response": None,
                "created_at": utcnow_iso(),
                "expires_at": expires_at,
            }
        )
    except Exception as exc:
        logger.error("Falha ao registrar idempotency_key: %s", exc)
        return None
    return record_id


async def complete_idempotency(record_id: Optional[str], response: Dict[str, Any]):
    """Marca o registro de idempotência como concluído com a resposta completa serializável."""
    if not record_id:
        return
    response_summary = response if isinstance(response, dict) else {}
    try:
        await db.idempotency_keys.update_one(
            {"id": record_id},
            {
                "$set": {
                    "status": "completed",
                    "response": response_summary,
                    "completed_at": utcnow_iso(),
                }
            },
        )
    except Exception as exc:
        logger.error("Falha ao completar idempotency_key: %s", exc)
