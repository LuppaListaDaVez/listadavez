"""Outbox Pattern para eventos realtime — P1.

Garante confiabilidade de entrega de eventos mesmo se a aplicação
cair entre a operação de negócio e a publicação WebSocket.

Fluxo:
1. Após operação de negócio, escrever evento na outbox (PENDING)
2. Dispatcher background processa PENDING → publica WebSocket
3. Marca PUBLISHED após sucesso
4. Retentar FAILED (até max_attempts)
5. Mover para DEAD_LETTER após esgotamento

CAMPOS da coleção event_outbox:
  id, tenant_id, event_type, aggregate_type, aggregate_id,
  store_id, payload, status, attempt_count, last_error,
  created_at, published_at
"""
import asyncio
import logging
from datetime import datetime, timezone, timedelta
from typing import Optional

from db import db
from models import new_id

logger = logging.getLogger("lista-da-vez.outbox")

MAX_ATTEMPTS = 5
RETRY_BACKOFF_SECONDS = [5, 15, 30, 60, 120]
DISPATCH_INTERVAL_SECONDS = 2
DEAD_LETTER_AFTER_HOURS = 24


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


async def enqueue_event(
    *,
    tenant_id: str,
    event_type: str,
    aggregate_type: str,
    aggregate_id: str,
    store_id: Optional[str] = None,
    payload: Optional[dict] = None,
):
    """Grava evento na outbox. Chamar após operação de negócio ser persistida."""
    # Sanitizar payload — nunca salvar dados sensíveis
    safe_payload = {k: v for k, v in (payload or {}).items()
                    if k not in {"password_hash", "token", "access_token", "refresh_token"}}
    await db.event_outbox.insert_one({
        "id": new_id(),
        "tenant_id": tenant_id,
        "event_type": event_type,
        "aggregate_type": aggregate_type,
        "aggregate_id": aggregate_id,
        "store_id": store_id,
        "payload": safe_payload,
        "status": "PENDING",
        "attempt_count": 0,
        "last_error": None,
        "created_at": _now_iso(),
        "published_at": None,
    })


async def _dispatch_one(event: dict):
    """Tenta publicar um evento da outbox via realtime."""
    from realtime import event_bus

    try:
        tenant_id = event.get("tenant_id")
        store_id = event.get("store_id")
        event_type = event.get("event_type")
        payload = event.get("payload") or {}

        if store_id:
            await event_bus.publish_event(
                tenant_id=tenant_id, store_id=store_id,
                queue_id=payload.get("queue_id"),
                event_type=event_type, payload=payload,
            )
        else:
            await event_bus.publish_tenant_event(
                tenant_id=tenant_id, event_type=event_type, payload=payload,
            )

        await db.event_outbox.update_one(
            {"id": event["id"]},
            {"$set": {"status": "PUBLISHED", "published_at": _now_iso()}},
        )
        logger.debug("OUTBOX_PUBLISHED id=%s type=%s", event["id"][:8], event_type)

    except Exception as exc:
        attempt = event.get("attempt_count", 0) + 1
        status = "DEAD_LETTER" if attempt >= MAX_ATTEMPTS else "FAILED"
        await db.event_outbox.update_one(
            {"id": event["id"]},
            {"$set": {
                "status": status,
                "attempt_count": attempt,
                "last_error": str(exc)[:500],
            }},
        )
        logger.warning("OUTBOX_FAILED id=%s attempt=%d status=%s err=%s",
                       event["id"][:8], attempt, status, exc)


async def dispatch_pending():
    """Processa eventos PENDING + FAILED prontos para retry."""
    now = datetime.now(timezone.utc)
    retry_before = (now - timedelta(seconds=RETRY_BACKOFF_SECONDS[-1])).isoformat()

    cursor = db.event_outbox.find({
        "$or": [
            {"status": "PENDING"},
            {"status": "FAILED", "updated_at": {"$lt": retry_before}},
        ]
    }).sort("created_at", 1).limit(50)

    events = await cursor.to_list(50)
    if not events:
        return

    for event in events:
        await db.event_outbox.update_one(
            {"id": event["id"]},
            {"$set": {"updated_at": _now_iso()}},
        )
        await _dispatch_one(event)


async def cleanup_dead_letter():
    """Remove dead letters antigos."""
    threshold = (datetime.now(timezone.utc) - timedelta(hours=DEAD_LETTER_AFTER_HOURS)).isoformat()
    result = await db.event_outbox.delete_many({
        "status": {"$in": ["DEAD_LETTER", "PUBLISHED"]},
        "created_at": {"$lt": threshold},
    })
    if result.deleted_count:
        logger.info("OUTBOX_CLEANUP deleted=%d", result.deleted_count)


async def run_dispatcher():
    """Background task: despacha outbox continuamente."""
    logger.info("OUTBOX_DISPATCHER_STARTED interval=%ds", DISPATCH_INTERVAL_SECONDS)
    cleanup_counter = 0
    while True:
        try:
            await dispatch_pending()
            cleanup_counter += 1
            if cleanup_counter >= 1800:  # ~1h
                await cleanup_dead_letter()
                cleanup_counter = 0
        except Exception as exc:
            logger.error("OUTBOX_DISPATCHER_ERROR: %s", exc, exc_info=False)
        await asyncio.sleep(DISPATCH_INTERVAL_SECONDS)
