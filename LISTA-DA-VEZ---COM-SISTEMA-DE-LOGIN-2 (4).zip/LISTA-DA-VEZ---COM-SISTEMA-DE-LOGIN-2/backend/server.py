"""FastAPI entry point para Lista da Vez SaaS — P0."""
from dotenv import load_dotenv
from pathlib import Path

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

import logging
import os

from fastapi import APIRouter, Depends, FastAPI, Request
from security import require_super_admin
import asyncio
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from db import init_indexes
from middleware import RequestContextMiddleware
from routes_auth import router as auth_router
from routes_google_auth import router as google_auth_router
from routes_super_admin import router as super_admin_router
from routes_tenant import router as tenant_router
from routes_tenant_auth import router as tenant_auth_router
from routes_admin_security import router as admin_security_router
from routes_health import router as health_router
from routes_health import metrics_router
from routes_teams import router as teams_router
from routes_sellers import router as sellers_router
from routes_loss_reasons import router as loss_reasons_router
from routes_motivos_perda import router as motivos_perda_router
from routes_store_settings import router as store_settings_router
from routes_queue import router as queue_router
from routes_attendances import router as attendances_router
from routes_products import router as products_router
from routes_sales import router as sales_router
from routes_ws import router as ws_router
from routes_dashboard import router as dashboard_router
from routes_reports import router as reports_router
from routes_export import router as export_router
from routes_export_jobs import router as export_jobs_router
from routes_goals import router as goals_router
from routes_rankings import router as rankings_router
from routes_gamification import router as gamification_router
from routes_achievements import (
    router as achievements_router,
    awards_router as achievement_awards_router,
    rankings_router as achievement_rankings_router,
    requests_router as achievement_requests_router,
)
from routes_feedbacks import router as feedbacks_router
from routes_notifications import router as notifications_router
from routes_proactive_approaches import router as proactive_approaches_router
from routes_automation import router as automation_router
from routes_alerts import router as alerts_router
from routes_motivation_events import router as motivation_router
from routes_notification_preferences import router as notif_prefs_router
from routes_invites import router as invites_router
from seed import run_seed

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("lista-da-vez")


def _validate_required_env():
    """Valida variáveis de ambiente no boot. Fail-fast para ausências críticas."""
    env = os.environ.get("ENVIRONMENT", "development")

    # ── Sempre obrigatórias ───────────────────────────────────────────────────
    always_required = ["JWT_SECRET", "DATABASE_URL"]
    missing = [k for k in always_required if not os.environ.get(k)]
    if missing:
        raise RuntimeError(
            f"Variáveis obrigatórias ausentes: {', '.join(missing)}. "
            "Configure-as antes de iniciar a aplicação."
        )

    # ── Validação de segurança: JWT_SECRET ───────────────────────────────────
    jwt_secret = os.environ.get("JWT_SECRET", "")
    if len(jwt_secret) < 32:
        msg = f"JWT_SECRET muito curto ({len(jwt_secret)} chars, mínimo 32). Use: openssl rand -hex 32"
        if env == "production":
            raise RuntimeError(f"SECURITY_ERROR: {msg}")
        logger.warning("SECURITY_WARNING: %s", msg)

    # ── Validações específicas de produção ───────────────────────────────────
    if env == "production":
        cors = os.environ.get("CORS_ORIGINS", "*")
        if "*" in [o.strip() for o in cors.split(",")]:
            raise RuntimeError(
                "SECURITY_ERROR: CORS_ORIGINS='*' não é permitido em ENVIRONMENT=production. "
                "Defina a lista explícita de origens permitidas."
            )
        seed_demo = os.environ.get("SEED_DEMO_DATA", "false").lower()
        if seed_demo in ("true", "1", "yes"):
            logger.warning(
                "SECURITY_WARNING: SEED_DEMO_DATA=true em ENVIRONMENT=production. "
                "Credenciais demo estarão ativas. Desative antes do deploy real."
            )

    # ── Warnings para serviços opcionais ausentes ────────────────────────────
    if not os.environ.get("REDIS_URL"):
        logger.warning(
            "OPERATIONAL_INFO: REDIS_URL não configurado — outbox, export jobs e "
            "realtime usarão adapter in-memory (não escala em múltiplas instâncias)."
        )
    if not os.environ.get("FRONTEND_URL"):
        logger.warning(
            "OPERATIONAL_INFO: FRONTEND_URL não configurado — links de convite usarão "
            "fallback 'http://localhost:3000'. Configure para produção."
        )
    # ── Warnings de configuração de e-mail (qualquer ambiente) ──────────────
    _email_provider = os.environ.get("EMAIL_PROVIDER", "log").lower()
    if _email_provider == "smtp":
        # Checar novos nomes e aliases
        _smtp_host = os.environ.get("SMTP_HOST", "")
        _smtp_user = os.environ.get("SMTP_USER", "")
        _smtp_pass = os.environ.get("SMTP_PASSWORD") or os.environ.get("SMTP_PASS") or ""
        _smtp_missing = (
            (["SMTP_HOST"] if not _smtp_host else []) +
            (["SMTP_USER"] if not _smtp_user else []) +
            (["SMTP_PASSWORD (ou SMTP_PASS)"] if not _smtp_pass else [])
        )
        if _smtp_missing:
            logger.warning(
                "OPERATIONAL_WARNING: EMAIL_PROVIDER=smtp mas variáveis ausentes: %s "
                "— e-mails de convite serão LOGGED até a configuração ser corrigida.",
                ", ".join(_smtp_missing),
            )
    elif _email_provider == "ses":
        _ses_missing = [k for k in ("AWS_REGION", "SES_FROM_EMAIL") if not os.environ.get(k)]
        if _ses_missing:
            logger.warning(
                "OPERATIONAL_WARNING: EMAIL_PROVIDER=ses mas variáveis ausentes: %s "
                "— e-mails de convite serão LOGGED até a configuração ser corrigida.",
                ", ".join(_ses_missing),
            )
    elif _email_provider not in ("log",):
        logger.warning(
            "OPERATIONAL_WARNING: EMAIL_PROVIDER='%s' desconhecido. "
            "Valores válidos: smtp | ses | log. Usando fallback log.",
            _email_provider,
        )
    if env == "production" and not os.environ.get("BACKUP_ENCRYPTION_KEY"):
        logger.warning("OPERATIONAL_INFO: BACKUP_ENCRYPTION_KEY não configurado — backups não serão criptografados.")


_validate_required_env()

app = FastAPI(
    title="Lista da Vez SaaS API",
    version="1.0.0-p2",
    # Desabilitar docs em produção para reduzir superfície de ataque
    docs_url="/docs" if os.environ.get("ENVIRONMENT", "development") != "production" else None,
    redoc_url="/redoc" if os.environ.get("ENVIRONMENT", "development") != "production" else None,
)


# ── Global Exception Handler ─────────────────────────────────────────────────
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Captura exceções não tratadas. Loga stack trace internamente, retorna resposta genérica ao cliente."""
    request_id = getattr(request.state, "request_id", "unknown")
    logger.error(
        "UNHANDLED_EXCEPTION req=%s path=%s type=%s",
        request_id,
        request.url.path,
        type(exc).__name__,
        exc_info=True,
    )
    return JSONResponse(
        status_code=500,
        content={
            "error": "INTERNAL_SERVER_ERROR",
            "message": "Ocorreu um erro interno. Por favor, tente novamente.",
            "request_id": request_id,
        },
    )


# ── Middleware ────────────────────────────────────────────────────────────────
app.add_middleware(RequestContextMiddleware)

_cors_origins_raw = os.environ.get("CORS_ORIGINS")
if not _cors_origins_raw:
    raise RuntimeError("Variável obrigatória ausente: CORS_ORIGINS")
_cors_origins = [origin.strip() for origin in _cors_origins_raw.split(",") if origin.strip()]

# Avisar se usando wildcard (inseguro em produção)
if "*" in _cors_origins and os.environ.get("ENVIRONMENT", "development") == "production":
    logger.warning(
        "SECURITY_WARNING: CORS_ORIGINS='*' em ambiente de produção. "
        "Defina CORS_ORIGINS com a lista explícita de origens permitidas."
    )

app.add_middleware(
    CORSMiddleware,
    allow_origins=_cors_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type", "Idempotency-Key", "X-Request-Id", "Accept"],
    expose_headers=["X-Request-Id", "Retry-After", "X-Total-Count"],
)

# ── API Router ────────────────────────────────────────────────────────────────
api_router = APIRouter(prefix="/api")
api_router.include_router(health_router)
api_router.include_router(metrics_router)
api_router.include_router(auth_router)
api_router.include_router(google_auth_router)
api_router.include_router(tenant_auth_router)
api_router.include_router(admin_security_router)
api_router.include_router(super_admin_router)
api_router.include_router(tenant_router)
api_router.include_router(teams_router)
api_router.include_router(sellers_router)
api_router.include_router(loss_reasons_router)
api_router.include_router(motivos_perda_router)
api_router.include_router(store_settings_router)
api_router.include_router(queue_router)
api_router.include_router(attendances_router)
api_router.include_router(products_router)
api_router.include_router(sales_router)
api_router.include_router(ws_router)
api_router.include_router(dashboard_router)
api_router.include_router(reports_router)
api_router.include_router(export_router)
api_router.include_router(export_jobs_router)
api_router.include_router(goals_router)
api_router.include_router(rankings_router)
api_router.include_router(gamification_router)
api_router.include_router(achievements_router)
api_router.include_router(achievement_awards_router)
api_router.include_router(achievement_rankings_router)
api_router.include_router(achievement_requests_router)
api_router.include_router(feedbacks_router)
api_router.include_router(notifications_router)
api_router.include_router(proactive_approaches_router)
api_router.include_router(automation_router)
api_router.include_router(alerts_router)
api_router.include_router(motivation_router)
api_router.include_router(notif_prefs_router)
# Etapa 14 — LGPD, Retenção, Backup/Restore
from routes_privacy import router as privacy_router
from routes_retention import router as retention_router
from routes_backup import router as backup_router
from routes_admin_privacy import router as admin_privacy_router
api_router.include_router(privacy_router)
api_router.include_router(retention_router)
api_router.include_router(backup_router)
api_router.include_router(admin_privacy_router)

# ── P2: API v1 + DomainError handler ─────────────────────────────────────────
from interfaces.v1 import v1_router, domain_error_handler
from domain.base import DomainError
api_router.include_router(v1_router)
app.add_exception_handler(DomainError, domain_error_handler)
api_router.include_router(invites_router)  # Prompt 2: convites públicos

app.include_router(api_router)


@app.on_event("startup")
async def on_startup():
    logger.info("Initializing MongoDB indexes...")
    await init_indexes()
    logger.info("Running seed...")
    await run_seed()
    logger.info("Running seed_etapa14...")
    from seed import seed_etapa14
    await seed_etapa14()
    logger.info("Running P0.5 migrations (backfill)...")
    await _run_p0_5_migrations()
    # P1: iniciar tasks background
    asyncio.create_task(_start_background_tasks())
    logger.info("Boot complete — P2 (Clean Architecture, Repositories, Use Cases, API v1, Prometheus).")


@app.on_event("shutdown")
async def on_shutdown():
    """Graceful shutdown — drena conexões WebSocket antes de encerrar.

    Garante que:
    - Clientes WS recebam close frame (não 'connection reset').
    - Jobs em andamento não são perdidos (dispatcher finaliza ciclo atual).
    - Rate limiter Redis fecha conexão limpa.
    """
    logger.info("SHUTDOWN_INITIATED: drenando conexões WebSocket...")
    try:
        from realtime import event_bus
        await event_bus.close_all(reason="server_shutdown")
        logger.info("SHUTDOWN: WebSocket connections drained.")
    except Exception as e:
        logger.warning("SHUTDOWN: erro ao drenar WS: %s", e)

    # Fechar conexão Redis do rate limiter
    try:
        from rate_limit_service import rate_limiter
        if hasattr(rate_limiter, "_redis") and rate_limiter._redis:
            await rate_limiter._redis.aclose()
            logger.info("SHUTDOWN: Redis rate limiter closed.")
    except Exception as e:
        logger.warning("SHUTDOWN: erro ao fechar Redis: %s", e)

    logger.info("SHUTDOWN_COMPLETE.")


async def _start_background_tasks():
    """Inicia tasks de background assíncronas."""
    logger.info("Starting outbox dispatcher...")
    from outbox_service import run_dispatcher
    asyncio.create_task(run_dispatcher())

    logger.info("Starting export job dispatcher...")
    from export_job_service import run_export_dispatcher
    asyncio.create_task(run_export_dispatcher())

    logger.info("Starting cache eviction...")
    asyncio.create_task(_cache_eviction_loop())

    logger.info("Starting realtime adapter (if Redis)...")
    from realtime import event_bus
    if hasattr(event_bus._adapter, "start"):
        await event_bus._adapter.start()


async def _cache_eviction_loop():
    """Remove entradas expiradas do cache periodicamente."""
    from cache_service import cache
    while True:
        cache.evict_expired()
        await asyncio.sleep(60)


async def _run_p0_5_migrations():
    """Backfill P0.5: idempotente, safe para produção."""
    try:
        import sys as _sys
        import os as _os
        _scripts_path = _os.path.join(_os.path.dirname(__file__), "../scripts")
        if _scripts_path not in _sys.path:
            _sys.path.insert(0, _scripts_path)
        from backfill_p0_5 import (
            backfill_users,
            backfill_sales_source,
            backfill_attendances_source,
            backfill_store_slugs,
            register_migration_event,
        )
        from db import db as _db
        u = await backfill_users(_db)
        s = await backfill_sales_source(_db)
        a = await backfill_attendances_source(_db)
        st = await backfill_store_slugs(_db)
        stats = {
            "users_normalized_email": u["updated_normalized_email"],
            "users_token_version":    u["updated_token_version"],
            "sales_source":           s["updated"],
            "attendances_source":     a["updated"],
            "stores_slug":            st["updated"],
        }
        if any(v > 0 for v in stats.values()):
            await register_migration_event(_db, stats)
            logger.info("P0.5 backfill aplicado: %s", stats)
        else:
            logger.info("P0.5 backfill: nenhum dado novo a migrar (idempotente).")
    except Exception as e:
        logger.error("Erro na migração P0.5: %s", e, exc_info=True)


@app.get("/")
async def root():
    return {"service": "lista-da-vez-api", "status": "ok", "version": "1.0.0-p2"}


# ── Endpoint de Observabilidade ───────────────────────────────────────────────
@app.get("/api/admin/observability")
async def admin_observability(_: dict = Depends(require_super_admin)):
    """Métricas operacionais — apenas Super Admin."""
    from observability import metrics
    from cache_service import cache
    from realtime import event_bus
    from db import db

    snap = metrics.snapshot()

    # WebSocket stats
    snap["websocket"] = {
        "active_connections": event_bus.get_active_connections_count(),
        "by_store": event_bus.get_active_connections_by_store(),
        "mode": event_bus.mode,
        "events_published": event_bus.events_published_count,
        "events_failed": event_bus.events_failed_count,
    }

    # Cache stats
    snap["cache"] = cache.stats

    # Outbox stats
    try:
        outbox_stats = {}
        for status in ["PENDING", "PUBLISHED", "FAILED", "DEAD_LETTER"]:
            outbox_stats[status.lower()] = await db.event_outbox.count_documents({"status": status})
        snap["outbox"] = outbox_stats
    except Exception:
        snap["outbox"] = {}

    # DB health
    import time
    t0 = time.monotonic()
    try:
        from db import client
        await client.admin.command("ping")
        snap["db_response_ms"] = round((time.monotonic() - t0) * 1000)
        snap["db_status"] = "connected"
    except Exception:
        snap["db_status"] = "unreachable"
        snap["db_response_ms"] = -1

    return snap


# ── Middleware de métricas ─────────────────────────────────────────────────────
from starlette.middleware.base import BaseHTTPMiddleware as _BaseHTTPMiddleware

class _MetricsMiddleware(_BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        import time as _time
        from observability import metrics
        t0 = _time.monotonic()
        response = await call_next(request)
        dur = int((_time.monotonic() - t0) * 1000)
        metrics.record_request(response.status_code, dur)
        if response.status_code == 429:
            metrics.record_rate_limit()
        return response

app.add_middleware(_MetricsMiddleware)
