"""SalesService — registro comercial detalhado (Etapa 5).

Regras de dinheiro ESTRITAMENTE em inteiros (centavos). Nenhum cálculo com float.
Validação centralizada de itens, descontos e formas de pagamento.
"""
from typing import Dict, Any, List

from fastapi import HTTPException

from db import db
from models import new_id, utcnow_iso

VALID_PAYMENT_METHODS = {
    "CASH", "DEBIT", "CREDIT", "PIX", "TRANSFER",
    "VOUCHER", "BOLETO", "STORE_CREDIT", "OTHER",
}


MAX_SALE_CENTS = 100_000_000_00  # R$ 100.000.000,00 (100 milhões)


def _as_int_cents(value, field: str) -> int:
    """Garante inteiro >= 0 em centavos. Rejeita floats/booleanos/negativos/absurdos."""
    if value is None:
        return 0
    if isinstance(value, bool) or not isinstance(value, int):
        raise HTTPException(status_code=400, detail=f"{field} deve ser um inteiro em centavos.")
    if value < 0:
        raise HTTPException(status_code=400, detail=f"{field} não pode ser negativo.")
    if value > MAX_SALE_CENTS:
        raise HTTPException(status_code=400, detail=f"{field} excede o valor máximo permitido (R$ 100.000.000,00).")
    return value


def compute_sale_amounts(sale: Dict[str, Any]) -> Dict[str, Any]:
    """Valida e calcula os valores monetários (centavos) de uma venda detalhada.

    Retorna dict com items computados, gross/discount/net e payment_methods.
    """
    items_in = sale.get("items") or []
    computed_items: List[dict] = []
    items_total = 0
    for item in items_in:
        qty = item.get("quantity")
        if isinstance(qty, bool) or not isinstance(qty, int) or qty <= 0:
            raise HTTPException(status_code=400, detail="Quantidade do item deve ser um inteiro positivo.")
        unit = _as_int_cents(item.get("unit_price_cents"), "Preço unitário")
        disc = _as_int_cents(item.get("discount_cents"), "Desconto do item")
        gross_line = unit * qty
        if disc > gross_line:
            raise HTTPException(status_code=400, detail="Desconto do item não pode exceder o valor do item.")
        line_total = gross_line - disc
        computed_items.append({
            "product_id": item.get("product_id"),
            "name": item.get("name"),
            "sku": item.get("sku"),
            "quantity": qty,
            "unit_price_cents": unit,
            "discount_cents": disc,
            "line_total_cents": line_total,
        })
        items_total += line_total

    if computed_items:
        gross = items_total
    else:
        gross = _as_int_cents(sale.get("gross_amount_cents"), "Valor bruto")

    order_discount = _as_int_cents(sale.get("discount_amount_cents"), "Desconto")
    if order_discount > gross:
        raise HTTPException(status_code=400, detail="Desconto não pode exceder o valor bruto da venda.")
    net = gross - order_discount
    if net < 0:
        raise HTTPException(status_code=400, detail="O valor líquido da venda não pode ser negativo.")

    payments_in = sale.get("payment_methods") or []
    computed_payments: List[dict] = []
    pay_total = 0
    for p in payments_in:
        method = str(p.get("method") or "").upper()
        if method not in VALID_PAYMENT_METHODS:
            raise HTTPException(status_code=400, detail=f"Forma de pagamento inválida: {method or '(vazio)'}.")
        amt = _as_int_cents(p.get("amount_cents"), "Valor do pagamento")
        if amt <= 0:
            raise HTTPException(status_code=400, detail="Valor da forma de pagamento deve ser maior que zero.")
        computed_payments.append({"method": method, "amount_cents": amt})
        pay_total += amt
    if computed_payments and pay_total != net:
        raise HTTPException(
            status_code=400,
            detail="A soma das formas de pagamento deve ser igual ao valor líquido da venda.",
        )

    return {
        "items": computed_items,
        "gross_amount_cents": gross,
        "discount_amount_cents": order_discount,
        "net_amount_cents": net,
        "payment_methods": computed_payments,
    }


async def create_sale(*, tenant_id, store_id, attendance_id, seller_id, customer_visit_id,
                       sale: Dict[str, Any], actor_user_id) -> dict:
    """Cria uma venda detalhada vinculada a um atendimento + itens em sale_items."""
    items_in = sale.get("items") or []

    # Resolve produtos (valida existência e preenche dados ausentes).
    product_ids = [i.get("product_id") for i in items_in if i.get("product_id")]
    products = {}
    if product_ids:
        async for p in db.products.find({"tenant_id": tenant_id, "id": {"$in": product_ids}}):
            products[p["id"]] = p

    enriched_items: List[dict] = []
    for i in items_in:
        item = dict(i)
        pid = item.get("product_id")
        if pid:
            prod = products.get(pid)
            if not prod:
                raise HTTPException(status_code=404, detail="Produto não encontrado.")
            if not item.get("name"):
                item["name"] = prod.get("name")
            if not item.get("sku"):
                item["sku"] = prod.get("sku")
            if item.get("unit_price_cents") is None:
                item["unit_price_cents"] = prod.get("price_cents", 0)
        if not (item.get("name") and str(item.get("name")).strip()):
            raise HTTPException(status_code=400, detail="O nome do item é obrigatório.")
        enriched_items.append(item)

    computed = compute_sale_amounts({**sale, "items": enriched_items})

    now = utcnow_iso()
    sale_id = new_id()
    sale_doc = {
        "id": sale_id, "tenant_id": tenant_id, "store_id": store_id,
        "attendance_id": attendance_id, "seller_id": seller_id,
        "customer_visit_id": customer_visit_id,
        "gross_amount_cents": computed["gross_amount_cents"],
        "discount_amount_cents": computed["discount_amount_cents"],
        "net_amount_cents": computed["net_amount_cents"],
        "payment_methods": computed["payment_methods"],
        "item_count": sum(i["quantity"] for i in computed["items"]),
        "notes": sale.get("notes"),
        "status": "COMPLETED",
        "created_by": actor_user_id, "created_at": now, "updated_at": now,
    }
    await db.sales.insert_one(sale_doc)
    for it in computed["items"]:
        await db.sale_items.insert_one({
            "id": new_id(), "tenant_id": tenant_id, "store_id": store_id,
            "sale_id": sale_id, "attendance_id": attendance_id,
            "product_id": it["product_id"], "name": it["name"], "sku": it["sku"],
            "quantity": it["quantity"], "unit_price_cents": it["unit_price_cents"],
            "discount_cents": it["discount_cents"], "line_total_cents": it["line_total_cents"],
            "created_at": now,
        })
    sale_doc.pop("_id", None)
    return sale_doc


async def get_sale_with_items(tenant_id: str, sale_id: str) -> dict:
    sale = await db.sales.find_one({"tenant_id": tenant_id, "id": sale_id})
    if not sale:
        raise HTTPException(status_code=404, detail="Venda não encontrada.")
    sale.pop("_id", None)
    items = await db.sale_items.find({"tenant_id": tenant_id, "sale_id": sale_id}).to_list(500)
    for it in items:
        it.pop("_id", None)
    sale["items"] = items
    return sale
