"""RealtimeEventBus — P1 com adapter Redis Pub/Sub.

Modo in_memory: padrão, para dev e mono-instância.
Modo redis: produção multi-pod. Requer REDIS_URL.

Variáveis de ambiente:
  REALTIME_MODE=in_memory|redis
  REDIS_URL=redis://localhost:6379/0

Canais Redis:
  tenant:{tenant_id}            — eventos tenant-wide
  store:{tenant_id}:{store_id}  — eventos por loja
"""
import asyncio
import json
import logging
import os
from datetime import datetime, timezone
from typing import Any, Dict, Optional

logger = logging.getLogger("lista-da-vez.realtime")


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class InMemoryRealtimeAdapter:
    """Adapter in-memory (single-process). Para dev e piloto mono-instância."""

    def __init__(self):
        self._connections: Dict[Any, Dict[str, Any]] = {}
        self._by_store: Dict[tuple, set] = {}
        self._by_tenant: Dict[str, set] = {}
        self.events_published = 0
        self.events_failed = 0

    async def subscribe_to_store(self, *, tenant_id, store_id, websocket, user_id, metadata=None):
        self._connections[websocket] = {
            "tenant_id": tenant_id, "store_id": store_id,
            "user_id": user_id, "metadata": metadata or {},
        }
        self._by_store.setdefault((tenant_id, store_id), set()).add(websocket)
        self._by_tenant.setdefault(tenant_id, set()).add(websocket)
        logger.info("WS_CONNECTED tenant=%s store=%s user=%s total=%d",
                    tenant_id, store_id, user_id, len(self._connections))

    async def subscribe_to_tenant(self, *, tenant_id, websocket, user_id, metadata=None):
        """Conexão apenas no nível do tenant (sem loja). Usado para notificações e feed."""
        self._connections[websocket] = {
            "tenant_id": tenant_id, "store_id": None,
            "user_id": user_id, "metadata": metadata or {},
        }
        self._by_tenant.setdefault(tenant_id, set()).add(websocket)
        logger.info("WS_TENANT_CONNECTED tenant=%s user=%s total=%d",
                    tenant_id, user_id, len(self._connections))

    def unsubscribe(self, websocket):
        info = self._connections.pop(websocket, None)
        if not info:
            return
        key = (info["tenant_id"], info["store_id"])
        self._by_store.get(key, set()).discard(websocket)
        if not self._by_store.get(key):
            self._by_store.pop(key, None)
        self._by_tenant.get(info["tenant_id"], set()).discard(websocket)
        if not self._by_tenant.get(info["tenant_id"]):
            self._by_tenant.pop(info["tenant_id"], None)
        logger.info("WS_DISCONNECTED tenant=%s store=%s user=%s total=%d",
                    info["tenant_id"], info["store_id"], info["user_id"], len(self._connections))

    async def _send(self, ws, event: dict):
        try:
            await ws.send_json(event)
            self.events_published += 1
        except Exception as e:
            self.events_failed += 1
            logger.warning("WS_SEND_FAILED: %s", e)
            self.unsubscribe(ws)

    async def broadcast_to_store(self, tenant_id, store_id, event: dict):
        # Validação tenant-scoped: garantir que evento pertence ao tenant do canal
        if event.get("tenant_id") and event["tenant_id"] != tenant_id:
            logger.error("REALTIME_TENANT_LEAK attempt: event.tenant_id=%s != channel.tenant_id=%s",
                         event.get("tenant_id"), tenant_id)
            return
        conns = list(self._by_store.get((tenant_id, store_id), set()))
        await asyncio.gather(*[self._send(ws, event) for ws in conns], return_exceptions=True)

    async def broadcast_to_user(self, tenant_id, user_id, event: dict):
        targets = [ws for ws, info in self._connections.items()
                   if info["tenant_id"] == tenant_id and info["user_id"] == user_id]
        await asyncio.gather(*[self._send(ws, event) for ws in targets], return_exceptions=True)

    async def broadcast_to_tenant(self, tenant_id: str, event: dict):
        conns = list(self._by_tenant.get(tenant_id, set()))
        await asyncio.gather(*[self._send(ws, event) for ws in conns], return_exceptions=True)

    def get_active_connections_count(self) -> int:
        return len(self._connections)

    def get_active_connections_by_store(self) -> Dict[str, int]:
        return {f"{t}:{s}": len(c) for (t, s), c in self._by_store.items()}

    async def close_all(self, reason: str = "server_shutdown"):
        """Drena todas as conexões WebSocket ativamente enviando close frame."""
        import websockets.exceptions  # type: ignore
        conns = list(self._connections)
        logger.info("REALTIME_CLOSE_ALL: closing %d connections (reason=%s)", len(conns), reason)
        shutdown_event = {
            "event_type": "server.shutdown",
            "reason": reason,
            "timestamp": _now_iso(),
        }
        # Notifica clientes antes de fechar
        await asyncio.gather(
            *[self._send(ws, shutdown_event) for ws in conns],
            return_exceptions=True,
        )
        # Fecha cada conexão
        async def _close(ws):
            try:
                await ws.close()
            except Exception:
                pass

        await asyncio.gather(*[_close(ws) for ws in conns], return_exceptions=True)
        self._connections.clear()
        self._by_store.clear()
        self._by_tenant.clear()
        logger.info("REALTIME_CLOSE_ALL: done.")

    async def publish_event(self, *, tenant_id, store_id, event_type, payload=None, queue_id=None, user_id=None):
        event = {
            "event_type": event_type, "tenant_id": tenant_id, "store_id": store_id,
            "queue_id": queue_id, "timestamp": _now_iso(), "payload": payload or {},
        }
        await self.broadcast_to_store(tenant_id, store_id, event)
        logger.info("REALTIME_EVENT type=%s store=%s", event_type, store_id)

    async def publish_tenant_event(self, *, tenant_id: str, event_type: str, payload: dict = None):
        event = {
            "event_type": event_type, "tenant_id": tenant_id,
            "timestamp": _now_iso(), "payload": payload or {},
        }
        await self.broadcast_to_tenant(tenant_id, event)
        logger.info("REALTIME_TENANT_EVENT type=%s tenant=%s", event_type, tenant_id)


class RedisPubSubRealtimeAdapter(InMemoryRealtimeAdapter):
    """Adapter Redis Pub/Sub — P1. Para multi-instância.

    REDIS_URL deve ser configurada. Requisita redis e aioredis:
      pip install redis[asyncio]

    Em cada instância:
    - Websockets locais gerenciados em memória (herda InMemoryRealtimeAdapter)
    - Eventos publicados no Redis pub/sub para broadcast cross-instância
    - Subscriber local repassa para conexões WebSocket locais
    """

    def __init__(self, redis_url: str):
        super().__init__()
        self._redis_url = redis_url
        self._redis_pub = None
        self._redis_sub = None
        self._subscriber_task = None
        logger.info("REALTIME_REDIS_ADAPTER_INIT url=%s", redis_url[:30] + "...")

    async def start(self):
        """Conecta ao Redis e inicia subscriber."""
        try:
            import redis.asyncio as aioredis
            self._redis_pub = await aioredis.from_url(self._redis_url, decode_responses=True)
            self._redis_sub = await aioredis.from_url(self._redis_url, decode_responses=True)
            self._subscriber_task = asyncio.create_task(self._subscribe_loop())
            logger.info("REALTIME_REDIS_CONNECTED")
        except Exception as e:
            logger.error("REALTIME_REDIS_CONNECT_FAILED: %s — usando in-memory fallback", e)

    async def _subscribe_loop(self):
        """Escuta canais Redis e repassa para WebSockets locais."""
        try:
            pubsub = self._redis_sub.pubsub()
            await pubsub.psubscribe("realtime:*")  # subscreve todos os canais realtime:*
            async for message in pubsub.listen():
                if message["type"] not in ("pmessage", "message"):
                    continue
                try:
                    channel = message.get("channel", "")
                    data = json.loads(message.get("data", "{}"))
                    tenant_id = data.get("tenant_id")
                    store_id = data.get("store_id")
                    if not tenant_id:
                        continue
                    # Repassa para conexões locais
                    if store_id:
                        conns = list(self._by_store.get((tenant_id, store_id), set()))
                    else:
                        conns = list(self._by_tenant.get(tenant_id, set()))
                    await asyncio.gather(*[self._send(ws, data) for ws in conns], return_exceptions=True)
                except Exception as inner:
                    logger.warning("REALTIME_REDIS_MSG_ERROR: %s", inner)
        except Exception as e:
            logger.error("REALTIME_REDIS_SUBSCRIBER_LOOP_DIED: %s", e)

    async def publish_event(self, *, tenant_id, store_id, event_type, payload=None, queue_id=None, user_id=None):
        event = {
            "event_type": event_type, "tenant_id": tenant_id, "store_id": store_id,
            "queue_id": queue_id, "timestamp": _now_iso(), "payload": payload or {},
        }
        if self._redis_pub:
            try:
                channel = f"realtime:store:{tenant_id}:{store_id}"
                await self._redis_pub.publish(channel, json.dumps(event))
                logger.info("REALTIME_REDIS_PUB type=%s store=%s", event_type, store_id)
            except Exception as e:
                logger.warning("REALTIME_REDIS_PUB_FAILED: %s — fallback in-memory", e)
                await super().publish_event(
                    tenant_id=tenant_id, store_id=store_id, event_type=event_type,
                    payload=payload, queue_id=queue_id, user_id=user_id,
                )
        else:
            await super().publish_event(
                tenant_id=tenant_id, store_id=store_id, event_type=event_type,
                payload=payload, queue_id=queue_id, user_id=user_id,
            )

    async def publish_tenant_event(self, *, tenant_id: str, event_type: str, payload: dict = None):
        event = {
            "event_type": event_type, "tenant_id": tenant_id,
            "timestamp": _now_iso(), "payload": payload or {},
        }
        if self._redis_pub:
            try:
                channel = f"realtime:tenant:{tenant_id}"
                await self._redis_pub.publish(channel, json.dumps(event))
            except Exception as e:
                logger.warning("REALTIME_REDIS_PUB_TENANT_FAILED: %s", e)
                await super().publish_tenant_event(tenant_id=tenant_id, event_type=event_type, payload=payload)
        else:
            await super().publish_tenant_event(tenant_id=tenant_id, event_type=event_type, payload=payload)


# ── Fábrica singleton ─────────────────────────────────────────────────────────
def _create_event_bus():
    redis_url = os.environ.get("REDIS_URL")
    mode = (os.environ.get("REALTIME_MODE") or "in_memory").lower()
    if mode == "redis" and redis_url:
        adapter = RedisPubSubRealtimeAdapter(redis_url)
        adapter.mode = "redis"
        return adapter
    if mode == "redis" and not redis_url:
        logger.warning("REALTIME_MODE=redis mas REDIS_URL ausente — usando in_memory.")
    adapter = InMemoryRealtimeAdapter()
    adapter.mode = "in_memory"
    return adapter


# Mantém compatibilidade com código antigo que usa event_bus.events_published_count
class _CompatEventBus:
    """Wrapper para manter compatibilidade com atributos legados."""
    def __init__(self, adapter):
        self._adapter = adapter

    def __getattr__(self, name):
        # Redireciona para o adapter
        return getattr(self._adapter, name)

    @property
    def events_published_count(self):
        return self._adapter.events_published

    @property
    def events_failed_count(self):
        return self._adapter.events_failed

    @property
    def mode(self):
        return self._adapter.mode

    async def close_all(self, reason: str = "server_shutdown"):
        """Delega graceful shutdown para o adapter."""
        await self._adapter.close_all(reason)


_raw = _create_event_bus()
event_bus = _CompatEventBus(_raw)
