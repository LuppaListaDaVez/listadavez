"""ExternalNotificationService — abstração de provedores de e-mail e push.

Correções v2:
- ACCEPTED para SMTP aceito (era DELIVERED incorretamente).
- LOGGED para modo log (era DELIVERED incorretamente).
- Retorno correto em caso de falha SMTP (não mais {"status":"sent"} quando falha).
- Nenhum segredo nos logs.
"""
import logging
from typing import Optional

from db import db
from models import new_id, utcnow_iso
import email_config as cfg

logger = logging.getLogger(__name__)

# Status canônicos
_ACCEPTED   = "ACCEPTED"
_FAILED     = "FAILED"
_LOGGED     = "LOGGED"
_SKIPPED    = "SKIPPED"
_SENT       = "SENT"   # mantido para PUSH (sem mudança de semântica)


async def _get_db_email_config() -> Optional[dict]:
    """Carrega configuração SMTP do banco. Retorna None se incompleta."""
    try:
        doc = await db.system_settings.find_one({"_id": "email_config"})
        return cfg.load_from_db_doc(doc) if doc else None
    except Exception:
        return None


async def log_delivery(
    tenant_id: str,
    event_type: Optional[str],
    channel: str,
    recipient_user_id: str,
    status: str,
    provider: str = "MOCK",
    error_message: Optional[str] = None,
    notification_id: Optional[str] = None,
):
    """Persiste registro de entrega. delivered_at somente para status=DELIVERED."""
    doc = {
        "id": new_id(),
        "tenant_id": tenant_id,
        "notification_id": notification_id,
        "event_type": event_type,
        "recipient_user_id": recipient_user_id,   # já mascarado antes de chegar aqui
        "channel": channel,
        "status": status,
        "provider": provider,
        "provider_message_id": None,
        "error_code": None,
        "error_message": error_message,
        "attempt_count": 1,
        "last_attempt_at": utcnow_iso(),
        # DELIVERED somente via webhook — nunca setado aqui
        "delivered_at": utcnow_iso() if status == "DELIVERED" else None,
        "accepted_at": utcnow_iso() if status == _ACCEPTED else None,
        "read_at": None,
        "created_at": utcnow_iso(),
        "updated_at": utcnow_iso(),
    }
    await db.notification_deliveries.insert_one(doc)
    doc.pop("_id", None)
    return doc


class EmailProvider:
    """Provedor de e-mail abstrato — mock em desenvolvimento."""
    def __init__(self):
        import os
        self.provider_name = os.environ.get("EMAIL_PROVIDER", "MOCK")
        self.configured = self.provider_name not in ("MOCK", "log")

    async def send_email(
        self,
        to: str,
        subject: str,
        body: str,
        tenant_id: str,
        recipient_user_id: str,
        event_type: Optional[str] = None,
    ) -> dict:
        if not self.configured:
            logger.info("EMAIL_MOCK event=%s", event_type)
            return await log_delivery(
                tenant_id=tenant_id,
                event_type=event_type,
                channel="EMAIL",
                recipient_user_id=recipient_user_id,
                status=_SKIPPED,
                provider="MOCK",
                error_message=f"Provider não configurado (EMAIL_PROVIDER={self.provider_name}).",
            )
        logger.info("EMAIL_SEND event=%s provider=%s", event_type, self.provider_name)
        return await log_delivery(
            tenant_id=tenant_id,
            event_type=event_type,
            channel="EMAIL",
            recipient_user_id=recipient_user_id,
            status=_SENT,
            provider=self.provider_name,
        )


class PushProvider:
    """Provedor de push abstrato — mock em desenvolvimento."""
    def __init__(self):
        import os
        self.provider_name = os.environ.get("PUSH_PROVIDER", "MOCK")
        self.configured = self.provider_name != "MOCK"

    async def send_push(
        self,
        subscription: dict,
        title: str,
        body: str,
        tenant_id: str,
        recipient_user_id: str,
        event_type: Optional[str] = None,
    ) -> dict:
        if not self.configured:
            logger.info("PUSH_MOCK event=%s", event_type)
            return await log_delivery(
                tenant_id=tenant_id,
                event_type=event_type,
                channel="PUSH",
                recipient_user_id=recipient_user_id,
                status=_SKIPPED,
                provider="MOCK",
                error_message=f"Provider não configurado (PUSH_PROVIDER={self.provider_name}).",
            )
        logger.info("PUSH_SEND event=%s provider=%s", event_type, self.provider_name)
        return await log_delivery(
            tenant_id=tenant_id,
            event_type=event_type,
            channel="PUSH",
            recipient_user_id=recipient_user_id,
            status=_SENT,
            provider=self.provider_name,
        )


email_provider = EmailProvider()
push_provider  = PushProvider()


async def send_invite_email(
    *,
    to_email: str,
    to_name: str = "",
    invite_link: str,
    tenant_name: str,
    tenant_id: str,
    invite_type: str = "TENANT_OWNER",
) -> dict:
    """Envia e-mail de convite.

    Prioridade: configuração salva no banco → variáveis de ambiente.
    Retorna {"status": "accepted"|"logged"|"failed", "to": ..., "tenant_id": ...}
    Nunca retorna "sent"/"delivered" após falha.
    """
    from email_service import send_smtp_raw, _build_html

    db_config_raw = await _get_db_email_config()

    if db_config_raw:
        # Usar config do banco (carregada e normalizada por email_config.load_from_db_doc)
        subject = f"Convite para ativar sua conta — {tenant_name}"
        html, text = _build_html(
            tenant_name=tenant_name,
            invite_link=invite_link,
            invite_type=invite_type,
            to_name=to_name,
        )
        # Converter de volta para o formato dict que send_smtp_raw aceita
        smtp_cfg = {
            "smtp_host":     db_config_raw["host"],
            "smtp_port":     db_config_raw["port"],
            "smtp_user":     db_config_raw["user"],
            "smtp_password": db_config_raw["password"],
            "smtp_tls":      db_config_raw["tls"],
            "smtp_ssl":      db_config_raw["ssl"],
            "smtp_from":     db_config_raw["from_"],
            "smtp_timeout":  db_config_raw["timeout"],
        }
        try:
            await send_smtp_raw(
                config=smtp_cfg,
                to_email=to_email,
                subject=subject,
                html=html,
                text=text,
            )
            await log_delivery(
                tenant_id=tenant_id,
                event_type="INVITE",
                channel="EMAIL",
                recipient_user_id=f"invite:{to_email[:3]}***",
                status=_ACCEPTED,
                provider="SMTP_DB",
            )
            return {"status": "accepted", "to": to_email, "tenant_id": tenant_id}
        except Exception as exc:
            logger.error(
                "INVITE_SMTP_FAILED tenant=%s error=%s",
                tenant_id, type(exc).__name__,
            )
            await log_delivery(
                tenant_id=tenant_id,
                event_type="INVITE",
                channel="EMAIL",
                recipient_user_id=f"invite:{to_email[:3]}***",
                status=_FAILED,
                provider="SMTP_DB",
                error_message=type(exc).__name__,   # nunca incluir senha/token
            )
            return {"status": "failed", "to": to_email, "tenant_id": tenant_id}
    else:
        # Fallback: env vars (EMAIL_PROVIDER do .env)
        from email_service import send_invite_email as _env_send
        accepted = await _env_send(
            to_email=to_email,
            to_name=to_name,
            invite_link=invite_link,
            invite_type=invite_type,
            tenant_name=tenant_name,
            tenant_id=tenant_id,
            log_delivery_fn=log_delivery,
        )
        final_status = "accepted" if accepted else "logged"
        return {"status": final_status, "to": to_email, "tenant_id": tenant_id}


async def send_password_reset_email(
    *,
    to_email: str,
    to_name: str = "",
    reset_link: str,
    tenant_name: str = "",
    tenant_id: str = "",
) -> dict:
    """Envia e-mail de redefinição de senha.

    Retorna {"status": "accepted"|"logged"|"failed", "to": ..., "tenant_id": ...}
    Nunca retorna "sent"/"delivered" após falha.
    """
    from email_service import send_smtp_raw, _build_password_reset_html

    db_config_raw = await _get_db_email_config()

    if db_config_raw:
        subject = "Redefinição de senha — Lista da Vez"
        html, text = _build_password_reset_html(
            reset_link=reset_link,
            to_name=to_name,
            tenant_name=tenant_name,
        )
        smtp_cfg = {
            "smtp_host":     db_config_raw["host"],
            "smtp_port":     db_config_raw["port"],
            "smtp_user":     db_config_raw["user"],
            "smtp_password": db_config_raw["password"],
            "smtp_tls":      db_config_raw["tls"],
            "smtp_ssl":      db_config_raw["ssl"],
            "smtp_from":     db_config_raw["from_"],
            "smtp_timeout":  db_config_raw["timeout"],
        }
        try:
            await send_smtp_raw(
                config=smtp_cfg,
                to_email=to_email,
                subject=subject,
                html=html,
                text=text,
            )
            await log_delivery(
                tenant_id=tenant_id,
                event_type="PASSWORD_RESET",
                channel="EMAIL",
                recipient_user_id=f"reset:{to_email[:3]}***",
                status=_ACCEPTED,
                provider="SMTP_DB",
            )
            return {"status": "accepted", "to": to_email, "tenant_id": tenant_id}
        except Exception as exc:
            logger.error(
                "RESET_SMTP_FAILED tenant=%s error=%s",
                tenant_id, type(exc).__name__,
            )
            await log_delivery(
                tenant_id=tenant_id,
                event_type="PASSWORD_RESET",
                channel="EMAIL",
                recipient_user_id=f"reset:{to_email[:3]}***",
                status=_FAILED,
                provider="SMTP_DB",
                error_message=type(exc).__name__,
            )
            return {"status": "failed", "to": to_email, "tenant_id": tenant_id}
    else:
        from email_service import send_password_reset_email as _env_send
        accepted = await _env_send(
            to_email=to_email,
            to_name=to_name,
            reset_link=reset_link,
            tenant_name=tenant_name,
            tenant_id=tenant_id,
            log_delivery_fn=log_delivery,
        )
        final_status = "accepted" if accepted else "logged"
        return {"status": final_status, "to": to_email, "tenant_id": tenant_id}
