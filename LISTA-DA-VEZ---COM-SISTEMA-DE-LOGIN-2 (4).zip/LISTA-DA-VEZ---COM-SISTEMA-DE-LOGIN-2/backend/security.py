"""Auth utilities: bcrypt + JWT + dependencies — Etapa 13."""
import os
import hashlib
import secrets
import uuid
from datetime import datetime, timezone, timedelta
from typing import Optional

import bcrypt
import jwt
from fastapi import Depends, HTTPException, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

from db import db

JWT_ALGORITHM = os.environ.get("JWT_ALGORITHM", "HS256")
ACCESS_TOKEN_EXPIRES_MIN = int(os.environ.get("ACCESS_TOKEN_EXPIRES_MIN", "15"))
REFRESH_TOKEN_EXPIRES_DAYS = int(os.environ.get("REFRESH_TOKEN_EXPIRES_DAYS", "7"))


def get_jwt_secret() -> str:
    return os.environ["JWT_SECRET"]


# ─── password ──────────────────────────────────────────────────────────────────
def hash_password(password: str) -> str:
    salt = bcrypt.gensalt()
    return bcrypt.hashpw(password.encode("utf-8"), salt).decode("utf-8")


def verify_password(plain: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))
    except Exception:
        return False


# ─── tokens ────────────────────────────────────────────────────────────────────
def create_tenant_access_token(
    *,
    user_id: str,
    email: str,
    tenant_id: str,
    tenant_slug: str,
    membership_id: str,
    role: str,
    session_id: str,
) -> str:
    now = datetime.now(timezone.utc)
    payload = {
        "sub": user_id,
        "user_id": user_id,
        "email": email,
        "is_super_admin": False,
        "auth_context": "TENANT",
        "tenant_id": tenant_id,
        "tenant_slug": tenant_slug,
        "membership_id": membership_id,
        "role": role,
        "session_id": session_id,
        "type": "access",
        "jti": str(uuid.uuid4()),
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(minutes=ACCESS_TOKEN_EXPIRES_MIN)).timestamp()),
    }
    return jwt.encode(payload, get_jwt_secret(), algorithm=JWT_ALGORITHM)


def create_super_admin_access_token(
    *,
    user_id: str,
    email: str,
    session_id: str,
) -> str:
    now = datetime.now(timezone.utc)
    payload = {
        "sub": user_id,
        "user_id": user_id,
        "email": email,
        "is_super_admin": True,
        "auth_context": "SUPER_ADMIN",
        "session_id": session_id,
        "type": "access",
        "jti": str(uuid.uuid4()),
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(minutes=ACCESS_TOKEN_EXPIRES_MIN)).timestamp()),
    }
    return jwt.encode(payload, get_jwt_secret(), algorithm=JWT_ALGORITHM)


def create_access_token(user_id: str, email: str, is_super_admin: bool) -> str:
    """Compatibilidade legada — usado apenas por Super Admin via /auth/login global."""
    now = datetime.now(timezone.utc)
    payload = {
        "sub": user_id,
        "email": email,
        "is_super_admin": is_super_admin,
        "auth_context": "SUPER_ADMIN" if is_super_admin else "LEGACY",
        "type": "access",
        "jti": str(uuid.uuid4()),
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(minutes=ACCESS_TOKEN_EXPIRES_MIN)).timestamp()),
    }
    return jwt.encode(payload, get_jwt_secret(), algorithm=JWT_ALGORITHM)


def create_refresh_token_raw() -> str:
    return secrets.token_urlsafe(48)


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def decode_token(token: str) -> dict:
    return jwt.decode(token, get_jwt_secret(), algorithms=[JWT_ALGORITHM])


# ─── HTTP dependency ────────────────────────────────────────────────────────────
bearer_scheme = HTTPBearer(auto_error=False)


async def get_current_user(
    request: Request,
    creds: Optional[HTTPAuthorizationCredentials] = Depends(bearer_scheme),
) -> dict:
    token = creds.credentials if creds else None
    if not token:
        auth = request.headers.get("Authorization", "")
        if auth.startswith("Bearer "):
            token = auth[7:]
    if not token:
        raise HTTPException(status_code=401, detail="Não autenticado")
    try:
        payload = decode_token(token)
        if payload.get("type") != "access":
            raise HTTPException(status_code=401, detail="Tipo de token inválido")
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expirado")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Token inválido")

    # Armazena payload no request.state para uso downstream
    request.state.token_payload = payload
    request.state.user_id = payload.get("sub")
    request.state.session_id = payload.get("session_id")

    user = await db.users.find_one({"id": payload["sub"]})
    if not user or user.get("status") != "ACTIVE":
        raise HTTPException(status_code=401, detail="Usuário inválido")
    user.pop("password_hash", None)
    user.pop("_id", None)
    return user


def require_super_admin(user: dict = Depends(get_current_user)) -> dict:
    if not user.get("is_super_admin"):
        raise HTTPException(
            status_code=403,
            detail={
                "error": "SUPER_ADMIN_ONLY",
                "message": "Acesso restrito ao Super Admin.",
            },
        )
    return user


def _get_request_id(request: Optional[Request]) -> Optional[str]:
    if request is None:
        return None
    return getattr(request.state, "request_id", None)


async def get_tenant_membership(
    tenant_slug: str,
    user: dict,
    token_payload: Optional[dict] = None,
    request: Optional[Request] = None,
) -> tuple:
    """Resolve tenant + valida membership + verifica isolamento de sessão tenant."""
    tenant = await db.tenants.find_one({"slug": tenant_slug})
    if not tenant:
        raise HTTPException(status_code=404, detail="Empresa não encontrada.")
    if tenant.get("status") not in ("ACTIVE", "TRIAL"):
        raise HTTPException(status_code=403, detail="Empresa não está ativa.")

    # Super Admin bypass
    if user.get("is_super_admin"):
        membership = {
            "tenant_id": tenant["id"],
            "user_id": user["id"],
            "role": "TENANT_ADMIN",
            "store_ids": [],
            "status": "ACTIVE",
        }
        return tenant, membership

    # Verificação de isolamento tenant-scoped
    if token_payload:
        auth_context = token_payload.get("auth_context", "LEGACY")
        if auth_context == "TENANT":
            token_tenant_slug = token_payload.get("tenant_slug")
            token_tenant_id = token_payload.get("tenant_id")

            slug_mismatch = token_tenant_slug and token_tenant_slug != tenant_slug
            id_mismatch = token_tenant_id and token_tenant_id != tenant["id"]

            if slug_mismatch or id_mismatch:
                # Logar security event de forma assíncrona (fire-and-forget)
                try:
                    from security_event_service import log_security_event, SecurityEventType
                    await log_security_event(
                        event_type=SecurityEventType.TENANT_SESSION_MISMATCH,
                        tenant_id=tenant["id"],
                        tenant_slug=tenant_slug,
                        user_id=user["id"],
                        session_id=token_payload.get("session_id"),
                        metadata={
                            "token_tenant_slug": token_tenant_slug,
                            "url_tenant_slug": tenant_slug,
                        },
                        request=request,
                    )
                except Exception:
                    pass
                raise HTTPException(
                    status_code=401,
                    detail={
                        "error": "TENANT_SESSION_MISMATCH",
                        "message": "Sua sessão não pertence a esta empresa. Faça login novamente.",
                        "action": "REAUTH_REQUIRED",
                        "request_id": _get_request_id(request),
                    },
                )
        # LEGACY tokens de não-super-admin: ainda permitidos para compatibilidade
        # mas apenas se o usuário tiver membership válida

    membership = await db.tenant_memberships.find_one(
        {"tenant_id": tenant["id"], "user_id": user["id"], "status": "ACTIVE"}
    )
    if not membership:
        raise HTTPException(
            status_code=403, detail="Você não tem acesso a esta empresa."
        )
    membership.pop("_id", None)
    return tenant, membership


def require_roles(*allowed_roles: str):
    """Factory para dependency que verifica role."""
    async def _dep(
        tenant_slug: str,
        user: dict = Depends(get_current_user),
        request: Request = None,
    ):
        token_payload = getattr(request.state, "token_payload", None) if request else None
        tenant, membership = await get_tenant_membership(tenant_slug, user, token_payload, request)
        if membership["role"] not in allowed_roles:
            raise HTTPException(
                status_code=403, detail="Permissão insuficiente para esta ação."
            )
        return {"tenant": tenant, "membership": membership, "user": user}

    return _dep


async def resolve_tenant_context(
    tenant_slug: str,
    user: dict = Depends(get_current_user),
    request: Request = None,
):
    """Dependency padrão: retorna tenant, membership, user para qualquer role."""
    token_payload = getattr(request.state, "token_payload", None) if request else None
    tenant, membership = await get_tenant_membership(tenant_slug, user, token_payload, request)
    return {"tenant": tenant, "membership": membership, "user": user}
