"""Lista da Vez — endpoints da fila (P0: idempotência + rate limit)."""
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request

from db import db
from idempotency_service import check_idempotency, register_idempotency, complete_idempotency
from models import (
    QueueCreate, QueueUpdate, QueueStatusUpdate,
    QueueJoinRequest, QueueLeaveRequest, StartAttendanceRequest,
    StartPreferenceAttendanceRequest,
    FinishAttendanceRequest, FinishMultipleAttendancesRequest, ReorderQueueRequest, MarkAwayRequest,
    ReturnSellerRequest, QuickAttendanceRequest, utcnow_iso,
    # Novos modelos — Prompt 2
    SairDaFilaRequest, RetornarOperacaoRequest, NovaJornadaRequest, RetornarDaForaRequest,
)
from rate_limit_service import make_rate_limit_dep
from security import resolve_tenant_context
from feature_guard import require_feature
from audit import log_audit
import queue_engine as qe

router = APIRouter(prefix="/tenants/{tenant_slug}/stores/{store_id}", tags=["queue"])

_rl_queue = make_rate_limit_dep("QUEUE_ACTIONS")
_rl_att_start = make_rate_limit_dep("ATTENDANCE_START")
_rl_att_finish = make_rate_limit_dep("ATTENDANCE_FINISH")

MANAGER_ROLES = {"TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER"}

def _store_allowed(membership, store_id):
    if membership["role"] in {"TENANT_ADMIN", "REGIONAL_MANAGER"}:
        return True
    return store_id in (membership.get("store_ids") or [])


async def _guard(ctx, store_id):
    await require_feature(ctx["tenant"]["id"], "lista_da_vez")
    store = await db.stores.find_one({"tenant_id": ctx["tenant"]["id"], "id": store_id})
    if not store:
        raise HTTPException(status_code=404, detail="Unidade não encontrada.")
    if not _store_allowed(ctx["membership"], store_id):
        raise HTTPException(status_code=403, detail="Sem acesso a esta unidade.")


async def _own_seller_id(ctx):
    s = await db.seller_profiles.find_one(
        {"tenant_id": ctx["tenant"]["id"], "user_id": ctx["user"]["id"]}
    )
    return s["id"] if s else None


# ---------- Queues CRUD ----------
@router.get("/queues")
async def list_queues(store_id: str, ctx: dict = Depends(resolve_tenant_context)):
    await _guard(ctx, store_id)
    await qe.ensure_default_queue(ctx["tenant"]["id"], store_id)
    items = await db.queues.find(
        {"tenant_id": ctx["tenant"]["id"], "store_id": store_id}
    ).sort("is_default", -1).to_list(200)
    for q in items:
        q.pop("_id", None)
    return items


@router.post("/queues", status_code=201)
async def create_queue(store_id: str, payload: QueueCreate, request: Request, ctx: dict = Depends(resolve_tenant_context)):
    await _guard(ctx, store_id)
    if ctx["membership"]["role"] not in MANAGER_ROLES:
        raise HTTPException(status_code=403, detail="Permissão insuficiente para criar filas.")
    return await qe.create_queue(tenant_id=ctx["tenant"]["id"], store_id=store_id,
                                 data=payload.model_dump(), actor_user_id=ctx["user"]["id"], request=request)


@router.get("/queues/{queue_id}")
async def get_queue(store_id: str, queue_id: str, ctx: dict = Depends(resolve_tenant_context)):
    await _guard(ctx, store_id)
    q = await db.queues.find_one({"tenant_id": ctx["tenant"]["id"], "store_id": store_id, "id": queue_id})
    if not q:
        raise HTTPException(status_code=404, detail="Fila não encontrada.")
    q.pop("_id", None)
    return q


@router.put("/queues/{queue_id}")
async def update_queue(store_id: str, queue_id: str, payload: QueueUpdate, request: Request, ctx: dict = Depends(resolve_tenant_context)):
    await _guard(ctx, store_id)
    if ctx["membership"]["role"] not in MANAGER_ROLES:
        raise HTTPException(status_code=403, detail="Permissão insuficiente.")
    q = await db.queues.find_one({"tenant_id": ctx["tenant"]["id"], "store_id": store_id, "id": queue_id})
    if not q:
        raise HTTPException(status_code=404, detail="Fila não encontrada.")
    updates = {k: v for k, v in payload.model_dump(exclude_none=True).items()}
    if "settings" in updates:
        updates["settings"] = {**(q.get("settings") or {}), **updates["settings"]}
    if updates:
        updates["updated_at"] = utcnow_iso()
        await db.queues.update_one({"id": queue_id}, {"$set": updates, "$inc": {"version": 1}})
    await log_audit(action="QUEUE_UPDATED", entity="queue", entity_id=queue_id,
                    tenant_id=ctx["tenant"]["id"], store_id=store_id, user_id=ctx["user"]["id"],
                    new_value=updates, request=request)
    updated = await db.queues.find_one({"id": queue_id})
    updated.pop("_id", None)
    return updated


@router.patch("/queues/{queue_id}/status")
async def queue_status(store_id: str, queue_id: str, payload: QueueStatusUpdate, request: Request, ctx: dict = Depends(resolve_tenant_context)):
    await _guard(ctx, store_id)
    if ctx["membership"]["role"] not in MANAGER_ROLES:
        raise HTTPException(status_code=403, detail="Permissão insuficiente.")
    q = await db.queues.find_one({"tenant_id": ctx["tenant"]["id"], "store_id": store_id, "id": queue_id})
    if not q:
        raise HTTPException(status_code=404, detail="Fila não encontrada.")
    if q.get("is_default") and payload.status == "INACTIVE":
        raise HTTPException(status_code=400, detail="A fila padrão não pode ser desativada.")
    await db.queues.update_one({"id": queue_id}, {"$set": {"status": payload.status, "updated_at": utcnow_iso()}})
    await log_audit(action="QUEUE_STATUS_CHANGED", entity="queue", entity_id=queue_id,
                    tenant_id=ctx["tenant"]["id"], store_id=store_id, user_id=ctx["user"]["id"],
                    old_value={"status": q["status"]}, new_value={"status": payload.status}, request=request)
    return {"id": queue_id, "status": payload.status}


# ---------- Queue state & events ----------
@router.get("/queue")
async def queue_state(store_id: str, queue_id: Optional[str] = None, ctx: dict = Depends(resolve_tenant_context)):
    await _guard(ctx, store_id)
    return await qe.get_queue_state(ctx["tenant"]["id"], store_id, queue_id)


@router.get("/queue/events")
async def queue_events(store_id: str, queue_id: Optional[str] = None, limit: int = 50, ctx: dict = Depends(resolve_tenant_context)):
    await _guard(ctx, store_id)
    tenant_id = ctx["tenant"]["id"]
    q = {"tenant_id": tenant_id, "store_id": store_id}
    if queue_id:
        q["queue_id"] = queue_id
    raw = await db.queue_events.find(q).sort("created_at", -1).limit(min(limit, 200)).to_list(200)
    seller_ids = [e["seller_id"] for e in raw if e.get("seller_id")]
    sellers = {}
    if seller_ids:
        async for s in db.seller_profiles.find({"id": {"$in": seller_ids}}):
            sellers[s["id"]] = s
    users = {}
    if sellers:
        async for u in db.users.find({"id": {"$in": [s["user_id"] for s in sellers.values()]}}):
            users[u["id"]] = u
    out = []
    for e in raw:
        e.pop("_id", None)
        s = sellers.get(e.get("seller_id"))
        out.append({**e, "seller_name": users.get(s["user_id"], {}).get("name") if s else None})
    return out


# ---------- Operations ----------
@router.post("/queue/join")
async def join(store_id: str, payload: QueueJoinRequest, request: Request,
               ctx: dict = Depends(resolve_tenant_context),
               _rl: None = Depends(_rl_queue)):
    await _guard(ctx, store_id)
    role = ctx["membership"]["role"]
    if role == "SELLER":
        if await _own_seller_id(ctx) != payload.seller_id:
            raise HTTPException(status_code=403, detail="Vendedor só pode entrar na própria fila.")
    elif role not in MANAGER_ROLES | {"SUPERVISOR"}:
        raise HTTPException(status_code=403, detail="Permissão insuficiente.")
    return await qe.join_queue(tenant_id=ctx["tenant"]["id"], store_id=store_id, queue_id=payload.queue_id,
                               seller_id=payload.seller_id, actor_user_id=ctx["user"]["id"], actor_role=role, request=request)


@router.post("/queue/leave")
async def leave(store_id: str, payload: QueueLeaveRequest, request: Request,
                ctx: dict = Depends(resolve_tenant_context),
                _rl: None = Depends(_rl_queue)):
    await _guard(ctx, store_id)
    role = ctx["membership"]["role"]
    if role == "SELLER":
        if await _own_seller_id(ctx) != payload.seller_id:
            raise HTTPException(status_code=403, detail="Vendedor só pode sair da própria fila.")
    elif role not in MANAGER_ROLES | {"SUPERVISOR"}:
        raise HTTPException(status_code=403, detail="Permissão insuficiente.")
    return await qe.leave_queue(tenant_id=ctx["tenant"]["id"], store_id=store_id, queue_id=payload.queue_id,
                                seller_id=payload.seller_id, actor_user_id=ctx["user"]["id"], actor_role=role,
                                reason=payload.reason, request=request)


@router.post("/queue/start-attendance")
async def start_attendance(store_id: str, payload: StartAttendanceRequest, request: Request,
                           ctx: dict = Depends(resolve_tenant_context),
                           _rl: None = Depends(_rl_att_start)):
    await _guard(ctx, store_id)
    role = ctx["membership"]["role"]
    if role == "SELLER":
        if await _own_seller_id(ctx) != payload.seller_id:
            raise HTTPException(status_code=403, detail="Vendedor só pode iniciar o próprio atendimento.")
    elif role not in MANAGER_ROLES:
        raise HTTPException(status_code=403, detail="Permissão insuficiente.")
    return await qe.start_attendance(tenant_id=ctx["tenant"]["id"], store_id=store_id, queue_id=payload.queue_id,
                                     seller_id=payload.seller_id, actor_user_id=ctx["user"]["id"], actor_role=role,
                                     source=payload.source, customer_name=payload.customer_name,
                                     customer_phone=payload.customer_phone, notes=payload.notes, request=request)


@router.post("/queue/start-preference-attendance")
async def start_preference_attendance(store_id: str, payload: StartPreferenceAttendanceRequest, request: Request,
                                      ctx: dict = Depends(resolve_tenant_context),
                                      _rl: None = Depends(_rl_att_start)):
    await _guard(ctx, store_id)
    role = ctx["membership"]["role"]
    if role == "SELLER":
        own_seller_id = await _own_seller_id(ctx)
        if payload.seller_id and payload.seller_id != own_seller_id:
            raise HTTPException(status_code=403, detail="Você só pode iniciar Atendimento por Preferência para si próprio.")
        effective_seller_id = own_seller_id
    elif role in MANAGER_ROLES:
        if not payload.seller_id:
            raise HTTPException(status_code=400, detail="Selecione o vendedor procurado.")
        effective_seller_id = payload.seller_id
    else:
        raise HTTPException(status_code=403, detail="Permissão insuficiente para iniciar Atendimento por Preferência.")

    idempotency_key = request.headers.get("Idempotency-Key")
    tenant_id = ctx["tenant"]["id"]
    user_id = ctx["user"]["id"]
    idem_payload = {"seller_id": effective_seller_id, "queue_id": payload.queue_id, "customer_name": payload.customer_name}
    cached = await check_idempotency(
        idempotency_key=idempotency_key, tenant_id=tenant_id, user_id=user_id,
        endpoint="/queue/start-preference-attendance", method="POST", payload=idem_payload,
    )
    if cached:
        return cached
    record_id = await register_idempotency(
        idempotency_key=idempotency_key, tenant_id=tenant_id, user_id=user_id,
        endpoint="/queue/start-preference-attendance", method="POST", payload=idem_payload,
    )
    result = await qe.start_preference_attendance(
        tenant_id=tenant_id, store_id=store_id, queue_id=payload.queue_id,
        seller_id=effective_seller_id, customer_name=payload.customer_name,
        customer_phone=payload.customer_phone, notes=payload.notes,
        actor_user_id=user_id, actor_role=role, request=request,
    )
    await complete_idempotency(record_id, result)
    return result


@router.post("/queue/finish-attendance")
async def finish_attendance(store_id: str, payload: FinishAttendanceRequest, request: Request,
                            ctx: dict = Depends(resolve_tenant_context),
                            _rl: None = Depends(_rl_att_finish)):
    await _guard(ctx, store_id)
    role = ctx["membership"]["role"]
    if role == "SELLER":
        own = await _own_seller_id(ctx)
        att = await db.attendances.find_one({"tenant_id": ctx["tenant"]["id"], "id": payload.attendance_id})
        if not att or att.get("seller_id") != own:
            raise HTTPException(status_code=403, detail="Você só pode finalizar o seu próprio atendimento.")
    elif role not in MANAGER_ROLES:
        raise HTTPException(status_code=403, detail="Permissão insuficiente.")

    # ── Idempotência P0 ──────────────────────────────────────────────────────
    idempotency_key = request.headers.get("Idempotency-Key")
    tenant_id = ctx["tenant"]["id"]
    user_id = ctx["user"]["id"]
    idem_payload = {"attendance_id": payload.attendance_id, "result": payload.result}

    cached = await check_idempotency(
        idempotency_key=idempotency_key,
        tenant_id=tenant_id,
        user_id=user_id,
        endpoint="/queue/finish-attendance",
        method="POST",
        payload=idem_payload,
    )
    if cached:
        return cached

    record_id = await register_idempotency(
        idempotency_key=idempotency_key,
        tenant_id=tenant_id,
        user_id=user_id,
        endpoint="/queue/finish-attendance",
        method="POST",
        payload=idem_payload,
    )

    result = await qe.finish_attendance(
        tenant_id=tenant_id, store_id=store_id, attendance_id=payload.attendance_id,
        result=payload.result, sale_amount_cents=payload.sale_amount_cents,
        sale=payload.sale.model_dump() if payload.sale else None,
        loss_reason_id=payload.loss_reason_id, notes=payload.notes,
        product_quantity=payload.product_quantity,
        grupo_motivo_perda_id=payload.grupo_motivo_perda_id,
        subgrupo_motivo_perda_id=payload.subgrupo_motivo_perda_id,
        motivo_perda_id=payload.motivo_perda_id,
        descricao_complementar=payload.descricao_complementar,
        actor_user_id=user_id, actor_role=role, request=request,
    )
    await complete_idempotency(record_id, result)
    return result


@router.post("/queue/finish-multiple-attendances")
async def finish_multiple_attendances(store_id: str, payload: FinishMultipleAttendancesRequest, request: Request,
                                      ctx: dict = Depends(resolve_tenant_context),
                                      _rl: None = Depends(_rl_att_finish)):
    await _guard(ctx, store_id)
    role = ctx["membership"]["role"]
    if role == "SELLER":
        own = await _own_seller_id(ctx)
        att = await db.attendances.find_one({"tenant_id": ctx["tenant"]["id"], "id": payload.attendance_id}, {"_id": 0})
        if not att or att.get("seller_id") != own:
            raise HTTPException(status_code=403, detail="Você só pode finalizar seus próprios atendimentos.")
    elif role not in MANAGER_ROLES:
        raise HTTPException(status_code=403, detail="Permissão insuficiente.")

    idempotency_key = request.headers.get("Idempotency-Key")
    tenant_id = ctx["tenant"]["id"]
    user_id = ctx["user"]["id"]
    idem_payload = {"attendance_id": payload.attendance_id, "mode": payload.mode, "total_customers": payload.total_customers, "successes": payload.successes, "no_sales": payload.no_sales}
    cached = await check_idempotency(idempotency_key=idempotency_key, tenant_id=tenant_id, user_id=user_id,
                                     endpoint="/queue/finish-multiple-attendances", method="POST", payload=idem_payload)
    if cached:
        return cached
    record_id = await register_idempotency(idempotency_key=idempotency_key, tenant_id=tenant_id, user_id=user_id,
                                           endpoint="/queue/finish-multiple-attendances", method="POST", payload=idem_payload)
    result = await qe.finish_multiple_attendances(
        tenant_id=tenant_id, store_id=store_id, payload=payload.model_dump(),
        actor_user_id=user_id, actor_role=role, request=request,
    )
    await complete_idempotency(record_id, result)
    return result


@router.patch("/queue/reorder")
async def reorder(store_id: str, payload: ReorderQueueRequest, request: Request, ctx: dict = Depends(resolve_tenant_context)):
    await _guard(ctx, store_id)
    if ctx["membership"]["role"] not in MANAGER_ROLES:
        raise HTTPException(status_code=403, detail="Apenas administradores e gerentes podem reordenar a fila.")
    return await qe.reorder_queue(tenant_id=ctx["tenant"]["id"], store_id=store_id, queue_id=payload.queue_id,
                                  ordered_seller_ids=payload.ordered_seller_ids, actor_user_id=ctx["user"]["id"],
                                  actor_role=ctx["membership"]["role"], request=request)


@router.post("/queue/mark-away")
async def mark_away(store_id: str, payload: MarkAwayRequest, request: Request, ctx: dict = Depends(resolve_tenant_context)):
    await _guard(ctx, store_id)
    role = ctx["membership"]["role"]
    if role == "SELLER":
        if await _own_seller_id(ctx) != payload.seller_id:
            raise HTTPException(status_code=403, detail="Vendedor só pode alterar o próprio status.")
    elif role not in MANAGER_ROLES | {"SUPERVISOR"}:
        raise HTTPException(status_code=403, detail="Permissão insuficiente.")
    return await qe.mark_seller_away(tenant_id=ctx["tenant"]["id"], store_id=store_id, seller_id=payload.seller_id,
                                     new_status=payload.new_status, actor_user_id=ctx["user"]["id"], actor_role=role,
                                     reason=payload.reason, request=request)


@router.post("/queue/return")
async def return_seller(store_id: str, payload: ReturnSellerRequest, request: Request, ctx: dict = Depends(resolve_tenant_context)):
    await _guard(ctx, store_id)
    role = ctx["membership"]["role"]
    if role == "SELLER":
        if await _own_seller_id(ctx) != payload.seller_id:
            raise HTTPException(status_code=403, detail="Vendedor só pode retornar a si mesmo.")
    elif role not in MANAGER_ROLES | {"SUPERVISOR"}:
        raise HTTPException(status_code=403, detail="Permissão insuficiente.")
    return await qe.return_seller_available(tenant_id=ctx["tenant"]["id"], store_id=store_id, seller_id=payload.seller_id,
                                            actor_user_id=ctx["user"]["id"], actor_role=role, reason=payload.reason,
                                            join_queue=bool(payload.join_queue), queue_id=payload.queue_id, request=request)


@router.post("/queue/quick-attendance", status_code=201)
async def quick_attendance(store_id: str, payload: QuickAttendanceRequest, request: Request, ctx: dict = Depends(resolve_tenant_context)):
    await _guard(ctx, store_id)
    await require_feature(ctx["tenant"]["id"], "registro_rapido")
    if ctx["membership"]["role"] not in MANAGER_ROLES:
        raise HTTPException(status_code=403, detail="Apenas gerentes podem usar o Registro Rápido.")
    return await qe.quick_attendance(
        tenant_id=ctx["tenant"]["id"], store_id=store_id,
        seller_id=payload.seller_id, result=payload.result,
        customer_name=payload.customer_name, customer_phone=payload.customer_phone,
        sale_amount_cents=payload.sale_amount_cents,
        sale=payload.sale.model_dump() if payload.sale else None,
        loss_reason_id=payload.loss_reason_id, notes=payload.notes,
        product_quantity=payload.product_quantity,
        grupo_motivo_perda_id=payload.grupo_motivo_perda_id,
        subgrupo_motivo_perda_id=payload.subgrupo_motivo_perda_id,
        motivo_perda_id=payload.motivo_perda_id,
        descricao_complementar=payload.descricao_complementar,
        actor_user_id=ctx["user"]["id"], actor_role=ctx["membership"]["role"], request=request,
    )


# ────────────────────────────────────────────────────────────────────────────────
# Novos endpoints — Prompt 2: Máquina de estados em português
# ────────────────────────────────────────────────────────────────────────────────

@router.post("/queue/sair-da-fila")
async def sair_da_fila(store_id: str, payload: SairDaFilaRequest, request: Request,
                       ctx: dict = Depends(resolve_tenant_context)):
    """Janela de Saída: vendedor sai da Fila Geral com motivo obrigatório.
    Motivos: LANCHE_OU_ALMOCO, ATIVIDADE_OPERACIONAL, ENCERRAR_DIA.
    """
    await _guard(ctx, store_id)
    tenant_id = ctx["tenant"]["id"]
    role = ctx["membership"]["role"]
    seller_id = payload.seller_id

    # Vendedor só pode sair do próprio estado; gerentes podem mover qualquer vendedor da unidade
    if role == "SELLER":
        profile = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": ctx["user"]["id"]})
        if not profile or profile["id"] != seller_id:
            raise HTTPException(status_code=403, detail="Vendedor só pode alterar o próprio status.")

    return await qe.sair_da_fila(
        tenant_id=tenant_id, store_id=store_id,
        seller_id=seller_id, motivo=payload.motivo,
        queue_id=payload.queue_id,
        actor_user_id=ctx["user"]["id"], actor_role=role, request=request,
    )


@router.post("/queue/retornar-operacao")
async def retornar_operacao(store_id: str, payload: RetornarOperacaoRequest, request: Request,
                            ctx: dict = Depends(resolve_tenant_context)):
    """Remove o subestado Atividade Operacional — vendedor volta a receber chamadas na sua posição."""
    await _guard(ctx, store_id)
    tenant_id = ctx["tenant"]["id"]
    role = ctx["membership"]["role"]

    if role == "SELLER":
        profile = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": ctx["user"]["id"]})
        if not profile or profile["id"] != payload.seller_id:
            raise HTTPException(status_code=403, detail="Vendedor só pode alterar o próprio status.")

    return await qe.retornar_operacao(
        tenant_id=tenant_id, store_id=store_id,
        seller_id=payload.seller_id,
        actor_user_id=ctx["user"]["id"], actor_role=role, request=request,
    )


@router.post("/queue/nova-jornada")
async def nova_jornada(store_id: str, payload: NovaJornadaRequest, request: Request,
                       ctx: dict = Depends(resolve_tenant_context)):
    """Inicia nova jornada para vendedor que encerrou o dia — retorna ao estado Disponível."""
    await _guard(ctx, store_id)
    tenant_id = ctx["tenant"]["id"]
    role = ctx["membership"]["role"]

    if role == "SELLER":
        profile = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": ctx["user"]["id"]})
        if not profile or profile["id"] != payload.seller_id:
            raise HTTPException(status_code=403, detail="Vendedor só pode iniciar a própria jornada.")

    return await qe.nova_jornada(
        tenant_id=tenant_id, store_id=store_id,
        seller_id=payload.seller_id,
        actor_user_id=ctx["user"]["id"], actor_role=role, request=request,
    )


@router.post("/queue/retornar-da-fora")
async def retornar_da_fora(store_id: str, payload: RetornarDaForaRequest, request: Request,
                           ctx: dict = Depends(resolve_tenant_context)):
    """Vendedor retorna do estado Fora (lanche/almoço) para o final da Fila Geral."""
    await _guard(ctx, store_id)
    tenant_id = ctx["tenant"]["id"]
    role = ctx["membership"]["role"]

    if role == "SELLER":
        profile = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": ctx["user"]["id"]})
        if not profile or profile["id"] != payload.seller_id:
            raise HTTPException(status_code=403, detail="Vendedor só pode alterar o próprio status.")

    return await qe.retornar_da_fora(
        tenant_id=tenant_id, store_id=store_id,
        seller_id=payload.seller_id, queue_id=payload.queue_id,
        actor_user_id=ctx["user"]["id"], actor_role=role, request=request,
    )
