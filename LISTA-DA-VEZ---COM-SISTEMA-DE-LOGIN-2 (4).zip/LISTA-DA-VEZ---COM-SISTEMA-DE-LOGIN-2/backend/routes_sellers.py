"""Seller profiles routes."""
from fastapi import APIRouter, Depends, HTTPException, Request
from pymongo.errors import DuplicateKeyError

from db import db
from models import (
    SellerCreate, SellerUpdate, SellerStatusChange, new_id, utcnow_iso,
)
from security import resolve_tenant_context, require_roles, hash_password
from state_machine import change_state
from audit import log_audit

router = APIRouter(prefix="/tenants/{tenant_slug}/sellers", tags=["sellers"])


def _store_allowed(membership, store_id):
    if membership["role"] in {"TENANT_ADMIN", "REGIONAL_MANAGER"}:
        return True
    return store_id in (membership.get("store_ids") or [])


def _can_view(membership, role_only_self_seller: bool = False):
    return True


async def _clean(cursor):
    items = await cursor.to_list(length=500)
    for it in items:
        it.pop("_id", None)
    return items


@router.get("")
async def list_sellers(ctx: dict = Depends(resolve_tenant_context)):
    tenant = ctx["tenant"]
    membership = ctx["membership"]
    q = {"tenant_id": tenant["id"]}
    if membership["role"] in {"REGIONAL_MANAGER", "STORE_MANAGER", "SUPERVISOR"}:
        store_ids = membership.get("store_ids") or []
        if store_ids:
            q["store_id"] = {"$in": store_ids}
    elif membership["role"] == "SELLER":
        q["user_id"] = ctx["user"]["id"]
    sellers = await _clean(db.seller_profiles.find(q).sort("employee_code", 1))
    user_ids = [s["user_id"] for s in sellers]
    users = {}
    async for u in db.users.find({"id": {"$in": user_ids}}):
        users[u["id"]] = {"name": u["name"], "email": u["email"], "phone": u.get("phone")}
    for s in sellers:
        s["user"] = users.get(s["user_id"], {})
    return sellers


@router.post("", status_code=201)
async def create_seller(
    payload: SellerCreate, request: Request,
    ctx: dict = Depends(require_roles("TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER")),
):
    tenant = ctx["tenant"]
    if not _store_allowed(ctx["membership"], payload.store_id):
        raise HTTPException(status_code=403, detail="Sem acesso a esta unidade.")
    store = await db.stores.find_one({"tenant_id": tenant["id"], "id": payload.store_id})
    if not store:
        raise HTTPException(status_code=404, detail="Unidade não encontrada.")

    now = utcnow_iso()

    # Resolve user — either existing or create
    user_id = payload.user_id
    if not user_id:
        if not (payload.email and payload.name and payload.password):
            raise HTTPException(status_code=400, detail="user_id ou (name+email+password) são obrigatórios.")
        email = payload.email.lower().strip()
        existing = await db.users.find_one({"email": email})
        if existing:
            user_id = existing["id"]
        else:
            user_id = new_id()
            try:
                await db.users.insert_one({
                    "id": user_id, "name": payload.name, "email": email, "phone": payload.phone,
                    "password_hash": hash_password(payload.password), "avatar_url": None,
                    "is_super_admin": False, "status": "ACTIVE", "last_login_at": None,
                    "created_at": now, "updated_at": now,
                })
            except DuplicateKeyError:
                raise HTTPException(status_code=409, detail="Já existe um usuário com este e-mail.")

    # Ensure membership with SELLER role (or above)
    membership = await db.tenant_memberships.find_one(
        {"tenant_id": tenant["id"], "user_id": user_id}
    )
    if not membership:
        try:
            await db.tenant_memberships.insert_one({
                "id": new_id(), "tenant_id": tenant["id"], "user_id": user_id,
                "role": "SELLER", "store_ids": [payload.store_id],
                "status": "ACTIVE", "created_at": now, "updated_at": now,
            })
        except DuplicateKeyError:
            pass

    # Unique seller_profile per tenant+user
    if await db.seller_profiles.find_one({"tenant_id": tenant["id"], "user_id": user_id}):
        raise HTTPException(status_code=409, detail="Vendedor já cadastrado para este usuário.")

    seller = {
        "id": new_id(), "tenant_id": tenant["id"], "user_id": user_id,
        "store_id": payload.store_id, "team_id": payload.team_id,
        "employee_code": payload.employee_code, "hire_date": payload.hire_date,
        "status": payload.status or "ACTIVE", "current_status": payload.current_status or "OFFLINE",
        "avatar_url": None, "created_at": now, "updated_at": now,
    }
    try:
        await db.seller_profiles.insert_one(seller)
    except DuplicateKeyError:
        raise HTTPException(status_code=409, detail="Vendedor já cadastrado para este usuário.")
    await log_audit(action="SELLER_CREATED", entity="seller_profile", entity_id=seller["id"],
        tenant_id=tenant["id"], store_id=payload.store_id, user_id=ctx["user"]["id"],
        new_value={"employee_code": seller["employee_code"]}, request=request)
    seller.pop("_id", None)
    return seller


@router.get("/{seller_id}")
async def get_seller(seller_id: str, ctx: dict = Depends(resolve_tenant_context)):
    s = await db.seller_profiles.find_one({"tenant_id": ctx["tenant"]["id"], "id": seller_id})
    if not s:
        raise HTTPException(status_code=404, detail="Vendedor não encontrado.")
    if ctx["membership"]["role"] == "STORE_MANAGER" and not _store_allowed(ctx["membership"], s["store_id"]):
        raise HTTPException(status_code=403, detail="Sem acesso.")
    if ctx["membership"]["role"] == "SELLER" and s["user_id"] != ctx["user"]["id"]:
        raise HTTPException(status_code=403, detail="Sem acesso.")
    s.pop("_id", None)
    u = await db.users.find_one({"id": s["user_id"]})
    if u:
        s["user"] = {"name": u["name"], "email": u["email"], "phone": u.get("phone")}
    return s


@router.put("/{seller_id}")
async def update_seller(seller_id: str, payload: SellerUpdate, request: Request,
    ctx: dict = Depends(require_roles("TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER"))):
    s = await db.seller_profiles.find_one({"tenant_id": ctx["tenant"]["id"], "id": seller_id})
    if not s:
        raise HTTPException(status_code=404, detail="Vendedor não encontrado.")
    if not _store_allowed(ctx["membership"], s["store_id"]):
        raise HTTPException(status_code=403, detail="Sem acesso.")
    updates = {k: v for k, v in payload.model_dump(exclude_none=True).items()}
    # Don't allow direct current_status mutation
    updates.pop("current_status", None)
    if updates:
        updates["updated_at"] = utcnow_iso()
        await db.seller_profiles.update_one(
            {"id": seller_id, "tenant_id": ctx["tenant"]["id"]}, {"$set": updates})
    await log_audit(action="SELLER_UPDATED", entity="seller_profile", entity_id=seller_id,
        tenant_id=ctx["tenant"]["id"], store_id=s["store_id"], user_id=ctx["user"]["id"],
        new_value=updates, request=request)
    updated = await db.seller_profiles.find_one({"id": seller_id, "tenant_id": ctx["tenant"]["id"]})
    updated.pop("_id", None)
    return updated


@router.patch("/{seller_id}/status")
async def change_seller_status(
    seller_id: str, payload: SellerStatusChange, request: Request,
    ctx: dict = Depends(resolve_tenant_context),
):
    s = await db.seller_profiles.find_one({"tenant_id": ctx["tenant"]["id"], "id": seller_id})
    if not s:
        raise HTTPException(status_code=404, detail="Vendedor não encontrado.")
    role = ctx["membership"]["role"]
    is_self = s["user_id"] == ctx["user"]["id"]

    if role == "SELLER" and not is_self:
        raise HTTPException(status_code=403, detail="Sem acesso.")
    if role == "STORE_MANAGER" and not _store_allowed(ctx["membership"], s["store_id"]):
        raise HTTPException(status_code=403, detail="Sem acesso.")

    updated = await change_state(
        tenant_id=ctx["tenant"]["id"], store_id=s["store_id"], seller_id=seller_id,
        to_state=payload.new_status, actor_user_id=ctx["user"]["id"],
        actor_role=role, reason=payload.reason, is_self=is_self, request=request,
    )
    return updated


@router.get("/{seller_id}/status-logs")
async def status_logs(seller_id: str, ctx: dict = Depends(resolve_tenant_context)):
    s = await db.seller_profiles.find_one({"tenant_id": ctx["tenant"]["id"], "id": seller_id})
    if not s:
        raise HTTPException(status_code=404, detail="Vendedor não encontrado.")
    role = ctx["membership"]["role"]
    if role == "STORE_MANAGER" and not _store_allowed(ctx["membership"], s["store_id"]):
        raise HTTPException(status_code=403, detail="Sem acesso.")
    if role == "SELLER" and s["user_id"] != ctx["user"]["id"]:
        raise HTTPException(status_code=403, detail="Sem acesso.")
    return await _clean(
        db.seller_status_logs.find({"tenant_id": ctx["tenant"]["id"], "seller_id": seller_id}).sort("created_at", -1).limit(200)
    )
