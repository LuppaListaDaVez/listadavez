"""AlertService — Etapa 12: alertas inteligentes e operacionais."""
from typing import Optional, List
import hashlib

from db import db
from models import new_id, utcnow_iso
from realtime import event_bus
from notification_service import create_notification


async def _dedup_alert(tenant_id: str, alert_type: str, store_id: Optional[str], seller_id: Optional[str]) -> bool:
    """Retorna True se alerta idêntico aberto já existe (deduplicação)."""
    q = {
        "tenant_id": tenant_id,
        "alert_type": alert_type,
        "status": "OPEN",
        "store_id": store_id,
        "seller_id": seller_id,
    }
    existing = await db.alert_events.find_one(q)
    return existing is not None


async def create_alert(
    tenant_id: str,
    alert_type: str,
    title: str,
    message: str,
    *,
    store_id: Optional[str] = None,
    team_id: Optional[str] = None,
    seller_id: Optional[str] = None,
    alert_rule_id: Optional[str] = None,
    severity: str = "WARNING",
    metadata: Optional[dict] = None,
) -> Optional[dict]:
    # Deduplication
    if await _dedup_alert(tenant_id, alert_type, store_id, seller_id):
        return None

    now = utcnow_iso()
    doc = {
        "id": new_id(),
        "tenant_id": tenant_id,
        "store_id": store_id,
        "team_id": team_id,
        "seller_id": seller_id,
        "alert_rule_id": alert_rule_id,
        "alert_type": alert_type,
        "severity": severity,
        "title": title,
        "message": message,
        "status": "OPEN",
        "acknowledged_by": None,
        "acknowledged_at": None,
        "resolved_by": None,
        "resolved_at": None,
        "metadata": metadata or {},
        "created_at": now,
        "updated_at": now,
    }
    await db.alert_events.insert_one(doc)
    doc.pop("_id", None)

    # Realtime para a loja
    if store_id:
        await event_bus.publish_event(
            tenant_id=tenant_id,
            store_id=store_id,
            event_type="alert.created",
            payload={"id": doc["id"], "severity": severity, "title": title, "alert_type": alert_type},
        )
    return doc


async def acknowledge_alert(
    tenant_id: str,
    alert_id: str,
    user_id: str,
) -> Optional[dict]:
    now = utcnow_iso()
    await db.alert_events.update_one(
        {"tenant_id": tenant_id, "id": alert_id, "status": "OPEN"},
        {"$set": {"status": "ACKNOWLEDGED", "acknowledged_by": user_id, "acknowledged_at": now, "updated_at": now}},
    )
    doc = await db.alert_events.find_one({"id": alert_id})
    if doc:
        doc.pop("_id", None)
    return doc


async def resolve_alert(
    tenant_id: str,
    alert_id: str,
    user_id: str,
) -> Optional[dict]:
    now = utcnow_iso()
    await db.alert_events.update_one(
        {"tenant_id": tenant_id, "id": alert_id},
        {"$set": {"status": "RESOLVED", "resolved_by": user_id, "resolved_at": now, "updated_at": now}},
    )
    doc = await db.alert_events.find_one({"id": alert_id})
    if doc:
        doc.pop("_id", None)
    return doc


async def list_alerts(
    tenant_id: str,
    membership: dict,
    actor_user_id: str,
    filters: dict,
) -> List[dict]:
    from permission_service import get_accessible_store_ids
    from permissions import ROLE_PERMISSIONS, P_ALERTS_VIEW_TENANT

    role = membership["role"]
    accessible_ids = await get_accessible_store_ids(membership, tenant_id)
    q: dict = {"tenant_id": tenant_id}

    if role == "SELLER":
        q["seller_id"] = actor_user_id
    elif P_ALERTS_VIEW_TENANT not in ROLE_PERMISSIONS.get(role, []):
        req_store = filters.get("store_id")
        if req_store:
            if req_store not in accessible_ids:
                q["store_id"] = "__none__"
            else:
                q["store_id"] = req_store
        else:
            q["store_id"] = {"$in": accessible_ids} if accessible_ids else "__none__"
    else:
        if filters.get("store_id"):
            q["store_id"] = filters["store_id"]

    if filters.get("status"):
        q["status"] = filters["status"]
    if filters.get("severity"):
        q["severity"] = filters["severity"]
    if filters.get("alert_type"):
        q["alert_type"] = filters["alert_type"]

    raw = await db.alert_events.find(q).sort("created_at", -1).limit(200).to_list(200)
    for d in raw:
        d.pop("_id", None)
    return raw


async def generate_smart_alerts(tenant_id: str):
    """Geração periódica de alertas inteligentes baseados em métricas."""
    from datetime import datetime, timezone, timedelta
    from features import is_enabled

    if not await is_enabled(tenant_id, "alertas_inteligentes"):
        return

    now = datetime.now(timezone.utc)
    day_start = now.replace(hour=0, minute=0, second=0, microsecond=0).isoformat()
    day_end = now.isoformat()

    stores = await db.stores.find({"tenant_id": tenant_id, "status": "ACTIVE"}).to_list(50)
    for store in stores:
        store_id = store["id"]

        # Alerta: atendimento parado por muito tempo (> 30 min)
        stalled_cutoff = (now - timedelta(minutes=30)).isoformat()
        stalled = await db.attendances.find_one({
            "tenant_id": tenant_id,
            "store_id": store_id,
            "status": "IN_PROGRESS",
            "started_at": {"$lte": stalled_cutoff},
        })
        if stalled:
            await create_alert(
                tenant_id=tenant_id,
                alert_type="ATTENDANCE_STALLED",
                title="Atendimento parado",
                message=f"Atendimento em andamento há mais de 30 minutos na unidade {store.get('name', '')}.",
                store_id=store_id,
                severity="WARNING",
                metadata={"attendance_id": stalled["id"]},
            )

        # Alerta: taxa de conversão muito baixa hoje (< 20%)
        atts_today = await db.attendances.find({
            "tenant_id": tenant_id, "store_id": store_id,
            "status": "FINISHED", "started_at": {"$gte": day_start, "$lte": day_end},
        }).to_list(200)
        if len(atts_today) >= 5:
            sales_count = sum(1 for a in atts_today if a.get("result") in ("SALE", "WITH_SALE"))
            conv_pct = sales_count / len(atts_today) * 100
            if conv_pct < 20:
                await create_alert(
                    tenant_id=tenant_id,
                    alert_type="LOW_CONVERSION",
                    title="Baixa conversão hoje",
                    message=f"Taxa de conversão está em {conv_pct:.0f}% na unidade {store.get('name', '')}.",
                    store_id=store_id,
                    severity="WARNING",
                    metadata={"conversion_pct": round(conv_pct)},
                )
