"""Endpoints públicos de convite — Prompt 2.

POST /invites/{token}/accept  — aceitar convite e ativar conta/tenant.
Endpoint público (sem autenticação).
"""
import logging
from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException, Request

from db import db
from models import InviteAccept, new_id, utcnow_iso
from security import hash_password, hash_token
from session_service import create_session
from security_event_service import log_security_event, SecurityEventType
from rate_limit_service import check_rate_limit, get_client_ip
from audit import log_audit
from routes_tenant_auth import _issue_tenant_tokens

logger = logging.getLogger("lista-da-vez.invites")

router = APIRouter(prefix="/invites", tags=["invites"])

_GENERIC_INVITE_ERROR = "Convite inválido ou expirado."


@router.post("/{token}/accept")
async def accept_invite(token: str, payload: InviteAccept, request: Request):
    """Aceitar convite e ativar conta.

    - Para TENANT_OWNER: cria usuário (ou reutiliza existente), cria TenantMembership,
      ativa o tenant e retorna tokens de acesso.
    - E-mail já existente: apenas cria membership (não muda senha). Retorna instrução de login.
    """
    ip = get_client_ip(request)
    user_agent = request.headers.get("user-agent")

    # Rate limit por IP (grupo AUTH_LOGIN existente — reaproveitado)
    allowed, retry_after = await check_rate_limit(ip, "AUTH_LOGIN")
    if not allowed:
        raise HTTPException(
            status_code=429,
            headers={"Retry-After": str(retry_after or 60)},
            detail={
                "error": "RATE_LIMIT_EXCEEDED",
                "message": "Muitas tentativas. Tente novamente em alguns instantes.",
                "retry_after_seconds": retry_after or 60,
            },
        )

    # Buscar o documento de convite pelo hash do token
    token_hash = hash_token(token)
    invite = await db.invite_tokens.find_one({"token_hash": token_hash})

    # Validação de segurança — mensagem genérica para não vazar motivo
    now_dt = datetime.now(timezone.utc)

    def _is_invalid() -> bool:
        if not invite:
            return True
        if invite.get("used_at"):
            return True
        if invite.get("revoked_at"):
            return True
        expires = invite.get("expires_at")
        if expires:
            if isinstance(expires, str):
                from datetime import timezone as tz
                expires_dt = datetime.fromisoformat(expires)
                if expires_dt.tzinfo is None:
                    expires_dt = expires_dt.replace(tzinfo=timezone.utc)
            else:
                expires_dt = expires
                if expires_dt.tzinfo is None:
                    expires_dt = expires_dt.replace(tzinfo=timezone.utc)
            if expires_dt < now_dt:
                return True
        return False

    if _is_invalid():
        await log_security_event(
            event_type=SecurityEventType.INVITE_INVALID,
            ip=ip,
            user_agent=user_agent,
            metadata={"reason": "invalid_or_expired"},
            request=request,
        )
        raise HTTPException(status_code=400, detail=_GENERIC_INVITE_ERROR)

    invite_type = invite.get("invite_type")
    email = invite["email"].lower().strip()

    # ── TENANT_OWNER ──────────────────────────────────────────────────────────
    if invite_type == "TENANT_OWNER":
        tenant = await db.tenants.find_one({"id": invite["tenant_id"]})
        if not tenant:
            raise HTTPException(status_code=400, detail=_GENERIC_INVITE_ERROR)

        existing_user = await db.users.find_one({"email": email})
        now = utcnow_iso()

        if existing_user:
            # Usuário já existe em outro tenant → só cria membership, NÃO muda a senha
            user = existing_user
            already_member = await db.tenant_memberships.find_one(
                {"tenant_id": tenant["id"], "user_id": user["id"]}
            )
            if not already_member:
                await db.tenant_memberships.insert_one(
                    {
                        "id": new_id(),
                        "tenant_id": tenant["id"],
                        "user_id": user["id"],
                        "role": invite["role"],
                        "store_ids": invite.get("store_ids", []),
                        "status": "ACTIVE",
                        "created_at": now,
                        "updated_at": now,
                    }
                )

            # Ativar o tenant
            await db.tenants.update_one(
                {"id": tenant["id"]},
                {"$set": {"status": "ACTIVE", "updated_at": now}},
            )
            # Marcar convite como usado
            await db.invite_tokens.update_one(
                {"token_hash": token_hash},
                {"$set": {"used_at": now}},
            )
            await log_audit(
                action="TENANT_ACTIVATED",
                entity="tenant",
                entity_id=tenant["id"],
                tenant_id=tenant["id"],
                user_id=user["id"],
                request=request,
            )
            await log_security_event(
                event_type=SecurityEventType.INVITE_ACCEPTED,
                tenant_id=tenant["id"],
                user_id=user["id"],
                ip=ip,
                user_agent=user_agent,
                metadata={"invite_type": invite_type, "user_existed": True},
                request=request,
            )
            logger.info("INVITE_ACCEPTED: tenant=%s user=%s (existing user)", tenant["id"], user["id"])
            return {
                "message": (
                    "Conta vinculada com sucesso. Como você já possui uma conta, "
                    "faça login com sua senha existente."
                ),
                "tenant_slug": tenant["slug"],
                "existing_user": True,
            }

        else:
            # Novo usuário — criar conta com a senha fornecida
            if not payload.password or len(payload.password) < 8:
                raise HTTPException(status_code=422, detail="Senha deve ter ao menos 8 caracteres.")

            user = {
                "id": new_id(),
                "name": payload.name.strip() or "Administrador",
                "email": email,
                "normalized_email": email,   # P0.5: campo obrigatório
                "phone": None,
                "password_hash": hash_password(payload.password),
                "avatar_url": None,
                "is_super_admin": False,
                "status": "ACTIVE",
                "token_version": 1,          # P0.5: campo obrigatório
                "last_login_at": None,
                "created_at": now,
                "updated_at": now,
            }
            await db.users.insert_one(user)

            membership = {
                "id": new_id(),
                "tenant_id": tenant["id"],
                "user_id": user["id"],
                "role": invite["role"],
                "store_ids": invite.get("store_ids", []),
                "status": "ACTIVE",
                "created_at": now,
                "updated_at": now,
            }
            await db.tenant_memberships.insert_one(membership)

            # Ativar o tenant
            await db.tenants.update_one(
                {"id": tenant["id"]},
                {"$set": {"status": "ACTIVE", "updated_at": now}},
            )
            # Marcar convite como usado
            await db.invite_tokens.update_one(
                {"token_hash": token_hash},
                {"$set": {"used_at": now}},
            )

            await log_audit(
                action="TENANT_ACTIVATED",
                entity="tenant",
                entity_id=tenant["id"],
                tenant_id=tenant["id"],
                user_id=user["id"],
                request=request,
            )
            await log_security_event(
                event_type=SecurityEventType.INVITE_ACCEPTED,
                tenant_id=tenant["id"],
                user_id=user["id"],
                ip=ip,
                user_agent=user_agent,
                metadata={"invite_type": invite_type, "user_existed": False},
                request=request,
            )
            logger.info("INVITE_ACCEPTED: tenant=%s user=%s (new user)", tenant["id"], user["id"])

            # Emitir tokens de acesso — reutilizando _issue_tenant_tokens
            # Recarregar tenant atualizado
            tenant_updated = await db.tenants.find_one({"id": tenant["id"]})
            tenant_updated.pop("_id", None)
            membership.pop("_id", None) if "_id" in membership else None

            access_token, refresh_raw, session = await _issue_tenant_tokens(
                user=user,
                tenant=tenant_updated,
                membership=membership,
                ip=ip,
                user_agent=user_agent,
            )

            return {
                "message": "Conta ativada com sucesso.",
                "access_token": access_token,
                "refresh_token": refresh_raw,
                "token_type": "bearer",
                "auth_context": "TENANT",
                "tenant_slug": tenant["slug"],
                "tenant_id": tenant["id"],
                "session_id": session["id"],
                "user": {
                    "id": user["id"],
                    "name": user["name"],
                    "email": user["email"],
                    "is_super_admin": False,
                },
                "membership": {
                    "role": membership["role"],
                    "store_ids": membership.get("store_ids", []),
                },
            }

    # ── TENANT_USER ─────────────────────────────────────────────────────────
    if invite_type == "TENANT_USER":
        tenant = await db.tenants.find_one({"id": invite["tenant_id"]})
        if not tenant:
            raise HTTPException(status_code=400, detail=_GENERIC_INVITE_ERROR)

        existing_user = await db.users.find_one({"email": email})
        now = utcnow_iso()
        role = invite["role"]
        store_ids = invite.get("store_ids", [])
        all_stores = invite.get("all_stores", False)
        # REGIONAL_MANAGER all_stores=True → store_ids=[] (todas as filiais)
        membership_store_ids = [] if (role == "REGIONAL_MANAGER" and all_stores) else store_ids

        if existing_user:
            user = existing_user
            already_member = await db.tenant_memberships.find_one(
                {"tenant_id": tenant["id"], "user_id": user["id"]}
            )
            if not already_member:
                await db.tenant_memberships.insert_one({
                    "id": new_id(),
                    "tenant_id": tenant["id"],
                    "user_id": user["id"],
                    "role": role,
                    "store_ids": membership_store_ids,
                    "status": "ACTIVE",
                    "created_at": now,
                    "updated_at": now,
                })
        else:
            if not payload.password or len(payload.password) < 8:
                raise HTTPException(status_code=422, detail="Senha deve ter ao menos 8 caracteres.")
            user = {
                "id": new_id(),
                "name": payload.name.strip() or "Funcionário",
                "email": email,
                "normalized_email": email,
                "token_version": 1,
                "phone": None,
                "password_hash": hash_password(payload.password),
                "avatar_url": None,
                "is_super_admin": False,
                "status": "ACTIVE",
                "last_login_at": None,
                "created_at": now,
                "updated_at": now,
            }
            await db.users.insert_one(user)
            await db.tenant_memberships.insert_one({
                "id": new_id(),
                "tenant_id": tenant["id"],
                "user_id": user["id"],
                "role": role,
                "store_ids": membership_store_ids,
                "status": "ACTIVE",
                "created_at": now,
                "updated_at": now,
            })

        # Para SELLER: criar também o seller_profile
        if role == "SELLER" and store_ids:
            existing_profile = await db.seller_profiles.find_one(
                {"tenant_id": tenant["id"], "user_id": user["id"]}
            )
            if not existing_profile:
                seller_profile = {
                    "id": new_id(),
                    "tenant_id": tenant["id"],
                    "user_id": user["id"],
                    "store_id": store_ids[0],
                    "team_id": None,
                    "employee_code": None,
                    "hire_date": None,
                    "status": "ACTIVE",
                    "current_status": "OFFLINE",
                    "avatar_url": None,
                    "created_at": now,
                    "updated_at": now,
                }
                await db.seller_profiles.insert_one(seller_profile)

        # Marcar convite como usado
        await db.invite_tokens.update_one(
            {"token_hash": token_hash},
            {"$set": {"used_at": now}},
        )

        await log_audit(
            action="USER_ACTIVATED",
            entity="user",
            entity_id=user["id"],
            tenant_id=tenant["id"],
            user_id=user["id"],
            request=request,
        )
        await log_security_event(
            event_type=SecurityEventType.INVITE_ACCEPTED,
            tenant_id=tenant["id"],
            user_id=user["id"],
            ip=ip,
            user_agent=user_agent,
            metadata={"invite_type": invite_type, "role": role, "user_existed": existing_user is not None},
            request=request,
        )

        if existing_user:
            return {
                "message": "Conta vinculada. Faça login com sua senha existente.",
                "tenant_slug": tenant["slug"],
                "existing_user": True,
            }

        # Novo usuário — emitir tokens de acesso
        membership_doc = await db.tenant_memberships.find_one(
            {"tenant_id": tenant["id"], "user_id": user["id"]}
        )
        membership_doc.pop("_id", None)
        tenant_updated = await db.tenants.find_one({"id": tenant["id"]})
        tenant_updated.pop("_id", None)

        access_token, refresh_raw, session = await _issue_tenant_tokens(
            user=user,
            tenant=tenant_updated,
            membership=membership_doc,
            ip=ip,
            user_agent=user_agent,
        )
        return {
            "message": "Conta ativada com sucesso.",
            "access_token": access_token,
            "refresh_token": refresh_raw,
            "token_type": "bearer",
            "auth_context": "TENANT",
            "tenant_slug": tenant["slug"],
            "tenant_id": tenant["id"],
            "session_id": session["id"],
            "user": {
                "id": user["id"],
                "name": user["name"],
                "email": user["email"],
                "is_super_admin": False,
            },
            "membership": {
                "role": membership_doc["role"],
                "store_ids": membership_doc.get("store_ids", []),
            },
        }

    # invite_type não reconhecido (não deve chegar aqui)
    raise HTTPException(status_code=400, detail=_GENERIC_INVITE_ERROR)