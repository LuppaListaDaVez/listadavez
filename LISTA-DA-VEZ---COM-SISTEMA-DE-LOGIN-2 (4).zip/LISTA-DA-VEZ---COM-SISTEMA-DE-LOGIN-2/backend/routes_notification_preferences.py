"""Endpoints de Preferências de Notificação — Etapa 12."""
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from typing import Optional
from security import resolve_tenant_context
from feature_guard import require_feature
from permissions import ROLE_PERMISSIONS, P_NOTIF_PREFERENCES_SELF, P_NOTIF_PREFERENCES_ANY
import notification_preference_service as svc

router = APIRouter(prefix="/tenants/{tenant_slug}", tags=["notification_preferences"])


def _has(role, *perms):
    return any(p in ROLE_PERMISSIONS.get(role, []) for p in perms)


class PreferenceUpdate(BaseModel):
    in_app_enabled: Optional[bool] = None
    realtime_enabled: Optional[bool] = None
    email_enabled: Optional[bool] = None
    push_enabled: Optional[bool] = None
    motivation_events_enabled: Optional[bool] = None
    quiet_hours_enabled: Optional[bool] = None
    quiet_hours_start: Optional[str] = None
    quiet_hours_end: Optional[str] = None
    channels_by_event_type: Optional[dict] = None


@router.get("/notifications/preferences")
async def get_preferences(ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "preferencias_notificacao")
    return await svc.get_preferences(ctx["tenant"]["id"], ctx["user"]["id"])


@router.put("/notifications/preferences")
async def update_preferences(
    payload: PreferenceUpdate,
    request: Request,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "preferencias_notificacao")
    if not _has(ctx["membership"]["role"], P_NOTIF_PREFERENCES_SELF, P_NOTIF_PREFERENCES_ANY):
        raise HTTPException(status_code=403, detail="Sem permissão.")
    return await svc.upsert_preferences(
        ctx["tenant"]["id"],
        ctx["user"]["id"],
        payload.model_dump(exclude_none=True),
        request,
    )
