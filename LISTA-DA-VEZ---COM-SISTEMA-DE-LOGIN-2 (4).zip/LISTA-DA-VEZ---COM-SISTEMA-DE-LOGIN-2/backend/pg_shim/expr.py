"""Filtro estilo MongoDB + avaliador de expressões de agregação, em Python puro.

Usado tanto para find/update/delete (filtro exato) quanto para os estágios
$match/$project/$group/$addFields do executor de pipeline (pipeline.py).
"""
from __future__ import annotations

import re
from datetime import datetime, timezone
from typing import Any
from zoneinfo import ZoneInfo


class _Missing:
    def __repr__(self):
        return "<MISSING>"

    def __eq__(self, other):
        return isinstance(other, _Missing)

    def __hash__(self):
        return 0


MISSING = _Missing()


def get_path(doc: Any, path: str) -> Any:
    """Resolve um caminho pontilhado (ex: 'a.b.0.c') em um dict/list Python.
    Segue a semântica do Mongo: se um passo intermediário for uma lista e a
    próxima chave não for um índice numérico, o caminho é mapeado sobre cada
    elemento da lista (ex: '$vendas.valor' com vendas=[{valor:1},{valor:2}] -> [1,2])."""
    parts = path.split(".")
    cur = doc
    for i, part in enumerate(parts):
        if isinstance(cur, dict):
            if part not in cur:
                return MISSING
            cur = cur[part]
        elif isinstance(cur, list):
            if part.lstrip("-").isdigit():
                idx = int(part)
                if idx < 0 or idx >= len(cur):
                    return MISSING
                cur = cur[idx]
            else:
                remaining = ".".join(parts[i:])
                mapped = []
                for item in cur:
                    v = get_path(item, remaining)
                    if v is not MISSING:
                        mapped.append(v)
                return mapped
        else:
            return MISSING
    return cur


def set_path(doc: dict, path: str, value: Any) -> None:
    parts = path.split(".")
    cur = doc
    for part in parts[:-1]:
        nxt = cur.get(part) if isinstance(cur, dict) else None
        if not isinstance(nxt, (dict, list)):
            nxt = {}
            cur[part] = nxt
        cur = nxt
    cur[parts[-1]] = value


def unset_path(doc: dict, path: str) -> None:
    parts = path.split(".")
    cur = doc
    for part in parts[:-1]:
        if not isinstance(cur, dict) or part not in cur:
            return
        cur = cur[part]
    if isinstance(cur, dict):
        cur.pop(parts[-1], None)


def bson_type_name(value: Any) -> str:
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "bool"
    if isinstance(value, int):
        return "int"
    if isinstance(value, float):
        return "double"
    if isinstance(value, str):
        return "string"
    if isinstance(value, dict):
        return "object"
    if isinstance(value, list):
        return "array"
    return "unknown"


def _cmp_ok(val: Any) -> bool:
    return val is not MISSING and val is not None


def _normalize_cmp_pair(val: Any, opval: Any):
    """Permite comparar datetime (passado pelo código chamador) com string ISO (lida do JSONB)."""
    if isinstance(opval, datetime) and isinstance(val, str):
        parsed = _parse_iso(val)
        if parsed is not None:
            return parsed, opval
    if isinstance(val, datetime) and isinstance(opval, str):
        parsed = _parse_iso(opval)
        if parsed is not None:
            return val, parsed
    return val, opval


def _match_operator(val: Any, op: str, opval: Any, doc: Any = None, variables: dict | None = None) -> bool:
    if op in ("$gt", "$gte", "$lt", "$lte", "$eq", "$ne"):
        val, opval = _normalize_cmp_pair(val, opval)
    if op == "$in":
        return val in opval if val is not MISSING else False
    if op == "$nin":
        return val not in opval if val is not MISSING else True
    if op == "$ne":
        return (val if val is not MISSING else None) != opval
    if op == "$eq":
        return (val if val is not MISSING else None) == opval
    if op == "$exists":
        return (val is not MISSING) == bool(opval)
    if op == "$gt":
        return _cmp_ok(val) and val > opval
    if op == "$gte":
        return _cmp_ok(val) and val >= opval
    if op == "$lt":
        return _cmp_ok(val) and val < opval
    if op == "$lte":
        return _cmp_ok(val) and val <= opval
    if op == "$regex":
        if not isinstance(val, str):
            return False
        return re.search(opval, val) is not None
    if op == "$type":
        return bson_type_name(val if val is not MISSING else None) == opval
    if op == "$size":
        return isinstance(val, list) and len(val) == opval
    if op == "$not":
        return not match_value(val, opval)
    if op == "$elemMatch":
        if not isinstance(val, list):
            return False
        return any(matches(item, opval) for item in val)
    # operador desconhecido: não bloquear a query
    return True


def match_value(val: Any, cond: Any) -> bool:
    if isinstance(cond, dict) and cond and all(str(k).startswith("$") for k in cond.keys()):
        for op, opval in cond.items():
            if not _match_operator(val, op, opval):
                return False
        return True
    return (val if val is not MISSING else None) == cond


def matches(doc: dict, filt: dict | None, variables: dict | None = None) -> bool:
    if not filt:
        return True
    for key, cond in filt.items():
        if key == "$or":
            if not any(matches(doc, c, variables) for c in cond):
                return False
        elif key == "$and":
            if not all(matches(doc, c, variables) for c in cond):
                return False
        elif key == "$nor":
            if any(matches(doc, c, variables) for c in cond):
                return False
        elif key == "$expr":
            if not eval_expr(cond, doc, variables):
                return False
        elif key == "$where":
            # não suportado de forma genérica — trata como sem restrição adicional
            continue
        else:
            val = get_path(doc, key)
            if not match_value(val, cond):
                return False
    return True


def _parse_iso(value: Any) -> datetime | None:
    if isinstance(value, datetime):
        return value
    if not isinstance(value, str):
        return None
    try:
        v = value.replace("Z", "+00:00")
        dt = datetime.fromisoformat(v)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except ValueError:
        return None


def _to_number(v):
    return v if isinstance(v, (int, float)) and not isinstance(v, bool) else (v or 0)


def _apply_tz(dt: datetime, tz_name: Any) -> datetime:
    """Converte para o timezone informado (estilo Mongo `timezone: "America/Sao_Paulo"`)."""
    if not tz_name or not isinstance(tz_name, str):
        return dt
    try:
        return dt.astimezone(ZoneInfo(tz_name))
    except Exception:
        return dt


def eval_expr(expr: Any, doc: Any, variables: dict | None = None) -> Any:
    variables = variables or {}
    if isinstance(expr, str):
        if expr.startswith("$$"):
            name = expr[2:]
            if name == "NOW":
                return datetime.now(timezone.utc)
            return variables.get(name)
        if expr.startswith("$"):
            return get_path(doc, expr[1:])
        return expr
    if isinstance(expr, list):
        return [eval_expr(v, doc, variables) for v in expr]
    if isinstance(expr, dict):
        keys = list(expr.keys())
        if len(keys) == 1 and keys[0].startswith("$") and keys[0] not in ("$literal",):
            op = keys[0]
            arg = expr[op]
            return _apply_op(op, arg, doc, variables)
        if len(keys) == 1 and keys[0] == "$literal":
            return expr["$literal"]
        return {k: eval_expr(v, doc, variables) for k, v in expr.items()}
    return expr


def _args(arg, doc, variables, n=None):
    val = eval_expr(arg, doc, variables) if not isinstance(arg, list) else [eval_expr(a, doc, variables) for a in arg]
    if isinstance(val, list):
        return val
    return [val]


def _apply_op(op: str, arg: Any, doc: Any, variables: dict) -> Any:
    if op == "$ifNull":
        vals = arg if isinstance(arg, list) else [arg]
        for v in vals[:-1]:
            r = eval_expr(v, doc, variables)
            if r is not None and r is not MISSING:
                return r
        return eval_expr(vals[-1], doc, variables) if vals else None
    if op == "$cond":
        if isinstance(arg, dict):
            cond = eval_expr(arg.get("if"), doc, variables)
            return eval_expr(arg.get("then") if cond else arg.get("else"), doc, variables)
        cond, then, els = arg
        return eval_expr(then, doc, variables) if eval_expr(cond, doc, variables) else eval_expr(els, doc, variables)
    if op == "$eq":
        a, b = _args(arg, doc, variables)
        return a == b
    if op == "$ne":
        a, b = _args(arg, doc, variables)
        return a != b
    if op == "$gt":
        a, b = _args(arg, doc, variables)
        return (a or 0) > (b or 0) if not isinstance(a, str) else a > b
    if op == "$gte":
        a, b = _args(arg, doc, variables)
        return (a or 0) >= (b or 0) if not isinstance(a, str) else a >= b
    if op == "$lt":
        a, b = _args(arg, doc, variables)
        return (a or 0) < (b or 0) if not isinstance(a, str) else a < b
    if op == "$lte":
        a, b = _args(arg, doc, variables)
        return (a or 0) <= (b or 0) if not isinstance(a, str) else a <= b
    if op == "$in":
        a, b = _args(arg, doc, variables)
        return a in (b or [])
    if op == "$nin":
        a, b = _args(arg, doc, variables)
        return a not in (b or [])
    if op == "$and":
        return all(eval_expr(v, doc, variables) for v in arg)
    if op == "$or":
        return any(eval_expr(v, doc, variables) for v in arg)
    if op == "$not":
        v = arg[0] if isinstance(arg, list) else arg
        return not eval_expr(v, doc, variables)
    if op == "$add":
        return sum(_to_number(eval_expr(v, doc, variables)) for v in arg)
    if op == "$subtract":
        a, b = _args(arg, doc, variables)
        return _to_number(a) - _to_number(b)
    if op == "$multiply":
        vals = [_to_number(eval_expr(v, doc, variables)) for v in arg]
        r = 1
        for v in vals:
            r *= v
        return r
    if op == "$divide":
        a, b = _args(arg, doc, variables)
        b = _to_number(b)
        return (_to_number(a) / b) if b else 0
    if op == "$toLong" or op == "$toInt":
        v = eval_expr(arg, doc, variables)
        try:
            return int(v)
        except (TypeError, ValueError):
            return 0
    if op == "$toDouble":
        v = eval_expr(arg, doc, variables)
        try:
            return float(v)
        except (TypeError, ValueError):
            return 0.0
    if op == "$toString":
        v = eval_expr(arg, doc, variables)
        return "" if v is None else str(v)
    if op == "$size":
        v = eval_expr(arg, doc, variables)
        return len(v) if isinstance(v, (list, str)) else 0
    if op == "$substr" or op == "$substrBytes" or op == "$substrCP":
        s, start, length = _args(arg, doc, variables)
        s = s or ""
        start = int(start or 0)
        if length is None or length < 0:
            return s[start:]
        return s[start:start + int(length)]
    if op == "$concat":
        return "".join(str(eval_expr(v, doc, variables) or "") for v in arg)
    if op == "$type":
        v = eval_expr(arg, doc, variables)
        return bson_type_name(v)
    if op == "$literal":
        return arg
    if op == "$arrayElemAt":
        v, idx = _args(arg, doc, variables)
        if not isinstance(v, list):
            return None
        try:
            return v[idx]
        except IndexError:
            return None
    if op == "$filter":
        inp = eval_expr(arg.get("input"), doc, variables) or []
        as_name = arg.get("as", "this")
        cond = arg.get("cond")
        return [item for item in inp if eval_expr(cond, doc, {**variables, as_name: item})]
    if op == "$map":
        inp = eval_expr(arg.get("input"), doc, variables) or []
        as_name = arg.get("as", "this")
        in_expr = arg.get("in")
        return [eval_expr(in_expr, doc, {**variables, as_name: item}) for item in inp]
    if op == "$let":
        vars_def = arg.get("vars", {})
        new_vars = dict(variables)
        for k, v in vars_def.items():
            new_vars[k] = eval_expr(v, doc, variables)
        return eval_expr(arg.get("in"), doc, new_vars)
    if op == "$regexMatch":
        inp = eval_expr(arg.get("input"), doc, variables)
        regex = arg.get("regex")
        if not isinstance(inp, str) or not isinstance(regex, str):
            return False
        return re.search(regex, inp) is not None
    if op in ("$dateToString", "$dateFromString"):
        return _date_convert(op, arg, doc, variables)
    if op in ("$hour", "$dayOfWeek", "$isoWeek", "$isoWeekYear", "$year", "$month", "$dayOfMonth", "$minute", "$second"):
        tz_name = arg.get("timezone") if isinstance(arg, dict) else None
        v = eval_expr(arg, doc, variables) if not isinstance(arg, dict) else eval_expr(arg.get("date"), doc, variables)
        dt = _parse_iso(v)
        if dt is None:
            return None
        dt = _apply_tz(dt, tz_name)
        if op == "$hour":
            return dt.hour
        if op == "$minute":
            return dt.minute
        if op == "$second":
            return dt.second
        if op == "$dayOfWeek":
            return (dt.weekday() + 1) % 7 + 1  # Mongo: 1=domingo..7=sábado
        if op == "$isoWeek":
            return dt.isocalendar()[1]
        if op == "$isoWeekYear":
            return dt.isocalendar()[0]
        if op == "$year":
            return dt.year
        if op == "$month":
            return dt.month
        if op == "$dayOfMonth":
            return dt.day
    if op == "$sum":
        # como expressão fora de $group: soma valores de um array
        v = eval_expr(arg, doc, variables)
        if isinstance(v, list):
            return sum(_to_number(x) for x in v)
        return _to_number(v)
    if op == "$avg":
        v = eval_expr(arg, doc, variables)
        if isinstance(v, list) and v:
            return sum(_to_number(x) for x in v) / len(v)
        return 0
    if op == "$first":
        v = eval_expr(arg, doc, variables)
        return v[0] if isinstance(v, list) and v else None
    if op == "$last":
        v = eval_expr(arg, doc, variables)
        return v[-1] if isinstance(v, list) and v else None
    # operador não suportado — não falha a pipeline, retorna None
    return None


def _date_convert(op: str, arg: dict, doc: Any, variables: dict) -> Any:
    if op == "$dateFromString":
        s = eval_expr(arg.get("dateString"), doc, variables)
        return _parse_iso(s)
    # $dateToString
    date_val = eval_expr(arg.get("date"), doc, variables)
    dt = _parse_iso(date_val)
    if dt is None:
        return None
    dt = _apply_tz(dt, arg.get("timezone"))
    fmt = arg.get("format", "%Y-%m-%dT%H:%M:%S")
    fmt = (
        fmt.replace("%Y", "{Y}").replace("%m", "{m}").replace("%d", "{d}")
        .replace("%H", "{H}").replace("%M", "{M}").replace("%S", "{S}")
    )
    fmt = fmt.format(Y=f"{dt.year:04d}", m=f"{dt.month:02d}", d=f"{dt.day:02d}",
                      H=f"{dt.hour:02d}", M=f"{dt.minute:02d}", S=f"{dt.second:02d}")
    return fmt
