"""PGCollection / PGCursor — API compatível com Motor (AsyncIOMotorCollection)
sobre uma tabela PostgreSQL genérica (id, tenant_id, doc JSONB)."""
from __future__ import annotations

import re
from types import SimpleNamespace
from typing import Any, Optional

from pymongo.errors import DuplicateKeyError

from .expr import matches, get_path, MISSING
from .pipeline import run_pipeline

_SAFE_KEY = re.compile(r"^[A-Za-z0-9_]+$")


def _to_text(v):
    if v is None:
        return None, True
    if isinstance(v, bool):
        return ("true" if v else "false"), False
    if isinstance(v, (int, float, str)):
        return str(v), False
    return None, None


def build_where(alias: str, filt: Optional[dict], start_idx: int = 1):
    conditions: list[str] = []
    params: list = []
    if not filt:
        return conditions, params
    for key, cond in filt.items():
        if not isinstance(key, str) or key.startswith("$") or "." in key or not _SAFE_KEY.match(key):
            continue
        if isinstance(cond, dict) and cond and any(str(k).startswith("$") for k in cond.keys()):
            if "$in" in cond and isinstance(cond["$in"], list):
                vals = []
                ok = True
                for v in cond["$in"]:
                    tv, isnull = _to_text(v)
                    if isnull is None:
                        ok = False
                        break
                    if not isnull:
                        vals.append(tv)
                if ok and vals:
                    ph = ", ".join(f"${start_idx + len(params) + i}" for i in range(len(vals)))
                    conditions.append(f"({alias}.doc->>'{key}') IN ({ph})")
                    params.extend(vals)
            continue
        tv, isnull = _to_text(cond)
        if isnull is True:
            conditions.append(f"({alias}.doc->>'{key}') IS NULL")
        elif isnull is False:
            params.append(tv)
            conditions.append(f"({alias}.doc->>'{key}') = ${start_idx + len(params) - 1}")
    return conditions, params


def _sort_bucket(v):
    if v is MISSING or v is None:
        return 0
    if isinstance(v, bool):
        return 1
    if isinstance(v, (int, float)):
        return 1
    return 2


def apply_sort(docs: list[dict], sort_spec: list[tuple[str, int]]) -> list[dict]:
    result = list(docs)
    for field, direction in reversed(sort_spec):
        result.sort(key=lambda d: (_sort_bucket(get_path(d, field)), get_path(d, field) if get_path(d, field) not in (MISSING, None) else 0), reverse=direction == -1)
    return result


def apply_update(doc: dict, update: dict) -> dict:
    from .expr import set_path, unset_path

    doc = dict(doc)
    has_operator = any(str(k).startswith("$") for k in update.keys())
    if not has_operator:
        new_doc = dict(update)
        new_doc.setdefault("id", doc.get("id"))
        return new_doc
    for op, fields in update.items():
        if op == "$set":
            for k, v in fields.items():
                set_path(doc, k, v)
        elif op == "$inc":
            for k, v in fields.items():
                cur = get_path(doc, k)
                cur = cur if isinstance(cur, (int, float)) and not isinstance(cur, bool) else 0
                set_path(doc, k, cur + v)
        elif op == "$unset":
            for k in fields:
                unset_path(doc, k)
        elif op == "$push":
            for k, v in fields.items():
                arr = get_path(doc, k)
                if not isinstance(arr, list):
                    arr = []
                if isinstance(v, dict) and "$each" in v:
                    arr = arr + list(v["$each"])
                else:
                    arr = arr + [v]
                set_path(doc, k, arr)
        elif op == "$addToSet":
            for k, v in fields.items():
                arr = get_path(doc, k)
                if not isinstance(arr, list):
                    arr = []
                if v not in arr:
                    arr = arr + [v]
                set_path(doc, k, arr)
        elif op == "$setOnInsert":
            continue
    return doc


class _AsyncIter:
    def __init__(self, coro):
        self._coro = coro
        self._docs = None
        self._idx = 0

    def __aiter__(self):
        return self

    async def __anext__(self):
        if self._docs is None:
            self._docs = await self._coro
        if self._idx >= len(self._docs):
            raise StopAsyncIteration
        d = self._docs[self._idx]
        self._idx += 1
        return d


class PGCursor:
    def __init__(self, coll: "PGCollection", filt: Optional[dict], projection=None):
        self.coll = coll
        self.filt = filt
        self.projection = projection
        self._sort: Optional[list[tuple[str, int]]] = None
        self._skip = 0
        self._limit: Optional[int] = None

    def sort(self, key, direction=None):
        if isinstance(key, list):
            self._sort = [(k, d) for k, d in key]
        else:
            self._sort = [(key, direction if direction is not None else 1)]
        return self

    def skip(self, n):
        self._skip = n
        return self

    def limit(self, n):
        self._limit = n
        return self

    async def _resolve(self):
        return await self.coll._load_matching(self.filt, sort=self._sort, skip=self._skip, limit=self._limit)

    async def to_list(self, length=None):
        docs = await self._resolve()
        if length is not None:
            docs = docs[:length]
        return docs

    def __aiter__(self):
        return _AsyncIter(self._resolve())


class _AggCursor:
    def __init__(self, coll: "PGCollection", pipeline: list[dict]):
        self.coll = coll
        self.pipeline = pipeline

    async def _resolve(self):
        initial_filt = None
        if self.pipeline and isinstance(self.pipeline[0], dict) and "$match" in self.pipeline[0]:
            initial_filt = self.pipeline[0]["$match"]
        docs = await self.coll._load_all(initial_filt)
        return await run_pipeline(self.coll.db, self.pipeline, docs, {})

    async def to_list(self, length=None):
        docs = await self._resolve()
        return docs[:length] if length is not None else docs

    def __aiter__(self):
        return _AsyncIter(self._resolve())


class PGCollection:
    def __init__(self, db, name: str):
        self.db = db
        self.name = name
        self.table = f"doc_{name}"
        self._ensured = False

    async def _ensure_table(self):
        if self._ensured or self.table in self.db._ensured_tables:
            self._ensured = True
            return
        await self.db.execute(
            f'CREATE TABLE IF NOT EXISTS {self.table} ('
            f'row_seq BIGSERIAL PRIMARY KEY, id TEXT, tenant_id TEXT, '
            f'doc JSONB NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT now(), '
            f'updated_at TIMESTAMPTZ NOT NULL DEFAULT now())'
        )
        await self.db.execute(f'CREATE INDEX IF NOT EXISTS "ix_{self.table}_tenant" ON {self.table} (tenant_id)')
        await self.db.execute(f'CREATE UNIQUE INDEX IF NOT EXISTS "ux_{self.table}_id" ON {self.table} (id) WHERE id IS NOT NULL')
        self.db._ensured_tables.add(self.table)
        self._ensured = True

    async def _load_all(self, filt: Optional[dict] = None) -> list[dict]:
        await self._ensure_table()
        conditions, params = build_where("t", filt)
        where_sql = f" WHERE {' AND '.join(conditions)}" if conditions else ""
        rows = await self.db.fetch(f"SELECT doc FROM {self.table} t{where_sql} ORDER BY t.row_seq ASC", *params)
        return [r["doc"] for r in rows]

    async def _load_matching(self, filt, sort=None, skip=0, limit=None) -> list[dict]:
        docs = await self._load_all(filt)
        docs = [d for d in docs if matches(d, filt)]
        if sort:
            docs = apply_sort(docs, sort)
        if skip:
            docs = docs[skip:]
        if limit is not None:
            docs = docs[:limit]
        return docs

    def find(self, filt: Optional[dict] = None, projection=None) -> PGCursor:
        return PGCursor(self, filt, projection)

    async def find_one(self, filt: Optional[dict] = None, projection=None, sort=None) -> Optional[dict]:
        if sort:
            docs = await self._load_matching(filt, sort=sort, limit=1)
        else:
            docs = await self._load_matching(filt, limit=1)
        return docs[0] if docs else None

    async def count_documents(self, filt: Optional[dict] = None) -> int:
        docs = await self._load_matching(filt)
        return len(docs)

    async def estimated_document_count(self) -> int:
        return await self.count_documents(None)

    async def insert_one(self, doc: dict):
        await self._ensure_table()
        doc = dict(doc)
        doc.pop("_id", None)
        try:
            await self.db.execute(
                f"INSERT INTO {self.table} (id, tenant_id, doc) VALUES ($1, $2, $3)",
                doc.get("id"), doc.get("tenant_id"), doc,
            )
        except self.db.UniqueViolationError as e:
            raise DuplicateKeyError(str(e))
        return SimpleNamespace(inserted_id=doc.get("id"))

    async def insert_many(self, docs: list[dict]):
        ids = []
        for d in docs:
            r = await self.insert_one(d)
            ids.append(r.inserted_id)
        return SimpleNamespace(inserted_ids=ids)

    async def _select_for_update(self, conn, filt):
        await self._ensure_table()
        conditions, params = build_where("t", filt)
        where_sql = f" WHERE {' AND '.join(conditions)}" if conditions else ""
        rows = await conn.fetch(f"SELECT row_seq, doc FROM {self.table} t{where_sql} ORDER BY t.row_seq ASC FOR UPDATE", *params)
        result = [(r["row_seq"], r["doc"]) for r in rows]
        return [(rid, d) for rid, d in result if matches(d, filt)]

    async def _write_conn(self, conn, row_id, new_doc, is_insert=False):
        try:
            if is_insert:
                await conn.execute(
                    f"INSERT INTO {self.table} (id, tenant_id, doc) VALUES ($1, $2, $3)",
                    new_doc.get("id"), new_doc.get("tenant_id"), new_doc,
                )
            else:
                await conn.execute(
                    f"UPDATE {self.table} SET doc = $1, tenant_id = $2, updated_at = now() WHERE row_seq = $3",
                    new_doc, new_doc.get("tenant_id"), row_id,
                )
        except self.db.UniqueViolationError as e:
            raise DuplicateKeyError(str(e))

    def _build_upsert_doc(self, filt, update):
        new_doc: dict = {}
        if "$setOnInsert" in update:
            new_doc.update(update["$setOnInsert"])
        rest = {k: v for k, v in update.items() if k != "$setOnInsert"}
        new_doc = apply_update(new_doc, rest) if rest else new_doc
        for k, v in (filt or {}).items():
            if isinstance(k, str) and not k.startswith("$") and "." not in k and k not in new_doc and not isinstance(v, dict):
                new_doc[k] = v
        return new_doc

    async def update_one(self, filt, update, upsert=False):
        async with self.db.transaction() as conn:
            matched = await self._select_for_update(conn, filt)
            if not matched:
                if upsert:
                    new_doc = self._build_upsert_doc(filt, update)
                    await self._write_conn(conn, None, new_doc, is_insert=True)
                    return SimpleNamespace(matched_count=0, modified_count=0, upserted_id=new_doc.get("id"))
                return SimpleNamespace(matched_count=0, modified_count=0, upserted_id=None)
            row_id, doc = matched[0]
            new_doc = apply_update(doc, update)
            await self._write_conn(conn, row_id, new_doc)
            return SimpleNamespace(matched_count=1, modified_count=1, upserted_id=None)

    async def update_many(self, filt, update):
        async with self.db.transaction() as conn:
            matched = await self._select_for_update(conn, filt)
            for row_id, doc in matched:
                new_doc = apply_update(doc, update)
                await self._write_conn(conn, row_id, new_doc)
            return SimpleNamespace(matched_count=len(matched), modified_count=len(matched))

    async def find_one_and_update(self, filt, update, return_document=False, upsert=False, projection=None):
        async with self.db.transaction() as conn:
            matched = await self._select_for_update(conn, filt)
            after = bool(return_document)
            if not matched:
                if upsert:
                    new_doc = self._build_upsert_doc(filt, update)
                    await self._write_conn(conn, None, new_doc, is_insert=True)
                    return new_doc if after else None
                return None
            row_id, doc = matched[0]
            new_doc = apply_update(doc, update)
            await self._write_conn(conn, row_id, new_doc)
            return new_doc if after else doc

    async def replace_one(self, filt, replacement, upsert=False):
        async with self.db.transaction() as conn:
            matched = await self._select_for_update(conn, filt)
            new_doc = dict(replacement)
            if not matched:
                if upsert:
                    for k, v in (filt or {}).items():
                        if isinstance(k, str) and not k.startswith("$") and "." not in k and k not in new_doc:
                            new_doc[k] = v
                    await self._write_conn(conn, None, new_doc, is_insert=True)
                    return SimpleNamespace(matched_count=0, modified_count=0, upserted_id=new_doc.get("id"))
                return SimpleNamespace(matched_count=0, modified_count=0, upserted_id=None)
            row_id, _ = matched[0]
            new_doc.setdefault("id", matched[0][1].get("id"))
            await self._write_conn(conn, row_id, new_doc)
            return SimpleNamespace(matched_count=1, modified_count=1, upserted_id=None)

    async def distinct(self, field, filt=None):
        docs = await self._load_matching(filt)
        out = []
        for d in docs:
            v = get_path(d, field)
            if v is not MISSING and v not in out:
                out.append(v)
        return out

    async def find_one_and_delete(self, filt, projection=None):
        async with self.db.transaction() as conn:
            matched = await self._select_for_update(conn, filt)
            if not matched:
                return None
            row_id, doc = matched[0]
            await conn.execute(f"DELETE FROM {self.table} WHERE row_seq = $1", row_id)
            return doc

    async def delete_one(self, filt):
        async with self.db.transaction() as conn:
            matched = await self._select_for_update(conn, filt)
            if not matched:
                return SimpleNamespace(deleted_count=0)
            row_id, _ = matched[0]
            await conn.execute(f"DELETE FROM {self.table} WHERE row_seq = $1", row_id)
            return SimpleNamespace(deleted_count=1)

    async def delete_many(self, filt):
        async with self.db.transaction() as conn:
            matched = await self._select_for_update(conn, filt)
            for row_id, _ in matched:
                await conn.execute(f"DELETE FROM {self.table} WHERE row_seq = $1", row_id)
            return SimpleNamespace(deleted_count=len(matched))

    def aggregate(self, pipeline: list[dict], **kwargs):
        return _AggCursor(self, pipeline)

    async def create_index(self, keys, unique=False, sparse=False, expireAfterSeconds=None, partialFilterExpression=None, **kwargs):
        await self._ensure_table()
        if isinstance(keys, str):
            keys = [(keys, 1)]
        elif isinstance(keys, tuple):
            keys = [keys]
        field_names = [k[0] if isinstance(k, (tuple, list)) else k for k in keys]
        field_names = [f for f in field_names if _SAFE_KEY.match(f)]
        if not field_names:
            return
        if expireAfterSeconds is not None:
            self.db.register_ttl(self.name, field_names[0], expireAfterSeconds)
            return
        expr = ", ".join(f"(doc->>'{f}')" for f in field_names)
        if not unique:
            idx_name = f"idx_{self.table}_{'_'.join(field_names)}"[:63]
            try:
                await self.db.execute(f'CREATE INDEX IF NOT EXISTS "{idx_name}" ON {self.table} ({expr})')
            except Exception:
                pass
            return
        where_sql = ""
        if partialFilterExpression:
            conds = []
            for f, cond in partialFilterExpression.items():
                if isinstance(cond, dict) and cond.get("$type"):
                    conds.append(f"jsonb_typeof(doc->'{f}') = 'string'")
                else:
                    conds.append(f"(doc->>'{f}') IS NOT NULL")
            if conds:
                where_sql = " WHERE " + " AND ".join(conds)
        elif sparse:
            where_sql = " WHERE " + " AND ".join(f"(doc->>'{f}') IS NOT NULL" for f in field_names)
        idx_name = f"uq_{self.table}_{'_'.join(field_names)}"[:63]
        try:
            await self.db.execute(f'CREATE UNIQUE INDEX IF NOT EXISTS "{idx_name}" ON {self.table} ({expr}){where_sql}')
        except Exception as exc:
            import logging
            logging.getLogger("lista-da-vez.pg_shim").error(
                "Falha ao criar índice único %s (dados duplicados existentes?): %s", idx_name, exc
            )

    async def drop_index(self, name):
        try:
            await self.db.execute(f'DROP INDEX IF EXISTS "{name}"')
        except Exception:
            pass
