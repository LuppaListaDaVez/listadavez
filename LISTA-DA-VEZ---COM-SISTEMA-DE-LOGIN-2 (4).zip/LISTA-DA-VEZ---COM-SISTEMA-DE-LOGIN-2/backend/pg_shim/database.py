"""PGDatabase — pool assíncrono PostgreSQL (Supabase) com API de acesso
por atributo/índice compatível com `AsyncIOMotorDatabase` (db.<collection>)."""
from __future__ import annotations

import asyncio
import json
import logging
import os
from datetime import datetime

import asyncpg

from .collection import PGCollection

logger = logging.getLogger("lista-da-vez.pg_shim")


def _asyncpg_dsn() -> str:
    url = os.environ["DATABASE_URL"]
    return url.replace("postgresql+asyncpg://", "postgresql://")


async def _init_connection(conn):
    def _json_default(o):
        if isinstance(o, datetime):
            return o.isoformat()
        return str(o)

    await conn.set_type_codec(
        "jsonb",
        encoder=lambda v: json.dumps(v, default=_json_default),
        decoder=json.loads,
        schema="pg_catalog",
        format="text",
    )


class _TxnCtx:
    def __init__(self, pool):
        self.pool = pool
        self.conn = None
        self.tx = None

    async def __aenter__(self):
        self.conn = await self.pool.acquire()
        self.tx = self.conn.transaction()
        await self.tx.start()
        return self.conn

    async def __aexit__(self, exc_type, exc, tb):
        try:
            if exc_type:
                await self.tx.rollback()
            else:
                await self.tx.commit()
        finally:
            await self.pool.release(self.conn)
        return False


class PGDatabase:
    """Substituto de `AsyncIOMotorDatabase` persistindo em PostgreSQL/Supabase."""

    UniqueViolationError = asyncpg.exceptions.UniqueViolationError

    def __init__(self):
        self.pool: asyncpg.Pool | None = None
        self._collections: dict[str, PGCollection] = {}
        self._ensured_tables: set[str] = set()
        self._ttl_registry: list[tuple[str, str, int]] = []
        self._ttl_task: asyncio.Task | None = None

    async def connect(self):
        if self.pool is not None:
            return
        self.pool = await asyncpg.create_pool(
            dsn=_asyncpg_dsn(),
            min_size=2,
            max_size=15,
            statement_cache_size=0,
            command_timeout=30,
            init=_init_connection,
        )
        logger.info("PostgreSQL (Supabase) pool conectado.")

    async def disconnect(self):
        if self._ttl_task:
            self._ttl_task.cancel()
        if self.pool is not None:
            await self.pool.close()

    def __getattr__(self, name: str) -> PGCollection:
        return self[name]

    def __getitem__(self, name: str) -> PGCollection:
        if name not in self._collections:
            self._collections[name] = PGCollection(self, name)
        return self._collections[name]

    async def execute(self, sql: str, *params):
        async with self.pool.acquire() as conn:
            return await conn.execute(sql, *params)

    async def fetch(self, sql: str, *params):
        async with self.pool.acquire() as conn:
            return await conn.fetch(sql, *params)

    def transaction(self) -> _TxnCtx:
        return _TxnCtx(self.pool)

    def register_ttl(self, collection: str, field: str, seconds: int):
        self._ttl_registry.append((collection, field, seconds))

    async def _sweep_ttls_once(self):
        for coll, field, seconds in list(self._ttl_registry):
            table = f"doc_{coll}"
            try:
                if seconds == 0:
                    await self.execute(
                        f"DELETE FROM {table} WHERE (doc->>'{field}') IS NOT NULL "
                        f"AND (doc->>'{field}')::timestamptz < now()"
                    )
                else:
                    await self.execute(
                        f"DELETE FROM {table} WHERE (doc->>'{field}') IS NOT NULL "
                        f"AND (doc->>'{field}')::timestamptz + interval '{int(seconds)} seconds' < now()"
                    )
            except Exception as exc:  # noqa: BLE001 — best-effort, nunca derruba o app
                logger.debug("TTL sweep falhou para %s.%s: %s", coll, field, exc)

    async def start_ttl_sweeper(self, interval_seconds: int = 300):
        async def _loop():
            while True:
                await asyncio.sleep(interval_seconds)
                await self._sweep_ttls_once()

        self._ttl_task = asyncio.create_task(_loop())


_db_singleton = PGDatabase()


def get_pg_database() -> PGDatabase:
    return _db_singleton
