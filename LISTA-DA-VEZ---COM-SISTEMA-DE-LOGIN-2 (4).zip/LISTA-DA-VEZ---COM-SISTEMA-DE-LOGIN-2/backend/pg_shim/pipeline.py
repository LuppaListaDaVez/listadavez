"""Executor de pipeline de agregação estilo MongoDB, em Python puro,
operando sobre listas de dicts já carregadas do PostgreSQL."""
from __future__ import annotations

from typing import Any

from .expr import eval_expr, matches, get_path, MISSING


def _flatten_numeric(v: Any) -> list:
    """Achata um valor (possivelmente lista, por causa de caminho mapeado sobre array) em números."""
    if isinstance(v, list):
        out = []
        for item in v:
            out.extend(_flatten_numeric(item))
        return out
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return [v]
    return []


def _accumulate(op: str, expr: Any, docs: list[dict], variables: dict) -> Any:
    if op == "$sum":
        total = 0
        for d in docs:
            v = eval_expr(expr, d, variables)
            total += sum(_flatten_numeric(v))
        return total
    if op == "$avg":
        vals = []
        for d in docs:
            vals.extend(_flatten_numeric(eval_expr(expr, d, variables)))
        return (sum(vals) / len(vals)) if vals else None
    if op == "$min":
        vals = []
        for d in docs:
            v = eval_expr(expr, d, variables)
            vals.extend(v if isinstance(v, list) else [v])
        vals = [v for v in vals if v is not None]
        return min(vals) if vals else None
    if op == "$max":
        vals = []
        for d in docs:
            v = eval_expr(expr, d, variables)
            vals.extend(v if isinstance(v, list) else [v])
        vals = [v for v in vals if v is not None]
        return max(vals) if vals else None
    if op == "$first":
        return eval_expr(expr, docs[0], variables) if docs else None
    if op == "$last":
        return eval_expr(expr, docs[-1], variables) if docs else None
    if op == "$push":
        return [eval_expr(expr, d, variables) for d in docs]
    if op == "$addToSet":
        out = []
        for d in docs:
            v = eval_expr(expr, d, variables)
            if v not in out:
                out.append(v)
        return out
    if op == "$count":
        return len(docs)
    return None


def _group_key(doc: dict, id_expr: Any, variables: dict) -> Any:
    val = eval_expr(id_expr, doc, variables)
    if isinstance(val, dict):
        return tuple(sorted(val.items(), key=lambda kv: kv[0]))
    if isinstance(val, list):
        return tuple(val)
    return val


def _stage_group(docs: list[dict], spec: dict, variables: dict) -> list[dict]:
    id_expr = spec.get("_id")
    groups: dict[Any, list[dict]] = {}
    group_id_value: dict[Any, Any] = {}
    for d in docs:
        key = _group_key(d, id_expr, variables)
        groups.setdefault(key, []).append(d)
        if key not in group_id_value:
            group_id_value[key] = eval_expr(id_expr, d, variables)
    out = []
    for key, members in groups.items():
        row = {"_id": group_id_value[key]}
        for field, accexpr in spec.items():
            if field == "_id":
                continue
            if isinstance(accexpr, dict) and len(accexpr) == 1:
                op, expr = next(iter(accexpr.items()))
                row[field] = _accumulate(op, expr, members, variables)
        out.append(row)
    return out


def _stage_project(docs: list[dict], spec: dict, variables: dict, keep_mode: bool) -> list[dict]:
    out = []
    for d in docs:
        if keep_mode:
            new_doc = {}
            explicit_exclude = all(v in (0, False) for v in spec.values() if not isinstance(v, dict)) and any(
                v in (0, False) for v in spec.values() if not isinstance(v, dict)
            )
            if explicit_exclude and not any(isinstance(v, dict) or v in (1, True) for v in spec.values()):
                new_doc = dict(d)
                for k, v in spec.items():
                    if v in (0, False):
                        new_doc.pop(k, None)
            else:
                for k, v in spec.items():
                    if isinstance(v, dict) or (not isinstance(v, bool) and v not in (0, 1)):
                        new_doc[k] = eval_expr(v, d, variables)
                    elif v in (1, True):
                        val = get_path(d, k)
                        if val is not MISSING:
                            new_doc[k] = val
        else:
            new_doc = dict(d)
            for k, v in spec.items():
                new_doc[k] = eval_expr(v, d, variables)
        out.append(new_doc)
    return out


def _stage_sort(docs: list[dict], spec: dict) -> list[dict]:
    keys = list(spec.items())

    def sort_key(d):
        vals = []
        for k, direction in keys:
            v = get_path(d, k)
            if v is MISSING or v is None:
                v = ""
            vals.append(v)
        return vals

    result = list(docs)
    for k, direction in reversed(keys):
        result.sort(key=lambda d, k=k: (get_path(d, k) is MISSING or get_path(d, k) is None, get_path(d, k) if get_path(d, k) is not MISSING else 0), reverse=direction == -1)
    return result


def _stage_unwind(docs: list[dict], spec: Any) -> list[dict]:
    if isinstance(spec, str):
        path = spec.lstrip("$")
        preserve = False
    else:
        path = spec.get("path", "").lstrip("$")
        preserve = bool(spec.get("preserveNullAndEmptyArrays"))
    out = []
    for d in docs:
        arr = get_path(d, path)
        if not isinstance(arr, list) or not arr:
            if preserve:
                nd = dict(d)
                nd[path] = None
                out.append(nd)
            continue
        for item in arr:
            nd = dict(d)
            nd[path] = item
            out.append(nd)
    return out


def _stage_bucket(docs: list[dict], spec: dict, variables: dict) -> list[dict]:
    group_by = spec.get("groupBy")
    boundaries = spec.get("boundaries", [])
    default = spec.get("default")
    output = spec.get("output", {"count": {"$sum": 1}})
    buckets: dict[Any, list[dict]] = {}
    for d in docs:
        v = eval_expr(group_by, d, variables)
        bucket_key = default
        for i in range(len(boundaries) - 1):
            if v is not None and boundaries[i] <= v < boundaries[i + 1]:
                bucket_key = boundaries[i]
                break
        buckets.setdefault(bucket_key, []).append(d)
    out = []
    for key, members in buckets.items():
        row = {"_id": key}
        for field, accexpr in output.items():
            op, expr = next(iter(accexpr.items()))
            row[field] = _accumulate(op, expr, members, variables)
        out.append(row)
    return out


async def run_pipeline(db, pipeline: list[dict], docs: list[dict], variables: dict | None = None) -> list[dict]:
    variables = variables or {}
    current = docs
    for stage in pipeline:
        (stage_name, spec), = stage.items()
        if stage_name == "$match":
            current = [d for d in current if matches(d, spec, variables)]
        elif stage_name == "$group":
            current = _stage_group(current, spec, variables)
        elif stage_name in ("$project",):
            current = _stage_project(current, spec, variables, keep_mode=True)
        elif stage_name == "$addFields":
            current = _stage_project(current, spec, variables, keep_mode=False)
        elif stage_name == "$sort":
            current = _stage_sort(current, spec)
        elif stage_name == "$limit":
            current = current[: int(spec)]
        elif stage_name == "$skip":
            current = current[int(spec):]
        elif stage_name == "$unwind":
            current = _stage_unwind(current, spec)
        elif stage_name == "$bucket":
            current = _stage_bucket(current, spec, variables)
        elif stage_name == "$count":
            current = [{spec: len(current)}]
        elif stage_name == "$replaceRoot":
            current = [eval_expr(spec.get("newRoot"), d, variables) for d in current]
        elif stage_name == "$facet":
            row = {}
            for name, subpipeline in spec.items():
                row[name] = await run_pipeline(db, subpipeline, current, variables)
            current = [row]
        elif stage_name == "$lookup":
            current = await _stage_lookup(db, current, spec, variables)
        else:
            continue
    return current


async def _stage_lookup(db, docs: list[dict], spec: dict, variables: dict) -> list[dict]:
    from_coll = spec.get("from")
    as_field = spec.get("as")
    out = []
    if "pipeline" in spec:
        let_spec = spec.get("let", {})
        foreign_docs = await db[from_coll]._load_all()
        for d in docs:
            local_vars = {**variables, **{k: eval_expr(v, d, variables) for k, v in let_spec.items()}}
            result = await run_pipeline(db, spec["pipeline"], list(foreign_docs), local_vars)
            nd = dict(d)
            nd[as_field] = result
            out.append(nd)
        return out
    local_field = spec.get("localField")
    foreign_field = spec.get("foreignField")
    foreign_docs = await db[from_coll]._load_all()
    for d in docs:
        local_val = get_path(d, local_field)
        matched = [fd for fd in foreign_docs if get_path(fd, foreign_field) == local_val]
        nd = dict(d)
        nd[as_field] = matched
        out.append(nd)
    return out
