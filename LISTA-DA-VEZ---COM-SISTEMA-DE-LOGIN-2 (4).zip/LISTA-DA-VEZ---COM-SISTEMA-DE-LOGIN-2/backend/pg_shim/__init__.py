"""Motor/PyMongo-compatible async driver backed by PostgreSQL (Supabase).

Mantém a mesma superfície de API usada em todo o código de negócio
(find_one, find, insert_one, update_one, find_one_and_update, aggregate, ...)
para que nenhuma rota/serviço precise ser alterada. Os documentos continuam
sendo dicts Python; a persistência física agora é PostgreSQL (coluna JSONB).
"""
