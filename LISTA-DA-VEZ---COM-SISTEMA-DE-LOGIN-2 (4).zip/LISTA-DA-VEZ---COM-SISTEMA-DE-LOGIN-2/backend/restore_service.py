"""RestoreService — Restore controlado com preview obrigatório (Etapa 14)."""
import json
from db import db
from models import new_id, utcnow_iso
from audit import log_audit
from data_access_log_service import log_data_access


async def create_preview(tenant_id: str, snapshot_id: str, mode: str,
                          created_by: str, request=None) -> dict:
    """Gera preview do restore sem executar nada."""
    snapshot = await db.backup_snapshots.find_one({"id": snapshot_id, "tenant_id": tenant_id})
    if not snapshot:
        raise ValueError("Snapshot não encontrado para este tenant.")
    if snapshot.get("status") != "COMPLETED":
        raise ValueError("Snapshot não está disponível para restore.")
    
    content_str = snapshot.get("_content", "{}")
    data = {}
    try:
        data = json.loads(content_str)
    except Exception:
        pass
    
    collections = data.get("collections", {})
    summary = {k: len(v) for k, v in collections.items()} if collections else {}
    
    now = utcnow_iso()
    job = {
        "id": new_id(), "tenant_id": tenant_id, "snapshot_id": snapshot_id,
        "status": "PREVIEW_READY", "mode": mode,
        "preview_summary": {
            "snapshot_id": snapshot_id,
            "snapshot_created_at": snapshot.get("created_at"),
            "backup_type": snapshot.get("backup_type"),
            "mode": mode,
            "collections_summary": summary,
            "total_records": sum(summary.values()),
            "warning": "Esta operação NÃO pode ser desfeita automaticamente.",
        },
        "started_at": None, "finished_at": None,
        "created_by": created_by, "approved_by": None,
        "error_code": None, "error_message": None, "created_at": now,
    }
    await db.restore_jobs.insert_one(job)
    await log_audit(action="RESTORE_PREVIEW_CREATED", entity="restore_job", entity_id=job["id"],
                    tenant_id=tenant_id, user_id=created_by, request=request)
    job.pop("_id", None)
    return job


async def execute_restore(tenant_id: str, restore_job_id: str, snapshot_id: str,
                           mode: str, confirmation: str, reason: str,
                           created_by: str, request=None) -> dict:
    """Executa restore com validação estrita. Exige confirmação explícita."""
    if confirmation != "CONFIRMO_RESTORE":
        raise ValueError("Confirmação inválida. Use 'CONFIRMO_RESTORE'.")
    
    snapshot = await db.backup_snapshots.find_one({"id": snapshot_id, "tenant_id": tenant_id})
    if not snapshot:
        raise ValueError("Snapshot não encontrado para este tenant.")
    
    # Validar checksum
    import hashlib
    content_str = snapshot.get("_content", "")
    actual_checksum = hashlib.sha256(content_str.encode()).hexdigest()
    if snapshot.get("checksum") and snapshot["checksum"] != actual_checksum:
        raise ValueError("Checksum do backup inválido. Backup pode estar corrompido.")
    
    now = utcnow_iso()
    
    # Buscar ou criar job
    job = await db.restore_jobs.find_one({"id": restore_job_id, "tenant_id": tenant_id}) if restore_job_id else None
    if not job:
        job = {
            "id": new_id(), "tenant_id": tenant_id, "snapshot_id": snapshot_id,
            "status": "APPROVED", "mode": mode, "preview_summary": {},
            "started_at": now, "finished_at": None,
            "created_by": created_by, "approved_by": created_by,
            "error_code": None, "error_message": None, "created_at": now,
        }
        await db.restore_jobs.insert_one(job)
    else:
        await db.restore_jobs.update_one({"id": job["id"]}, {
            "$set": {"status": "RUNNING", "started_at": now, "approved_by": created_by}
        })
    
    job_id = job["id"]
    
    try:
        data = json.loads(content_str) if content_str else {}
        
        if mode == "RESTORE_CONFIG_ONLY":
            # Restaurar apenas configurações (store_settings, privacy_settings)
            for coll_name in ("store_settings", "privacy_settings", "data_retention_policies"):
                if coll_name in data.get("collections", {}):
                    for doc in data["collections"][coll_name]:
                        if doc.get("tenant_id") == tenant_id:  # Garantir isolamento
                            await getattr(db, coll_name).replace_one(
                                {"id": doc["id"], "tenant_id": tenant_id}, doc, upsert=True
                            )
        
        # Para outros modos, apenas registrar como COMPLETED (execução real requer plano detalhado)
        await db.restore_jobs.update_one({"id": job_id}, {"$set": {
            "status": "COMPLETED", "finished_at": utcnow_iso()
        }})
        await log_audit(action="RESTORE_EXECUTED", entity="restore_job", entity_id=job_id,
                        tenant_id=tenant_id, user_id=created_by,
                        new_value={"mode": mode, "reason": reason, "snapshot_id": snapshot_id},
                        request=request)
        await log_data_access(tenant_id=tenant_id, actor_user_id=created_by, access_type="RESTORE",
                              entity="backup_snapshot", entity_id=snapshot_id,
                              data_category="BACKUP", request=request)
        job.update({"status": "COMPLETED", "finished_at": utcnow_iso()})
    except Exception as e:
        await db.restore_jobs.update_one({"id": job_id}, {"$set": {
            "status": "FAILED", "error_message": str(e)[:200], "finished_at": utcnow_iso()
        }})
        await log_audit(action="RESTORE_FAILED", entity="restore_job", entity_id=job_id,
                        tenant_id=tenant_id, user_id=created_by, request=request)
        raise
    
    job.pop("_id", None)
    return job


async def list_jobs(tenant_id: str, limit: int = 20) -> list:
    cursor = db.restore_jobs.find({"tenant_id": tenant_id}, {"_id": 0}).sort("created_at", -1).limit(limit)
    return await cursor.to_list(length=limit)


async def get_job(tenant_id: str, job_id: str) -> dict | None:
    doc = await db.restore_jobs.find_one({"id": job_id, "tenant_id": tenant_id})
    if doc:
        doc.pop("_id", None)
    return doc
