"""Observabilidade Operacional — P1.

Endpoint protegido: GET /api/admin/observability
Apenas Super Admin.

Métricas incluídas:
- Request stats (total, por status, latência)
- Logins falhos
- Rate limits
- Idempotência conflicts
- WebSocket connections
- Outbox stats
- Cache stats
- Queue sizes
- Vendas/min
- DB response time
"""
import asyncio
import time
import logging
from collections import defaultdict
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger("lista-da-vez.observability")


class OperationalMetrics:
    """Collector em memória de métricas operacionais."""

    def __init__(self):
        self._lock = asyncio.Lock()
        self.total_requests = 0
        self.requests_by_status: dict = defaultdict(int)
        self.latencies: list = []  # últimas 1000 latências (ms)
        self._latency_max = 1000
        self.login_failures = 0
        self.rate_limit_hits = 0
        self.idempotency_conflicts = 0
        self.sales_created = 0
        self.attendances_started = 0
        self.attendances_finished = 0
        self._start_time = time.monotonic()

    def record_request(self, status_code: int, duration_ms: int):
        self.total_requests += 1
        self.requests_by_status[str(status_code)] += 1
        self.latencies.append(duration_ms)
        if len(self.latencies) > self._latency_max:
            self.latencies = self.latencies[-self._latency_max:]

    def record_login_failure(self):
        self.login_failures += 1

    def record_rate_limit(self):
        self.rate_limit_hits += 1

    def record_idempotency_conflict(self):
        self.idempotency_conflicts += 1

    def record_sale_created(self):
        self.sales_created += 1

    def record_attendance(self, event: str):
        if event == "STARTED":
            self.attendances_started += 1
        elif event == "FINISHED":
            self.attendances_finished += 1

    def _percentile(self, lats: list, p: float) -> float:
        if not lats:
            return 0.0
        sorted_lats = sorted(lats)
        idx = int(len(sorted_lats) * p / 100)
        return sorted_lats[min(idx, len(sorted_lats) - 1)]

    def snapshot(self) -> dict:
        lats = list(self.latencies)
        uptime = time.monotonic() - self._start_time
        return {
            "uptime_seconds": round(uptime),
            "requests": {
                "total": self.total_requests,
                "by_status": dict(self.requests_by_status),
                "rps": round(self.total_requests / max(uptime, 1), 2),
            },
            "latency_ms": {
                "avg": round(sum(lats) / len(lats)) if lats else 0,
                "p50": round(self._percentile(lats, 50)),
                "p95": round(self._percentile(lats, 95)),
                "p99": round(self._percentile(lats, 99)),
                "max": max(lats) if lats else 0,
            },
            "errors": {
                "4xx": sum(v for k, v in self.requests_by_status.items() if k.startswith("4")),
                "5xx": sum(v for k, v in self.requests_by_status.items() if k.startswith("5")),
                "login_failures": self.login_failures,
                "rate_limit_hits": self.rate_limit_hits,
                "idempotency_conflicts": self.idempotency_conflicts,
            },
            "business": {
                "sales_created": self.sales_created,
                "attendances_started": self.attendances_started,
                "attendances_finished": self.attendances_finished,
            },
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }


# Singleton global
metrics = OperationalMetrics()
