"""Endpoints de Privacidade / LGPD — Etapa 14."""
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from security import resolve_tenant_context
from feature_guard import require_feature
from permissions import (
    ROLE_PERMISSIONS,
    P_PRIVACY_REQUESTS_VIEW, P_PRIVACY_REQUESTS_CREATE, P_PRIVACY_REQUESTS_UPDATE,
    P_PRIVACY_REQUESTS_ASSIGN, P_PRIVACY_REQUESTS_RESOLVE, P_PRIVACY_REQUESTS_EXPORT,
    P_PRIVACY_REQUESTS_ANONYMIZE,
    P_PRIVACY_CONSENTS_VIEW, P_PRIVACY_CONSENTS_MANAGE,
    P_PRIVACY_DATA_MAP_VIEW, P_PRIVACY_DATA_MAP_MANAGE,
    P_PRIVACY_SETTINGS_VIEW, P_PRIVACY_SETTINGS_UPDATE,
    P_PRIVACY_ACCESS_LOGS_VIEW,
    P_DATA_SUBJECT_EXPORT, P_DATA_SUBJECT_EXPORT_SELF, P_DATA_SUBJECT_ANONYMIZE,
)
import privacy_request_service as pr_svc
import consent_service as cs_svc
import data_subject_export_service as export_svc
import anonymization_service as anon_svc
import privacy_settings_service as ps_svc
import data_access_log_service as dal_svc
from db import db
from models import new_id, utcnow_iso

router = APIRouter(prefix="/tenants/{tenant_slug}", tags=["privacy"])


def _has(role, *perms):
    return any(p in ROLE_PERMISSIONS.get(role, []) for p in perms)


# ─── Solicitações LGPD ───────────────────────────────────────────────────────

class PrivacyRequestCreate(BaseModel):
    request_type: str = "ACCESS"
    requester_type: str = "SELF"
    data_subject_type: str = "USER"
    data_subject_user_id: Optional[str] = None
    data_subject_customer_ref: Optional[str] = None
    data_subject_name: Optional[str] = None
    data_subject_email: Optional[str] = None
    description: str = ""
    priority: str = "NORMAL"
    due_at: Optional[str] = None


class PrivacyRequestUpdate(BaseModel):
    status: Optional[str] = None
    notes: Optional[str] = ""
    assigned_to: Optional[str] = None


@router.get("/privacy/requests")
async def list_requests(
    status: Optional[str] = None,
    request_type: Optional[str] = None,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "lgpd")
    role = ctx["membership"]["role"]
    if not _has(role, P_PRIVACY_REQUESTS_VIEW, P_PRIVACY_REQUESTS_CREATE):
        raise HTTPException(403, "Sem permissão.")
    return await pr_svc.list_requests(
        ctx["tenant"]["id"], ctx["user"]["id"], role, status, request_type
    )


@router.post("/privacy/requests")
async def create_request(
    payload: PrivacyRequestCreate,
    request: Request,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "lgpd")
    if not _has(ctx["membership"]["role"], P_PRIVACY_REQUESTS_CREATE):
        raise HTTPException(403, "Sem permissão.")
    return await pr_svc.create_request(
        ctx["tenant"]["id"], payload.model_dump(), ctx["user"]["id"], request
    )


@router.get("/privacy/requests/stats")
async def get_stats(ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "lgpd")
    if not _has(ctx["membership"]["role"], P_PRIVACY_REQUESTS_VIEW):
        raise HTTPException(403, "Sem permissão.")
    return await pr_svc.get_stats(ctx["tenant"]["id"])


@router.get("/privacy/requests/{request_id}")
async def get_request(
    request_id: str,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "lgpd")
    if not _has(ctx["membership"]["role"], P_PRIVACY_REQUESTS_VIEW, P_PRIVACY_REQUESTS_CREATE):
        raise HTTPException(403, "Sem permissão.")
    doc = await pr_svc.get_request(
        ctx["tenant"]["id"], request_id, ctx["user"]["id"], ctx["membership"]["role"]
    )
    if not doc:
        raise HTTPException(404, "Solicitação não encontrada.")
    return doc


@router.put("/privacy/requests/{request_id}")
async def update_request(
    request_id: str,
    payload: PrivacyRequestUpdate,
    request: Request,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "lgpd")
    if not _has(ctx["membership"]["role"], P_PRIVACY_REQUESTS_UPDATE, P_PRIVACY_REQUESTS_RESOLVE):
        raise HTTPException(403, "Sem permissão.")
    doc = await pr_svc.update_status(
        ctx["tenant"]["id"], request_id,
        payload.status, ctx["user"]["id"], payload.notes or "", request
    )
    if not doc:
        raise HTTPException(404, "Solicitação não encontrada.")
    return doc


@router.post("/privacy/requests/{request_id}/assign")
async def assign_request(
    request_id: str,
    body: dict,
    request: Request,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "lgpd")
    if not _has(ctx["membership"]["role"], P_PRIVACY_REQUESTS_ASSIGN):
        raise HTTPException(403, "Sem permissão.")
    doc = await pr_svc.assign_request(
        ctx["tenant"]["id"], request_id, body.get("assigned_to"),
        ctx["user"]["id"], request
    )
    if not doc:
        raise HTTPException(404, "Solicitação não encontrada.")
    return doc


@router.post("/privacy/requests/{request_id}/resolve")
async def resolve_request(
    request_id: str,
    body: dict,
    request: Request,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "lgpd")
    if not _has(ctx["membership"]["role"], P_PRIVACY_REQUESTS_RESOLVE):
        raise HTTPException(403, "Sem permissão.")
    doc = await pr_svc.update_status(
        ctx["tenant"]["id"], request_id, "RESOLVED",
        ctx["user"]["id"], body.get("notes", ""), request
    )
    if not doc:
        raise HTTPException(404, "Solicitação não encontrada.")
    return doc


@router.post("/privacy/requests/{request_id}/reject")
async def reject_request(
    request_id: str,
    body: dict,
    request: Request,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "lgpd")
    if not _has(ctx["membership"]["role"], P_PRIVACY_REQUESTS_RESOLVE):
        raise HTTPException(403, "Sem permissão.")
    doc = await pr_svc.update_status(
        ctx["tenant"]["id"], request_id, "REJECTED",
        ctx["user"]["id"], body.get("reason", ""), request
    )
    if not doc:
        raise HTTPException(404, "Solicitação não encontrada.")
    return doc


# ─── Consentimentos ──────────────────────────────────────────────────────────

class ConsentCreate(BaseModel):
    subject_type: str = "USER"
    subject_user_id: Optional[str] = None
    purpose: str = "ACCOUNT_ACCESS"
    legal_basis: str = "CONSENT"
    version: str = "1.0"
    source: str = "SYSTEM"
    expires_at: Optional[str] = None


@router.get("/privacy/consents")
async def list_consents(
    subject_user_id: Optional[str] = None,
    status: Optional[str] = None,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "lgpd")
    if not _has(ctx["membership"]["role"], P_PRIVACY_CONSENTS_VIEW, P_PRIVACY_CONSENTS_MANAGE):
        raise HTTPException(403, "Sem permissão.")
    return await cs_svc.list_consents(ctx["tenant"]["id"], subject_user_id, status)


@router.post("/privacy/consents")
async def create_consent(
    payload: ConsentCreate,
    request: Request,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "lgpd")
    if not _has(ctx["membership"]["role"], P_PRIVACY_CONSENTS_MANAGE):
        raise HTTPException(403, "Sem permissão.")
    return await cs_svc.create_consent(
        ctx["tenant"]["id"], payload.model_dump(), ctx["user"]["id"], request
    )


@router.post("/privacy/consents/{consent_id}/withdraw")
async def withdraw_consent(
    consent_id: str,
    request: Request,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "lgpd")
    if not _has(ctx["membership"]["role"], P_PRIVACY_CONSENTS_MANAGE):
        raise HTTPException(403, "Sem permissão.")
    doc = await cs_svc.withdraw_consent(
        ctx["tenant"]["id"], consent_id, ctx["user"]["id"], request
    )
    if not doc:
        raise HTTPException(404, "Consentimento não encontrado.")
    return doc


@router.get("/privacy/consent-events")
async def list_consent_events(ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "lgpd")
    if not _has(ctx["membership"]["role"], P_PRIVACY_CONSENTS_VIEW, P_PRIVACY_CONSENTS_MANAGE):
        raise HTTPException(403, "Sem permissão.")
    return await cs_svc.list_consent_events(ctx["tenant"]["id"])


# ─── Mapa de Dados ────────────────────────────────────────────────────────────

@router.get("/privacy/data-map")
async def get_data_map(ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "lgpd")
    if not _has(ctx["membership"]["role"], P_PRIVACY_DATA_MAP_VIEW, P_PRIVACY_DATA_MAP_MANAGE):
        raise HTTPException(403, "Sem permissão.")
    cursor = db.data_processing_records.find(
        {"tenant_id": ctx["tenant"]["id"]}, {"_id": 0}
    )
    return await cursor.to_list(length=100)


# ─── Logs de Acesso a Dados Pessoais ─────────────────────────────────────────

@router.get("/privacy/access-logs")
async def list_access_logs(
    data_category: Optional[str] = None,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "lgpd")
    if not _has(ctx["membership"]["role"], P_PRIVACY_ACCESS_LOGS_VIEW):
        raise HTTPException(403, "Sem permissão.")
    await dal_svc.log_data_access(
        tenant_id=ctx["tenant"]["id"], actor_user_id=ctx["user"]["id"],
        actor_role=ctx["membership"]["role"], access_type="VIEW",
        entity="data_access_logs", data_category=data_category or "USER_ACCOUNT",
    )
    return await dal_svc.list_logs(ctx["tenant"]["id"], data_category=data_category)


# ─── Exportação de Dados do Titular ──────────────────────────────────────────

@router.get("/privacy/data-exports")
async def list_exports(ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "lgpd")
    if not _has(ctx["membership"]["role"], P_DATA_SUBJECT_EXPORT, P_DATA_SUBJECT_EXPORT_SELF):
        raise HTTPException(403, "Sem permissão.")
    return await export_svc.list_exports(ctx["tenant"]["id"])


@router.post("/privacy/data-exports")
async def create_export(
    body: dict,
    request: Request,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "lgpd")
    subject_user_id = body.get("subject_user_id", ctx["user"]["id"])
    role = ctx["membership"]["role"]
    # SELLER só pode exportar próprios dados
    if role == "SELLER" and subject_user_id != ctx["user"]["id"]:
        raise HTTPException(403, "Sellers só podem exportar dados próprios.")
    if not _has(role, P_DATA_SUBJECT_EXPORT, P_DATA_SUBJECT_EXPORT_SELF):
        raise HTTPException(403, "Sem permissão.")
    return await export_svc.create_export(
        ctx["tenant"]["id"], subject_user_id, ctx["user"]["id"],
        body.get("file_format", "JSON"), request
    )


@router.get("/privacy/data-exports/{export_id}")
async def get_export(export_id: str, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "lgpd")
    doc = await export_svc.get_export(ctx["tenant"]["id"], export_id)
    if not doc:
        raise HTTPException(404, "Exportação não encontrada.")
    return doc


@router.get("/privacy/data-exports/{export_id}/download")
async def download_export(
    export_id: str,
    request: Request,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "lgpd")
    if not _has(ctx["membership"]["role"], P_DATA_SUBJECT_EXPORT, P_DATA_SUBJECT_EXPORT_SELF):
        raise HTTPException(403, "Sem permissão.")
    result = await export_svc.download_export(
        ctx["tenant"]["id"], export_id, ctx["user"]["id"], request
    )
    if not result:
        raise HTTPException(404, "Exportação não disponível ou expirada.")
    return result


# ─── Configurações de Privacidade ─────────────────────────────────────────────

@router.get("/settings/data-protection")
async def get_privacy_settings(ctx: dict = Depends(resolve_tenant_context)):
    if not _has(ctx["membership"]["role"], P_PRIVACY_SETTINGS_VIEW, P_PRIVACY_SETTINGS_UPDATE):
        raise HTTPException(403, "Sem permissão.")
    return await ps_svc.get_settings(ctx["tenant"]["id"])


@router.put("/settings/data-protection")
async def update_privacy_settings(
    body: dict,
    request: Request,
    ctx: dict = Depends(resolve_tenant_context),
):
    if not _has(ctx["membership"]["role"], P_PRIVACY_SETTINGS_UPDATE):
        raise HTTPException(403, "Sem permissão.")
    return await ps_svc.upsert_settings(
        ctx["tenant"]["id"], body, ctx["user"]["id"], request
    )
