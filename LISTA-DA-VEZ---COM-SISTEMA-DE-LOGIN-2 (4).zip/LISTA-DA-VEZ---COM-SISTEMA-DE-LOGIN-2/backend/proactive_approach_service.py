"""ProactiveApproachService — Etapa 11: Abordagem Proativa."""
from typing import Optional, Dict, Any, List
from fastapi import HTTPException

from db import db
from models import new_id, utcnow_iso
from audit import log_audit
from realtime import event_bus
from permission_service import can_access_store, get_accessible_store_ids
from permissions import (
    P_PROACTIVITY_CREATE_SELF, P_PROACTIVITY_CREATE_ANY,
    P_PROACTIVITY_UPDATE_SELF, P_PROACTIVITY_UPDATE_ANY,
    P_PROACTIVITY_CANCEL_SELF, P_PROACTIVITY_CANCEL_ANY,
    P_PROACTIVITY_CLOSE_NO_SALE_SELF, P_PROACTIVITY_CLOSE_NO_SALE_ANY,
    P_PROACTIVITY_CONVERT_TO_ATTENDANCE_SELF, P_PROACTIVITY_CONVERT_TO_ATTENDANCE_ANY,
    P_PROACTIVITY_CONVERT_TO_SALE_SELF, P_PROACTIVITY_CONVERT_TO_SALE_ANY,
    ROLE_PERMISSIONS,
)


def _has_perm(role: str, perm: str) -> bool:
    return perm in ROLE_PERMISSIONS.get(role, [])


async def _get_seller_profile(tenant_id: str, user_id: str) -> Optional[dict]:
    sp = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": user_id})
    if sp:
        sp.pop("_id", None)
    return sp


async def _get_approach_or_404(tenant_id: str, approach_id: str) -> dict:
    doc = await db.proactive_approaches.find_one({"tenant_id": tenant_id, "id": approach_id})
    if not doc:
        raise HTTPException(status_code=404, detail="Abordagem não encontrada.")
    doc.pop("_id", None)
    return doc


async def _check_store_access(membership: dict, store_id: str):
    if not can_access_store(membership, store_id):
        raise HTTPException(status_code=403, detail="Sem acesso a esta unidade.")


async def _resolve_seller_context(
    tenant_id: str,
    membership: dict,
    actor_user_id: str,
    seller_id: Optional[str],
    store_id: str,
) -> str:
    """Retorna seller_id resolvido baseado no role e dados informados."""
    role = membership["role"]
    if role == "SELLER":
        own = await _get_seller_profile(tenant_id, actor_user_id)
        if not own:
            raise HTTPException(status_code=400, detail="Perfil de vendedor não encontrado.")
        if seller_id and seller_id != own["id"]:
            raise HTTPException(status_code=403, detail="Vendedor não pode criar abordagem para outro vendedor.")
        return own["id"]
    # Managers podem criar para qualquer vendedor na loja
    if seller_id:
        sp = await db.seller_profiles.find_one({"tenant_id": tenant_id, "id": seller_id, "store_id": store_id})
        if not sp:
            raise HTTPException(status_code=400, detail="Vendedor não encontrado nesta loja.")
        return seller_id
    # Se não informado, usa o próprio usuário se for vendedor na loja
    own = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": actor_user_id, "store_id": store_id})
    if own:
        return own["id"]
    raise HTTPException(status_code=400, detail="Informe o vendedor responsável pela abordagem.")


async def create_approach(
    tenant_id: str,
    actor_user_id: str,
    membership: dict,
    data: dict,
    request=None,
) -> dict:
    role = membership["role"]
    if not (_has_perm(role, P_PROACTIVITY_CREATE_SELF) or _has_perm(role, P_PROACTIVITY_CREATE_ANY)):
        raise HTTPException(status_code=403, detail="Sem permissão para criar abordagem proativa.")

    store_id = data.get("store_id")
    if not store_id:
        raise HTTPException(status_code=400, detail="store_id é obrigatório.")

    await _check_store_access(membership, store_id)

    store = await db.stores.find_one({"tenant_id": tenant_id, "id": store_id})
    if not store:
        raise HTTPException(status_code=400, detail="Loja não encontrada.")

    seller_id = await _resolve_seller_context(
        tenant_id, membership, actor_user_id, data.get("seller_id"), store_id
    )

    # ── Validar status do vendedor (apenas para SELLER agindo por conta própria) ──
    if role == "SELLER":
        # Verificar atendimento ativo
        active_att = await db.attendances.find_one({
            "tenant_id": tenant_id, "seller_id": seller_id, "status": "IN_PROGRESS"
        })
        if active_att:
            raise HTTPException(
                status_code=400,
                detail="Finalize o atendimento atual antes de iniciar uma abordagem proativa.",
            )
        # Verificar disponibilidade
        sp_check = await db.seller_profiles.find_one({"tenant_id": tenant_id, "id": seller_id})
        if sp_check:
            current_status = sp_check.get("current_status", "AVAILABLE")
            if current_status == "UNAVAILABLE":
                raise HTTPException(
                    status_code=400,
                    detail="Você precisa estar disponível para iniciar uma abordagem proativa.",
                )
            if current_status in ("WAITING_IN_QUEUE", "SERVING"):
                raise HTTPException(
                    status_code=400,
                    detail="Você precisa estar fora da fila da vez para iniciar uma abordagem proativa.",
                )
    sp = await db.seller_profiles.find_one({"tenant_id": tenant_id, "id": seller_id})
    team_id = sp.get("team_id") if sp else None

    now = utcnow_iso()
    doc = {
        "id": new_id(),
        "tenant_id": tenant_id,
        "store_id": store_id,
        "seller_id": seller_id,
        "team_id": team_id,
        "created_by": actor_user_id,
        "customer_name": data.get("customer_name"),
        "customer_phone": data.get("customer_phone"),
        "customer_note": data.get("customer_note"),
        "source": data.get("source", "STORE_FLOOR"),
        "approach_type": data.get("approach_type", "ACTIVE_APPROACH"),
        "status": "OPEN",
        "result": "PENDING",
        "loss_reason_id": None,
        "linked_attendance_id": None,
        "linked_sale_id": None,
        "notes": data.get("notes"),
        "started_at": now,
        "converted_at": None,
        "closed_at": None,
        "cancelled_at": None,
        "created_at": now,
        "updated_at": now,
    }
    await db.proactive_approaches.insert_one(doc)
    doc.pop("_id", None)

    await log_audit(
        action="PROACTIVE_APPROACH_CREATED",
        entity="proactive_approach",
        entity_id=doc["id"],
        tenant_id=tenant_id,
        store_id=store_id,
        user_id=actor_user_id,
        new_value={"seller_id": seller_id, "source": doc["source"], "approach_type": doc["approach_type"]},
        request=request,
    )
    await event_bus.publish_event(
        tenant_id=tenant_id, store_id=store_id,
        event_type="proactivity.created",
        payload={"approach_id": doc["id"], "seller_id": seller_id, "status": "OPEN"},
    )
    return doc


async def update_approach(
    tenant_id: str,
    approach_id: str,
    actor_user_id: str,
    membership: dict,
    data: dict,
    request=None,
) -> dict:
    role = membership["role"]
    doc = await _get_approach_or_404(tenant_id, approach_id)

    if doc["status"] != "OPEN":
        raise HTTPException(status_code=400, detail="Apenas abordagens abertas podem ser editadas.")

    if role == "SELLER":
        if not _has_perm(role, P_PROACTIVITY_UPDATE_SELF):
            raise HTTPException(status_code=403, detail="Sem permissão.")
        sp = await _get_seller_profile(tenant_id, actor_user_id)
        if not sp or doc["seller_id"] != sp["id"]:
            raise HTTPException(status_code=403, detail="Só pode editar suas próprias abordagens.")
    else:
        if not _has_perm(role, P_PROACTIVITY_UPDATE_ANY):
            raise HTTPException(status_code=403, detail="Sem permissão.")
        await _check_store_access(membership, doc["store_id"])

    updatable = ["customer_name", "customer_phone", "customer_note", "source", "approach_type", "notes"]
    updates = {k: data[k] for k in updatable if k in data}
    updates["updated_at"] = utcnow_iso()
    await db.proactive_approaches.update_one({"id": approach_id}, {"$set": updates})

    await log_audit(
        action="PROACTIVE_APPROACH_UPDATED", entity="proactive_approach", entity_id=approach_id,
        tenant_id=tenant_id, store_id=doc["store_id"], user_id=actor_user_id,
        old_value={k: doc.get(k) for k in updatable}, new_value=updates, request=request,
    )
    updated = await _get_approach_or_404(tenant_id, approach_id)
    await event_bus.publish_event(
        tenant_id=tenant_id, store_id=doc["store_id"],
        event_type="proactivity.updated",
        payload={"approach_id": approach_id},
    )
    return updated


async def cancel_approach(
    tenant_id: str,
    approach_id: str,
    actor_user_id: str,
    membership: dict,
    reason: Optional[str] = None,
    request=None,
) -> dict:
    role = membership["role"]
    doc = await _get_approach_or_404(tenant_id, approach_id)
    if doc["status"] != "OPEN":
        raise HTTPException(status_code=400, detail="Apenas abordagens abertas podem ser canceladas.")

    if role == "SELLER":
        if not _has_perm(role, P_PROACTIVITY_CANCEL_SELF):
            raise HTTPException(status_code=403, detail="Sem permissão.")
        sp = await _get_seller_profile(tenant_id, actor_user_id)
        if not sp or doc["seller_id"] != sp["id"]:
            raise HTTPException(status_code=403, detail="Só pode cancelar suas próprias abordagens.")
    else:
        if not _has_perm(role, P_PROACTIVITY_CANCEL_ANY):
            raise HTTPException(status_code=403, detail="Sem permissão.")
        await _check_store_access(membership, doc["store_id"])

    now = utcnow_iso()
    await db.proactive_approaches.update_one(
        {"id": approach_id},
        {"$set": {"status": "CANCELLED", "result": "CANCELLED", "cancelled_at": now, "notes": reason or doc.get("notes"), "updated_at": now}},
    )
    await log_audit(
        action="PROACTIVE_APPROACH_CANCELLED", entity="proactive_approach", entity_id=approach_id,
        tenant_id=tenant_id, store_id=doc["store_id"], user_id=actor_user_id,
        new_value={"reason": reason}, request=request,
    )
    await event_bus.publish_event(
        tenant_id=tenant_id, store_id=doc["store_id"],
        event_type="proactivity.closed",
        payload={"approach_id": approach_id, "status": "CANCELLED"},
    )
    return await _get_approach_or_404(tenant_id, approach_id)


async def close_no_sale(
    tenant_id: str,
    approach_id: str,
    actor_user_id: str,
    membership: dict,
    data: dict,
    request=None,
) -> dict:
    role = membership["role"]
    doc = await _get_approach_or_404(tenant_id, approach_id)
    if doc["status"] != "OPEN":
        raise HTTPException(status_code=400, detail="Apenas abordagens abertas podem ser encerradas.")

    if role == "SELLER":
        if not _has_perm(role, P_PROACTIVITY_CLOSE_NO_SALE_SELF):
            raise HTTPException(status_code=403, detail="Sem permissão.")
        sp = await _get_seller_profile(tenant_id, actor_user_id)
        if not sp or doc["seller_id"] != sp["id"]:
            raise HTTPException(status_code=403, detail="Sem acesso.")
    else:
        if not _has_perm(role, P_PROACTIVITY_CLOSE_NO_SALE_ANY):
            raise HTTPException(status_code=403, detail="Sem permissão.")
        await _check_store_access(membership, doc["store_id"])

    now = utcnow_iso()
    updates = {
        "status": "NO_SALE",
        "result": "NO_SALE",
        "loss_reason_id": data.get("loss_reason_id"),
        "notes": data.get("notes") or doc.get("notes"),
        "closed_at": now,
        "updated_at": now,
    }
    await db.proactive_approaches.update_one({"id": approach_id}, {"$set": updates})
    await log_audit(
        action="PROACTIVE_APPROACH_CLOSED_NO_SALE", entity="proactive_approach", entity_id=approach_id,
        tenant_id=tenant_id, store_id=doc["store_id"], user_id=actor_user_id,
        new_value={"loss_reason_id": data.get("loss_reason_id")}, request=request,
    )
    await event_bus.publish_event(
        tenant_id=tenant_id, store_id=doc["store_id"],
        event_type="proactivity.closed",
        payload={"approach_id": approach_id, "status": "NO_SALE"},
    )
    return await _get_approach_or_404(tenant_id, approach_id)


async def convert_to_attendance(
    tenant_id: str,
    approach_id: str,
    actor_user_id: str,
    membership: dict,
    data: dict,
    request=None,
) -> dict:
    role = membership["role"]
    doc = await _get_approach_or_404(tenant_id, approach_id)
    if doc["status"] != "OPEN":
        raise HTTPException(status_code=400, detail="Apenas abordagens abertas podem ser convertidas.")

    if role == "SELLER":
        if not _has_perm(role, P_PROACTIVITY_CONVERT_TO_ATTENDANCE_SELF):
            raise HTTPException(status_code=403, detail="Sem permissão.")
        sp = await _get_seller_profile(tenant_id, actor_user_id)
        if not sp or doc["seller_id"] != sp["id"]:
            raise HTTPException(status_code=403, detail="Sem acesso.")
    else:
        if not _has_perm(role, P_PROACTIVITY_CONVERT_TO_ATTENDANCE_ANY):
            raise HTTPException(status_code=403, detail="Sem permissão.")
        await _check_store_access(membership, doc["store_id"])

    now = utcnow_iso()
    # Criar attendance com source=PROACTIVE
    attendance_id = new_id()
    attendance = {
        "id": attendance_id,
        "tenant_id": tenant_id,
        "store_id": doc["store_id"],
        "queue_id": None,
        "seller_id": doc["seller_id"],
        "customer_visit_id": None,
        "status": "IN_PROGRESS",
        "result": None,
        "source": "PROACTIVE",
        "proactive_approach_id": approach_id,
        "sale_amount_cents": None,
        "loss_reason_id": None,
        "notes": data.get("notes") or doc.get("notes"),
        "started_at": now,
        "finished_at": None,
        "created_at": now,
        "updated_at": now,
    }
    # Create customer_visit if customer_name provided
    customer_name = data.get("customer_name") or doc.get("customer_name")
    if customer_name:
        visit_id = new_id()
        await db.customer_visits.insert_one({
            "id": visit_id,
            "tenant_id": tenant_id,
            "store_id": doc["store_id"],
            "seller_id": doc["seller_id"],
            "customer_name": customer_name,
            "customer_phone": doc.get("customer_phone"),
            "source": "PROACTIVE",
            "created_at": now,
        })
        attendance["customer_visit_id"] = visit_id

    await db.attendances.insert_one(attendance)

    updates = {
        "status": "CONVERTED_TO_ATTENDANCE",
        "result": "PENDING",
        "linked_attendance_id": attendance_id,
        "converted_at": now,
        "updated_at": now,
    }
    await db.proactive_approaches.update_one({"id": approach_id}, {"$set": updates})
    await log_audit(
        action="PROACTIVE_APPROACH_CONVERTED_TO_ATTENDANCE",
        entity="proactive_approach", entity_id=approach_id,
        tenant_id=tenant_id, store_id=doc["store_id"], user_id=actor_user_id,
        new_value={"attendance_id": attendance_id}, request=request,
    )
    await event_bus.publish_event(
        tenant_id=tenant_id, store_id=doc["store_id"],
        event_type="proactivity.converted_to_attendance",
        payload={"approach_id": approach_id, "attendance_id": attendance_id},
    )
    result = await _get_approach_or_404(tenant_id, approach_id)
    result["attendance"] = {k: v for k, v in attendance.items() if k != "_id"}
    return result


async def convert_to_sale(
    tenant_id: str,
    approach_id: str,
    actor_user_id: str,
    membership: dict,
    data: dict,
    request=None,
) -> dict:
    role = membership["role"]
    doc = await _get_approach_or_404(tenant_id, approach_id)
    if doc["status"] != "OPEN":
        raise HTTPException(status_code=400, detail="Apenas abordagens abertas podem ser convertidas em venda.")

    if role == "SELLER":
        if not _has_perm(role, P_PROACTIVITY_CONVERT_TO_SALE_SELF):
            raise HTTPException(status_code=403, detail="Sem permissão.")
        sp = await _get_seller_profile(tenant_id, actor_user_id)
        if not sp or doc["seller_id"] != sp["id"]:
            raise HTTPException(status_code=403, detail="Sem acesso.")
    else:
        if not _has_perm(role, P_PROACTIVITY_CONVERT_TO_SALE_ANY):
            raise HTTPException(status_code=403, detail="Sem permissão.")
        await _check_store_access(membership, doc["store_id"])

    gross = data.get("gross_amount_cents", 0) or 0
    discount = data.get("discount_amount_cents", 0) or 0
    net = data.get("net_amount_cents") or (gross - discount)
    payment_method = data.get("payment_method", "CASH")

    now = utcnow_iso()
    sale_id = new_id()
    sale = {
        "id": sale_id,
        "tenant_id": tenant_id,
        "store_id": doc["store_id"],
        "seller_id": doc["seller_id"],
        "attendance_id": None,
        "proactive_approach_id": approach_id,
        "source": "PROACTIVE",
        "status": "COMPLETED",
        "gross_amount_cents": gross,
        "discount_amount_cents": discount,
        "net_amount_cents": net,
        "payment_methods": [{"method": payment_method, "amount_cents": net}],
        "notes": data.get("notes"),
        "created_at": now,
        "updated_at": now,
    }
    await db.sales.insert_one(sale)

    # Insert sale items if provided
    items = data.get("items") or []
    for item in items:
        await db.sale_items.insert_one({
            "id": new_id(),
            "tenant_id": tenant_id,
            "sale_id": sale_id,
            "product_id": item.get("product_id"),
            "name": item.get("name"),
            "sku": item.get("sku"),
            "quantity": item.get("quantity", 1),
            "unit_price_cents": item.get("unit_price_cents"),
            "discount_cents": item.get("discount_cents", 0),
            "created_at": now,
        })

    updates = {
        "status": "CONVERTED_TO_SALE",
        "result": "SALE",
        "linked_sale_id": sale_id,
        "converted_at": now,
        "closed_at": now,
        "updated_at": now,
    }
    await db.proactive_approaches.update_one({"id": approach_id}, {"$set": updates})
    await log_audit(
        action="PROACTIVE_APPROACH_CONVERTED_TO_SALE",
        entity="proactive_approach", entity_id=approach_id,
        tenant_id=tenant_id, store_id=doc["store_id"], user_id=actor_user_id,
        new_value={"sale_id": sale_id, "net_amount_cents": net}, request=request,
    )
    await event_bus.publish_event(
        tenant_id=tenant_id, store_id=doc["store_id"],
        event_type="proactivity.converted_to_sale",
        payload={"approach_id": approach_id, "sale_id": sale_id, "net_amount_cents": net},
    )

    # ── Recalcular metas e conquistas (igual ao fluxo do queue_engine) ──
    try:
        import goals_service as _goals_svc
        await _goals_svc.recalculate_active_goals(
            tenant_id, store_id=doc["store_id"], seller_id=doc["seller_id"]
        )
    except Exception:
        pass
    try:
        import achievement_service as _ach_svc
        await _ach_svc.evaluate_active_achievements(
            tenant_id, doc["seller_id"], doc["store_id"]
        )
    except Exception:
        pass

    result = await _get_approach_or_404(tenant_id, approach_id)
    result["sale"] = {k: v for k, v in sale.items() if k != "_id"}
    return result


async def get_approach(
    tenant_id: str,
    approach_id: str,
    actor_user_id: str,
    membership: dict,
) -> dict:
    doc = await _get_approach_or_404(tenant_id, approach_id)
    role = membership["role"]
    if role == "SELLER":
        sp = await _get_seller_profile(tenant_id, actor_user_id)
        if not sp or doc["seller_id"] != sp["id"]:
            raise HTTPException(status_code=403, detail="Sem acesso.")
    elif role not in ("TENANT_ADMIN", "REGIONAL_MANAGER"):
        if not can_access_store(membership, doc["store_id"]):
            raise HTTPException(status_code=403, detail="Sem acesso a esta unidade.")
    return await _enrich_approach(doc)


async def list_approaches(
    tenant_id: str,
    actor_user_id: str,
    membership: dict,
    filters: dict,
) -> List[dict]:
    role = membership["role"]
    accessible_store_ids = await get_accessible_store_ids(membership, tenant_id)

    q: dict = {"tenant_id": tenant_id}

    if role == "SELLER":
        sp = await _get_seller_profile(tenant_id, actor_user_id)
        q["seller_id"] = sp["id"] if sp else "__none__"
    else:
        req_store = filters.get("store_id")
        if req_store:
            if req_store not in accessible_store_ids:
                raise HTTPException(status_code=403, detail="Sem acesso a esta unidade.")
            q["store_id"] = req_store
        else:
            if accessible_store_ids:
                q["store_id"] = {"$in": accessible_store_ids}

    # Apply filters
    if filters.get("seller_id") and role != "SELLER":
        q["seller_id"] = filters["seller_id"]
    if filters.get("team_id"):
        q["team_id"] = filters["team_id"]
    if filters.get("status"):
        q["status"] = filters["status"]
    if filters.get("result"):
        q["result"] = filters["result"]
    if filters.get("source"):
        q["source"] = filters["source"]
    if filters.get("approach_type"):
        q["approach_type"] = filters["approach_type"]
    if filters.get("date_from") or filters.get("date_to"):
        date_q: dict = {}
        if filters.get("date_from"):
            date_q["$gte"] = filters["date_from"]
        if filters.get("date_to"):
            date_q["$lte"] = filters["date_to"] + "T23:59:59.999999+00:00"
        q["started_at"] = date_q

    limit = min(int(filters.get("limit", 200)), 500)
    raw = await db.proactive_approaches.find(q).sort("created_at", -1).limit(limit).to_list(limit)
    for doc in raw:
        doc.pop("_id", None)
    return await _enrich_list(raw)


async def list_my_approaches(
    tenant_id: str,
    actor_user_id: str,
    filters: dict,
) -> List[dict]:
    sp = await _get_seller_profile(tenant_id, actor_user_id)
    if not sp:
        return []
    q: dict = {"tenant_id": tenant_id, "seller_id": sp["id"]}
    if filters.get("status"):
        q["status"] = filters["status"]
    if filters.get("date_from") or filters.get("date_to"):
        date_q: dict = {}
        if filters.get("date_from"):
            date_q["$gte"] = filters["date_from"]
        if filters.get("date_to"):
            date_q["$lte"] = filters["date_to"] + "T23:59:59.999999+00:00"
        q["started_at"] = date_q
    raw = await db.proactive_approaches.find(q).sort("created_at", -1).limit(200).to_list(200)
    for doc in raw:
        doc.pop("_id", None)
    return await _enrich_list(raw)


async def get_proactivity_summary(
    tenant_id: str,
    actor_user_id: str,
    membership: dict,
    filters: dict,
) -> dict:
    role = membership["role"]
    accessible_store_ids = await get_accessible_store_ids(membership, tenant_id)

    q: dict = {"tenant_id": tenant_id}
    if role == "SELLER":
        sp = await _get_seller_profile(tenant_id, actor_user_id)
        q["seller_id"] = sp["id"] if sp else "__none__"
    else:
        req_store = filters.get("store_id")
        if req_store:
            if req_store not in accessible_store_ids:
                raise HTTPException(status_code=403, detail="Sem acesso a esta unidade.")
            q["store_id"] = req_store
        elif accessible_store_ids:
            q["store_id"] = {"$in": accessible_store_ids}
        if filters.get("seller_id"):
            q["seller_id"] = filters["seller_id"]

    if filters.get("date_from") or filters.get("date_to"):
        date_q: dict = {}
        if filters.get("date_from"):
            date_q["$gte"] = filters["date_from"]
        if filters.get("date_to"):
            date_q["$lte"] = filters["date_to"] + "T23:59:59.999999+00:00"
        q["started_at"] = date_q

    docs = await db.proactive_approaches.find(q).to_list(5000)
    for d in docs:
        d.pop("_id", None)

    total = len(docs)
    open_count = sum(1 for d in docs if d["status"] == "OPEN")
    converted_att = sum(1 for d in docs if d["status"] == "CONVERTED_TO_ATTENDANCE")
    converted_sale = sum(1 for d in docs if d["status"] == "CONVERTED_TO_SALE")
    no_sale = sum(1 for d in docs if d["status"] == "NO_SALE")
    cancelled = sum(1 for d in docs if d["status"] == "CANCELLED")

    sale_ids = [d["linked_sale_id"] for d in docs if d.get("linked_sale_id")]
    proactive_revenue = 0
    if sale_ids:
        sales = await db.sales.find({"id": {"$in": sale_ids}}).to_list(5000)
        proactive_revenue = sum(s.get("net_amount_cents", 0) or 0 for s in sales)

    closed = converted_att + converted_sale + no_sale
    conversion_to_att_pct = round(converted_att / total * 100) if total else 0
    conversion_to_sale_pct = round(converted_sale / total * 100) if total else 0
    avg_ticket = round(proactive_revenue / converted_sale) if converted_sale else 0

    # By seller
    by_seller: dict = {}
    for d in docs:
        sid = d["seller_id"]
        if sid not in by_seller:
            by_seller[sid] = {"total": 0, "sales": 0, "revenue": 0}
        by_seller[sid]["total"] += 1
        if d["status"] == "CONVERTED_TO_SALE":
            by_seller[sid]["sales"] += 1

    # Loss reasons
    lr_counts: dict = {}
    for d in docs:
        if d["status"] == "NO_SALE" and d.get("loss_reason_id"):
            lr_counts[d["loss_reason_id"]] = lr_counts.get(d["loss_reason_id"], 0) + 1

    # Sources
    source_counts: dict = {}
    for d in docs:
        src = d.get("source", "OTHER")
        source_counts[src] = source_counts.get(src, 0) + 1

    return {
        "total_approaches": total,
        "open": open_count,
        "converted_to_attendance": converted_att,
        "converted_to_sale": converted_sale,
        "no_sale": no_sale,
        "cancelled": cancelled,
        "proactive_revenue_cents": proactive_revenue,
        "conversion_to_attendance_pct": conversion_to_att_pct,
        "conversion_to_sale_pct": conversion_to_sale_pct,
        "avg_ticket_cents": avg_ticket,
        "by_seller": by_seller,
        "loss_reason_counts": lr_counts,
        "source_counts": source_counts,
    }


async def _enrich_approach(doc: dict) -> dict:
    sp = await db.seller_profiles.find_one({"id": doc["seller_id"]})
    sp_name = None
    if sp:
        sp.pop("_id", None)
        user = await db.users.find_one({"id": sp.get("user_id", "")})
        if user:
            sp_name = user.get("name")
    store = await db.stores.find_one({"id": doc.get("store_id", "")})
    lr = None
    if doc.get("loss_reason_id"):
        lr_doc = await db.loss_reasons.find_one({"id": doc["loss_reason_id"]})
        if lr_doc:
            lr_doc.pop("_id", None)
            lr = lr_doc
    return {**doc, "seller_name": sp_name, "store_name": store.get("name") if store else None, "loss_reason": lr}


async def _enrich_list(docs: List[dict]) -> List[dict]:
    if not docs:
        return []
    seller_ids = list({d["seller_id"] for d in docs})
    store_ids = list({d["store_id"] for d in docs if d.get("store_id")})
    lr_ids = list({d["loss_reason_id"] for d in docs if d.get("loss_reason_id")})

    sellers = {}
    async for sp in db.seller_profiles.find({"id": {"$in": seller_ids}}):
        sellers[sp["id"]] = sp

    user_ids = list({sp.get("user_id") for sp in sellers.values() if sp.get("user_id")})
    users = {}
    async for u in db.users.find({"id": {"$in": user_ids}}):
        users[u["id"]] = u

    stores = {}
    async for st in db.stores.find({"id": {"$in": store_ids}}):
        stores[st["id"]] = st

    lrs = {}
    async for lr in db.loss_reasons.find({"id": {"$in": lr_ids}}):
        lr.pop("_id", None)
        lrs[lr["id"]] = lr

    out = []
    for d in docs:
        sp = sellers.get(d["seller_id"], {})
        u = users.get(sp.get("user_id", ""), {})
        st = stores.get(d.get("store_id", ""), {})
        lr = lrs.get(d.get("loss_reason_id", ""))
        out.append({
            **d,
            "seller_name": u.get("name"),
            "store_name": st.get("name"),
            "loss_reason_name": lr.get("name") if lr else None,
        })
    return out
