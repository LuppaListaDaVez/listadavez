"""Relatório Fluxo de Oportunidades por Horário."""
import csv
import io
import zipfile
from dataclasses import dataclass
from datetime import datetime, time, timedelta, timezone
from typing import Optional
from zoneinfo import ZoneInfo

from fastapi import HTTPException
from fastapi.responses import StreamingResponse

from db import db
from permission_service import get_accessible_store_ids
from permissions import ROLE_PERMISSIONS, P_REPORTS_VIEW_SELF, P_REPORTS_VIEW_STORE, P_REPORTS_VIEW_TENANT, P_SALES_VIEW_STORE, P_SALES_VIEW_TENANT


VALID_ATTENDANCE_STATUSES = ["IN_PROGRESS", "FINISHED"]
INVALID_ATTENDANCE_STATUSES = ["CANCELLED"]
VALID_SALE_STATUSES = ["COMPLETED", "CONFIRMED", "FINISHED"]
ATTENDANCE_TIME_FIELD = "started_at"


@dataclass
class Periodo:
    inicio_local: datetime
    fim_local: datetime
    inicio_utc: datetime
    fim_utc: datetime
    timezone_nome: str
    granularidade: str


def _parse_iso_utc(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def _iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat()


def _local_date(value: Optional[str], tz: ZoneInfo, default: datetime) -> datetime:
    if not value:
        return default
    try:
        return datetime.combine(datetime.strptime(value, "%Y-%m-%d").date(), time.min, tzinfo=tz)
    except Exception:
        raise HTTPException(status_code=400, detail="Data inválida. Use o formato AAAA-MM-DD.")


def _add_month(dt: datetime) -> datetime:
    month = dt.month + 1
    year = dt.year + (month - 1) // 12
    month = ((month - 1) % 12) + 1
    return dt.replace(year=year, month=month, day=1, hour=0, minute=0, second=0, microsecond=0)


def _periodo(date_start: Optional[str], date_end: Optional[str], timezone_nome: str) -> Periodo:
    tz = ZoneInfo(timezone_nome)
    agora = datetime.now(tz)
    hoje = datetime.combine(agora.date(), time.min, tzinfo=tz)
    inicio = _local_date(date_start, tz, hoje)
    fim_dia = _local_date(date_end, tz, hoje) if date_end else hoje
    fim = fim_dia + timedelta(days=1)
    if fim <= inicio:
        raise HTTPException(status_code=400, detail="A data final deve ser maior ou igual à data inicial.")
    dias = (fim.date() - inicio.date()).days
    if dias <= 1:
        granularidade = "hour"
    elif dias <= 31:
        granularidade = "day"
    elif dias <= 180:
        granularidade = "week"
    else:
        granularidade = "month"
    return Periodo(inicio, fim, inicio.astimezone(timezone.utc), fim.astimezone(timezone.utc), timezone_nome, granularidade)


async def _timezone_empresa(tenant_id: str, store_id: Optional[str], store_ids: list[str]) -> str:
    if store_id:
        store = await db.stores.find_one({"tenant_id": tenant_id, "id": store_id}, {"_id": 0, "timezone": 1})
        return store.get("timezone") or "America/Sao_Paulo" if store else "America/Sao_Paulo"
    store = await db.stores.find_one({"tenant_id": tenant_id, "id": {"$in": store_ids}}, {"_id": 0, "timezone": 1}) if store_ids else None
    return (store or {}).get("timezone") or "America/Sao_Paulo"


def _tem_relatorios(role: str) -> bool:
    perms = ROLE_PERMISSIONS.get(role, [])
    return any(p in perms for p in [P_REPORTS_VIEW_SELF, P_REPORTS_VIEW_STORE, P_REPORTS_VIEW_TENANT])


def _pode_ver_financeiro(role: str) -> bool:
    perms = ROLE_PERMISSIONS.get(role, [])
    return any(p in perms for p in [P_SALES_VIEW_TENANT, P_SALES_VIEW_STORE]) and role != "SELLER"


async def _seller_ids_por_filtro(tenant_id: str, store_ids: list[str], team_id: Optional[str], seller_id: Optional[str], role: str, user_id: str) -> Optional[list[str]]:
    if role == "SELLER":
        profile = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": user_id}, {"_id": 0, "id": 1})
        return [profile["id"]] if profile else ["__sem_acesso__"]

    base = {"tenant_id": tenant_id, "store_id": {"$in": store_ids}}
    if team_id:
        team = await db.teams.find_one({"tenant_id": tenant_id, "id": team_id}, {"_id": 0, "store_id": 1})
        if not team or team.get("store_id") not in store_ids:
            raise HTTPException(status_code=403, detail="Sem acesso a esta equipe.")
        base["team_id"] = team_id
    if seller_id:
        if seller_id == "__sem_vendedor__":
            return ["__sem_vendedor__"]
        seller = await db.seller_profiles.find_one({"tenant_id": tenant_id, "id": seller_id}, {"_id": 0, "store_id": 1, "team_id": 1})
        if not seller or seller.get("store_id") not in store_ids or (team_id and seller.get("team_id") != team_id):
            raise HTTPException(status_code=403, detail="Sem acesso a este vendedor.")
        return [seller_id]
    if team_id:
        sellers = await db.seller_profiles.find(base, {"_id": 0, "id": 1}).to_list(1000)
        return [s["id"] for s in sellers] or ["__sem_resultado__"]
    return None


async def resolver_escopo(ctx: dict, store_id: Optional[str], team_id: Optional[str], seller_id: Optional[str], date_start: Optional[str], date_end: Optional[str]) -> tuple[dict, Periodo, bool, list[str], Optional[list[str]]]:
    tenant_id = ctx["tenant"]["id"]
    role = ctx["membership"]["role"]
    if not _tem_relatorios(role):
        raise HTTPException(status_code=403, detail="Sem permissão para visualizar relatórios.")
    accessible = await get_accessible_store_ids(ctx["membership"], tenant_id)
    if store_id:
        if store_id not in accessible:
            raise HTTPException(status_code=403, detail="Sem acesso a esta unidade.")
        store_ids = [store_id]
    else:
        store_ids = accessible
    timezone_nome = await _timezone_empresa(tenant_id, store_id, store_ids)
    periodo = _periodo(date_start, date_end, timezone_nome)
    seller_ids = await _seller_ids_por_filtro(tenant_id, store_ids, team_id, seller_id, role, ctx["user"]["id"])
    filtros = {"tenant_id": tenant_id, "store_id": {"$in": store_ids}}
    if seller_ids is not None:
        if seller_ids == ["__sem_vendedor__"]:
            filtros["$or"] = [{"seller_id": None}, {"seller_id": {"$exists": False}}, {"seller_id": ""}]
        else:
            filtros["seller_id"] = {"$in": seller_ids}
    return filtros, periodo, _pode_ver_financeiro(role), store_ids, seller_ids


def _bucket_expr(granularidade: str, tz: str):
    if granularidade == "hour":
        return {"$dateToString": {"format": "%Y-%m-%dT%H:00", "date": "$started_date", "timezone": tz}}
    if granularidade == "day":
        return {"$dateToString": {"format": "%Y-%m-%d", "date": "$started_date", "timezone": tz}}
    if granularidade == "month":
        return {"$dateToString": {"format": "%Y-%m", "date": "$started_date", "timezone": tz}}
    return {
        "ano": {"$isoWeekYear": {"date": "$started_date", "timezone": tz}},
        "semana": {"$isoWeek": {"date": "$started_date", "timezone": tz}},
    }


def _bucket_key_from_local(dt: datetime, granularidade: str) -> str:
    if granularidade == "hour":
        return dt.strftime("%Y-%m-%dT%H:00")
    if granularidade == "day":
        return dt.strftime("%Y-%m-%d")
    if granularidade == "month":
        return dt.strftime("%Y-%m")
    iso = dt.isocalendar()
    return f"{iso.year}-W{iso.week:02d}"


def _bucket_key_mongo(raw) -> str:
    if isinstance(raw, dict):
        return f"{int(raw.get('ano'))}-W{int(raw.get('semana')):02d}"
    return str(raw)


def _label(dt: datetime, granularidade: str) -> str:
    if granularidade == "hour":
        return dt.strftime("%Hh")
    if granularidade == "day":
        return dt.strftime("%d/%m")
    if granularidade == "month":
        return dt.strftime("%m/%Y")
    iso = dt.isocalendar()
    return f"Sem. {iso.week:02d}/{iso.year}"


def _iter_intervalos(periodo: Periodo) -> list[datetime]:
    fim_analise = min(periodo.fim_local, datetime.now(ZoneInfo(periodo.timezone_nome)))
    atual = periodo.inicio_local
    out = []
    while atual < fim_analise:
        out.append(atual)
        if periodo.granularidade == "hour":
            atual += timedelta(hours=1)
        elif periodo.granularidade == "day":
            atual += timedelta(days=1)
        elif periodo.granularidade == "week":
            atual += timedelta(weeks=1)
        else:
            atual = _add_month(atual)
    return out


def _base_match(filtros: dict, periodo: Periodo, attendance_type: Optional[str] = None) -> dict:
    q = {
        **filtros,
        ATTENDANCE_TIME_FIELD: {"$gte": _iso(periodo.inicio_utc), "$lt": _iso(periodo.fim_utc)},
        "status": {"$in": VALID_ATTENDANCE_STATUSES},
        "$and": [
            {"deleted": {"$ne": True}},
            {"is_test": {"$ne": True}},
            {"is_duplicate": {"$ne": True}},
            {ATTENDANCE_TIME_FIELD: {"$nin": [None, ""]}},
        ],
    }
    if attendance_type:
        if attendance_type == "MULTIPLE":
            q["$and"].append({"$or": [
                {"attendance_type": "MULTIPLE"},
                {"source": {"$in": ["MULTIPLE_AGGREGATED", "MULTIPLE_DETAILED"]}},
                {"origin": {"$in": ["MULTIPLE_AGGREGATED", "MULTIPLE_DETAILED"]}},
            ]})
        else:
            q["$and"].append({"$or": [{"source": attendance_type}, {"origin": attendance_type}, {"attendance_type": attendance_type}]})
    return q


async def _agregar(filtros: dict, periodo: Periodo, attendance_type: Optional[str] = None) -> dict:
    q = _base_match(filtros, periodo, attendance_type)
    lookup_match = {"$expr": {"$and": [
        {"$eq": ["$tenant_id", "$$tenant_id"]},
        {"$eq": ["$attendance_id", "$$att_id"]},
        {"$in": ["$status", VALID_SALE_STATUSES]},
        {"$ne": ["$deleted", True]},
        {"$ne": ["$is_test", True]},
    ]}}
    pipeline = [
        {"$match": q},
        {"$addFields": {"started_date": {"$dateFromString": {"dateString": f"${ATTENDANCE_TIME_FIELD}"}}}},
        {"$lookup": {
            "from": "sales",
            "let": {"att_id": "$id", "tenant_id": "$tenant_id"},
            "pipeline": [{"$match": lookup_match}, {"$project": {"_id": 0, "id": 1, "net_amount_cents": 1}}],
            "as": "vendas_validas",
        }},
        {"$addFields": {
            "sales_count": {"$size": "$vendas_validas"},
            "converted": {"$cond": [{"$gt": [{"$size": "$vendas_validas"}, 0]}, 1, 0]},
            "revenue": {"$sum": "$vendas_validas.net_amount_cents"},
            "bucket": _bucket_expr(periodo.granularidade, periodo.timezone_nome),
            "weekday": {"$dayOfWeek": {"date": "$started_date", "timezone": periodo.timezone_nome}},
            "hour": {"$hour": {"date": "$started_date", "timezone": periodo.timezone_nome}},
        }},
        {"$facet": {
            "series": [
                {"$group": {"_id": "$bucket", "opportunities": {"$sum": 1}, "converted_opportunities": {"$sum": "$converted"}, "sales": {"$sum": "$sales_count"}, "revenue": {"$sum": "$revenue"}}},
            ],
            "heatmap": [
                {"$group": {"_id": {"weekday": "$weekday", "hour": "$hour"}, "opportunities": {"$sum": 1}, "converted_opportunities": {"$sum": "$converted"}, "sales": {"$sum": "$sales_count"}, "revenue": {"$sum": "$revenue"}}},
            ],
        }},
    ]
    agg = await db.attendances.aggregate(pipeline, allowDiskUse=True).to_list(1)
    return agg[0] if agg else {"series": [], "heatmap": []}


def _conversion(converted: int, opportunities: int) -> float:
    if not opportunities:
        return 0
    return min(100, (converted / opportunities) * 100)


def _percent_change(atual: int, anterior: int):
    if anterior == 0:
        return None
    return ((atual - anterior) / anterior) * 100


def _totais(series: list[dict], qtd_intervalos: int, financeiro: bool) -> dict:
    opp = sum(int(i.get("opportunities") or 0) for i in series)
    conv = sum(int(i.get("converted_opportunities") or 0) for i in series)
    sales = sum(int(i.get("sales") or 0) for i in series)
    revenue = sum(int(i.get("revenue") or 0) for i in series)
    totals = {
        "opportunities": opp,
        "converted_opportunities": conv,
        "sales": sales,
        "conversion_rate": _conversion(conv, opp),
        "average_opportunities": (opp / qtd_intervalos) if qtd_intervalos else 0,
    }
    if financeiro:
        totals["revenue"] = revenue
        totals["average_ticket"] = int(round(revenue / sales)) if sales else 0
    return totals


async def _sales_without_attendance(tenant_id: str, store_ids: list[str], seller_ids: Optional[list[str]], periodo: Periodo) -> int:
    q = {
        "tenant_id": tenant_id,
        "store_id": {"$in": store_ids},
        "created_at": {"$gte": _iso(periodo.inicio_utc), "$lt": _iso(periodo.fim_utc)},
        "status": {"$in": VALID_SALE_STATUSES},
        "$and": [
            {"deleted": {"$ne": True}},
            {"is_test": {"$ne": True}},
            {"$or": [{"attendance_id": None}, {"attendance_id": ""}, {"attendance_id": {"$exists": False}}]},
        ],
    }
    if seller_ids and seller_ids not in (["__sem_vendedor__"], ["__sem_resultado__"]):
        q["seller_id"] = {"$in": seller_ids}
    return await db.sales.count_documents(q)


async def gerar_relatorio(ctx: dict, *, date_start: Optional[str], date_end: Optional[str], store_id: Optional[str], team_id: Optional[str], seller_id: Optional[str], attendance_type: Optional[str]) -> dict:
    filtros, periodo, financeiro, store_ids, seller_ids = await resolver_escopo(ctx, store_id, team_id, seller_id, date_start, date_end)
    if not store_ids:
        raise HTTPException(status_code=403, detail="Nenhuma unidade acessível para este usuário.")
    agregado = await _agregar(filtros, periodo, attendance_type)
    por_bucket = {_bucket_key_mongo(i["_id"]): i for i in agregado.get("series", [])}
    intervalos = _iter_intervalos(periodo)
    series = []
    for dt in intervalos:
        key = _bucket_key_from_local(dt, periodo.granularidade)
        raw = por_bucket.get(key, {})
        opp = int(raw.get("opportunities") or 0)
        conv = int(raw.get("converted_opportunities") or 0)
        sales = int(raw.get("sales") or 0)
        revenue = int(raw.get("revenue") or 0)
        item = {
            "bucket_start": dt.isoformat(),
            "label": _label(dt, periodo.granularidade),
            "opportunities": opp,
            "converted_opportunities": conv,
            "sales": sales,
            "conversion_rate": _conversion(conv, opp),
        }
        if financeiro:
            item["revenue"] = revenue
            item["average_ticket"] = int(round(revenue / sales)) if sales else 0
        series.append(item)
    totals = _totais(series, len(series), financeiro)

    duracao = min(periodo.fim_local, datetime.now(ZoneInfo(periodo.timezone_nome))) - periodo.inicio_local
    prev_end = periodo.inicio_local
    prev_start = prev_end - duracao
    periodo_anterior = Periodo(prev_start, prev_end, prev_start.astimezone(timezone.utc), prev_end.astimezone(timezone.utc), periodo.timezone_nome, periodo.granularidade)
    anterior_agregado = await _agregar(filtros, periodo_anterior, attendance_type)
    anterior_series = []
    for i in anterior_agregado.get("series", []):
        anterior_series.append({
            "opportunities": int(i.get("opportunities") or 0),
            "converted_opportunities": int(i.get("converted_opportunities") or 0),
            "sales": int(i.get("sales") or 0),
            "revenue": int(i.get("revenue") or 0),
        })
    prev_totals = _totais(anterior_series, max(len(anterior_series), 1), financeiro)
    comparison = {
        "opportunities_change": _percent_change(totals["opportunities"], prev_totals["opportunities"]),
        "converted_change": _percent_change(totals["converted_opportunities"], prev_totals["converted_opportunities"]),
        "sales_change": _percent_change(totals["sales"], prev_totals["sales"]),
        "conversion_change_points": totals["conversion_rate"] - prev_totals["conversion_rate"] if prev_totals["opportunities"] else None,
        "sem_base_comparativa": prev_totals["opportunities"] == 0,
    }
    if financeiro:
        comparison["revenue_change"] = _percent_change(totals.get("revenue", 0), prev_totals.get("revenue", 0))

    heatmap = []
    mapa = {(int(i["_id"].get("weekday")), int(i["_id"].get("hour"))): i for i in agregado.get("heatmap", [])}
    for weekday in range(1, 8):
        for hour in range(0, 24):
            raw = mapa.get((weekday, hour), {})
            opp = int(raw.get("opportunities") or 0)
            conv = int(raw.get("converted_opportunities") or 0)
            sales = int(raw.get("sales") or 0)
            cell = {"weekday": weekday, "hour": hour, "opportunities": opp, "converted_opportunities": conv, "sales": sales, "conversion_rate": _conversion(conv, opp)}
            if financeiro:
                cell["revenue"] = int(raw.get("revenue") or 0)
            heatmap.append(cell)

    return {
        "period": {"start": periodo.inicio_local.isoformat(), "end": periodo.fim_local.isoformat(), "timezone": periodo.timezone_nome, "granularity": periodo.granularidade, "attendance_time_field": ATTENDANCE_TIME_FIELD},
        "filters": {"store_id": store_id, "team_id": team_id, "seller_id": seller_id, "attendance_type": attendance_type},
        "rules": {"valid_attendance_statuses": VALID_ATTENDANCE_STATUSES, "invalid_attendance_statuses": INVALID_ATTENDANCE_STATUSES, "valid_sale_statuses": VALID_SALE_STATUSES, "organizational_history_limitation": "Atendimentos atuais não armazenam team_id histórico; filtros por equipe usam a equipe atual do vendedor."},
        "can_view_financial": financeiro,
        "totals": totals,
        "comparison": comparison,
        "series": series,
        "heatmap": heatmap,
        "data_quality": {"sales_without_attendance": await _sales_without_attendance(ctx["tenant"]["id"], store_ids, seller_ids, periodo)},
        "indexes_documented": [
            "attendances: tenant_id + started_at",
            "attendances: tenant_id + store_id + started_at",
            "attendances: tenant_id + seller_id + started_at",
            "sales: tenant_id + attendance_id + status",
        ],
    }


async def opcoes_filtros(ctx: dict, store_id: Optional[str] = None, team_id: Optional[str] = None) -> dict:
    tenant_id = ctx["tenant"]["id"]
    accessible = await get_accessible_store_ids(ctx["membership"], tenant_id)
    if store_id and store_id not in accessible:
        raise HTTPException(status_code=403, detail="Sem acesso a esta unidade.")
    store_ids = [store_id] if store_id else accessible
    stores = await db.stores.find({"tenant_id": tenant_id, "id": {"$in": store_ids}}, {"_id": 0, "id": 1, "name": 1}).sort("name", 1).to_list(500)
    teams = await db.teams.find({"tenant_id": tenant_id, "store_id": {"$in": store_ids}, "status": {"$ne": "DELETED"}}, {"_id": 0, "id": 1, "name": 1, "store_id": 1}).sort("name", 1).to_list(1000)
    seller_q = {"tenant_id": tenant_id, "store_id": {"$in": store_ids}}
    if team_id:
        if not any(t["id"] == team_id for t in teams):
            raise HTTPException(status_code=403, detail="Sem acesso a esta equipe.")
        seller_q["team_id"] = team_id
    sellers = await db.seller_profiles.find(seller_q, {"_id": 0, "id": 1, "user_id": 1, "store_id": 1, "team_id": 1}).to_list(1000)
    users = await db.users.find({"id": {"$in": [s.get("user_id") for s in sellers]}}, {"_id": 0, "id": 1, "name": 1}).to_list(1000)
    nomes = {u["id"]: u.get("name") or "—" for u in users}
    sem_vendedor = await db.attendances.count_documents({"tenant_id": tenant_id, "store_id": {"$in": store_ids}, "$or": [{"seller_id": None}, {"seller_id": ""}, {"seller_id": {"$exists": False}}]})
    return {
        "stores": stores,
        "teams": teams,
        "sellers": [{"id": s["id"], "name": nomes.get(s.get("user_id"), "—"), "store_id": s.get("store_id"), "team_id": s.get("team_id")} for s in sellers] + ([{"id": "__sem_vendedor__", "name": "Sem vendedor atribuído", "store_id": None, "team_id": None}] if sem_vendedor else []),
        "attendance_types": [
            {"id": "QUEUE", "name": "Fila"},
            {"id": "QUICK", "name": "Registro rápido"},
            {"id": "MANUAL", "name": "Manual"},
            {"id": "PREFERENCE", "name": "Preferência"},
            {"id": "MULTIPLE", "name": "Múltiplos atendimentos"},
        ],
    }


def _fmt_money(cents: int) -> str:
    return f"R$ {cents / 100:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def csv_response(report: dict) -> StreamingResponse:
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["Fluxo de Oportunidades por Horário"])
    writer.writerow(["Período", report["period"]["start"], report["period"]["end"], "Timezone", report["period"]["timezone"], "Granularidade", report["period"]["granularity"]])
    writer.writerow([])
    headers = ["Intervalo", "Oportunidades", "Oportunidades convertidas", "Vendas realizadas", "Conversão"]
    if report.get("can_view_financial"):
        headers += ["Receita", "Ticket médio"]
    writer.writerow(headers)
    for item in report["series"]:
        row = [item["label"], item["opportunities"], item["converted_opportunities"], item["sales"], f"{item['conversion_rate']:.2f}%"]
        if report.get("can_view_financial"):
            row += [_fmt_money(item.get("revenue", 0)), _fmt_money(item.get("average_ticket", 0))]
        writer.writerow(row)
    writer.writerow([])
    writer.writerow(["Vendas sem atendimento vinculado", report["data_quality"]["sales_without_attendance"]])
    content = "\ufeff" + output.getvalue()
    return StreamingResponse(iter([content.encode("utf-8")]), media_type="text/csv; charset=utf-8", headers={"Content-Disposition": "attachment; filename=fluxo_oportunidades_horario.csv", "Access-Control-Expose-Headers": "Content-Disposition"})


def xlsx_response(report: dict) -> StreamingResponse:
    headers = ["Intervalo", "Oportunidades", "Oportunidades convertidas", "Vendas realizadas", "Conversão"]
    if report.get("can_view_financial"):
        headers += ["Receita", "Ticket médio"]
    rows = [headers]
    for item in report["series"]:
        row = [item["label"], item["opportunities"], item["converted_opportunities"], item["sales"], round(item["conversion_rate"], 2)]
        if report.get("can_view_financial"):
            row += [item.get("revenue", 0) / 100, item.get("average_ticket", 0) / 100]
        rows.append(row)
    xml_rows = []
    for r, row in enumerate(rows, start=1):
        cells = []
        for c, val in enumerate(row, start=1):
            col = chr(64 + c)
            if isinstance(val, (int, float)):
                cells.append(f'<c r="{col}{r}"><v>{val}</v></c>')
            else:
                text = str(val).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                cells.append(f'<c r="{col}{r}" t="inlineStr"><is><t>{text}</t></is></c>')
        xml_rows.append(f'<row r="{r}">{"".join(cells)}</row>')
    sheet = f'<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>{"".join(xml_rows)}</sheetData></worksheet>'
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>')
        z.writestr("_rels/.rels", '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr("xl/workbook.xml", '<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Fluxo" sheetId="1" r:id="rId1"/></sheets></workbook>')
        z.writestr("xl/_rels/workbook.xml.rels", '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>')
        z.writestr("xl/worksheets/sheet1.xml", sheet)
    buf.seek(0)
    return StreamingResponse(iter([buf.getvalue()]), media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", headers={"Content-Disposition": "attachment; filename=fluxo_oportunidades_horario.xlsx", "Access-Control-Expose-Headers": "Content-Disposition"})