"""Autenticação tenant-scoped — Etapa 13.
Endpoints: POST /api/tenants/{slug}/auth/login
           POST /api/tenants/{slug}/auth/logout
           POST /api/tenants/{slug}/auth/password-reset/request
           POST /api/tenants/{slug}/auth/password-reset/confirm
           POST /api/tenants/{slug}/auth/change-password
"""
import os
import secrets
from datetime import datetime, timezone, timedelta
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel, EmailStr

from db import db
from models import LoginRequest, RefreshRequest, new_id, utcnow_iso
from security import (
    REFRESH_TOKEN_EXPIRES_DAYS,
    create_tenant_access_token,
    create_refresh_token_raw,
    get_current_user,
    hash_password,
    hash_token,
    verify_password,
)
from session_service import create_session, revoke_session, revoke_all_user_sessions
from security_event_service import log_security_event, SecurityEventType
from rate_limit_service import (
    check_rate_limit, make_rate_limit_dep, get_client_ip,
    check_email_lockout, record_failed_login, reset_email_lockout,
)
from audit import log_audit

_RESET_EXPIRES_HOURS = 1
_GENERIC_CRED_ERROR = "Credenciais inválidas."


def _get_frontend_url() -> str:
    return os.environ.get("FRONTEND_URL", "http://localhost:3000").rstrip("/")


def _cookie_secure(request: Request) -> bool:
    forwarded_proto = (request.headers.get("x-forwarded-proto") or "").split(",")[0].strip().lower()
    return forwarded_proto == "https" or request.url.scheme == "https" or os.environ.get("ENVIRONMENT") == "production"


class PasswordResetRequestPayload(BaseModel):
    email: EmailStr


class PasswordResetConfirmPayload(BaseModel):
    token: str
    new_password: str


class ChangePasswordPayload(BaseModel):
    current_password: str
    new_password: str

router = APIRouter(prefix="/tenants", tags=["tenant-auth"])


async def _issue_tenant_tokens(
    *,
    user: dict,
    tenant: dict,
    membership: dict,
    ip: Optional[str] = None,
    user_agent: Optional[str] = None,
) -> tuple:
    membership_id = membership.get("id", "")
    role = membership["role"]
    session = await create_session(
        user_id=user["id"],
        auth_context="TENANT",
        tenant_id=tenant["id"],
        tenant_slug=tenant["slug"],
        membership_id=membership_id,
        role=role,
        ip=ip,
        user_agent=user_agent,
    )
    access_token = create_tenant_access_token(
        user_id=user["id"],
        email=user["email"],
        tenant_id=tenant["id"],
        tenant_slug=tenant["slug"],
        membership_id=membership_id,
        role=role,
        session_id=session["id"],
    )
    refresh_raw = create_refresh_token_raw()
    refresh_hash = hash_token(refresh_raw)
    family_id = new_id()
    expires_at = (
        datetime.now(timezone.utc) + timedelta(days=REFRESH_TOKEN_EXPIRES_DAYS)
    ).isoformat()
    await db.refresh_tokens.insert_one(
        {
            "id": new_id(),
            "session_id": session["id"],
            "user_id": user["id"],
            "tenant_id": tenant["id"],
            "token_hash": refresh_hash,
            "family_id": family_id,
            "created_at": utcnow_iso(),
            "expires_at": expires_at,
            "rotated_at": None,
            "revoked_at": None,
            "reuse_detected_at": None,
            "ip": ip,
            "user_agent": user_agent,
        }
    )
    return access_token, refresh_raw, session


@router.post("/{tenant_slug}/auth/login")
async def tenant_login(tenant_slug: str, payload: LoginRequest, request: Request, response: Response):
    ip = get_client_ip(request)
    user_agent = request.headers.get("user-agent")
    email = payload.email.lower().strip()

    # Rate limit: IP + email + tenant_slug
    rl_key = f"{ip}:{email}:{tenant_slug}"
    allowed, retry_after = await check_rate_limit(rl_key, "AUTH_LOGIN")
    if not allowed:
        await log_security_event(
            event_type=SecurityEventType.RATE_LIMIT_EXCEEDED,
            tenant_slug=tenant_slug,
            ip=ip,
            user_agent=user_agent,
            metadata={"email_hint": email[:3] + "***", "group": "AUTH_LOGIN"},
            request=request,
        )
        raise HTTPException(
            status_code=429,
            headers={"Retry-After": str(retry_after or 60)},
            detail={
                "error": "RATE_LIMIT_EXCEEDED",
                "message": "Muitas tentativas de login. Tente novamente em alguns instantes.",
                "retry_after_seconds": retry_after or 60,
            },
        )

    # Lockout por conta: verificar se e-mail já atingiu o limite de falhas
    lockout_ok, _lockout_retry = await check_email_lockout(email, tenant_slug)
    if not lockout_ok:
        await log_security_event(
            event_type=SecurityEventType.LOGIN_FAILED,
            tenant_slug=tenant_slug,
            ip=ip,
            user_agent=user_agent,
            metadata={"reason": "account_lockout", "email_hint": email[:3] + "***"},
            request=request,
        )
        # Mesma mensagem genérica — não revelamos que a conta está bloqueada
        raise HTTPException(status_code=401, detail={"error": "INVALID_CREDENTIALS", "message": _GENERIC_CRED_ERROR})

    # Resolver tenant
    tenant = await db.tenants.find_one({"slug": tenant_slug})
    if not tenant:
        # Não revelar se tenant existe
        raise HTTPException(status_code=401, detail={"error": "INVALID_CREDENTIALS", "message": _GENERIC_CRED_ERROR})
    if tenant.get("status") not in ("ACTIVE", "TRIAL"):
        await log_security_event(
            event_type=SecurityEventType.TENANT_SUSPENDED_ACCESS_ATTEMPT,
            tenant_id=tenant["id"],
            tenant_slug=tenant_slug,
            ip=ip,
            user_agent=user_agent,
            request=request,
        )
        raise HTTPException(status_code=403, detail="Empresa não está ativa.")

    # Validar usuário
    user = await db.users.find_one({"email": email})
    if not user or user.get("status") != "ACTIVE":
        await record_failed_login(email, tenant_slug)
        await log_security_event(
            event_type=SecurityEventType.LOGIN_FAILED,
            tenant_id=tenant["id"],
            tenant_slug=tenant_slug,
            ip=ip,
            user_agent=user_agent,
            metadata={"reason": "user_not_found_or_inactive"},
            request=request,
        )
        raise HTTPException(status_code=401, detail={"error": "INVALID_CREDENTIALS", "message": _GENERIC_CRED_ERROR})

    if not verify_password(payload.password, user["password_hash"]):
        await record_failed_login(email, tenant_slug)
        await log_security_event(
            event_type=SecurityEventType.LOGIN_FAILED,
            tenant_id=tenant["id"],
            tenant_slug=tenant_slug,
            user_id=user["id"],
            ip=ip,
            user_agent=user_agent,
            metadata={"reason": "wrong_password"},
            request=request,
        )
        raise HTTPException(status_code=401, detail={"error": "INVALID_CREDENTIALS", "message": _GENERIC_CRED_ERROR})

    # Validar membership
    membership = await db.tenant_memberships.find_one(
        {"tenant_id": tenant["id"], "user_id": user["id"], "status": "ACTIVE"}
    )
    if not membership:
        await record_failed_login(email, tenant_slug)
        await log_security_event(
            event_type=SecurityEventType.LOGIN_FAILED,
            tenant_id=tenant["id"],
            tenant_slug=tenant_slug,
            user_id=user["id"],
            ip=ip,
            user_agent=user_agent,
            metadata={"reason": "no_membership"},
            request=request,
        )
        raise HTTPException(status_code=401, detail={"error": "INVALID_CREDENTIALS", "message": _GENERIC_CRED_ERROR})

    membership.pop("_id", None)

    # Login bem-sucedido: resetar contador de tentativas falhadas
    await reset_email_lockout(email, tenant_slug)

    # Emitir tokens
    access_token, refresh_raw, session = await _issue_tenant_tokens(
        user=user,
        tenant=tenant,
        membership=membership,
        ip=ip,
        user_agent=user_agent,
    )

    await db.users.update_one(
        {"id": user["id"]},
        {"$set": {"last_login_at": utcnow_iso(), "updated_at": utcnow_iso()}},
    )

    await log_security_event(
        event_type=SecurityEventType.LOGIN_SUCCESS,
        tenant_id=tenant["id"],
        tenant_slug=tenant_slug,
        user_id=user["id"],
        session_id=session["id"],
        ip=ip,
        user_agent=user_agent,
        request=request,
    )

    await log_audit(
        action="TENANT_LOGIN",
        entity="user",
        entity_id=user["id"],
        tenant_id=tenant["id"],
        user_id=user["id"],
        request=request,
    )

    secure_cookie = _cookie_secure(request)
    response.set_cookie(
        key="access_token",
        value=access_token,
        httponly=True,
        secure=secure_cookie,
        samesite="lax",
        max_age=60 * 15,
        path="/",
    )
    response.set_cookie(
        key="refresh_token",
        value=refresh_raw,
        httponly=True,
        secure=secure_cookie,
        samesite="lax",
        max_age=REFRESH_TOKEN_EXPIRES_DAYS * 24 * 60 * 60,
        path="/",
    )

    return {
        "access_token": access_token,
        "refresh_token": refresh_raw,
        "token_type": "bearer",
        "auth_context": "TENANT",
        "tenant_slug": tenant["slug"],
        "tenant_id": tenant["id"],
        "session_id": session["id"],
        "user": {
            "id": user["id"],
            "name": user["name"],
            "email": user["email"],
            "is_super_admin": False,
        },
        "membership": {
            "role": membership["role"],
            "store_ids": membership.get("store_ids", []),
        },
    }


@router.post("/{tenant_slug}/auth/logout")
async def tenant_logout(
    tenant_slug: str,
    payload: RefreshRequest | None = None,
    request: Request = None,
    user: dict = Depends(get_current_user),
):
    token_payload = getattr(request.state, "token_payload", {}) if request else {}
    session_id = token_payload.get("session_id")
    tenant_id = token_payload.get("tenant_id")

    if session_id:
        await revoke_session(session_id, "LOGOUT")

    if payload and payload.refresh_token:
        token_hash = hash_token(payload.refresh_token)
        await db.refresh_tokens.update_one(
            {"token_hash": token_hash},
            {"$set": {"revoked_at": utcnow_iso()}},
        )

    await log_security_event(
        event_type=SecurityEventType.LOGOUT,
        tenant_id=tenant_id,
        tenant_slug=tenant_slug,
        user_id=user["id"],
        session_id=session_id,
        request=request,
    )

    return {"message": "Logout efetuado."}



# ─── Solicitar redefinição de senha ─────────────────────────────────────────
@router.post(
    "/{tenant_slug}/auth/password-reset/request",
    dependencies=[Depends(make_rate_limit_dep("INVITE_SEND"))],
)
async def request_password_reset(
    tenant_slug: str,
    payload: PasswordResetRequestPayload,
    request: Request,
):
    """Gera token de redefinição de senha e envia e-mail.

    Sempre retorna 200 (não revela se o e-mail existe).
    """
    from external_notification_service import send_password_reset_email

    ip = get_client_ip(request)
    email = payload.email.lower().strip()

    # Resolver tenant
    tenant = await db.tenants.find_one({"slug": tenant_slug})
    if not tenant or tenant.get("status") not in ("ACTIVE", "TRIAL"):
        # Retorna 200 mesmo assim para não revelar existência do tenant
        return {"message": "Se o e-mail estiver cadastrado, você receberá as instruções em breve."}

    user = await db.users.find_one({"email": email})

    # Só procede se usuário existe E tem membership ativa neste tenant
    membership = None
    if user:
        membership = await db.tenant_memberships.find_one(
            {"tenant_id": tenant["id"], "user_id": user["id"], "status": "ACTIVE"}
        )

    if user and membership:
        # Revogar tokens não usados anteriores
        now_dt = datetime.now(timezone.utc)
        await db.password_reset_tokens.update_many(
            {
                "user_id": user["id"],
                "tenant_id": tenant["id"],
                "used_at": None,
                "expires_at": {"$gt": now_dt},
            },
            {"$set": {"revoked_at": now_dt.isoformat()}},
        )

        # Gerar novo token
        token_raw = secrets.token_urlsafe(32)
        token_hash = hash_token(token_raw)
        await db.password_reset_tokens.insert_one(
            {
                "id": new_id(),
                "token_hash": token_hash,
                "user_id": user["id"],
                "tenant_id": tenant["id"],
                "email": email,
                "created_at": utcnow_iso(),
                "expires_at": now_dt + timedelta(hours=_RESET_EXPIRES_HOURS),
                "used_at": None,
                "revoked_at": None,
            }
        )

        reset_link = (
            f"{_get_frontend_url()}/redefinir-senha"
            f"?token={token_raw}&slug={tenant_slug}"
        )

        await send_password_reset_email(
            to_email=email,
            to_name=user.get("name", ""),
            reset_link=reset_link,
            tenant_name=tenant["name"],
            tenant_id=tenant["id"],
        )

        await log_security_event(
            event_type=SecurityEventType.INVITE_SENT,
            tenant_id=tenant["id"],
            tenant_slug=tenant_slug,
            user_id=user["id"],
            ip=ip,
            metadata={"action": "PASSWORD_RESET_REQUEST", "email": email[:3] + "***"},
            request=request,
        )

    return {"message": "Se o e-mail estiver cadastrado, você receberá as instruções em breve."}


# ─── Confirmar redefinição de senha ─────────────────────────────────────────
@router.post("/{tenant_slug}/auth/password-reset/confirm")
async def confirm_password_reset(
    tenant_slug: str,
    payload: PasswordResetConfirmPayload,
    request: Request,
):
    """Valida token e define nova senha."""
    if not payload.new_password or len(payload.new_password) < 8:
        raise HTTPException(status_code=422, detail="A nova senha deve ter pelo menos 8 caracteres.")

    token_hash = hash_token(payload.token)
    now_dt = datetime.now(timezone.utc)

    stored = await db.password_reset_tokens.find_one({"token_hash": token_hash})

    if not stored:
        raise HTTPException(status_code=400, detail="Link de redefinição inválido ou expirado.")

    if stored.get("used_at"):
        raise HTTPException(status_code=400, detail="Este link já foi utilizado. Solicite uma nova redefinição.")

    if stored.get("revoked_at"):
        raise HTTPException(status_code=400, detail="Link de redefinição inválido. Solicite um novo.")

    # Verificar expiração (campo expires_at pode ser datetime BSON ou ISO string)
    expires_at = stored["expires_at"]
    if isinstance(expires_at, str):
        expires_at = datetime.fromisoformat(expires_at)
    if expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=timezone.utc)
    if expires_at < now_dt:
        raise HTTPException(status_code=400, detail="Link de redefinição expirado. Solicite um novo.")

    # Resolver tenant para confirmar scope
    tenant = await db.tenants.find_one({"slug": tenant_slug})
    if not tenant or tenant["id"] != stored["tenant_id"]:
        raise HTTPException(status_code=400, detail="Link de redefinição inválido.")

    # Atualizar senha
    new_hash = hash_password(payload.new_password)
    await db.users.update_one(
        {"id": stored["user_id"]},
        {"$set": {"password_hash": new_hash, "updated_at": utcnow_iso()}},
    )

    # Marcar token como usado
    await db.password_reset_tokens.update_one(
        {"token_hash": token_hash},
        {"$set": {"used_at": utcnow_iso()}},
    )

    # Revogar todas as sessões ativas do usuário (força re-login)
    await revoke_all_user_sessions(stored["user_id"], tenant_id=stored["tenant_id"], reason="PASSWORD_RESET")
    await db.refresh_tokens.update_many(
        {"user_id": stored["user_id"], "tenant_id": stored["tenant_id"], "revoked_at": None},
        {"$set": {"revoked_at": utcnow_iso()}},
    )

    await log_security_event(
        event_type=SecurityEventType.LOGIN_SUCCESS,
        tenant_id=tenant["id"],
        tenant_slug=tenant_slug,
        user_id=stored["user_id"],
        metadata={"action": "PASSWORD_RESET_CONFIRMED"},
        request=request,
    )

    return {"message": "Senha redefinida com sucesso. Faça login com sua nova senha."}


# ─── Alterar senha (usuário logado) ──────────────────────────────────────────
@router.post("/{tenant_slug}/auth/change-password")
async def change_password(
    tenant_slug: str,
    payload: ChangePasswordPayload,
    request: Request,
    user: dict = Depends(get_current_user),
):
    """Altera a senha do usuário autenticado."""
    if not payload.new_password or len(payload.new_password) < 8:
        raise HTTPException(status_code=422, detail="A nova senha deve ter pelo menos 8 caracteres.")

    # get_current_user strips password_hash for security; fetch it fresh for verification
    user_with_hash = await db.users.find_one({"id": user["id"]}, {"password_hash": 1})
    if not user_with_hash:
        raise HTTPException(status_code=404, detail="Usuário não encontrado.")
    if not verify_password(payload.current_password, user_with_hash.get("password_hash", "")):
        raise HTTPException(status_code=400, detail="Senha atual incorreta.")

    new_hash = hash_password(payload.new_password)
    await db.users.update_one(
        {"id": user["id"]},
        {"$set": {"password_hash": new_hash, "updated_at": utcnow_iso()}},
    )

    return {"message": "Senha alterada com sucesso."}
