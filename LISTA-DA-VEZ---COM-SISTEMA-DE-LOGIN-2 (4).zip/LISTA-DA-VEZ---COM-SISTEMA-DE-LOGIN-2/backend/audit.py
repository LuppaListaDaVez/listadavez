"""Audit log helper."""
from typing import Optional, Any
from fastapi import Request

from db import db
from models import new_id, utcnow_iso


async def log_audit(
    *,
    action: str,
    entity: str,
    entity_id: Optional[str] = None,
    tenant_id: Optional[str] = None,
    store_id: Optional[str] = None,
    user_id: Optional[str] = None,
    old_value: Any = None,
    new_value: Any = None,
    request: Optional[Request] = None,
):
    ip = None
    user_agent = None
    if request is not None:
        ip = request.client.host if request.client else None
        user_agent = request.headers.get("user-agent")
    await db.audit_logs.insert_one(
        {
            "id": new_id(),
            "tenant_id": tenant_id,
            "store_id": store_id,
            "user_id": user_id,
            "action": action,
            "entity": entity,
            "entity_id": entity_id,
            "old_value": old_value,
            "new_value": new_value,
            "ip": ip,
            "user_agent": user_agent,
            "created_at": utcnow_iso(),
        }
    )
