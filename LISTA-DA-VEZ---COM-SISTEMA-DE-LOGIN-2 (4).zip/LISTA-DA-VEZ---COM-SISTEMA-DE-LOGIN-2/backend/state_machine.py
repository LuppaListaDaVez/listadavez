"""SellerStateMachine — única forma de mudar current_status do vendedor."""
from typing import Optional
from fastapi import HTTPException, Request

from db import db
from models import new_id, utcnow_iso
from audit import log_audit

ALLOWED_TRANSITIONS = {
    "OFFLINE": {"AVAILABLE", "ABSENT", "BLOCKED", "BREAK", "LUNCH", "MEETING", "TRAINING"},
    "AVAILABLE": {"BREAK", "LUNCH", "MEETING", "TRAINING", "ABSENT", "OFFLINE", "BLOCKED", "WAITING_IN_QUEUE", "SERVING"},
    "BREAK": {"AVAILABLE", "OFFLINE", "BLOCKED", "LUNCH", "MEETING", "ABSENT", "WAITING_IN_QUEUE"},
    "LUNCH": {"AVAILABLE", "OFFLINE", "BLOCKED", "BREAK", "MEETING", "ABSENT", "WAITING_IN_QUEUE"},
    "MEETING": {"AVAILABLE", "OFFLINE", "BLOCKED", "BREAK", "LUNCH", "ABSENT", "WAITING_IN_QUEUE"},
    "TRAINING": {"AVAILABLE", "OFFLINE", "BLOCKED", "WAITING_IN_QUEUE"},
    "ABSENT": {"AVAILABLE", "OFFLINE", "BLOCKED", "BREAK", "LUNCH", "MEETING", "WAITING_IN_QUEUE"},
    "BLOCKED": {"AVAILABLE"},
    # Vendedor na fila pode sair para status operacional (via sair_da_fila) ou entrar em atendimento
    "WAITING_IN_QUEUE": {"AVAILABLE", "SERVING", "OFFLINE", "BREAK", "LUNCH", "MEETING", "ABSENT"},
    "SERVING": {"AVAILABLE"},
}

# Targets not yet operational in Etapa 2
DEFERRED_STATES = {"WAITING_IN_QUEUE", "SERVING"}

# Allowed self-transitions for SELLER role
_SELF_STATUS_SET = {"AVAILABLE", "OFFLINE", "BREAK", "LUNCH", "MEETING", "ABSENT"}
SELLER_SELF_TRANSITIONS = {
    (src, dst)
    for src in _SELF_STATUS_SET | {"WAITING_IN_QUEUE"}
    for dst in _SELF_STATUS_SET
    if src != dst
}

REASON_REQUIRED_TARGETS = {"BLOCKED", "ABSENT", "OFFLINE"}

# Estados considerados "Fora" da operação (mapeiam para FORA na UI)
AWAY_STATES = {"BREAK", "LUNCH", "OFFLINE", "MEETING", "TRAINING", "ABSENT"}

# Mapeamento de motivos em português → estado interno
MOTIVO_PARA_ESTADO = {
    "LANCHE_OU_ALMOCO": "BREAK",
    "ENCERRAR_DIA": "OFFLINE",
    # ATIVIDADE_OPERACIONAL não muda o estado — permanece WAITING_IN_QUEUE com sub-flag
}

# Mapeamento de estado interno → label em português (compatibilidade)
ESTADO_PARA_PT = {
    "AVAILABLE": "DISPONIVEL",
    "WAITING_IN_QUEUE": "NA_FILA_GERAL",
    "SERVING": "EM_ATENDIMENTO",
    "BREAK": "FORA",
    "LUNCH": "FORA",
    "OFFLINE": "FORA",
    "MEETING": "FORA",
    "TRAINING": "FORA",
    "ABSENT": "FORA",
    "BLOCKED": "BLOQUEADO",
}

MOTIVO_PT_LABEL = {
    "LANCHE_OU_ALMOCO": "Lanche ou almoço",
    "ATIVIDADE_OPERACIONAL": "Atividade operacional",
    "ENCERRAR_DIA": "Encerramento do dia",
}


async def change_state(
    *,
    tenant_id: str,
    store_id: str,
    seller_id: str,
    to_state: str,
    actor_user_id: str,
    actor_role: str,
    reason: Optional[str] = None,
    is_self: bool = False,
    via_queue_engine: bool = False,
    request: Optional[Request] = None,
):
    seller = await db.seller_profiles.find_one(
        {"id": seller_id, "tenant_id": tenant_id}
    )
    if not seller:
        raise HTTPException(status_code=404, detail="Vendedor não encontrado.")
    if seller["store_id"] != store_id:
        raise HTTPException(status_code=404, detail="Vendedor não pertence a esta unidade.")

    from_state = seller.get("current_status", "OFFLINE")

    if to_state in DEFERRED_STATES and not via_queue_engine:
        raise HTTPException(
            status_code=409,
            detail={
                "error": "USE_QUEUE_ENDPOINTS",
                "message": "Use os endpoints da Lista da Vez para colocar o vendedor na fila ou em atendimento.",
            },
        )

    allowed = ALLOWED_TRANSITIONS.get(from_state, set())
    if to_state not in allowed:
        raise HTTPException(
            status_code=409,
            detail={
                "error": "TRANSICAO_DE_ESTADO_INVALIDA",
                "message": "Transição de estado inválida para este vendedor.",
                "estado_atual": ESTADO_PARA_PT.get(from_state, from_state),
                "estado_destino": ESTADO_PARA_PT.get(to_state, to_state),
            },
        )

    # SELLER permission gates (skipped when initiated by QueueEngine)
    if not via_queue_engine:
        if actor_role == "SELLER":
            if not is_self:
                raise HTTPException(status_code=403, detail="Vendedor só pode alterar o próprio status.")
            if (from_state, to_state) not in SELLER_SELF_TRANSITIONS:
                raise HTTPException(status_code=403, detail="Transição não permitida para o seu papel.")
        elif actor_role == "SUPERVISOR" and to_state == "BLOCKED":
            raise HTTPException(status_code=403, detail="Supervisor não pode bloquear vendedor.")

        if from_state == "BLOCKED" and actor_role not in {"TENANT_ADMIN", "STORE_MANAGER"}:
            raise HTTPException(status_code=403, detail="Apenas Admin ou Gerente podem desbloquear.")

    if not is_self and to_state in REASON_REQUIRED_TARGETS and not (reason and reason.strip()):
        raise HTTPException(status_code=400, detail="Motivo é obrigatório para esta transição.")
    if not via_queue_engine and not is_self and not (reason and reason.strip()):
        raise HTTPException(status_code=400, detail="Motivo é obrigatório quando outro usuário altera o status.")

    now = utcnow_iso()
    await db.seller_profiles.update_one(
        {"id": seller_id},
        {"$set": {"current_status": to_state, "updated_at": now}},
    )
    await db.seller_status_logs.insert_one(
        {
            "id": new_id(),
            "tenant_id": tenant_id,
            "store_id": store_id,
            "seller_id": seller_id,
            "user_id": seller["user_id"],
            "old_status": from_state,
            "new_status": to_state,
            "old_status_pt": ESTADO_PARA_PT.get(from_state, from_state),
            "new_status_pt": ESTADO_PARA_PT.get(to_state, to_state),
            "reason": reason,
            "changed_by": actor_user_id,
            "created_at": now,
        }
    )

    action = "SELLER_STATUS_CHANGED"
    if to_state == "BLOCKED":
        action = "SELLER_BLOCKED"
    elif from_state == "BLOCKED":
        action = "SELLER_UNBLOCKED"

    await log_audit(
        action=action,
        entity="seller_profile",
        entity_id=seller_id,
        tenant_id=tenant_id,
        store_id=store_id,
        user_id=actor_user_id,
        old_value={"current_status": from_state},
        new_value={"current_status": to_state, "reason": reason},
        request=request,
    )

    updated = await db.seller_profiles.find_one({"id": seller_id})
    updated.pop("_id", None)
    return updated

