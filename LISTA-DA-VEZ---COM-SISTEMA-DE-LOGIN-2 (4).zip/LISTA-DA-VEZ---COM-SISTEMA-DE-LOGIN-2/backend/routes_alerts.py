"""Endpoints de Alertas — Etapa 12."""
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from security import resolve_tenant_context
from feature_guard import require_feature
from permissions import ROLE_PERMISSIONS, P_ALERTS_VIEW_SELF, P_ALERTS_VIEW_STORE, P_ALERTS_VIEW_TENANT, P_ALERTS_ACK_SELF, P_ALERTS_ACK_ANY, P_ALERTS_RESOLVE, P_ALERTS_SETTINGS_VIEW, P_ALERTS_SETTINGS_UPDATE
import alert_service as svc
from db import db

router = APIRouter(prefix="/tenants/{tenant_slug}", tags=["alerts"])


def _has(role, *perms):
    rp = ROLE_PERMISSIONS.get(role, [])
    return any(p in rp for p in perms)


@router.get("/alerts")
async def list_alerts(
    status: Optional[str] = None,
    severity: Optional[str] = None,
    alert_type: Optional[str] = None,
    store_id: Optional[str] = None,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "alertas_inteligentes")
    role = ctx["membership"]["role"]
    if not _has(role, P_ALERTS_VIEW_SELF, P_ALERTS_VIEW_STORE, P_ALERTS_VIEW_TENANT):
        raise HTTPException(status_code=403, detail="Sem permissão.")
    filters = {"status": status, "severity": severity, "alert_type": alert_type, "store_id": store_id}
    return await svc.list_alerts(ctx["tenant"]["id"], ctx["membership"], ctx["user"]["id"], filters)


@router.get("/alerts/{alert_id}")
async def get_alert(alert_id: str, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "alertas_inteligentes")
    doc = await db.alert_events.find_one({"tenant_id": ctx["tenant"]["id"], "id": alert_id})
    if not doc:
        raise HTTPException(status_code=404, detail="Alerta não encontrado.")
    doc.pop("_id", None)
    return doc


@router.post("/alerts/{alert_id}/acknowledge")
async def acknowledge(alert_id: str, request: Request, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "alertas_inteligentes")
    if not _has(ctx["membership"]["role"], P_ALERTS_ACK_SELF, P_ALERTS_ACK_ANY):
        raise HTTPException(status_code=403, detail="Sem permissão.")
    result = await svc.acknowledge_alert(ctx["tenant"]["id"], alert_id, ctx["user"]["id"])
    if not result:
        raise HTTPException(status_code=404, detail="Alerta não encontrado.")
    return result


@router.post("/alerts/{alert_id}/resolve")
async def resolve(alert_id: str, request: Request, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "alertas_inteligentes")
    if not _has(ctx["membership"]["role"], P_ALERTS_RESOLVE):
        raise HTTPException(status_code=403, detail="Sem permissão.")
    result = await svc.resolve_alert(ctx["tenant"]["id"], alert_id, ctx["user"]["id"])
    if not result:
        raise HTTPException(status_code=404, detail="Alerta não encontrado.")
    return result


# ─── Alert Rules ──────────────────────────────────────────────────────────────

class AlertRuleCreate(BaseModel):
    name: str
    description: Optional[str] = None
    alert_type: str
    severity: str = "WARNING"
    is_active: bool = True


@router.get("/alert-rules")
async def list_alert_rules(ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "alertas_inteligentes")
    if not _has(ctx["membership"]["role"], P_ALERTS_SETTINGS_VIEW):
        raise HTTPException(status_code=403, detail="Sem permissão.")
    raw = await db.alert_rules.find({"tenant_id": ctx["tenant"]["id"]}).to_list(100)
    for d in raw:
        d.pop("_id", None)
    return raw


@router.post("/alert-rules")
async def create_alert_rule(payload: AlertRuleCreate, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "alertas_inteligentes")
    if not _has(ctx["membership"]["role"], P_ALERTS_SETTINGS_UPDATE):
        raise HTTPException(status_code=403, detail="Sem permissão.")
    from models import new_id, utcnow_iso
    now = utcnow_iso()
    doc = {
        "id": new_id(), "tenant_id": ctx["tenant"]["id"],
        **payload.model_dump(),
        "conditions": [], "target_roles": [], "target_store_ids": [],
        "created_by": ctx["user"]["id"],
        "created_at": now, "updated_at": now,
    }
    await db.alert_rules.insert_one(doc)
    doc.pop("_id", None)
    return doc


@router.put("/alert-rules/{rule_id}")
async def update_alert_rule(rule_id: str, payload: AlertRuleCreate, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "alertas_inteligentes")
    if not _has(ctx["membership"]["role"], P_ALERTS_SETTINGS_UPDATE):
        raise HTTPException(status_code=403, detail="Sem permissão.")
    from models import utcnow_iso
    updates = {**payload.model_dump(), "updated_at": utcnow_iso()}
    await db.alert_rules.update_one({"tenant_id": ctx["tenant"]["id"], "id": rule_id}, {"$set": updates})
    doc = await db.alert_rules.find_one({"id": rule_id})
    if not doc:
        raise HTTPException(status_code=404)
    doc.pop("_id", None)
    return doc


@router.post("/alert-rules/{rule_id}/enable")
async def enable_alert_rule(rule_id: str, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "alertas_inteligentes")
    if not _has(ctx["membership"]["role"], P_ALERTS_SETTINGS_UPDATE):
        raise HTTPException(status_code=403, detail="Sem permissão.")
    from models import utcnow_iso
    await db.alert_rules.update_one({"tenant_id": ctx["tenant"]["id"], "id": rule_id}, {"$set": {"is_active": True, "updated_at": utcnow_iso()}})
    return {"enabled": True}


@router.post("/alert-rules/{rule_id}/disable")
async def disable_alert_rule(rule_id: str, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "alertas_inteligentes")
    if not _has(ctx["membership"]["role"], P_ALERTS_SETTINGS_UPDATE):
        raise HTTPException(status_code=403, detail="Sem permissão.")
    from models import utcnow_iso
    await db.alert_rules.update_one({"tenant_id": ctx["tenant"]["id"], "id": rule_id}, {"$set": {"is_active": False, "updated_at": utcnow_iso()}})
    return {"disabled": True}


# ─── Generate Alerts (manual trigger) ─────────────────────────────────────────

@router.post("/alerts/generate")
async def trigger_smart_alerts(ctx: dict = Depends(resolve_tenant_context)):
    """Dispara geração manual de alertas inteligentes (para admins)."""
    await require_feature(ctx["tenant"]["id"], "alertas_inteligentes")
    if not _has(ctx["membership"]["role"], P_ALERTS_SETTINGS_UPDATE):
        raise HTTPException(status_code=403, detail="Sem permissão.")
    await svc.generate_smart_alerts(ctx["tenant"]["id"])
    return {"triggered": True}
