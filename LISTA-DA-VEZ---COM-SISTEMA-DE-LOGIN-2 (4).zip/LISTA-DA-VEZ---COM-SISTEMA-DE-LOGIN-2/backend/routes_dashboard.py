"""Dashboard KPIs — P1: eliminado N+1 com agregações MongoDB + cache TTL 15s."""
from datetime import datetime, timezone, timedelta
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException

from db import db
from security import resolve_tenant_context
from feature_guard import require_feature
from permission_service import require_permission, get_accessible_store_ids
from cache_service import cache, key_dashboard, TTL

router = APIRouter(prefix="/tenants/{tenant_slug}/dashboard", tags=["dashboard"])

# SELLER (dashboard.view_self) não tem acesso ao dashboard principal
DASHBOARD_PERMS = ("dashboard.view_store", "dashboard.view_tenant")


def _date_range(date_from: Optional[str], date_to: Optional[str]):
    """Converte datas YYYY-MM-DD em ISO UTC start/end. Padrão: hoje."""
    now = datetime.now(timezone.utc)
    if date_from:
        try:
            start = datetime.strptime(date_from, "%Y-%m-%d").replace(tzinfo=timezone.utc)
        except ValueError:
            start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    else:
        start = now.replace(hour=0, minute=0, second=0, microsecond=0)

    if date_to:
        try:
            end_base = datetime.strptime(date_to, "%Y-%m-%d").replace(tzinfo=timezone.utc)
            end = end_base.replace(hour=23, minute=59, second=59, microsecond=999999)
        except ValueError:
            end = now.replace(hour=23, minute=59, second=59, microsecond=999999)
    else:
        end = now.replace(hour=23, minute=59, second=59, microsecond=999999)

    # Limitar máximo a 31 dias para evitar queries muito pesadas
    max_end = start + timedelta(days=30)
    if end > max_end:
        end = max_end.replace(hour=23, minute=59, second=59, microsecond=999999)

    return start.isoformat(), end.isoformat()


def _has_dashboard_perm(role: str) -> bool:
    from permissions import ROLE_PERMISSIONS
    return any(p in ROLE_PERMISSIONS.get(role, []) for p in DASHBOARD_PERMS)


@router.get("/summary")
async def dashboard_summary(
    store_id: Optional[str] = None,
    seller_id: Optional[str] = None,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "dashboards")
    role = ctx["membership"]["role"]
    tenant_id = ctx["tenant"]["id"]
    if not _has_dashboard_perm(role):
        raise HTTPException(status_code=403, detail="Sem permissão para visualizar o dashboard.")

    accessible_store_ids = await get_accessible_store_ids(ctx["membership"], tenant_id)
    period_start, period_end = _date_range(date_from, date_to)

    if store_id:
        if store_id not in accessible_store_ids:
            raise HTTPException(status_code=403, detail="Sem acesso a esta unidade.")
        store_filter_ids = [store_id]
    else:
        store_filter_ids = accessible_store_ids

    # Filtro por vendedor explícito (manager/admin filtrando um vendedor específico)
    seller_filter_id = None
    if seller_id:
        # Validar que o vendedor pertence às lojas acessíveis
        sp = await db.seller_profiles.find_one(
            {"id": seller_id, "tenant_id": tenant_id, "store_id": {"$in": store_filter_ids}}
        )
        if not sp:
            raise HTTPException(status_code=403, detail="Vendedor não encontrado ou sem acesso.")
        seller_filter_id = seller_id

    # Cache key inclui tenant + scope + datas
    scope = store_id or "all"
    if seller_filter_id:
        scope = f"seller:{seller_filter_id}"
    cache_key = key_dashboard(tenant_id, scope, f"{date_from or 'today'}_{date_to or 'today'}")
    cached = cache.get(cache_key)
    if cached:
        return cached

    # ─── KPIs do período — aggregation ───────────────────────────────────────
    att_match: dict = {
        "tenant_id": tenant_id,
        "store_id": {"$in": store_filter_ids},
        "created_at": {"$gte": period_start, "$lte": period_end},
    }
    if seller_filter_id:
        att_match["seller_id"] = seller_filter_id

    kpi_pipeline = [
        {"$match": att_match},
        {"$group": {
            "_id": "$status",
            "count": {"$sum": 1},
            "vendas": {"$sum": {"$cond": [{"$and": [{"$eq": ["$status", "FINISHED"]}, {"$eq": ["$result", "SALE"]}]}, 1, 0]}},
            "total_cents": {"$sum": {"$cond": [{"$and": [{"$eq": ["$status", "FINISHED"]}, {"$eq": ["$result", "SALE"]}]}, {"$ifNull": ["$sale_amount_cents", 0]}, 0]}},
            "total_produtos": {"$sum": {"$cond": [{"$and": [{"$eq": ["$status", "FINISHED"]}, {"$eq": ["$result", "SALE"]}]}, {"$ifNull": ["$product_quantity", 0]}, 0]}},
        }},
    ]
    kpi_agg = await db.attendances.aggregate(kpi_pipeline).to_list(20)
    status_counts = {r["_id"]: r for r in kpi_agg}

    finished_data = status_counts.get("FINISHED", {})
    in_progress_data = status_counts.get("IN_PROGRESS", {})
    total_atts_today = sum(r["count"] for r in kpi_agg)
    finished_today_n = finished_data.get("count", 0)
    in_progress_n = in_progress_data.get("count", 0)
    sales_today_n = finished_data.get("vendas", 0)
    total_sold_cents = finished_data.get("total_cents", 0)
    total_produtos_vendidos = finished_data.get("total_produtos", 0)
    avg_ticket_cents = round(total_sold_cents / sales_today_n) if sales_today_n else 0
    conversion_pct = round(sales_today_n / finished_today_n * 100) if finished_today_n else 0
    pa = round(total_produtos_vendidos / sales_today_n, 2) if sales_today_n else 0.0

    # Tempo médio
    if finished_today_n > 0:
        fin_match = {**att_match, "status": "FINISHED",
                     "started_at": {"$ne": None}, "finished_at": {"$ne": None}}
        dur_pipeline = [
            {"$match": fin_match},
            {"$project": {
                "_id": 0,
                "duration": {"$divide": [
                    {"$subtract": [
                        {"$toLong": {"$dateFromString": {"dateString": "$finished_at"}}},
                        {"$toLong": {"$dateFromString": {"dateString": "$started_at"}}},
                    ]}, 1000
                ]},
            }},
            {"$group": {"_id": None, "avg_duration": {"$avg": "$duration"}}},
        ]
        try:
            dur_result = await db.attendances.aggregate(dur_pipeline).to_list(1)
            avg_duration_seconds = round(dur_result[0]["avg_duration"]) if dur_result else 0
        except Exception:
            avg_duration_seconds = 0
    else:
        avg_duration_seconds = 0

    # ─── Sellers por status ───────────────────────────────────────────────────
    sellers_match: dict = {"tenant_id": tenant_id, "status": "ACTIVE"}
    if store_filter_ids:
        sellers_match["store_id"] = {"$in": store_filter_ids}
    if seller_filter_id:
        sellers_match["id"] = seller_filter_id
    sellers_agg = await db.seller_profiles.aggregate([
        {"$match": sellers_match},
        {"$group": {"_id": "$current_status", "count": {"$sum": 1}}},
    ]).to_list(20)
    sellers_by_status = {r["_id"]: r["count"] for r in sellers_agg}

    # ─── Tendência do período (agrupada por dia) ──────────────────────────────
    trend_match: dict = {
        "tenant_id": tenant_id,
        "store_id": {"$in": store_filter_ids},
        "status": "FINISHED",
        "finished_at": {"$gte": period_start, "$lte": period_end},
    }
    if seller_filter_id:
        trend_match["seller_id"] = seller_filter_id

    trend_pipeline = [
        {"$match": trend_match},
        {"$project": {
            "date": {"$substr": ["$finished_at", 0, 10]},
            "is_sale": {"$cond": [{"$eq": ["$result", "SALE"]}, 1, 0]},
        }},
        {"$group": {
            "_id": "$date",
            "atendimentos": {"$sum": 1},
            "vendas": {"$sum": "$is_sale"},
        }},
        {"$sort": {"_id": 1}},
    ]
    trend_agg = await db.attendances.aggregate(trend_pipeline).to_list(31)
    trend_by_date = {r["_id"]: r for r in trend_agg}

    # Gerar todos os dias do período (até 31)
    try:
        start_dt = datetime.fromisoformat(period_start).replace(tzinfo=timezone.utc)
        end_dt = datetime.fromisoformat(period_end).replace(tzinfo=timezone.utc)
    except Exception:
        start_dt = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
        end_dt = start_dt

    delta_days = min(int((end_dt - start_dt).days) + 1, 31)
    week_data = []
    for i in range(delta_days):
        day = start_dt + timedelta(days=i)
        d_str = day.strftime("%Y-%m-%d")
        d_label = day.strftime("%d/%m")
        row = trend_by_date.get(d_str, {"atendimentos": 0, "vendas": 0})
        att_n = row["atendimentos"]
        sale_n = row["vendas"]
        week_data.append({
            "date": d_label,
            "atendimentos": att_n,
            "vendas": sale_n,
            "conversao": round(sale_n / att_n * 100) if att_n else 0,
        })

    # ─── Proatividade ─────────────────────────────────────────────────────────
    proactivity_kpis = None
    from features import is_enabled as _feat_enabled
    if await _feat_enabled(tenant_id, "abordagem_proativa"):
        pa_q = {
            "tenant_id": tenant_id,
            "store_id": {"$in": store_filter_ids},
            "started_at": {"$gte": period_start, "$lte": period_end},
        }
        if seller_filter_id:
            pa_q["seller_id"] = seller_filter_id
        pa_pipeline = [
            {"$match": pa_q},
            {"$group": {
                "_id": "$status",
                "count": {"$sum": 1},
                "sale_ids": {"$push": "$linked_sale_id"},
            }},
        ]
        pa_agg = await db.proactive_approaches.aggregate(pa_pipeline).to_list(20)
        pa_counts = {r["_id"]: r["count"] for r in pa_agg}
        pa_total = sum(pa_counts.values())
        all_sale_ids = [sid for r in pa_agg for sid in r.get("sale_ids", []) if sid]
        pa_revenue = 0
        if all_sale_ids:
            rev_agg = await db.sales.aggregate([
                {"$match": {"id": {"$in": all_sale_ids}}},
                {"$group": {"_id": None, "total": {"$sum": {"$ifNull": ["$net_amount_cents", 0]}}}},
            ]).to_list(1)
            pa_revenue = rev_agg[0]["total"] if rev_agg else 0
        pa_conv_sale = pa_counts.get("CONVERTED_TO_SALE", 0)
        proactivity_kpis = {
            "total_hoje": pa_total,
            "abertas": pa_counts.get("OPEN", 0),
            "convertidas_atendimento": pa_counts.get("CONVERTED_TO_ATTENDANCE", 0),
            "convertidas_venda": pa_conv_sale,
            "sem_venda": pa_counts.get("NO_SALE", 0),
            "receita_proativa_cents": pa_revenue,
            "conversao_venda_pct": round(pa_conv_sale / pa_total * 100) if pa_total else 0,
        }

    result = {
        "kpis": {
            "atendimentos_hoje": total_atts_today,
            "em_andamento": in_progress_n,
            "finalizados_hoje": finished_today_n,
            "vendas_hoje": sales_today_n,
            "total_vendido_cents": total_sold_cents,
            "ticket_medio_cents": avg_ticket_cents,
            "conversao_pct": conversion_pct,
            "tempo_medio_segundos": avg_duration_seconds,
            "total_produtos_vendidos": total_produtos_vendidos,
            "pa": pa,
        },
        "sellers_status": sellers_by_status,
        "week_trend": week_data,
        "scoped_store_ids": store_filter_ids,
        "proactivity_kpis": proactivity_kpis,
    }
    cache.set(cache_key, result, TTL["dashboard"])
    return result

