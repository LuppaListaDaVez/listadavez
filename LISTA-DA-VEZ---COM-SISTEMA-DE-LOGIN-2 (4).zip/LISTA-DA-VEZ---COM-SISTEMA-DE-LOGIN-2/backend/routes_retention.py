"""Endpoints de Retenção, Legal Hold — Etapa 14."""
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Request
from security import resolve_tenant_context
from feature_guard import require_feature
from permissions import (
    ROLE_PERMISSIONS,
    P_RETENTION_POLICIES_VIEW, P_RETENTION_POLICIES_UPDATE,
    P_RETENTION_JOBS_VIEW, P_RETENTION_JOBS_RUN, P_RETENTION_JOBS_CANCEL,
    P_LEGAL_HOLD_VIEW, P_LEGAL_HOLD_CREATE, P_LEGAL_HOLD_RELEASE,
)
import retention_policy_service as rp_svc
import legal_hold_service as lh_svc

router = APIRouter(prefix="/tenants/{tenant_slug}", tags=["retention"])


def _has(role, *perms):
    return any(p in ROLE_PERMISSIONS.get(role, []) for p in perms)


# ─── Políticas de Retenção ────────────────────────────────────────────────────

@router.get("/retention/policies")
async def list_policies(ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "retencao_dados")
    if not _has(ctx["membership"]["role"], P_RETENTION_POLICIES_VIEW, P_RETENTION_POLICIES_UPDATE):
        raise HTTPException(403, "Sem permissão.")
    return await rp_svc.list_policies(ctx["tenant"]["id"])


@router.put("/retention/policies/{policy_id}")
async def update_policy(
    policy_id: str,
    body: dict,
    request: Request,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "retencao_dados")
    if not _has(ctx["membership"]["role"], P_RETENTION_POLICIES_UPDATE):
        raise HTTPException(403, "Sem permissão.")
    try:
        doc = await rp_svc.update_policy(
            ctx["tenant"]["id"], policy_id, body, ctx["user"]["id"], request
        )
    except ValueError as e:
        raise HTTPException(400, str(e))
    if not doc:
        raise HTTPException(404, "Política não encontrada.")
    return doc


@router.post("/retention/policies/{policy_id}/preview")
async def preview_policy(policy_id: str, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "retencao_dados")
    if not _has(ctx["membership"]["role"], P_RETENTION_POLICIES_VIEW, P_RETENTION_POLICIES_UPDATE):
        raise HTTPException(403, "Sem permissão.")
    return await rp_svc.preview_policy(ctx["tenant"]["id"], policy_id)


@router.post("/retention/policies/{policy_id}/run")
async def run_policy(
    policy_id: str,
    request: Request,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "retencao_dados")
    if not _has(ctx["membership"]["role"], P_RETENTION_JOBS_RUN):
        raise HTTPException(403, "Sem permissão.")
    try:
        job = await rp_svc.run_job(ctx["tenant"]["id"], policy_id, ctx["user"]["id"], request)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return job


@router.get("/retention/jobs")
async def list_jobs(ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "retencao_dados")
    if not _has(ctx["membership"]["role"], P_RETENTION_JOBS_VIEW, P_RETENTION_JOBS_RUN):
        raise HTTPException(403, "Sem permissão.")
    return await rp_svc.list_jobs(ctx["tenant"]["id"])


# ─── Legal Holds ─────────────────────────────────────────────────────────────

@router.get("/legal-holds")
async def list_holds(
    status: Optional[str] = None,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "lgpd")
    if not _has(ctx["membership"]["role"], P_LEGAL_HOLD_VIEW, P_LEGAL_HOLD_CREATE):
        raise HTTPException(403, "Sem permissão.")
    return await lh_svc.list_holds(ctx["tenant"]["id"], status)


@router.post("/legal-holds")
async def create_hold(
    body: dict,
    request: Request,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "lgpd")
    if not _has(ctx["membership"]["role"], P_LEGAL_HOLD_CREATE):
        raise HTTPException(403, "Sem permissão.")
    return await lh_svc.create_hold(ctx["tenant"]["id"], body, ctx["user"]["id"], request)


@router.post("/legal-holds/{hold_id}/release")
async def release_hold(
    hold_id: str,
    request: Request,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "lgpd")
    if not _has(ctx["membership"]["role"], P_LEGAL_HOLD_RELEASE):
        raise HTTPException(403, "Sem permissão.")
    doc = await lh_svc.release_hold(ctx["tenant"]["id"], hold_id, ctx["user"]["id"], request)
    if not doc:
        raise HTTPException(404, "Legal hold não encontrado.")
    return doc
