"""achievement_service.py — Conquistas configuráveis por tenant (MVP).

Fluxo principal:
  1. Admin cria conquista (achievements) com uma regra (achievement_rules).
  2. Ao finalizar atendimento, evaluate_active_achievements é chamado (fire-and-forget).
  3. Para cada conquista ATIVA, calcula a métrica do vendedor e, se atingida, chama grant_achievement.
  4. grant_achievement insere em achievement_awards, cria gamification_event e notificação.
"""
import logging
from datetime import datetime, timezone, timedelta
from typing import Optional

from db import db
from models import new_id, utcnow_iso

logger = logging.getLogger(__name__)

# ─── Constantes ──────────────────────────────────────────────────────────────
METRIC_TO_GOAL_TYPE = {
    "REVENUE": "REVENUE",
    "CONVERSION": "CONVERSION",
    "AVERAGE_TICKET": "AVERAGE_TICKET",
    "SALES_COUNT": "SALES_COUNT",
    "ATTENDANCE_COUNT": "ATTENDANCES",
    "ITEMS_SOLD": "ITEMS_SOLD",
}

PERIOD_SENTINEL_START = "1970-01-01T00:00:00+00:00"  # para recurrence=ONCE
PERIOD_SENTINEL_END   = "9999-12-31T23:59:59+00:00"


# ─── Helpers de período ───────────────────────────────────────────────────────
def _period_bounds_from_type(period_type: Optional[str]):
    """Retorna (start_iso, end_iso) para o período atual."""
    now = datetime.now(timezone.utc)
    if period_type == "MONTHLY":
        start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        # Último dia do mês
        if start.month == 12:
            end = start.replace(year=start.year + 1, month=1) - timedelta(seconds=1)
        else:
            end = start.replace(month=start.month + 1) - timedelta(seconds=1)
        return start.isoformat(), end.isoformat()
    elif period_type == "WEEKLY":
        start = (now - timedelta(days=now.weekday())).replace(
            hour=0, minute=0, second=0, microsecond=0
        )
        end = (start + timedelta(days=7) - timedelta(seconds=1))
        return start.isoformat(), end.isoformat()
    elif period_type == "DAILY":
        start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        end = now.replace(hour=23, minute=59, second=59, microsecond=0)
        return start.isoformat(), end.isoformat()
    else:
        # Sem período — desde sempre
        return None, None


def _get_achievement_period(achievement: dict) -> tuple[Optional[str], Optional[str]]:
    """Retorna (period_start, period_end) baseado na configuração da conquista."""
    if achievement.get("period_type") == "CUSTOM":
        return achievement.get("period_start"), achievement.get("period_end")
    return _period_bounds_from_type(achievement.get("period_type"))


def _get_dedup_period(achievement: dict) -> tuple[str, str]:
    """Retorna o par (period_start, period_end) usado para deduplicação."""
    recurrence = achievement.get("recurrence", "ONCE")
    if recurrence == "ONCE":
        return PERIOD_SENTINEL_START, PERIOD_SENTINEL_END
    if recurrence == "ALWAYS":
        ts = utcnow_iso()
        return ts, ts
    start, end = _period_bounds_from_type(recurrence)
    return start or PERIOD_SENTINEL_START, end or PERIOD_SENTINEL_END


# ─── Cálculo de métricas ──────────────────────────────────────────────────────
async def calculate_metric_for_seller(
    tenant_id: str,
    seller_id: str,   # seller_profile_id
    store_id: str,
    metric: str,
    period_start: Optional[str],
    period_end: Optional[str],
) -> int:
    """Calcula o valor atual de uma métrica para um vendedor no período.
    
    Usa a mesma fonte de dados que goals_service para consistência.
    CONVERSION retorna percentual 0-100 (escala interna de conquistas).
    """
    goal_type = METRIC_TO_GOAL_TYPE.get(metric, metric)

    # Filtro base para attendances (usa finished_at — consistente com goals_service)
    att_q: dict = {"tenant_id": tenant_id, "seller_id": seller_id, "status": "FINISHED"}
    if period_start:
        att_q.setdefault("finished_at", {})["$gte"] = period_start
    if period_end:
        att_q.setdefault("finished_at", {})["$lte"] = period_end + "T23:59:59.999999+00:00"

    # Filtro base para sales (usa created_at)
    sales_q: dict = {"tenant_id": tenant_id, "seller_id": seller_id, "status": "COMPLETED"}
    if period_start:
        sales_q.setdefault("created_at", {})["$gte"] = period_start
    if period_end:
        sales_q.setdefault("created_at", {})["$lte"] = period_end + "T23:59:59.999999+00:00"

    if goal_type == "REVENUE":
        pipeline = [
            {"$match": {**att_q, "result": "SALE"}},
            {"$group": {"_id": None, "total": {"$sum": {"$ifNull": ["$sale_amount_cents", 0]}}}},
        ]
        agg = await db.attendances.aggregate(pipeline).to_list(1)
        return agg[0]["total"] if agg else 0

    elif goal_type == "SALES_COUNT":
        return await db.attendances.count_documents({**att_q, "result": "SALE"})

    elif goal_type == "ATTENDANCES":
        return await db.attendances.count_documents({**att_q, "result": {"$ne": "INVALID"}})

    elif goal_type == "ITEMS_SOLD":
        # item_count está na coleção sales (definido em sales_service.create_sale)
        pipeline = [
            {"$match": sales_q},
            {"$group": {"_id": None, "total": {"$sum": {"$ifNull": ["$item_count", 0]}}}},
        ]
        agg = await db.sales.aggregate(pipeline).to_list(1)
        return agg[0]["total"] if agg else 0

    elif goal_type == "AVERAGE_TICKET":
        pipeline = [
            {"$match": {**att_q, "result": "SALE"}},
            {"$group": {
                "_id": None,
                "total_rev": {"$sum": {"$ifNull": ["$sale_amount_cents", 0]}},
                "count": {"$sum": 1},
            }},
        ]
        agg = await db.attendances.aggregate(pipeline).to_list(1)
        if not agg or agg[0]["count"] == 0:
            return 0
        return int(agg[0]["total_rev"] / agg[0]["count"])

    elif goal_type == "CONVERSION":
        # Escala 0-100 (específico para regras de conquistas)
        pipeline = [
            {"$match": {**att_q, "result": {"$ne": "INVALID"}}},
            {"$group": {
                "_id": None,
                "sales": {"$sum": {"$cond": [{"$eq": ["$result", "SALE"]}, 1, 0]}},
                "total": {"$sum": 1},
            }},
        ]
        agg = await db.attendances.aggregate(pipeline).to_list(1)
        if not agg or agg[0]["total"] == 0:
            return 0
        return int(agg[0]["sales"] * 100 / agg[0]["total"])

    return 0


# ─── Avaliação de regra ────────────────────────────────────────────────────────
def evaluate_operator(current: int, operator: str, target: int) -> bool:
    ops = {
        "GTE": lambda a, b: a >= b,
        "GT":  lambda a, b: a > b,
        "LTE": lambda a, b: a <= b,
        "LT":  lambda a, b: a < b,
        "EQ":  lambda a, b: a == b,
    }
    fn = ops.get(operator.upper())
    return fn(current, target) if fn else False


# ─── Concessão de conquista ───────────────────────────────────────────────────
async def grant_achievement(
    tenant_id: str,
    achievement_id: str,
    seller_id: str,
    store_id: str,
    team_id: Optional[str],
    award_type: str,
    awarded_by: Optional[str],
    period_start_dedup: Optional[str] = None,
    period_end_dedup: Optional[str] = None,
    metadata: Optional[dict] = None,
    reason: Optional[str] = None,
) -> Optional[dict]:
    """Concede uma conquista a um vendedor.

    Retorna o award criado ou None se já foi concedida (duplicata).
    """
    achievement = await db.achievements.find_one({"tenant_id": tenant_id, "id": achievement_id})
    if not achievement:
        return None

    ps = period_start_dedup or PERIOD_SENTINEL_START
    pe = period_end_dedup or PERIOD_SENTINEL_END
    now = utcnow_iso()

    award = {
        "id": new_id(),
        "tenant_id": tenant_id,
        "achievement_id": achievement_id,
        "seller_id": seller_id,
        "store_id": store_id,
        "team_id": team_id,
        "achievement_name": achievement["name"],
        "achievement_description": achievement.get("description"),
        "icon": achievement.get("icon", "award"),
        "points_awarded": achievement.get("points", 50),
        "period_start": ps,
        "period_end": pe,
        "earned_at": now,
        "awarded_by": awarded_by,
        "award_type": award_type,
        "metadata": metadata or {},
        "reason": reason,
        "created_at": now,
    }

    try:
        await db.achievement_awards.insert_one(award)
    except Exception as exc:
        if "duplicate key" in str(exc).lower() or "E11000" in str(exc):
            return None   # já concedida neste período
        raise

    award.pop("_id", None)

    # ── Gamification event (pontos) ──────────────────────────────────────────
    points = achievement.get("points", 50)
    try:
        await db.gamification_events.insert_one({
            "id": new_id(),
            "tenant_id": tenant_id,
            "seller_id": seller_id,
            "event_type": "BADGE_EARNED",
            "points": points,
            "badge_name": achievement["name"],
            "achievement_id": achievement_id,
            "award_id": award["id"],
            "created_at": now,
        })
    except Exception:
        pass

    # ── Notificação interna ───────────────────────────────────────────────────
    try:
        sp = await db.seller_profiles.find_one({"id": seller_id, "tenant_id": tenant_id})
        if sp:
            await db.notifications.insert_one({
                "id": new_id(),
                "tenant_id": tenant_id,
                "user_id": sp["user_id"],
                "type": "ACHIEVEMENT_EARNED",
                "title": f"Conquista desbloqueada: {achievement['name']}",
                "body": achievement.get("description", ""),
                "icon": achievement.get("icon", "award"),
                "metadata": {"achievement_id": achievement_id, "award_id": award["id"],
                             "points": points},
                "read": False,
                "created_at": now,
            })
    except Exception:
        pass

    # ── Evento público de motivação (P1: TV/display) ────────────────────────
    try:
        from public_motivation_event_service import create_motivation_event
        await create_motivation_event(
            tenant_id=tenant_id,
            event_type="BADGE_EARNED",
            seller_id=seller_id,
            store_id=store_id,
            badge_id=award["id"],
            extra_ctx={"badge_name": achievement["name"]},
        )
    except Exception:
        pass

    return award


# ─── Verificar deduplicação ───────────────────────────────────────────────────
async def already_granted(
    tenant_id: str, seller_id: str, achievement_id: str,
    period_start: str, recurrence: str,
) -> bool:
    """Retorna True se a conquista já foi concedida no período."""
    if recurrence == "ALWAYS":
        return False
    q = {"tenant_id": tenant_id, "seller_id": seller_id,
         "achievement_id": achievement_id, "period_start": period_start}
    return bool(await db.achievement_awards.find_one(q))


# ─── Cálculo de progresso ─────────────────────────────────────────────────────
async def get_progress_for_seller(
    tenant_id: str,
    seller_id: str,
    store_id: str,
    achievement: dict,
) -> dict:
    """Retorna o progresso do vendedor para uma conquista."""
    rule = await db.achievement_rules.find_one(
        {"tenant_id": tenant_id, "achievement_id": achievement["id"]}
    )
    ps, pe = _get_achievement_period(achievement)
    ps_dedup, pe_dedup = _get_dedup_period(achievement)

    earned = bool(await db.achievement_awards.find_one({
        "tenant_id": tenant_id,
        "achievement_id": achievement["id"],
        "seller_id": seller_id,
        "period_start": ps_dedup,
    }))

    if not rule:
        return {
            "achievement": achievement,
            "current_value": 0,
            "target_value": None,
            "progress_pct": 0,
            "earned": earned,
            "metric": None,
        }

    current = await calculate_metric_for_seller(
        tenant_id, seller_id, store_id, rule["metric"], ps, pe
    )
    target = rule.get("target_value", 1)
    pct = min(100, int(current * 100 / target)) if target > 0 else 0

    return {
        "achievement": achievement,
        "current_value": current,
        "target_value": target,
        "progress_pct": pct,
        "earned": earned,
        "metric": rule.get("metric"),
        "operator": rule.get("operator"),
    }


# ─── Avaliação em massa ───────────────────────────────────────────────────────
async def evaluate_active_achievements(
    tenant_id: str,
    seller_id: str,
    store_id: str,
) -> list[dict]:
    """Avalia todas as conquistas ATIVAS para o vendedor. Retorna as concedidas."""
    try:
        achievements_cursor = db.achievements.find(
            {"tenant_id": tenant_id, "status": "ACTIVE", "approval_mode": "AUTOMATIC"}
        )
        achievements = await achievements_cursor.to_list(200)
        awarded = []

        for ach in achievements:
            recurrence = ach.get("recurrence", "ONCE")
            ps_dedup, pe_dedup = _get_dedup_period(ach)

            if await already_granted(tenant_id, seller_id, ach["id"], ps_dedup, recurrence):
                continue

            rule = await db.achievement_rules.find_one(
                {"tenant_id": tenant_id, "achievement_id": ach["id"]}
            )
            if not rule:
                continue

            ps, pe = _get_achievement_period(ach)
            current = await calculate_metric_for_seller(
                tenant_id, seller_id, store_id, rule["metric"], ps, pe
            )

            if not evaluate_operator(current, rule.get("operator", "GTE"), rule.get("target_value", 0)):
                continue

            award = await grant_achievement(
                tenant_id=tenant_id,
                achievement_id=ach["id"],
                seller_id=seller_id,
                store_id=store_id,
                team_id=None,
                award_type="AUTOMATIC",
                awarded_by=None,
                period_start_dedup=ps_dedup,
                period_end_dedup=pe_dedup,
                metadata={"metric": rule["metric"], "current_value": current},
            )
            if award:
                awarded.append(award)

        return awarded
    except Exception as exc:
        logger.error("evaluate_active_achievements error: %s", exc, exc_info=True)
        return []
