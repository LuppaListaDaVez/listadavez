"""Feedbacks endpoints — Etapa 10 / Prompt 9."""
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel

from db import db
from security import resolve_tenant_context
from feature_guard import require_feature
from permission_service import get_accessible_store_ids
from permissions import (
    P_FEEDBACKS_VIEW_SELF, P_FEEDBACKS_VIEW_STORE, P_FEEDBACKS_VIEW_TENANT,
    P_FEEDBACKS_CREATE, P_FEEDBACKS_UPDATE, P_FEEDBACKS_ACKNOWLEDGE,
)
import feedback_service

router = APIRouter(prefix="/tenants/{tenant_slug}/feedbacks", tags=["feedbacks"])

VIEW_PERMS = (P_FEEDBACKS_VIEW_SELF, P_FEEDBACKS_VIEW_STORE, P_FEEDBACKS_VIEW_TENANT)


def _has_perm(role: str, perm: str) -> bool:
    from permissions import ROLE_PERMISSIONS
    return perm in ROLE_PERMISSIONS.get(role, [])


def _has_view_perm(role: str) -> bool:
    from permissions import ROLE_PERMISSIONS
    return any(p in ROLE_PERMISSIONS.get(role, []) for p in VIEW_PERMS)


class ActionPlanInput(BaseModel):
    description: Optional[str] = None
    due_date: Optional[str] = None
    status: Optional[str] = None


class FeedbackCreate(BaseModel):
    seller_id: str
    type: str
    title: str
    content: str
    action_plan: Optional[ActionPlanInput] = None
    period_start: Optional[str] = None  # YYYY-MM-DD
    period_end: Optional[str] = None    # YYYY-MM-DD


class FeedbackUpdate(BaseModel):
    title: Optional[str] = None
    content: Optional[str] = None
    type: Optional[str] = None


class ActionPlanUpdate(BaseModel):
    status: Optional[str] = None
    description: Optional[str] = None
    due_date: Optional[str] = None


@router.get("")
async def list_feedbacks(
    seller_id: Optional[str] = None,
    type: Optional[str] = None,
    is_acknowledged: Optional[bool] = None,
    page: int = 1,
    page_size: int = 50,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "feedbacks")
    role = ctx["membership"]["role"]
    if not _has_view_perm(role):
        raise HTTPException(403, "Sem permissão para visualizar feedbacks.")

    tenant_id = ctx["tenant"]["id"]
    user_id = ctx["user"]["id"]
    accessible_store_ids = await get_accessible_store_ids(ctx["membership"], tenant_id)

    page = max(1, page)
    page_size = min(max(1, page_size), 100)
    skip = (page - 1) * page_size

    filters: dict = {}
    if type:
        filters["type"] = type.upper()
    if is_acknowledged is not None:
        filters["is_acknowledged"] = is_acknowledged

    if role == "SELLER":
        profile = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": user_id})
        sid = profile["id"] if profile else "__none__"
        filters["seller_id"] = sid
    elif role == "TENANT_ADMIN":
        if seller_id:
            filters["seller_id"] = seller_id
    else:
        if seller_id:
            filters["seller_id"] = seller_id
        elif accessible_store_ids:
            q: dict = {"tenant_id": tenant_id, **filters}
            q["store_id"] = {"$in": accessible_store_ids}
            total = await db.feedbacks.count_documents(q)
            docs = await db.feedbacks.find(q).sort("created_at", -1).skip(skip).limit(page_size).to_list(page_size)
            for d in docs:
                d.pop("_id", None)
            return {
                "items": docs,
                "pagination": {"page": page, "page_size": page_size, "total": total, "has_next": (skip + page_size) < total},
            }

    q2: dict = {"tenant_id": tenant_id, **filters}
    total = await db.feedbacks.count_documents(q2)
    docs = await db.feedbacks.find(q2).sort("created_at", -1).skip(skip).limit(page_size).to_list(page_size)
    for d in docs:
        d.pop("_id", None)
    return {
        "items": docs,
        "pagination": {"page": page, "page_size": page_size, "total": total, "has_next": (skip + page_size) < total},
    }


@router.post("")
async def create_feedback(
    payload: FeedbackCreate,
    request: Request,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "feedbacks")
    role = ctx["membership"]["role"]
    if not _has_perm(role, P_FEEDBACKS_CREATE):
        raise HTTPException(403, "Sem permissão para criar feedbacks.")

    tenant_id = ctx["tenant"]["id"]
    accessible_store_ids = await get_accessible_store_ids(ctx["membership"], tenant_id)

    data = payload.model_dump()
    if data.get("action_plan"):
        data["action_plan"] = payload.action_plan.model_dump(exclude_none=True) if payload.action_plan else None

    # Validar que o vendedor está em uma unidade acessível (exceto TENANT_ADMIN)
    if role != "TENANT_ADMIN" and accessible_store_ids:
        sp = await db.seller_profiles.find_one({"tenant_id": tenant_id, "id": data["seller_id"]})
        if sp and sp.get("store_id") and sp["store_id"] not in accessible_store_ids:
            raise HTTPException(403, "Sem acesso ao vendedor informado.")

    return await feedback_service.create_feedback(
        tenant_id=tenant_id,
        author_id=ctx["user"]["id"],
        author_name=ctx["user"].get("name", ""),
        data=data,
        request=request,
    )


@router.get("/seller-context")
async def get_seller_context(
    seller_id: str,
    date_from: str,
    date_to: str,
    ctx: dict = Depends(resolve_tenant_context),
):
    """Retorna desempenho do vendedor no período — contexto para criar feedback."""
    await require_feature(ctx["tenant"]["id"], "feedbacks")
    role = ctx["membership"]["role"]
    if not _has_perm(role, P_FEEDBACKS_CREATE):
        raise HTTPException(403, "Sem permissão.")

    tenant_id = ctx["tenant"]["id"]
    accessible_store_ids = await get_accessible_store_ids(ctx["membership"], tenant_id)

    seller_profile = await db.seller_profiles.find_one({"tenant_id": tenant_id, "id": seller_id})
    if not seller_profile:
        raise HTTPException(404, "Vendedor não encontrado.")

    if role != "TENANT_ADMIN" and accessible_store_ids:
        if seller_profile.get("store_id") not in accessible_store_ids:
            raise HTTPException(403, "Sem acesso a este vendedor.")

    # Nome do vendedor
    seller_user = await db.users.find_one({"id": seller_profile.get("user_id", "")})
    seller_name = seller_user.get("name", "Vendedor") if seller_user else "Vendedor"

    # Parse de datas
    try:
        start_dt = datetime.strptime(date_from, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    except ValueError:
        start_dt = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    try:
        end_dt = datetime.strptime(date_to, "%Y-%m-%d").replace(tzinfo=timezone.utc)
        end_dt = end_dt.replace(hour=23, minute=59, second=59, microsecond=999999)
    except ValueError:
        end_dt = datetime.now(timezone.utc).replace(hour=23, minute=59, second=59, microsecond=999999)

    period_start_iso = start_dt.isoformat()
    period_end_iso = end_dt.isoformat()

    # ─── KPIs de atendimento ──────────────────────────────────────────────────
    total_atts = await db.attendances.count_documents({
        "tenant_id": tenant_id,
        "seller_id": seller_id,
        "created_at": {"$gte": period_start_iso, "$lte": period_end_iso},
    })

    kpi_pipeline = [
        {"$match": {
            "tenant_id": tenant_id,
            "seller_id": seller_id,
            "status": "FINISHED",
            "finished_at": {"$gte": period_start_iso, "$lte": period_end_iso},
        }},
        {"$group": {
            "_id": None,
            "finalizados": {"$sum": 1},
            "vendas": {"$sum": {"$cond": [{"$eq": ["$result", "SALE"]}, 1, 0]}},
            "receita_cents": {"$sum": {
                "$cond": [{"$eq": ["$result", "SALE"]}, {"$ifNull": ["$sale_amount_cents", 0]}, 0]
            }},
        }},
    ]
    kpi_agg = await db.attendances.aggregate(kpi_pipeline).to_list(1)
    kpi = dict(kpi_agg[0]) if kpi_agg else {}
    kpi.pop("_id", None)

    finalizados = kpi.get("finalizados", 0)
    vendas = kpi.get("vendas", 0)
    receita_cents = kpi.get("receita_cents", 0)
    conversao_pct = round(vendas / finalizados * 100) if finalizados else 0
    ticket_medio_cents = round(receita_cents / vendas) if vendas else 0

    # ─── Metas do vendedor/loja no período ────────────────────────────────────
    store_id = seller_profile.get("store_id")
    scope_filter: list = [{"scope": "SELLER", "seller_id": seller_id}]
    if store_id:
        scope_filter.append({"scope": "STORE", "store_id": store_id})

    goals_filter: dict = {
        "tenant_id": tenant_id,
        "status": {"$in": ["ACTIVE", "COMPLETED", "EXPIRED"]},
        "$or": scope_filter,
        "period_end": {"$gte": date_from},
        "period_start": {"$lte": date_to},
    }
    goals_raw = await db.goals.find(goals_filter).sort("created_at", -1).limit(8).to_list(8)
    goals_data = []
    for g in goals_raw:
        g.pop("_id", None)
        goals_data.append({
            "id": g.get("id"),
            "title": g.get("title", ""),
            "type": g.get("type", ""),
            "scope": g.get("scope", ""),
            "target_value": g.get("target_value", 0),
            "current_value": g.get("current_value", 0),
            "progress_pct": g.get("progress_pct", 0),
            "status": g.get("status", "ACTIVE"),
            "period_start": g.get("period_start", ""),
            "period_end": g.get("period_end", ""),
        })

    # ─── Ranking na unidade no período ───────────────────────────────────────
    ranking_data: dict = {"position": None, "total_sellers": 0, "criteria": "REVENUE"}
    if store_id:
        rank_pipeline = [
            {"$match": {
                "tenant_id": tenant_id,
                "store_id": store_id,
                "status": "FINISHED",
                "result": "SALE",
                "finished_at": {"$gte": period_start_iso, "$lte": period_end_iso},
            }},
            {"$group": {
                "_id": "$seller_id",
                "revenue": {"$sum": {"$ifNull": ["$sale_amount_cents", 0]}},
            }},
            {"$sort": {"revenue": -1}},
        ]
        rank_agg = await db.attendances.aggregate(rank_pipeline).to_list(200)
        position: Optional[int] = None
        for i, r in enumerate(rank_agg):
            if r["_id"] == seller_id:
                position = i + 1
                break
        if position is None:
            position = len(rank_agg) + 1 if rank_agg else 1
        ranking_data = {
            "position": position,
            "total_sellers": len(rank_agg) if rank_agg else 1,
            "criteria": "REVENUE",
        }

    return {
        "seller_id": seller_id,
        "seller_name": seller_name,
        "period_start": date_from,
        "period_end": date_to,
        "kpis": {
            "total_atendimentos": total_atts,
            "finalizados": finalizados,
            "vendas": vendas,
            "conversao_pct": conversao_pct,
            "receita_total_cents": receita_cents,
            "ticket_medio_cents": ticket_medio_cents,
        },
        "goals": goals_data,
        "ranking": ranking_data,
    }


@router.get("/{feedback_id}")
async def get_feedback(feedback_id: str, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "feedbacks")
    role = ctx["membership"]["role"]
    if not _has_view_perm(role):
        raise HTTPException(403, "Sem permissão para visualizar feedbacks.")

    tenant_id = ctx["tenant"]["id"]
    feedback = await feedback_service.get_feedback(tenant_id, feedback_id)

    # SELLER: só pode ver feedbacks direcionados a ele
    if role == "SELLER":
        profile = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": ctx["user"]["id"]})
        sid = profile["id"] if profile else "__none__"
        if feedback.get("seller_id") != sid:
            raise HTTPException(403, "Sem permissão para visualizar este feedback.")

    return feedback


@router.put("/{feedback_id}")
async def update_feedback(
    feedback_id: str,
    payload: FeedbackUpdate,
    request: Request,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "feedbacks")
    role = ctx["membership"]["role"]
    if not _has_perm(role, P_FEEDBACKS_UPDATE):
        raise HTTPException(403, "Sem permissão para editar feedbacks.")

    tenant_id = ctx["tenant"]["id"]
    feedback = await feedback_service.get_feedback(tenant_id, feedback_id)

    # Apenas o autor pode editar
    if feedback.get("author_id") != ctx["user"]["id"] and role != "TENANT_ADMIN":
        raise HTTPException(403, "Apenas o autor pode editar este feedback.")

    return await feedback_service.update_feedback(
        tenant_id=tenant_id,
        feedback_id=feedback_id,
        actor_user_id=ctx["user"]["id"],
        data=payload.model_dump(exclude_none=True),
        request=request,
    )


@router.patch("/{feedback_id}/acknowledge")
async def acknowledge_feedback(feedback_id: str, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "feedbacks")
    role = ctx["membership"]["role"]
    if not _has_perm(role, P_FEEDBACKS_ACKNOWLEDGE):
        raise HTTPException(403, "Sem permissão para confirmar leitura.")

    tenant_id = ctx["tenant"]["id"]
    feedback = await feedback_service.get_feedback(tenant_id, feedback_id)

    # Apenas o destinatário pode confirmar
    profile = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": ctx["user"]["id"]})
    sid = profile["id"] if profile else "__none__"
    if feedback.get("seller_id") != sid:
        raise HTTPException(403, "Apenas o destinatário pode confirmar a leitura.")

    return await feedback_service.acknowledge_feedback(
        tenant_id=tenant_id,
        feedback_id=feedback_id,
        seller_user_id=ctx["user"]["id"],
    )


@router.put("/{feedback_id}/action-plan")
async def update_action_plan(
    feedback_id: str,
    payload: ActionPlanUpdate,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "feedbacks")
    role = ctx["membership"]["role"]
    tenant_id = ctx["tenant"]["id"]
    feedback = await feedback_service.get_feedback(tenant_id, feedback_id)

    # Vendedor pode atualizar status do plano. Gerentes podem atualizar tudo.
    is_seller = role == "SELLER"
    if is_seller:
        profile = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": ctx["user"]["id"]})
        sid = profile["id"] if profile else "__none__"
        if feedback.get("seller_id") != sid:
            raise HTTPException(403, "Sem permissão para atualizar este plano de ação.")
        # Vendedor só pode mudar status
        data = {"status": payload.status} if payload.status else {}
    else:
        if not _has_perm(role, P_FEEDBACKS_UPDATE):
            raise HTTPException(403, "Sem permissão para editar planos de ação.")
        data = payload.model_dump(exclude_none=True)

    if not data:
        return feedback

    return await feedback_service.update_action_plan(
        tenant_id=tenant_id,
        feedback_id=feedback_id,
        actor_user_id=ctx["user"]["id"],
        data=data,
    )
