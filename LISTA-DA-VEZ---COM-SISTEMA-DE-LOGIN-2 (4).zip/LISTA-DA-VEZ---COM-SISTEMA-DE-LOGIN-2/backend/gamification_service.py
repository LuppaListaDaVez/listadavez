"""GamificationService — Etapa 9. Badges e eventos de gamificação simples."""
from datetime import datetime, timezone, date

from fastapi import HTTPException

from db import db
from models import new_id, utcnow_iso
from audit import log_audit

# Catálogo de badges disponíveis (Fix 5: pontos configuráveis por badge)
BADGE_CATALOG = {
    "TOP_SELLER_DAY":       {"name": "Top Vendedor do Dia",       "description": "Maior receita no dia.",                   "icon": "trophy", "points": 100},
    "TOP_SELLER_WEEK":      {"name": "Top Vendedor da Semana",    "description": "Maior receita na semana.",                "icon": "trophy", "points": 200},
    "TOP_CONVERSION_DAY":   {"name": "Maior Conversão do Dia",    "description": "Maior taxa de conversão no dia.",         "icon": "target", "points": 75},
    "TOP_CONVERSION_WEEK":  {"name": "Maior Conversão da Semana", "description": "Maior taxa de conversão na semana.",      "icon": "target", "points": 150},
    "FIRST_SALE_OF_DAY":    {"name": "Primeira Venda do Dia",     "description": "Realizou a primeira venda do dia.",       "icon": "zap",    "points": 50},
    "BEST_AVERAGE_TICKET":  {"name": "Melhor Ticket Médio",       "description": "Maior ticket médio no período.",          "icon": "award",  "points": 80},
    "MOST_ATTENDANCES":     {"name": "Mais Atendimentos",         "description": "Maior número de atendimentos no período.","icon": "users",  "points": 60},
    "GOAL_ACHIEVED":        {"name": "Meta Atingida",             "description": "Meta comercial concluída com sucesso.",   "icon": "check-circle", "points": 120},
}

GAMIFICATION_EVENT_TYPES = {
    "SALE_CREATED", "GOAL_ACHIEVED", "TOP_RANKING_POSITION", "BADGE_EARNED", "ATTENDANCE_FINISHED",
}


def _today() -> str:
    return date.today().isoformat()


async def award_badge(
    tenant_id: str, seller_id: str, store_id: str,
    badge_key: str, period_start: str, period_end: str,
    metadata: dict = None, actor_user_id: str = None, request=None,
) -> dict | None:
    """Concede um badge a um seller se ainda não possuir no período."""
    if badge_key not in BADGE_CATALOG:
        return None

    # Verificar duplicidade
    exists = await db.seller_badges.find_one({
        "tenant_id": tenant_id,
        "seller_id": seller_id,
        "badge_key": badge_key,
        "period_start": period_start,
        "period_end": period_end,
    })
    if exists:
        return None  # já possui

    catalog = BADGE_CATALOG[badge_key]
    now = utcnow_iso()
    doc = {
        "id": new_id(),
        "tenant_id": tenant_id,
        "seller_id": seller_id,
        "store_id": store_id,
        "badge_key": badge_key,
        "badge_name": catalog["name"],
        "description": catalog["description"],
        "icon": catalog["icon"],
        "earned_at": now,
        "period_start": period_start,
        "period_end": period_end,
        "metadata": metadata or {},
        "created_at": now,
    }
    await db.seller_badges.insert_one(doc)
    doc.pop("_id", None)

    # Criar gamification_event (Fix 5: usar pontos do catálogo, não fixo 50)
    await create_gamification_event(
        tenant_id=tenant_id, store_id=store_id, seller_id=seller_id,
        event_type="BADGE_EARNED", points=catalog.get("points", 50),
        payload={"badge_key": badge_key, "badge_name": catalog["name"]},
    )

    # Notificar vendedor sobre badge conquistado
    try:
        sp = await db.seller_profiles.find_one({"tenant_id": tenant_id, "id": seller_id})
        if sp and sp.get("user_id"):
            from notification_service import create_notification
            await create_notification(
                tenant_id=tenant_id,
                user_id=sp["user_id"],
                ntype="BADGE_EARNED",
                title="Conquista desbloqueada!",
                body=f'Você ganhou o badge "{catalog["name"]}".',
                entity_type="badge",
                entity_id=doc["id"],
            )
    except Exception:
        pass

    if actor_user_id:
        await log_audit(
            action="BADGE_EARNED", entity="seller_badge", entity_id=doc["id"],
            tenant_id=tenant_id, user_id=actor_user_id,
            new_value={"badge_key": badge_key, "seller_id": seller_id},
            request=request,
        )

    return doc


async def list_seller_badges(tenant_id: str, seller_id: str, limit: int = 50) -> list:
    docs = await db.seller_badges.find(
        {"tenant_id": tenant_id, "seller_id": seller_id}
    ).sort("earned_at", -1).limit(limit).to_list(limit)
    for d in docs:
        d.pop("_id", None)
    return docs


async def list_store_badges(tenant_id: str, store_id: str, limit: int = 100) -> list:
    docs = await db.seller_badges.find(
        {"tenant_id": tenant_id, "store_id": store_id}
    ).sort("earned_at", -1).limit(limit).to_list(limit)
    for d in docs:
        d.pop("_id", None)
    return docs


async def list_tenant_badges(tenant_id: str, limit: int = 200) -> list:
    docs = await db.seller_badges.find(
        {"tenant_id": tenant_id}
    ).sort("earned_at", -1).limit(limit).to_list(limit)
    for d in docs:
        d.pop("_id", None)
    return docs


async def create_gamification_event(
    tenant_id: str, store_id: str, seller_id: str,
    event_type: str, points: int = 0, payload: dict = None,
) -> dict:
    now = utcnow_iso()
    doc = {
        "id": new_id(),
        "tenant_id": tenant_id,
        "store_id": store_id,
        "seller_id": seller_id,
        "event_type": event_type,
        "points": points,
        "payload": payload or {},
        "created_at": now,
    }
    await db.gamification_events.insert_one(doc)
    doc.pop("_id", None)
    return doc


async def get_seller_points(tenant_id: str, seller_id: str,
                            period_start: str = None, period_end: str = None) -> int:
    q: dict = {"tenant_id": tenant_id, "seller_id": seller_id}
    if period_start:
        q.setdefault("created_at", {})["$gte"] = period_start
    if period_end:
        q.setdefault("created_at", {})["$lte"] = period_end + "T23:59:59.999999+00:00"
    events = await db.gamification_events.find(q).to_list(2000)
    return sum(e.get("points", 0) for e in events)
