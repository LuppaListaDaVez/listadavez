"""Endpoints de Eventos Motivacionais e Templates — Etapa 12."""
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from pymongo.errors import DuplicateKeyError
from security import resolve_tenant_context
from feature_guard import require_feature
from permissions import ROLE_PERMISSIONS, P_MOTIVATION_VIEW, P_MOTIVATION_MANAGE, P_NOTIF_TEMPLATES_VIEW, P_NOTIF_TEMPLATES_MANAGE, P_NOTIF_DELIVERY_LOGS
import public_motivation_event_service as mot_svc
from db import db

router = APIRouter(prefix="/tenants/{tenant_slug}", tags=["motivation", "notifications"])


def _has(role, *perms):
    return any(p in ROLE_PERMISSIONS.get(role, []) for p in perms)


# ─── Motivation Events ────────────────────────────────────────────────────────

@router.get("/motivation-events")
async def list_motivation_events(
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    event_type: Optional[str] = None,
    store_id: Optional[str] = None,
    limit: int = 50,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "motivacao_publica")
    if not _has(ctx["membership"]["role"], P_MOTIVATION_VIEW):
        raise HTTPException(status_code=403, detail="Sem permissão.")
    filters = {"date_from": date_from, "date_to": date_to, "event_type": event_type,
               "store_id": store_id, "limit": limit}
    return await mot_svc.list_motivation_events(ctx["tenant"]["id"], ctx["user"]["id"], filters)


@router.get("/motivation-events/feed")
async def motivation_feed(
    limit: int = 20,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "motivacao_publica")
    if not _has(ctx["membership"]["role"], P_MOTIVATION_VIEW):
        raise HTTPException(status_code=403, detail="Sem permissão.")
    return await mot_svc.list_motivation_events(ctx["tenant"]["id"], ctx["user"]["id"], {"limit": limit})


class AnnouncementCreate(BaseModel):
    title: Optional[str] = None
    message: str
    event_type: str = "ADMIN_ANNOUNCEMENT"  # ADMIN_ANNOUNCEMENT | GENERAL_ANNOUNCEMENT | RECOGNITION | AWARD | SCHEDULED_MESSAGE


@router.post("/motivation-events/announce", status_code=201)
async def create_announcement(
    payload: AnnouncementCreate,
    ctx: dict = Depends(resolve_tenant_context),
):
    """Admin/Gerente cria aviso público no Feed Motivacional."""
    await require_feature(ctx["tenant"]["id"], "motivacao_publica")
    if not _has(ctx["membership"]["role"], P_MOTIVATION_MANAGE):
        raise HTTPException(status_code=403, detail="Sem permissão para criar avisos.")
    valid_types = {"ADMIN_ANNOUNCEMENT", "GENERAL_ANNOUNCEMENT", "RECOGNITION", "AWARD", "SCHEDULED_MESSAGE"}
    if payload.event_type not in valid_types:
        payload.event_type = "ADMIN_ANNOUNCEMENT"
    user = ctx["user"]
    extra = {
        "message": payload.message,
        "title": payload.title or "Aviso",
        "seller_name": user.get("name", "Administração"),
    }
    result = await mot_svc.create_motivation_event(
        tenant_id=ctx["tenant"]["id"],
        event_type=payload.event_type,
        extra_ctx=extra,
        skip_dedup=True,
    )
    if not result:
        raise HTTPException(status_code=503, detail="Feature motivacao_publica não ativa.")
    return result


@router.post("/motivation-events/test")
async def test_motivation_event(
    request: Request,
    ctx: dict = Depends(resolve_tenant_context),
):
    """Criar evento motivacional de teste (apenas admins)."""
    await require_feature(ctx["tenant"]["id"], "motivacao_publica")
    if not _has(ctx["membership"]["role"], P_MOTIVATION_MANAGE):
        raise HTTPException(status_code=403, detail="Sem permissão.")
    result = await mot_svc.create_motivation_event(
        tenant_id=ctx["tenant"]["id"],
        event_type="CONVERSION_HIGHLIGHT",
        extra_ctx={"seller_name": ctx["user"].get("name", "Admin")},
    )
    return result or {"detail": "Evento duplicado ou feature inativa."}


# ─── Notification Templates ───────────────────────────────────────────────────

class TemplateCreate(BaseModel):
    key: str
    name: str
    description: Optional[str] = None
    channel: str = "IN_APP"
    event_type: str
    title_template: str
    body_template: str
    severity: str = "INFO"
    is_public: bool = False
    is_active: bool = True


@router.get("/notification-templates")
async def list_templates(ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "templates_notificacao")
    if not _has(ctx["membership"]["role"], P_NOTIF_TEMPLATES_VIEW):
        raise HTTPException(status_code=403, detail="Sem permissão.")
    raw = await db.notification_templates.find({"tenant_id": ctx["tenant"]["id"]}).to_list(200)
    for d in raw:
        d.pop("_id", None)
    return raw


@router.post("/notification-templates")
async def create_template(payload: TemplateCreate, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "templates_notificacao")
    if not _has(ctx["membership"]["role"], P_NOTIF_TEMPLATES_MANAGE):
        raise HTTPException(status_code=403, detail="Sem permissão.")
    from models import new_id, utcnow_iso
    now = utcnow_iso()
    doc = {
        "id": new_id(), "tenant_id": ctx["tenant"]["id"],
        **payload.model_dump(),
        "created_by": ctx["user"]["id"],
        "created_at": now, "updated_at": now,
    }
    await db.notification_templates.insert_one(doc)
    doc.pop("_id", None)
    return doc


@router.get("/notification-templates/{template_id}")
async def get_template(template_id: str, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "templates_notificacao")
    if not _has(ctx["membership"]["role"], P_NOTIF_TEMPLATES_VIEW):
        raise HTTPException(status_code=403, detail="Sem permissão.")
    doc = await db.notification_templates.find_one({"tenant_id": ctx["tenant"]["id"], "id": template_id})
    if not doc:
        raise HTTPException(status_code=404, detail="Template não encontrado.")
    doc.pop("_id", None)
    return doc


@router.put("/notification-templates/{template_id}")
async def update_template(template_id: str, payload: TemplateCreate, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "templates_notificacao")
    if not _has(ctx["membership"]["role"], P_NOTIF_TEMPLATES_MANAGE):
        raise HTTPException(status_code=403, detail="Sem permissão.")
    from models import utcnow_iso
    updates = {**payload.model_dump(), "updated_at": utcnow_iso()}
    await db.notification_templates.update_one({"tenant_id": ctx["tenant"]["id"], "id": template_id}, {"$set": updates})
    doc = await db.notification_templates.find_one({"id": template_id})
    if not doc:
        raise HTTPException(status_code=404)
    doc.pop("_id", None)
    return doc


@router.delete("/notification-templates/{template_id}")
async def delete_template(template_id: str, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "templates_notificacao")
    if not _has(ctx["membership"]["role"], P_NOTIF_TEMPLATES_MANAGE):
        raise HTTPException(status_code=403, detail="Sem permissão.")
    await db.notification_templates.delete_one({"tenant_id": ctx["tenant"]["id"], "id": template_id})
    return {"deleted": True}


# ─── Notification Deliveries Log ─────────────────────────────────────────────

@router.get("/notification-deliveries")
async def list_deliveries(
    channel: Optional[str] = None,
    status: Optional[str] = None,
    ctx: dict = Depends(resolve_tenant_context),
):
    if not _has(ctx["membership"]["role"], P_NOTIF_DELIVERY_LOGS):
        raise HTTPException(status_code=403, detail="Sem permissão.")
    q: dict = {"tenant_id": ctx["tenant"]["id"]}
    if channel:
        q["channel"] = channel
    if status:
        q["status"] = status
    raw = await db.notification_deliveries.find(q).sort("created_at", -1).limit(200).to_list(200)
    for d in raw:
        d.pop("_id", None)
    return raw


# ─── Push Subscriptions ───────────────────────────────────────────────────────

class PushSubCreate(BaseModel):
    endpoint: str
    keys: Optional[dict] = None
    device_label: Optional[str] = None
    browser: Optional[str] = None
    platform: Optional[str] = None


@router.post("/push-subscriptions")
async def register_push_sub(payload: PushSubCreate, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "push_notifications")
    from models import new_id, utcnow_iso
    now = utcnow_iso()
    existing = await db.push_subscriptions.find_one({
        "tenant_id": ctx["tenant"]["id"],
        "user_id": ctx["user"]["id"],
        "endpoint": payload.endpoint,
    })
    if existing:
        existing.pop("_id", None)
        return existing
    doc = {
        "id": new_id(), "tenant_id": ctx["tenant"]["id"],
        "user_id": ctx["user"]["id"],
        "provider": "WEBPUSH",
        **payload.model_dump(),
        "is_active": True,
        "created_at": now, "updated_at": now, "revoked_at": None,
    }
    try:
        await db.push_subscriptions.insert_one(doc)
    except DuplicateKeyError:
        existing = await db.push_subscriptions.find_one({
            "tenant_id": ctx["tenant"]["id"],
            "user_id": ctx["user"]["id"],
            "endpoint": payload.endpoint,
        })
        if existing:
            existing.pop("_id", None)
            return existing
        raise
    doc.pop("_id", None)
    return doc


@router.delete("/push-subscriptions/{sub_id}")
async def revoke_push_sub(sub_id: str, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "push_notifications")
    from models import utcnow_iso
    await db.push_subscriptions.update_one(
        {"tenant_id": ctx["tenant"]["id"], "id": sub_id, "user_id": ctx["user"]["id"]},
        {"$set": {"is_active": False, "revoked_at": utcnow_iso()}},
    )
    return {"revoked": True}


# ─── Test external notification ───────────────────────────────────────────────

@router.post("/external-notifications/test-email")
async def test_email(ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "email_transacional")
    from external_notification_service import email_provider
    user = ctx["user"]
    return await email_provider.send_email(
        to=user.get("email", "test@example.com"),
        subject="Teste de e-mail — Lista da Vez",
        body="Este é um e-mail de teste do sistema Lista da Vez.",
        tenant_id=ctx["tenant"]["id"],
        recipient_user_id=user["id"],
        event_type="TEST_EMAIL",
    )


@router.post("/external-notifications/test-push")
async def test_push(ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "push_notifications")
    from external_notification_service import push_provider
    sub = await db.push_subscriptions.find_one({
        "tenant_id": ctx["tenant"]["id"],
        "user_id": ctx["user"]["id"],
        "is_active": True,
    })
    return await push_provider.send_push(
        subscription=sub or {},
        title="Teste Push — Lista da Vez",
        body="Esta é uma notificação push de teste.",
        tenant_id=ctx["tenant"]["id"],
        recipient_user_id=ctx["user"]["id"],
        event_type="TEST_PUSH",
    )
