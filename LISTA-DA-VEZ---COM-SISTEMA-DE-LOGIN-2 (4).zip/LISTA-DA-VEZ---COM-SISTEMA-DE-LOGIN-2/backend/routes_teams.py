"""Teams routes — depende de multi_equipes."""
from datetime import datetime, timezone, timedelta
from typing import Literal
from fastapi import APIRouter, Depends, HTTPException, Query, Request

from db import db
from models import (
    TeamCreate, TeamUpdate, TeamStatusUpdate, TeamMembersUpdate,
    new_id, utcnow_iso,
)
from security import resolve_tenant_context, require_roles
from feature_guard import require_feature
from audit import log_audit

router = APIRouter(prefix="/tenants/{tenant_slug}/teams", tags=["teams"])


def _store_allowed(membership, store_id):
    if membership["role"] in {"TENANT_ADMIN", "REGIONAL_MANAGER"}:
        return True
    return store_id in (membership.get("store_ids") or [])


async def _clean(cursor):
    items = await cursor.to_list(length=500)
    for it in items:
        it.pop("_id", None)
    return items


@router.get("")
async def list_teams(ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "multi_equipes")
    tenant_id = ctx["tenant"]["id"]
    q = {"tenant_id": tenant_id}
    if ctx["membership"]["role"] == "STORE_MANAGER":
        q["store_id"] = {"$in": ctx["membership"].get("store_ids") or []}
    teams = await _clean(db.teams.find(q).sort("name", 1))

    # Batch member count via aggregation
    team_ids = [t["id"] for t in teams]
    member_counts: dict = {}
    if team_ids:
        pipeline = [
            {"$match": {"tenant_id": tenant_id, "team_id": {"$in": team_ids}}},
            {"$group": {"_id": "$team_id", "count": {"$sum": 1}}},
        ]
        async for doc in db.seller_profiles.aggregate(pipeline):
            member_counts[doc["_id"]] = doc["count"]
    for t in teams:
        t["member_count"] = member_counts.get(t["id"], 0)
    return teams


@router.post("", status_code=201)
async def create_team(
    payload: TeamCreate, request: Request,
    ctx: dict = Depends(require_roles("TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER")),
):
    tenant = ctx["tenant"]
    await require_feature(tenant["id"], "multi_equipes")
    if not _store_allowed(ctx["membership"], payload.store_id):
        raise HTTPException(status_code=403, detail="Sem acesso a esta unidade.")
    store = await db.stores.find_one({"tenant_id": tenant["id"], "id": payload.store_id})
    if not store:
        raise HTTPException(status_code=404, detail="Unidade não encontrada.")
    now = utcnow_iso()
    team = {
        "id": new_id(), "tenant_id": tenant["id"], "store_id": payload.store_id,
        "name": payload.name, "description": payload.description,
        "status": "ACTIVE", "created_at": now, "updated_at": now,
    }
    await db.teams.insert_one(team)
    await log_audit(action="TEAM_CREATED", entity="team", entity_id=team["id"],
        tenant_id=tenant["id"], store_id=payload.store_id, user_id=ctx["user"]["id"],
        new_value={"name": team["name"]}, request=request)
    team.pop("_id", None)
    team["member_count"] = 0
    return team


# ── Rankings — DEVE ficar antes de /{team_id} para não ser capturado como parâmetro
@router.get("/rankings")
async def get_team_rankings(
    ctx: dict = Depends(resolve_tenant_context),
    period: Literal["week", "month", "all"] = Query(default="month"),
):
    """Ranking de equipes por vendas no período."""
    await require_feature(ctx["tenant"]["id"], "multi_equipes")
    tenant_id = ctx["tenant"]["id"]

    now = datetime.now(timezone.utc)
    if period == "week":
        start_dt = (now - timedelta(days=now.weekday())).replace(
            hour=0, minute=0, second=0, microsecond=0
        )
        start_iso = start_dt.isoformat()
    elif period == "month":
        start_iso = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0).isoformat()
    else:
        start_iso = None

    att_match: dict = {"tenant_id": tenant_id, "result": "SALE"}
    if start_iso:
        att_match["created_at"] = {"$gte": start_iso}

    pipeline = [
        {"$match": att_match},
        {
            "$lookup": {
                "from": "seller_profiles",
                "localField": "seller_id",
                "foreignField": "id",
                "as": "sp",
            }
        },
        {"$unwind": "$sp"},
        {"$match": {"sp.team_id": {"$ne": None}}},
        {
            "$group": {
                "_id": "$sp.team_id",
                "sales": {"$sum": 1},
                "revenue": {"$sum": {"$ifNull": ["$sale_amount_cents", 0]}},
            }
        },
        {"$sort": {"sales": -1}},
    ]

    raw = []
    async for doc in db.attendances.aggregate(pipeline):
        raw.append(doc)

    if not raw:
        return []

    team_ids = [r["_id"] for r in raw]
    teams_map: dict = {}
    async for t in db.teams.find({"tenant_id": tenant_id, "id": {"$in": team_ids}}):
        t.pop("_id", None)
        teams_map[t["id"]] = t

    store_ids = list({t["store_id"] for t in teams_map.values()})
    stores_map: dict = {}
    async for s in db.stores.find({"tenant_id": tenant_id, "id": {"$in": store_ids}}):
        s.pop("_id", None)
        stores_map[s["id"]] = s["name"]

    result = []
    for rank, r in enumerate(raw, start=1):
        team = teams_map.get(r["_id"])
        if not team:
            continue
        result.append({
            "rank": rank,
            "team_id": r["_id"],
            "team_name": team["name"],
            "store_name": stores_map.get(team["store_id"], ""),
            "sales": r["sales"],
            "revenue_cents": r["revenue"],
        })

    return result


@router.get("/{team_id}")
async def get_team(team_id: str, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "multi_equipes")
    team = await db.teams.find_one({"tenant_id": ctx["tenant"]["id"], "id": team_id})
    if not team:
        raise HTTPException(status_code=404, detail="Equipe não encontrada.")
    if not _store_allowed(ctx["membership"], team["store_id"]):
        raise HTTPException(status_code=403, detail="Sem acesso.")
    team.pop("_id", None)
    team["member_count"] = await db.seller_profiles.count_documents(
        {"tenant_id": ctx["tenant"]["id"], "team_id": team_id}
    )
    return team


@router.put("/{team_id}")
async def update_team(team_id: str, payload: TeamUpdate, request: Request,
    ctx: dict = Depends(require_roles("TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER"))):
    await require_feature(ctx["tenant"]["id"], "multi_equipes")
    team = await db.teams.find_one({"tenant_id": ctx["tenant"]["id"], "id": team_id})
    if not team:
        raise HTTPException(status_code=404, detail="Equipe não encontrada.")
    if not _store_allowed(ctx["membership"], team["store_id"]):
        raise HTTPException(status_code=403, detail="Sem acesso.")
    updates = {k: v for k, v in payload.model_dump(exclude_none=True).items()}
    if updates:
        updates["updated_at"] = utcnow_iso()
        await db.teams.update_one({"id": team_id}, {"$set": updates})
    await log_audit(action="TEAM_UPDATED", entity="team", entity_id=team_id,
        tenant_id=ctx["tenant"]["id"], store_id=team["store_id"], user_id=ctx["user"]["id"],
        new_value=updates, request=request)
    updated = await db.teams.find_one({"id": team_id})
    updated.pop("_id", None)
    updated["member_count"] = await db.seller_profiles.count_documents(
        {"tenant_id": ctx["tenant"]["id"], "team_id": team_id}
    )
    return updated


@router.get("/{team_id}/members")
async def list_team_members(team_id: str, ctx: dict = Depends(resolve_tenant_context)):
    """Lista os vendedores que pertencem a esta equipe."""
    await require_feature(ctx["tenant"]["id"], "multi_equipes")
    team = await db.teams.find_one({"tenant_id": ctx["tenant"]["id"], "id": team_id})
    if not team:
        raise HTTPException(status_code=404, detail="Equipe não encontrada.")
    if not _store_allowed(ctx["membership"], team["store_id"]):
        raise HTTPException(status_code=403, detail="Sem acesso.")

    sellers = await _clean(db.seller_profiles.find(
        {"tenant_id": ctx["tenant"]["id"], "team_id": team_id}
    ))
    user_ids = [s["user_id"] for s in sellers]
    users_map: dict = {}
    async for u in db.users.find({"id": {"$in": user_ids}}):
        u.pop("_id", None)
        users_map[u["id"]] = {
            "name": u.get("name", ""),
            "email": u.get("email", ""),
            "avatar_url": u.get("avatar_url"),
        }
    for s in sellers:
        s["user"] = users_map.get(s["user_id"], {})
    return sellers


@router.put("/{team_id}/members")
async def update_team_members(
    team_id: str,
    payload: TeamMembersUpdate,
    request: Request,
    ctx: dict = Depends(require_roles("TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER")),
):
    """Define a lista completa de membros de uma equipe."""
    await require_feature(ctx["tenant"]["id"], "multi_equipes")
    tenant = ctx["tenant"]
    team = await db.teams.find_one({"tenant_id": tenant["id"], "id": team_id})
    if not team:
        raise HTTPException(status_code=404, detail="Equipe não encontrada.")
    if not _store_allowed(ctx["membership"], team["store_id"]):
        raise HTTPException(status_code=403, detail="Sem acesso.")

    now = utcnow_iso()
    await db.seller_profiles.update_many(
        {"tenant_id": tenant["id"], "team_id": team_id},
        {"$set": {"team_id": None, "updated_at": now}},
    )

    if payload.seller_profile_ids:
        await db.seller_profiles.update_many(
            {
                "tenant_id": tenant["id"],
                "id": {"$in": payload.seller_profile_ids},
                "store_id": team["store_id"],
            },
            {"$set": {"team_id": team_id, "updated_at": now}},
        )

    member_count = await db.seller_profiles.count_documents(
        {"tenant_id": tenant["id"], "team_id": team_id}
    )

    await log_audit(
        action="TEAM_MEMBERS_UPDATED",
        entity="team",
        entity_id=team_id,
        tenant_id=tenant["id"],
        store_id=team["store_id"],
        user_id=ctx["user"]["id"],
        new_value={"seller_profile_ids": payload.seller_profile_ids, "member_count": member_count},
        request=request,
    )
    return {"team_id": team_id, "member_count": member_count}


@router.patch("/{team_id}/status")
async def status_team(team_id: str, payload: TeamStatusUpdate, request: Request,
    ctx: dict = Depends(require_roles("TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER"))):
    await require_feature(ctx["tenant"]["id"], "multi_equipes")
    team = await db.teams.find_one({"tenant_id": ctx["tenant"]["id"], "id": team_id})
    if not team:
        raise HTTPException(status_code=404, detail="Equipe não encontrada.")
    if not _store_allowed(ctx["membership"], team["store_id"]):
        raise HTTPException(status_code=403, detail="Sem acesso.")
    await db.teams.update_one({"id": team_id},
        {"$set": {"status": payload.status, "updated_at": utcnow_iso()}})
    await log_audit(action="TEAM_STATUS_CHANGED", entity="team", entity_id=team_id,
        tenant_id=ctx["tenant"]["id"], store_id=team["store_id"], user_id=ctx["user"]["id"],
        old_value={"status": team["status"]}, new_value={"status": payload.status}, request=request)
    return {"id": team_id, "status": payload.status}
