"""Store settings routes."""
from fastapi import APIRouter, Depends, HTTPException, Request
from pymongo.errors import DuplicateKeyError

from db import db
from models import StoreSettingsUpdate, new_id, utcnow_iso
from security import resolve_tenant_context, require_roles
from features import is_enabled
from audit import log_audit

router = APIRouter(prefix="/tenants/{tenant_slug}/stores/{store_id}/settings", tags=["store-settings"])

DEFAULT_QUEUE = {
    "allow_multiple_queues": False,
    "seller_can_join_multiple_queues": False,
    "return_to_end_after_attendance": True,
    "require_loss_reason": True,
    "require_sale_amount": True,
    "allow_invalid_attendance": True,
    "return_from_break_to_end": True,
    "notify_when_positions_before": 2,
    "allow_manager_reorder": True,
    "preference_enabled": True,
    "preference_return_rule": "PREVIOUS_POSITION",
}
DEFAULT_REALTIME = {"enabled": False, "fallback_polling_seconds": 5}
DEFAULT_NOTIFY = {
    "notify_seller_turn": True,
    "notify_positions_before": True,
    "notify_feedback_received": True,
}


def _store_allowed(membership, store_id):
    if membership["role"] in {"TENANT_ADMIN", "REGIONAL_MANAGER"}:
        return True
    return store_id in (membership.get("store_ids") or [])


async def ensure_settings(tenant_id: str, store_id: str):
    existing = await db.store_settings.find_one({"tenant_id": tenant_id, "store_id": store_id})
    if existing:
        return existing
    now = utcnow_iso()
    doc = {
        "id": new_id(), "tenant_id": tenant_id, "store_id": store_id,
        "queue_settings": DEFAULT_QUEUE.copy(),
        "realtime_settings": DEFAULT_REALTIME.copy(),
        "notification_settings": DEFAULT_NOTIFY.copy(),
        "created_at": now, "updated_at": now,
    }
    try:
        await db.store_settings.insert_one(doc)
    except DuplicateKeyError:
        return await db.store_settings.find_one({"tenant_id": tenant_id, "store_id": store_id})
    return doc


@router.get("")
async def get_settings(store_id: str, ctx: dict = Depends(resolve_tenant_context)):
    tenant = ctx["tenant"]
    store = await db.stores.find_one({"tenant_id": tenant["id"], "id": store_id})
    if not store:
        raise HTTPException(status_code=404, detail="Unidade não encontrada.")
    if not _store_allowed(ctx["membership"], store_id):
        raise HTTPException(status_code=403, detail="Sem acesso.")
    doc = await ensure_settings(tenant["id"], store_id)
    doc.pop("_id", None)
    return doc


@router.put("")
async def update_settings(
    store_id: str, payload: StoreSettingsUpdate, request: Request,
    ctx: dict = Depends(require_roles("TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER")),
):
    tenant = ctx["tenant"]
    store = await db.stores.find_one({"tenant_id": tenant["id"], "id": store_id})
    if not store:
        raise HTTPException(status_code=404, detail="Unidade não encontrada.")
    if not _store_allowed(ctx["membership"], store_id):
        raise HTTPException(status_code=403, detail="Sem acesso.")

    existing = await ensure_settings(tenant["id"], store_id)

    qs = {**existing["queue_settings"], **(payload.queue_settings or {})}
    if qs.get("preference_return_rule") not in {"TO_TOP", "PREVIOUS_POSITION", "TO_END", "CONSUME_TURN"}:
        qs["preference_return_rule"] = "PREVIOUS_POSITION"
    qs["preference_enabled"] = qs.get("preference_enabled", True) is not False
    rs = {**existing["realtime_settings"], **(payload.realtime_settings or {})}
    ns = {**existing["notification_settings"], **(payload.notification_settings or {})}

    # multi_filas gate
    if qs.get("allow_multiple_queues") or qs.get("seller_can_join_multiple_queues"):
        if not await is_enabled(tenant["id"], "multi_filas"):
            raise HTTPException(
                status_code=403,
                detail={
                    "error": "FEATURE_DISABLED",
                    "message": "Recurso de múltiplas filas não está disponível no plano atual.",
                },
            )

    now = utcnow_iso()
    await db.store_settings.update_one(
        {"id": existing["id"]},
        {"$set": {
            "queue_settings": qs, "realtime_settings": rs,
            "notification_settings": ns, "updated_at": now,
        }},
    )
    await log_audit(action="STORE_SETTINGS_UPDATED", entity="store_settings",
        entity_id=existing["id"], tenant_id=tenant["id"], store_id=store_id,
        user_id=ctx["user"]["id"], new_value={"queue_settings": qs}, request=request)
    doc = await db.store_settings.find_one({"id": existing["id"]})
    doc.pop("_id", None)
    return doc
