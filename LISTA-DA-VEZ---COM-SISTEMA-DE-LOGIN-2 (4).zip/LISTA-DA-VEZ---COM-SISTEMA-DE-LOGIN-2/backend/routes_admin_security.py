"""Painel de segurança — apenas SUPER_ADMIN — Etapa 13."""
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, Query, Request

from db import db, client
from realtime import event_bus
from security import require_super_admin
from session_service import revoke_session, list_sessions

router = APIRouter(
    prefix="/admin",
    tags=["admin-security"],
    dependencies=[Depends(require_super_admin)],
)


async def _to_list(cursor, limit=200):
    items = await cursor.to_list(length=limit)
    for it in items:
        it.pop("_id", None)
    return items


# ── Eventos de Segurança ────────────────────────────────────────────────────
@router.get("/security/events")
async def list_security_events(
    tenant_id: Optional[str] = Query(None),
    tenant_slug: Optional[str] = Query(None),
    event_type: Optional[str] = Query(None),
    severity: Optional[str] = Query(None),
    limit: int = Query(100, le=500),
):
    query: dict = {}
    if tenant_id:
        query["tenant_id"] = tenant_id
    if tenant_slug:
        query["tenant_slug"] = tenant_slug
    if event_type:
        query["event_type"] = event_type
    if severity:
        query["severity"] = severity
    return await _to_list(
        db.security_events.find(query, {"_id": 0}).sort("created_at", -1),
        limit=limit,
    )


# ── Sessões ────────────────────────────────────────────────────────────────
@router.get("/security/sessions")
async def list_all_sessions(
    tenant_id: Optional[str] = Query(None),
    user_id: Optional[str] = Query(None),
    active_only: bool = Query(True),
    limit: int = Query(100, le=500),
):
    return await list_sessions(
        tenant_id=tenant_id, user_id=user_id, active_only=active_only, limit=limit
    )


@router.post("/security/sessions/{session_id}/revoke")
async def revoke_session_endpoint(
    session_id: str,
    request: Request,
    actor: dict = Depends(require_super_admin),
):
    session = await db.auth_sessions.find_one({"id": session_id})
    if not session:
        raise HTTPException(status_code=404, detail="Sessão não encontrada.")
    await revoke_session(session_id, reason="REVOKED_BY_ADMIN")

    from security_event_service import log_security_event, SecurityEventType
    await log_security_event(
        event_type=SecurityEventType.SESSION_REVOKED,
        tenant_id=session.get("tenant_id"),
        user_id=session.get("user_id"),
        session_id=session_id,
        metadata={"revoked_by": actor["id"]},
        request=request,
    )
    return {"message": "Sessão revogada."}


# ── Eventos de Rate Limit ─────────────────────────────────────────────────
@router.get("/security/rate-limit-events")
async def list_rate_limit_events(limit: int = Query(100, le=500)):
    return await _to_list(
        db.security_events.find(
            {"event_type": "RATE_LIMIT_EXCEEDED"}, {"_id": 0}
        ).sort("created_at", -1),
        limit=limit,
    )


# ── Idempotência ──────────────────────────────────────────────────────────
@router.get("/security/idempotency-keys")
async def list_idempotency_keys(
    tenant_id: Optional[str] = Query(None),
    limit: int = Query(100, le=500),
):
    query: dict = {}
    if tenant_id:
        query["tenant_id"] = tenant_id
    return await _to_list(
        db.idempotency_keys.find(query, {"_id": 0, "payload_hash": 0}).sort("created_at", -1),
        limit=limit,
    )


# ── Logs Técnicos ─────────────────────────────────────────────────────────
@router.get("/system/logs")
async def list_technical_logs(
    level: Optional[str] = Query(None),
    limit: int = Query(100, le=500),
):
    query: dict = {}
    if level:
        query["level"] = level
    return await _to_list(
        db.technical_logs.find(query, {"_id": 0}).sort("created_at", -1),
        limit=limit,
    )


# ── Métricas de Sistema ───────────────────────────────────────────────────
@router.get("/system/metrics")
async def system_metrics():
    total_tenants = await db.tenants.count_documents({})
    active_tenants = await db.tenants.count_documents({"status": {"$in": ["ACTIVE", "TRIAL"]}})
    total_users = await db.users.count_documents({})
    active_users = await db.users.count_documents({"status": "ACTIVE"})
    total_sessions = await db.auth_sessions.count_documents({})
    active_sessions = await db.auth_sessions.count_documents({"revoked_at": None})

    # Últimas 24h
    from datetime import datetime, timezone, timedelta
    from models import utcnow_iso
    since_24h = (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat()
    logins_24h = await db.security_events.count_documents(
        {"event_type": "LOGIN_SUCCESS", "created_at": {"$gte": since_24h}}
    )
    failed_logins_24h = await db.security_events.count_documents(
        {"event_type": "LOGIN_FAILED", "created_at": {"$gte": since_24h}}
    )
    rate_limits_24h = await db.security_events.count_documents(
        {"event_type": "RATE_LIMIT_EXCEEDED", "created_at": {"$gte": since_24h}}
    )
    tenant_mismatches_24h = await db.security_events.count_documents(
        {"event_type": "TENANT_SESSION_MISMATCH", "created_at": {"$gte": since_24h}}
    )

    return {
        "tenants": {"total": total_tenants, "active": active_tenants},
        "users": {"total": total_users, "active": active_users},
        "sessions": {"total": total_sessions, "active": active_sessions},
        "last_24h": {
            "logins_success": logins_24h,
            "logins_failed": failed_logins_24h,
            "rate_limit_exceeded": rate_limits_24h,
            "tenant_session_mismatch": tenant_mismatches_24h,
        },
        "realtime": {
            "active_connections": event_bus.get_active_connections_count(),
            "mode": event_bus.mode,
        },
    }


# ── Health Detalhado (Super Admin) ────────────────────────────────────────
@router.get("/system/health")
async def detailed_health():
    try:
        await client.admin.command("ping")
        db_status = "ok"
        tenant_count = await db.tenants.estimated_document_count()
    except Exception as e:
        db_status = f"error: {e}"
        tenant_count = None

    return {
        "status": "ok",
        "version": "1.0.0-etapa-13",
        "db": {"status": db_status, "tenant_count": tenant_count},
        "realtime": {
            "mode": event_bus.mode,
            "active_connections": event_bus.get_active_connections_count(),
        },
    }


# ── MFA Configs (visualização) ────────────────────────────────────────────
@router.get("/security/mfa")
async def list_mfa_configs(limit: int = Query(50, le=200)):
    items = await db.mfa_configs.find(
        {}, {"_id": 0, "totp_secret": 0, "recovery_codes_hashed": 0}
    ).sort("enabled_at", -1).to_list(length=limit)
    return items


from pydantic import BaseModel


class MFAConfirmRequest(BaseModel):
    code: str


@router.post("/security/mfa/setup")
async def setup_mfa(actor: dict = Depends(require_super_admin)):
    from mfa_service import setup_mfa as _setup_mfa
    return await _setup_mfa(actor["id"], actor["email"])


@router.post("/security/mfa/confirm")
async def confirm_mfa(payload: MFAConfirmRequest, actor: dict = Depends(require_super_admin)):
    from mfa_service import confirm_mfa_setup
    success = await confirm_mfa_setup(actor["id"], payload.code)
    if not success:
        raise HTTPException(status_code=400, detail="Código TOTP inválido.")
    return {"message": "MFA ativado com sucesso."}
