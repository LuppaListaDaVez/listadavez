"""RetentionPolicyService — Políticas de retenção e jobs (Etapa 14)."""
from typing import Optional
from db import db
from models import new_id, utcnow_iso
from audit import log_audit

# Políticas padrão — mínimos seguros
DEFAULT_POLICIES = [
    {"data_category": "CUSTOMER_VISITS",   "retention_days": 730,  "action_after_retention": "ANONYMIZE"},
    {"data_category": "ATTENDANCES",       "retention_days": 730,  "action_after_retention": "ANONYMIZE"},
    {"data_category": "SALES",             "retention_days": 1825, "action_after_retention": "ANONYMIZE"},
    {"data_category": "SALE_ITEMS",        "retention_days": 1825, "action_after_retention": "KEEP"},
    {"data_category": "FEEDBACKS",         "retention_days": 730,  "action_after_retention": "ANONYMIZE"},
    {"data_category": "NOTIFICATIONS",     "retention_days": 90,   "action_after_retention": "DELETE"},
    {"data_category": "MOTIVATION_EVENTS", "retention_days": 365,  "action_after_retention": "DELETE"},
    {"data_category": "AUDIT_LOGS",        "retention_days": 1825, "action_after_retention": "KEEP"},
    {"data_category": "SECURITY_EVENTS",   "retention_days": 1825, "action_after_retention": "KEEP"},
    {"data_category": "API_REQUEST_LOGS",  "retention_days": 90,   "action_after_retention": "DELETE"},
    {"data_category": "REPORT_EXPORTS",    "retention_days": 30,   "action_after_retention": "DELETE"},
    {"data_category": "BACKUPS",           "retention_days": 90,   "action_after_retention": "DELETE"},
]

MIN_RETENTION = {"AUDIT_LOGS": 365, "SECURITY_EVENTS": 365, "SALES": 365, "SALE_ITEMS": 365}


async def seed_default_policies(tenant_id: str, created_by: str = "system"):
    now = utcnow_iso()
    for p in DEFAULT_POLICIES:
        existing = await db.data_retention_policies.find_one(
            {"tenant_id": tenant_id, "data_category": p["data_category"]}
        )
        if not existing:
            await db.data_retention_policies.insert_one({
                "id": new_id(), "tenant_id": tenant_id,
                **p,
                "is_default": True, "is_active": True, "legal_hold_exempt": False,
                "created_by": created_by, "created_at": now, "updated_at": now,
            })


async def list_policies(tenant_id: str) -> list:
    cursor = db.data_retention_policies.find({"tenant_id": tenant_id}, {"_id": 0})
    return await cursor.to_list(length=200)


async def get_policy(tenant_id: str, policy_id: str) -> Optional[dict]:
    doc = await db.data_retention_policies.find_one({"id": policy_id, "tenant_id": tenant_id})
    if doc:
        doc.pop("_id", None)
    return doc


async def update_policy(tenant_id: str, policy_id: str, data: dict,
                        user_id: str, request=None) -> Optional[dict]:
    doc = await db.data_retention_policies.find_one({"id": policy_id, "tenant_id": tenant_id})
    if not doc:
        return None
    # Validar mínimos seguros
    new_days = data.get("retention_days", doc["retention_days"])
    cat = doc["data_category"]
    min_days = MIN_RETENTION.get(cat, 0)
    if new_days < min_days:
        raise ValueError(f"Retenção mínima para {cat} é {min_days} dias.")
    now = utcnow_iso()
    upd = {k: v for k, v in data.items() if k in ("retention_days", "action_after_retention", "is_active")}
    upd["updated_at"] = now
    await db.data_retention_policies.update_one({"id": policy_id}, {"$set": upd})
    await log_audit(action="RETENTION_POLICY_UPDATED", entity="retention_policy",
                    entity_id=policy_id, tenant_id=tenant_id, user_id=user_id,
                    old_value=doc, new_value=upd, request=request)
    doc.update(upd)
    doc.pop("_id", None)
    return doc


async def preview_policy(tenant_id: str, policy_id: str) -> dict:
    """Retorna estimativa de documentos afetados sem executar."""
    policy = await get_policy(tenant_id, policy_id)
    if not policy:
        return {"error": "Política não encontrada"}
    
    from datetime import datetime, timezone, timedelta
    cutoff = (datetime.now(timezone.utc) - timedelta(days=policy["retention_days"])).isoformat()
    
    collection_map = {
        "CUSTOMER_VISITS": "customer_visits",
        "ATTENDANCES": "attendances",
        "SALES": "sales",
        "SALE_ITEMS": "sale_items",
        "FEEDBACKS": "feedbacks",
        "NOTIFICATIONS": "notifications",
        "MOTIVATION_EVENTS": "motivation_events",
        "AUDIT_LOGS": "audit_logs",
        "REPORT_EXPORTS": "data_subject_exports",
    }
    coll_name = collection_map.get(policy["data_category"])
    count = 0
    if coll_name:
        coll = getattr(db, coll_name)
        count = await coll.count_documents({"tenant_id": tenant_id, "created_at": {"$lt": cutoff}})
    
    return {
        "policy_id": policy_id,
        "data_category": policy["data_category"],
        "cutoff_date": cutoff,
        "estimated_records_affected": count,
        "action": policy["action_after_retention"],
        "is_dry_run": True,
    }


async def run_job(tenant_id: str, policy_id: str, user_id: str, request=None) -> dict:
    """Executa job de retenção."""
    policy = await get_policy(tenant_id, policy_id)
    if not policy:
        raise ValueError("Política não encontrada")
    
    # Verificar legal hold
    hold = await db.legal_holds.find_one({
        "tenant_id": tenant_id, "status": "ACTIVE",
        "data_category": policy["data_category"]
    })
    if hold:
        raise ValueError(f"Dados sob legal hold ativo: {hold.get('name')}")
    
    from datetime import datetime, timezone, timedelta
    cutoff = (datetime.now(timezone.utc) - timedelta(days=policy["retention_days"])).isoformat()
    
    now = utcnow_iso()
    job = {
        "id": new_id(), "tenant_id": tenant_id, "policy_id": policy_id,
        "data_category": policy["data_category"], "status": "RUNNING",
        "started_at": now, "finished_at": None, "records_scanned": 0,
        "records_affected": 0, "error_code": None, "error_message": None,
        "created_by": user_id, "created_at": now,
    }
    await db.retention_jobs.insert_one(job)
    job_id = job["id"]
    
    collection_map = {
        "NOTIFICATIONS": ("notifications", "DELETE"),
        "MOTIVATION_EVENTS": ("motivation_events", "DELETE"),
        "REPORT_EXPORTS": ("data_subject_exports", "DELETE"),
    }
    affected = 0
    try:
        if policy["data_category"] in collection_map:
            coll_name, action = collection_map[policy["data_category"]]
            coll = getattr(db, coll_name)
            filt = {"tenant_id": tenant_id, "created_at": {"$lt": cutoff}}
            scanned = await coll.count_documents(filt)
            if action == "DELETE" and policy["action_after_retention"] == "DELETE":
                result = await coll.delete_many(filt)
                affected = result.deleted_count
            else:
                affected = scanned  # preview
        
        await db.retention_jobs.update_one({"id": job_id}, {"$set": {
            "status": "COMPLETED", "finished_at": utcnow_iso(),
            "records_scanned": affected, "records_affected": affected,
        }})
        await log_audit(action="RETENTION_JOB_COMPLETED", entity="retention_job",
                        entity_id=job_id, tenant_id=tenant_id, user_id=user_id, request=request)
    except Exception as e:
        await db.retention_jobs.update_one({"id": job_id}, {"$set": {
            "status": "FAILED", "finished_at": utcnow_iso(), "error_message": str(e)[:200],
        }})
        raise
    
    job.update({"status": "COMPLETED", "records_affected": affected})
    job.pop("_id", None)
    return job


async def list_jobs(tenant_id: str, limit: int = 20) -> list:
    cursor = db.retention_jobs.find({"tenant_id": tenant_id}, {"_id": 0}).sort("created_at", -1).limit(limit)
    return await cursor.to_list(length=limit)
