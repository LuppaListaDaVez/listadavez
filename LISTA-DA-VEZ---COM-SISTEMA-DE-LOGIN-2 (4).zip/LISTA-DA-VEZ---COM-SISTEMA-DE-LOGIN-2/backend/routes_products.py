"""Produtos (Etapa 5) — CRUD gated por feature `produtos`."""
from fastapi import APIRouter, Depends, HTTPException, Request
from pymongo.errors import DuplicateKeyError

from db import db
from models import ProductCreate, ProductUpdate, ProductStatusUpdate, new_id, utcnow_iso
from security import resolve_tenant_context, require_roles
from feature_guard import require_feature
from audit import log_audit

router = APIRouter(prefix="/tenants/{tenant_slug}/products", tags=["products"])

MANAGER_ROLES = ("TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER")


@router.get("")
async def list_products(active: bool = None, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "produtos")
    q = {"tenant_id": ctx["tenant"]["id"]}
    if active is not None:
        q["active"] = active
    items = await db.products.find(q).sort("name", 1).to_list(1000)
    for it in items:
        it.pop("_id", None)
    return items


@router.post("", status_code=201)
async def create_product(payload: ProductCreate, request: Request,
                         ctx: dict = Depends(require_roles(*MANAGER_ROLES))):
    tenant = ctx["tenant"]
    await require_feature(tenant["id"], "produtos")
    if payload.price_cents is None or payload.price_cents < 0:
        raise HTTPException(status_code=400, detail="Preço deve ser um inteiro em centavos.")
    if payload.sku:
        existing = await db.products.find_one({"tenant_id": tenant["id"], "sku": payload.sku})
        if existing:
            raise HTTPException(status_code=409, detail="Já existe um produto com este SKU.")
    now = utcnow_iso()
    doc = {
        "id": new_id(), "tenant_id": tenant["id"], "store_id": None,
        "sku": payload.sku, "name": payload.name, "description": payload.description,
        "price_cents": payload.price_cents, "category": payload.category,
        "active": payload.active if payload.active is not None else True,
        "created_at": now, "updated_at": now,
    }
    try:
        await db.products.insert_one(doc)
    except DuplicateKeyError:
        raise HTTPException(status_code=409, detail="Já existe um produto com este SKU.")
    await log_audit(action="PRODUCT_CREATED", entity="product", entity_id=doc["id"],
                    tenant_id=tenant["id"], store_id=None, user_id=ctx["user"]["id"],
                    new_value={"name": doc["name"], "sku": doc["sku"]}, request=request)
    doc.pop("_id", None)
    return doc


@router.get("/{product_id}")
async def get_product(product_id: str, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "produtos")
    p = await db.products.find_one({"tenant_id": ctx["tenant"]["id"], "id": product_id})
    if not p:
        raise HTTPException(status_code=404, detail="Produto não encontrado.")
    p.pop("_id", None)
    return p


@router.put("/{product_id}")
async def update_product(product_id: str, payload: ProductUpdate, request: Request,
                         ctx: dict = Depends(require_roles(*MANAGER_ROLES))):
    tenant = ctx["tenant"]
    await require_feature(tenant["id"], "produtos")
    p = await db.products.find_one({"tenant_id": tenant["id"], "id": product_id})
    if not p:
        raise HTTPException(status_code=404, detail="Produto não encontrado.")
    updates = {k: v for k, v in payload.model_dump(exclude_none=True).items()}
    if "price_cents" in updates and updates["price_cents"] < 0:
        raise HTTPException(status_code=400, detail="Preço deve ser um inteiro em centavos.")
    if updates.get("sku") and updates["sku"] != p.get("sku"):
        dup = await db.products.find_one({"tenant_id": tenant["id"], "sku": updates["sku"]})
        if dup:
            raise HTTPException(status_code=409, detail="Já existe um produto com este SKU.")
    if updates:
        updates["updated_at"] = utcnow_iso()
        try:
            await db.products.update_one({"id": product_id}, {"$set": updates})
        except DuplicateKeyError:
            raise HTTPException(status_code=409, detail="Já existe um produto com este SKU.")
    await log_audit(action="PRODUCT_UPDATED", entity="product", entity_id=product_id,
                    tenant_id=tenant["id"], store_id=None, user_id=ctx["user"]["id"],
                    new_value=updates, request=request)
    updated = await db.products.find_one({"id": product_id})
    updated.pop("_id", None)
    return updated


@router.patch("/{product_id}/status")
async def status_product(product_id: str, payload: ProductStatusUpdate, request: Request,
                         ctx: dict = Depends(require_roles(*MANAGER_ROLES))):
    tenant = ctx["tenant"]
    await require_feature(tenant["id"], "produtos")
    p = await db.products.find_one({"tenant_id": tenant["id"], "id": product_id})
    if not p:
        raise HTTPException(status_code=404, detail="Produto não encontrado.")
    await db.products.update_one({"id": product_id},
                                 {"$set": {"active": payload.active, "updated_at": utcnow_iso()}})
    await log_audit(action="PRODUCT_STATUS_CHANGED", entity="product", entity_id=product_id,
                    tenant_id=tenant["id"], store_id=None, user_id=ctx["user"]["id"],
                    old_value={"active": p.get("active")}, new_value={"active": payload.active}, request=request)
    return {"id": product_id, "active": payload.active}
