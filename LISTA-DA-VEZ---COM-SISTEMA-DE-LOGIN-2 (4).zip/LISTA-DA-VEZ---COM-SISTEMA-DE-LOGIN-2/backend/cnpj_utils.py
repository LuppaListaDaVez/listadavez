"""Utilitários de validação e normalização de CNPJ.

Implementa o cálculo padrão de dígito verificador (módulo 11, dois dígitos).
Aceita CNPJ com ou sem máscara (ex: "11.222.333/0001-81" ou "11222333000181").
"""
import re


def normalizar_cnpj(cnpj: str) -> str:
    """Remove caracteres não numéricos e retorna string de 14 dígitos (ou menos se inválido)."""
    return re.sub(r"\D", "", cnpj or "")


def validar_cnpj(cnpj: str) -> bool:
    """Valida CNPJ usando o algoritmo oficial de módulo 11.

    Retorna True se válido, False caso contrário.
    Aceita string com ou sem máscara — normaliza internamente.
    """
    nums = normalizar_cnpj(cnpj)

    if len(nums) != 14:
        return False

    # Rejeita sequências com todos os dígitos iguais (ex: "00000000000000")
    if nums == nums[0] * 14:
        return False

    # Primeiro dígito verificador
    pesos1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    soma1 = sum(int(nums[i]) * pesos1[i] for i in range(12))
    resto1 = soma1 % 11
    d1 = 0 if resto1 < 2 else 11 - resto1

    if int(nums[12]) != d1:
        return False

    # Segundo dígito verificador
    pesos2 = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    soma2 = sum(int(nums[i]) * pesos2[i] for i in range(13))
    resto2 = soma2 % 11
    d2 = 0 if resto2 < 2 else 11 - resto2

    return int(nums[13]) == d2
