"""FeedbackService — Etapa 10. Feedbacks de gerentes para vendedores + planos de ação."""
from datetime import datetime, timezone
from typing import Optional

from fastapi import HTTPException

from db import db
from models import new_id, utcnow_iso
from audit import log_audit

FEEDBACK_TYPES = {"POSITIVE", "CONSTRUCTIVE", "WARNING", "ACTION_PLAN"}
ACTION_PLAN_STATUSES = {"PENDING", "IN_PROGRESS", "COMPLETED"}


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


async def create_feedback(
    *,
    tenant_id: str,
    author_id: str,
    author_name: str,
    data: dict,
    request=None,
) -> dict:
    ftype = data.get("type", "").upper()
    if ftype not in FEEDBACK_TYPES:
        raise HTTPException(400, f"Tipo de feedback inválido: {ftype}")

    seller_id = data.get("seller_id")
    if not seller_id:
        raise HTTPException(400, "seller_id é obrigatório.")

    # Resolver seller_profile → validar existência + capturar user_id e store_id
    seller_profile = await db.seller_profiles.find_one({"tenant_id": tenant_id, "id": seller_id})
    if not seller_profile:
        raise HTTPException(404, "Vendedor não encontrado.")

    # Buscar nome do vendedor
    seller_user = await db.users.find_one({"id": seller_profile.get("user_id")})
    seller_name = seller_user.get("name", "Vendedor") if seller_user else "Vendedor"

    title = str(data.get("title", "")).strip()
    content = str(data.get("content", "")).strip()
    if not title:
        raise HTTPException(400, "O título é obrigatório.")
    if not content:
        raise HTTPException(400, "O conteúdo é obrigatório.")

    # Plano de ação obrigatório para ACTION_PLAN
    action_plan = None
    ap_data = data.get("action_plan")
    if ftype == "ACTION_PLAN":
        if not ap_data or not ap_data.get("description"):
            raise HTTPException(400, "Plano de ação com descrição é obrigatório para este tipo.")
        action_plan = {
            "description": str(ap_data["description"]).strip(),
            "due_date": ap_data.get("due_date"),
            "status": "PENDING",
        }
    elif ap_data and ap_data.get("description"):
        # Plano de ação opcional para outros tipos
        action_plan = {
            "description": str(ap_data["description"]).strip(),
            "due_date": ap_data.get("due_date"),
            "status": "PENDING",
        }

    now = _now_iso()
    feedback_id = new_id()
    doc = {
        "id": feedback_id,
        "tenant_id": tenant_id,
        "store_id": seller_profile.get("store_id"),
        "seller_id": seller_id,
        "seller_name": seller_name,
        "seller_user_id": seller_profile.get("user_id"),
        "author_id": author_id,
        "author_name": author_name,
        "type": ftype,
        "title": title,
        "content": content,
        "action_plan": action_plan,
        "period_start": data.get("period_start"),
        "period_end": data.get("period_end"),
        "is_acknowledged": False,
        "acknowledged_at": None,
        "created_at": now,
        "updated_at": now,
    }

    await db.feedbacks.insert_one(doc)
    doc.pop("_id", None)

    await log_audit(
        action="FEEDBACK_CREATED", entity="feedback", entity_id=feedback_id,
        tenant_id=tenant_id, user_id=author_id,
        new_value={"type": ftype, "title": title, "seller_id": seller_id},
        request=request,
    )

    # Criar notificação para o vendedor
    try:
        from notification_service import create_notification
        seller_user = await db.users.find_one({"id": seller_profile.get("user_id")})
        seller_name = seller_user.get("name", "Vendedor") if seller_user else "Vendedor"
        type_labels = {
            "POSITIVE": "Feedback Positivo",
            "CONSTRUCTIVE": "Feedback Construtivo",
            "WARNING": "Aviso",
            "ACTION_PLAN": "Plano de Ação",
        }
        await create_notification(
            tenant_id=tenant_id,
            user_id=seller_profile["user_id"],
            ntype="FEEDBACK_RECEIVED",
            title=f"Novo feedback: {type_labels.get(ftype, ftype)}",
            body=f'{author_name} enviou um feedback: "{title}"',
            entity_type="feedback",
            entity_id=feedback_id,
        )
    except Exception:
        pass  # notificação falha silenciosamente

    return doc


async def _enrich_feedback(doc: dict, tenant_id: str) -> dict:
    """Adiciona seller_name se não estiver presente."""
    if not doc.get("seller_name") and doc.get("seller_id"):
        sp = await db.seller_profiles.find_one({"tenant_id": tenant_id, "id": doc["seller_id"]})
        if sp and sp.get("user_id"):
            u = await db.users.find_one({"id": sp["user_id"]})
            doc["seller_name"] = u.get("name", "Vendedor") if u else "Vendedor"
    return doc


async def get_feedback(tenant_id: str, feedback_id: str) -> dict:
    doc = await db.feedbacks.find_one({"tenant_id": tenant_id, "id": feedback_id})
    if not doc:
        raise HTTPException(404, "Feedback não encontrado.")
    doc.pop("_id", None)
    return await _enrich_feedback(doc, tenant_id)


async def list_feedbacks(tenant_id: str, filters: dict) -> list:
    q: dict = {"tenant_id": tenant_id}
    for key in ("seller_id", "author_id", "type", "store_id"):
        if filters.get(key):
            q[key] = filters[key]
    if filters.get("is_acknowledged") is not None:
        q["is_acknowledged"] = filters["is_acknowledged"]

    raw = await db.feedbacks.find(q).sort("created_at", -1).limit(200).to_list(200)
    result = []
    for doc in raw:
        doc.pop("_id", None)
        result.append(await _enrich_feedback(doc, tenant_id))
    return result


async def update_feedback(
    *,
    tenant_id: str,
    feedback_id: str,
    actor_user_id: str,
    data: dict,
    request=None,
) -> dict:
    feedback = await get_feedback(tenant_id, feedback_id)
    allowed = {"title", "content", "type"}
    update: dict = {}
    for k in allowed:
        if k in data and data[k] is not None:
            update[k] = data[k]

    if "type" in update:
        t = update["type"].upper()
        if t not in FEEDBACK_TYPES:
            raise HTTPException(400, f"Tipo inválido: {t}")
        update["type"] = t

    if not update:
        return feedback

    update["updated_at"] = _now_iso()
    await db.feedbacks.update_one({"tenant_id": tenant_id, "id": feedback_id}, {"$set": update})
    await log_audit(
        action="FEEDBACK_UPDATED", entity="feedback", entity_id=feedback_id,
        tenant_id=tenant_id, user_id=actor_user_id,
        old_value={k: feedback.get(k) for k in update},
        new_value=update,
        request=request,
    )
    return await get_feedback(tenant_id, feedback_id)


async def acknowledge_feedback(
    *,
    tenant_id: str,
    feedback_id: str,
    seller_user_id: str,
) -> dict:
    """Vendedor confirma leitura do feedback."""
    feedback = await get_feedback(tenant_id, feedback_id)
    if feedback.get("is_acknowledged"):
        return feedback  # já confirmado

    now = _now_iso()
    await db.feedbacks.update_one(
        {"tenant_id": tenant_id, "id": feedback_id},
        {"$set": {"is_acknowledged": True, "acknowledged_at": now, "updated_at": now}},
    )
    return await get_feedback(tenant_id, feedback_id)


async def update_action_plan(
    *,
    tenant_id: str,
    feedback_id: str,
    actor_user_id: str,
    data: dict,
) -> dict:
    """Atualiza status/descrição do plano de ação."""
    feedback = await get_feedback(tenant_id, feedback_id)
    if not feedback.get("action_plan"):
        raise HTTPException(400, "Este feedback não possui plano de ação.")

    new_status = data.get("status", "").upper()
    if new_status and new_status not in ACTION_PLAN_STATUSES:
        raise HTTPException(400, f"Status inválido: {new_status}. Use: PENDING, IN_PROGRESS, COMPLETED.")

    plan = dict(feedback["action_plan"])
    if new_status:
        plan["status"] = new_status
    if data.get("description"):
        plan["description"] = str(data["description"]).strip()
    if data.get("due_date"):
        plan["due_date"] = data["due_date"]

    now = _now_iso()
    await db.feedbacks.update_one(
        {"tenant_id": tenant_id, "id": feedback_id},
        {"$set": {"action_plan": plan, "updated_at": now}},
    )
    return await get_feedback(tenant_id, feedback_id)
