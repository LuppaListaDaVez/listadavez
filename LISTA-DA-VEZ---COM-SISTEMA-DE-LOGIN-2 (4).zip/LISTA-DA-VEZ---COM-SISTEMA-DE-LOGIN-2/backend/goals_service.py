"""GoalsService — Etapa 9.

Regras monetárias:
  - REVENUE e AVERAGE_TICKET: valores em centavos (inteiros)
  - CONVERSION: basis points (70% = 7000, 100% = 10000)
  - ATTENDANCES, SALES_COUNT, ITEMS_SOLD: inteiros simples
"""
from datetime import datetime, timezone, date, time
from typing import Optional
from zoneinfo import ZoneInfo

from fastapi import HTTPException

from db import db
from models import new_id, utcnow_iso
from audit import log_audit

GOAL_TYPES = {"REVENUE", "CONVERSION", "AVERAGE_TICKET", "ATTENDANCES", "SALES_COUNT", "ITEMS_SOLD"}
GOAL_SCOPES = {"TENANT", "STORE", "TEAM", "SELLER"}
GOAL_PERIODS = {"DAILY", "WEEKLY", "MONTHLY", "CUSTOM"}
GOAL_STATUSES = {"SCHEDULED", "ACTIVE", "COMPLETED", "CANCELLED", "EXPIRED", "PAUSED"}
GOAL_REFRESHABLE_STATUSES = {"SCHEDULED", "ACTIVE", "EXPIRED"}
GOAL_STATUS_LABELS = {
    "SCHEDULED": "Agendada",
    "ACTIVE": "Em andamento",
    "COMPLETED": "Atingida",
    "EXPIRED": "Encerrada sem atingir",
    "PAUSED": "Pausada",
    "CANCELLED": "Cancelada",
}
GOAL_STATUS_ALIASES = {
    "AGENDADA": "SCHEDULED",
    "EM ANDAMENTO": "ACTIVE",
    "ATINGIDA": "COMPLETED",
    "ENCERRADA SEM ATINGIR": "EXPIRED",
    "PAUSADA": "PAUSED",
    "CANCELADA": "CANCELLED",
    "ATIVA": "ACTIVE",
    "CONCLUIDA": "COMPLETED",
    "CONCLUÍDA": "COMPLETED",
    "EXPIRADA": "EXPIRED",
}


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _today_str() -> str:
    return date.today().isoformat()


def normalize_goal_status_filter(value: Optional[str]) -> Optional[str]:
    if not value:
        return None
    raw = str(value).strip()
    upper = raw.upper()
    if upper in GOAL_STATUSES:
        return upper
    return GOAL_STATUS_ALIASES.get(upper)


async def _goal_timezone(tenant_id: str, goal: dict) -> ZoneInfo:
    tz_name = None
    store_id = goal.get("store_id")
    if not store_id and goal.get("seller_id"):
        sp = await db.seller_profiles.find_one(
            {"tenant_id": tenant_id, "id": goal["seller_id"]},
            {"_id": 0, "store_id": 1},
        )
        store_id = (sp or {}).get("store_id")
    if not store_id and goal.get("team_id"):
        sp = await db.seller_profiles.find_one(
            {"tenant_id": tenant_id, "team_id": goal["team_id"]},
            {"_id": 0, "store_id": 1},
        )
        store_id = (sp or {}).get("store_id")
    if store_id:
        store = await db.stores.find_one(
            {"tenant_id": tenant_id, "id": store_id},
            {"_id": 0, "timezone": 1},
        )
        tz_name = (store or {}).get("timezone")
    if not tz_name:
        store = await db.stores.find_one({"tenant_id": tenant_id}, {"_id": 0, "timezone": 1})
        tz_name = (store or {}).get("timezone")
    try:
        return ZoneInfo(tz_name or "America/Sao_Paulo")
    except Exception:
        return ZoneInfo("America/Sao_Paulo")


def _local_date_to_utc_iso(value: Optional[str], tz: ZoneInfo, end_of_day: bool = False) -> Optional[str]:
    if not value:
        return None
    value = str(value)[:10]
    parsed = datetime.strptime(value, "%Y-%m-%d").date()
    local_time = time.max if end_of_day else time.min
    local_dt = datetime.combine(parsed, local_time, tzinfo=tz)
    return local_dt.astimezone(timezone.utc).isoformat()


async def _goal_period_bounds(tenant_id: str, goal: dict) -> tuple[Optional[str], Optional[str], str]:
    tz = await _goal_timezone(tenant_id, goal)
    today = datetime.now(tz).date().isoformat()
    return (
        _local_date_to_utc_iso(goal.get("period_start"), tz, end_of_day=False),
        _local_date_to_utc_iso(goal.get("period_end"), tz, end_of_day=True),
        today,
    )


def _derive_goal_status(goal: dict, current: int, target: int, today: str) -> tuple[str, Optional[str]]:
    raw_status = str(goal.get("status") or "ACTIVE").upper()
    completed_at = goal.get("completed_at")
    if raw_status == "CANCELLED":
        return "CANCELLED", completed_at
    if raw_status == "PAUSED":
        return "PAUSED", completed_at
    if target > 0 and current >= target:
        return "COMPLETED", completed_at or _now_iso()
    period_start = str(goal.get("period_start") or "")[:10]
    period_end = str(goal.get("period_end") or "")[:10]
    if period_start and today < period_start:
        return "SCHEDULED", completed_at
    if period_end and today > period_end:
        return "EXPIRED", completed_at
    return "ACTIVE", completed_at


def decorate_goal(goal: dict) -> dict:
    doc = dict(goal)
    doc.pop("_id", None)
    status = str(doc.get("status") or "ACTIVE").upper()
    doc["status"] = status
    doc["status_code"] = status
    doc["status_label"] = GOAL_STATUS_LABELS.get(status, status)
    doc["progress_percent"] = int(doc.get("progress_percent") or 0)
    doc["progress_pct"] = doc["progress_percent"]
    doc["current_value"] = int(doc.get("current_value") or 0)
    doc["target_value"] = int(doc.get("target_value") or 0)
    return doc


async def _compute_goal_progress(tenant_id: str, goal: dict) -> int:
    """FONTE ÚNICA DE VERDADE para cálculo de progresso de metas.

    Utiliza aggregation pipelines MongoDB para eficiência (sem fetch em memória).
    Cobre todos os tipos: REVENUE, CONVERSION, AVERAGE_TICKET, ATTENDANCES, SALES_COUNT, ITEMS_SOLD.
    Cobre todos os escopos: TENANT, STORE, TEAM, SELLER.
    Lida com: meta zero, progresso parcial, meta atingida, acima da meta, estorno,
               cancelamento, edição, exclusão, concorrência, períodos e timezone.
    
    Fontes de dados:
    - attendances (status=FINISHED, result=SALE): vendas feitas via fila (sale_amount_cents)
    - sales (attendance_id=None, status=COMPLETED): vendas proativas/standalone (net_amount_cents)
    - sales (status=COMPLETED): para ITEMS_SOLD (item_count) e AVERAGE_TICKET
    """
    gtype = goal["type"]
    scope = goal["scope"]
    period_start, period_end, _today = await _goal_period_bounds(tenant_id, goal)

    # Resolve seller_ids do time (escopo TEAM) — consulta única
    team_seller_ids: list | None = None
    if scope == "TEAM" and goal.get("team_id"):
        profiles = await db.seller_profiles.find(
            {"tenant_id": tenant_id, "team_id": goal["team_id"]}
        ).to_list(500)
        team_seller_ids = [s["id"] for s in profiles]

    def _att_base() -> dict:
        """Filtro base para attendances FINISHED no escopo/período da meta."""
        q: dict = {"tenant_id": tenant_id, "status": "FINISHED"}
        if scope == "STORE" and goal.get("store_id"):
            q["store_id"] = goal["store_id"]
        elif scope == "TEAM":
            q["seller_id"] = {"$in": team_seller_ids if team_seller_ids else ["__never__"]}
        elif scope == "SELLER" and goal.get("seller_id"):
            q["seller_id"] = goal["seller_id"]
        if period_start:
            q.setdefault("finished_at", {})["$gte"] = period_start
        if period_end:
            q.setdefault("finished_at", {})["$lte"] = period_end
        return q

    def _sales_base(standalone_only: bool = False) -> dict:
        """Filtro base para sales COMPLETED no escopo/período da meta.
        
        standalone_only=True: apenas vendas sem atendimento (proativas/diretas).
        standalone_only=False: todas as vendas COMPLETED (para ITEMS_SOLD).
        """
        q: dict = {"tenant_id": tenant_id, "status": "COMPLETED"}
        if standalone_only:
            q["attendance_id"] = None  # exclui vendas já contadas via attendance
        if scope == "STORE" and goal.get("store_id"):
            q["store_id"] = goal["store_id"]
        elif scope == "TEAM":
            q["seller_id"] = {"$in": team_seller_ids if team_seller_ids else ["__never__"]}
        elif scope == "SELLER" and goal.get("seller_id"):
            q["seller_id"] = goal["seller_id"]
        if period_start:
            q.setdefault("created_at", {})["$gte"] = period_start
        if period_end:
            q.setdefault("created_at", {})["$lte"] = period_end
        return q

    # ── ATTENDANCES: conta atendimentos finalizados válidos (exclui INVALID) ──
    if gtype == "ATTENDANCES":
        return await db.attendances.count_documents(
            {**_att_base(), "result": {"$ne": "INVALID"}}
        )

    # ── SALES_COUNT: atendimentos SALE + vendas standalone ────────────────────
    if gtype == "SALES_COUNT":
        att_count = await db.attendances.count_documents({**_att_base(), "result": "SALE"})
        standalone_count = await db.sales.count_documents(_sales_base(standalone_only=True))
        return att_count + standalone_count

    # ── REVENUE: sale_amount_cents (queue) + net_amount_cents (standalone) ────
    if gtype == "REVENUE":
        att_pipe = [
            {"$match": {**_att_base(), "result": "SALE"}},
            {"$group": {"_id": None, "total": {"$sum": {"$ifNull": ["$sale_amount_cents", 0]}}}},
        ]
        att_agg = await db.attendances.aggregate(att_pipe).to_list(1)
        att_rev = att_agg[0]["total"] if att_agg else 0

        sa_pipe = [
            {"$match": _sales_base(standalone_only=True)},
            {"$group": {"_id": None, "total": {"$sum": {"$ifNull": ["$net_amount_cents", 0]}}}},
        ]
        sa_agg = await db.sales.aggregate(sa_pipe).to_list(1)
        sa_rev = sa_agg[0]["total"] if sa_agg else 0

        return att_rev + sa_rev

    # ── ITEMS_SOLD: item_count de TODAS as vendas COMPLETED no período ────────
    if gtype == "ITEMS_SOLD":
        pipeline = [
            {"$match": _sales_base(standalone_only=False)},
            {"$group": {"_id": None, "total": {"$sum": {"$ifNull": ["$item_count", 0]}}}},
        ]
        agg = await db.sales.aggregate(pipeline).to_list(1)
        return agg[0]["total"] if agg else 0

    # ── AVERAGE_TICKET: média de sale_amount_cents em atendimentos SALE ──────
    if gtype == "AVERAGE_TICKET":
        pipeline = [
            {"$match": {**_att_base(), "result": "SALE"}},
            {"$group": {
                "_id": None,
                "total": {"$sum": {"$ifNull": ["$sale_amount_cents", 0]}},
                "count": {"$sum": 1},
            }},
        ]
        agg = await db.attendances.aggregate(pipeline).to_list(1)
        if not agg or agg[0]["count"] == 0:
            return 0
        return int(agg[0]["total"] / agg[0]["count"])

    # ── CONVERSION: basis points (7000 = 70%, 10000 = 100%) ─────────────────
    if gtype == "CONVERSION":
        pipeline = [
            {"$match": {**_att_base(), "result": {"$ne": "INVALID"}}},
            {"$group": {
                "_id": None,
                "sales": {"$sum": {"$cond": [{"$eq": ["$result", "SALE"]}, 1, 0]}},
                "total": {"$sum": 1},
            }},
        ]
        agg = await db.attendances.aggregate(pipeline).to_list(1)
        if not agg or agg[0]["total"] == 0:
            return 0
        return round(agg[0]["sales"] / agg[0]["total"] * 10000)

    return 0


# Mantém alias para compatibilidade com chamadas externas pontuais
_compute_current_value = _compute_goal_progress


def _compute_progress_pct(current: int, target: int) -> int:
    """Retorna o percentual REAL, sem limite máximo.
    
    A barra visual no frontend é limitada a 100%, mas o valor exibido pode ser > 100%.
    Ex: meta=100, realizado=120 → retorna 120 (frontend mostra barra cheia + texto '120%').
    Meta zero: retorna 0 (sem divisão por zero).
    """
    if target <= 0:
        return 0
    return round(current / target * 100)


async def create_goal(*, tenant_id: str, actor_user_id: str, data: dict, request=None) -> dict:
    gtype = data.get("type", "").upper()
    scope = data.get("scope", "").upper()
    period = data.get("period", "CUSTOM").upper()

    if gtype not in GOAL_TYPES:
        raise HTTPException(400, f"Tipo de meta inválido: {gtype}")
    if scope not in GOAL_SCOPES:
        raise HTTPException(400, f"Escopo inválido: {scope}")
    if period not in GOAL_PERIODS:
        raise HTTPException(400, f"Período inválido: {period}")

    target = data.get("target_value")
    if not isinstance(target, int) or isinstance(target, bool) or target <= 0:
        raise HTTPException(400, "target_value deve ser inteiro positivo.")

    period_start = data.get("period_start") or _today_str()
    period_end = data.get("period_end") or _today_str()

    now = _now_iso()
    goal_id = new_id()
    doc = {
        "id": goal_id,
        "tenant_id": tenant_id,
        "store_id": data.get("store_id"),
        "team_id": data.get("team_id"),
        "seller_id": data.get("seller_id"),
        "created_by": actor_user_id,
        "title": str(data.get("title", "")).strip(),
        "description": data.get("description"),
        "type": gtype,
        "scope": scope,
        "period": period,
        "target_value": target,
        "current_value": 0,
        "progress_percent": 0,
        "status": "ACTIVE",
        "period_start": period_start,
        "period_end": period_end,
        "created_at": now,
        "updated_at": now,
        "completed_at": None,
        "cancelled_at": None,
    }

    if not doc["title"]:
        raise HTTPException(400, "O título da meta é obrigatório.")

    await db.goals.insert_one(doc)
    doc.pop("_id", None)

    # Calcular progresso inicial
    await _refresh_goal(tenant_id, doc)

    await log_audit(
        action="GOAL_CREATED", entity="goal", entity_id=goal_id,
        tenant_id=tenant_id, user_id=actor_user_id,
        new_value={"title": doc["title"], "type": gtype, "scope": scope, "target": target},
        request=request,
    )

    # ── Notificar vendedor quando meta é criada para ele ──────────────────────
    if scope == "SELLER" and doc.get("seller_id"):
        try:
            sp = await db.seller_profiles.find_one({"tenant_id": tenant_id, "id": doc["seller_id"]})
            if sp and sp.get("user_id"):
                from notification_service import create_notification
                # Montar corpo da notificação com detalhes da meta
                title_str = doc.get("title") or ""
                body_parts = [f'Uma nova meta foi cadastrada para você: "{title_str}".']
                if gtype == "REVENUE" and target:
                    brl_target = target / 100
                    body_parts.append(
                        f"Receita alvo: R$ {brl_target:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
                    )
                elif target:
                    body_parts.append(f"Valor alvo: {target}.")
                if doc.get("period_end"):
                    body_parts.append(f"Prazo: até {doc['period_end']}.")
                await create_notification(
                    tenant_id=tenant_id,
                    user_id=sp["user_id"],
                    ntype="GOAL_CREATED",
                    title="Nova meta cadastrada para você",
                    body=" ".join(body_parts),
                    entity_type="goal",
                    entity_id=goal_id,
                )
        except Exception:
            pass  # Notificação não crítica — não bloqueia a criação da meta

    return await get_goal(tenant_id, goal_id)


async def _refresh_goal(tenant_id: str, goal: dict) -> dict:
    """Recalcula current_value, progress_percent e status de uma meta. Atualiza no DB.
    
    Após atualizar, emite evento WebSocket 'goals.updated' para todos os painéis
    relevantes atualizarem em tempo real sem necessidade de refresh manual.
    """
    current = await _compute_goal_progress(tenant_id, goal)
    target = goal["target_value"]
    pct = _compute_progress_pct(current, target)  # valor real, sem cap
    now = _now_iso()
    _start, _end, today = await _goal_period_bounds(tenant_id, goal)

    status, completed_at = _derive_goal_status(goal, current, target, today)

    upd = {
        "current_value": current,
        "progress_percent": pct,
        "status": status,
        "updated_at": now,
    }
    if completed_at and not goal.get("completed_at"):
        upd["completed_at"] = completed_at

    completed_matches = (goal.get("completed_at") or None) == (upd.get("completed_at") or goal.get("completed_at") or None)
    unchanged = (
        int(goal.get("current_value") or 0) == current
        and int(goal.get("progress_percent") or 0) == pct
        and str(goal.get("status") or "ACTIVE").upper() == status
        and completed_matches
    )
    if unchanged:
        return decorate_goal({**goal, **{k: v for k, v in upd.items() if k != "updated_at"}})

    await db.goals.update_one({"tenant_id": tenant_id, "id": goal["id"]}, {"$set": upd})

    # ── Notificar vendedor quando meta SELLER é concluída ────────────────────
    if status == "COMPLETED" and goal.get("status") != "COMPLETED" and goal.get("scope") == "SELLER" and goal.get("seller_id"):
        try:
            sp = await db.seller_profiles.find_one({"tenant_id": tenant_id, "id": goal["seller_id"]})
            if sp and sp.get("user_id"):
                from notification_service import create_notification
                await create_notification(
                    tenant_id=tenant_id,
                    user_id=sp["user_id"],
                    ntype="GOAL_COMPLETED",
                    title="Meta atingida!",
                    body=f'Parabéns! Você atingiu a meta "{goal.get("title", "")}".',
                    entity_type="goal",
                    entity_id=goal["id"],
                )
                try:
                    from realtime import event_bus
                    await event_bus.broadcast_to_user(tenant_id, sp["user_id"], {
                        "event_type": "GOAL_ACHIEVED",
                        "tenant_id": tenant_id,
                        "timestamp": utcnow_iso(),
                        "payload": {
                            "seller_id": goal["seller_id"],
                            "seller_name": sp.get("name", "Vendedor"),
                            "sales_count": current,
                            "goal_target": target,
                            "goal_name": goal.get("title", "Meta diária"),
                            "goal_type": goal.get("type", "SALES_COUNT"),
                        }
                    })
                except Exception:
                    pass
        except Exception:
            pass

    # ── Emitir goals.updated para todos os painéis atualizarem em tempo real ─
    try:
        await _broadcast_goal_update(tenant_id, {**goal, **upd})
    except Exception:
        pass

    return decorate_goal({**goal, **upd})


async def get_goal(tenant_id: str, goal_id: str) -> dict:
    doc = await db.goals.find_one({"tenant_id": tenant_id, "id": goal_id})
    if not doc:
        raise HTTPException(404, "Meta não encontrada.")
    doc.pop("_id", None)
    if str(doc.get("status") or "ACTIVE").upper() in GOAL_REFRESHABLE_STATUSES:
        doc = await _refresh_goal(tenant_id, doc)
    return decorate_goal(doc)


async def list_goals(tenant_id: str, filters: dict) -> list:
    q: dict = {"tenant_id": tenant_id}
    for key in ("status", "type", "scope", "store_id", "team_id", "seller_id"):
        if filters.get(key):
            q[key] = filters[key]
    if filters.get("period_start"):
        q.setdefault("period_end", {})["$gte"] = filters["period_start"]
    if filters.get("period_end"):
        q.setdefault("period_start", {})["$lte"] = filters["period_end"]

    raw = await db.goals.find(q).sort("created_at", -1).limit(200).to_list(200)
    return await refresh_and_decorate_goals(tenant_id, raw)


async def refresh_and_decorate_goals(tenant_id: str, goals: list[dict]) -> list[dict]:
    out = []
    for doc in goals:
        doc.pop("_id", None)
        if str(doc.get("status") or "ACTIVE").upper() in GOAL_REFRESHABLE_STATUSES:
            try:
                doc = await _refresh_goal(tenant_id, doc)
            except Exception:
                doc = decorate_goal(doc)
        else:
            doc = decorate_goal(doc)
        out.append(doc)
    return out


def goal_applies_to_seller(goal: dict, profile: Optional[dict]) -> bool:
    if not profile:
        return False
    scope = goal.get("scope")
    if scope == "SELLER":
        return goal.get("seller_id") == profile.get("id")
    if scope == "STORE":
        return bool(profile.get("store_id") and goal.get("store_id") == profile.get("store_id"))
    if scope == "TEAM":
        return bool(profile.get("team_id") and goal.get("team_id") == profile.get("team_id"))
    return False


async def list_applicable_goals_for_seller(
    tenant_id: str,
    profile: Optional[dict],
    filters: Optional[dict] = None,
    limit: int = 200,
) -> list[dict]:
    filters = filters or {}
    sid = profile.get("id") if profile else "__none__"
    seller_store_id = profile.get("store_id") if profile else None
    seller_team_id = profile.get("team_id") if profile else None
    or_clauses: list = [{"seller_id": sid, "scope": "SELLER"}]
    if seller_store_id:
        or_clauses.append({"store_id": seller_store_id, "scope": "STORE"})
    if seller_team_id:
        or_clauses.append({"team_id": seller_team_id, "scope": "TEAM"})
    q: dict = {"tenant_id": tenant_id, "$or": or_clauses}
    for k, v in filters.items():
        if k not in ("seller_id", "store_id", "team_id") and v is not None:
            q[k] = v
    raw = await db.goals.find(q).sort("created_at", -1).limit(limit).to_list(limit)
    return await refresh_and_decorate_goals(tenant_id, raw)


async def update_goal(*, tenant_id: str, goal_id: str, actor_user_id: str, data: dict, request=None) -> dict:
    goal = await get_goal(tenant_id, goal_id)
    if goal["status"] not in ("ACTIVE", "SCHEDULED", "PAUSED", "EXPIRED"):
        raise HTTPException(400, f"Meta em status '{goal['status']}' não pode ser editada.")

    allowed = {"title", "description", "target_value", "period_end"}
    update: dict = {}
    for k in allowed:
        if k in data and data[k] is not None:
            update[k] = data[k]

    if "target_value" in update:
        tv = update["target_value"]
        if not isinstance(tv, int) or isinstance(tv, bool) or tv <= 0:
            raise HTTPException(400, "target_value deve ser inteiro positivo.")

    if not update:
        return goal

    update["updated_at"] = _now_iso()
    await db.goals.update_one({"tenant_id": tenant_id, "id": goal_id}, {"$set": update})
    await log_audit(
        action="GOAL_UPDATED", entity="goal", entity_id=goal_id,
        tenant_id=tenant_id, user_id=actor_user_id,
        old_value={k: goal.get(k) for k in update}, new_value=update,
        request=request,
    )
    # Recalcula progresso se target_value ou period_end mudou (afeta % diretamente)
    updated_goal = await get_goal(tenant_id, goal_id)
    if "target_value" in update or "period_end" in update:
        try:
            await _refresh_goal(tenant_id, updated_goal)
        except Exception:
            pass
        return await get_goal(tenant_id, goal_id)
    return updated_goal


async def cancel_goal(*, tenant_id: str, goal_id: str, actor_user_id: str, reason: Optional[str] = None, request=None) -> dict:
    goal = await get_goal(tenant_id, goal_id)
    if goal["status"] not in ("ACTIVE", "SCHEDULED", "PAUSED", "EXPIRED"):
        raise HTTPException(400, f"Meta em status '{goal['status']}' não pode ser cancelada.")

    now = _now_iso()
    await db.goals.update_one(
        {"tenant_id": tenant_id, "id": goal_id},
        {"$set": {"status": "CANCELLED", "cancelled_at": now, "updated_at": now}},
    )
    await log_audit(
        action="GOAL_CANCELLED", entity="goal", entity_id=goal_id,
        tenant_id=tenant_id, user_id=actor_user_id,
        new_value={"reason": reason},
        request=request,
    )
    try:
        await _broadcast_goal_update(tenant_id, await get_goal(tenant_id, goal_id))
    except Exception:
        pass
    return await get_goal(tenant_id, goal_id)


async def recalculate_goal(*, tenant_id: str, goal_id: str, actor_user_id: str, request=None) -> dict:
    goal = await get_goal(tenant_id, goal_id)
    if goal["status"] not in ("ACTIVE", "EXPIRED", "SCHEDULED", "PAUSED"):
        raise HTTPException(400, "Apenas metas abertas podem ser recalculadas.")

    updated = await _refresh_goal(tenant_id, goal)
    await log_audit(
        action="GOAL_RECALCULATED", entity="goal", entity_id=goal_id,
        tenant_id=tenant_id, user_id=actor_user_id,
        new_value={"current_value": updated["current_value"], "progress_percent": updated["progress_percent"]},
        request=request,
    )
    return await get_goal(tenant_id, goal_id)


async def recalculate_active_goals(tenant_id: str, store_id: Optional[str] = None, seller_id: Optional[str] = None) -> None:
    """Chamado após attendance.finished ou sale.created. Atualiza metas ACTIVE.
    
    Silencioso: erros não bloqueiam o fluxo principal.
    """
    try:
        q: dict = {"tenant_id": tenant_id, "status": {"$in": list(GOAL_REFRESHABLE_STATUSES)}}
        _or_clauses = [{"scope": "TENANT"}]
        if store_id:
            _or_clauses.append({"scope": "STORE", "store_id": store_id})
        if seller_id:
            _or_clauses.append({"scope": "SELLER", "seller_id": seller_id})
            sp = await db.seller_profiles.find_one(
                {"tenant_id": tenant_id, "id": seller_id},
                {"_id": 0, "team_id": 1, "store_id": 1},
            )
            team_id = (sp or {}).get("team_id")
            if team_id:
                _or_clauses.append({"scope": "TEAM", "team_id": team_id})
            if not store_id and (sp or {}).get("store_id"):
                _or_clauses.append({"scope": "STORE", "store_id": sp["store_id"]})
        q["$or"] = _or_clauses

        active_goals = await db.goals.find(q).to_list(100)
        for goal in active_goals:
            goal.pop("_id", None)
            try:
                await _refresh_goal(tenant_id, goal)
            except Exception:
                pass
    except Exception:
        pass


async def _broadcast_goal_update(tenant_id: str, goal: dict) -> None:
    from realtime import event_bus
    status = str(goal.get("status") or "ACTIVE").upper()
    ws_payload = {
        "event_type": "goals.updated",
        "tenant_id": tenant_id,
        "timestamp": utcnow_iso(),
        "payload": {
            "goal_id": goal["id"],
            "current_value": int(goal.get("current_value") or 0),
            "progress_percent": int(goal.get("progress_percent") or 0),
            "progress_pct": int(goal.get("progress_percent") or 0),
            "status": status,
            "status_label": GOAL_STATUS_LABELS.get(status, status),
        },
    }
    store_id = goal.get("store_id")
    if store_id:
        await event_bus.broadcast_to_store(tenant_id, store_id, ws_payload)
    else:
        await event_bus.broadcast_to_tenant(tenant_id, ws_payload)
