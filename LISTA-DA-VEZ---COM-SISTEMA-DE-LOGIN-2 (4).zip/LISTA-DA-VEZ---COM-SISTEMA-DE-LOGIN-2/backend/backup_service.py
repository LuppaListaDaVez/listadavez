"""BackupService — Backup tenant-scoped (Etapa 14). Snapshots armazenados no MongoDB."""
import json
import hashlib
from db import db
from models import new_id, utcnow_iso
from audit import log_audit
from data_access_log_service import log_data_access
from datetime import datetime, timezone, timedelta

BACKUP_EXPIRES_DAYS = 30
BACKUP_COLLECTIONS = [
    "stores", "users", "tenant_memberships", "teams", "seller_profiles",
    "loss_reasons", "store_settings", "goals", "feedbacks",
    "automation_rules", "alert_rules", "notification_preferences",
    "privacy_settings", "data_retention_policies", "consents",
]


async def create_backup(tenant_id: str, backup_type: str, created_by: str,
                        request=None) -> dict:
    """Cria snapshot tenant-scoped. Inclui apenas dados daquele tenant."""
    now = utcnow_iso()
    expires_at = (datetime.now(timezone.utc) + timedelta(days=BACKUP_EXPIRES_DAYS)).isoformat()
    
    job = {
        "id": new_id(), "tenant_id": tenant_id, "backup_type": backup_type,
        "status": "RUNNING", "started_at": now, "finished_at": None,
        "created_by": created_by, "records_included": 0,
        "collections_included": [], "error_code": None, "error_message": None,
        "snapshot_id": None, "created_at": now,
    }
    await db.backup_jobs.insert_one(job)
    job_id = job["id"]
    
    snapshot = {
        "id": new_id(), "tenant_id": tenant_id, "backup_type": backup_type,
        "status": "RUNNING", "scope": "TENANT",
        "storage_provider": "mongodb_internal",
        "file_path": None, "checksum": None, "size_bytes": 0,
        "created_by": created_by, "created_at": now, "expires_at": expires_at,
        "completed_at": None, "error_code": None, "error_message": None,
        "metadata": {"collections": []},
    }
    await db.backup_snapshots.insert_one(snapshot)
    snap_id = snapshot["id"]
    
    try:
        snapshot_data = {"tenant_id": tenant_id, "backup_type": backup_type, "created_at": now, "collections": {}}
        total_records = 0
        collections_done = []
        
        for coll_name in BACKUP_COLLECTIONS:
            coll = getattr(db, coll_name)
            docs = await coll.find({"tenant_id": tenant_id}, {"_id": 0}).to_list(length=5000)
            # Remover campos sensíveis
            clean_docs = []
            for d in docs:
                d.pop("password_hash", None)
                clean_docs.append(d)
            snapshot_data["collections"][coll_name] = clean_docs
            total_records += len(clean_docs)
            collections_done.append(coll_name)
        
        # Tenant config (sem secrets)
        tenant_doc = await db.tenants.find_one({"id": tenant_id}, {"_id": 0})
        if tenant_doc:
            snapshot_data["tenant_config"] = tenant_doc
        
        content_str = json.dumps(snapshot_data, ensure_ascii=False, default=str)
        checksum = hashlib.sha256(content_str.encode()).hexdigest()
        size_bytes = len(content_str.encode())
        file_path = f"backups/{tenant_id}/{snap_id}.json"
        
        await db.backup_snapshots.update_one({"id": snap_id}, {"$set": {
            "status": "COMPLETED", "file_path": file_path,
            "checksum": checksum, "size_bytes": size_bytes,
            "completed_at": utcnow_iso(),
            "metadata": {"collections": collections_done, "total_records": total_records},
            "_content": content_str,
        }})
        await db.backup_jobs.update_one({"id": job_id}, {"$set": {
            "status": "COMPLETED", "finished_at": utcnow_iso(), "snapshot_id": snap_id,
            "records_included": total_records, "collections_included": collections_done,
        }})
        await log_audit(action="BACKUP_CREATED", entity="backup_snapshot", entity_id=snap_id,
                        tenant_id=tenant_id, user_id=created_by, request=request)
        await log_data_access(tenant_id=tenant_id, actor_user_id=created_by,
                              access_type="BACKUP", entity="tenant", entity_id=tenant_id,
                              data_category="BACKUP", request=request)
        snapshot.update({"status": "COMPLETED", "checksum": checksum,
                         "size_bytes": size_bytes, "snapshot_id": snap_id})
        job.update({"status": "COMPLETED", "snapshot_id": snap_id, "records_included": total_records})
    except Exception as e:
        err = str(e)[:200]
        await db.backup_snapshots.update_one({"id": snap_id}, {"$set": {
            "status": "FAILED", "error_message": err, "completed_at": utcnow_iso()
        }})
        await db.backup_jobs.update_one({"id": job_id}, {"$set": {
            "status": "FAILED", "error_message": err, "finished_at": utcnow_iso()
        }})
        raise
    
    snapshot.pop("_id", None)
    snapshot.pop("_content", None)
    return {"snapshot": snapshot, "job": {k: v for k, v in job.items() if k != "_id"}}


async def list_snapshots(tenant_id: str, limit: int = 20) -> list:
    cursor = db.backup_snapshots.find(
        {"tenant_id": tenant_id}, {"_id": 0, "_content": 0}
    ).sort("created_at", -1).limit(limit)
    return await cursor.to_list(length=limit)


async def get_snapshot(tenant_id: str, snapshot_id: str) -> dict | None:
    doc = await db.backup_snapshots.find_one({"id": snapshot_id, "tenant_id": tenant_id})
    if not doc:
        return None
    doc.pop("_id", None)
    doc.pop("_content", None)
    return doc


async def download_snapshot(tenant_id: str, snapshot_id: str, actor_id: str,
                             request=None) -> dict | None:
    """Retorna conteúdo para download autenticado. Valida expiração."""
    from datetime import datetime, timezone
    doc = await db.backup_snapshots.find_one({"id": snapshot_id, "tenant_id": tenant_id})
    if not doc or doc.get("status") != "COMPLETED":
        return None
    if doc.get("expires_at") and doc["expires_at"] < datetime.now(timezone.utc).isoformat():
        return None
    await log_audit(action="BACKUP_DOWNLOADED", entity="backup_snapshot", entity_id=snapshot_id,
                    tenant_id=tenant_id, user_id=actor_id, request=request)
    await log_data_access(tenant_id=tenant_id, actor_user_id=actor_id, access_type="DOWNLOAD",
                          entity="backup_snapshot", entity_id=snapshot_id,
                          data_category="BACKUP", request=request)
    content = doc.get("_content", "{}")
    doc.pop("_id", None)
    doc.pop("_content", None)
    return {"metadata": doc, "content": content}


async def delete_snapshot(tenant_id: str, snapshot_id: str, actor_id: str, request=None) -> bool:
    result = await db.backup_snapshots.update_one(
        {"id": snapshot_id, "tenant_id": tenant_id},
        {"$set": {"status": "DELETED", "_content": None}}
    )
    if result.modified_count:
        await log_audit(action="BACKUP_DELETED", entity="backup_snapshot", entity_id=snapshot_id,
                        tenant_id=tenant_id, user_id=actor_id, request=request)
        return True
    return False


async def list_jobs(tenant_id: str, limit: int = 20) -> list:
    cursor = db.backup_jobs.find({"tenant_id": tenant_id}, {"_id": 0}).sort("created_at", -1).limit(limit)
    return await cursor.to_list(length=limit)
