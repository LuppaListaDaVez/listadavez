"""DataAccessLogService — Registro de acesso a dados pessoais (Etapa 14)."""
from typing import Optional
from db import db
from models import new_id, utcnow_iso
from fastapi import Request


async def log_data_access(
    *,
    tenant_id: str,
    actor_user_id: str,
    actor_role: str = None,
    access_type: str,
    entity: str,
    entity_id: Optional[str] = None,
    data_category: str = "USER_ACCOUNT",
    reason: Optional[str] = None,
    request: Optional[Request] = None,
):
    ip = None
    ua = None
    req_id = None
    if request:
        ip = request.client.host if request.client else None
        ua = request.headers.get("user-agent")
        req_id = getattr(request.state, "request_id", None)
    
    await db.data_access_logs.insert_one({
        "id": new_id(),
        "tenant_id": tenant_id,
        "actor_user_id": actor_user_id,
        "actor_role": actor_role,
        "access_type": access_type,
        "entity": entity,
        "entity_id": entity_id,
        "data_category": data_category,
        "reason": reason,
        "ip": ip,
        "user_agent": ua,
        "request_id": req_id,
        "created_at": utcnow_iso(),
    })


async def list_logs(tenant_id: str, actor_user_id: Optional[str] = None,
                    data_category: Optional[str] = None, limit: int = 100) -> list:
    filt = {"tenant_id": tenant_id}
    if actor_user_id:
        filt["actor_user_id"] = actor_user_id
    if data_category:
        filt["data_category"] = data_category
    cursor = db.data_access_logs.find(filt, {"_id": 0}).sort("created_at", -1).limit(limit)
    return await cursor.to_list(length=limit)
