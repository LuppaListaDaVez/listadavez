"""Serviço da hierarquia livre de motivos de perda."""
import re
from typing import Optional

from fastapi import HTTPException

from db import db


def normalizar_nome(nome: str) -> str:
    return re.sub(r"\s+", " ", (nome or "").strip()).casefold()


def limpar_texto(valor: Optional[str]) -> Optional[str]:
    if valor is None:
        return None
    texto = re.sub(r"\s+", " ", str(valor).strip())
    return texto or None


async def hierarquia_ativa_existe(empresa_id: str) -> bool:
    grupos = await db.grupos_motivos_perda.find(
        {"empresa_id": empresa_id, "ativo": True}, {"_id": 0, "identificador": 1}
    ).to_list(1000)
    if not grupos:
        return False
    grupo_ids = [g["identificador"] for g in grupos]
    subgrupos = await db.subgrupos_motivos_perda.find(
        {"empresa_id": empresa_id, "grupo_motivo_perda_id": {"$in": grupo_ids}, "ativo": True},
        {"_id": 0, "identificador": 1},
    ).to_list(1000)
    if not subgrupos:
        return False
    subgrupo_ids = [s["identificador"] for s in subgrupos]
    motivo = await db.motivos_perda.find_one(
        {"empresa_id": empresa_id, "subgrupo_motivo_perda_id": {"$in": subgrupo_ids}, "ativo": True},
        {"_id": 0, "identificador": 1},
    )
    return bool(motivo)


async def validar_combinação_para_atendimento(
    *,
    empresa_id: str,
    grupo_motivo_perda_id: Optional[str],
    subgrupo_motivo_perda_id: Optional[str],
    motivo_perda_id: Optional[str],
    descricao_complementar: Optional[str],
) -> dict:
    if not grupo_motivo_perda_id or not subgrupo_motivo_perda_id or not motivo_perda_id:
        raise HTTPException(status_code=400, detail={
            "error": "CLASSIFICACAO_DE_PERDA_OBRIGATORIA",
            "message": "Selecione Grupo, Subgrupo e Motivo para concluir como Não sucesso.",
        })

    grupo = await db.grupos_motivos_perda.find_one({
        "empresa_id": empresa_id,
        "identificador": grupo_motivo_perda_id,
        "ativo": True,
    }, {"_id": 0})
    if not grupo:
        raise HTTPException(status_code=400, detail={
            "error": "GRUPO_MOTIVO_PERDA_INVALIDO",
            "message": "Grupo de motivo de perda inválido ou inativo.",
        })

    subgrupo = await db.subgrupos_motivos_perda.find_one({
        "empresa_id": empresa_id,
        "identificador": subgrupo_motivo_perda_id,
        "grupo_motivo_perda_id": grupo_motivo_perda_id,
        "ativo": True,
    }, {"_id": 0})
    if not subgrupo:
        raise HTTPException(status_code=400, detail={
            "error": "SUBGRUPO_MOTIVO_PERDA_INVALIDO",
            "message": "Subgrupo inválido, inativo ou incompatível com o Grupo selecionado.",
        })

    motivo = await db.motivos_perda.find_one({
        "empresa_id": empresa_id,
        "identificador": motivo_perda_id,
        "subgrupo_motivo_perda_id": subgrupo_motivo_perda_id,
        "ativo": True,
    }, {"_id": 0})
    if not motivo:
        raise HTTPException(status_code=400, detail={
            "error": "MOTIVO_PERDA_INVALIDO",
            "message": "Motivo inválido, inativo ou incompatível com o Subgrupo selecionado.",
        })

    limite = int(motivo.get("limite_descricao_complementar") or 300)
    descricao = limpar_texto(descricao_complementar)
    if motivo.get("exige_descricao_complementar"):
        if not descricao:
            raise HTTPException(status_code=400, detail={
                "error": "DESCRICAO_COMPLEMENTAR_OBRIGATORIA",
                "message": "Informe a descrição complementar para este motivo.",
            })
        if len(descricao) > limite:
            raise HTTPException(status_code=400, detail={
                "error": "DESCRICAO_COMPLEMENTAR_LONGA",
                "message": f"A descrição complementar deve ter no máximo {limite} caracteres.",
            })
    elif descricao and len(descricao) > limite:
        raise HTTPException(status_code=400, detail={
            "error": "DESCRICAO_COMPLEMENTAR_LONGA",
            "message": f"A descrição complementar deve ter no máximo {limite} caracteres.",
        })

    return {
        "grupo": grupo,
        "subgrupo": subgrupo,
        "motivo": motivo,
        "descricao_complementar": descricao,
    }