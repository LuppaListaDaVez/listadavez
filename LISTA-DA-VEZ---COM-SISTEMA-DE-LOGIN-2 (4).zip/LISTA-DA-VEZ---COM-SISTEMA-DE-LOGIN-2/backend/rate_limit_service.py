"""Rate limiting com sliding window — Redis-backed com fallback in-memory.

Modo Redis (produção multi-instância):
  Usa Sorted Sets do Redis: ZADD + ZREMRANGEBYSCORE + ZCARD numa pipeline atômica.
  Chave: rl:{group}:{key}  TTL automático = window_seconds + 10s de margem.

Modo in-memory (fallback):
  Usado quando Redis está indisponível. Funciona apenas em instância única.

Variáveis de ambiente:
  REDIS_URL=redis://localhost:6379/0  (se ausente → in-memory)
  TRUST_PROXY_HEADERS=false           (padrão: ignora X-Forwarded-For/X-Real-IP)
    false → usa sempre request.client.host (seguro contra falsificação de IP)
    true  → usa X-Forwarded-For/X-Real-IP (para deploys atrás de proxy confiável)
"""
import asyncio
import logging
import os
import time
from collections import defaultdict
from typing import Dict, List, Optional, Tuple

from fastapi import Depends, HTTPException, Request

logger = logging.getLogger("lista-da-vez.rate_limit")

# Configurações: (max_requests, window_seconds)
RATE_LIMITS: Dict[str, Tuple[int, int]] = {
    "AUTH_LOGIN": (50, 900),           # 50 tentativas / 15 min
    "AUTH_REFRESH": (20, 300),         # 20 / 5 min
    "SUPER_ADMIN_LOGIN": (10, 1800),   # 10 / 30 min
    "QUEUE_ACTIONS": (120, 60),        # 120 / min
    "SALES_CREATE": (60, 60),          # 60 / min
    "ATTENDANCE_START": (60, 60),      # 60 / min
    "ATTENDANCE_FINISH": (60, 60),     # 60 / min
    "ATTENDANCE_CANCEL": (30, 60),     # 30 / min
    "REPORT_EXPORT": (10, 3600),       # 10 / hora
    "NOTIFICATIONS": (120, 60),        # 120 / min
    "GENERAL_API": (600, 60),          # 600 / min
    "INVITE_SEND": (20, 3600),         # 20 convites/hora por IP (Prompt 2)
    "ACCOUNT_LOCKOUT": (5, 900),       # 5 logins falhados / 15 min por e-mail
}


# ── In-memory fallback ────────────────────────────────────────────────────────

class InMemoryRateLimiter:
    """Sliding window in-memory. Funciona apenas em instância única."""

    def __init__(self):
        self._windows: Dict[str, List[float]] = defaultdict(list)
        self._lock = asyncio.Lock()

    async def check(self, key: str, group: str) -> Tuple[bool, Optional[int]]:
        if group not in RATE_LIMITS:
            return True, None
        max_requests, window_seconds = RATE_LIMITS[group]
        now = time.time()
        window_key = f"{group}:{key}"
        async with self._lock:
            self._windows[window_key] = [
                ts for ts in self._windows[window_key]
                if now - ts < window_seconds
            ]
            count = len(self._windows[window_key])
            if count >= max_requests:
                oldest = min(self._windows[window_key]) if self._windows[window_key] else now
                retry_after = int(window_seconds - (now - oldest)) + 1
                return False, max(1, retry_after)
            self._windows[window_key].append(now)
            return True, None

    async def peek(self, key: str, group: str) -> Tuple[bool, Optional[int]]:
        """Verifica o contador sem incrementá-lo."""
        if group not in RATE_LIMITS:
            return True, None
        max_requests, window_seconds = RATE_LIMITS[group]
        now = time.time()
        window_key = f"{group}:{key}"
        async with self._lock:
            self._windows[window_key] = [
                ts for ts in self._windows[window_key]
                if now - ts < window_seconds
            ]
            count = len(self._windows[window_key])
            if count >= max_requests:
                oldest = min(self._windows[window_key]) if self._windows[window_key] else now
                retry_after = int(window_seconds - (now - oldest)) + 1
                return False, max(1, retry_after)
            return True, None

    async def reset(self, key: str, group: str) -> None:
        """Remove todas as entradas do contador para a chave."""
        window_key = f"{group}:{key}"
        async with self._lock:
            self._windows.pop(window_key, None)


# ── Redis-backed sliding window ───────────────────────────────────────────────

class RedisRateLimiter:
    """Sliding window via Redis Sorted Sets — seguro para multi-instância.

    Algoritmo por request:
      1. ZADD rl:{group}:{key} <now_ms> <now_ms>   (adiciona timestamp atual)
      2. ZREMRANGEBYSCORE ... 0 <oldest_ms>          (remove timestamps expirados)
      3. ZCARD ...                                   (conta requests na janela)
      4. EXPIRE ... window_seconds + 10              (TTL de limpeza automática)
    Tudo numa pipeline para atomicidade.
    """

    def __init__(self, redis_url: str):
        self._redis_url = redis_url
        self._redis = None
        self._fallback = InMemoryRateLimiter()
        self._fallback_active = False

    async def _get_redis(self):
        if self._redis is None:
            import redis.asyncio as aioredis
            self._redis = aioredis.from_url(
                self._redis_url,
                decode_responses=True,
                socket_connect_timeout=2,
                socket_timeout=2,
            )
        return self._redis

    async def check(self, key: str, group: str) -> Tuple[bool, Optional[int]]:
        if group not in RATE_LIMITS:
            return True, None

        max_requests, window_seconds = RATE_LIMITS[group]

        try:
            r = await self._get_redis()
            now_ms = int(time.time() * 1000)
            oldest_ms = now_ms - window_seconds * 1000
            rkey = f"rl:{group}:{key}"

            async with r.pipeline(transaction=True) as pipe:
                pipe.zadd(rkey, {str(now_ms): now_ms})
                pipe.zremrangebyscore(rkey, 0, oldest_ms)
                pipe.zcard(rkey)
                pipe.expire(rkey, window_seconds + 10)
                results = await pipe.execute()

            count = results[2]  # zcard result

            if self._fallback_active:
                logger.info("RATE_LIMIT_REDIS_RECOVERED")
                self._fallback_active = False

            if count > max_requests:
                # Calcular retry_after: tempo até o request mais antigo expirar
                oldest_scores = await r.zrange(rkey, 0, 0, withscores=True)
                if oldest_scores:
                    oldest_ts_ms = oldest_scores[0][1]
                    retry_after = int((oldest_ts_ms + window_seconds * 1000 - now_ms) / 1000) + 1
                else:
                    retry_after = window_seconds
                return False, max(1, retry_after)

            return True, None

        except Exception as e:
            if not self._fallback_active:
                logger.warning("RATE_LIMIT_REDIS_UNAVAILABLE: %s — usando fallback in-memory", e)
                self._fallback_active = True
            return await self._fallback.check(key, group)

    async def peek(self, key: str, group: str) -> Tuple[bool, Optional[int]]:
        """Verifica o contador sem incrementá-lo."""
        if group not in RATE_LIMITS:
            return True, None
        max_requests, window_seconds = RATE_LIMITS[group]
        try:
            r = await self._get_redis()
            now_ms = int(time.time() * 1000)
            oldest_ms = now_ms - window_seconds * 1000
            rkey = f"rl:{group}:{key}"

            async with r.pipeline(transaction=True) as pipe:
                pipe.zremrangebyscore(rkey, 0, oldest_ms)
                pipe.zcard(rkey)
                results = await pipe.execute()

            count = results[1]
            if count >= max_requests:
                oldest_scores = await r.zrange(rkey, 0, 0, withscores=True)
                if oldest_scores:
                    oldest_ts_ms = oldest_scores[0][1]
                    retry_after = int((oldest_ts_ms + window_seconds * 1000 - now_ms) / 1000) + 1
                else:
                    retry_after = window_seconds
                return False, max(1, retry_after)
            return True, None
        except Exception as e:
            if not self._fallback_active:
                logger.warning("RATE_LIMIT_REDIS_UNAVAILABLE: %s — peek fallback in-memory", e)
            return await self._fallback.peek(key, group)

    async def reset(self, key: str, group: str) -> None:
        """Remove todas as entradas do contador para a chave."""
        rkey = f"rl:{group}:{key}"
        try:
            r = await self._get_redis()
            await r.delete(rkey)
        except Exception:
            await self._fallback.reset(key, group)


# ── Singleton ─────────────────────────────────────────────────────────────────

def _create_rate_limiter():
    redis_url = os.environ.get("REDIS_URL", "").strip("\"'")
    if redis_url:
        logger.info("RATE_LIMIT_MODE=redis url=%s", redis_url[:30])
        return RedisRateLimiter(redis_url)
    logger.info("RATE_LIMIT_MODE=in_memory (REDIS_URL ausente)")
    return InMemoryRateLimiter()


rate_limiter = _create_rate_limiter()

# Lido uma vez no boot para evitar re-leitura por request.
_TRUST_PROXY_HEADERS: bool = (
    os.environ.get("TRUST_PROXY_HEADERS", "false").strip().lower() == "true"
)


# ── Lockout por conta (e-mail) ────────────────────────────────────────────────

async def check_email_lockout(email: str, context: str = "") -> Tuple[bool, Optional[int]]:
    """Verifica se o e-mail está bloqueado por tentativas excessivas.

    Consulta o contador sem incrementá-lo — deve ser chamado antes de verificar
    as credenciais. Retorna (allowed, retry_after_seconds).
    """
    key = f"{email}:{context}" if context else email
    return await rate_limiter.peek(key, "ACCOUNT_LOCKOUT")


async def record_failed_login(email: str, context: str = "") -> None:
    """Registra uma tentativa de login falhada para o e-mail.

    Deve ser chamado somente após falha de credenciais confirmada.
    Quando o contador atingir o limite, `check_email_lockout` bloqueará
    as próximas requisições.
    """
    key = f"{email}:{context}" if context else email
    await rate_limiter.check(key, "ACCOUNT_LOCKOUT")


async def reset_email_lockout(email: str, context: str = "") -> None:
    """Remove o contador de falhas do e-mail.

    Deve ser chamado imediatamente após um login bem-sucedido.
    """
    key = f"{email}:{context}" if context else email
    await rate_limiter.reset(key, "ACCOUNT_LOCKOUT")


# ── Helpers públicos ──────────────────────────────────────────────────────────

def get_client_ip(request: Request) -> str:
    """Extrai o IP real do cliente para uso no rate limiting.

    Comportamento controlado por TRUST_PROXY_HEADERS (variável de ambiente):

    - TRUST_PROXY_HEADERS=false (padrão):
        Ignora X-Forwarded-For e X-Real-IP completamente.
        Usa sempre request.client.host — o IP da conexão TCP direta.
        Isso previne que um atacante falsifique o IP via header e burle o rate limit.

    - TRUST_PROXY_HEADERS=true:
        Confia nos headers de proxy (X-Forwarded-For → X-Real-IP → client.host).
        Use somente quando a aplicação estiver atrás de um proxy reverso confiável
        (ex.: Nginx, AWS ALB) que sobrescreve esses headers de forma controlada.
    """
    if _TRUST_PROXY_HEADERS:
        return (
            request.headers.get("X-Real-IP")
            or request.headers.get("X-Forwarded-For", "").split(",")[0].strip()
            or (request.client.host if request.client else "unknown")
        ) or "unknown"
    return (request.client.host if request.client else "unknown") or "unknown"


async def check_rate_limit(key: str, group: str) -> Tuple[bool, Optional[int]]:
    return await rate_limiter.check(key, group)


def make_rate_limit_dep(group: str):
    """Dependency de rate limit por grupo (usa IP real como chave)."""
    async def _dep(request: Request):
        ip = get_client_ip(request)
        allowed, retry_after = await rate_limiter.check(ip, group)
        if not allowed:
            raise HTTPException(
                status_code=429,
                headers={"Retry-After": str(retry_after or 60)},
                detail={
                    "error": "RATE_LIMIT_EXCEEDED",
                    "message": "Muitas tentativas. Tente novamente em alguns instantes.",
                    "retry_after_seconds": retry_after or 60,
                },
            )
    return _dep
