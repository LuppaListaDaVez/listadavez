"""FeatureFlagService: helpers to query/mutate tenant feature flags.

P1: cache TTL de 30s para reduzir chamadas ao banco.
"""
from typing import Dict, List

from db import db
from models import new_id, utcnow_iso
from cache_service import cache, key_features, invalidate_features, TTL

# Catalog of features required by the system (seeded on boot).
FEATURE_CATALOG: List[Dict[str, str]] = [
    {"key": "lista_da_vez", "name": "Lista da Vez", "description": "Fila de atendimento em tempo real."},
    {"key": "tempo_real", "name": "Tempo Real", "description": "Atualizações em tempo real via WebSocket."},
    {"key": "notificacoes", "name": "Notificações", "description": "Notificações para vendedores e gerentes."},
    {"key": "registro_rapido", "name": "Registro Rápido", "description": "Registro rápido de atendimentos."},
    {"key": "motivos_nao_venda", "name": "Motivos de Não Venda", "description": "Cadastro de motivos de não conversão."},
    {"key": "abordagem_proativa", "name": "Abordagem Proativa", "description": "Acompanhamento proativo de clientes."},
    {"key": "relatorios_basicos", "name": "Relatórios Básicos", "description": "Relatórios operacionais básicos."},
    {"key": "relatorios_avancados", "name": "Relatórios Avançados", "description": "Relatórios avançados com filtros."},
    {"key": "dashboards", "name": "Dashboards", "description": "Painéis visuais executivos."},
    {"key": "feedbacks", "name": "Feedbacks", "description": "Coleta de feedback de clientes."},
    {"key": "rankings", "name": "Rankings", "description": "Ranking de vendedores."},
    {"key": "metas", "name": "Metas", "description": "Cadastro e acompanhamento de metas."},
    {"key": "exportacao", "name": "Exportação", "description": "Exportação de dados em CSV/Excel."},
    {"key": "multi_lojas", "name": "Multi Lojas", "description": "Gestão de múltiplas unidades."},
    {"key": "multi_filas", "name": "Multi Filas", "description": "Múltiplas filas por unidade."},
    {"key": "multi_equipes", "name": "Multi Equipes", "description": "Múltiplas equipes por unidade."},
    {"key": "produtos", "name": "Produtos", "description": "Cadastro de produtos."},
    {"key": "vendas_detalhadas", "name": "Vendas Detalhadas", "description": "Detalhamento de vendas."},
    {"key": "api_integracao", "name": "API de Integração", "description": "API para integrações externas."},
    {"key": "integracao_pdv", "name": "Integração PDV", "description": "Integração com sistemas de PDV."},
    {"key": "gamificacao", "name": "Gamificação", "description": "Elementos de gamificação."},
    {"key": "suporte_prioritario", "name": "Suporte Prioritário", "description": "Atendimento prioritário."},
    # Etapa 12
    {"key": "automacoes", "name": "Automações", "description": "Regras de automação configuráveis."},
    {"key": "alertas_inteligentes", "name": "Alertas Inteligentes", "description": "Alertas operacionais inteligentes."},
    {"key": "notificacoes_externas", "name": "Notificações Externas", "description": "Canais externos (e-mail, push)."},
    {"key": "email_transacional", "name": "E-mail Transacional", "description": "Envio de e-mails automáticos."},
    {"key": "push_notifications", "name": "Push Notifications", "description": "Notificações push para dispositivos."},
    {"key": "motivacao_publica", "name": "Motivação Pública", "description": "Eventos motivacionais públicos em tempo real."},
    {"key": "templates_notificacao", "name": "Templates de Notificação", "description": "Gerenciamento de templates de mensagem."},
    {"key": "preferencias_notificacao", "name": "Preferências de Notificação", "description": "Preferências individuais de notificação."},
    # Etapa 14
    {"key": "lgpd", "name": "LGPD / Privacidade", "description": "Portal de privacidade, solicitações LGPD, consentimentos e mapa de dados."},
    {"key": "retencao_dados", "name": "Retenção de Dados", "description": "Políticas de retenção e jobs de ciclo de vida dos dados."},
    {"key": "backup_restore", "name": "Backup & Restore", "description": "Backup tenant-scoped e restore controlado."},
    {"key": "anonimizacao_dados", "name": "Anonimização", "description": "Anonimização segura de dados pessoais."},
]


async def get_tenant_features(tenant_id: str) -> Dict[str, bool]:
    # P1: cache de features por tenant
    cached = cache.get(key_features(tenant_id))
    if cached is not None:
        return cached
    cursor = db.tenant_features.find({"tenant_id": tenant_id})
    items = await cursor.to_list(length=500)
    result = {item["feature_key"]: bool(item.get("enabled", False)) for item in items}
    cache.set(key_features(tenant_id), result, TTL["feature_flags"])
    return result


async def set_tenant_feature(
    *, tenant_id: str, feature_key: str, enabled: bool, updated_by: str
):
    now = utcnow_iso()
    existing = await db.tenant_features.find_one(
        {"tenant_id": tenant_id, "feature_key": feature_key}
    )
    if existing:
        await db.tenant_features.update_one(
            {"id": existing["id"]},
            {
                "$set": {
                    "enabled": enabled,
                    "updated_at": now,
                    "updated_by": updated_by,
                }
            },
        )
    else:
        await db.tenant_features.insert_one(
            {
                "id": new_id(),
                "tenant_id": tenant_id,
                "feature_key": feature_key,
                "enabled": enabled,
                "created_at": now,
                "updated_at": now,
                "updated_by": updated_by,
            }
        )
    # P1: invalidar cache após escrita
    invalidate_features(tenant_id)


async def is_enabled(tenant_id: str, feature_key: str) -> bool:
    # P1: usa get_tenant_features que tem cache
    features = await get_tenant_features(tenant_id)
    return bool(features.get(feature_key, False))
