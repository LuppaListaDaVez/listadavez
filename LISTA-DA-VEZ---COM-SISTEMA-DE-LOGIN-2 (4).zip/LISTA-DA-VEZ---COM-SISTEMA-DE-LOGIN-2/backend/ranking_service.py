"""RankingService — Etapa 9. Cálculo e persistência de rankings."""
from datetime import datetime, timezone, date, timedelta
from typing import Optional

from db import db
from models import new_id, utcnow_iso

RANKING_CRITERIA = {
    "REVENUE", "CONVERSION", "AVERAGE_TICKET",
    "SALES_COUNT", "ATTENDANCE_COUNT", "ITEMS_SOLD",
}
RANKING_SCOPES = {"TENANT", "STORE", "TEAM"}


def _today() -> str:
    return date.today().isoformat()


def _month_start() -> str:
    t = date.today()
    return date(t.year, t.month, 1).isoformat()


async def _get_seller_name(seller_id: str) -> str:
    s = await db.seller_profiles.find_one({"id": seller_id})
    if not s:
        return "—"
    u = await db.users.find_one({"id": s.get("user_id", "")})
    return u.get("name", "—") if u else "—"


async def _get_store_name(store_id: str) -> str:
    s = await db.stores.find_one({"id": store_id})
    return s.get("name", "—") if s else "—"


async def _get_team_name(team_id: str) -> str:
    t = await db.teams.find_one({"id": team_id})
    return t.get("name", "—") if t else "—"


def _centsToBRL(cents: int) -> str:
    return f"R$ {cents / 100:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def _bpToStr(bp: int) -> str:
    return f"{bp / 100:.1f}%"


async def _fetch_finished_atts(tenant_id: str, store_ids: Optional[list], seller_ids: Optional[list],
                                period_start: str, period_end: str) -> list:
    q: dict = {"tenant_id": tenant_id, "status": "FINISHED"}
    if store_ids:
        q["store_id"] = {"$in": store_ids}
    if seller_ids:
        q["seller_id"] = {"$in": seller_ids}
    q["finished_at"] = {"$gte": period_start, "$lte": period_end + "T23:59:59.999999+00:00"}
    return await db.attendances.find(q).to_list(5000)


async def get_ranking(
    tenant_id: str,
    criteria: str,
    scope: str = "STORE",
    store_ids: Optional[list] = None,
    period_start: Optional[str] = None,
    period_end: Optional[str] = None,
) -> dict:
    """Calcula ranking dinamicamente com dados reais."""
    criteria = criteria.upper()
    if criteria not in RANKING_CRITERIA:
        criteria = "REVENUE"

    ps = period_start or _month_start()
    pe = period_end or _today()

    atts = await _fetch_finished_atts(tenant_id, store_ids, None, ps, pe)
    valid = [a for a in atts if a.get("result") != "INVALID"]
    sales = [a for a in valid if a.get("result") == "SALE"]

    # Build aggregation by seller
    by_seller: dict = {}
    for a in valid:
        sid = a.get("seller_id")
        if not sid:
            continue
        if sid not in by_seller:
            by_seller[sid] = {
                "seller_id": sid,
                "store_id": a.get("store_id"),
                "atendimentos": 0,
                "vendas": 0,
                "revenue": 0,
                "items": 0,
            }
        by_seller[sid]["atendimentos"] += 1
        if a.get("result") == "SALE":
            by_seller[sid]["vendas"] += 1
            by_seller[sid]["revenue"] += a.get("sale_amount_cents") or 0

    # ITEMS_SOLD: fetch sale_items
    # REGRA: soma a quantidade real de produtos registrada em sale_items (não usa product_quantity da attendance).
    if criteria == "ITEMS_SOLD":
        # 1) Coleta sale_ids dos atendimentos finalizados com venda
        att_sale_ids: list = []
        att_sale_seller_map: dict = {}  # sale_id → seller_id
        for a in sales:
            if a.get("sale_id"):
                att_sale_ids.append(a["sale_id"])
                att_sale_seller_map[a["sale_id"]] = a.get("seller_id")

        # 2) Também busca vendas proativas diretas (source=PROACTIVE, sem attendance)
        proactive_sales_q: dict = {"tenant_id": tenant_id, "status": "COMPLETED", "attendance_id": None}
        if store_ids:
            proactive_sales_q["store_id"] = {"$in": store_ids}
        proactive_sales_q["created_at"] = {"$gte": ps, "$lte": pe + "T23:59:59.999999+00:00"}
        proactive_docs = await db.sales.find(proactive_sales_q).to_list(2000)
        for s in proactive_docs:
            if s["id"] not in att_sale_seller_map:
                att_sale_ids.append(s["id"])
                att_sale_seller_map[s["id"]] = s.get("seller_id")

        if att_sale_ids:
            # Busca sale_items para todos os sale_ids coletados
            items = await db.sale_items.find(
                {"tenant_id": tenant_id, "sale_id": {"$in": att_sale_ids}}
            ).to_list(20000)
            for item in items:
                sid = att_sale_seller_map.get(item["sale_id"])
                if not sid:
                    continue
                qty = item.get("quantity", 1)
                if sid in by_seller:
                    by_seller[sid]["items"] += qty
                else:
                    by_seller.setdefault(sid, {
                        "seller_id": sid, "store_id": None,
                        "atendimentos": 0, "vendas": 0, "revenue": 0, "items": 0,
                    })
                    by_seller[sid]["items"] += qty

            # Vendas sem sale_items específicos (ex.: múltiplos agregados) usam item_count técnico.
            sales_docs = await db.sales.find({"tenant_id": tenant_id, "id": {"$in": att_sale_ids}}, {"_id": 0, "id": 1, "seller_id": 1, "item_count": 1}).to_list(20000)
            counted_sale_ids = {item.get("sale_id") for item in items}
            for sale in sales_docs:
                if sale["id"] in counted_sale_ids:
                    continue
                sid = att_sale_seller_map.get(sale["id"]) or sale.get("seller_id")
                if sid:
                    by_seller.setdefault(sid, {"seller_id": sid, "store_id": None, "atendimentos": 0, "vendas": 0, "revenue": 0, "items": 0})
                    by_seller[sid]["items"] += sale.get("item_count") or 0

    # Bulk fetch sellers, users and stores to avoid N+1 queries
    all_seller_ids = list(by_seller.keys())
    sellers_map: dict = {}
    if all_seller_ids:
        async for sp in db.seller_profiles.find({"id": {"$in": all_seller_ids}}):
            sellers_map[sp["id"]] = sp
    user_ids = [sp["user_id"] for sp in sellers_map.values() if sp.get("user_id")]
    users_map: dict = {}
    if user_ids:
        async for u in db.users.find({"id": {"$in": user_ids}}):
            users_map[u["id"]] = u
    all_store_ids = list({d.get("store_id") for d in by_seller.values() if d.get("store_id")})
    stores_map: dict = {}
    if all_store_ids:
        async for st in db.stores.find({"id": {"$in": all_store_ids}}):
            stores_map[st["id"]] = st

    items_list = []
    for sid, d in by_seller.items():
        sp = sellers_map.get(sid, {})
        u = users_map.get(sp.get("user_id", ""), {})
        name = u.get("name") or "—"
        avatar_url = u.get("avatar_url") or sp.get("avatar_url")
        store_id = d.get("store_id")
        store_name = stores_map.get(store_id, {}).get("name", "—") if store_id else "—"

        att = d["atendimentos"]
        ven = d["vendas"]
        rev = d["revenue"]
        its = d["items"]

        if criteria == "REVENUE":
            value = rev
            label = _centsToBRL(rev)
        elif criteria == "CONVERSION":
            value = round(ven / att * 10000) if att else 0
            label = _bpToStr(value)
        elif criteria == "AVERAGE_TICKET":
            value = round(rev / ven) if ven else 0
            label = _centsToBRL(value)
        elif criteria == "SALES_COUNT":
            value = ven
            label = str(ven)
        elif criteria == "ATTENDANCE_COUNT":
            value = att
            label = str(att)
        else:  # ITEMS_SOLD
            value = its
            label = str(its)

        items_list.append({
            "seller_id": sid,
            "seller_name": name,
            "seller_avatar_url": avatar_url,
            "store_id": store_id,
            "store_name": store_name,
            "position": 0,  # will be set below
            "value": value,
            "metric_label": label,
            # extra context
            "atendimentos": att,
            "vendas": ven,
        })

    items_list.sort(key=lambda x: x["value"], reverse=True)
    for i, item in enumerate(items_list):
        item["position"] = i + 1

    return {
        "criteria": criteria,
        "scope": scope,
        "period_start": ps,
        "period_end": pe,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "items": items_list,
    }


async def persist_ranking(tenant_id: str, actor_user_id: str, ranking_data: dict) -> dict:
    """Persiste um ranking calculado na coleção rankings."""
    now = utcnow_iso()
    doc = {
        "id": new_id(),
        "tenant_id": tenant_id,
        "store_id": ranking_data.get("store_id"),
        "team_id": ranking_data.get("team_id"),
        "criteria": ranking_data["criteria"],
        "scope": ranking_data.get("scope", "STORE"),
        "period_start": ranking_data["period_start"],
        "period_end": ranking_data["period_end"],
        "items": ranking_data.get("items", []),
        "generated_by": actor_user_id,
        "created_at": now,
        "updated_at": now,
    }
    await db.rankings.insert_one(doc)
    doc.pop("_id", None)
    return doc
