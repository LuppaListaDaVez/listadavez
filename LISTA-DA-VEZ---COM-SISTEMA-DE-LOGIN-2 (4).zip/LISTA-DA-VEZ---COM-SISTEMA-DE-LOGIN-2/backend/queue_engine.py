"""QueueEngine — P1: concorrência protegida com queue_lock_service + outbox pattern.

Nenhum controller deve manipular queue_entries, status do vendedor ou
attendances diretamente. Os controllers chamam estas funções.
"""
from typing import Optional, List, Dict, Any

from fastapi import HTTPException, Request
from pymongo import ReturnDocument

from db import db
from models import new_id, utcnow_iso, SaleInput
from audit import log_audit
from features import is_enabled
from state_machine import change_state
from realtime import event_bus
from queue_lock_service import seller_lock
import sales_service
import goals_service
import motivos_perda_service

QUEUE_DEFAULT_SETTINGS = {
    "return_to_end_after_attendance": True,
    "allow_manager_reorder": True,
    "require_loss_reason": True,
    "require_sale_amount": True,
    "allow_invalid_attendance": True,
    "return_from_break_to_end": True,
    "notify_when_positions_before": 2,
    "proactive_converted_affects_queue": True,
    "preference_enabled": True,
    "preference_return_rule": "PREVIOUS_POSITION",
}

AWAY_STATES = {"BREAK", "LUNCH", "MEETING", "TRAINING", "ABSENT", "OFFLINE", "BLOCKED"}


def _conflict():
    raise HTTPException(
        status_code=409,
        detail={
            "error": "QUEUE_OPERATION_CONFLICT",
            "message": "A fila foi atualizada por outra operação. Atualize os dados e tente novamente.",
        },
    )


MAX_MULTIPLE_CUSTOMERS = 50


def _distribute_int(total: int, slots: int) -> list[int]:
    if slots <= 0:
        return []
    base = total // slots
    rem = total % slots
    return [base + (1 if i < rem else 0) for i in range(slots)]


def _validate_non_negative_int(value, field: str) -> int:
    if value is None:
        return 0
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise HTTPException(status_code=400, detail=f"{field} deve ser um inteiro maior ou igual a zero.")
    return value


def _strip_mongo_ids(value):
    if isinstance(value, dict):
        return {k: _strip_mongo_ids(v) for k, v in value.items() if k != "_id"}
    if isinstance(value, list):
        return [_strip_mongo_ids(v) for v in value]
    return value


def _build_multiple_rows(payload: dict) -> list[dict]:
    mode = payload.get("mode")
    if mode == "AGGREGATED":
        total = _validate_non_negative_int(payload.get("total_customers"), "Total de clientes")
        successes = _validate_non_negative_int(payload.get("successes"), "Sucessos")
        no_sales = _validate_non_negative_int(payload.get("no_sales"), "Não sucessos")
        amount = _validate_non_negative_int(payload.get("total_amount_cents") or 0, "Valor total")
        products = _validate_non_negative_int(payload.get("total_product_quantity") or 0, "Produtos totais")
        if total <= 0 or total > MAX_MULTIPLE_CUSTOMERS:
            raise HTTPException(status_code=400, detail=f"Total de clientes deve ficar entre 1 e {MAX_MULTIPLE_CUSTOMERS}.")
        if successes + no_sales != total:
            raise HTTPException(status_code=400, detail="Sucessos + não sucessos deve ser igual ao total de clientes.")
        if successes == 0 and (amount > 0 or products > 0):
            raise HTTPException(status_code=400, detail="Sem sucessos, valor total e produtos totais devem ser zero.")
        amounts = _distribute_int(amount, successes)
        product_dist = _distribute_int(products, successes)
        rows = []
        for i in range(successes):
            rows.append({"result": "SALE", "sale_amount_cents": amounts[i], "product_quantity": product_dist[i], "customer_name": f"Cliente {i + 1}", "notes": payload.get("notes")})
        for i in range(no_sales):
            rows.append({"result": "NO_SALE", "sale_amount_cents": 0, "product_quantity": 0, "customer_name": f"Cliente {successes + i + 1}", "notes": payload.get("notes")})
        return rows
    rows = payload.get("rows") or []
    if not rows or len(rows) > MAX_MULTIPLE_CUSTOMERS:
        raise HTTPException(status_code=400, detail=f"Informe entre 1 e {MAX_MULTIPLE_CUSTOMERS} linhas detalhadas.")
    out = []
    for idx, row in enumerate(rows, 1):
        result = row.get("result")
        if result not in {"SALE", "NO_SALE"}:
            raise HTTPException(status_code=400, detail=f"Resultado inválido na linha {idx}.")
        amount = _validate_non_negative_int(row.get("sale_amount_cents") or 0, f"Valor da linha {idx}")
        products = _validate_non_negative_int(row.get("product_quantity") or 0, f"Produtos da linha {idx}")
        if result == "NO_SALE" and (amount > 0 or products > 0):
            raise HTTPException(status_code=400, detail=f"Linha {idx}: não sucesso não pode ter valor ou produtos.")
        out.append({**row, "sale_amount_cents": amount, "product_quantity": products, "customer_name": row.get("customer_name") or f"Cliente {idx}"})
    return out


# ---------------- Queue helpers ----------------
async def ensure_default_queue(tenant_id: str, store_id: str) -> dict:
    q = await db.queues.find_one(
        {"tenant_id": tenant_id, "store_id": store_id, "is_default": True}
    )
    if q:
        return q
    now = utcnow_iso()
    doc = {
        "id": new_id(), "tenant_id": tenant_id, "store_id": store_id,
        "name": "Fila Geral", "type": "GENERAL", "department_name": None,
        "team_id": None, "priority_level": None, "is_default": True,
        "routing_rules": None, "status": "ACTIVE",
        "settings": QUEUE_DEFAULT_SETTINGS.copy(), "version": 1,
        "locked_at": None, "locked_by": None,
        "created_at": now, "updated_at": now,
    }
    await db.queues.insert_one(doc)
    return doc


async def _resolve_queue(tenant_id: str, store_id: str, queue_id: Optional[str]) -> dict:
    if queue_id:
        q = await db.queues.find_one(
            {"tenant_id": tenant_id, "store_id": store_id, "id": queue_id}
        )
        if not q:
            raise HTTPException(status_code=404, detail="Fila não encontrada.")
        return q
    return await ensure_default_queue(tenant_id, store_id)


def _queue_settings(queue: dict) -> dict:
    return {**QUEUE_DEFAULT_SETTINGS, **(queue.get("settings") or {})}


async def _store_queue_settings(tenant_id: str, store_id: str) -> dict:
    st = await db.store_settings.find_one({"tenant_id": tenant_id, "store_id": store_id})
    return (st or {}).get("queue_settings", {}) or {}


async def _get_seller(tenant_id: str, store_id: str, seller_id: str) -> dict:
    s = await db.seller_profiles.find_one({"tenant_id": tenant_id, "id": seller_id})
    if not s:
        raise HTTPException(status_code=404, detail="Vendedor não encontrado.")
    if s["store_id"] != store_id:
        raise HTTPException(status_code=404, detail="Vendedor não pertence a esta unidade.")
    return s


async def _emit_event(tenant_id, store_id, queue_id, seller_id, event_type, created_by, payload=None):
    await db.queue_events.insert_one({
        "id": new_id(), "tenant_id": tenant_id, "store_id": store_id,
        "queue_id": queue_id, "seller_id": seller_id, "event_type": event_type,
        "payload": payload or {}, "created_by": created_by, "created_at": utcnow_iso(),
    })


async def _publish(tenant_id, store_id, queue_id, events):
    """Publica eventos realtime (best-effort; nunca quebra a operação principal)."""
    for event_type, payload in events:
        await event_bus.publish_event(
            tenant_id=tenant_id, store_id=store_id, queue_id=queue_id,
            event_type=event_type, payload=payload or {},
        )


async def recalculate_positions(tenant_id: str, queue_id: str):
    now = utcnow_iso()
    entries = await db.queue_entries.find(
        {"tenant_id": tenant_id, "queue_id": queue_id, "status": "WAITING"}
    ).sort([("position", 1), ("entered_at", 1)]).to_list(1000)
    for i, e in enumerate(entries, start=1):
        if e.get("position") != i:
            await db.queue_entries.update_one(
                {"id": e["id"]}, {"$set": {"position": i, "updated_at": now}}
            )


async def _insert_at_end(tenant_id, store_id, queue_id, seller):
    now = utcnow_iso()
    count = await db.queue_entries.count_documents(
        {"tenant_id": tenant_id, "queue_id": queue_id, "status": "WAITING"}
    )
    await db.queue_entries.insert_one({
        "id": new_id(), "tenant_id": tenant_id, "store_id": store_id, "queue_id": queue_id,
        "seller_id": seller["id"], "user_id": seller["user_id"], "position": count + 1,
        "status": "WAITING", "entered_at": now, "updated_at": now,
    })


async def _insert_at_position(tenant_id, store_id, queue_id, seller, position: int):
    now = utcnow_iso()
    count = await db.queue_entries.count_documents(
        {"tenant_id": tenant_id, "queue_id": queue_id, "status": "WAITING"}
    )
    pos = max(1, min(int(position or 1), count + 1))
    await db.queue_entries.delete_many({"tenant_id": tenant_id, "queue_id": queue_id, "seller_id": seller["id"], "status": "WAITING"})
    await db.queue_entries.update_many(
        {"tenant_id": tenant_id, "queue_id": queue_id, "status": "WAITING", "position": {"$gte": pos}},
        {"$inc": {"position": 1}, "$set": {"updated_at": now}},
    )
    await db.queue_entries.insert_one({
        "id": new_id(), "tenant_id": tenant_id, "store_id": store_id, "queue_id": queue_id,
        "seller_id": seller["id"], "user_id": seller["user_id"], "position": pos,
        "status": "WAITING", "entered_at": now, "updated_at": now,
    })
    await recalculate_positions(tenant_id, queue_id)
    return pos


async def _preference_rule(tenant_id: str, store_id: str, queue: dict) -> str:
    settings = _queue_settings(queue)
    store_qs = await _store_queue_settings(tenant_id, store_id)
    rule = store_qs.get("preference_return_rule") or settings.get("preference_return_rule") or "PREVIOUS_POSITION"
    return rule if rule in {"TO_TOP", "PREVIOUS_POSITION", "TO_END", "CONSUME_TURN"} else "PREVIOUS_POSITION"


async def _apply_preference_return(*, tenant_id, store_id, queue, attendance, seller, actor_user_id, actor_role, request=None):
    now = utcnow_iso()
    rule = attendance.get("preference_return_rule") or "PREVIOUS_POSITION"
    snap = attendance.get("preference_queue_snapshot") or {}
    if attendance.get("preference_return_applied"):
        return attendance
    updates = {
        "preference_return_applied": True,
        "preference_return_applied_at": now,
        "preference_return_rule_applied": rule,
        "preference_turn_consumed": rule == "CONSUME_TURN",
    }
    seller_current = await db.seller_profiles.find_one({"tenant_id": tenant_id, "id": seller["id"]})
    if not seller_current or seller_current.get("status") != "ACTIVE" or seller_current.get("jornada_encerrada") or seller_current.get("current_status") not in {"AVAILABLE", "WAITING_IN_QUEUE"} or queue.get("status") != "ACTIVE":
        updates.update({"preference_final_position": None, "preference_return_method": "nao_reinserido", "preference_return_failure_reason": "Vendedor indisponível, inativo, fora da jornada ou fila inativa."})
        await db.attendances.update_one({"id": attendance["id"]}, {"$set": updates})
        return {**attendance, **updates}

    if seller_current.get("current_status") != "WAITING_IN_QUEUE":
        await change_state(tenant_id=tenant_id, store_id=store_id, seller_id=seller["id"], to_state="WAITING_IN_QUEUE",
                           actor_user_id=actor_user_id, actor_role=actor_role, via_queue_engine=True, request=request)

    method = "fim"
    final_pos = None
    if rule == "TO_TOP":
        final_pos = await _insert_at_position(tenant_id, store_id, queue["id"], seller_current, 1)
        method = "topo"
    elif rule in {"TO_END", "CONSUME_TURN"}:
        await _insert_at_end(tenant_id, store_id, queue["id"], seller_current)
        await recalculate_positions(tenant_id, queue["id"])
        final_entry = await db.queue_entries.find_one({"tenant_id": tenant_id, "queue_id": queue["id"], "seller_id": seller["id"], "status": "WAITING"}, {"_id": 0})
        final_pos = final_entry.get("position") if final_entry else None
        method = "perdeu_a_vez" if rule == "CONSUME_TURN" else "fim"
    else:
        prev_id = snap.get("previous_member_id")
        next_id = snap.get("next_member_id")
        prev_entry = await db.queue_entries.find_one({"tenant_id": tenant_id, "queue_id": queue["id"], "seller_id": prev_id, "status": "WAITING"}, {"_id": 0}) if prev_id else None
        next_entry = await db.queue_entries.find_one({"tenant_id": tenant_id, "queue_id": queue["id"], "seller_id": next_id, "status": "WAITING"}, {"_id": 0}) if next_id else None
        if prev_entry and next_entry and prev_entry.get("position", 0) < next_entry.get("position", 0):
            final_pos = await _insert_at_position(tenant_id, store_id, queue["id"], seller_current, next_entry["position"])
            method = "entre_vizinhos"
        elif next_entry:
            final_pos = await _insert_at_position(tenant_id, store_id, queue["id"], seller_current, next_entry["position"])
            method = "antes_do_posterior"
        elif prev_entry:
            final_pos = await _insert_at_position(tenant_id, store_id, queue["id"], seller_current, prev_entry["position"] + 1)
            method = "apos_anterior"
        else:
            final_pos = await _insert_at_position(tenant_id, store_id, queue["id"], seller_current, snap.get("previous_position") or 1)
            method = "posicao_numerica"
    await db.queues.update_one({"id": queue["id"]}, {"$inc": {"version": 1}, "$set": {"updated_at": now}})
    queue_after = await db.queues.find_one({"id": queue["id"]}, {"_id": 0})
    updates.update({
        "preference_final_position": final_pos,
        "preference_queue_version_final": queue_after.get("version") if queue_after else None,
        "preference_return_method": method,
    })
    await db.attendances.update_one({"id": attendance["id"]}, {"$set": updates})
    await _emit_event(tenant_id, store_id, queue["id"], seller["id"], "PREFERENCE_RETURN_APPLIED", actor_user_id, updates)
    await log_audit(action="PREFERENCE_RETURN_APPLIED", entity="attendance", entity_id=attendance["id"],
                    tenant_id=tenant_id, store_id=store_id, user_id=actor_user_id, new_value=updates, request=request)
    return {**attendance, **updates}


async def _enrich(sellers: List[dict]) -> List[dict]:
    user_ids = [s["user_id"] for s in sellers]
    team_ids = [s.get("team_id") for s in sellers if s.get("team_id")]
    users = {}
    async for u in db.users.find({"id": {"$in": user_ids}}):
        users[u["id"]] = u
    teams = {}
    if team_ids:
        async for t in db.teams.find({"id": {"$in": team_ids}}):
            teams[t["id"]] = t
    out = []
    for s in sellers:
        u = users.get(s["user_id"], {})
        t = teams.get(s.get("team_id")) if s.get("team_id") else None
        out.append({
            "seller_id": s["id"], "user_id": s["user_id"],
            "name": u.get("name"), "email": u.get("email"),
            "employee_code": s.get("employee_code"),
            "current_status": s.get("current_status"),
            "team_name": t.get("name") if t else None,
            "avatar_url": u.get("avatar_url") or s.get("avatar_url"),
            # Novos flags do Prompt 2
            "em_atividade_operacional": s.get("em_atividade_operacional", False),
            "jornada_encerrada": s.get("jornada_encerrada", False),
            "motivo_saida": s.get("motivo_saida"),
        })
    return out


# ---------------- State ----------------
async def get_queue_state(tenant_id: str, store_id: str, queue_id: Optional[str] = None) -> dict:
    store = await db.stores.find_one({"tenant_id": tenant_id, "id": store_id})
    if not store:
        raise HTTPException(status_code=404, detail="Unidade não encontrada.")
    store.pop("_id", None)
    queue = await _resolve_queue(tenant_id, store_id, queue_id)
    queue.pop("_id", None)
    await recalculate_positions(tenant_id, queue["id"])

    raw_entries = await db.queue_entries.find(
        {"tenant_id": tenant_id, "queue_id": queue["id"], "status": "WAITING"}
    ).sort("position", 1).to_list(1000)
    seller_ids = [e["seller_id"] for e in raw_entries]
    sellers_map = {}
    if seller_ids:
        async for s in db.seller_profiles.find({"id": {"$in": seller_ids}}):
            sellers_map[s["id"]] = s
    entry_sellers = [sellers_map[sid] for sid in seller_ids if sid in sellers_map]
    enriched_map = {e["seller_id"]: e for e in await _enrich(entry_sellers)}
    entries = []
    for e in raw_entries:
        info = enriched_map.get(e["seller_id"], {})
        entries.append({
            "id": e["id"], "seller_id": e["seller_id"], "position": e["position"],
            "status": e["status"], "entered_at": e["entered_at"],
            # Flags do Prompt 2 — incluídos por _enrich mas repetidos aqui para clareza
            "em_atividade_operacional": info.get("em_atividade_operacional", False),
            **info,
        })

    all_sellers = await db.seller_profiles.find(
        {"tenant_id": tenant_id, "store_id": store_id, "status": "ACTIVE"}
    ).to_list(1000)
    waiting_ids = set(seller_ids)
    available = [s for s in all_sellers if s.get("current_status") == "AVAILABLE" and s["id"] not in waiting_ids]
    serving = [s for s in all_sellers if s.get("current_status") == "SERVING"]
    away = [s for s in all_sellers if s.get("current_status") in AWAY_STATES]

    raw_att = await db.attendances.find(
        {"tenant_id": tenant_id, "store_id": store_id, "status": "IN_PROGRESS"}
    ).sort("started_at", 1).to_list(1000)
    att_seller_ids = [a["seller_id"] for a in raw_att]
    att_sellers = {}
    if att_seller_ids:
        async for s in db.seller_profiles.find({"id": {"$in": att_seller_ids}}):
            att_sellers[s["id"]] = s
    att_enrich = {e["seller_id"]: e for e in await _enrich(list(att_sellers.values()))}
    visit_ids = [a.get("customer_visit_id") for a in raw_att if a.get("customer_visit_id")]
    visits_map = {}
    if visit_ids:
        async for v in db.customer_visits.find({"id": {"$in": visit_ids}}):
            visits_map[v["id"]] = v
    active_attendances = []
    for a in raw_att:
        a.pop("_id", None)
        v = visits_map.get(a.get("customer_visit_id"), {})
        active_attendances.append({
            **a, "seller": att_enrich.get(a["seller_id"], {}),
            "customer_name": v.get("customer_name"),
        })

    raw_events = await db.queue_events.find(
        {"tenant_id": tenant_id, "queue_id": queue["id"]}
    ).sort("created_at", -1).limit(40).to_list(40)
    ev_seller_ids = [e["seller_id"] for e in raw_events if e.get("seller_id")]
    ev_sellers = {}
    if ev_seller_ids:
        async for s in db.seller_profiles.find({"id": {"$in": ev_seller_ids}}):
            ev_sellers[s["id"]] = s
    ev_enrich = {e["seller_id"]: e for e in await _enrich(list(ev_sellers.values()))}
    recent_events = []
    for e in raw_events:
        e.pop("_id", None)
        recent_events.append({
            **e, "seller_name": (ev_enrich.get(e.get("seller_id")) or {}).get("name"),
        })

    queues = await db.queues.find(
        {"tenant_id": tenant_id, "store_id": store_id, "status": "ACTIVE"}
    ).sort("is_default", -1).to_list(100)
    for q in queues:
        q.pop("_id", None)

    effective_settings = {**_queue_settings(queue), **(await _store_queue_settings(tenant_id, store_id))}

    return {
        "store": store, "queue": queue, "queues": queues, "entries": entries,
        "effective_settings": effective_settings,
        "available_sellers": await _enrich(available),
        "serving_sellers": await _enrich(serving),
        "away_sellers": await _enrich(away),
        "active_attendances": active_attendances,
        "recent_events": recent_events,
    }


# ---------------- Queue CRUD ----------------
async def create_queue(*, tenant_id, store_id, data, actor_user_id, request=None):
    is_default = bool(data.get("is_default"))
    existing_default = await db.queues.find_one(
        {"tenant_id": tenant_id, "store_id": store_id, "is_default": True}
    )
    if existing_default and is_default:
        is_default = False
    if not is_default and not await is_enabled(tenant_id, "multi_filas"):
        raise HTTPException(
            status_code=403,
            detail={"error": "FEATURE_DISABLED", "message": "Recurso de múltiplas filas não está disponível no plano atual."},
        )
    now = utcnow_iso()
    doc = {
        "id": new_id(), "tenant_id": tenant_id, "store_id": store_id,
        "name": data.get("name") or "Fila", "type": data.get("type") or "GENERAL",
        "department_name": data.get("department_name"), "team_id": data.get("team_id"),
        "priority_level": data.get("priority_level"), "is_default": is_default,
        "routing_rules": data.get("routing_rules"), "status": "ACTIVE",
        "settings": {**QUEUE_DEFAULT_SETTINGS, **(data.get("settings") or {})},
        "version": 1, "locked_at": None, "locked_by": None,
        "created_at": now, "updated_at": now,
    }
    await db.queues.insert_one(doc)
    await _emit_event(tenant_id, store_id, doc["id"], None, "QUEUE_CREATED", actor_user_id, {"name": doc["name"]})
    await log_audit(action="QUEUE_CREATED", entity="queue", entity_id=doc["id"],
                    tenant_id=tenant_id, store_id=store_id, user_id=actor_user_id,
                    new_value={"name": doc["name"], "type": doc["type"]}, request=request)
    doc.pop("_id", None)
    return doc


# ---------------- Operations ----------------
async def join_queue(*, tenant_id, store_id, queue_id, seller_id, actor_user_id, actor_role, request=None):
    queue = await _resolve_queue(tenant_id, store_id, queue_id)
    if queue["status"] != "ACTIVE":
        raise HTTPException(status_code=409, detail="Esta fila está inativa.")
    async with seller_lock(tenant_id, seller_id, "JOIN_QUEUE"):
        seller = await _get_seller(tenant_id, store_id, seller_id)
        if seller.get("status") != "ACTIVE":
            raise HTTPException(status_code=409, detail="Vendedor inativo não pode entrar na fila.")
        if seller.get("current_status") != "AVAILABLE":
            raise HTTPException(status_code=409, detail={
                "error": "TRANSICAO_DE_ESTADO_INVALIDA",
                "message": "Apenas vendedores em estado Disponível podem entrar na Fila Geral.",
            })
        if await db.queue_entries.find_one({"tenant_id": tenant_id, "queue_id": queue["id"], "seller_id": seller_id, "status": "WAITING"}):
            raise HTTPException(status_code=409, detail="Vendedor já está aguardando nesta fila.")
        qs = await _store_queue_settings(tenant_id, store_id)
        if not qs.get("seller_can_join_multiple_queues", False):
            other = await db.queue_entries.find_one({"tenant_id": tenant_id, "store_id": store_id, "seller_id": seller_id, "status": "WAITING"})
            if other:
                raise HTTPException(status_code=409, detail={"error": "SELLER_ALREADY_WAITING_IN_ANOTHER_QUEUE", "message": "Vendedor já está aguardando em outra fila."})
        await change_state(tenant_id=tenant_id, store_id=store_id, seller_id=seller_id, to_state="WAITING_IN_QUEUE",
                           actor_user_id=actor_user_id, actor_role=actor_role, via_queue_engine=True, request=request)
        await _insert_at_end(tenant_id, store_id, queue["id"], seller)
        await recalculate_positions(tenant_id, queue["id"])
        await _emit_event(tenant_id, store_id, queue["id"], seller_id, "SELLER_JOINED", actor_user_id)
        await log_audit(action="QUEUE_JOIN", entity="queue_entry", entity_id=queue["id"],
                        tenant_id=tenant_id, store_id=store_id, user_id=actor_user_id,
                        new_value={"seller_id": seller_id}, request=request)
    await _publish(tenant_id, store_id, queue["id"], [
        ("queue.seller_joined", {"seller_id": seller_id}),
        ("queue.updated", {}),
        ("dashboard.updated", {}),
    ])
    return await get_queue_state(tenant_id, store_id, queue["id"])


async def leave_queue(*, tenant_id, store_id, queue_id, seller_id, actor_user_id, actor_role, reason=None, request=None):
    queue = await _resolve_queue(tenant_id, store_id, queue_id)
    seller = await _get_seller(tenant_id, store_id, seller_id)
    deleted = await db.queue_entries.find_one_and_delete(
        {"tenant_id": tenant_id, "queue_id": queue["id"], "seller_id": seller_id, "status": "WAITING"}
    )
    if not deleted:
        raise HTTPException(status_code=409, detail="Vendedor não está nesta fila.")
    if seller.get("current_status") == "WAITING_IN_QUEUE":
        await change_state(tenant_id=tenant_id, store_id=store_id, seller_id=seller_id, to_state="AVAILABLE",
                           actor_user_id=actor_user_id, actor_role=actor_role, reason=reason, via_queue_engine=True, request=request)
    await recalculate_positions(tenant_id, queue["id"])
    await _emit_event(tenant_id, store_id, queue["id"], seller_id, "SELLER_LEFT", actor_user_id, {"reason": reason})
    await log_audit(action="QUEUE_LEAVE", entity="queue_entry", entity_id=queue["id"],
                    tenant_id=tenant_id, store_id=store_id, user_id=actor_user_id,
                    new_value={"seller_id": seller_id, "reason": reason}, request=request)
    await _publish(tenant_id, store_id, queue["id"], [
        ("queue.seller_left", {"seller_id": seller_id}),
        ("queue.updated", {}),
        ("dashboard.updated", {}),
    ])
    return await get_queue_state(tenant_id, store_id, queue["id"])


# ───── Novos endpoints Prompt 2: Janela de Saída Obrigatória ─────────────────

async def sair_da_fila(*, tenant_id, store_id, seller_id, motivo, actor_user_id, actor_role,
                       queue_id=None, request=None):
    """Retira o vendedor da Fila Geral via Janela de Saída.
    Motivos válidos: LANCHE_OU_ALMOCO, ATIVIDADE_OPERACIONAL, ENCERRAR_DIA.
    • LANCHE_OU_ALMOCO → vendedor vai para Fora (BREAK).
    • ATIVIDADE_OPERACIONAL → permanece na fila com subestado EM_ATIVIDADE_OPERACIONAL.
    • ENCERRAR_DIA → vendedor vai para Fora (OFFLINE) com jornada_encerrada=True.
    """
    from state_machine import MOTIVO_PARA_ESTADO, MOTIVO_PT_LABEL, ESTADO_PARA_PT, AWAY_STATES as SM_AWAY

    MOTIVOS_VALIDOS = {"LANCHE_OU_ALMOCO", "ATIVIDADE_OPERACIONAL", "ENCERRAR_DIA"}
    if motivo not in MOTIVOS_VALIDOS:
        raise HTTPException(status_code=400, detail={
            "error": "MOTIVO_INVALIDO",
            "message": "Motivo inválido. Selecione: Lanche ou almoço, Atividade operacional ou Encerrar o dia.",
        })

    seller = await _get_seller(tenant_id, store_id, seller_id)
    queue = await _resolve_queue(tenant_id, store_id, queue_id)
    current = seller.get("current_status")
    waiting_entry = await db.queue_entries.find_one({"tenant_id": tenant_id, "queue_id": queue["id"], "seller_id": seller_id, "status": "WAITING"}, {"_id": 0})

    # Bloquear se não estiver na Fila Geral
    if current != "WAITING_IN_QUEUE" and waiting_entry and current == "AVAILABLE":
        await db.seller_profiles.update_one({"id": seller_id}, {"$set": {"current_status": "WAITING_IN_QUEUE", "updated_at": utcnow_iso()}})
        seller["current_status"] = "WAITING_IN_QUEUE"
        current = "WAITING_IN_QUEUE"
    if current != "WAITING_IN_QUEUE":
        raise HTTPException(status_code=409, detail={
            "error": "TRANSICAO_DE_ESTADO_INVALIDA",
            "message": "A Janela de Saída só está disponível para vendedores que estão na Fila Geral.",
            "estado_atual": ESTADO_PARA_PT.get(current, current),
        })

    # Bloquear se houver atendimento aberto
    in_progress = await db.attendances.find_one(
        {"tenant_id": tenant_id, "seller_id": seller_id, "status": "IN_PROGRESS"}
    )
    if in_progress:
        raise HTTPException(status_code=409, detail={
            "error": "ATENDIMENTO_EM_ABERTO",
            "message": "Não é possível sair da Fila Geral enquanto há um atendimento em andamento. Conclua o atendimento primeiro.",
        })

    now = utcnow_iso()
    motivo_label = MOTIVO_PT_LABEL.get(motivo, motivo)

    if motivo == "ATIVIDADE_OPERACIONAL":
        # Permanece na fila — apenas ativa o sub-estado
        await db.seller_profiles.update_one(
            {"id": seller_id},
            {"$set": {
                "em_atividade_operacional": True,
                "motivo_saida": motivo,
                "updated_at": now,
            }},
        )
        await db.seller_status_logs.insert_one({
            "id": new_id(), "tenant_id": tenant_id, "store_id": store_id,
            "seller_id": seller_id, "user_id": seller["user_id"],
            "old_status": "WAITING_IN_QUEUE", "new_status": "WAITING_IN_QUEUE",
            "old_status_pt": "NA_FILA_GERAL", "new_status_pt": "EM_ATIVIDADE_OPERACIONAL",
            "reason": motivo_label, "changed_by": actor_user_id, "created_at": now,
        })
        await _emit_event(tenant_id, store_id, queue["id"], seller_id,
                          "SELLER_EM_ATIVIDADE_OPERACIONAL", actor_user_id, {"motivo": motivo})
        await log_audit(action="ATIVIDADE_OPERACIONAL", entity="seller_profile", entity_id=seller_id,
                        tenant_id=tenant_id, store_id=store_id, user_id=actor_user_id,
                        new_value={"motivo": motivo_label}, request=request)
    else:
        # Remove da fila
        deleted = await db.queue_entries.find_one_and_delete(
            {"tenant_id": tenant_id, "queue_id": queue["id"], "seller_id": seller_id, "status": "WAITING"}
        )
        if deleted is None:
            raise HTTPException(status_code=409, detail={
                "error": "TRANSICAO_DE_ESTADO_INVALIDA",
                "message": "Vendedor não está nesta Fila Geral.",
            })
        await recalculate_positions(tenant_id, queue["id"])

        novo_estado_interno = MOTIVO_PARA_ESTADO[motivo]  # "BREAK" ou "OFFLINE"
        await change_state(
            tenant_id=tenant_id, store_id=store_id, seller_id=seller_id,
            to_state=novo_estado_interno, actor_user_id=actor_user_id,
            actor_role=actor_role, reason=motivo_label,
            via_queue_engine=True, request=request,
        )

        extra_set: dict = {"motivo_saida": motivo, "updated_at": now}
        if motivo == "ENCERRAR_DIA":
            extra_set["jornada_encerrada"] = True
        await db.seller_profiles.update_one({"id": seller_id}, {"$set": extra_set})

        await _emit_event(tenant_id, store_id, queue["id"], seller_id,
                          "SELLER_SAIU_DA_FILA", actor_user_id, {"motivo": motivo_label})
        await log_audit(action="SAIR_DA_FILA", entity="queue_entry", entity_id=queue["id"],
                        tenant_id=tenant_id, store_id=store_id, user_id=actor_user_id,
                        new_value={"seller_id": seller_id, "motivo": motivo_label}, request=request)

    await _publish(tenant_id, store_id, queue["id"], [
        ("queue.seller_left", {"seller_id": seller_id, "motivo": motivo}),
        ("queue.updated", {}),
        ("dashboard.updated", {}),
    ])
    return await get_queue_state(tenant_id, store_id, queue["id"])


async def retornar_operacao(*, tenant_id, store_id, seller_id, actor_user_id, actor_role, request=None):
    """Remove o subestado EM_ATIVIDADE_OPERACIONAL — vendedor volta a receber chamadas na posição atual."""
    from state_machine import ESTADO_PARA_PT

    seller = await _get_seller(tenant_id, store_id, seller_id)
    if (seller.get("current_status") != "WAITING_IN_QUEUE"
            or not seller.get("em_atividade_operacional")):
        raise HTTPException(status_code=409, detail={
            "error": "TRANSICAO_DE_ESTADO_INVALIDA",
            "message": "Vendedor não está em Atividade Operacional.",
        })

    now = utcnow_iso()
    await db.seller_profiles.update_one(
        {"id": seller_id},
        {"$set": {"em_atividade_operacional": False, "motivo_saida": None, "updated_at": now}},
    )
    await db.seller_status_logs.insert_one({
        "id": new_id(), "tenant_id": tenant_id, "store_id": store_id,
        "seller_id": seller_id, "user_id": seller["user_id"],
        "old_status": "WAITING_IN_QUEUE", "new_status": "WAITING_IN_QUEUE",
        "old_status_pt": "EM_ATIVIDADE_OPERACIONAL", "new_status_pt": "NA_FILA_GERAL",
        "reason": "Retornou à operação", "changed_by": actor_user_id, "created_at": now,
    })
    queue = await ensure_default_queue(tenant_id, store_id)
    await _emit_event(tenant_id, store_id, queue["id"], seller_id,
                      "SELLER_RETORNOU_OPERACAO", actor_user_id)
    await log_audit(action="RETORNOU_OPERACAO", entity="seller_profile", entity_id=seller_id,
                    tenant_id=tenant_id, store_id=store_id, user_id=actor_user_id, request=request)
    await _publish(tenant_id, store_id, queue["id"], [
        ("seller.status_changed", {"seller_id": seller_id}),
        ("queue.updated", {}),
    ])
    return await get_queue_state(tenant_id, store_id, queue["id"])


async def nova_jornada(*, tenant_id, store_id, seller_id, actor_user_id, actor_role, request=None):
    """Inicia nova jornada para vendedor que encerrou o dia — volta a Disponível (DISPONIVEL)."""
    seller = await _get_seller(tenant_id, store_id, seller_id)
    if not seller.get("jornada_encerrada"):
        raise HTTPException(status_code=409, detail={
            "error": "TRANSICAO_DE_ESTADO_INVALIDA",
            "message": "A jornada do vendedor não foi encerrada. Não é necessário iniciar uma nova jornada.",
        })

    now = utcnow_iso()
    # Reset flags e muda para AVAILABLE (Disponível)
    await db.seller_profiles.update_one(
        {"id": seller_id},
        {"$set": {
            "jornada_encerrada": False,
            "em_atividade_operacional": False,
            "motivo_saida": None,
            "current_status": "AVAILABLE",
            "updated_at": now,
        }},
    )
    await db.seller_status_logs.insert_one({
        "id": new_id(), "tenant_id": tenant_id, "store_id": store_id,
        "seller_id": seller_id, "user_id": seller["user_id"],
        "old_status": seller.get("current_status", "OFFLINE"),
        "new_status": "AVAILABLE",
        "old_status_pt": "FORA", "new_status_pt": "DISPONIVEL",
        "reason": "Nova jornada iniciada", "changed_by": actor_user_id, "created_at": now,
    })
    queue = await ensure_default_queue(tenant_id, store_id)
    await _emit_event(tenant_id, store_id, queue["id"], seller_id,
                      "SELLER_NOVA_JORNADA", actor_user_id)
    await log_audit(action="NOVA_JORNADA", entity="seller_profile", entity_id=seller_id,
                    tenant_id=tenant_id, store_id=store_id, user_id=actor_user_id, request=request)
    await _publish(tenant_id, store_id, queue["id"], [
        ("seller.status_changed", {"seller_id": seller_id}),
        ("queue.updated", {}),
        ("dashboard.updated", {}),
    ])
    return await get_queue_state(tenant_id, store_id, queue["id"])


async def retornar_da_fora(*, tenant_id, store_id, seller_id, actor_user_id, actor_role,
                           queue_id=None, request=None):
    """Retorna vendedor do estado Fora (almoço/lanche) para o final da Fila Geral."""
    from state_machine import AWAY_STATES as SM_AWAY, ESTADO_PARA_PT

    seller = await _get_seller(tenant_id, store_id, seller_id)
    current = seller.get("current_status")

    if current not in SM_AWAY:
        raise HTTPException(status_code=409, detail={
            "error": "TRANSICAO_DE_ESTADO_INVALIDA",
            "message": "Vendedor não está no estado Fora.",
            "estado_atual": ESTADO_PARA_PT.get(current, current),
        })

    # Bloquear retorno após encerramento do dia
    if seller.get("jornada_encerrada"):
        raise HTTPException(status_code=409, detail={
            "error": "JORNADA_ENCERRADA",
            "message": "A jornada foi encerrada. Inicie uma nova jornada para voltar a operar.",
        })

    queue = await _resolve_queue(tenant_id, store_id, queue_id)
    now = utcnow_iso()

    # AVAILABLE → WAITING_IN_QUEUE (dois passos internamente)
    await change_state(tenant_id=tenant_id, store_id=store_id, seller_id=seller_id,
                       to_state="AVAILABLE", actor_user_id=actor_user_id, actor_role=actor_role,
                       reason="Retorno da pausa", via_queue_engine=True, request=request)
    await change_state(tenant_id=tenant_id, store_id=store_id, seller_id=seller_id,
                       to_state="WAITING_IN_QUEUE", actor_user_id=actor_user_id, actor_role=actor_role,
                       via_queue_engine=True, request=request)

    # Limpa flags
    await db.seller_profiles.update_one(
        {"id": seller_id},
        {"$set": {"motivo_saida": None, "em_atividade_operacional": False, "updated_at": now}},
    )

    # Insere no final da fila
    seller_updated = await db.seller_profiles.find_one({"id": seller_id})
    existing = await db.queue_entries.find_one(
        {"tenant_id": tenant_id, "queue_id": queue["id"], "seller_id": seller_id, "status": "WAITING"}
    )
    if not existing:
        await _insert_at_end(tenant_id, store_id, queue["id"], seller_updated)
        await recalculate_positions(tenant_id, queue["id"])

    await _emit_event(tenant_id, store_id, queue["id"], seller_id,
                      "SELLER_RETURNED_TO_END", actor_user_id, {"from": current})
    await log_audit(action="RETORNAR_DA_FORA", entity="queue_entry", entity_id=queue["id"],
                    tenant_id=tenant_id, store_id=store_id, user_id=actor_user_id,
                    new_value={"seller_id": seller_id}, request=request)
    await _publish(tenant_id, store_id, queue["id"], [
        ("queue.seller_joined", {"seller_id": seller_id}),
        ("queue.updated", {}),
        ("dashboard.updated", {}),
    ])
    return await get_queue_state(tenant_id, store_id, queue["id"])


async def start_attendance(*, tenant_id, store_id, queue_id, seller_id, actor_user_id, actor_role,
                           source="WALK_IN", customer_name=None, customer_phone=None, notes=None, request=None):
    # P1: lock de concorrência para evitar dois atendimentos simultâneos
    async with seller_lock(tenant_id, seller_id, "START_ATTENDANCE"):
        queue = await _resolve_queue(tenant_id, store_id, queue_id)
        seller = await _get_seller(tenant_id, store_id, seller_id)
        if seller.get("current_status") != "WAITING_IN_QUEUE":
            raise HTTPException(status_code=409, detail={
                "error": "TRANSICAO_DE_ESTADO_INVALIDA",
                "message": "Vendedor precisa estar na Fila Geral para iniciar atendimento.",
            })
        # Bloquear se vendedor estiver em Atividade Operacional
        if seller.get("em_atividade_operacional"):
            raise HTTPException(status_code=409, detail={
                "error": "EM_ATIVIDADE_OPERACIONAL",
                "message": "Vendedor está em Atividade Operacional e não pode receber atendimento. Aguarde o retorno.",
            })
        # Verificação atômica via MongoDB — evita race condition com find_one_and_update
        in_progress = await db.attendances.find_one(
            {"tenant_id": tenant_id, "seller_id": seller_id, "status": "IN_PROGRESS"}
        )
        if in_progress:
            raise HTTPException(status_code=409, detail={
                "error": "ATENDIMENTO_EM_ABERTO",
                "message": "Vendedor já possui um atendimento em andamento.",
            })
        is_manager = actor_role in {"TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER"}
        if not is_manager:
            entry = await db.queue_entries.find_one(
                {"tenant_id": tenant_id, "queue_id": queue["id"], "seller_id": seller_id, "status": "WAITING"}
            )
            if not entry:
                raise HTTPException(status_code=409, detail={"error": "SELLER_NOT_FIRST_IN_QUEUE", "message": "Este vendedor não é o próximo da Lista da Vez."})
            if entry.get("position") != 1:
                earlier_entries = await db.queue_entries.find(
                    {
                        "tenant_id": tenant_id,
                        "queue_id": queue["id"],
                        "status": "WAITING",
                        "position": {"$lt": entry.get("position")},
                    }
                ).sort("position", 1).to_list(1000)
                earlier_seller_ids = [earlier["seller_id"] for earlier in earlier_entries]
                active_seller_before = await db.seller_profiles.find_one({
                    "tenant_id": tenant_id,
                    "id": {"$in": earlier_seller_ids},
                    "$or": [
                        {"em_atividade_operacional": {"$ne": True}},
                        {"em_atividade_operacional": {"$exists": False}},
                    ],
                }) if earlier_seller_ids else None
                if active_seller_before:
                    raise HTTPException(status_code=409, detail={"error": "SELLER_NOT_FIRST_IN_QUEUE", "message": "Este vendedor não é o próximo da Lista da Vez."})
        # Remoção atômica do queue_entry (find_one_and_delete evita race condition)
        claimed = await db.queue_entries.find_one_and_delete(
            {"tenant_id": tenant_id, "queue_id": queue["id"], "seller_id": seller_id, "status": "WAITING"}
        )
        if not claimed:
            _conflict()
        await recalculate_positions(tenant_id, queue["id"])
        await change_state(tenant_id=tenant_id, store_id=store_id, seller_id=seller_id, to_state="SERVING",
                           actor_user_id=actor_user_id, actor_role=actor_role, via_queue_engine=True, request=request)
        now = utcnow_iso()
        visit_id = new_id()
        await db.customer_visits.insert_one({
            "id": visit_id, "tenant_id": tenant_id, "store_id": store_id, "queue_id": queue["id"],
            "seller_id": seller_id, "customer_name": customer_name, "customer_phone": customer_phone,
            "source": source or "WALK_IN", "arrival_time": now, "start_time": now, "end_time": None,
            "status": "IN_PROGRESS", "notes": notes, "created_at": now, "updated_at": now,
        })
        att_id = new_id()
        att = {
            "id": att_id, "tenant_id": tenant_id, "store_id": store_id, "queue_id": queue["id"],
            "customer_visit_id": visit_id, "seller_id": seller_id, "started_at": now, "finished_at": None,
            "status": "IN_PROGRESS",
            "source": "QUEUE",
            "origin": "MANUAL" if source == "MANUAL" else "QUEUE",
            "result": None, "sale_amount_cents": None, "loss_reason_id": None, "notes": notes,
            "created_by": actor_user_id, "created_at": now, "updated_at": now,
        }
        await db.attendances.insert_one(att)
        await _emit_event(tenant_id, store_id, queue["id"], seller_id, "ATTENDANCE_STARTED", actor_user_id, {"attendance_id": att_id})
        await log_audit(action="ATTENDANCE_STARTED", entity="attendance", entity_id=att_id,
                        tenant_id=tenant_id, store_id=store_id, user_id=actor_user_id,
                        new_value={"seller_id": seller_id}, request=request)
        att.pop("_id", None)
    await _publish(tenant_id, store_id, queue["id"], [
        ("attendance.started", {"attendance_id": att["id"], "seller_id": seller_id}),
        ("seller.status_changed", {"seller_id": seller_id, "status": "SERVING"}),
        ("queue.updated", {}),
        ("dashboard.updated", {}),
    ])
    return {"attendance": att, "state": await get_queue_state(tenant_id, store_id, queue["id"])}


async def start_preference_attendance(*, tenant_id, store_id, queue_id, seller_id, customer_name,
                                      customer_phone=None, notes=None, actor_user_id=None,
                                      actor_role=None, request=None):
    if not (customer_name and customer_name.strip()):
        raise HTTPException(status_code=400, detail="Informe o nome do cliente para Atendimento por Preferência.")
    async with seller_lock(tenant_id, seller_id, "START_PREFERENCE_ATTENDANCE"):
        queue = await _resolve_queue(tenant_id, store_id, queue_id)
        effective_settings = {**_queue_settings(queue), **(await _store_queue_settings(tenant_id, store_id))}
        if effective_settings.get("preference_enabled") is False:
            raise HTTPException(status_code=403, detail={"error": "PREFERENCE_DISABLED", "message": "Atendimento por preferência desabilitado nesta unidade."})
        if queue.get("status") != "ACTIVE":
            raise HTTPException(status_code=409, detail="Esta fila está inativa.")
        seller = await _get_seller(tenant_id, store_id, seller_id)
        if seller.get("status") != "ACTIVE":
            raise HTTPException(status_code=409, detail="Vendedor inativo não pode receber atendimento por preferência.")
        if seller.get("em_atividade_operacional"):
            raise HTTPException(status_code=409, detail={"error": "VENDEDOR_EM_PAUSA", "message": "O vendedor está em Atividade Operacional."})
        if seller.get("jornada_encerrada"):
            raise HTTPException(status_code=409, detail={"error": "JORNADA_ENCERRADA", "message": "O vendedor não participa da jornada atual."})
        in_progress = await db.attendances.find_one({"tenant_id": tenant_id, "seller_id": seller_id, "status": "IN_PROGRESS"}, {"_id": 0})
        if in_progress:
            raise HTTPException(status_code=409, detail={"error": "ATENDIMENTO_EM_ABERTO", "message": "O vendedor já está em atendimento."})

        entries = await db.queue_entries.find({"tenant_id": tenant_id, "queue_id": queue["id"], "status": "WAITING"}, {"_id": 0}).sort("position", 1).to_list(1000)
        idx = next((i for i, e in enumerate(entries) if e.get("seller_id") == seller_id), None)
        if idx is None:
            raise HTTPException(status_code=409, detail={"error": "VENDEDOR_FORA_DA_FILA", "message": "O vendedor não participa da Fila Geral atual."})
        if seller.get("current_status") != "WAITING_IN_QUEUE":
            if seller.get("current_status") == "AVAILABLE":
                await db.seller_profiles.update_one({"id": seller_id}, {"$set": {"current_status": "WAITING_IN_QUEUE", "updated_at": utcnow_iso()}})
                seller["current_status"] = "WAITING_IN_QUEUE"
            else:
                raise HTTPException(status_code=409, detail={"error": "VENDEDOR_INDISPONIVEL", "message": "O vendedor precisa estar na Fila Geral para receber Atendimento por Preferência."})
        entry = entries[idx]
        snapshot = {
            "previous_position": entry.get("position"),
            "previous_member_id": entries[idx - 1]["seller_id"] if idx > 0 else None,
            "next_member_id": entries[idx + 1]["seller_id"] if idx + 1 < len(entries) else None,
            "queue_size_at_start": len(entries),
            "queue_version_at_start": queue.get("version"),
            "queue_id": queue["id"],
            "store_id": store_id,
            "started_snapshot_at": utcnow_iso(),
        }
        rule = await _preference_rule(tenant_id, store_id, queue)
        claimed = await db.queue_entries.find_one_and_delete({"tenant_id": tenant_id, "queue_id": queue["id"], "seller_id": seller_id, "status": "WAITING"})
        if not claimed:
            _conflict()
        await recalculate_positions(tenant_id, queue["id"])
        await db.queues.update_one({"id": queue["id"]}, {"$inc": {"version": 1}, "$set": {"updated_at": utcnow_iso()}})
        await change_state(tenant_id=tenant_id, store_id=store_id, seller_id=seller_id, to_state="SERVING",
                           actor_user_id=actor_user_id, actor_role=actor_role, via_queue_engine=True, request=request)
        now = utcnow_iso()
        visit_id = new_id()
        await db.customer_visits.insert_one({
            "id": visit_id, "tenant_id": tenant_id, "store_id": store_id, "queue_id": queue["id"],
            "seller_id": seller_id, "customer_name": customer_name.strip(), "customer_phone": customer_phone,
            "source": "PREFERENCE", "arrival_time": now, "start_time": now, "end_time": None,
            "status": "IN_PROGRESS", "notes": notes, "created_at": now, "updated_at": now,
        })
        att_id = new_id()
        att = {
            "id": att_id, "tenant_id": tenant_id, "store_id": store_id, "queue_id": queue["id"],
            "customer_visit_id": visit_id, "seller_id": seller_id, "started_at": now, "finished_at": None,
            "status": "IN_PROGRESS", "source": "PREFERENCE", "origin": "PREFERENCE", "attendance_type": "PREFERENCE",
            "is_preference": True, "preference_customer_name": customer_name.strip(), "preference_customer_phone": customer_phone,
            "preference_started_by": actor_user_id, "preference_queue_snapshot": snapshot,
            "preference_previous_position": snapshot["previous_position"],
            "preference_previous_member_id": snapshot["previous_member_id"],
            "preference_next_member_id": snapshot["next_member_id"],
            "preference_queue_version_at_start": snapshot["queue_version_at_start"],
            "preference_return_rule": rule, "preference_return_applied": False,
            "preference_turn_consumed": False, "result": None, "sale_amount_cents": None,
            "loss_reason_id": None, "notes": notes, "created_by": actor_user_id,
            "created_at": now, "updated_at": now,
        }
        await db.attendances.insert_one(att)
        await _emit_event(tenant_id, store_id, queue["id"], seller_id, "PREFERENCE_ATTENDANCE_STARTED", actor_user_id, {"attendance_id": att_id, "rule": rule, "snapshot": snapshot})
        await log_audit(action="PREFERENCE_ATTENDANCE_STARTED", entity="attendance", entity_id=att_id,
                        tenant_id=tenant_id, store_id=store_id, user_id=actor_user_id,
                        new_value={"seller_id": seller_id, "customer_name": customer_name.strip(), "return_rule": rule, "snapshot": snapshot}, request=request)
        att.pop("_id", None)
    await _publish(tenant_id, store_id, queue["id"], [
        ("attendance.preference_started", {"attendance_id": att["id"], "seller_id": seller_id, "return_rule": rule}),
        ("seller.status_changed", {"seller_id": seller_id, "status": "SERVING"}),
        ("queue.updated", {}),
        ("dashboard.updated", {}),
    ])
    return {"attendance": att, "state": await get_queue_state(tenant_id, store_id, queue["id"])}


async def finish_attendance(*, tenant_id, store_id, attendance_id, result, sale_amount_cents=None,
                            loss_reason_id=None, notes=None, sale=None, product_quantity=None,
                            grupo_motivo_perda_id=None, subgrupo_motivo_perda_id=None,
                            motivo_perda_id=None, descricao_complementar=None,
                            actor_user_id, actor_role, request=None):
    att = await db.attendances.find_one({"tenant_id": tenant_id, "id": attendance_id})
    if not att:
        raise HTTPException(status_code=404, detail="Atendimento não encontrado.")
    if att["store_id"] != store_id:
        raise HTTPException(status_code=404, detail="Atendimento não pertence a esta unidade.")

    # Trava por vendedor: evita que finish-attendance concorrentes (mesmo attendance_id)
    # criem vendas duplicadas antes da transição atômica de status abaixo.
    async with seller_lock(tenant_id, att["seller_id"], "FINISH_ATTENDANCE"):
        att = await db.attendances.find_one({"tenant_id": tenant_id, "id": attendance_id})
        if not att or att["status"] != "IN_PROGRESS":
            raise HTTPException(status_code=409, detail="Atendimento não está em andamento.")
        queue = await _resolve_queue(tenant_id, store_id, att.get("queue_id"))
        settings = _queue_settings(queue)

        detailed_enabled = await is_enabled(tenant_id, "vendas_detalhadas")
        # Usa modo detalhado sempre que `sale` for fornecido (mesmo sem itens ou valor),
        # pois o objeto `sale` indica que o usuário quer registrar na aba Vendas.
        use_detailed = bool(result == "SALE" and sale is not None and detailed_enabled)

        if result == "SALE" and not use_detailed and settings.get("require_sale_amount", True):
            if sale_amount_cents is None or sale_amount_cents <= 0:
                raise HTTPException(status_code=400, detail="Informe o valor da venda.")
        classificacao_perda = None
        if result == "NO_SALE" and settings.get("require_loss_reason", True):
            if await motivos_perda_service.hierarquia_ativa_existe(tenant_id):
                classificacao_perda = await motivos_perda_service.validar_combinação_para_atendimento(
                    empresa_id=tenant_id,
                    grupo_motivo_perda_id=grupo_motivo_perda_id,
                    subgrupo_motivo_perda_id=subgrupo_motivo_perda_id,
                    motivo_perda_id=motivo_perda_id,
                    descricao_complementar=descricao_complementar,
                )
                loss_reason_id = None
            elif not loss_reason_id:
                raise HTTPException(status_code=400, detail="Informe o motivo da não venda.")
        if result == "INVALID":
            if not settings.get("allow_invalid_attendance", True):
                raise HTTPException(status_code=400, detail="Atendimento inválido não é permitido nas configurações.")
            if not (notes and notes.strip()):
                raise HTTPException(status_code=400, detail="Justificativa é obrigatória para atendimento inválido.")
        if loss_reason_id:
            lr = await db.loss_reasons.find_one({"tenant_id": tenant_id, "id": loss_reason_id})
            if not lr:
                raise HTTPException(status_code=404, detail="Motivo de perda não encontrado.")

        created_sale = None
        final_amount_cents = None
        if result == "SALE":
            if use_detailed:
                # Se não há itens nem gross_amount_cents mas sale_amount_cents foi passado,
                # usa sale_amount_cents como gross_amount_cents para o registro da venda.
                effective_sale = sale if isinstance(sale, dict) else (sale.model_dump() if hasattr(sale, "model_dump") else (sale.dict() if hasattr(sale, "dict") else {}))
                if not (effective_sale.get("items") or effective_sale.get("gross_amount_cents")) and sale_amount_cents:
                    effective_sale = {**effective_sale, "gross_amount_cents": sale_amount_cents}
                created_sale = await sales_service.create_sale(
                    tenant_id=tenant_id, store_id=store_id, attendance_id=attendance_id,
                    seller_id=att["seller_id"], customer_visit_id=att.get("customer_visit_id"),
                    sale=effective_sale, actor_user_id=actor_user_id,
                )
                final_amount_cents = created_sale["net_amount_cents"] or sale_amount_cents
            else:
                # Modo simples: sempre registrar a venda na aba Vendas, sem itens detalhados
                simple_sale = SaleInput(gross_amount_cents=sale_amount_cents or 0)
                created_sale = await sales_service.create_sale(
                    tenant_id=tenant_id, store_id=store_id, attendance_id=attendance_id,
                    seller_id=att["seller_id"], customer_visit_id=att.get("customer_visit_id"),
                    sale=simple_sale.model_dump(), actor_user_id=actor_user_id,
                )
                final_amount_cents = sale_amount_cents

        now = utcnow_iso()
        finished = await db.attendances.find_one_and_update(
            {"id": attendance_id, "status": "IN_PROGRESS"},
            {"$set": {
                "status": "FINISHED", "result": result,
                "sale_amount_cents": final_amount_cents if result == "SALE" else None,
                "sale_id": created_sale["id"] if created_sale else None,
                "loss_reason_id": loss_reason_id, "notes": notes,
                "grupo_motivo_perda_id": classificacao_perda["grupo"]["identificador"] if classificacao_perda else None,
                "subgrupo_motivo_perda_id": classificacao_perda["subgrupo"]["identificador"] if classificacao_perda else None,
                "motivo_perda_id": classificacao_perda["motivo"]["identificador"] if classificacao_perda else None,
                "grupo_motivo_perda_nome_historico": classificacao_perda["grupo"]["nome"] if classificacao_perda else None,
                "subgrupo_motivo_perda_nome_historico": classificacao_perda["subgrupo"]["nome"] if classificacao_perda else None,
                "motivo_perda_nome_historico": classificacao_perda["motivo"]["nome"] if classificacao_perda else None,
                "descricao_complementar": classificacao_perda["descricao_complementar"] if classificacao_perda else None,
                "product_quantity": product_quantity if result == "SALE" else None,
                "finished_at": now, "updated_at": now,
            }},
            return_document=ReturnDocument.AFTER,
        )
        if not finished:
            _conflict()

    visit_status = {"SALE": "CONVERTED", "NO_SALE": "LOST", "FOLLOW_UP": "ABANDONED", "INVALID": "INVALID"}.get(result, "LOST")
    if att.get("customer_visit_id"):
        await db.customer_visits.update_one(
            {"id": att["customer_visit_id"]},
            {"$set": {"status": visit_status, "end_time": now, "updated_at": now}},
        )

    seller_id = att["seller_id"]
    seller = await db.seller_profiles.find_one({"tenant_id": tenant_id, "id": seller_id})
    if seller and seller.get("current_status") == "SERVING":
        await change_state(tenant_id=tenant_id, store_id=store_id, seller_id=seller_id, to_state="AVAILABLE",
                           actor_user_id=actor_user_id, actor_role=actor_role, via_queue_engine=True, request=request)
    await _emit_event(tenant_id, store_id, queue["id"], seller_id, "ATTENDANCE_FINISHED", actor_user_id, {"result": result})
    await log_audit(action="ATTENDANCE_FINISHED", entity="attendance", entity_id=attendance_id,
                    tenant_id=tenant_id, store_id=store_id, user_id=actor_user_id,
                    new_value={"result": result, "sale_amount_cents": finished.get("sale_amount_cents")}, request=request)

    if att.get("is_preference") and seller:
        finished = await _apply_preference_return(tenant_id=tenant_id, store_id=store_id, queue=queue,
                                                  attendance=finished, seller=seller,
                                                  actor_user_id=actor_user_id, actor_role=actor_role, request=request)
    elif settings.get("return_to_end_after_attendance", True) and seller and queue["status"] == "ACTIVE":
        await change_state(tenant_id=tenant_id, store_id=store_id, seller_id=seller_id, to_state="WAITING_IN_QUEUE",
                           actor_user_id=actor_user_id, actor_role=actor_role, via_queue_engine=True, request=request)
        await _insert_at_end(tenant_id, store_id, queue["id"], seller)
        await recalculate_positions(tenant_id, queue["id"])
        await _emit_event(tenant_id, store_id, queue["id"], seller_id, "SELLER_RETURNED_TO_END", actor_user_id)

    finished.pop("_id", None)
    events = [
        ("attendance.finished", {"attendance_id": attendance_id, "result": result}),
        ("seller.status_changed", {"seller_id": seller_id}),
        ("queue.updated", {}),
        ("dashboard.updated", {}),
    ]
    if created_sale:
        events.append(("sale.created", {
            "sale_id": created_sale["id"], "attendance_id": attendance_id,
            "seller_id": seller_id, "net_amount_cents": created_sale["net_amount_cents"],
        }))
    await _publish(tenant_id, store_id, queue["id"], events)
    # Recalcular metas ativas (silencioso — não bloqueia o fluxo)
    await goals_service.recalculate_active_goals(tenant_id, store_id=store_id, seller_id=seller_id)
    # Avaliar conquistas ativas (silencioso — fire-and-forget)
    try:
        import achievement_service as _ach_svc
        await _ach_svc.evaluate_active_achievements(tenant_id, seller_id, store_id)
    except Exception:
        pass

    # ── Sincronizar status da abordagem proativa vinculada ──
    if att.get("proactive_approach_id"):
        approach_status_map = {
            "SALE": "CONVERTED_TO_SALE",
            "NO_SALE": "NO_SALE",
            "INVALID": "CANCELLED",
        }
        new_approach_status = approach_status_map.get(result)
        if new_approach_status:
            try:
                await db.proactive_approaches.update_one(
                    {"id": att["proactive_approach_id"], "tenant_id": tenant_id},
                    {"$set": {"status": new_approach_status, "closed_at": now, "updated_at": now}},
                )
            except Exception:
                pass

    return {"attendance": finished, "sale": created_sale, "state": await get_queue_state(tenant_id, store_id, queue["id"])}


async def _validate_loss_for_multiple(tenant_id: str, common: dict) -> dict | None:
    if await motivos_perda_service.hierarquia_ativa_existe(tenant_id):
        return await motivos_perda_service.validar_combinação_para_atendimento(
            empresa_id=tenant_id,
            grupo_motivo_perda_id=common.get("grupo_motivo_perda_id"),
            subgrupo_motivo_perda_id=common.get("subgrupo_motivo_perda_id"),
            motivo_perda_id=common.get("motivo_perda_id"),
            descricao_complementar=common.get("descricao_complementar"),
        )
    if not common.get("loss_reason_id"):
        raise HTTPException(status_code=400, detail="Informe o motivo comum dos atendimentos sem sucesso.")
    lr = await db.loss_reasons.find_one({"tenant_id": tenant_id, "id": common.get("loss_reason_id")}, {"_id": 0})
    if not lr:
        raise HTTPException(status_code=404, detail="Motivo de perda não encontrado.")
    return None


async def finish_multiple_attendances(*, tenant_id, store_id, payload: dict, actor_user_id, actor_role, request=None):
    first = await db.attendances.find_one({"tenant_id": tenant_id, "store_id": store_id, "id": payload.get("attendance_id"), "status": "IN_PROGRESS"}, {"_id": 0})
    if not first:
        raise HTTPException(status_code=404, detail="Atendimento ativo não encontrado para lançamento múltiplo.")
    seller_id = first["seller_id"]
    async with seller_lock(tenant_id, seller_id, "FINISH_MULTIPLE_ATTENDANCES"):
        first = await db.attendances.find_one({"tenant_id": tenant_id, "store_id": store_id, "id": payload.get("attendance_id"), "status": "IN_PROGRESS"}, {"_id": 0})
        if not first:
            _conflict()
        queue = await _resolve_queue(tenant_id, store_id, first.get("queue_id")) if first.get("queue_id") else await ensure_default_queue(tenant_id, store_id)
        seller = await db.seller_profiles.find_one({"tenant_id": tenant_id, "id": seller_id}, {"_id": 0})
        rows = _build_multiple_rows(payload)
        no_sale_rows = [r for r in rows if r["result"] == "NO_SALE"]
        common_loss = await _validate_loss_for_multiple(tenant_id, payload) if no_sale_rows else None
        sale_rows = [r for r in rows if r["result"] == "SALE"]
        total_amount = sum(r.get("sale_amount_cents") or 0 for r in sale_rows)
        total_products = sum(r.get("product_quantity") or 0 for r in sale_rows)
        batch_id = new_id()
        now = utcnow_iso()
        batch_doc = {
            "id": batch_id, "tenant_id": tenant_id, "store_id": store_id, "queue_id": first.get("queue_id"),
            "seller_id": seller_id, "mode": payload.get("mode"), "total_customers": len(rows),
            "total_successes": len(sale_rows), "total_no_sales": len(no_sale_rows),
            "total_amount_cents": total_amount, "total_product_quantity": total_products,
            "notes": payload.get("notes"), "status": "PENDING", "created_by": actor_user_id,
            "idempotency_key": request.headers.get("Idempotency-Key") if request else None,
            "allocation_mode": "AGGREGATED" if payload.get("mode") == "AGGREGATED" else "DETAILED",
            "allocation_method": "EQUAL_WITH_REMAINDER" if payload.get("mode") == "AGGREGATED" else "INDIVIDUAL",
            "created_at": now, "updated_at": now,
        }
        await db.multiple_attendance_batches.insert_one(batch_doc)
        created_attendances, created_sales = [], []
        try:
            for idx, row in enumerate(rows, 1):
                is_first = idx == 1
                result = row["result"]
                visit_id = first.get("customer_visit_id") if is_first else new_id()
                att_id = first["id"] if is_first else new_id()
                if not is_first:
                    await db.customer_visits.insert_one({
                        "id": visit_id, "tenant_id": tenant_id, "store_id": store_id, "queue_id": first.get("queue_id"),
                        "seller_id": seller_id, "customer_name": row.get("customer_name"), "customer_phone": row.get("customer_phone"),
                        "source": batch_doc["allocation_mode"], "arrival_time": first.get("started_at") or now,
                        "start_time": first.get("started_at") or now, "end_time": now,
                        "status": "CONVERTED" if result == "SALE" else "LOST", "notes": row.get("notes") or payload.get("notes"),
                        "created_at": now, "updated_at": now,
                    })
                fields = {
                    "multiple_batch_id": batch_id, "multiple_sequence": idx, "is_multiple": True,
                    "multiple_mode": payload.get("mode"), "allocation_mode": batch_doc["allocation_mode"],
                    "allocation_method": batch_doc["allocation_method"], "is_estimated_allocation": payload.get("mode") == "AGGREGATED",
                    "status": "FINISHED", "result": result, "finished_at": now, "updated_at": now,
                    "source": "MULTIPLE_AGGREGATED" if payload.get("mode") == "AGGREGATED" else "MULTIPLE_DETAILED",
                    "origin": "MULTIPLE_AGGREGATED" if payload.get("mode") == "AGGREGATED" else "MULTIPLE_DETAILED",
                    "attendance_type": "MULTIPLE", "notes": row.get("notes") or payload.get("notes"),
                    "product_quantity": row.get("product_quantity") if result == "SALE" else 0,
                    "sale_amount_cents": row.get("sale_amount_cents") if result == "SALE" else None,
                    "loss_reason_id": payload.get("loss_reason_id") if result == "NO_SALE" else None,
                }
                if result == "NO_SALE" and common_loss:
                    fields.update({
                        "grupo_motivo_perda_id": common_loss["grupo"]["identificador"],
                        "subgrupo_motivo_perda_id": common_loss["subgrupo"]["identificador"],
                        "motivo_perda_id": common_loss["motivo"]["identificador"],
                        "grupo_motivo_perda_nome_historico": common_loss["grupo"]["nome"],
                        "subgrupo_motivo_perda_nome_historico": common_loss["subgrupo"]["nome"],
                        "motivo_perda_nome_historico": common_loss["motivo"]["nome"],
                        "descricao_complementar": common_loss["descricao_complementar"],
                    })
                if is_first:
                    att_doc = await db.attendances.find_one_and_update({"id": first["id"], "status": "IN_PROGRESS"}, {"$set": fields}, return_document=ReturnDocument.AFTER)
                    att_doc.pop("_id", None)
                    if first.get("customer_visit_id"):
                        await db.customer_visits.update_one({"id": first["customer_visit_id"]}, {"$set": {"status": "CONVERTED" if result == "SALE" else "LOST", "end_time": now, "updated_at": now}})
                else:
                    att_doc = {"id": att_id, "tenant_id": tenant_id, "store_id": store_id, "queue_id": first.get("queue_id"), "customer_visit_id": visit_id, "seller_id": seller_id, "started_at": first.get("started_at") or now, "created_at": now, "created_by": actor_user_id, **fields}
                    await db.attendances.insert_one(att_doc)
                if result == "SALE":
                    sale_doc = await sales_service.create_sale(tenant_id=tenant_id, store_id=store_id, attendance_id=att_id, seller_id=seller_id, customer_visit_id=visit_id, sale={"gross_amount_cents": row.get("sale_amount_cents") or 0, "notes": "Venda de atendimento múltiplo"}, actor_user_id=actor_user_id)
                    sale_doc.pop("_id", None)
                    await db.sales.update_one({"id": sale_doc["id"]}, {"$set": {"item_count": row.get("product_quantity") or 0, "multiple_batch_id": batch_id, "allocation_mode": batch_doc["allocation_mode"], "allocation_method": batch_doc["allocation_method"], "is_estimated_allocation": payload.get("mode") == "AGGREGATED"}})
                    await db.attendances.update_one({"id": att_id}, {"$set": {"sale_id": sale_doc["id"]}})
                    sale_doc["item_count"] = row.get("product_quantity") or 0
                    att_doc["sale_id"] = sale_doc["id"]
                    created_sales.append(sale_doc)
                created_attendances.append(att_doc)
            if seller and seller.get("current_status") == "SERVING":
                await change_state(tenant_id=tenant_id, store_id=store_id, seller_id=seller_id, to_state="AVAILABLE", actor_user_id=actor_user_id, actor_role=actor_role, via_queue_engine=True, request=request)
            if queue.get("status") == "ACTIVE" and _queue_settings(queue).get("return_to_end_after_attendance", True):
                seller_current = await db.seller_profiles.find_one({"tenant_id": tenant_id, "id": seller_id})
                await change_state(tenant_id=tenant_id, store_id=store_id, seller_id=seller_id, to_state="WAITING_IN_QUEUE", actor_user_id=actor_user_id, actor_role=actor_role, via_queue_engine=True, request=request)
                await _insert_at_end(tenant_id, store_id, queue["id"], seller_current)
                await recalculate_positions(tenant_id, queue["id"])
            await db.multiple_attendance_batches.update_one({"id": batch_id}, {"$set": {"status": "COMMITTED", "committed_at": utcnow_iso(), "updated_at": utcnow_iso()}})
        except Exception as exc:
            await db.multiple_attendance_batches.update_one({"id": batch_id}, {"$set": {"status": "FAILED", "failure_reason": str(exc), "updated_at": utcnow_iso()}})
            raise
        await _emit_event(tenant_id, store_id, queue["id"], seller_id, "MULTIPLE_ATTENDANCES_COMMITTED", actor_user_id, {"batch_id": batch_id, "total_customers": len(rows)})
        await log_audit(action="MULTIPLE_ATTENDANCES_COMMITTED", entity="multiple_attendance_batch", entity_id=batch_id, tenant_id=tenant_id, store_id=store_id, user_id=actor_user_id, new_value={"total_customers": len(rows), "successes": len(sale_rows), "no_sales": len(no_sale_rows), "total_amount_cents": total_amount}, request=request)
        await goals_service.recalculate_active_goals(tenant_id, store_id=store_id, seller_id=seller_id)
        await _publish(tenant_id, store_id, queue["id"], [("attendance.multiple_committed", {"batch_id": batch_id, "seller_id": seller_id, "total_customers": len(rows)}), ("queue.updated", {}), ("dashboard.updated", {}), ("sales.updated", {})])
        try:
            import achievement_service as _ach_svc
            await _ach_svc.evaluate_active_achievements(tenant_id, seller_id, store_id)
        except Exception:
            pass
        batch_doc.pop("_id", None)
        return _strip_mongo_ids({"batch": {**batch_doc, "status": "COMMITTED"}, "attendances": created_attendances, "sales": created_sales, "state": await get_queue_state(tenant_id, store_id, queue["id"])})


async def reorder_queue(*, tenant_id, store_id, queue_id, ordered_seller_ids, actor_user_id, actor_role, request=None):
    queue = await _resolve_queue(tenant_id, store_id, queue_id)
    if not _queue_settings(queue).get("allow_manager_reorder", True):
        raise HTTPException(status_code=403, detail="Reordenação não permitida nas configurações da fila.")
    current = await db.queue_entries.find(
        {"tenant_id": tenant_id, "queue_id": queue["id"], "status": "WAITING"}
    ).to_list(1000)
    current_ids = {e["seller_id"] for e in current}
    if set(ordered_seller_ids) != current_ids or len(ordered_seller_ids) != len(current):
        raise HTTPException(status_code=400, detail="A lista enviada deve conter exatamente os vendedores aguardando na fila.")
    now = utcnow_iso()
    for i, sid in enumerate(ordered_seller_ids, start=1):
        await db.queue_entries.update_one(
            {"tenant_id": tenant_id, "queue_id": queue["id"], "seller_id": sid, "status": "WAITING"},
            {"$set": {"position": i, "updated_at": now}},
        )
    await db.queues.update_one({"id": queue["id"]}, {"$inc": {"version": 1}, "$set": {"updated_at": now}})
    await _emit_event(tenant_id, store_id, queue["id"], None, "QUEUE_REORDERED", actor_user_id, {"order": ordered_seller_ids})
    await log_audit(action="QUEUE_REORDERED", entity="queue", entity_id=queue["id"],
                    tenant_id=tenant_id, store_id=store_id, user_id=actor_user_id,
                    new_value={"order": ordered_seller_ids}, request=request)
    await _publish(tenant_id, store_id, queue["id"], [
        ("queue.reordered", {"order": ordered_seller_ids}),
        ("queue.updated", {}),
    ])
    return await get_queue_state(tenant_id, store_id, queue["id"])


async def mark_seller_away(*, tenant_id, store_id, seller_id, new_status, actor_user_id, actor_role, reason=None, request=None):
    seller = await _get_seller(tenant_id, store_id, seller_id)
    waiting = await db.queue_entries.find(
        {"tenant_id": tenant_id, "store_id": store_id, "seller_id": seller_id, "status": "WAITING"}
    ).to_list(100)
    affected = set()
    for e in waiting:
        await db.queue_entries.delete_one({"id": e["id"]})
        affected.add(e["queue_id"])
    for qid in affected:
        await recalculate_positions(tenant_id, qid)
    # Normalize to AVAILABLE first when leaving queue/serving states.
    if seller.get("current_status") in {"WAITING_IN_QUEUE", "SERVING"}:
        await change_state(tenant_id=tenant_id, store_id=store_id, seller_id=seller_id, to_state="AVAILABLE",
                           actor_user_id=actor_user_id, actor_role=actor_role, via_queue_engine=True, request=request)
    await change_state(tenant_id=tenant_id, store_id=store_id, seller_id=seller_id, to_state=new_status,
                       actor_user_id=actor_user_id, actor_role=actor_role, reason=reason, via_queue_engine=True, request=request)
    queue = await ensure_default_queue(tenant_id, store_id)
    await _emit_event(tenant_id, store_id, queue["id"], seller_id, "SELLER_STATUS_CHANGED", actor_user_id, {"new_status": new_status})
    await log_audit(action="SELLER_STATUS_CHANGED", entity="seller_profile", entity_id=seller_id,
                    tenant_id=tenant_id, store_id=store_id, user_id=actor_user_id,
                    new_value={"current_status": new_status, "reason": reason}, request=request)
    await _publish(tenant_id, store_id, queue["id"], [
        ("seller.status_changed", {"seller_id": seller_id, "status": new_status}),
        ("queue.updated", {}),
        ("dashboard.updated", {}),
    ])
    return await get_queue_state(tenant_id, store_id, queue["id"])


async def return_seller_available(*, tenant_id, store_id, seller_id, actor_user_id, actor_role,
                                  reason=None, join_queue=False, queue_id=None, request=None):
    seller = await _get_seller(tenant_id, store_id, seller_id)
    queue = await _resolve_queue(tenant_id, store_id, queue_id)
    if seller.get("current_status") != "AVAILABLE":
        await change_state(tenant_id=tenant_id, store_id=store_id, seller_id=seller_id, to_state="AVAILABLE",
                           actor_user_id=actor_user_id, actor_role=actor_role, reason=reason, via_queue_engine=True, request=request)
    if join_queue:
        seller = await db.seller_profiles.find_one({"tenant_id": tenant_id, "id": seller_id})
        if not await db.queue_entries.find_one({"tenant_id": tenant_id, "queue_id": queue["id"], "seller_id": seller_id, "status": "WAITING"}):
            await change_state(tenant_id=tenant_id, store_id=store_id, seller_id=seller_id, to_state="WAITING_IN_QUEUE",
                               actor_user_id=actor_user_id, actor_role=actor_role, via_queue_engine=True, request=request)
            await _insert_at_end(tenant_id, store_id, queue["id"], seller)
            await recalculate_positions(tenant_id, queue["id"])
            await _emit_event(tenant_id, store_id, queue["id"], seller_id, "SELLER_JOINED", actor_user_id)
    await _emit_event(tenant_id, store_id, queue["id"], seller_id, "SELLER_STATUS_CHANGED", actor_user_id, {"new_status": "AVAILABLE"})
    await log_audit(action="SELLER_STATUS_CHANGED", entity="seller_profile", entity_id=seller_id,
                    tenant_id=tenant_id, store_id=store_id, user_id=actor_user_id,
                    new_value={"current_status": "AVAILABLE", "reason": reason}, request=request)
    await _publish(tenant_id, store_id, queue["id"], [
        ("seller.status_changed", {"seller_id": seller_id, "status": "AVAILABLE"}),
        ("queue.updated", {}),
        ("dashboard.updated", {}),
    ])
    return await get_queue_state(tenant_id, store_id, queue["id"])


async def quick_attendance(*, tenant_id, store_id, seller_id, result,
                           customer_name=None, customer_phone=None,
                           sale_amount_cents=None, loss_reason_id=None, notes=None, sale=None,
                           product_quantity=None,
                           grupo_motivo_perda_id=None, subgrupo_motivo_perda_id=None,
                           motivo_perda_id=None, descricao_complementar=None,
                           actor_user_id, actor_role, request=None):
    """Registro Rápido: cria e finaliza atendimento em uma única operação, sem passar pela fila."""
    seller = await _get_seller(tenant_id, store_id, seller_id)
    if seller.get("current_status") != "AVAILABLE":
        raise HTTPException(status_code=409, detail="Registro rápido requer vendedor com status DISPONÍVEL.")

    queue = await ensure_default_queue(tenant_id, store_id)
    settings = _queue_settings(queue)

    detailed_enabled = await is_enabled(tenant_id, "vendas_detalhadas")
    use_detailed = bool(result == "SALE" and sale is not None and detailed_enabled)

    if result == "SALE" and not use_detailed and settings.get("require_sale_amount", True):
        if sale_amount_cents is None or sale_amount_cents <= 0:
            raise HTTPException(status_code=400, detail="Informe o valor da venda.")
    classificacao_perda = None
    if result == "NO_SALE" and settings.get("require_loss_reason", True):
        if await motivos_perda_service.hierarquia_ativa_existe(tenant_id):
            classificacao_perda = await motivos_perda_service.validar_combinação_para_atendimento(
                empresa_id=tenant_id,
                grupo_motivo_perda_id=grupo_motivo_perda_id,
                subgrupo_motivo_perda_id=subgrupo_motivo_perda_id,
                motivo_perda_id=motivo_perda_id,
                descricao_complementar=descricao_complementar,
            )
            loss_reason_id = None
        elif not loss_reason_id:
            raise HTTPException(status_code=400, detail="Informe o motivo da não venda.")
    if result == "INVALID":
        if not settings.get("allow_invalid_attendance", True):
            raise HTTPException(status_code=400, detail="Atendimento inválido não é permitido nas configurações.")
        if not (notes and notes.strip()):
            raise HTTPException(status_code=400, detail="Justificativa é obrigatória para atendimento inválido.")
    if loss_reason_id:
        lr = await db.loss_reasons.find_one({"tenant_id": tenant_id, "id": loss_reason_id})
        if not lr:
            raise HTTPException(status_code=404, detail="Motivo de perda não encontrado.")

    await change_state(tenant_id=tenant_id, store_id=store_id, seller_id=seller_id, to_state="SERVING",
                       actor_user_id=actor_user_id, actor_role=actor_role, via_queue_engine=True, request=request)

    now = utcnow_iso()
    visit_id = new_id()
    att_id = new_id()
    await db.customer_visits.insert_one({
        "id": visit_id, "tenant_id": tenant_id, "store_id": store_id, "queue_id": None,
        "seller_id": seller_id, "customer_name": customer_name, "customer_phone": customer_phone,
        "source": "QUICK", "arrival_time": now, "start_time": now, "end_time": None,
        "status": "IN_PROGRESS", "notes": notes, "created_at": now, "updated_at": now,
    })
    await db.attendances.insert_one({
        "id": att_id, "tenant_id": tenant_id, "store_id": store_id, "queue_id": None,
        "customer_visit_id": visit_id, "seller_id": seller_id, "started_at": now, "finished_at": None,
        "status": "IN_PROGRESS",
        "source": "QUICK",     # P0.5: campo canônico de origem
        "origin": "QUICK",     # mantido para backward compat
        "result": None, "sale_amount_cents": None, "loss_reason_id": None, "notes": notes,
        "created_by": actor_user_id, "created_at": now, "updated_at": now,
    })

    created_sale = None
    final_amount_cents = None
    if result == "SALE":
        if use_detailed:
            effective_sale = sale if isinstance(sale, dict) else (sale.model_dump() if hasattr(sale, "model_dump") else (sale.dict() if hasattr(sale, "dict") else {}))
            if not (effective_sale.get("items") or effective_sale.get("gross_amount_cents")) and sale_amount_cents:
                effective_sale = {**effective_sale, "gross_amount_cents": sale_amount_cents}
            created_sale = await sales_service.create_sale(
                tenant_id=tenant_id, store_id=store_id, attendance_id=att_id,
                seller_id=seller_id, customer_visit_id=visit_id,
                sale=effective_sale, actor_user_id=actor_user_id,
            )
            final_amount_cents = created_sale["net_amount_cents"] or sale_amount_cents
        else:
            # Modo simples: sempre registrar a venda na aba Vendas, sem itens detalhados
            simple_sale = SaleInput(gross_amount_cents=sale_amount_cents or 0)
            created_sale = await sales_service.create_sale(
                tenant_id=tenant_id, store_id=store_id, attendance_id=att_id,
                seller_id=seller_id, customer_visit_id=visit_id,
                sale=simple_sale.model_dump(), actor_user_id=actor_user_id,
            )
            final_amount_cents = sale_amount_cents

    now = utcnow_iso()
    finished = await db.attendances.find_one_and_update(
        {"id": att_id},
        {"$set": {
            "status": "FINISHED", "result": result,
            "sale_amount_cents": final_amount_cents if result == "SALE" else None,
            "sale_id": created_sale["id"] if created_sale else None,
            "loss_reason_id": loss_reason_id, "notes": notes,
            "grupo_motivo_perda_id": classificacao_perda["grupo"]["identificador"] if classificacao_perda else None,
            "subgrupo_motivo_perda_id": classificacao_perda["subgrupo"]["identificador"] if classificacao_perda else None,
            "motivo_perda_id": classificacao_perda["motivo"]["identificador"] if classificacao_perda else None,
            "grupo_motivo_perda_nome_historico": classificacao_perda["grupo"]["nome"] if classificacao_perda else None,
            "subgrupo_motivo_perda_nome_historico": classificacao_perda["subgrupo"]["nome"] if classificacao_perda else None,
            "motivo_perda_nome_historico": classificacao_perda["motivo"]["nome"] if classificacao_perda else None,
            "descricao_complementar": classificacao_perda["descricao_complementar"] if classificacao_perda else None,
            "product_quantity": product_quantity if result == "SALE" else None,
            "finished_at": now, "updated_at": now,
        }},
        return_document=ReturnDocument.AFTER,
    )

    visit_status = {"SALE": "CONVERTED", "NO_SALE": "LOST", "FOLLOW_UP": "ABANDONED", "INVALID": "INVALID"}.get(result, "LOST")
    await db.customer_visits.update_one(
        {"id": visit_id},
        {"$set": {"status": visit_status, "end_time": now, "updated_at": now}},
    )

    await change_state(tenant_id=tenant_id, store_id=store_id, seller_id=seller_id, to_state="AVAILABLE",
                       actor_user_id=actor_user_id, actor_role=actor_role, via_queue_engine=True, request=request)

    await _emit_event(tenant_id, store_id, queue["id"], seller_id, "ATTENDANCE_FINISHED", actor_user_id,
                      {"result": result, "origin": "QUICK"})
    await log_audit(action="ATTENDANCE_FINISHED", entity="attendance", entity_id=att_id,
                    tenant_id=tenant_id, store_id=store_id, user_id=actor_user_id,
                    new_value={"result": result, "origin": "QUICK",
                               "sale_amount_cents": finished.get("sale_amount_cents")}, request=request)

    finished.pop("_id", None)
    events = [
        ("attendance.finished", {"attendance_id": att_id, "result": result, "origin": "QUICK"}),
        ("seller.status_changed", {"seller_id": seller_id, "status": "AVAILABLE"}),
        ("dashboard.updated", {}),
    ]
    if created_sale:
        events.append(("sale.created", {
            "sale_id": created_sale["id"], "attendance_id": att_id,
            "seller_id": seller_id, "net_amount_cents": created_sale["net_amount_cents"],
        }))
    await _publish(tenant_id, store_id, queue["id"], events)
    # Recalcular metas ativas (silencioso — não bloqueia o fluxo)
    await goals_service.recalculate_active_goals(tenant_id, store_id=store_id, seller_id=seller_id)
    return {"attendance": finished, "sale": created_sale, "state": await get_queue_state(tenant_id, store_id)}


async def cancel_attendance(*, tenant_id, store_id, attendance_id, reason, actor_user_id, actor_role, request=None):
    att = await db.attendances.find_one({"tenant_id": tenant_id, "id": attendance_id})
    if not att:
        raise HTTPException(status_code=404, detail="Atendimento não encontrado.")
    if att["store_id"] != store_id:
        raise HTTPException(status_code=404, detail="Atendimento não pertence a esta unidade.")
    if att["status"] != "IN_PROGRESS":
        raise HTTPException(status_code=409, detail="Atendimento não está em andamento.")
    if not (reason and reason.strip()):
        raise HTTPException(status_code=400, detail="Motivo é obrigatório para cancelar o atendimento.")
    now = utcnow_iso()
    cancelled = await db.attendances.find_one_and_update(
        {"id": attendance_id, "status": "IN_PROGRESS"},
        {"$set": {"status": "CANCELLED", "notes": reason, "finished_at": now, "updated_at": now}},
        return_document=ReturnDocument.AFTER,
    )
    if not cancelled:
        _conflict()
    if att.get("customer_visit_id"):
        await db.customer_visits.update_one(
            {"id": att["customer_visit_id"]},
            {"$set": {"status": "ABANDONED", "end_time": now, "updated_at": now}},
        )
    queue = await _resolve_queue(tenant_id, store_id, att.get("queue_id"))
    settings = _queue_settings(queue)
    seller = await db.seller_profiles.find_one({"tenant_id": tenant_id, "id": att["seller_id"]})
    if seller and seller.get("current_status") == "SERVING":
        await change_state(tenant_id=tenant_id, store_id=store_id, seller_id=att["seller_id"], to_state="AVAILABLE",
                           actor_user_id=actor_user_id, actor_role=actor_role, reason=reason, via_queue_engine=True, request=request)
        if att.get("is_preference"):
            cancelled = await _apply_preference_return(tenant_id=tenant_id, store_id=store_id, queue=queue,
                                                       attendance=cancelled, seller=seller,
                                                       actor_user_id=actor_user_id, actor_role=actor_role, request=request)
        elif settings.get("return_to_end_after_attendance", True) and queue["status"] == "ACTIVE":
            await change_state(tenant_id=tenant_id, store_id=store_id, seller_id=att["seller_id"], to_state="WAITING_IN_QUEUE",
                               actor_user_id=actor_user_id, actor_role=actor_role, via_queue_engine=True, request=request)
            await _insert_at_end(tenant_id, store_id, queue["id"], seller)
            await recalculate_positions(tenant_id, queue["id"])
            await _emit_event(tenant_id, store_id, queue["id"], att["seller_id"], "SELLER_RETURNED_TO_END", actor_user_id)
    await _emit_event(tenant_id, store_id, queue["id"], att["seller_id"], "ATTENDANCE_CANCELLED", actor_user_id, {"reason": reason})
    await log_audit(action="ATTENDANCE_CANCELLED", entity="attendance", entity_id=attendance_id,
                    tenant_id=tenant_id, store_id=store_id, user_id=actor_user_id,
                    new_value={"reason": reason}, request=request)
    cancelled.pop("_id", None)
    await _publish(tenant_id, store_id, queue["id"], [
        ("attendance.cancelled", {"attendance_id": attendance_id}),
        ("seller.status_changed", {"seller_id": att["seller_id"]}),
        ("queue.updated", {}),
        ("dashboard.updated", {}),
    ])
    # Recalcular metas — cancela impacto de eventual SALE vinculado (silencioso)
    await goals_service.recalculate_active_goals(tenant_id, store_id=store_id, seller_id=att["seller_id"])
    return {"attendance": cancelled, "state": await get_queue_state(tenant_id, store_id, queue["id"])}
