"""NotificationService — Etapa 10. Central de notificações internas por usuário."""
from datetime import datetime, timezone
from typing import Optional

from db import db
from models import new_id, utcnow_iso
from realtime import event_bus

# Tipos conhecidos — qualquer string é aceita; tipos desconhecidos são guardados como-estão.
# O sistema é aberto para extensão sem alterar o service.
NOTIFICATION_TYPES = {
    "FEEDBACK_RECEIVED", "GOAL_COMPLETED", "GOAL_EXPIRED", "GOAL_EXCEEDED",
    "BADGE_EARNED", "RANKING_CHANGED", "PERSONAL_RECORD", "COMPANY_RECORD",
    "CAMPAIGN_STARTED", "CAMPAIGN_UPDATED", "CAMPAIGN_ENDED",
    "AWARD", "RECOGNITION", "ADMIN_ANNOUNCEMENT", "GENERAL_ANNOUNCEMENT",
    "SCHEDULED_MESSAGE", "MOTIVATION_EVENT", "STATUS_CHANGED", "SYSTEM",
}


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


async def create_notification(
    *,
    tenant_id: str,
    user_id: str,
    ntype: str,
    title: str,
    body: str,
    entity_type: Optional[str] = None,
    entity_id: Optional[str] = None,
    store_id: Optional[str] = None,
) -> dict:
    """Cria uma notificação para o usuário e transmite via WebSocket se conectado."""
    # Aceita qualquer tipo; se desconhecido, mantém como-está (extensível)
    if not ntype:
        ntype = "SYSTEM"

    now = _now_iso()
    notif_id = new_id()
    doc = {
        "id": notif_id,
        "tenant_id": tenant_id,
        "user_id": user_id,
        "store_id": store_id,
        "type": ntype,
        "title": title,
        "body": body,
        "entity_type": entity_type,
        "entity_id": entity_id,
        "is_read": False,
        "read_at": None,
        "created_at": now,
    }

    await db.notifications.insert_one(doc)
    doc.pop("_id", None)

    # Broadcast em tempo real para o usuário se estiver conectado
    try:
        await event_bus.broadcast_to_user(
            tenant_id,
            user_id,
            {
                "event_type": "notification.created",
                "payload": {
                    "id": notif_id,
                    "type": ntype,
                    "title": title,
                    "body": body,
                    "entity_type": entity_type,
                    "entity_id": entity_id,
                    "store_id": store_id,
                    "is_read": False,
                    "created_at": now,
                },
                "timestamp": now,
            },
        )
    except Exception:
        pass  # broadcast falha silenciosamente

    return doc


async def list_notifications(
    tenant_id: str,
    user_id: str,
    limit: int = 50,
    skip: int = 0,
    unread_only: bool = False,
) -> list:
    q: dict = {"tenant_id": tenant_id, "user_id": user_id}
    if unread_only:
        q["is_read"] = False

    docs = (
        await db.notifications.find(q)
        .sort("created_at", -1)
        .skip(skip)
        .limit(limit)
        .to_list(limit)
    )
    for d in docs:
        d.pop("_id", None)
    return docs


async def get_unread_count(tenant_id: str, user_id: str) -> int:
    return await db.notifications.count_documents(
        {"tenant_id": tenant_id, "user_id": user_id, "is_read": False}
    )


async def mark_read(
    *,
    tenant_id: str,
    notification_id: str,
    user_id: str,
) -> dict:
    """Marca uma notificação específica como lida."""
    doc = await db.notifications.find_one(
        {"tenant_id": tenant_id, "id": notification_id, "user_id": user_id}
    )
    if not doc:
        from fastapi import HTTPException
        raise HTTPException(404, "Notificação não encontrada.")

    if not doc.get("is_read"):
        now = _now_iso()
        await db.notifications.update_one(
            {"tenant_id": tenant_id, "id": notification_id},
            {"$set": {"is_read": True, "read_at": now}},
        )
        doc["is_read"] = True
        doc["read_at"] = now

    doc.pop("_id", None)
    return doc


async def mark_all_read(*, tenant_id: str, user_id: str) -> dict:
    """Marca todas as notificações não lidas do usuário como lidas."""
    now = _now_iso()
    result = await db.notifications.update_many(
        {"tenant_id": tenant_id, "user_id": user_id, "is_read": False},
        {"$set": {"is_read": True, "read_at": now}},
    )
    return {"updated": result.modified_count}
