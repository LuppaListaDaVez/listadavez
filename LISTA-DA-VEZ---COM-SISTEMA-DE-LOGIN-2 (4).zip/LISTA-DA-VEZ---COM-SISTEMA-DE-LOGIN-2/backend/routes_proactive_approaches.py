"""Endpoints de Abordagem Proativa — Etapa 11."""
from typing import Optional, List
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel

from db import db
from security import resolve_tenant_context
from feature_guard import require_feature
from permission_service import require_permission
from permissions import (
    P_PROACTIVITY_VIEW_SELF, P_PROACTIVITY_VIEW_STORE, P_PROACTIVITY_VIEW_TENANT,
    P_PROACTIVITY_CREATE_SELF, P_PROACTIVITY_CREATE_ANY,
    P_PROACTIVITY_REPORTS_VIEW,
    ROLE_PERMISSIONS,
)
import proactive_approach_service as svc

router = APIRouter(prefix="/tenants/{tenant_slug}", tags=["proactivity"])

PROACTIVITY_VIEW_PERMS = (P_PROACTIVITY_VIEW_SELF, P_PROACTIVITY_VIEW_STORE, P_PROACTIVITY_VIEW_TENANT)


def _has_any(role: str, *perms: str) -> bool:
    rp = ROLE_PERMISSIONS.get(role, [])
    return any(p in rp for p in perms)


# ─── Pydantic Models ──────────────────────────────────────────────────────────

class ApproachCreate(BaseModel):
    store_id: str
    seller_id: Optional[str] = None
    customer_name: Optional[str] = None
    customer_phone: Optional[str] = None
    customer_note: Optional[str] = None
    source: Optional[str] = "STORE_FLOOR"
    approach_type: Optional[str] = "ACTIVE_APPROACH"
    notes: Optional[str] = None


class ApproachUpdate(BaseModel):
    customer_name: Optional[str] = None
    customer_phone: Optional[str] = None
    customer_note: Optional[str] = None
    source: Optional[str] = None
    approach_type: Optional[str] = None
    notes: Optional[str] = None


class CancelRequest(BaseModel):
    reason: Optional[str] = None


class CloseNoSaleRequest(BaseModel):
    loss_reason_id: Optional[str] = None
    notes: Optional[str] = None


class ConvertToAttendanceRequest(BaseModel):
    customer_name: Optional[str] = None
    notes: Optional[str] = None


class SaleItemInput(BaseModel):
    product_id: Optional[str] = None
    name: Optional[str] = None
    sku: Optional[str] = None
    quantity: int = 1
    unit_price_cents: Optional[int] = None
    discount_cents: Optional[int] = 0


class ConvertToSaleRequest(BaseModel):
    gross_amount_cents: Optional[int] = 0
    discount_amount_cents: Optional[int] = 0
    net_amount_cents: Optional[int] = None
    payment_method: Optional[str] = "CASH"
    items: Optional[List[SaleItemInput]] = []
    notes: Optional[str] = None


# ─── Endpoints ────────────────────────────────────────────────────────────────

@router.get("/proactive-approaches")
async def list_approaches(
    store_id: Optional[str] = None,
    seller_id: Optional[str] = None,
    team_id: Optional[str] = None,
    status: Optional[str] = None,
    result: Optional[str] = None,
    source: Optional[str] = None,
    approach_type: Optional[str] = None,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    limit: int = 200,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "abordagem_proativa")
    role = ctx["membership"]["role"]
    if not _has_any(role, *PROACTIVITY_VIEW_PERMS):
        raise HTTPException(status_code=403, detail="Sem permissão.")

    filters = {
        "store_id": store_id, "seller_id": seller_id, "team_id": team_id,
        "status": status, "result": result, "source": source,
        "approach_type": approach_type, "date_from": date_from, "date_to": date_to,
        "limit": limit,
    }
    return await svc.list_approaches(
        tenant_id=ctx["tenant"]["id"],
        actor_user_id=ctx["user"]["id"],
        membership=ctx["membership"],
        filters=filters,
    )


@router.post("/proactive-approaches")
async def create_approach(
    payload: ApproachCreate,
    request: Request,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "abordagem_proativa")
    return await svc.create_approach(
        tenant_id=ctx["tenant"]["id"],
        actor_user_id=ctx["user"]["id"],
        membership=ctx["membership"],
        data=payload.model_dump(),
        request=request,
    )


@router.get("/proactive-approaches/{approach_id}")
async def get_approach(approach_id: str, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "abordagem_proativa")
    return await svc.get_approach(
        tenant_id=ctx["tenant"]["id"],
        approach_id=approach_id,
        actor_user_id=ctx["user"]["id"],
        membership=ctx["membership"],
    )


@router.put("/proactive-approaches/{approach_id}")
async def update_approach(
    approach_id: str,
    payload: ApproachUpdate,
    request: Request,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "abordagem_proativa")
    return await svc.update_approach(
        tenant_id=ctx["tenant"]["id"],
        approach_id=approach_id,
        actor_user_id=ctx["user"]["id"],
        membership=ctx["membership"],
        data=payload.model_dump(exclude_none=True),
        request=request,
    )


@router.post("/proactive-approaches/{approach_id}/cancel")
async def cancel_approach(
    approach_id: str,
    payload: CancelRequest,
    request: Request,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "abordagem_proativa")
    return await svc.cancel_approach(
        tenant_id=ctx["tenant"]["id"],
        approach_id=approach_id,
        actor_user_id=ctx["user"]["id"],
        membership=ctx["membership"],
        reason=payload.reason,
        request=request,
    )


@router.post("/proactive-approaches/{approach_id}/close-no-sale")
async def close_no_sale(
    approach_id: str,
    payload: CloseNoSaleRequest,
    request: Request,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "abordagem_proativa")
    return await svc.close_no_sale(
        tenant_id=ctx["tenant"]["id"],
        approach_id=approach_id,
        actor_user_id=ctx["user"]["id"],
        membership=ctx["membership"],
        data=payload.model_dump(),
        request=request,
    )


@router.post("/proactive-approaches/{approach_id}/convert-to-attendance")
async def convert_to_attendance(
    approach_id: str,
    payload: ConvertToAttendanceRequest,
    request: Request,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "abordagem_proativa")
    return await svc.convert_to_attendance(
        tenant_id=ctx["tenant"]["id"],
        approach_id=approach_id,
        actor_user_id=ctx["user"]["id"],
        membership=ctx["membership"],
        data=payload.model_dump(),
        request=request,
    )


@router.post("/proactive-approaches/{approach_id}/convert-to-sale")
async def convert_to_sale(
    approach_id: str,
    payload: ConvertToSaleRequest,
    request: Request,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "abordagem_proativa")
    return await svc.convert_to_sale(
        tenant_id=ctx["tenant"]["id"],
        approach_id=approach_id,
        actor_user_id=ctx["user"]["id"],
        membership=ctx["membership"],
        data=payload.model_dump(),
        request=request,
    )


@router.get("/my-proactive-approaches")
async def my_approaches(
    status: Optional[str] = None,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "abordagem_proativa")
    return await svc.list_my_approaches(
        tenant_id=ctx["tenant"]["id"],
        actor_user_id=ctx["user"]["id"],
        filters={"status": status, "date_from": date_from, "date_to": date_to},
    )


@router.get("/proactivity/summary")
async def proactivity_summary(
    store_id: Optional[str] = None,
    seller_id: Optional[str] = None,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "abordagem_proativa")
    role = ctx["membership"]["role"]
    if not _has_any(role, *PROACTIVITY_VIEW_PERMS):
        raise HTTPException(status_code=403, detail="Sem permissão.")
    return await svc.get_proactivity_summary(
        tenant_id=ctx["tenant"]["id"],
        actor_user_id=ctx["user"]["id"],
        membership=ctx["membership"],
        filters={"store_id": store_id, "seller_id": seller_id, "date_from": date_from, "date_to": date_to},
    )
