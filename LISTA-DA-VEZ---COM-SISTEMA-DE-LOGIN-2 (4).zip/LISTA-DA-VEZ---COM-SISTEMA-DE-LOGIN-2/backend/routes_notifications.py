"""Notifications endpoints (P0) — paginação e rate limit."""
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request

from rate_limit_service import make_rate_limit_dep
from security import resolve_tenant_context
from feature_guard import require_feature
import notification_service

router = APIRouter(prefix="/tenants/{tenant_slug}/notifications", tags=["notifications"])

_rl_notif = make_rate_limit_dep("NOTIFICATIONS")


@router.get("/unread-count")
async def get_unread_count(ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "notificacoes")
    count = await notification_service.get_unread_count(ctx["tenant"]["id"], ctx["user"]["id"])
    return {"count": count}


@router.get("")
async def list_notifications(
    page: int = 1,
    page_size: int = 50,
    unread_only: bool = False,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "notificacoes")
    page = max(1, page)
    page_size = min(max(1, page_size), 100)
    skip = (page - 1) * page_size
    notifs = await notification_service.list_notifications(
        tenant_id=ctx["tenant"]["id"],
        user_id=ctx["user"]["id"],
        limit=page_size,
        skip=skip,
        unread_only=unread_only,
    )
    unread_count = await notification_service.get_unread_count(ctx["tenant"]["id"], ctx["user"]["id"])
    return {
        "notifications": notifs,
        "unread_count": unread_count,
        "pagination": {
            "page": page,
            "page_size": page_size,
            "total": len(notifs) + skip,  # estimativa
            "has_next": len(notifs) == page_size,
        },
    }


@router.patch("/{notification_id}/read")
async def mark_read(notification_id: str, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "notificacoes")
    return await notification_service.mark_read(
        tenant_id=ctx["tenant"]["id"],
        notification_id=notification_id,
        user_id=ctx["user"]["id"],
    )


@router.post("/mark-all-read")
async def mark_all_read(ctx: dict = Depends(resolve_tenant_context),
                        _rl: None = Depends(_rl_notif)):
    await require_feature(ctx["tenant"]["id"], "notificacoes")
    return await notification_service.mark_all_read(
        tenant_id=ctx["tenant"]["id"],
        user_id=ctx["user"]["id"],
    )
