"""NotificationPreferenceService — Etapa 12."""
from typing import Optional
from db import db
from models import new_id, utcnow_iso
from audit import log_audit


async def get_preferences(tenant_id: str, user_id: str) -> dict:
    doc = await db.notification_preferences.find_one({"tenant_id": tenant_id, "user_id": user_id})
    if not doc:
        return _default_prefs(tenant_id, user_id)
    doc.pop("_id", None)
    return doc


async def upsert_preferences(
    tenant_id: str,
    user_id: str,
    data: dict,
    request=None,
) -> dict:
    existing = await db.notification_preferences.find_one({"tenant_id": tenant_id, "user_id": user_id})
    allowed = [
        "in_app_enabled", "realtime_enabled", "email_enabled", "push_enabled",
        "motivation_events_enabled", "quiet_hours_enabled",
        "quiet_hours_start", "quiet_hours_end", "channels_by_event_type",
    ]
    updates = {k: data[k] for k in allowed if k in data}
    updates["updated_at"] = utcnow_iso()
    if existing:
        await db.notification_preferences.update_one(
            {"tenant_id": tenant_id, "user_id": user_id},
            {"$set": updates},
        )
    else:
        prefs = _default_prefs(tenant_id, user_id)
        prefs.update(updates)
        await db.notification_preferences.insert_one(prefs)
    await log_audit(
        action="NOTIFICATION_PREFERENCES_UPDATED", entity="notification_preferences", entity_id=user_id,
        tenant_id=tenant_id, user_id=user_id, new_value=updates, request=request,
    )
    return await get_preferences(tenant_id, user_id)


def _default_prefs(tenant_id: str, user_id: str) -> dict:
    return {
        "id": new_id(),
        "tenant_id": tenant_id,
        "user_id": user_id,
        "in_app_enabled": True,
        "realtime_enabled": True,
        "email_enabled": False,
        "push_enabled": False,
        "motivation_events_enabled": True,
        "quiet_hours_enabled": False,
        "quiet_hours_start": "22:00",
        "quiet_hours_end": "08:00",
        "channels_by_event_type": {},
        "created_at": utcnow_iso(),
        "updated_at": utcnow_iso(),
    }
