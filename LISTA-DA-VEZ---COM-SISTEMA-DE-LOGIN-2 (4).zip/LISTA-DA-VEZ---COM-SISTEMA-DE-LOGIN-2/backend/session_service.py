"""Gerenciamento de sessões autenticadas — Etapa 13."""
from datetime import datetime, timezone, timedelta
from typing import Optional

from db import db
from models import new_id, utcnow_iso

SESSION_TTL_DAYS = 7  # Same as refresh token TTL


async def create_session(
    *,
    user_id: str,
    auth_context: str,
    tenant_id: Optional[str] = None,
    tenant_slug: Optional[str] = None,
    membership_id: Optional[str] = None,
    role: Optional[str] = None,
    ip: Optional[str] = None,
    user_agent: Optional[str] = None,
    token_version: int = 1,
) -> dict:
    session_id = new_id()
    now = datetime.now(timezone.utc)
    expires_at = (now + timedelta(days=SESSION_TTL_DAYS)).isoformat()

    session = {
        "id": session_id,
        "user_id": user_id,
        "tenant_id": tenant_id,
        "tenant_slug": tenant_slug,
        "membership_id": membership_id,
        "role": role,
        "auth_context": auth_context,
        "ip": ip,
        "user_agent": user_agent,
        "device_label": None,
        "created_at": now.isoformat(),
        "last_seen_at": now.isoformat(),
        "expires_at": expires_at,
        "revoked_at": None,
        "revoked_reason": None,
        "token_version": token_version,
    }
    await db.auth_sessions.insert_one(session)
    session.pop("_id", None)
    return session


async def get_session(session_id: str) -> Optional[dict]:
    if not session_id:
        return None
    session = await db.auth_sessions.find_one({"id": session_id})
    if session:
        session.pop("_id", None)
    return session


async def is_session_valid(session_id: str) -> bool:
    if not session_id:
        return False
    session = await get_session(session_id)
    if not session:
        return False
    if session.get("revoked_at"):
        return False
    try:
        exp = datetime.fromisoformat(session["expires_at"])
        if exp.tzinfo is None:
            exp = exp.replace(tzinfo=timezone.utc)
        if exp < datetime.now(timezone.utc):
            return False
    except (KeyError, ValueError):
        return False
    return True


async def update_session_last_seen(session_id: str):
    await db.auth_sessions.update_one(
        {"id": session_id},
        {"$set": {"last_seen_at": utcnow_iso()}},
    )


async def revoke_session(session_id: str, reason: str = "LOGOUT"):
    await db.auth_sessions.update_one(
        {"id": session_id},
        {"$set": {"revoked_at": utcnow_iso(), "revoked_reason": reason}},
    )


async def revoke_all_user_sessions(
    user_id: str, tenant_id: Optional[str] = None, reason: str = "LOGOUT_ALL"
):
    query: dict = {"user_id": user_id, "revoked_at": None}
    if tenant_id:
        query["tenant_id"] = tenant_id
    await db.auth_sessions.update_many(
        query,
        {"$set": {"revoked_at": utcnow_iso(), "revoked_reason": reason}},
    )


async def revoke_tenant_sessions(tenant_id: str, reason: str = "TENANT_SUSPENDED"):
    await db.auth_sessions.update_many(
        {"tenant_id": tenant_id, "revoked_at": None},
        {"$set": {"revoked_at": utcnow_iso(), "revoked_reason": reason}},
    )


async def list_sessions(
    tenant_id: Optional[str] = None,
    user_id: Optional[str] = None,
    active_only: bool = True,
    limit: int = 100,
) -> list:
    query: dict = {}
    if tenant_id:
        query["tenant_id"] = tenant_id
    if user_id:
        query["user_id"] = user_id
    if active_only:
        query["revoked_at"] = None
    cursor = db.auth_sessions.find(query, {"_id": 0}).sort("created_at", -1).limit(limit)
    return await cursor.to_list(length=limit)
