"""Relatórios (Etapas 7/8) — /api/tenants/{slug}/reports/*."""
import csv
import io
import zipfile
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse

from db import db
from security import resolve_tenant_context
from feature_guard import require_feature
from permission_service import get_accessible_store_ids, require_permission
from permissions import (
    P_REPORTS_VIEW_SELF,
    P_REPORTS_VIEW_STORE,
    P_REPORTS_VIEW_TENANT,
)
import opportunity_flow_service

router = APIRouter(prefix="/tenants/{tenant_slug}/reports", tags=["reports"])

REPORT_PERMS = (P_REPORTS_VIEW_SELF, P_REPORTS_VIEW_STORE, P_REPORTS_VIEW_TENANT)


def _financeiro(ctx: dict) -> bool:
    return opportunity_flow_service._pode_ver_financeiro(ctx["membership"]["role"])


def _money(cents: int) -> str:
    return f"R$ {cents / 100:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


async def _preference_report_data(ctx: dict, date_start: Optional[str], date_end: Optional[str], store_id: Optional[str], seller_id: Optional[str], result: Optional[str], return_rule: Optional[str]):
    tenant_id = ctx["tenant"]["id"]
    store_ids = await get_accessible_store_ids(ctx["membership"], tenant_id)
    if store_id:
        if store_id not in store_ids:
            raise HTTPException(status_code=403, detail="Sem acesso a esta unidade.")
        store_ids = [store_id]
    q = {"tenant_id": tenant_id, "is_preference": True, "store_id": {"$in": store_ids}}
    if date_start:
        q.setdefault("started_at", {})["$gte"] = f"{date_start}T00:00:00+00:00"
    if date_end:
        q.setdefault("started_at", {})["$lt"] = f"{date_end}T23:59:59+00:00"
    if seller_id:
        q["seller_id"] = seller_id
    if result:
        q["result"] = result
    if return_rule:
        q["preference_return_rule_applied"] = return_rule
    raw = await db.attendances.find(q, {"_id": 0}).sort("started_at", -1).to_list(5000)
    att_ids = [a["id"] for a in raw]
    sales = await db.sales.find({"tenant_id": tenant_id, "attendance_id": {"$in": att_ids}, "status": {"$in": ["COMPLETED", "CONFIRMED", "FINISHED"]}, "deleted": {"$ne": True}}, {"_id": 0}).to_list(10000) if att_ids else []
    sales_by_att = {}
    for s in sales:
        sales_by_att.setdefault(s.get("attendance_id"), []).append(s)
    seller_ids = list({a.get("seller_id") for a in raw if a.get("seller_id")})
    sellers = await db.seller_profiles.find({"id": {"$in": seller_ids}}, {"_id": 0}).to_list(1000) if seller_ids else []
    users = await db.users.find({"id": {"$in": [s.get("user_id") for s in sellers]}}, {"_id": 0, "id": 1, "name": 1}).to_list(1000) if sellers else []
    user_names = {u["id"]: u.get("name") for u in users}
    seller_names = {s["id"]: user_names.get(s.get("user_id"), "—") for s in sellers}
    store_docs = await db.stores.find({"id": {"$in": list({a.get("store_id") for a in raw})}}, {"_id": 0, "id": 1, "name": 1}).to_list(500) if raw else []
    store_names = {s["id"]: s.get("name") for s in store_docs}
    financeiro = _financeiro(ctx)
    rows = []
    total_revenue = 0
    total_duration = 0
    duration_count = 0
    by_rule = {}
    by_seller = {}
    reposition_failures = 0
    for a in raw:
        sale_list = sales_by_att.get(a["id"], [])
        revenue = sum(int(s.get("net_amount_cents") or 0) for s in sale_list)
        total_revenue += revenue
        if a.get("started_at") and a.get("finished_at"):
            try:
                dur = max(0, (datetime.fromisoformat(a["finished_at"].replace("Z", "+00:00")) - datetime.fromisoformat(a["started_at"].replace("Z", "+00:00"))).total_seconds())
                total_duration += dur
                duration_count += 1
            except Exception:
                dur = None
        else:
            dur = None
        rule = a.get("preference_return_rule_applied") or a.get("preference_return_rule") or "PREVIOUS_POSITION"
        by_rule[rule] = by_rule.get(rule, 0) + 1
        by_seller[a.get("seller_id")] = by_seller.get(a.get("seller_id"), 0) + 1
        if a.get("preference_return_failure_reason"):
            reposition_failures += 1
        row = {
            "id": a["id"], "started_at": a.get("started_at"), "finished_at": a.get("finished_at"),
            "customer_name": a.get("preference_customer_name"), "seller_id": a.get("seller_id"),
            "seller_name": seller_names.get(a.get("seller_id"), "—"), "store_name": store_names.get(a.get("store_id"), "—"),
            "previous_position": a.get("preference_previous_position"), "final_position": a.get("preference_final_position"),
            "return_rule": rule, "turn_consumed": bool(a.get("preference_turn_consumed")),
            "result": a.get("result"), "status": a.get("status"), "duration_seconds": dur,
            "sales_count": len(sale_list), "started_by": a.get("preference_started_by"),
        }
        if financeiro:
            row["revenue"] = revenue
        rows.append(row)
    total = len(raw)
    with_sale = sum(1 for r in rows if r["sales_count"] > 0)
    totals = {
        "preference_attendances": total,
        "finished": sum(1 for a in raw if a.get("status") == "FINISHED"),
        "with_sale": with_sale,
        "without_sale": sum(1 for a in raw if a.get("status") == "FINISHED" and a.get("result") != "SALE"),
        "conversion_rate": (with_sale / total * 100) if total else 0,
        "sales": len(sales),
        "average_duration_seconds": int(total_duration / duration_count) if duration_count else 0,
        "reposition_failures": reposition_failures,
    }
    if financeiro:
        totals["revenue"] = total_revenue
        totals["average_ticket"] = int(total_revenue / len(sales)) if sales else 0
    top_sellers = [{"seller_id": sid, "seller_name": seller_names.get(sid, "—"), "count": count} for sid, count in sorted(by_seller.items(), key=lambda x: -x[1])[:10]]
    return {"can_view_financial": financeiro, "totals": totals, "by_rule": by_rule, "top_sellers": top_sellers, "items": rows}


@router.get("/preference-attendances")
async def preference_attendances_report(date_start: Optional[str] = None, date_end: Optional[str] = None, store_id: Optional[str] = None,
                                        seller_id: Optional[str] = None, result: Optional[str] = None, return_rule: Optional[str] = None,
                                        ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "relatorios_basicos")
    return await _preference_report_data(ctx, date_start, date_end, store_id, seller_id, result, return_rule)


@router.get("/preference-attendances/export.csv")
async def preference_attendances_export_csv(date_start: Optional[str] = None, date_end: Optional[str] = None, store_id: Optional[str] = None,
                                            seller_id: Optional[str] = None, result: Optional[str] = None, return_rule: Optional[str] = None,
                                            ctx: dict = Depends(resolve_tenant_context)):
    data = await _preference_report_data(ctx, date_start, date_end, store_id, seller_id, result, return_rule)
    output = io.StringIO(); writer = csv.writer(output)
    headers = ["Data", "Cliente", "Vendedor", "Unidade", "Posição anterior", "Posição final", "Regra", "Vez consumida", "Resultado", "Duração", "Vendas"]
    if data["can_view_financial"]: headers.append("Receita")
    writer.writerow(headers)
    for r in data["items"]:
        row = [r.get("started_at"), r.get("customer_name"), r.get("seller_name"), r.get("store_name"), r.get("previous_position"), r.get("final_position"), r.get("return_rule"), "Sim" if r.get("turn_consumed") else "Não", r.get("result"), r.get("duration_seconds"), r.get("sales_count")]
        if data["can_view_financial"]: row.append(_money(r.get("revenue") or 0))
        writer.writerow(row)
    content = "\ufeff" + output.getvalue()
    return StreamingResponse(iter([content.encode("utf-8")]), media_type="text/csv; charset=utf-8", headers={"Content-Disposition": "attachment; filename=atendimentos_por_preferencia.csv", "Access-Control-Expose-Headers": "Content-Disposition"})


@router.get("/preference-attendances/export.xlsx")
async def preference_attendances_export_xlsx(date_start: Optional[str] = None, date_end: Optional[str] = None, store_id: Optional[str] = None,
                                             seller_id: Optional[str] = None, result: Optional[str] = None, return_rule: Optional[str] = None,
                                             ctx: dict = Depends(resolve_tenant_context)):
    data = await _preference_report_data(ctx, date_start, date_end, store_id, seller_id, result, return_rule)
    headers = ["Data", "Cliente", "Vendedor", "Unidade", "Posição anterior", "Posição final", "Regra", "Vez consumida", "Resultado", "Duração", "Vendas"]
    if data["can_view_financial"]: headers.append("Receita")
    rows = [headers]
    for r in data["items"]:
        row = [r.get("started_at"), r.get("customer_name"), r.get("seller_name"), r.get("store_name"), r.get("previous_position"), r.get("final_position"), r.get("return_rule"), "Sim" if r.get("turn_consumed") else "Não", r.get("result"), r.get("duration_seconds"), r.get("sales_count")]
        if data["can_view_financial"]: row.append((r.get("revenue") or 0) / 100)
        rows.append(row)
    xml_rows = []
    for ridx, row in enumerate(rows, start=1):
        cells = []
        for cidx, val in enumerate(row, start=1):
            col = chr(64 + cidx)
            if isinstance(val, (int, float)) and val is not None:
                cells.append(f'<c r="{col}{ridx}"><v>{val}</v></c>')
            else:
                text = str(val or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                cells.append(f'<c r="{col}{ridx}" t="inlineStr"><is><t>{text}</t></is></c>')
        xml_rows.append(f'<row r="{ridx}">{"".join(cells)}</row>')
    sheet = f'<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>{"".join(xml_rows)}</sheetData></worksheet>'
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>')
        z.writestr("_rels/.rels", '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr("xl/workbook.xml", '<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Preferencia" sheetId="1" r:id="rId1"/></sheets></workbook>')
        z.writestr("xl/_rels/workbook.xml.rels", '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>')
        z.writestr("xl/worksheets/sheet1.xml", sheet)
    buf.seek(0)
    return StreamingResponse(iter([buf.getvalue()]), media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", headers={"Content-Disposition": "attachment; filename=atendimentos_por_preferencia.xlsx", "Access-Control-Expose-Headers": "Content-Disposition"})


@router.get("/opportunity-flow")
async def report_opportunity_flow(
    date_start: Optional[str] = None,
    date_end: Optional[str] = None,
    store_id: Optional[str] = None,
    team_id: Optional[str] = None,
    seller_id: Optional[str] = None,
    attendance_type: Optional[str] = None,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "relatorios_basicos")
    return await opportunity_flow_service.gerar_relatorio(
        ctx,
        date_start=date_start,
        date_end=date_end,
        store_id=store_id,
        team_id=team_id,
        seller_id=seller_id,
        attendance_type=attendance_type,
    )


@router.get("/opportunity-flow/options")
async def report_opportunity_flow_options(
    store_id: Optional[str] = None,
    team_id: Optional[str] = None,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "relatorios_basicos")
    return await opportunity_flow_service.opcoes_filtros(ctx, store_id=store_id, team_id=team_id)


@router.get("/opportunity-flow/export.csv")
async def export_opportunity_flow_csv(
    date_start: Optional[str] = None,
    date_end: Optional[str] = None,
    store_id: Optional[str] = None,
    team_id: Optional[str] = None,
    seller_id: Optional[str] = None,
    attendance_type: Optional[str] = None,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "relatorios_basicos")
    report = await opportunity_flow_service.gerar_relatorio(ctx, date_start=date_start, date_end=date_end, store_id=store_id, team_id=team_id, seller_id=seller_id, attendance_type=attendance_type)
    return opportunity_flow_service.csv_response(report)


@router.get("/opportunity-flow/export.xlsx")
async def export_opportunity_flow_xlsx(
    date_start: Optional[str] = None,
    date_end: Optional[str] = None,
    store_id: Optional[str] = None,
    team_id: Optional[str] = None,
    seller_id: Optional[str] = None,
    attendance_type: Optional[str] = None,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "relatorios_basicos")
    report = await opportunity_flow_service.gerar_relatorio(ctx, date_start=date_start, date_end=date_end, store_id=store_id, team_id=team_id, seller_id=seller_id, attendance_type=attendance_type)
    return opportunity_flow_service.xlsx_response(report)


def _has_report_perm(role: str) -> bool:
    from permissions import ROLE_PERMISSIONS
    return any(p in ROLE_PERMISSIONS.get(role, []) for p in REPORT_PERMS)


async def _build_base_filter(ctx: dict, date_start: Optional[str], date_end: Optional[str],
                              store_id: Optional[str]) -> tuple[dict, Optional[str]]:
    """Retorna (filtro_base, seller_filter_id) aplicando scoping por role."""
    tenant_id = ctx["tenant"]["id"]
    role = ctx["membership"]["role"]
    accessible_store_ids = await get_accessible_store_ids(ctx["membership"], tenant_id)

    if store_id:
        if store_id not in accessible_store_ids:
            raise HTTPException(status_code=403, detail="Sem acesso a esta unidade.")
        effective_store_ids = [store_id]
    else:
        effective_store_ids = accessible_store_ids

    q: dict = {"tenant_id": tenant_id, "store_id": {"$in": effective_store_ids}}

    if date_start:
        q.setdefault("created_at", {})["$gte"] = date_start
    if date_end:
        q.setdefault("created_at", {})["$lte"] = date_end + "T23:59:59.999999+00:00"

    seller_filter_id = None
    if role == "SELLER":
        profile = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": ctx["user"]["id"]})
        seller_filter_id = profile["id"] if profile else "__none__"
        q["seller_id"] = seller_filter_id

    return q, seller_filter_id


async def _get_seller_name_map(seller_ids: list[str]) -> dict:
    names: dict = {}
    async for s in db.seller_profiles.find({"id": {"$in": seller_ids}}):
        user = await db.users.find_one({"id": s.get("user_id", "")})
        names[s["id"]] = user.get("name", "—") if user else "—"
    return names


async def _get_store_name_map(store_ids: list[str]) -> dict:
    names: dict = {}
    async for s in db.stores.find({"id": {"$in": store_ids}}):
        names[s["id"]] = s.get("name", "—")
    return names


# ─── 1. Relatório de Atendimentos ────────────────────────────────────────────
@router.get("/attendances")
async def report_attendances(
    date_start: Optional[str] = None,
    date_end: Optional[str] = None,
    store_id: Optional[str] = None,
    seller_id: Optional[str] = None,
    result: Optional[str] = None,
    limit: int = 500,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "relatorios_basicos")
    if not _has_report_perm(ctx["membership"]["role"]):
        raise HTTPException(status_code=403, detail="Sem permissão para visualizar relatórios.")

    q, seller_filter_id = await _build_base_filter(ctx, date_start, date_end, store_id)
    if seller_id and not seller_filter_id:
        q["seller_id"] = seller_id
    if result:
        q["result"] = result

    raw = await db.attendances.find(q).sort("created_at", -1).limit(min(limit, 2000)).to_list(2000)
    if not raw:
        return []

    seller_ids = list({a["seller_id"] for a in raw if a.get("seller_id")})
    store_ids = list({a["store_id"] for a in raw if a.get("store_id")})
    seller_names = await _get_seller_name_map(seller_ids)
    store_names = await _get_store_name_map(store_ids)

    # Enrich loss reason names
    lr_ids = [a.get("loss_reason_id") for a in raw if a.get("loss_reason_id")]
    lr_names: dict = {}
    if lr_ids:
        async for lr in db.loss_reasons.find({"id": {"$in": lr_ids}}):
            lr_names[lr["id"]] = lr.get("name", "—")

    out = []
    for a in raw:
        a.pop("_id", None)
        out.append({
            "id": a["id"],
            "seller_name": seller_names.get(a["seller_id"], "—"),
            "store_name": store_names.get(a["store_id"], "—"),
            "status": a.get("status"),
            "result": a.get("result"),
            "sale_amount_cents": a.get("sale_amount_cents") or 0,
            "loss_reason": (
                " → ".join([x for x in [
                    a.get("grupo_motivo_perda_nome_historico"),
                    a.get("subgrupo_motivo_perda_nome_historico"),
                    a.get("motivo_perda_nome_historico"),
                ] if x]) or lr_names.get(a.get("loss_reason_id", ""), "—")
            ),
            "grupo_motivo_perda_nome_historico": a.get("grupo_motivo_perda_nome_historico"),
            "subgrupo_motivo_perda_nome_historico": a.get("subgrupo_motivo_perda_nome_historico"),
            "motivo_perda_nome_historico": a.get("motivo_perda_nome_historico"),
            "descricao_complementar": a.get("descricao_complementar"),
            "notes": a.get("notes"),
            "created_at": a.get("created_at"),
            "started_at": a.get("started_at"),
            "finished_at": a.get("finished_at"),
        })
    return out


# ─── 2. Taxa de Conversão ────────────────────────────────────────────────────
@router.get("/conversion")
async def report_conversion(
    date_start: Optional[str] = None,
    date_end: Optional[str] = None,
    store_id: Optional[str] = None,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "relatorios_basicos")
    if not _has_report_perm(ctx["membership"]["role"]):
        raise HTTPException(status_code=403, detail="Sem permissão para visualizar relatórios.")

    q, _ = await _build_base_filter(ctx, date_start, date_end, store_id)
    q["status"] = "FINISHED"

    raw = await db.attendances.find(q).to_list(5000)
    if not raw:
        return {"by_seller": [], "by_store": [], "total": _conv_stats([])}

    seller_ids = list({a["seller_id"] for a in raw})
    store_ids = list({a["store_id"] for a in raw})
    seller_names = await _get_seller_name_map(seller_ids)
    store_names = await _get_store_name_map(store_ids)

    # Por vendedor
    by_seller: dict = {}
    for a in raw:
        sid = a["seller_id"]
        if sid not in by_seller:
            by_seller[sid] = {"seller_id": sid, "seller_name": seller_names.get(sid, "—"), "atendimentos": 0, "vendas": 0, "total_cents": 0}
        by_seller[sid]["atendimentos"] += 1
        if a.get("result") == "SALE":
            by_seller[sid]["vendas"] += 1
            by_seller[sid]["total_cents"] += a.get("sale_amount_cents") or 0

    by_seller_list = []
    for d in by_seller.values():
        d["conversao_pct"] = round(d["vendas"] / d["atendimentos"] * 100) if d["atendimentos"] else 0
        d["ticket_medio_cents"] = round(d["total_cents"] / d["vendas"]) if d["vendas"] else 0
        by_seller_list.append(d)

    by_seller_list.sort(key=lambda x: x["conversao_pct"], reverse=True)

    # Por loja
    by_store: dict = {}
    for a in raw:
        stid = a["store_id"]
        if stid not in by_store:
            by_store[stid] = {"store_id": stid, "store_name": store_names.get(stid, "—"), "atendimentos": 0, "vendas": 0, "total_cents": 0}
        by_store[stid]["atendimentos"] += 1
        if a.get("result") == "SALE":
            by_store[stid]["vendas"] += 1
            by_store[stid]["total_cents"] += a.get("sale_amount_cents") or 0

    by_store_list = []
    for d in by_store.values():
        d["conversao_pct"] = round(d["vendas"] / d["atendimentos"] * 100) if d["atendimentos"] else 0
        d["ticket_medio_cents"] = round(d["total_cents"] / d["vendas"]) if d["vendas"] else 0
        by_store_list.append(d)

    return {
        "by_seller": by_seller_list,
        "by_store": by_store_list,
        "total": _conv_stats(raw),
    }


def _conv_stats(items: list) -> dict:
    total = len(items)
    sales = sum(1 for a in items if a.get("result") == "SALE")
    total_cents = sum(a.get("sale_amount_cents") or 0 for a in items if a.get("result") == "SALE")
    return {
        "atendimentos": total,
        "vendas": sales,
        "conversao_pct": round(sales / total * 100) if total else 0,
        "total_vendido_cents": total_cents,
        "ticket_medio_cents": round(total_cents / sales) if sales else 0,
    }


# ─── 3. Motivos de Não-Venda ─────────────────────────────────────────────────
@router.get("/loss-reasons")
async def report_loss_reasons(
    date_start: Optional[str] = None,
    date_end: Optional[str] = None,
    store_id: Optional[str] = None,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "relatorios_basicos")
    if not _has_report_perm(ctx["membership"]["role"]):
        raise HTTPException(status_code=403, detail="Sem permissão para visualizar relatórios.")

    q, _ = await _build_base_filter(ctx, date_start, date_end, store_id)
    q["result"] = "NO_SALE"
    q["status"] = "FINISHED"

    raw = await db.attendances.find(q).to_list(5000)

    # Contagem por motivo_perda_id hierárquico, com fallback para motivos antigos.
    counts: dict = {}
    for a in raw:
        motivo_id = a.get("motivo_perda_id")
        if motivo_id:
            key = f"hierarquia::{motivo_id}"
            counts.setdefault(key, {
                "name": a.get("motivo_perda_nome_historico") or "—",
                "grupo": a.get("grupo_motivo_perda_nome_historico"),
                "subgrupo": a.get("subgrupo_motivo_perda_nome_historico"),
                "count": 0,
            })
            counts[key]["count"] += 1
        elif a.get("loss_reason_id"):
            lr_id = a.get("loss_reason_id")
            counts[lr_id] = counts.get(lr_id, 0) + 1
        else:
            key = a.get("loss_reason_text") or a.get("notes") or "Sem motivo informado"
            counts[f"__text__{key}"] = counts.get(f"__text__{key}", 0) + 1

    # Enrich com nomes
    lr_ids = [k for k, v in counts.items() if not k.startswith("__text__") and not isinstance(v, dict)]
    lr_names: dict = {}
    if lr_ids:
        async for lr in db.loss_reasons.find({"id": {"$in": lr_ids}}):
            lr_names[lr["id"]] = lr.get("name", "—")

    total_no_sale = sum(v["count"] if isinstance(v, dict) else v for v in counts.values())
    result = []
    for key, value in sorted(counts.items(), key=lambda x: -(x[1]["count"] if isinstance(x[1], dict) else x[1])):
        if isinstance(value, dict):
            count = value["count"]
            name = value["name"]
            grupo = value.get("grupo")
            subgrupo = value.get("subgrupo")
        elif key.startswith("__text__"):
            count = value
            name = key[8:]
            grupo = None
            subgrupo = None
        else:
            count = value
            name = lr_names.get(key, "—")
            grupo = None
            subgrupo = None
        result.append({
            "name": name,
            "grupo": grupo,
            "subgrupo": subgrupo,
            "count": count,
            "pct": round(count / total_no_sale * 100) if total_no_sale else 0,
        })

    return {"items": result, "total_no_sale": total_no_sale, "total_finished": len(raw)}


# ─── 4. Performance de Vendedores ────────────────────────────────────────────
@router.get("/seller-performance")
async def report_seller_performance(
    date_start: Optional[str] = None,
    date_end: Optional[str] = None,
    store_id: Optional[str] = None,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "relatorios_basicos")
    if not _has_report_perm(ctx["membership"]["role"]):
        raise HTTPException(status_code=403, detail="Sem permissão para visualizar relatórios.")

    q, seller_filter_id = await _build_base_filter(ctx, date_start, date_end, store_id)
    q["status"] = "FINISHED"

    raw = await db.attendances.find(q).to_list(5000)

    seller_ids = list({a["seller_id"] for a in raw})
    seller_names = await _get_seller_name_map(seller_ids)

    perf: dict = {}
    for a in raw:
        sid = a["seller_id"]
        if sid not in perf:
            perf[sid] = {
                "seller_id": sid,
                "seller_name": seller_names.get(sid, "—"),
                "atendimentos": 0,
                "vendas": 0,
                "total_cents": 0,
                "durations": [],
            }
        perf[sid]["atendimentos"] += 1
        if a.get("result") == "SALE":
            perf[sid]["vendas"] += 1
            perf[sid]["total_cents"] += a.get("sale_amount_cents") or 0
        if a.get("started_at") and a.get("finished_at"):
            try:
                s_dt = datetime.fromisoformat(a["started_at"].replace("Z", "+00:00"))
                f_dt = datetime.fromisoformat(a["finished_at"].replace("Z", "+00:00"))
                d = (f_dt - s_dt).total_seconds()
                if d > 0:
                    perf[sid]["durations"].append(d)
            except Exception:
                pass

    result = []
    for d in perf.values():
        durs = d.pop("durations")
        d["conversao_pct"] = round(d["vendas"] / d["atendimentos"] * 100) if d["atendimentos"] else 0
        d["ticket_medio_cents"] = round(d["total_cents"] / d["vendas"]) if d["vendas"] else 0
        d["tempo_medio_segundos"] = round(sum(durs) / len(durs)) if durs else 0
        result.append(d)

    result.sort(key=lambda x: x["vendas"], reverse=True)
    return result


# ─── 5. Produtos mais vendidos ───────────────────────────────────────────────
@router.get("/products")
async def report_products(
    date_start: Optional[str] = None,
    date_end: Optional[str] = None,
    store_id: Optional[str] = None,
    limit: int = 20,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "relatorios_basicos")
    if not _has_report_perm(ctx["membership"]["role"]):
        raise HTTPException(status_code=403, detail="Sem permissão para visualizar relatórios.")

    tenant_id = ctx["tenant"]["id"]
    accessible_store_ids = await get_accessible_store_ids(ctx["membership"], tenant_id)
    if store_id:
        if store_id not in accessible_store_ids:
            raise HTTPException(status_code=403, detail="Sem acesso a esta unidade.")
        effective_store_ids = [store_id]
    else:
        effective_store_ids = accessible_store_ids

    sales_q: dict = {
        "tenant_id": tenant_id,
        "store_id": {"$in": effective_store_ids},
        "status": "COMPLETED",
    }
    if date_start:
        sales_q.setdefault("created_at", {})["$gte"] = date_start
    if date_end:
        sales_q.setdefault("created_at", {})["$lte"] = date_end + "T23:59:59.999999+00:00"

    sales_raw = await db.sales.find(sales_q).to_list(5000)
    sale_ids = [s["id"] for s in sales_raw]

    items_q: dict = {"sale_id": {"$in": sale_ids}} if sale_ids else {"sale_id": "__none__"}
    sale_items = await db.sale_items.find(items_q).to_list(20000)

    product_ids = list({i["product_id"] for i in sale_items if i.get("product_id")})
    prod_names: dict = {}
    if product_ids:
        async for p in db.products.find({"id": {"$in": product_ids}}):
            prod_names[p["id"]] = p.get("name", "—")

    agg: dict = {}
    for item in sale_items:
        pid = item.get("product_id") or f"__noname_{item.get('name', 'Produto')}"
        name = item.get("name") or prod_names.get(item.get("product_id", ""), "—")
        if pid not in agg:
            agg[pid] = {"product_id": pid if not pid.startswith("__") else None, "name": name, "quantidade": 0, "total_cents": 0}
        agg[pid]["quantidade"] += item.get("quantity", 1)
        net = (item.get("unit_price_cents") or 0) * item.get("quantity", 1) - (item.get("discount_cents") or 0)
        agg[pid]["total_cents"] += net

    result = sorted(agg.values(), key=lambda x: x["quantidade"], reverse=True)[:limit]
    return result



# ─── 6. PA — Produtos por Atendimento ───────────────────────────────────────
@router.get("/pa")
async def report_pa(
    date_start: Optional[str] = None,
    date_end: Optional[str] = None,
    store_id: Optional[str] = None,
    ctx: dict = Depends(resolve_tenant_context),
):
    """Retorna PA (Produtos por Atendimento) por vendedor e total agregado.

    PA = total_produtos_vendidos / total_atendimentos válidos.
    """
    await require_feature(ctx["tenant"]["id"], "relatorios_basicos")
    if not _has_report_perm(ctx["membership"]["role"]):
        raise HTTPException(status_code=403, detail="Sem permissão para visualizar relatórios.")

    q, seller_filter_id = await _build_base_filter(ctx, date_start, date_end, store_id)
    q["status"] = "FINISHED"

    raw = await db.attendances.find(q).to_list(5000)
    if not raw:
        return {"by_seller": [], "total": _pa_stats([])}

    seller_ids = list({a["seller_id"] for a in raw if a.get("seller_id")})
    seller_names = await _get_seller_name_map(seller_ids)

    by_seller: dict = {}
    for a in raw:
        sid = a["seller_id"]
        if sid not in by_seller:
            by_seller[sid] = {
                "seller_id": sid,
                "seller_name": seller_names.get(sid, "—"),
                "total_atendimentos": 0,
                "atendimentos_com_venda": 0,
                "total_produtos": 0,
                "total_cents": 0,
            }
        entry = by_seller[sid]
        if a.get("result") != "INVALID":
            entry["total_atendimentos"] += 1
        if a.get("result") == "SALE":
            entry["atendimentos_com_venda"] += 1
            entry["total_produtos"] += a.get("product_quantity") or 0
            entry["total_cents"] += a.get("sale_amount_cents") or 0

    result_list = []
    for d in by_seller.values():
        att_venda = d["atendimentos_com_venda"]
        total_att = d["total_atendimentos"]
        d["pa"] = round(d["total_produtos"] / total_att, 2) if total_att else 0.0
        d["conversao_pct"] = round(att_venda / total_att * 100, 1) if total_att else 0.0
        d["ticket_medio_cents"] = round(d["total_cents"] / att_venda) if att_venda else 0
        result_list.append(d)

    result_list.sort(key=lambda x: x["pa"], reverse=True)
    return {"by_seller": result_list, "total": _pa_stats(raw)}


def _pa_stats(items: list) -> dict:
    """Calcula PA agregado total — nunca média das médias."""
    total_att = sum(1 for a in items if a.get("result") != "INVALID" and a.get("status") == "FINISHED")
    sales = [a for a in items if a.get("result") == "SALE" and a.get("status") == "FINISHED"]
    total_products = sum(a.get("product_quantity") or 0 for a in sales)
    total_cents = sum(a.get("sale_amount_cents") or 0 for a in sales)
    att_com_venda = len(sales)
    return {
        "total_atendimentos": total_att,
        "atendimentos_com_venda": att_com_venda,
        "total_produtos": total_products,
        "pa": round(total_products / total_att, 2) if total_att else 0.0,
        "conversao_pct": round(att_com_venda / total_att * 100, 1) if total_att else 0.0,
        "total_vendido_cents": total_cents,
        "ticket_medio_cents": round(total_cents / att_com_venda) if att_com_venda else 0,
    }


@router.get("/proactivity")
async def proactivity_report(
    store_id: Optional[str] = None,
    seller_id: Optional[str] = None,
    date_start: Optional[str] = None,
    date_end: Optional[str] = None,
    limit: int = 200,
    ctx: dict = Depends(resolve_tenant_context),
):
    """Relatório de proatividade — KPIs completos."""
    await require_feature(ctx["tenant"]["id"], "abordagem_proativa")
    role = ctx["membership"]["role"]
    from permissions import ROLE_PERMISSIONS, P_PROACTIVITY_REPORTS_VIEW, P_PROACTIVITY_VIEW_SELF, P_PROACTIVITY_VIEW_STORE, P_PROACTIVITY_VIEW_TENANT
    view_perms = (P_PROACTIVITY_REPORTS_VIEW, P_PROACTIVITY_VIEW_SELF, P_PROACTIVITY_VIEW_STORE, P_PROACTIVITY_VIEW_TENANT)
    if not any(p in ROLE_PERMISSIONS.get(role, []) for p in view_perms):
        raise HTTPException(status_code=403, detail="Sem permissão para relatório de proatividade.")

    import proactive_approach_service as psvc
    filters = {
        "store_id": store_id,
        "seller_id": seller_id,
        "date_from": date_start,
        "date_to": date_end,
    }
    summary = await psvc.get_proactivity_summary(
        tenant_id=ctx["tenant"]["id"],
        actor_user_id=ctx["user"]["id"],
        membership=ctx["membership"],
        filters=filters,
    )

    # Enrich by_seller with seller names
    seller_ids = list(summary.get("by_seller", {}).keys())
    seller_names: dict = {}
    if seller_ids:
        async for sp in db.seller_profiles.find({"id": {"$in": seller_ids}}):
            u = await db.users.find_one({"id": sp.get("user_id", "")})
            seller_names[sp["id"]] = u.get("name", "—") if u else "—"

    by_seller_list = []
    for sid, data in summary.get("by_seller", {}).items():
        conv_pct = round(data["sales"] / data["total"] * 100) if data["total"] else 0
        by_seller_list.append({
            "seller_id": sid,
            "seller_name": seller_names.get(sid, "—"),
            "total_approaches": data["total"],
            "sales": data["sales"],
            "conversion_pct": conv_pct,
        })
    by_seller_list.sort(key=lambda x: x["total_approaches"], reverse=True)

    # Enrich loss reasons
    lr_ids = list(summary.get("loss_reason_counts", {}).keys())
    lr_names: dict = {}
    if lr_ids:
        async for lr in db.loss_reasons.find({"id": {"$in": lr_ids}}):
            lr_names[lr["id"]] = lr.get("name", "—")

    loss_reasons_list = [
        {"loss_reason_id": lid, "name": lr_names.get(lid, "—"), "count": cnt}
        for lid, cnt in summary.get("loss_reason_counts", {}).items()
    ]
    loss_reasons_list.sort(key=lambda x: x["count"], reverse=True)

    return {
        **summary,
        "by_seller": by_seller_list,
        "loss_reasons": loss_reasons_list,
        "source_breakdown": [
            {"source": s, "count": c}
            for s, c in summary.get("source_counts", {}).items()
        ],
    }
