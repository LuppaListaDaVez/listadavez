"""DataSubjectExportService — Portabilidade de dados (Etapa 14)."""
import json
from db import db
from models import new_id, utcnow_iso
from audit import log_audit
from data_access_log_service import log_data_access
from datetime import datetime, timezone, timedelta


EXPORT_EXPIRES_HOURS = 24


async def create_export(tenant_id: str, subject_user_id: str, created_by: str,
                        file_format: str = "JSON", request=None) -> dict:
    """Gera exportação de dados do titular. Não inclui secrets/tokens/senhas."""
    now = utcnow_iso()
    expires_at = (datetime.now(timezone.utc) + timedelta(hours=EXPORT_EXPIRES_HOURS)).isoformat()
    
    doc = {
        "id": new_id(), "tenant_id": tenant_id, "request_id": None,
        "subject_type": "USER", "subject_user_id": subject_user_id,
        "subject_customer_ref": None, "status": "RUNNING",
        "file_path": None, "file_format": file_format,
        "expires_at": expires_at, "downloaded_at": None,
        "created_by": created_by, "created_at": now, "finished_at": None,
        "error_code": None, "error_message": None,
    }
    await db.data_subject_exports.insert_one(doc)
    export_id = doc["id"]
    
    try:
        # Coletar dados do titular — SEM password_hash, tokens, refresh_tokens
        user = await db.users.find_one({"id": subject_user_id})
        if user:
            user.pop("_id", None)
            user.pop("password_hash", None)
        
        membership = await db.tenant_memberships.find_one(
            {"user_id": subject_user_id, "tenant_id": tenant_id}
        )
        if membership:
            membership.pop("_id", None)
        
        seller_profile = await db.seller_profiles.find_one(
            {"user_id": subject_user_id, "tenant_id": tenant_id}
        )
        if seller_profile:
            seller_profile.pop("_id", None)
        
        # Últimos 100 atendimentos
        attendances = await db.attendances.find(
            {"tenant_id": tenant_id, "seller_id": subject_user_id},
            {"_id": 0}
        ).sort("created_at", -1).limit(100).to_list(length=100)
        
        # Últimas 50 vendas
        sales = await db.sales.find(
            {"tenant_id": tenant_id, "seller_id": subject_user_id},
            {"_id": 0, "customer_phone": 0, "customer_email": 0}
        ).sort("created_at", -1).limit(50).to_list(length=50)
        
        # Notificações (não sensíveis)
        notifications = await db.notifications.find(
            {"tenant_id": tenant_id, "user_id": subject_user_id},
            {"_id": 0}
        ).sort("created_at", -1).limit(50).to_list(length=50)
        
        # Preferências de notificação
        notif_prefs = await db.notification_preferences.find_one(
            {"user_id": subject_user_id, "tenant_id": tenant_id}
        )
        if notif_prefs:
            notif_prefs.pop("_id", None)
        
        export_data = {
            "export_metadata": {
                "export_id": export_id,
                "tenant_id": tenant_id,
                "generated_at": now,
                "subject_user_id": subject_user_id,
                "expires_at": expires_at,
            },
            "user_profile": user,
            "tenant_membership": membership,
            "seller_profile": seller_profile,
            "notification_preferences": notif_prefs,
            "recent_attendances": attendances,
            "recent_sales": sales,
            "notifications": notifications,
        }
        
        # Armazenar conteúdo como string JSON no MongoDB
        content_str = json.dumps(export_data, ensure_ascii=False, default=str)
        file_path = f"exports/{tenant_id}/{export_id}.json"
        
        await db.data_subject_exports.update_one(
            {"id": export_id},
            {"$set": {
                "status": "READY", "file_path": file_path,
                "finished_at": utcnow_iso(), "_content": content_str,
            }}
        )
        await log_audit(action="DATA_SUBJECT_EXPORT_CREATED", entity="data_subject_export",
                        entity_id=export_id, tenant_id=tenant_id, user_id=created_by, request=request)
        await log_data_access(tenant_id=tenant_id, actor_user_id=created_by,
                              access_type="EXPORT", entity="user",
                              entity_id=subject_user_id, data_category="USER_ACCOUNT", request=request)
        doc.update({"status": "READY", "file_path": file_path, "finished_at": utcnow_iso()})
    except Exception as e:
        await db.data_subject_exports.update_one(
            {"id": export_id},
            {"$set": {"status": "FAILED", "error_message": str(e)[:200], "finished_at": utcnow_iso()}}
        )
        doc.update({"status": "FAILED"})
    
    doc.pop("_id", None)
    return doc


async def get_export(tenant_id: str, export_id: str) -> dict | None:
    doc = await db.data_subject_exports.find_one({"id": export_id, "tenant_id": tenant_id})
    if not doc:
        return None
    doc.pop("_id", None)
    doc.pop("_content", None)  # Não retornar conteúdo no summary
    return doc


async def download_export(tenant_id: str, export_id: str, actor_id: str, request=None) -> dict | None:
    """Retorna conteúdo para download. Registra acesso e valida expiração."""
    from datetime import datetime, timezone
    doc = await db.data_subject_exports.find_one({"id": export_id, "tenant_id": tenant_id})
    if not doc:
        return None
    if doc.get("status") not in ("READY", "DOWNLOADED"):
        return None
    if doc.get("expires_at") and doc["expires_at"] < datetime.now(timezone.utc).isoformat():
        await db.data_subject_exports.update_one({"id": export_id}, {"$set": {"status": "EXPIRED"}})
        return None
    
    now = utcnow_iso()
    await db.data_subject_exports.update_one(
        {"id": export_id},
        {"$set": {"status": "DOWNLOADED", "downloaded_at": now}}
    )
    await log_audit(action="DATA_SUBJECT_EXPORT_DOWNLOADED", entity="data_subject_export",
                    entity_id=export_id, tenant_id=tenant_id, user_id=actor_id, request=request)
    
    content = doc.get("_content", "{}")
    doc.pop("_id", None)
    doc.pop("_content", None)
    return {"metadata": doc, "content": content}


async def list_exports(tenant_id: str, limit: int = 20) -> list:
    cursor = db.data_subject_exports.find(
        {"tenant_id": tenant_id}, {"_id": 0, "_content": 0}
    ).sort("created_at", -1).limit(limit)
    return await cursor.to_list(length=limit)


async def expire_export(tenant_id: str, export_id: str) -> bool:
    result = await db.data_subject_exports.update_one(
        {"id": export_id, "tenant_id": tenant_id},
        {"$set": {"status": "EXPIRED", "updated_at": utcnow_iso()}}
    )
    return result.modified_count > 0
