"""Export Job Service — P1 Exportações Assíncronas.

Jobs assíncronos de geração de CSV:
- Cria job QUEUED no MongoDB
- Worker em background processa QUEUED → PROCESSING → DONE/FAILED
- Arquivo CSV gravado em /tmp/exports/
- Expiração automática após 24h

Fluxo:
  POST /export/async → job {status: "QUEUED"}
  GET  /export/jobs/{id} → {status, row_count, filename}
  GET  /export/jobs/{id}/download → StreamingResponse CSV
"""
import asyncio
import csv
import io
import logging
import os
from datetime import datetime, timezone, timedelta
from typing import Optional

from db import db
from models import new_id

logger = logging.getLogger("lista-da-vez.export_jobs")

EXPORT_DIR = "/tmp/exports"
JOB_TTL_HOURS = 24
DISPATCH_INTERVAL_SECONDS = 5
MAX_ROWS = 50_000


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


# ── CRUD de jobs ──────────────────────────────────────────────────────────────

async def create_export_job(
    *,
    tenant_id: str,
    requested_by: str,
    report_type: str,
    filters: dict,
) -> dict:
    """Cria job QUEUED. filters deve incluir accessible_store_ids já resolvido."""
    os.makedirs(EXPORT_DIR, exist_ok=True)
    job_id = new_id()
    doc = {
        "id": job_id,
        "tenant_id": tenant_id,
        "requested_by": requested_by,
        "report_type": report_type,
        "filters": filters,
        "status": "QUEUED",
        "file_path": None,
        "filename": None,
        "row_count": None,
        "error": None,
        "created_at": _now_iso(),
        "started_at": None,
        "finished_at": None,
        "expires_at": (datetime.now(timezone.utc) + timedelta(hours=JOB_TTL_HOURS)).isoformat(),
    }
    await db.export_jobs.insert_one(doc)
    logger.info("EXPORT_JOB_CREATED id=%s type=%s tenant=%s", job_id[:8], report_type, tenant_id[:8])
    return doc


async def get_export_job(job_id: str, tenant_id: str) -> Optional[dict]:
    return await db.export_jobs.find_one({"id": job_id, "tenant_id": tenant_id})


async def list_export_jobs(tenant_id: str, requested_by: str, limit: int = 10) -> list:
    cursor = db.export_jobs.find(
        {"tenant_id": tenant_id, "requested_by": requested_by}
    ).sort("created_at", -1).limit(limit)
    return await cursor.to_list(limit)


# ── Helpers de formatação ─────────────────────────────────────────────────────

def _fmt_cents(cents: int) -> str:
    return f"R$ {cents / 100:.2f}".replace(".", ",")


def _fmt_date(iso: Optional[str]) -> str:
    if not iso:
        return ""
    try:
        dt = datetime.fromisoformat(iso.replace("Z", "+00:00"))
        return dt.strftime("%d/%m/%Y %H:%M")
    except Exception:
        return iso


def _fmt_duration(seconds: int) -> str:
    if not seconds:
        return "0 min"
    m, s = divmod(seconds, 60)
    if m < 60:
        return f"{m}m {s}s"
    h, m = divmod(m, 60)
    return f"{h}h {m}m"


async def _get_seller_name_map(seller_ids: list) -> dict:
    names: dict = {}
    async for sp in db.seller_profiles.find({"id": {"$in": seller_ids}}):
        user = await db.users.find_one({"id": sp.get("user_id", "")})
        names[sp["id"]] = user.get("name", "—") if user else "—"
    return names


async def _get_store_name_map(store_ids: list) -> dict:
    names: dict = {}
    async for s in db.stores.find({"id": {"$in": store_ids}}):
        names[s["id"]] = s.get("name", "—")
    return names


# ── Geradores de dados ────────────────────────────────────────────────────────

async def _gen_attendances(tenant_id: str, filters: dict):
    store_ids = filters.get("accessible_store_ids", [])
    q: dict = {"tenant_id": tenant_id, "store_id": {"$in": store_ids}}
    if filters.get("date_start") or filters.get("date_end"):
        df = {}
        if filters.get("date_start"):
            df["$gte"] = filters["date_start"]
        if filters.get("date_end"):
            df["$lte"] = filters["date_end"] + "T23:59:59.999999+00:00"
        q["created_at"] = df
    if filters.get("seller_filter_id"):
        q["seller_id"] = filters["seller_filter_id"]
    elif filters.get("seller_id"):
        q["seller_id"] = filters["seller_id"]
    if filters.get("result"):
        q["result"] = filters["result"]

    raw = await db.attendances.find(q).sort("created_at", -1).limit(MAX_ROWS).to_list(MAX_ROWS)
    seller_names = await _get_seller_name_map(list({a["seller_id"] for a in raw}))
    store_names = await _get_store_name_map(list({a["store_id"] for a in raw}))
    lr_ids = [a.get("loss_reason_id") for a in raw if a.get("loss_reason_id")]
    lr_names: dict = {}
    if lr_ids:
        async for lr in db.loss_reasons.find({"id": {"$in": lr_ids}}):
            lr_names[lr["id"]] = lr.get("name", "—")

    rows = []
    now_str = datetime.now().strftime("%Y%m%d_%H%M")
    for a in raw:
        dur_secs = 0
        if a.get("started_at") and a.get("finished_at"):
            try:
                s_dt = datetime.fromisoformat(a["started_at"].replace("Z", "+00:00"))
                f_dt = datetime.fromisoformat(a["finished_at"].replace("Z", "+00:00"))
                dur_secs = int((f_dt - s_dt).total_seconds())
            except Exception:
                pass
        rows.append({
            "ID": a["id"],
            "Unidade": store_names.get(a["store_id"], "—"),
            "Vendedor": seller_names.get(a["seller_id"], "—"),
            "Status": a.get("status", ""),
            "Resultado": a.get("result", ""),
            "Valor Venda": _fmt_cents(a.get("sale_amount_cents") or 0),
            "Motivo Perda": lr_names.get(a.get("loss_reason_id", ""), a.get("loss_reason_text") or ""),
            "Obs": a.get("notes", ""),
            "Inicio": _fmt_date(a.get("created_at")),
            "Atendimento Iniciado": _fmt_date(a.get("started_at")),
            "Finalizado": _fmt_date(a.get("finished_at")),
            "Duracao": f"{dur_secs // 60}m {dur_secs % 60}s" if dur_secs else "",
        })
    return rows, f"atendimentos_{now_str}.csv"


async def _gen_conversion(tenant_id: str, filters: dict):
    store_ids = filters.get("accessible_store_ids", [])
    q: dict = {"tenant_id": tenant_id, "store_id": {"$in": store_ids}, "status": "FINISHED"}
    if filters.get("date_start") or filters.get("date_end"):
        df = {}
        if filters.get("date_start"):
            df["$gte"] = filters["date_start"]
        if filters.get("date_end"):
            df["$lte"] = filters["date_end"] + "T23:59:59.999999+00:00"
        q["created_at"] = df
    if filters.get("seller_filter_id"):
        q["seller_id"] = filters["seller_filter_id"]

    raw = await db.attendances.find(q).to_list(MAX_ROWS)
    seller_names = await _get_seller_name_map(list({a["seller_id"] for a in raw}))

    perf: dict = {}
    for a in raw:
        sid = a["seller_id"]
        if sid not in perf:
            perf[sid] = {"Vendedor": seller_names.get(sid, "—"), "Atendimentos": 0, "Vendas": 0, "Total Vendido": 0}
        perf[sid]["Atendimentos"] += 1
        if a.get("result") == "SALE":
            perf[sid]["Vendas"] += 1
            perf[sid]["Total Vendido"] += a.get("sale_amount_cents") or 0

    rows = []
    for d in sorted(perf.values(), key=lambda x: x["Vendas"], reverse=True):
        rows.append({
            "Vendedor": d["Vendedor"],
            "Atendimentos": d["Atendimentos"],
            "Vendas": d["Vendas"],
            "Conversao (%)": f"{round(d['Vendas'] / d['Atendimentos'] * 100)}%" if d["Atendimentos"] else "0%",
            "Total Vendido": _fmt_cents(d["Total Vendido"]),
            "Ticket Medio": _fmt_cents(round(d["Total Vendido"] / d["Vendas"])) if d["Vendas"] else "R$ 0,00",
        })
    now_str = datetime.now().strftime("%Y%m%d_%H%M")
    return rows, f"conversao_{now_str}.csv"


async def _gen_loss_reasons(tenant_id: str, filters: dict):
    store_ids = filters.get("accessible_store_ids", [])
    q: dict = {"tenant_id": tenant_id, "store_id": {"$in": store_ids}, "result": "NO_SALE", "status": "FINISHED"}
    if filters.get("date_start") or filters.get("date_end"):
        df = {}
        if filters.get("date_start"):
            df["$gte"] = filters["date_start"]
        if filters.get("date_end"):
            df["$lte"] = filters["date_end"] + "T23:59:59.999999+00:00"
        q["created_at"] = df
    if filters.get("seller_filter_id"):
        q["seller_id"] = filters["seller_filter_id"]

    raw = await db.attendances.find(q).to_list(MAX_ROWS)
    counts: dict = {}
    for a in raw:
        lr_id = a.get("loss_reason_id")
        if lr_id:
            counts[lr_id] = counts.get(lr_id, 0) + 1
        else:
            key = f"__t__{a.get('loss_reason_text') or a.get('notes') or 'Sem motivo'}"
            counts[key] = counts.get(key, 0) + 1

    lr_ids = [k for k in counts if not k.startswith("__t__")]
    lr_names: dict = {}
    if lr_ids:
        async for lr in db.loss_reasons.find({"id": {"$in": lr_ids}}):
            lr_names[lr["id"]] = lr.get("name", "—")

    total = sum(counts.values())
    rows = []
    for key, count in sorted(counts.items(), key=lambda x: -x[1]):
        name = key[5:] if key.startswith("__t__") else lr_names.get(key, "—")
        rows.append({
            "Motivo": name,
            "Ocorrencias": count,
            "Percentual (%)": f"{round(count / total * 100)}%" if total else "0%",
        })
    now_str = datetime.now().strftime("%Y%m%d_%H%M")
    return rows, f"motivos_perda_{now_str}.csv"


async def _gen_seller_performance(tenant_id: str, filters: dict):
    store_ids = filters.get("accessible_store_ids", [])
    q: dict = {"tenant_id": tenant_id, "store_id": {"$in": store_ids}, "status": "FINISHED"}
    if filters.get("date_start") or filters.get("date_end"):
        df = {}
        if filters.get("date_start"):
            df["$gte"] = filters["date_start"]
        if filters.get("date_end"):
            df["$lte"] = filters["date_end"] + "T23:59:59.999999+00:00"
        q["created_at"] = df
    if filters.get("seller_filter_id"):
        q["seller_id"] = filters["seller_filter_id"]

    raw = await db.attendances.find(q).to_list(MAX_ROWS)
    seller_names = await _get_seller_name_map(list({a["seller_id"] for a in raw}))

    perf: dict = {}
    for a in raw:
        sid = a["seller_id"]
        if sid not in perf:
            perf[sid] = {"Vendedor": seller_names.get(sid, "—"), "Atendimentos": 0, "Vendas": 0, "Total Vendido": 0, "_durs": []}
        perf[sid]["Atendimentos"] += 1
        if a.get("result") == "SALE":
            perf[sid]["Vendas"] += 1
            perf[sid]["Total Vendido"] += a.get("sale_amount_cents") or 0
        if a.get("started_at") and a.get("finished_at"):
            try:
                s_dt = datetime.fromisoformat(a["started_at"].replace("Z", "+00:00"))
                f_dt = datetime.fromisoformat(a["finished_at"].replace("Z", "+00:00"))
                d = (f_dt - s_dt).total_seconds()
                if d > 0:
                    perf[sid]["_durs"].append(d)
            except Exception:
                pass

    rows = []
    for d in sorted(perf.values(), key=lambda x: x["Vendas"], reverse=True):
        durs = d.pop("_durs")
        rows.append({
            "Vendedor": d["Vendedor"],
            "Atendimentos": d["Atendimentos"],
            "Vendas": d["Vendas"],
            "Conversao (%)": f"{round(d['Vendas'] / d['Atendimentos'] * 100)}%" if d["Atendimentos"] else "0%",
            "Total Vendido": _fmt_cents(d["Total Vendido"]),
            "Ticket Medio": _fmt_cents(round(d["Total Vendido"] / d["Vendas"])) if d["Vendas"] else "R$ 0,00",
            "Tempo Medio Atendimento": _fmt_duration(round(sum(durs) / len(durs))) if durs else "—",
        })
    now_str = datetime.now().strftime("%Y%m%d_%H%M")
    return rows, f"performance_vendedores_{now_str}.csv"


async def _gen_products(tenant_id: str, filters: dict):
    store_ids = filters.get("accessible_store_ids", [])
    sales_q: dict = {"tenant_id": tenant_id, "store_id": {"$in": store_ids}, "status": "COMPLETED"}
    if filters.get("date_start") or filters.get("date_end"):
        df = {}
        if filters.get("date_start"):
            df["$gte"] = filters["date_start"]
        if filters.get("date_end"):
            df["$lte"] = filters["date_end"] + "T23:59:59.999999+00:00"
        sales_q["created_at"] = df

    sales_raw = await db.sales.find(sales_q).to_list(MAX_ROWS)
    sale_ids = [s["id"] for s in sales_raw]
    now_str = datetime.now().strftime("%Y%m%d_%H%M")
    if not sale_ids:
        return [], f"produtos_{now_str}.csv"

    sale_items = await db.sale_items.find({"sale_id": {"$in": sale_ids}}).to_list(MAX_ROWS * 10)
    product_ids = list({i["product_id"] for i in sale_items if i.get("product_id")})
    prod_names: dict = {}
    if product_ids:
        async for p in db.products.find({"id": {"$in": product_ids}}):
            prod_names[p["id"]] = p.get("name", "—")

    agg: dict = {}
    for item in sale_items:
        pid = item.get("product_id") or f"__t_{item.get('name', '?')}"
        name = item.get("name") or prod_names.get(item.get("product_id", ""), "—")
        if pid not in agg:
            agg[pid] = {"Produto": name, "Quantidade Vendida": 0, "Total Arrecadado": 0}
        agg[pid]["Quantidade Vendida"] += item.get("quantity", 1)
        net = (item.get("unit_price_cents") or 0) * item.get("quantity", 1) - (item.get("discount_cents") or 0)
        agg[pid]["Total Arrecadado"] += net

    rows = []
    for d in sorted(agg.values(), key=lambda x: x["Quantidade Vendida"], reverse=True):
        rows.append({
            "Produto": d["Produto"],
            "Quantidade Vendida": d["Quantidade Vendida"],
            "Total Arrecadado": _fmt_cents(d["Total Arrecadado"]),
        })
    return rows, f"produtos_{now_str}.csv"


async def _gen_proactivity(tenant_id: str, filters: dict):
    store_ids = filters.get("accessible_store_ids", [])
    q: dict = {"tenant_id": tenant_id, "store_id": {"$in": store_ids}}
    if filters.get("date_start") or filters.get("date_end"):
        df = {}
        if filters.get("date_start"):
            df["$gte"] = filters["date_start"]
        if filters.get("date_end"):
            df["$lte"] = filters["date_end"] + "T23:59:59.999999+00:00"
        q["started_at"] = df
    if filters.get("seller_filter_id"):
        q["seller_id"] = filters["seller_filter_id"]
    elif filters.get("seller_id"):
        q["seller_id"] = filters["seller_id"]

    raw = await db.proactive_approaches.find(q).sort("created_at", -1).limit(MAX_ROWS).to_list(MAX_ROWS)
    seller_names = await _get_seller_name_map(list({a["seller_id"] for a in raw}))
    store_names = await _get_store_name_map(list({a.get("store_id") for a in raw if a.get("store_id")}))
    lr_ids = [a.get("loss_reason_id") for a in raw if a.get("loss_reason_id")]
    lr_names: dict = {}
    if lr_ids:
        async for lr in db.loss_reasons.find({"id": {"$in": lr_ids}}):
            lr_names[lr["id"]] = lr.get("name", "—")

    STATUS_PT = {
        "OPEN": "Aberta",
        "CONVERTED_TO_ATTENDANCE": "Convertida p/ Atendimento",
        "CONVERTED_TO_SALE": "Convertida p/ Venda",
        "NO_SALE": "Sem Venda",
        "CANCELLED": "Cancelada",
    }
    rows = []
    for a in raw:
        rows.append({
            "ID": a["id"],
            "Vendedor": seller_names.get(a["seller_id"], "—"),
            "Unidade": store_names.get(a.get("store_id", ""), "—"),
            "Status": STATUS_PT.get(a.get("status", ""), a.get("status", "")),
            "Resultado": a.get("result", ""),
            "Fonte": a.get("source", ""),
            "Tipo": a.get("approach_type", ""),
            "Cliente": a.get("customer_name") or "",
            "Motivo Perda": lr_names.get(a.get("loss_reason_id", ""), ""),
            "Obs": a.get("notes") or "",
            "Iniciada em": _fmt_date(a.get("started_at")),
            "Convertida em": _fmt_date(a.get("converted_at")),
            "Encerrada em": _fmt_date(a.get("closed_at")),
        })
    now_str = datetime.now().strftime("%Y%m%d_%H%M")
    return rows, f"proatividade_{now_str}.csv"


GENERATORS = {
    "attendances": _gen_attendances,
    "conversion": _gen_conversion,
    "loss-reasons": _gen_loss_reasons,
    "seller-performance": _gen_seller_performance,
    "products": _gen_products,
    "proactivity": _gen_proactivity,
}

REPORT_TYPES = set(GENERATORS.keys())


# ── Processamento de jobs ─────────────────────────────────────────────────────

async def _process_job(job: dict):
    job_id = job["id"]
    tenant_id = job["tenant_id"]
    report_type = job["report_type"]
    filters = job.get("filters") or {}

    await db.export_jobs.update_one(
        {"id": job_id},
        {"$set": {"status": "PROCESSING", "started_at": _now_iso()}},
    )
    try:
        generator = GENERATORS.get(report_type)
        if not generator:
            raise ValueError(f"Tipo de relatório desconhecido: {report_type}")

        rows, filename = await generator(tenant_id, filters)

        os.makedirs(EXPORT_DIR, exist_ok=True)
        file_path = os.path.join(EXPORT_DIR, f"{job_id}_{filename}")

        with open(file_path, "w", newline="", encoding="utf-8") as fh:
            if rows:
                writer = csv.DictWriter(fh, fieldnames=list(rows[0].keys()), extrasaction="ignore")
                writer.writeheader()
                writer.writerows(rows)
            else:
                fh.write("Sem dados para exportar\n")

        await db.export_jobs.update_one(
            {"id": job_id},
            {"$set": {
                "status": "DONE",
                "file_path": file_path,
                "filename": filename,
                "row_count": len(rows),
                "finished_at": _now_iso(),
            }},
        )
        logger.info("EXPORT_JOB_DONE id=%s type=%s rows=%d", job_id[:8], report_type, len(rows))

    except Exception as exc:
        logger.error("EXPORT_JOB_FAILED id=%s: %s", job_id[:8], exc, exc_info=True)
        await db.export_jobs.update_one(
            {"id": job_id},
            {"$set": {"status": "FAILED", "error": str(exc)[:500], "finished_at": _now_iso()}},
        )


async def dispatch_pending_jobs():
    jobs = await db.export_jobs.find({"status": "QUEUED"}).sort("created_at", 1).limit(5).to_list(5)
    for job in jobs:
        await _process_job(job)


async def cleanup_expired_jobs():
    threshold = _now_iso()
    expired = await db.export_jobs.find({
        "status": {"$in": ["DONE", "FAILED"]},
        "expires_at": {"$lt": threshold},
    }).to_list(100)

    for job in expired:
        fp = job.get("file_path")
        if fp and os.path.exists(fp):
            try:
                os.remove(fp)
            except Exception:
                pass

    if expired:
        ids = [j["id"] for j in expired]
        await db.export_jobs.delete_many({"id": {"$in": ids}})
        logger.info("EXPORT_CLEANUP deleted=%d", len(expired))


async def run_export_dispatcher():
    """Background task: processa jobs de exportação a cada 5s."""
    logger.info("EXPORT_DISPATCHER_STARTED interval=%ds", DISPATCH_INTERVAL_SECONDS)
    cleanup_counter = 0
    while True:
        try:
            await dispatch_pending_jobs()
            cleanup_counter += 1
            if cleanup_counter >= 720:  # ~1h
                await cleanup_expired_jobs()
                cleanup_counter = 0
        except Exception as exc:
            logger.error("EXPORT_DISPATCHER_ERROR: %s", exc)
        await asyncio.sleep(DISPATCH_INTERVAL_SECONDS)
