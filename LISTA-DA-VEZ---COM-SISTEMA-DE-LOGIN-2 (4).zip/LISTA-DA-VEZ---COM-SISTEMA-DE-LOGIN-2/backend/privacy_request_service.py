"""PrivacyRequestService — Solicitações LGPD (Etapa 14)."""
from typing import Optional
from db import db
from models import new_id, utcnow_iso
from audit import log_audit


async def create_request(tenant_id: str, data: dict, created_by: str, request=None) -> dict:
    now = utcnow_iso()
    doc = {
        "id": new_id(),
        "tenant_id": tenant_id,
        "request_type": data.get("request_type", "ACCESS"),
        "requester_type": data.get("requester_type", "SELF"),
        "requester_user_id": created_by,
        "data_subject_type": data.get("data_subject_type", "USER"),
        "data_subject_user_id": data.get("data_subject_user_id"),
        "data_subject_customer_ref": data.get("data_subject_customer_ref"),
        "data_subject_name": data.get("data_subject_name"),
        "data_subject_email": data.get("data_subject_email"),
        "data_subject_phone": data.get("data_subject_phone"),
        "status": "OPEN",
        "priority": data.get("priority", "NORMAL"),
        "description": data.get("description", ""),
        "assigned_to": None,
        "resolution_notes": None,
        "resolved_at": None,
        "rejected_reason": None,
        "created_by": created_by,
        "created_at": now,
        "updated_at": now,
        "due_at": data.get("due_at"),
    }
    await db.privacy_requests.insert_one(doc)
    doc.pop("_id", None)
    await log_audit(action="PRIVACY_REQUEST_CREATED", entity="privacy_request",
                    entity_id=doc["id"], tenant_id=tenant_id, user_id=created_by, request=request)
    return doc


async def list_requests(tenant_id: str, user_id: str, role: str,
                        status: Optional[str] = None, request_type: Optional[str] = None,
                        limit: int = 50) -> list:
    filt = {"tenant_id": tenant_id}
    # SELLER só vê próprias solicitações
    if role == "SELLER":
        filt["requester_user_id"] = user_id
    if status:
        filt["status"] = status
    if request_type:
        filt["request_type"] = request_type
    cursor = db.privacy_requests.find(filt, {"_id": 0}).sort("created_at", -1).limit(limit)
    return await cursor.to_list(length=limit)


async def get_request(tenant_id: str, request_id: str, user_id: str, role: str) -> Optional[dict]:
    doc = await db.privacy_requests.find_one({"id": request_id, "tenant_id": tenant_id})
    if not doc:
        return None
    if role == "SELLER" and doc.get("requester_user_id") != user_id:
        return None
    doc.pop("_id", None)
    return doc


async def update_status(tenant_id: str, request_id: str, new_status: str,
                        user_id: str, notes: str = "", request=None) -> Optional[dict]:
    doc = await db.privacy_requests.find_one({"id": request_id, "tenant_id": tenant_id})
    if not doc:
        return None
    now = utcnow_iso()
    upd = {"status": new_status, "updated_at": now}
    if new_status in ("RESOLVED", "REJECTED"):
        upd["resolved_at"] = now
        upd["resolution_notes"] = notes
    if new_status == "REJECTED":
        upd["rejected_reason"] = notes
    await db.privacy_requests.update_one({"id": request_id}, {"$set": upd})
    await log_audit(action=f"PRIVACY_REQUEST_{new_status}", entity="privacy_request",
                    entity_id=request_id, tenant_id=tenant_id, user_id=user_id,
                    new_value={"status": new_status, "notes": notes}, request=request)
    doc.update(upd)
    doc.pop("_id", None)
    return doc


async def assign_request(tenant_id: str, request_id: str, assigned_to: str,
                         user_id: str, request=None) -> Optional[dict]:
    doc = await db.privacy_requests.find_one({"id": request_id, "tenant_id": tenant_id})
    if not doc:
        return None
    now = utcnow_iso()
    await db.privacy_requests.update_one(
        {"id": request_id}, {"$set": {"assigned_to": assigned_to, "updated_at": now}}
    )
    await log_audit(action="PRIVACY_REQUEST_ASSIGNED", entity="privacy_request",
                    entity_id=request_id, tenant_id=tenant_id, user_id=user_id,
                    new_value={"assigned_to": assigned_to}, request=request)
    doc.update({"assigned_to": assigned_to, "updated_at": now})
    doc.pop("_id", None)
    return doc


async def get_stats(tenant_id: str) -> dict:
    total = await db.privacy_requests.count_documents({"tenant_id": tenant_id})
    open_c = await db.privacy_requests.count_documents({"tenant_id": tenant_id, "status": "OPEN"})
    resolved = await db.privacy_requests.count_documents({"tenant_id": tenant_id, "status": "RESOLVED"})
    in_review = await db.privacy_requests.count_documents({"tenant_id": tenant_id, "status": "IN_REVIEW"})
    return {"total": total, "open": open_c, "in_review": in_review, "resolved": resolved}
