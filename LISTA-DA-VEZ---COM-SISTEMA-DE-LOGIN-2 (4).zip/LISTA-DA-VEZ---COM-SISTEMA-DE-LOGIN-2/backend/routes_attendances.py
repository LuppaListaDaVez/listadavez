"""Atendimentos (P0) — paginação e rate limit."""
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request

from db import db
from models import AttendanceCancelRequest
from rate_limit_service import make_rate_limit_dep
from security import resolve_tenant_context
from feature_guard import require_feature
import queue_engine as qe

router = APIRouter(prefix="/tenants/{tenant_slug}/attendances", tags=["attendances"])

MANAGER_ROLES = {"TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER"}

_rl_cancel = make_rate_limit_dep("ATTENDANCE_CANCEL")


def _store_allowed(membership, store_id):
    if membership["role"] in {"TENANT_ADMIN", "REGIONAL_MANAGER"}:
        return True
    return store_id in (membership.get("store_ids") or [])


async def _enrich(items):
    seller_ids = [a["seller_id"] for a in items]
    sellers = {}
    if seller_ids:
        async for s in db.seller_profiles.find({"id": {"$in": seller_ids}}):
            sellers[s["id"]] = s
    users = {}
    if sellers:
        async for u in db.users.find({"id": {"$in": [s["user_id"] for s in sellers.values()]}}):
            users[u["id"]] = u
    stores = {}
    store_ids = list({a["store_id"] for a in items})
    if store_ids:
        async for st in db.stores.find({"id": {"$in": store_ids}}):
            stores[st["id"]] = st
    visits = {}
    visit_ids = [a.get("customer_visit_id") for a in items if a.get("customer_visit_id")]
    if visit_ids:
        async for v in db.customer_visits.find({"id": {"$in": visit_ids}}):
            visits[v["id"]] = v
    out = []
    for a in items:
        a.pop("_id", None)
        s = sellers.get(a["seller_id"], {})
        u = users.get(s.get("user_id"), {}) if s else {}
        out.append({
            **a,
            "seller_name": u.get("name"),
            "seller_avatar_url": u.get("avatar_url") or s.get("avatar_url"),
            "store_name": stores.get(a["store_id"], {}).get("name"),
            "customer_name": visits.get(a.get("customer_visit_id"), {}).get("customer_name"),
            "product_quantity": a.get("product_quantity") or 0,
            "is_preference": a.get("is_preference", False),
            "attendance_type": a.get("attendance_type") or a.get("origin") or a.get("source"),
            "preference_return_rule": a.get("preference_return_rule_applied") or a.get("preference_return_rule"),
        })
    return out


@router.get("")
async def list_attendances(
    status: Optional[str] = None,
    store_id: Optional[str] = None,
    page: int = 1,
    page_size: int = 50,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "lista_da_vez")
    tenant_id = ctx["tenant"]["id"]
    role = ctx["membership"]["role"]

    page = max(1, page)
    page_size = min(max(1, page_size), 100)
    skip = (page - 1) * page_size

    q: dict = {"tenant_id": tenant_id}
    if status:
        q["status"] = status
    if store_id:
        q["store_id"] = store_id
    if role in {"REGIONAL_MANAGER", "STORE_MANAGER", "SUPERVISOR"}:
        store_ids = ctx["membership"].get("store_ids") or []
        if store_ids:
            if store_id and store_id not in store_ids:
                return {"items": [], "pagination": {"page": page, "page_size": page_size, "total": 0, "has_next": False}}
            if not store_id:
                q["store_id"] = {"$in": store_ids}
    elif role == "SELLER":
        own = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": ctx["user"]["id"]})
        q["seller_id"] = own["id"] if own else "__none__"

    total = await db.attendances.count_documents(q)
    raw = await db.attendances.find(q).sort("created_at", -1).skip(skip).limit(page_size).to_list(page_size)
    items = await _enrich(raw)
    return {
        "items": items,
        "pagination": {
            "page": page,
            "page_size": page_size,
            "total": total,
            "has_next": (skip + page_size) < total,
        },
    }


@router.get("/{attendance_id}")
async def get_attendance(attendance_id: str, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "lista_da_vez")
    a = await db.attendances.find_one({"tenant_id": ctx["tenant"]["id"], "id": attendance_id})
    if not a:
        raise HTTPException(status_code=404, detail="Atendimento não encontrado.")
    role = ctx["membership"]["role"]
    if role in {"STORE_MANAGER", "SUPERVISOR"} and not _store_allowed(ctx["membership"], a["store_id"]):
        raise HTTPException(status_code=403, detail="Sem acesso.")
    if role == "SELLER":
        own = await db.seller_profiles.find_one({"tenant_id": ctx["tenant"]["id"], "user_id": ctx["user"]["id"]})
        if not own or a["seller_id"] != own["id"]:
            raise HTTPException(status_code=403, detail="Sem acesso.")
    out = await _enrich([a])
    return out[0]


@router.post("/{attendance_id}/cancel")
async def cancel(attendance_id: str, payload: AttendanceCancelRequest, request: Request,
                 ctx: dict = Depends(resolve_tenant_context),
                 _rl: None = Depends(_rl_cancel)):
    await require_feature(ctx["tenant"]["id"], "lista_da_vez")
    role = ctx["membership"]["role"]
    if role not in MANAGER_ROLES:
        raise HTTPException(status_code=403, detail="Apenas administradores e gerentes podem cancelar atendimentos.")
    a = await db.attendances.find_one({"tenant_id": ctx["tenant"]["id"], "id": attendance_id})
    if not a:
        raise HTTPException(status_code=404, detail="Atendimento não encontrado.")
    if not _store_allowed(ctx["membership"], a["store_id"]):
        raise HTTPException(status_code=403, detail="Sem acesso.")
    return await qe.cancel_attendance(tenant_id=ctx["tenant"]["id"], store_id=a["store_id"], attendance_id=attendance_id,
                                      reason=payload.reason, actor_user_id=ctx["user"]["id"], actor_role=role, request=request)
