"""Domain errors da camada de tenant/usuário."""
from ..base import ConflictError, NotFoundError, ForbiddenError, ValidationError

__all__ = [
    "TenantNotFoundError",
    "TenantSuspendedError",
    "UserNotFoundError",
    "StoreNotFoundError",
    "InsufficientPermissionsError",
    "TenantMismatchError",
]


class TenantNotFoundError(NotFoundError):
    def __init__(self, slug: str = ""):
        super().__init__(entity="Tenant", entity_id=slug)


class TenantSuspendedError(ForbiddenError):
    def __init__(self):
        super().__init__(message="Tenant suspenso ou inativo.")


class UserNotFoundError(NotFoundError):
    def __init__(self, user_id: str = ""):
        super().__init__(entity="Usuário", entity_id=user_id)


class StoreNotFoundError(NotFoundError):
    def __init__(self, store_id: str = ""):
        super().__init__(entity="Loja", entity_id=store_id)


class InsufficientPermissionsError(ForbiddenError):
    def __init__(self, permission: str = ""):
        msg = f"Permissão necessária: {permission}" if permission else "Permissões insuficientes."
        super().__init__(message=msg)


class TenantMismatchError(ForbiddenError):
    def __init__(self):
        super().__init__(message="Acesso negado: tenant mismatch.")
