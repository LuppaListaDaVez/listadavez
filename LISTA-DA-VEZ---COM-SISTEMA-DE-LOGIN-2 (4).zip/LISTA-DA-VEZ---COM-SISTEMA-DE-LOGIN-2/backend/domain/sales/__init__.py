"""Domain errors da camada de vendas."""
from ..base import ConflictError, NotFoundError, ValidationError

__all__ = [
    "SaleNotFoundError",
    "SaleAlreadyCancelledError",
    "InvalidSaleAmountError",
]


class SaleNotFoundError(NotFoundError):
    def __init__(self, sale_id: str = ""):
        super().__init__(entity="Venda", entity_id=sale_id)


class SaleAlreadyCancelledError(ConflictError):
    def __init__(self):
        super().__init__(
            code="SALE_ALREADY_CANCELLED",
            message="Esta venda já foi cancelada.",
        )


class InvalidSaleAmountError(ValidationError):
    def __init__(self):
        super().__init__(
            code="INVALID_SALE_AMOUNT",
            message="Valor da venda deve ser maior que zero.",
        )
