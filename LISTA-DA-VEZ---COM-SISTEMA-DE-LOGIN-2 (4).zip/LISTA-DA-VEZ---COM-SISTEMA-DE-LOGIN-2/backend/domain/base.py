"""Base classes para o domínio.

Entidades de domínio são objetos de valor que encapsulam regras de negócio.
Não dependem de banco nem de frameworks web.
"""
from dataclasses import dataclass, field
from typing import Any, Dict, Optional


class DomainError(Exception):
    """Erro de domínio base — representa violação de regra de negócio."""

    def __init__(self, code: str, message: str, status_code: int = 422):
        super().__init__(message)
        self.code = code
        self.message = message
        self.status_code = status_code

    def to_dict(self) -> Dict[str, Any]:
        return {"error": self.code, "message": self.message}


class NotFoundError(DomainError):
    def __init__(self, entity: str, entity_id: str = ""):
        super().__init__(
            code=f"{entity.upper()}_NOT_FOUND",
            message=f"{entity} não encontrado.",
            status_code=404,
        )
        self.entity = entity
        self.entity_id = entity_id


class ConflictError(DomainError):
    def __init__(self, code: str, message: str):
        super().__init__(code=code, message=message, status_code=409)


class ForbiddenError(DomainError):
    def __init__(self, message: str = "Acesso negado."):
        super().__init__(code="FORBIDDEN", message=message, status_code=403)


class ValidationError(DomainError):
    def __init__(self, code: str, message: str):
        super().__init__(code=code, message=message, status_code=422)


@dataclass(frozen=True)
class TenantId:
    """Value object para ID de tenant."""
    value: str

    def __post_init__(self):
        if not self.value or not isinstance(self.value, str):
            raise ValidationError("INVALID_TENANT_ID", "tenant_id inválido.")

    def __str__(self) -> str:
        return self.value


@dataclass(frozen=True)
class EntityId:
    """Value object genérico para IDs de entidades."""
    value: str

    def __post_init__(self):
        if not self.value or not isinstance(self.value, str):
            raise ValidationError("INVALID_ID", "ID inválido.")

    def __str__(self) -> str:
        return self.value
