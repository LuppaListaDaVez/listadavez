"""Domain errors e entidades da fila (Queue domain)."""
from ..base import DomainError, ConflictError, NotFoundError, ValidationError

__all__ = [
    "QueueConflictError",
    "AttendanceConflictError",
    "SellerNotInQueueError",
    "AttendanceNotFoundError",
    "QueueLockedError",
]


class QueueConflictError(ConflictError):
    """Vendedor já está na fila."""
    def __init__(self):
        super().__init__(
            code="QUEUE_SELLER_ALREADY_IN_QUEUE",
            message="Vendedor já está na fila.",
        )


class AttendanceConflictError(ConflictError):
    """Atendimento já foi iniciado/finalizado por outro processo."""
    def __init__(self, detail: str = ""):
        super().__init__(
            code="ATTENDANCE_CONFLICT",
            message=f"Conflito de atendimento. {detail}".strip(),
        )


class SellerNotInQueueError(ConflictError):
    def __init__(self):
        super().__init__(
            code="SELLER_NOT_IN_QUEUE",
            message="Vendedor não está na fila.",
        )


class AttendanceNotFoundError(NotFoundError):
    def __init__(self, att_id: str = ""):
        super().__init__(entity="Atendimento", entity_id=att_id)


class QueueLockedError(ConflictError):
    def __init__(self):
        super().__init__(
            code="QUEUE_OPERATION_CONFLICT",
            message="A fila foi atualizada por outra operação. Atualize os dados e tente novamente.",
        )
