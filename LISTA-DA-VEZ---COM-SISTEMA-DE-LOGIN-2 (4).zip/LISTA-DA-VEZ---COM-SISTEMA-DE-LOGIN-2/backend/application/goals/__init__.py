"""CreateGoalUseCase — cria meta de vendas/atendimento para o tenant.

Garante:
- tenant_id no contexto.
- Ator tem permissão.
- Loja existe no tenant.
- Período válido (start < end).
- Valor alvo > 0.
"""
import logging
from datetime import date
from typing import Any, Dict, Optional

from application.base import BaseUseCase, UseCaseContext
from domain.base import ValidationError
from domain.tenant import InsufficientPermissionsError, StoreNotFoundError
from infrastructure.repositories import store_repo
from permission_service import has_permission
from permissions import P_GOALS_CREATE
import goals_service

logger = logging.getLogger("lista-da-vez.usecases.create_goal")


class CreateGoalInput:
    def __init__(
        self,
        store_id: str,
        title: str,
        goal_type: str,
        target_value: float,
        period_start: str,
        period_end: str,
        seller_id: Optional[str] = None,
        team_id: Optional[str] = None,
        description: Optional[str] = None,
    ):
        self.store_id = store_id
        self.title = title
        self.goal_type = goal_type
        self.target_value = target_value
        self.period_start = period_start
        self.period_end = period_end
        self.seller_id = seller_id
        self.team_id = team_id
        self.description = description


class CreateGoalUseCase(BaseUseCase):
    """Caso de uso: criar meta.

    Checklist:
    1. Tenant válido.
    2. Loja existe no tenant.
    3. Ator tem permissão.
    4. Target > 0.
    5. Período válido (start <= end).
    6. Delegar para goal_service.
    """

    async def execute(self, ctx: UseCaseContext, inp: CreateGoalInput, **kwargs) -> Dict[str, Any]:
        # 1. Validar loja no tenant
        store = await store_repo.find_by_id_for_tenant(ctx.tenant_id, inp.store_id)
        if not store:
            raise StoreNotFoundError(inp.store_id)

        # 2. Validar permissão
        if not await has_permission(ctx.tenant_id, ctx.actor_user_id, P_GOALS_CREATE, inp.store_id):
            raise InsufficientPermissionsError(P_GOALS_CREATE)

        # 3. Validar target
        if inp.target_value <= 0:
            raise ValidationError(
                code="INVALID_TARGET_VALUE",
                message="O valor alvo da meta deve ser maior que zero.",
            )

        # 4. Validar período
        try:
            start = date.fromisoformat(inp.period_start)
            end = date.fromisoformat(inp.period_end)
            if start > end:
                raise ValidationError(
                    code="INVALID_PERIOD",
                    message="A data de início deve ser anterior à data de fim.",
                )
        except ValueError:
            raise ValidationError(
                code="INVALID_DATE_FORMAT",
                message="Datas devem estar no formato YYYY-MM-DD.",
            )

        # 5. Delegar para goals_service
        data = dict(
            store_id=inp.store_id,
            title=inp.title,
            goal_type=inp.goal_type,
            target_value=inp.target_value,
            period_start=inp.period_start,
            period_end=inp.period_end,
            seller_id=inp.seller_id,
            team_id=inp.team_id,
            description=inp.description,
        )
        result = await goals_service.create_goal(
            tenant_id=ctx.tenant_id,
            actor_user_id=ctx.actor_user_id,
            data=data,
        )

        logger.info(
            "CREATE_GOAL tenant=%s store=%s type=%s target=%s",
            ctx.tenant_id, inp.store_id, inp.goal_type, inp.target_value,
        )
        return result


# Singleton
create_goal_use_case = CreateGoalUseCase()
