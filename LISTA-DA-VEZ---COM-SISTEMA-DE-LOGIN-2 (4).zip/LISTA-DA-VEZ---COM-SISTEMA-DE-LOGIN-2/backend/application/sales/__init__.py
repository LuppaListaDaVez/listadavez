"""Application sales use cases."""
from .create_sale import create_sale_use_case, CreateSaleUseCase, CreateSaleInput

__all__ = ["create_sale_use_case", "CreateSaleUseCase", "CreateSaleInput"]
