"""CreateSaleUseCase — cria venda vinculada a um atendimento ou avulsa.

Garante:
- tenant_id no contexto.
- Ator tem permissão (sales.create_self ou sales.create_manual).
- Valores monetários são positivos.
- Cria itens de venda se fornecidos.
- Delega para sales_service (que já tem toda a lógica de cálculo).
"""
import logging
from typing import Any, Dict, List, Optional

from application.base import BaseUseCase, UseCaseContext
from domain.sales import InvalidSaleAmountError
from domain.tenant import InsufficientPermissionsError, StoreNotFoundError
from infrastructure.repositories import store_repo, sales_repo
from permission_service import has_permission
from permissions import P_SALES_CREATE_SELF, P_SALES_CREATE_MANUAL
import sales_service

logger = logging.getLogger("lista-da-vez.usecases.create_sale")


class CreateSaleInput:
    def __init__(
        self,
        store_id: str,
        seller_id: str,
        attendance_id: Optional[str] = None,
        items: Optional[List[Dict]] = None,
        gross_amount_cents: Optional[int] = None,
        discount_amount_cents: int = 0,
        payment_methods: Optional[List[Dict]] = None,
        notes: Optional[str] = None,
        source: str = "MANUAL",
    ):
        self.store_id = store_id
        self.seller_id = seller_id
        self.attendance_id = attendance_id
        self.items = items or []
        self.gross_amount_cents = gross_amount_cents
        self.discount_amount_cents = discount_amount_cents
        self.payment_methods = payment_methods or []
        self.notes = notes
        self.source = source


class CreateSaleUseCase(BaseUseCase):
    """Caso de uso: criar uma venda.

    Checklist:
    1. Tenant válido (no contexto).
    2. Loja existe no tenant.
    3. Ator tem permissão.
    4. Valores monetários válidos (>= 0).
    5. Delegar para sales_service.
    """

    async def execute(self, ctx: UseCaseContext, inp: CreateSaleInput, **kwargs) -> Dict[str, Any]:
        # 1. Validar loja no tenant
        store = await store_repo.find_by_id_for_tenant(ctx.tenant_id, inp.store_id)
        if not store:
            raise StoreNotFoundError(inp.store_id)

        # 2. Validar permissão
        is_self = inp.seller_id == kwargs.get("actor_seller_id")
        required_perm = P_SALES_CREATE_SELF if is_self else P_SALES_CREATE_MANUAL
        if not await has_permission(ctx.tenant_id, ctx.actor_user_id, required_perm, inp.store_id):
            raise InsufficientPermissionsError(required_perm)

        # 3. Validar valores monetários
        if inp.gross_amount_cents is not None and inp.gross_amount_cents < 0:
            raise InvalidSaleAmountError()

        if inp.discount_amount_cents < 0:
            from domain.base import ValidationError
            raise ValidationError(
                code="INVALID_DISCOUNT",
                message="Desconto não pode ser negativo.",
            )

        # 4. Delegar para sales_service (lógica existente preservada)
        from models import SaleInput, SaleItemInput, PaymentMethodInput

        sale_input = SaleInput(
            items=[SaleItemInput(**item) for item in inp.items],
            gross_amount_cents=inp.gross_amount_cents,
            discount_amount_cents=inp.discount_amount_cents,
            payment_methods=[PaymentMethodInput(**pm) for pm in inp.payment_methods],
            notes=inp.notes,
        )

        result = await sales_service.create_sale(
            tenant_id=ctx.tenant_id,
            store_id=inp.store_id,
            seller_id=inp.seller_id,
            attendance_id=inp.attendance_id,
            sale_input=sale_input,
            actor_user_id=ctx.actor_user_id,
            actor_role=ctx.actor_role,
            source=inp.source,
        )

        logger.info(
            "CREATE_SALE tenant=%s store=%s seller=%s amount_cents=%s",
            ctx.tenant_id, inp.store_id, inp.seller_id,
            inp.gross_amount_cents,
        )
        return result


# Singleton
create_sale_use_case = CreateSaleUseCase()
