"""BaseUseCase — contrato padrão para todos os casos de uso."""
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional
import logging

logger = logging.getLogger("lista-da-vez.usecases")


class UseCaseContext:
    """Contexto de execução de um use case (tenant, ator, request_id)."""

    def __init__(
        self,
        tenant_id: str,
        actor_user_id: str,
        actor_role: str,
        request_id: Optional[str] = None,
        store_id: Optional[str] = None,
    ):
        self.tenant_id = tenant_id
        self.actor_user_id = actor_user_id
        self.actor_role = actor_role
        self.request_id = request_id
        self.store_id = store_id


class BaseUseCase(ABC):
    """Contrato base para use cases.

    Todo use case deve:
    1. Validar tenant_id.
    2. Validar permissões do ator.
    3. Validar input.
    4. Executar a regra de negócio via repositories.
    5. Retornar DTO padronizado.
    6. Nunca chamar controllers.
    7. Nunca depender de componentes de UI.
    """

    @abstractmethod
    async def execute(self, ctx: UseCaseContext, **kwargs) -> Dict[str, Any]:
        raise NotImplementedError
