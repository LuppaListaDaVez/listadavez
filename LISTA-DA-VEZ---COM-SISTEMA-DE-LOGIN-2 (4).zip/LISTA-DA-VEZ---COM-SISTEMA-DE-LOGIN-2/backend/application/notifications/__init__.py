"""CreateNotificationUseCase — cria notificação in-app tenant-scoped.

Garante:
- tenant_id no contexto.
- Ator tem permissão.
- Usuário destinatário pertence ao tenant.
- Não vaza notificações entre tenants.
"""
import logging
from typing import Any, Dict, List, Optional

from application.base import BaseUseCase, UseCaseContext
from domain.tenant import InsufficientPermissionsError, UserNotFoundError
from infrastructure.repositories import user_repo
from permission_service import has_permission
from permissions import P_NOTIF_MANAGE
import notification_service

logger = logging.getLogger("lista-da-vez.usecases.create_notification")


class CreateNotificationInput:
    def __init__(
        self,
        recipient_user_id: str,
        notification_type: str,
        title: str,
        body: str,
        action_url: Optional[str] = None,
        metadata: Optional[Dict] = None,
    ):
        self.recipient_user_id = recipient_user_id
        self.notification_type = notification_type
        self.title = title
        self.body = body
        self.action_url = action_url
        self.metadata = metadata or {}


class CreateNotificationUseCase(BaseUseCase):
    """Caso de uso: criar notificação in-app.

    Checklist:
    1. Tenant válido (no contexto).
    2. Ator tem permissão para enviar notificações.
    3. Destinatário pertence ao tenant (anti-leak).
    4. Delegar para notification_service.
    """

    async def execute(self, ctx: UseCaseContext, inp: CreateNotificationInput, **kwargs) -> Dict[str, Any]:
        # 1. Validar permissão
        if not await has_permission(ctx.tenant_id, ctx.actor_user_id, P_NOTIF_MANAGE):
            raise InsufficientPermissionsError(P_NOTIF_MANAGE)

        # 2. Garantir que o destinatário pertence ao tenant (anti cross-tenant leak)
        membership = await user_repo.find_membership(ctx.tenant_id, inp.recipient_user_id)
        if not membership:
            raise UserNotFoundError(inp.recipient_user_id)

        # 3. Delegar para service
        result = await notification_service.create_notification(
            tenant_id=ctx.tenant_id,
            user_id=inp.recipient_user_id,
            ntype=inp.notification_type,
            title=inp.title,
            body=inp.body,
            entity_type=inp.metadata.get("entity_type") if inp.metadata else None,
            entity_id=inp.metadata.get("entity_id") if inp.metadata else None,
        )

        logger.info(
            "CREATE_NOTIFICATION tenant=%s recipient=%s type=%s",
            ctx.tenant_id, inp.recipient_user_id, inp.notification_type,
        )
        return result


# Singleton
create_notification_use_case = CreateNotificationUseCase()
