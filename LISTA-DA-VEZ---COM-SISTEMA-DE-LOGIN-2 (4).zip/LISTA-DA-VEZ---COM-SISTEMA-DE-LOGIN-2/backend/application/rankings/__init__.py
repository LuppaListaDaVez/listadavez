"""GenerateRankingUseCase — gera/atualiza ranking de vendedores.

Garante:
- tenant_id no contexto.
- Ator tem permissão de leitura de rankings.
- Loja existe no tenant.
- Critério é válido.
- Resultados são sempre tenant-scoped.
"""
import logging
from typing import Any, Dict, Optional

from application.base import BaseUseCase, UseCaseContext
from domain.base import ValidationError
from domain.tenant import InsufficientPermissionsError, StoreNotFoundError
from infrastructure.repositories import store_repo
from permission_service import has_permission
from permissions import P_RANKINGS_VIEW_TENANT
import ranking_service

logger = logging.getLogger("lista-da-vez.usecases.generate_ranking")

VALID_CRITERIA = {"REVENUE", "ATTENDANCES", "CONVERSION_RATE", "AVG_TICKET", "POINTS"}


class GenerateRankingInput:
    def __init__(
        self,
        store_id: Optional[str] = None,
        criteria: str = "REVENUE",
        period_start: Optional[str] = None,
        period_end: Optional[str] = None,
        limit: int = 20,
    ):
        self.store_id = store_id
        self.criteria = criteria
        self.period_start = period_start
        self.period_end = period_end
        self.limit = min(max(1, limit), 100)


class GenerateRankingUseCase(BaseUseCase):
    """Caso de uso: gerar ranking de vendedores.

    Checklist:
    1. Tenant válido.
    2. Ator tem permissão de visualização.
    3. Critério é válido.
    4. Se store_id fornecido, loja existe no tenant.
    5. Delegar para ranking_service (sempre com tenant_id).
    """

    async def execute(self, ctx: UseCaseContext, inp: GenerateRankingInput, **kwargs) -> Dict[str, Any]:
        # 1. Validar permissão
        if not await has_permission(ctx.tenant_id, ctx.actor_user_id, P_RANKINGS_VIEW_TENANT):
            raise InsufficientPermissionsError(P_RANKINGS_VIEW_TENANT)

        # 2. Validar critério
        if inp.criteria not in VALID_CRITERIA:
            raise ValidationError(
                code="INVALID_RANKING_CRITERIA",
                message=f"Critério inválido: '{inp.criteria}'. Permitidos: {', '.join(sorted(VALID_CRITERIA))}",
            )

        # 3. Validar store se fornecido
        if inp.store_id:
            store = await store_repo.find_by_id_for_tenant(ctx.tenant_id, inp.store_id)
            if not store:
                raise StoreNotFoundError(inp.store_id)

        # 4. Delegar para ranking_service (sempre filtra por tenant_id)
        store_ids = [inp.store_id] if inp.store_id else None
        result = await ranking_service.get_ranking(
            tenant_id=ctx.tenant_id,
            criteria=inp.criteria,
            store_ids=store_ids,
            period_start=inp.period_start,
            period_end=inp.period_end,
        )

        logger.info(
            "GENERATE_RANKING tenant=%s criteria=%s store=%s",
            ctx.tenant_id, inp.criteria, inp.store_id or "ALL",
        )
        return result


# Singleton
generate_ranking_use_case = GenerateRankingUseCase()
