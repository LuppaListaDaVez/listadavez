"""FinishAttendanceUseCase — finaliza atendimento com resultado e opcional venda.

Garante:
- tenant_id no contexto.
- Atendimento existe e pertence ao tenant.
- Ator tem permissão (queue.finish_self ou queue.finish_any).
- Idempotência via Idempotency-Key.
- Resultado válido (SALE, NO_SALE, FOLLOW_UP, INVALID).
- Se SALE: cria registro de venda.
- Publica evento no outbox.
- Atualiza posição da fila.
"""
import logging
from typing import Any, Dict, Optional

from application.base import BaseUseCase, UseCaseContext
from domain.queue import AttendanceNotFoundError, AttendanceConflictError
from domain.tenant import InsufficientPermissionsError
from infrastructure.repositories import attendance_repo
from permission_service import has_permission
from permissions import P_QUEUE_FINISH_SELF, P_QUEUE_FINISH_ANY
import queue_engine

logger = logging.getLogger("lista-da-vez.usecases.finish_attendance")

VALID_RESULTS = {"SALE", "NO_SALE", "FOLLOW_UP", "INVALID"}


class FinishAttendanceInput:
    def __init__(
        self,
        store_id: str,
        attendance_id: str,
        result: str,
        sale_amount_cents: Optional[int] = None,
        sale: Optional[Dict] = None,
        loss_reason_id: Optional[str] = None,
        notes: Optional[str] = None,
        queue_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
    ):
        self.store_id = store_id
        self.attendance_id = attendance_id
        self.result = result
        self.sale_amount_cents = sale_amount_cents
        self.sale = sale
        self.loss_reason_id = loss_reason_id
        self.notes = notes
        self.queue_id = queue_id
        self.idempotency_key = idempotency_key


class FinishAttendanceUseCase(BaseUseCase):
    """Caso de uso: finalizar atendimento.

    Checklist:
    1. Tenant válido (no contexto).
    2. Atendimento existe no tenant.
    3. Atendimento está IN_PROGRESS.
    4. Ator tem permissão.
    5. Resultado é válido.
    6. Idempotência verificada.
    7. Delegar para queue_engine (locks, outbox, events).
    """

    async def execute(self, ctx: UseCaseContext, inp: FinishAttendanceInput, **kwargs) -> Dict[str, Any]:
        # 1. Verificar atendimento no tenant
        att = await attendance_repo.find_by_id_for_tenant(ctx.tenant_id, inp.attendance_id)
        if not att:
            raise AttendanceNotFoundError(inp.attendance_id)

        if att["status"] != "IN_PROGRESS":
            raise AttendanceConflictError(
                f"Atendimento já está em estado '{att['status']}'."
            )

        # 2. Validar permissão
        is_own = att.get("seller_id") == kwargs.get("actor_seller_id")
        required_perm = P_QUEUE_FINISH_SELF if is_own else P_QUEUE_FINISH_ANY
        if not await has_permission(ctx.tenant_id, ctx.actor_user_id, required_perm, inp.store_id):
            raise InsufficientPermissionsError(required_perm)

        # 3. Validar resultado
        if inp.result not in VALID_RESULTS:
            from domain.base import ValidationError
            raise ValidationError(
                code="INVALID_RESULT",
                message=f"Resultado inválido: '{inp.result}'. Permitidos: {', '.join(VALID_RESULTS)}",
            )

        # 4. Delegar para engine (idempotência, lock, outbox, realtime)
        from models import FinishAttendanceRequest, SaleInput

        req = FinishAttendanceRequest(
            attendance_id=inp.attendance_id,
            result=inp.result,
            sale_amount_cents=inp.sale_amount_cents,
            sale=SaleInput(**inp.sale) if inp.sale else None,
            loss_reason_id=inp.loss_reason_id,
            notes=inp.notes,
        )

        result = await queue_engine.finish_attendance(
            tenant_id=ctx.tenant_id,
            store_id=inp.store_id,
            queue_id=inp.queue_id,
            body=req,
            actor_user_id=ctx.actor_user_id,
            actor_role=ctx.actor_role,
            request=kwargs.get("request"),
            idempotency_key=inp.idempotency_key,
        )

        logger.info(
            "FINISH_ATTENDANCE att=%s result=%s tenant=%s",
            inp.attendance_id, inp.result, ctx.tenant_id,
        )
        return result


# Singleton
finish_attendance_use_case = FinishAttendanceUseCase()
