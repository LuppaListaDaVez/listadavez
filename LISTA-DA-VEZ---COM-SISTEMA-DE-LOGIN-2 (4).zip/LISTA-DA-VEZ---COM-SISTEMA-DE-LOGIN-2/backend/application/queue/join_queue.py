"""JoinQueueUseCase — vendedor entra na fila de atendimento.

Garante:
- tenant_id no contexto.
- Actor tem permissão (queue.join_self ou queue.join_any).
- Vendedor está na loja correta.
- Não entra em duplicata.
- Lock de concorrência via queue_lock_service.
- Evento publicado no outbox.
"""
import logging
from typing import Any, Dict

from application.base import BaseUseCase, UseCaseContext
from domain.queue import QueueConflictError, QueueLockedError
from domain.tenant import StoreNotFoundError, InsufficientPermissionsError
from infrastructure.repositories import queue_repo, store_repo
from permission_service import has_permission
from permissions import P_QUEUE_JOIN_SELF, P_QUEUE_JOIN_ANY
import queue_engine  # delega para engine existente (incrementally migrated)

logger = logging.getLogger("lista-da-vez.usecases.join_queue")


class JoinQueueInput:
    def __init__(self, store_id: str, seller_id: str, queue_id: str | None = None):
        self.store_id = store_id
        self.seller_id = seller_id
        self.queue_id = queue_id


class JoinQueueUseCase(BaseUseCase):
    """Caso de uso: vendedor entra na fila.

    Regras:
    - Seller só pode entrar na própria fila (SELLER role) com P_QUEUE_JOIN_SELF.
    - Manager/Admin pode entrar por qualquer vendedor com P_QUEUE_JOIN_ANY.
    - Vendedor não pode estar BLOCKED.
    - Máximo de uma entrada por vendedor por fila.
    """

    async def execute(self, ctx: UseCaseContext, inp: JoinQueueInput, **kwargs) -> Dict[str, Any]:
        # 1. Validar store no tenant
        store = await store_repo.find_by_id_for_tenant(ctx.tenant_id, inp.store_id)
        if not store:
            raise StoreNotFoundError(inp.store_id)

        # 2. Validar permissão
        is_self = inp.seller_id == kwargs.get("actor_seller_id")
        required_perm = P_QUEUE_JOIN_SELF if is_self else P_QUEUE_JOIN_ANY
        if not await has_permission(ctx.tenant_id, ctx.actor_user_id, required_perm, inp.store_id):
            raise InsufficientPermissionsError(required_perm)

        # 3. Verificar duplicata (pré-check — lock confirma atomicamente)
        if inp.queue_id:
            queue = await queue_repo.find_by_id_for_tenant(ctx.tenant_id, inp.queue_id)
        else:
            queue = await queue_repo.find_default_queue(ctx.tenant_id, inp.store_id)

        if queue:
            existing = await queue_repo.find_entry_for_seller(
                ctx.tenant_id, queue["id"], inp.seller_id
            )
            if existing:
                raise QueueConflictError()

        # 4. Delegar para queue_engine (que tem lock de concorrência e outbox)
        # Migração incremental: use case valida tenant+permissão, engine executa
        from fastapi import Request as FastAPIRequest
        result = await queue_engine.join_queue(
            tenant_id=ctx.tenant_id,
            store_id=inp.store_id,
            queue_id=inp.queue_id,
            seller_id=inp.seller_id,
            actor_user_id=ctx.actor_user_id,
            actor_role=ctx.actor_role,
            request=kwargs.get("request"),
        )

        logger.info(
            "JOIN_QUEUE seller=%s tenant=%s store=%s queue=%s",
            inp.seller_id, ctx.tenant_id, inp.store_id,
            result.get("entry", {}).get("queue_id", "?"),
        )
        return result


# Singleton
join_queue_use_case = JoinQueueUseCase()
