"""Application layer — use cases, orchestration, business flows."""
