"""PublicMotivationEventService — Etapa 12: eventos motivacionais públicos em tempo real."""
from typing import Optional, Dict, Any, List
import hashlib

from db import db
from models import new_id, utcnow_iso
from realtime import event_bus
from features import is_enabled as feat_enabled
from notification_service import create_notification


_DEDUP_SET: set = set()  # memória local para dedup dentro da sessão; complementa DB


def _dedup_key(*parts) -> str:
    return hashlib.md5(":".join(str(p) for p in parts).encode()).hexdigest()


async def _check_dedup(key: str) -> bool:
    """Retorna True se é duplicata."""
    if key in _DEDUP_SET:
        return True
    existing = await db.motivation_events.find_one({"dedup_key": key})
    if existing:
        _DEDUP_SET.add(key)
        return True
    return False


TEMPLATES: Dict[str, Dict[str, str]] = {
    # Metas
    "GOAL_DAILY_ACHIEVED":   {"title": "Meta diária batida!", "msg": "{seller_name} bateu a meta diária de vendas!", "icon": "🏆"},
    "GOAL_WEEKLY_ACHIEVED":  {"title": "Meta semanal batida!", "msg": "{seller_name} bateu a meta semanal!", "icon": "🏆"},
    "GOAL_MONTHLY_ACHIEVED": {"title": "Meta mensal batida!", "msg": "{seller_name} bateu a meta mensal!", "icon": "🏆"},
    "GOAL_EXCEEDED":         {"title": "Meta superada!", "msg": "{seller_name} superou a meta em {excess}%!", "icon": "🚀"},
    # Badges/Conquistas
    "BADGE_EARNED":          {"title": "Nova conquista!", "msg": "{seller_name} desbloqueou a conquista {badge_name}.", "icon": "🎖️"},
    "AWARD":                 {"title": "Premiação!", "msg": "{seller_name} recebeu a premiação: {award_name}.", "icon": "🥇"},
    "RECOGNITION":           {"title": "Reconhecimento!", "msg": "{seller_name} foi reconhecido por {reason}.", "icon": "⭐"},
    # Ranking
    "RANKING_TOP_1":         {"title": "Novo líder!", "msg": "{seller_name} assumiu a posição 1 no ranking!", "icon": "🥇"},
    "RANKING_TOP_3":         {"title": "Top 3!", "msg": "{seller_name} entrou no top 3 do ranking!", "icon": "🥈"},
    "RANKING_TOP_10":        {"title": "Top 10!", "msg": "{seller_name} entrou no top 10 do ranking!", "icon": "🎯"},
    "RANKING_POSITION_UP":   {"title": "Subiu no ranking!", "msg": "{seller_name} subiu {positions} posições no ranking!", "icon": "📈"},
    # Recordes
    "PERSONAL_RECORD":       {"title": "Novo recorde pessoal!", "msg": "{seller_name} bateu seu próprio recorde!", "icon": "🔥"},
    "COMPANY_RECORD":        {"title": "Novo recorde da empresa!", "msg": "{seller_name} bateu o recorde da empresa!", "icon": "🔥"},
    # Campanhas
    "CAMPAIGN_STARTED":      {"title": "Nova campanha!", "msg": "Campanha {campaign_name} iniciada agora. Bora vender!", "icon": "🎯"},
    "CAMPAIGN_UPDATED":      {"title": "Campanha atualizada!", "msg": "A campanha {campaign_name} foi atualizada.", "icon": "📢"},
    "CAMPAIGN_ENDED":        {"title": "Campanha encerrada!", "msg": "A campanha {campaign_name} chegou ao fim.", "icon": "🏁"},
    # Proatividade
    "PROACTIVE_SALE_CREATED":{"title": "Venda proativa!", "msg": "{seller_name} fechou uma venda por abordagem proativa!", "icon": "⚡"},
    "FIRST_PROACTIVE_SALE":  {"title": "Primeira venda proativa!", "msg": "{seller_name} realizou a primeira venda proativa!", "icon": "⚡"},
    "TEAM_GOAL_ACHIEVED":    {"title": "Meta de equipe!", "msg": "Equipe {team_name} atingiu a meta do dia!", "icon": "👥"},
    "CONVERSION_HIGHLIGHT":  {"title": "Maior conversão!", "msg": "{seller_name} foi destaque em conversão hoje!", "icon": "📊"},
    "PROACTIVE_TOP_SELLER_DAY": {"title": "Destaque em proatividade!", "msg": "{seller_name} foi o mais proativo do dia!", "icon": "⚡"},
    # Avisos administrativos
    "ADMIN_ANNOUNCEMENT":    {"title": "Aviso da administração", "msg": "{message}", "icon": "📢"},
    "GENERAL_ANNOUNCEMENT":  {"title": "Comunicado geral", "msg": "{message}", "icon": "📣"},
    "SCHEDULED_MESSAGE":     {"title": "{title}", "msg": "{message}", "icon": "💬"},
}


def _render(tmpl: Dict[str, str], ctx: Dict[str, Any]) -> tuple[str, str]:
    title = tmpl["title"].format(**{k: ctx.get(k, "") for k in ctx})
    msg = tmpl["msg"].format(**{k: ctx.get(k, "") for k in ctx})
    return title, msg


async def _get_seller_info(tenant_id: str, seller_id: Optional[str]) -> Dict[str, Any]:
    """Retorna nome e foto do vendedor."""
    info = {"seller_name": "Vendedor", "seller_photo": None}
    if not seller_id:
        return info
    sp = await db.seller_profiles.find_one({"tenant_id": tenant_id, "id": seller_id})
    if sp and sp.get("user_id"):
        user = await db.users.find_one({"id": sp["user_id"]})
        if user:
            info["seller_name"] = user.get("name", "Vendedor")
            info["seller_photo"] = user.get("avatar_url")
    return info


async def create_motivation_event(
    tenant_id: str,
    event_type: str,
    *,
    seller_id: Optional[str] = None,
    store_id: Optional[str] = None,
    team_id: Optional[str] = None,
    goal_id: Optional[str] = None,
    badge_id: Optional[str] = None,
    ranking_id: Optional[str] = None,
    sale_id: Optional[str] = None,
    proactive_approach_id: Optional[str] = None,
    extra_ctx: Optional[Dict[str, Any]] = None,
    visibility_scope: str = "TENANT",
    period_key: Optional[str] = None,
    skip_dedup: bool = False,
) -> Optional[dict]:
    # Feature check
    if not await feat_enabled(tenant_id, "motivacao_publica"):
        return None

    # Dedup (anúncios admin sempre passam)
    if not skip_dedup:
        dedup_key = _dedup_key(tenant_id, event_type, seller_id or "", goal_id or "", badge_id or "",
                                ranking_id or "", period_key or "")
        if await _check_dedup(dedup_key):
            return None
    else:
        dedup_key = _dedup_key(tenant_id, event_type, seller_id or "", new_id())  # único

    # Build context for template
    ctx: Dict[str, Any] = {"seller_name": "Vendedor", "badge_name": "", "team_name": "",
                            "positions": 1, "excess": 0, "award_name": "", "reason": "",
                            "campaign_name": "", "message": "", "title": "Destaque!"}
    ctx.update(extra_ctx or {})

    # Enrich seller info (não sobrescreve seller_name se foi passado em extra_ctx)
    seller_info = await _get_seller_info(tenant_id, seller_id)
    if seller_id or "seller_name" not in (extra_ctx or {}):
        ctx["seller_name"] = seller_info["seller_name"]
    # Para foto, usa a do banco se disponível, senão None
    if seller_id:
        seller_info_photo = seller_info["seller_photo"]
    else:
        seller_info_photo = None

    if team_id:
        t = await db.teams.find_one({"tenant_id": tenant_id, "id": team_id})
        if t:
            ctx["team_name"] = t.get("name", "Equipe")

    if badge_id:
        b = await db.seller_badges.find_one({"tenant_id": tenant_id, "id": badge_id})
        if b:
            ctx["badge_name"] = b.get("badge_name") or b.get("name", "conquista")
        else:
            award = await db.achievement_awards.find_one({"tenant_id": tenant_id, "id": badge_id})
            if award:
                ctx["badge_name"] = award.get("achievement_name", "conquista")
            else:
                ach = await db.achievements.find_one({"tenant_id": tenant_id, "id": badge_id})
                if ach:
                    ctx["badge_name"] = ach.get("name", "conquista")

    tmpl = TEMPLATES.get(event_type, {"title": "Destaque!", "msg": "{seller_name} se destacou!", "icon": "⭐"})
    title, message = _render(tmpl, ctx)
    icon = tmpl.get("icon", "⭐")

    now = utcnow_iso()
    doc = {
        "id": new_id(),
        "tenant_id": tenant_id,
        "store_id": store_id,
        "team_id": team_id,
        "seller_id": seller_id,
        "seller_name": ctx["seller_name"],
        "seller_photo": seller_info_photo,
        "event_type": event_type,
        "icon": icon,
        "title": title,
        "message": message,
        "visibility_scope": visibility_scope,
        "ranking_id": ranking_id,
        "goal_id": goal_id,
        "badge_id": badge_id,
        "sale_id": sale_id,
        "proactive_approach_id": proactive_approach_id,
        "metadata": extra_ctx or {},
        "dedup_key": dedup_key,
        "created_at": now,
        "expires_at": None,
        "created_by_system": True,
    }
    await db.motivation_events.insert_one(doc)
    doc.pop("_id", None)
    if not skip_dedup:
        _DEDUP_SET.add(dedup_key)

    # Broadcast realtime to ALL tenant users
    broadcast_payload = {
        "id": doc["id"],
        "event_type": event_type,
        "icon": icon,
        "title": title,
        "message": message,
        "seller_id": seller_id,
        "seller_name": ctx["seller_name"],
        "seller_photo": seller_info_photo,
        "store_id": store_id,
        "visibility_scope": visibility_scope,
        "created_at": now,
    }
    await event_bus.publish_tenant_event(
        tenant_id=tenant_id,
        event_type="motivation.event_created",
        payload=broadcast_payload,
    )

    # Create internal notification for related seller (com params corretos)
    if seller_id:
        sp = await db.seller_profiles.find_one({"tenant_id": tenant_id, "id": seller_id})
        if sp and sp.get("user_id"):
            await create_notification(
                tenant_id=tenant_id,
                user_id=sp["user_id"],
                ntype="MOTIVATION_EVENT",
                title=title,
                body=message,
                entity_type="motivation_event",
                entity_id=doc["id"],
                store_id=store_id,
            )

    return doc


async def handle_goal_achieved(tenant_id: str, goal_id: str, seller_id: Optional[str], period_type: str = "DAILY"):
    event_type_map = {
        "DAILY": "GOAL_DAILY_ACHIEVED",
        "WEEKLY": "GOAL_WEEKLY_ACHIEVED",
        "MONTHLY": "GOAL_MONTHLY_ACHIEVED",
        "CUSTOM": "GOAL_DAILY_ACHIEVED",
    }
    event_type = event_type_map.get(period_type, "GOAL_DAILY_ACHIEVED")
    goal = await db.goals.find_one({"tenant_id": tenant_id, "id": goal_id})
    return await create_motivation_event(
        tenant_id=tenant_id,
        event_type=event_type,
        seller_id=seller_id,
        store_id=goal.get("store_id") if goal else None,
        goal_id=goal_id,
        period_key=goal.get("period") if goal else None,
    )


async def handle_badge_earned(tenant_id: str, badge_id: str, seller_id: str, store_id: Optional[str] = None):
    return await create_motivation_event(
        tenant_id=tenant_id,
        event_type="BADGE_EARNED",
        seller_id=seller_id,
        store_id=store_id,
        badge_id=badge_id,
    )


async def handle_ranking_changed(
    tenant_id: str,
    ranking_id: str,
    seller_id: str,
    old_position: int,
    new_position: int,
    store_id: Optional[str] = None,
):
    if new_position > old_position:
        return  # queda — não publicar coletivamente
    if new_position == 1:
        event_type = "RANKING_TOP_1"
    elif new_position <= 3:
        event_type = "RANKING_TOP_3"
    elif new_position <= 10:
        event_type = "RANKING_TOP_10"
    elif (old_position - new_position) >= 3:
        event_type = "RANKING_POSITION_UP"
    else:
        return  # mudança pequena, não publicar
    positions_up = old_position - new_position
    return await create_motivation_event(
        tenant_id=tenant_id,
        event_type=event_type,
        seller_id=seller_id,
        store_id=store_id,
        ranking_id=ranking_id,
        extra_ctx={"positions": positions_up},
    )


async def list_motivation_events(
    tenant_id: str,
    actor_user_id: str,
    filters: Optional[dict] = None,
) -> List[dict]:
    f = filters or {}
    q: dict = {"tenant_id": tenant_id}
    if f.get("store_id"):
        q["store_id"] = f["store_id"]
    if f.get("event_type"):
        q["event_type"] = f["event_type"]
    if f.get("date_from") or f.get("date_to"):
        dq: dict = {}
        if f.get("date_from"):
            dq["$gte"] = f["date_from"]
        if f.get("date_to"):
            dq["$lte"] = f["date_to"] + "T23:59:59.999999+00:00"
        q["created_at"] = dq
    limit = min(int(f.get("limit", 50)), 200)
    raw = await db.motivation_events.find(q).sort("created_at", -1).limit(limit).to_list(limit)
    for d in raw:
        d.pop("_id", None)
        # Retrocompatibilidade: garantir campos icon/seller_name em docs antigos
        if "icon" not in d:
            tmpl = TEMPLATES.get(d.get("event_type", ""), {})
            d["icon"] = tmpl.get("icon", "⭐")
        if "seller_name" not in d:
            d["seller_name"] = None
        if "seller_photo" not in d:
            d["seller_photo"] = None
    return raw

