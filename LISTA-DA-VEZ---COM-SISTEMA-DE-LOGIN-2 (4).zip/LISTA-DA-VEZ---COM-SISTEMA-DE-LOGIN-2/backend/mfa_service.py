"""Serviço MFA (TOTP) para Super Admin — estrutura base, Etapa 13."""
import os
import pyotp
import base64
from typing import Optional, Tuple
from datetime import datetime, timezone

from db import db
from models import new_id, utcnow_iso


def generate_totp_secret() -> str:
    """Gera um novo segredo TOTP base32."""
    return pyotp.random_base32()


def get_totp_uri(secret: str, email: str, issuer: str = "Lista da Vez") -> str:
    """Gera a URI para QR Code."""
    totp = pyotp.TOTP(secret)
    return totp.provisioning_uri(name=email, issuer_name=issuer)


def verify_totp(secret: str, code: str) -> bool:
    """Valida o código TOTP. Aceita janela de ±1 (30s)."""
    totp = pyotp.TOTP(secret)
    return totp.verify(code, valid_window=1)


def generate_recovery_codes(count: int = 8) -> list:
    """Gera recovery codes únicos."""
    import secrets
    return [
        f"{secrets.token_hex(4).upper()}-{secrets.token_hex(4).upper()}"
        for _ in range(count)
    ]


def hash_recovery_code(code: str) -> str:
    """Hash do recovery code para armazenamento seguro."""
    import hashlib
    return hashlib.sha256(code.encode()).hexdigest()


async def setup_mfa(user_id: str, email: str) -> dict:
    """
    Inicia o setup de MFA para um usuário.
    Retorna secret + URI para QR Code + recovery codes em texto puro (mostrar só uma vez).
    """
    secret = generate_totp_secret()
    uri = get_totp_uri(secret, email)
    recovery_codes_plain = generate_recovery_codes()
    recovery_codes_hashed = [hash_recovery_code(c) for c in recovery_codes_plain]

    await db.mfa_configs.update_one(
        {"user_id": user_id},
        {
            "$set": {
                "user_id": user_id,
                "totp_secret": secret,
                "enabled": False,
                "recovery_codes_hashed": recovery_codes_hashed,
                "setup_started_at": utcnow_iso(),
                "enabled_at": None,
                "last_used_at": None,
            }
        },
        upsert=True,
    )

    return {
        "secret": secret,
        "uri": uri,
        "recovery_codes": recovery_codes_plain,
    }


async def confirm_mfa_setup(user_id: str, code: str) -> bool:
    """
    Confirma o setup de MFA validando o primeiro TOTP.
    Ativa o MFA se o código for válido.
    """
    config = await db.mfa_configs.find_one({"user_id": user_id})
    if not config:
        return False
    if not verify_totp(config["totp_secret"], code):
        return False
    await db.mfa_configs.update_one(
        {"user_id": user_id},
        {"$set": {"enabled": True, "enabled_at": utcnow_iso()}},
    )
    return True


async def get_mfa_config(user_id: str) -> Optional[dict]:
    """Retorna configuração MFA do usuário (sem expor secret)."""
    config = await db.mfa_configs.find_one({"user_id": user_id})
    if not config:
        return None
    config.pop("_id", None)
    config.pop("totp_secret", None)
    config.pop("recovery_codes_hashed", None)
    return config


async def validate_mfa(user_id: str, code: str) -> Tuple[bool, str]:
    """
    Valida o código MFA (TOTP ou recovery code).
    Retorna (success, method) onde method é 'totp' ou 'recovery'.
    """
    config = await db.mfa_configs.find_one({"user_id": user_id})
    if not config or not config.get("enabled"):
        return True, "disabled"

    if verify_totp(config["totp_secret"], code):
        await db.mfa_configs.update_one(
            {"user_id": user_id},
            {"$set": {"last_used_at": utcnow_iso()}},
        )
        return True, "totp"

    code_hash = hash_recovery_code(code)
    recovery_codes = config.get("recovery_codes_hashed", [])
    if code_hash in recovery_codes:
        new_codes = [c for c in recovery_codes if c != code_hash]
        await db.mfa_configs.update_one(
            {"user_id": user_id},
            {
                "$set": {
                    "recovery_codes_hashed": new_codes,
                    "last_used_at": utcnow_iso(),
                }
            },
        )
        return True, "recovery"

    return False, "failed"


async def is_mfa_enabled(user_id: str) -> bool:
    config = await db.mfa_configs.find_one({"user_id": user_id})
    return bool(config and config.get("enabled"))
