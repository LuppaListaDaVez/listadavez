"""Cache TTL em memória — P1.

Cache tenant-scoped para dados de leitura frequente:
- Feature flags (TTL: 30s)
- Permissões por usuário (TTL: 60s)
- Configurações de tenant (TTL: 120s)
- Dashboard summaries (TTL: 15s)

REGRAS:
- Chave SEMPRE inclui tenant_id
- Nunca cacheia dados sensíveis (tokens, senhas)
- Invalidar após escrita/update
- Nunca compartilhar cache entre tenants

Para uso com Redis: substituir implementação mantendo interface.
"""
import asyncio
import time
import logging
from typing import Any, Dict, Optional, Tuple

logger = logging.getLogger("lista-da-vez.cache")

# TTLs padrão por categoria (segundos)
TTL = {
    "feature_flags": 30,
    "permissions": 60,
    "tenant_config": 120,
    "dashboard": 15,
    "store_settings": 60,
    "notifications_count": 10,
    "seller_profiles": 30,
}


class TTLCache:
    """Cache in-memory com TTL por chave."""

    def __init__(self):
        self._store: Dict[str, Tuple[Any, float]] = {}
        self._lock = asyncio.Lock()
        self._hits = 0
        self._misses = 0

    def get(self, key: str) -> Optional[Any]:
        item = self._store.get(key)
        if item is None:
            self._misses += 1
            return None
        value, expires_at = item
        if time.monotonic() > expires_at:
            self._store.pop(key, None)
            self._misses += 1
            return None
        self._hits += 1
        return value

    def set(self, key: str, value: Any, ttl_seconds: float = 30.0):
        self._store[key] = (value, time.monotonic() + ttl_seconds)

    def delete(self, key: str):
        self._store.pop(key, None)

    def delete_prefix(self, prefix: str):
        """Invalida todas as entradas que começam com prefix."""
        to_delete = [k for k in self._store if k.startswith(prefix)]
        for k in to_delete:
            del self._store[k]

    def evict_expired(self):
        """Remove entradas expiradas (chamado periodicamente)."""
        now = time.monotonic()
        expired = [k for k, (_, exp) in self._store.items() if now > exp]
        for k in expired:
            del self._store[k]

    @property
    def stats(self) -> dict:
        total = self._hits + self._misses
        return {
            "entries": len(self._store),
            "hits": self._hits,
            "misses": self._misses,
            "hit_rate": round(self._hits / total * 100, 1) if total else 0.0,
        }

    def clear(self):
        self._store.clear()


# ── Singleton global ──────────────────────────────────────────────────────────
cache = TTLCache()


# ── Helper keys ──────────────────────────────────────────────────────────────
def key_features(tenant_id: str) -> str:
    return f"tenant:{tenant_id}:feature_flags"


def key_permissions(tenant_id: str, user_id: str) -> str:
    return f"tenant:{tenant_id}:permissions:{user_id}"


def key_tenant_config(tenant_id: str) -> str:
    return f"tenant:{tenant_id}:config"


def key_dashboard(tenant_id: str, scope: str, date: str) -> str:
    return f"tenant:{tenant_id}:dashboard:{scope}:{date}"


def key_notif_count(tenant_id: str, user_id: str) -> str:
    return f"tenant:{tenant_id}:notif_count:{user_id}"


def invalidate_tenant(tenant_id: str):
    """Invalida TODO o cache de um tenant."""
    cache.delete_prefix(f"tenant:{tenant_id}:")
    logger.debug("CACHE_INVALIDATED tenant=%s", tenant_id)


def invalidate_features(tenant_id: str):
    cache.delete(key_features(tenant_id))


def invalidate_permissions(tenant_id: str, user_id: Optional[str] = None):
    if user_id:
        cache.delete(key_permissions(tenant_id, user_id))
    else:
        cache.delete_prefix(f"tenant:{tenant_id}:permissions:")
