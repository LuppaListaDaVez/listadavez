"""DataProtectionService — Etapa 14. Mascaramento e validações centralizadas."""
import hashlib
import re
from typing import Optional


# ─── Mascaramento de dados pessoais ──────────────────────────────────────────

def mask_phone(phone: Optional[str]) -> Optional[str]:
    """11987654321 → 11*****4321"""
    if not phone:
        return phone
    p = re.sub(r"\D", "", phone)
    if len(p) < 6:
        return "***"
    return p[:2] + "*****" + p[-4:]


def mask_email(email: Optional[str]) -> Optional[str]:
    """cliente@email.com → c*****@email.com"""
    if not email or "@" not in email:
        return email
    local, domain = email.split("@", 1)
    if len(local) <= 1:
        return email
    return local[0] + "*" * min(5, len(local) - 1) + "@" + domain


def mask_name(name: Optional[str]) -> Optional[str]:
    """Maria Silva → Maria S."""
    if not name:
        return name
    parts = name.strip().split()
    if len(parts) == 1:
        return parts[0]
    return parts[0] + " " + parts[-1][0] + "."


def mask_doc(doc: Optional[str]) -> Optional[str]:
    """12345678901 → ***.456.789-**"""
    if not doc:
        return doc
    d = re.sub(r"\D", "", doc)
    if len(d) < 6:
        return "***"
    return "***" + d[3:6] + "***" + d[-2:]


# ─── Anonimização de valores ──────────────────────────────────────────────────

ANON_NAME = "Usuário anonimizado"
ANON_CUSTOMER_NAME = "Cliente anonimizado"

def anon_email(user_id: str) -> str:
    h = hashlib.sha256(user_id.encode()).hexdigest()[:8]
    return f"anonimizado+{h}@privacy.local"


def strip_personal_fields(doc: dict, fields: list[str]) -> dict:
    """Remove ou nulifica campos pessoais de um documento (não modifica in-place)."""
    result = dict(doc)
    for f in fields:
        if f in result:
            result[f] = None
    return result


# ─── Validação de permissão de acesso a dado pessoal ────────────────────────

def can_view_full_personal_data(role: str) -> bool:
    """Apenas Tenant Admin pode ver dados pessoais completos por padrão."""
    return role in ("TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER")


def apply_customer_masking(doc: dict, role: str) -> dict:
    """Aplica mascaramento em doc de atendimento/visita conforme role."""
    if can_view_full_personal_data(role):
        return doc
    result = dict(doc)
    if result.get("customer_phone"):
        result["customer_phone"] = mask_phone(result["customer_phone"])
    if result.get("customer_email"):
        result["customer_email"] = mask_email(result["customer_email"])
    if result.get("customer_note"):
        result["customer_note"] = "***"
    return result
