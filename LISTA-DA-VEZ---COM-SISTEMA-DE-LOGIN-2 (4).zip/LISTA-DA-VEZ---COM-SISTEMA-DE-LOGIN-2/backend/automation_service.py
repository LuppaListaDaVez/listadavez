"""AutomationService — Etapa 12: regras de automação configuráveis."""
from typing import Optional, List, Dict, Any

from db import db
from models import new_id, utcnow_iso
from audit import log_audit

ALLOWED_TRIGGERS = {
    "GOAL_ACHIEVED", "GOAL_NEAR_TARGET", "BADGE_EARNED", "RANKING_CHANGED",
    "SALE_CREATED", "ATTENDANCE_CREATED", "ATTENDANCE_STALLED",
    "QUEUE_WAITING_TOO_LONG", "FEEDBACK_CREATED", "FEEDBACK_OVERDUE",
    "PROACTIVE_APPROACH_CREATED", "PROACTIVE_SALE_CREATED",
    "SCHEDULED_DAILY", "SCHEDULED_WEEKLY", "MANUAL",
}

ALLOWED_ACTIONS = {
    "CREATE_NOTIFICATION", "SEND_EMAIL", "SEND_PUSH",
    "CREATE_ALERT", "CREATE_MOTIVATION_EVENT",
}


async def create_rule(
    tenant_id: str,
    actor_user_id: str,
    data: dict,
    request=None,
) -> dict:
    trigger_type = data.get("trigger_type")
    if trigger_type not in ALLOWED_TRIGGERS:
        raise ValueError(f"trigger_type inválido: {trigger_type}")
    actions = data.get("actions") or []
    for a in actions:
        if a.get("type") not in ALLOWED_ACTIONS:
            raise ValueError(f"action.type inválido: {a.get('type')}")

    now = utcnow_iso()
    doc = {
        "id": new_id(),
        "tenant_id": tenant_id,
        "name": data.get("name", "Nova automação"),
        "description": data.get("description"),
        "trigger_type": trigger_type,
        "conditions": data.get("conditions") or [],
        "actions": actions,
        "is_active": data.get("is_active", True),
        "created_by": actor_user_id,
        "last_run_at": None,
        "created_at": now,
        "updated_at": now,
    }
    await db.automation_rules.insert_one(doc)
    doc.pop("_id", None)
    await log_audit(
        action="AUTOMATION_RULE_CREATED", entity="automation_rule", entity_id=doc["id"],
        tenant_id=tenant_id, user_id=actor_user_id,
        new_value={"name": doc["name"], "trigger_type": trigger_type}, request=request,
    )
    return doc


async def update_rule(
    tenant_id: str,
    rule_id: str,
    actor_user_id: str,
    data: dict,
    request=None,
) -> Optional[dict]:
    rule = await db.automation_rules.find_one({"tenant_id": tenant_id, "id": rule_id})
    if not rule:
        return None
    allowed_fields = ["name", "description", "conditions", "actions", "is_active"]
    updates = {k: data[k] for k in allowed_fields if k in data}
    updates["updated_at"] = utcnow_iso()
    await db.automation_rules.update_one({"id": rule_id}, {"$set": updates})
    await log_audit(
        action="AUTOMATION_RULE_UPDATED", entity="automation_rule", entity_id=rule_id,
        tenant_id=tenant_id, user_id=actor_user_id, new_value=updates, request=request,
    )
    doc = await db.automation_rules.find_one({"id": rule_id})
    if doc:
        doc.pop("_id", None)
    return doc


async def set_active(
    tenant_id: str,
    rule_id: str,
    actor_user_id: str,
    is_active: bool,
    request=None,
) -> Optional[dict]:
    await db.automation_rules.update_one(
        {"tenant_id": tenant_id, "id": rule_id},
        {"$set": {"is_active": is_active, "updated_at": utcnow_iso()}},
    )
    action = "AUTOMATION_RULE_ENABLED" if is_active else "AUTOMATION_RULE_DISABLED"
    await log_audit(
        action=action, entity="automation_rule", entity_id=rule_id,
        tenant_id=tenant_id, user_id=actor_user_id, request=request,
    )
    doc = await db.automation_rules.find_one({"id": rule_id})
    if doc:
        doc.pop("_id", None)
    return doc


async def delete_rule(tenant_id: str, rule_id: str, actor_user_id: str, request=None):
    await db.automation_rules.delete_one({"tenant_id": tenant_id, "id": rule_id})
    await log_audit(
        action="AUTOMATION_RULE_DELETED", entity="automation_rule", entity_id=rule_id,
        tenant_id=tenant_id, user_id=actor_user_id, request=request,
    )


async def list_rules(tenant_id: str, filters: dict = None) -> List[dict]:
    q: dict = {"tenant_id": tenant_id}
    if (filters or {}).get("is_active") is not None:
        q["is_active"] = filters["is_active"]
    raw = await db.automation_rules.find(q).sort("created_at", -1).limit(200).to_list(200)
    for d in raw:
        d.pop("_id", None)
    return raw


async def execute_rule(
    tenant_id: str,
    rule_id: str,
    actor_user_id: str,
    trigger_context: Optional[dict] = None,
    request=None,
) -> dict:
    """Executa uma automação manualmente ou via evento."""
    import alert_service
    import public_motivation_event_service as motivation_svc
    from notification_service import create_notification

    rule = await db.automation_rules.find_one({"tenant_id": tenant_id, "id": rule_id})
    if not rule:
        return {"executed": False, "reason": "Regra não encontrada"}
    if not rule.get("is_active"):
        return {"executed": False, "reason": "Regra inativa"}

    now = utcnow_iso()
    ctx = trigger_context or {}
    results = []

    for action in (rule.get("actions") or []):
        action_type = action.get("type")
        try:
            if action_type == "CREATE_NOTIFICATION":
                await create_notification(
                    tenant_id=tenant_id,
                    user_id=ctx.get("user_id") or actor_user_id,
                    title=action.get("title", "Automação"),
                    message=action.get("message", "Evento automático."),
                    notification_type="AUTOMATION",
                    entity="automation_rule",
                    entity_id=rule_id,
                    store_id=ctx.get("store_id"),
                )
                results.append({"type": action_type, "status": "OK"})
            elif action_type == "CREATE_ALERT":
                await alert_service.create_alert(
                    tenant_id=tenant_id,
                    alert_type="SYSTEM_WARNING",
                    title=action.get("title", "Alerta automático"),
                    message=action.get("message", "Alerta gerado por automação."),
                    store_id=ctx.get("store_id"),
                    severity=action.get("severity", "INFO"),
                    metadata={"automation_rule_id": rule_id, "context": ctx},
                )
                results.append({"type": action_type, "status": "OK"})
            elif action_type == "CREATE_MOTIVATION_EVENT":
                await motivation_svc.create_motivation_event(
                    tenant_id=tenant_id,
                    event_type=action.get("event_type", "CONVERSION_HIGHLIGHT"),
                    seller_id=ctx.get("seller_id"),
                    store_id=ctx.get("store_id"),
                    extra_ctx=ctx,
                )
                results.append({"type": action_type, "status": "OK"})
            elif action_type in ("SEND_EMAIL", "SEND_PUSH"):
                # Mock / log (provider não configurado em dev)
                from external_notification_service import log_delivery
                await log_delivery(
                    tenant_id=tenant_id,
                    event_type=rule.get("trigger_type"),
                    channel="EMAIL" if action_type == "SEND_EMAIL" else "PUSH",
                    recipient_user_id=ctx.get("user_id") or actor_user_id,
                    status="SKIPPED",
                    error_message="Provider não configurado em ambiente de desenvolvimento.",
                )
                results.append({"type": action_type, "status": "SKIPPED"})
        except Exception as e:  # noqa: BLE001
            results.append({"type": action_type, "status": "ERROR", "error": str(e)})

    # Log execution
    exec_doc = {
        "id": new_id(),
        "tenant_id": tenant_id,
        "automation_rule_id": rule_id,
        "trigger_context": ctx,
        "actions_executed": results,
        "executed_by": actor_user_id,
        "executed_at": now,
        "status": "SUCCESS" if all(r["status"] in ("OK", "SKIPPED") for r in results) else "PARTIAL",
    }
    await db.automation_executions.insert_one(exec_doc)

    # Update last_run_at
    await db.automation_rules.update_one(
        {"id": rule_id}, {"$set": {"last_run_at": now, "updated_at": now}},
    )
    await log_audit(
        action="AUTOMATION_RULE_EXECUTED", entity="automation_rule", entity_id=rule_id,
        tenant_id=tenant_id, user_id=actor_user_id,
        new_value={"results": results, "context": ctx}, request=request,
    )
    return {"executed": True, "results": results, "execution_id": exec_doc["id"]}


async def list_executions(tenant_id: str, rule_id: Optional[str] = None) -> List[dict]:
    q: dict = {"tenant_id": tenant_id}
    if rule_id:
        q["automation_rule_id"] = rule_id
    raw = await db.automation_executions.find(q).sort("executed_at", -1).limit(100).to_list(100)
    for d in raw:
        d.pop("_id", None)
    return raw
