"""Rankings endpoints — Etapa 9."""
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel

from security import resolve_tenant_context
from feature_guard import require_feature
from permission_service import get_accessible_store_ids
from permissions import (
    P_RANKINGS_VIEW_SELF, P_RANKINGS_VIEW_STORE, P_RANKINGS_VIEW_TENANT,
    P_RANKINGS_GENERATE,
)
import ranking_service

router = APIRouter(prefix="/tenants/{tenant_slug}/rankings", tags=["rankings"])

VIEW_PERMS = (P_RANKINGS_VIEW_SELF, P_RANKINGS_VIEW_STORE, P_RANKINGS_VIEW_TENANT)


def _has_view_perm(role: str) -> bool:
    from permissions import ROLE_PERMISSIONS
    return any(p in ROLE_PERMISSIONS.get(role, []) for p in VIEW_PERMS)


def _has_perm(role: str, perm: str) -> bool:
    from permissions import ROLE_PERMISSIONS
    return perm in ROLE_PERMISSIONS.get(role, [])


class GenerateRankingBody(BaseModel):
    criteria: str = "REVENUE"
    scope: str = "STORE"
    store_id: Optional[str] = None
    period_start: Optional[str] = None
    period_end: Optional[str] = None
    persist: bool = False


@router.get("")
async def get_ranking(
    criteria: str = "REVENUE",
    scope: str = "STORE",
    store_id: Optional[str] = None,
    period_start: Optional[str] = None,
    period_end: Optional[str] = None,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "rankings")
    role = ctx["membership"]["role"]
    if not _has_view_perm(role):
        raise HTTPException(403, "Sem permissão para visualizar rankings.")

    tenant_id = ctx["tenant"]["id"]
    accessible_store_ids = await get_accessible_store_ids(ctx["membership"], tenant_id)

    effective_store_ids = None
    if store_id:
        if accessible_store_ids and store_id not in accessible_store_ids:
            raise HTTPException(403, "Sem acesso a esta unidade.")
        effective_store_ids = [store_id]
    elif role != "TENANT_ADMIN" and accessible_store_ids:
        effective_store_ids = accessible_store_ids

    # SELLER: só pode ver ranking se permitido, mas sem filtro de seller aqui
    # (mostra posição de todos, o frontend destaca o seller logado)

    return await ranking_service.get_ranking(
        tenant_id=tenant_id,
        criteria=criteria,
        scope=scope,
        store_ids=effective_store_ids,
        period_start=period_start,
        period_end=period_end,
    )


@router.post("/generate")
async def generate_ranking(payload: GenerateRankingBody, request: Request, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "rankings")
    role = ctx["membership"]["role"]
    if not _has_perm(role, P_RANKINGS_GENERATE):
        raise HTTPException(403, "Sem permissão para gerar rankings.")

    tenant_id = ctx["tenant"]["id"]
    accessible_store_ids = await get_accessible_store_ids(ctx["membership"], tenant_id)

    effective_store_ids = None
    if payload.store_id:
        if accessible_store_ids and payload.store_id not in accessible_store_ids:
            raise HTTPException(403, "Sem acesso a esta unidade.")
        effective_store_ids = [payload.store_id]
    elif accessible_store_ids and role != "TENANT_ADMIN":
        effective_store_ids = accessible_store_ids

    ranking = await ranking_service.get_ranking(
        tenant_id=tenant_id,
        criteria=payload.criteria,
        scope=payload.scope,
        store_ids=effective_store_ids,
        period_start=payload.period_start,
        period_end=payload.period_end,
    )

    if payload.persist:
        persisted = await ranking_service.persist_ranking(tenant_id, ctx["user"]["id"], {
            **ranking,
            "store_id": payload.store_id,
        })
        ranking["persisted_id"] = persisted["id"]

    return ranking
