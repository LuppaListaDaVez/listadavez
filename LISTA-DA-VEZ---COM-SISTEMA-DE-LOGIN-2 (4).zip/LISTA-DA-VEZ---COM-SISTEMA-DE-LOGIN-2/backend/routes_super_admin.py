"""Super Admin routes (/api/super-admin)."""
import os
import re
import secrets
from datetime import datetime, timezone, timedelta

from fastapi import APIRouter, Depends, HTTPException, Request
from pymongo.errors import DuplicateKeyError

from db import db
from features import FEATURE_CATALOG, set_tenant_feature, get_tenant_features
from models import (
    FeatureCreate,
    PlanCreate,
    TenantCreate,
    TenantFeaturesUpdate,
    TenantStatusUpdate,
    TenantUpdate,
    new_id,
    utcnow_iso,
)
from security import hash_password, require_super_admin, hash_token, create_refresh_token_raw
from audit import log_audit
from security_event_service import log_security_event, SecurityEventType
from rate_limit_service import make_rate_limit_dep
from external_notification_service import send_invite_email
from pydantic import BaseModel

router = APIRouter(prefix="/super-admin", tags=["super-admin"], dependencies=[Depends(require_super_admin)])


SLUG_RE = re.compile(r"^[a-z0-9](?:[a-z0-9-]{0,38}[a-z0-9])?$")
_INVITE_EXPIRES_HOURS = 72


async def _list_to_clean(cursor):
    items = await cursor.to_list(length=500)
    for it in items:
        it.pop("_id", None)
    return items


def _get_frontend_url() -> str:
    return os.environ.get("FRONTEND_URL", "http://localhost:3000").rstrip("/")


async def _create_tenant_owner_invite(
    *,
    tenant_id: str,
    admin_email: str,
    actor_id: str,
) -> str:
    """Gera convite TENANT_OWNER, insere em invite_tokens, retorna o token raw."""
    token_raw = create_refresh_token_raw()
    token_hash = hash_token(token_raw)
    now = datetime.now(timezone.utc)
    await db.invite_tokens.insert_one(
        {
            "id": new_id(),
            "token_hash": token_hash,
            "tenant_id": tenant_id,
            "invite_type": "TENANT_OWNER",
            "email": admin_email.lower().strip(),
            "role": "TENANT_ADMIN",
            "store_ids": [],
            "all_stores": False,
            "created_by": actor_id,
            "created_at": now.isoformat(),
            "expires_at": now + timedelta(hours=_INVITE_EXPIRES_HOURS),  # BSON datetime para TTL
            "used_at": None,
            "revoked_at": None,
        }
    )
    return token_raw


# ---------- Tenants ----------
@router.get("/tenants")
async def list_tenants():
    return await _list_to_clean(db.tenants.find().sort("created_at", -1))


@router.post(
    "/tenants",
    status_code=201,
    dependencies=[Depends(make_rate_limit_dep("INVITE_SEND"))],
)
async def create_tenant(
    payload: TenantCreate,
    request: Request,
    actor: dict = Depends(require_super_admin),
):
    if not payload.admin_email:
        raise HTTPException(status_code=422, detail="admin_email é obrigatório para criar um tenant.")

    slug = payload.slug.lower().strip()
    if not SLUG_RE.match(slug):
        raise HTTPException(status_code=400, detail="Slug inválido (use letras minúsculas, números e -).")
    if slug in {"super-admin", "api", "auth", "health"}:
        raise HTTPException(status_code=400, detail="Slug reservado.")
    if await db.tenants.find_one({"slug": slug}):
        raise HTTPException(status_code=409, detail="Slug já em uso.")

    now = utcnow_iso()
    tenant = {
        "id": new_id(),
        "name": payload.name,
        "slug": slug,
        "cnpj": payload.cnpj,
        "email": payload.email,
        "phone": payload.phone,
        "status": "PENDING_ACTIVATION",
        "plan_id": payload.plan_id,
        "logo_url": payload.logo_url,
        "primary_color": payload.primary_color,
        "created_at": now,
        "updated_at": now,
    }
    try:
        await db.tenants.insert_one(tenant)
    except DuplicateKeyError as exc:
        err = str(exc)
        if "cnpj" in err:
            raise HTTPException(status_code=409, detail="CNPJ já cadastrado para outro tenant.")
        raise HTTPException(status_code=409, detail="Conflito ao criar tenant.")

    # Default settings
    await db.tenant_settings.insert_one(
        {
            "id": new_id(),
            "tenant_id": tenant["id"],
            "general_settings": {},
            "created_at": now,
            "updated_at": now,
        }
    )

    # Initialize all known features as disabled by default
    for f in FEATURE_CATALOG:
        await set_tenant_feature(
            tenant_id=tenant["id"],
            feature_key=f["key"],
            enabled=False,
            updated_by=actor["id"],
        )

    # Gerar convite de ativação para o dono
    admin_email = payload.admin_email.lower().strip()
    token_raw = await _create_tenant_owner_invite(
        tenant_id=tenant["id"],
        admin_email=admin_email,
        actor_id=actor["id"],
    )

    # Enviar e-mail de convite (loga em DEV_EMAIL_INVITE:, envia em produção via Prompt 4)
    invite_link = f"{_get_frontend_url()}/ativar-conta?token={token_raw}"
    await send_invite_email(
        to_email=admin_email,
        invite_link=invite_link,
        tenant_name=payload.name,
        tenant_id=tenant["id"],
        invite_type="TENANT_OWNER",
    )

    await log_audit(
        action="TENANT_INVITE_SENT",
        entity="tenant",
        entity_id=tenant["id"],
        tenant_id=tenant["id"],
        user_id=actor["id"],
        new_value={"name": tenant["name"], "slug": tenant["slug"], "admin_email": admin_email},
        request=request,
    )
    await log_security_event(
        event_type=SecurityEventType.INVITE_SENT,
        tenant_id=tenant["id"],
        user_id=actor["id"],
        metadata={"invite_type": "TENANT_OWNER", "email": admin_email[:3] + "***"},
        request=request,
    )

    tenant.pop("_id", None)
    return {
        **tenant,
        "invite_sent_to": admin_email,
        "message": "Tenant criado. Convite de ativação enviado para o e-mail do responsável.",
    }


@router.post(
    "/tenants/{tenant_id}/resend-invite",
    dependencies=[Depends(make_rate_limit_dep("INVITE_SEND"))],
)
async def resend_tenant_invite(
    tenant_id: str,
    request: Request,
    actor: dict = Depends(require_super_admin),
):
    """Revoga convites anteriores TENANT_OWNER e reenvia novo convite."""
    tenant = await db.tenants.find_one({"id": tenant_id})
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant não encontrado.")

    # Revogar convites não usados e não expirados
    now_dt = datetime.now(timezone.utc)
    await db.invite_tokens.update_many(
        {
            "tenant_id": tenant_id,
            "invite_type": "TENANT_OWNER",
            "used_at": None,
            "revoked_at": None,
            "expires_at": {"$gt": now_dt},
        },
        {"$set": {"revoked_at": now_dt.isoformat()}},
    )

    # Obter e-mail do convite anterior ou do tenant
    existing = await db.invite_tokens.find_one(
        {"tenant_id": tenant_id, "invite_type": "TENANT_OWNER"},
        sort=[("created_at", -1)],
    )
    admin_email = (existing or {}).get("email") or tenant.get("email")
    if not admin_email:
        raise HTTPException(
            status_code=422,
            detail="Nenhum e-mail de responsável encontrado para reenviar convite.",
        )

    # Gerar novo convite
    token_raw = await _create_tenant_owner_invite(
        tenant_id=tenant_id,
        admin_email=admin_email,
        actor_id=actor["id"],
    )

    invite_link = f"{_get_frontend_url()}/ativar-conta?token={token_raw}"
    await send_invite_email(
        to_email=admin_email,
        invite_link=invite_link,
        tenant_name=tenant["name"],
        tenant_id=tenant_id,
        invite_type="TENANT_OWNER",
    )

    await log_audit(
        action="TENANT_INVITE_RESENT",
        entity="tenant",
        entity_id=tenant_id,
        tenant_id=tenant_id,
        user_id=actor["id"],
        new_value={"admin_email": admin_email[:3] + "***"},
        request=request,
    )
    await log_security_event(
        event_type=SecurityEventType.INVITE_SENT,
        tenant_id=tenant_id,
        user_id=actor["id"],
        metadata={"invite_type": "TENANT_OWNER_RESEND", "email": admin_email[:3] + "***"},
        request=request,
    )

    return {"message": "Convite reenviado com sucesso.", "invite_sent_to": admin_email, "invite_link": invite_link}


@router.delete("/tenants/{tenant_id}")
async def delete_tenant(
    tenant_id: str,
    request: Request,
    actor: dict = Depends(require_super_admin),
):
    """Hard delete do tenant e todos os dados associados (ação irreversível)."""
    tenant = await db.tenants.find_one({"id": tenant_id})
    if not tenant:
        raise HTTPException(status_code=404, detail="Empresa não encontrada.")

    # Cascade delete em todas as coleções associadas
    await db.invite_tokens.delete_many({"tenant_id": tenant_id})
    await db.seller_profiles.delete_many({"tenant_id": tenant_id})
    await db.stores.delete_many({"tenant_id": tenant_id})
    await db.tenant_memberships.delete_many({"tenant_id": tenant_id})
    await db.tenant_settings.delete_many({"tenant_id": tenant_id})
    await db.tenants.delete_one({"id": tenant_id})

    await log_audit(
        action="TENANT_DELETED",
        entity="tenant",
        entity_id=tenant_id,
        tenant_id=tenant_id,
        user_id=actor["id"],
        old_value={"name": tenant.get("name"), "slug": tenant.get("slug"), "status": tenant.get("status")},
        request=request,
    )

    return {"success": True, "message": f"Empresa '{tenant['name']}' excluída permanentemente."}


@router.get("/tenants/{tenant_id}")
async def get_tenant(tenant_id: str):
    tenant = await db.tenants.find_one({"id": tenant_id})
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant não encontrado.")
    tenant.pop("_id", None)
    return tenant


@router.get("/tenants/{tenant_id}/users")
async def get_tenant_users(
    tenant_id: str,
    actor: dict = Depends(require_super_admin),
):
    """Lista usuários vinculados a uma empresa. Retorna apenas e-mail, nome e cargo — sem senhas ou tokens."""
    tenant = await db.tenants.find_one({"id": tenant_id})
    if not tenant:
        raise HTTPException(status_code=404, detail="Empresa não encontrada.")

    memberships = await db.tenant_memberships.find(
        {"tenant_id": tenant_id, "status": {"$ne": "DELETED"}}
    ).to_list(1000)

    result = []
    for m in memberships:
        user = await db.users.find_one({"id": m["user_id"]})
        if not user:
            continue
        result.append({
            "id": user["id"],
            "name": user.get("name") or "",
            "email": user.get("email") or "",
            "role": m.get("role") or "",
            "membership_status": m.get("status") or "ACTIVE",
        })

    return result


@router.delete("/tenants/{tenant_id}/users/{user_id}", status_code=204)
async def delete_tenant_user(
    tenant_id: str,
    user_id: str,
    request: Request,
    actor: dict = Depends(require_super_admin),
):
    """Super Admin exclui (soft-delete) usuário de uma empresa. Dados históricos preservados."""
    tenant = await db.tenants.find_one({"id": tenant_id})
    if not tenant:
        raise HTTPException(status_code=404, detail="Empresa não encontrada.")

    membership = await db.tenant_memberships.find_one({"tenant_id": tenant_id, "user_id": user_id})
    if not membership or membership.get("status") == "DELETED":
        raise HTTPException(status_code=404, detail="Usuário não encontrado nesta empresa.")

    # Proteção: não pode excluir o último TENANT_ADMIN ativo
    if membership.get("role") == "TENANT_ADMIN":
        remaining = await db.tenant_memberships.count_documents({
            "tenant_id": tenant_id,
            "role": "TENANT_ADMIN",
            "status": "ACTIVE",
            "user_id": {"$ne": user_id},
        })
        if remaining == 0:
            raise HTTPException(
                status_code=400,
                detail="Não é possível excluir o único administrador ativo desta empresa.",
            )

    now = utcnow_iso()
    await db.tenant_memberships.update_one(
        {"tenant_id": tenant_id, "user_id": user_id},
        {"$set": {"status": "DELETED", "updated_at": now}},
    )
    await db.seller_profiles.update_many(
        {"tenant_id": tenant_id, "user_id": user_id},
        {"$set": {"status": "DELETED", "updated_at": now}},
    )
    await log_audit(
        action="USER_DELETED",
        entity="user",
        entity_id=user_id,
        tenant_id=tenant_id,
        user_id=actor["id"],
        new_value={"status": "DELETED"},
        request=request,
    )

    from fastapi.responses import Response
    return Response(status_code=204)


@router.put("/tenants/{tenant_id}")
async def update_tenant(
    tenant_id: str,
    payload: TenantUpdate,
    request: Request,
    actor: dict = Depends(require_super_admin),
):
    tenant = await db.tenants.find_one({"id": tenant_id})
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant não encontrado.")
    updates = {k: v for k, v in payload.model_dump(exclude_none=True).items()}
    if updates:
        updates["updated_at"] = utcnow_iso()
        await db.tenants.update_one({"id": tenant_id}, {"$set": updates})
    await log_audit(
        action="TENANT_UPDATED",
        entity="tenant",
        entity_id=tenant_id,
        tenant_id=tenant_id,
        user_id=actor["id"],
        new_value=updates,
        request=request,
    )
    updated = await db.tenants.find_one({"id": tenant_id})
    updated.pop("_id", None)
    return updated


@router.patch("/tenants/{tenant_id}/status")
async def update_tenant_status(
    tenant_id: str,
    payload: TenantStatusUpdate,
    request: Request,
    actor: dict = Depends(require_super_admin),
):
    tenant = await db.tenants.find_one({"id": tenant_id})
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant não encontrado.")
    await db.tenants.update_one(
        {"id": tenant_id},
        {"$set": {"status": payload.status, "updated_at": utcnow_iso()}},
    )
    await log_audit(
        action="TENANT_UPDATED",
        entity="tenant",
        entity_id=tenant_id,
        tenant_id=tenant_id,
        user_id=actor["id"],
        old_value={"status": tenant["status"]},
        new_value={"status": payload.status},
        request=request,
    )
    return {"id": tenant_id, "status": payload.status}


# ---------- Plans ----------
@router.get("/plans")
async def list_plans():
    return await _list_to_clean(db.plans.find().sort("created_at", 1))


@router.post("/plans", status_code=201)
async def create_plan(payload: PlanCreate, actor: dict = Depends(require_super_admin)):
    now = utcnow_iso()
    plan = {
        "id": new_id(),
        "name": payload.name,
        "description": payload.description,
        "status": payload.status,
        "limits": payload.limits,
        "created_at": now,
        "updated_at": now,
    }
    try:
        await db.plans.insert_one(plan)
    except DuplicateKeyError:
        raise HTTPException(status_code=409, detail="Já existe um plano com este nome.")
    plan.pop("_id", None)
    return plan


# ---------- Features ----------
@router.get("/features")
async def list_features():
    return await _list_to_clean(db.features.find().sort("key", 1))


@router.post("/features", status_code=201)
async def create_feature(
    payload: FeatureCreate, actor: dict = Depends(require_super_admin)
):
    existing = await db.features.find_one({"key": payload.key})
    if existing:
        raise HTTPException(status_code=409, detail="Feature já existe.")
    now = utcnow_iso()
    feature = {
        "id": new_id(),
        "key": payload.key,
        "name": payload.name,
        "description": payload.description,
        "created_at": now,
        "updated_at": now,
    }
    await db.features.insert_one(feature)
    feature.pop("_id", None)
    return feature


# ---------- Tenant Features ----------
@router.get("/tenants/{tenant_id}/features")
async def list_tenant_features(tenant_id: str):
    tenant = await db.tenants.find_one({"id": tenant_id})
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant não encontrado.")
    catalog = await _list_to_clean(db.features.find().sort("key", 1))
    enabled_map = await get_tenant_features(tenant_id)
    return [
        {
            "feature_key": f["key"],
            "name": f["name"],
            "description": f.get("description"),
            "enabled": enabled_map.get(f["key"], False),
        }
        for f in catalog
    ]


@router.patch("/tenants/{tenant_id}/features")
async def update_tenant_features(
    tenant_id: str,
    payload: TenantFeaturesUpdate,
    request: Request,
    actor: dict = Depends(require_super_admin),
):
    tenant = await db.tenants.find_one({"id": tenant_id})
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant não encontrado.")
    for item in payload.features:
        await set_tenant_feature(
            tenant_id=tenant_id,
            feature_key=item.feature_key,
            enabled=item.enabled,
            updated_by=actor["id"],
        )
        await log_audit(
            action="FEATURE_ENABLED" if item.enabled else "FEATURE_DISABLED",
            entity="feature",
            entity_id=item.feature_key,
            tenant_id=tenant_id,
            user_id=actor["id"],
            new_value={"enabled": item.enabled},
            request=request,
        )
    return await list_tenant_features(tenant_id)


@router.get("/system/email-status")
async def get_email_status(actor: dict = Depends(require_super_admin)):
    """Retorna o status de configuração do e-mail transacional.
    Prioridade: config do banco > variáveis de ambiente.
    """
    import email_config as _ec

    # ── 1. Verificar configuração salva no banco ──────────────────────────
    db_cfg = await db.system_settings.find_one({"_id": "email_config"})
    if db_cfg:
        has_pass = bool(db_cfg.get("smtp_password") or db_cfg.get("smtp_pass"))
        has_host = bool(db_cfg.get("smtp_host"))
        if has_host and has_pass:
            return {
                "provider":     "smtp",
                "configured":   True,
                "source":       "database",
                "missing_vars": [],
                "from_address": db_cfg.get("smtp_from") or db_cfg.get("smtp_user", ""),
                "smtp_host":    db_cfg.get("smtp_host", ""),
                "smtp_user":    db_cfg.get("smtp_user", ""),
            }

    # ── 2. Fallback: variáveis de ambiente ────────────────────────────────
    provider = _ec.EMAIL_PROVIDER
    if provider == "smtp":
        configured = _ec.is_smtp_configured()
        # Checar todos os nomes (novo + alias)
        missing = []
        if not _ec.SMTP_HOST:
            missing.append("SMTP_HOST")
        if not _ec.SMTP_USER:
            missing.append("SMTP_USER")
        if not _ec.SMTP_PASSWORD:
            missing.append("SMTP_PASSWORD (ou SMTP_PASS)")
    elif provider == "ses":
        configured = _ec.is_ses_configured()
        missing = [k for k in ("AWS_REGION", "SES_FROM_EMAIL") if not os.environ.get(k)]
    else:
        configured = False
        missing = ["EMAIL_PROVIDER", "SMTP_HOST", "SMTP_USER", "SMTP_PASSWORD"]

    return {
        "provider":     provider,
        "configured":   configured,
        "source":       "environment",
        "missing_vars": missing,
        "from_address": _ec.EMAIL_FROM if provider == "smtp" else os.environ.get("SES_FROM_EMAIL", ""),
        "smtp_host":    _ec.SMTP_HOST,
        "smtp_user":    _ec.SMTP_USER,
    }


# ─── SMTP Config (salva no banco, tem prioridade sobre env vars) ──────────────

class SmtpConfigPayload(BaseModel):
    smtp_host: str = ""
    smtp_port: int = 587
    # Novos nomes canônicos
    smtp_tls:      bool = False
    smtp_ssl:      bool = False
    smtp_password: str  = ""
    # Aliases de compatibilidade com UI legada (aceitos, convertidos internamente)
    smtp_secure:   bool = False   # alias → smtp_tls
    smtp_pass:     str  = ""      # alias → smtp_password
    smtp_user:     str  = ""
    smtp_from:     str  = ""

    def resolved_tls(self) -> bool:
        return self.smtp_tls or self.smtp_secure

    def resolved_password(self) -> str:
        return self.smtp_password or self.smtp_pass


class SmtpTestPayload(BaseModel):
    config:     SmtpConfigPayload
    test_email: str


@router.get("/system/smtp-config")
async def get_smtp_config(actor: dict = Depends(require_super_admin)):
    """Retorna a configuração SMTP atual (banco > env vars). Senha mascarada."""
    db_cfg = await db.system_settings.find_one({"_id": "email_config"})

    if db_cfg:
        # Ler ambos nomes para máxima compatibilidade
        has_pass = bool(db_cfg.get("smtp_password") or db_cfg.get("smtp_pass"))
        tls = db_cfg.get("smtp_tls") if db_cfg.get("smtp_tls") is not None else db_cfg.get("smtp_secure", False)
        return {
            "source":       "database",
            "smtp_host":    db_cfg.get("smtp_host", ""),
            "smtp_port":    db_cfg.get("smtp_port", 587),
            "smtp_tls":     bool(tls),
            "smtp_ssl":     bool(db_cfg.get("smtp_ssl", False)),
            "smtp_user":    db_cfg.get("smtp_user", ""),
            "smtp_password": "****" if has_pass else "",
            # aliases legados para UI existente
            "smtp_secure":  bool(tls),
            "smtp_pass":    "****" if has_pass else "",
            "smtp_from":    db_cfg.get("smtp_from", ""),
        }

    import email_config as _ec
    has_env_pass = bool(_ec.SMTP_PASSWORD)
    return {
        "source":       "environment",
        "smtp_host":    _ec.SMTP_HOST,
        "smtp_port":    _ec.SMTP_PORT,
        "smtp_tls":     _ec.SMTP_TLS,
        "smtp_ssl":     _ec.SMTP_SSL,
        "smtp_user":    _ec.SMTP_USER,
        "smtp_password": "****" if has_env_pass else "",
        # aliases legados
        "smtp_secure":  _ec.SMTP_TLS,
        "smtp_pass":    "****" if has_env_pass else "",
        "smtp_from":    _ec.EMAIL_FROM,
    }


@router.put("/system/smtp-config")
async def save_smtp_config(payload: SmtpConfigPayload, actor: dict = Depends(require_super_admin)):
    """Salva configuração SMTP no banco (sobrepõe env vars em runtime).
    Aceita tanto os novos nomes (smtp_password, smtp_tls) quanto os aliases legados (smtp_pass, smtp_secure).
    """
    update: dict = {
        "smtp_host":   payload.smtp_host,
        "smtp_port":   payload.smtp_port,
        # Salvar ambos para compatibilidade máxima
        "smtp_tls":    payload.resolved_tls(),
        "smtp_ssl":    payload.smtp_ssl,
        "smtp_secure": payload.resolved_tls(),    # alias legado
        "smtp_user":   payload.smtp_user,
        "smtp_from":   payload.smtp_from,
        "updated_at":  datetime.now(timezone.utc).isoformat(),
        "updated_by":  actor.get("id"),
    }
    # Não sobrescreve senha se cliente enviou "****" (sentinel "não alterado")
    resolved_pwd = payload.resolved_password()
    if resolved_pwd and resolved_pwd != "****":
        update["smtp_password"] = resolved_pwd
        update["smtp_pass"]     = resolved_pwd   # alias legado

    await db.system_settings.update_one(
        {"_id": "email_config"},
        {"$set": update},
        upsert=True,
    )
    return {"success": True, "message": "Configuração SMTP salva."}


@router.delete("/system/smtp-config")
async def delete_smtp_config(actor: dict = Depends(require_super_admin)):
    """Remove configuração SMTP do banco (sistema volta a usar env vars)."""
    await db.system_settings.delete_one({"_id": "email_config"})
    return {"success": True, "message": "Configuração SMTP removida. Variáveis de ambiente serão utilizadas."}


# ─── Impersonação ──────────────────────────────────────────────────────────────

@router.post("/tenants/{tenant_id}/impersonate")
async def impersonate_tenant(
    tenant_id: str,
    request: Request,
    actor: dict = Depends(require_super_admin),
):
    """Gera tokens de acesso total (TENANT_ADMIN) para o Super Admin navegar num tenant.

    - O token carrega is_impersonation=True e impersonated_by com o ID do Super Admin.
    - A ação é registrada no audit trail para rastreabilidade.
    - Um tenant_admin virtual é gerado sem precisar de um usuário real ativo no tenant.
    """
    from security import create_tenant_access_token, create_refresh_token_raw, hash_token
    from session_service import create_session

    tenant = await db.tenants.find_one({"id": tenant_id})
    if not tenant:
        raise HTTPException(status_code=404, detail="Empresa não encontrada.")

    # Usar o Super Admin como identidade de impersonação
    actor_id   = actor["id"]
    actor_email = actor["email"]

    # Tentar encontrar um membership TENANT_ADMIN real (para ter um membership_id válido)
    admin_membership = await db.tenant_memberships.find_one(
        {"tenant_id": tenant_id, "role": "TENANT_ADMIN", "status": "ACTIVE"},
        sort=[("created_at", 1)],
    )
    membership_id = admin_membership["id"] if admin_membership else f"impersonation-{new_id()}"

    session = await create_session(
        user_id=actor_id,
        auth_context="TENANT",
        tenant_id=tenant["id"],
        tenant_slug=tenant["slug"],
        membership_id=membership_id,
        role="TENANT_ADMIN",
        ip=request.headers.get("x-forwarded-for", "").split(",")[0].strip(),
        user_agent=request.headers.get("user-agent"),
    )

    # Criar o JWT com claims extras de impersonação
    from datetime import datetime, timezone, timedelta
    from security import get_jwt_secret, JWT_ALGORITHM
    import uuid as _uuid
    import jwt as _jwt

    now = datetime.now(timezone.utc)
    payload = {
        "sub": actor_id,
        "user_id": actor_id,
        "email": actor_email,
        "name": actor.get("name", "Super Admin"),
        "is_super_admin": False,
        "auth_context": "TENANT",
        "tenant_id": tenant["id"],
        "tenant_slug": tenant["slug"],
        "membership_id": membership_id,
        "role": "TENANT_ADMIN",
        "session_id": session["id"],
        "is_impersonation": True,
        "impersonated_by": actor_id,
        "type": "access",
        "jti": str(_uuid.uuid4()),
        "iat": int(now.timestamp()),
        # Sessão de impersonação dura 4 horas
        "exp": int((now + timedelta(hours=4)).timestamp()),
    }
    access_token = _jwt.encode(payload, get_jwt_secret(), algorithm=JWT_ALGORITHM)

    # Refresh token de curta duração para impersonação
    refresh_raw = create_refresh_token_raw()
    refresh_hash = hash_token(refresh_raw)
    expires_at = (now + timedelta(hours=4)).isoformat()
    await db.refresh_tokens.insert_one(
        {
            "id": new_id(),
            "session_id": session["id"],
            "user_id": actor_id,
            "tenant_id": tenant["id"],
            "token_hash": refresh_hash,
            "family_id": new_id(),
            "created_at": now.isoformat(),
            "expires_at": expires_at,
            "used_at": None,
            "revoked_at": None,
            "is_impersonation": True,
        }
    )

    await log_audit(
        action="SUPER_ADMIN_IMPERSONATION_START",
        entity="tenant",
        entity_id=tenant_id,
        tenant_id=tenant_id,
        user_id=actor_id,
        new_value={
            "tenant_name": tenant["name"],
            "tenant_slug": tenant["slug"],
            "impersonated_by": actor_email,
        },
        request=request,
    )
    await log_security_event(
        event_type=SecurityEventType.LOGIN_SUCCESS,
        tenant_id=tenant_id,
        tenant_slug=tenant["slug"],
        user_id=actor_id,
        session_id=session["id"],
        ip=request.headers.get("x-forwarded-for", "").split(",")[0].strip(),
        user_agent=request.headers.get("user-agent"),
        metadata={"is_impersonation": True, "impersonated_by": actor_email},
        request=request,
    )

    return {
        "access_token": access_token,
        "refresh_token": refresh_raw,
        "token_type": "bearer",
        "auth_context": "TENANT",
        "tenant_slug": tenant["slug"],
        "tenant_id": tenant["id"],
        "tenant_name": tenant["name"],
        "session_id": session["id"],
        "is_impersonation": True,
        "user": {
            "id": actor_id,
            "name": actor.get("name", "Super Admin"),
            "email": actor_email,
            "avatar_url": actor.get("avatar_url"),
            "is_super_admin": True,
            "role": "TENANT_ADMIN",
        },
        "membership": {
            "role": "TENANT_ADMIN",
            "store_ids": [],
        },
    }


@router.post("/system/smtp-config/test")
async def test_smtp_config(
    payload: SmtpTestPayload,
    request: Request,
    actor: dict = Depends(require_super_admin),
):
    """Envia e-mail de teste e retorna diagnóstico por fase.

    Regra de segurança: bloqueado durante sessão de impersonação.
    Nunca expõe credenciais na resposta.
    """
    # Bloquear durante impersonação
    token_payload: dict = getattr(request.state, "token_payload", {})
    if token_payload.get("is_impersonation"):
        raise HTTPException(
            status_code=403,
            detail={
                "error": "IMPERSONATION_BLOCKED",
                "message": "Este endpoint não está disponível durante uma sessão de impersonação.",
            },
        )

    from email_service import _build_html

    config = payload.config.model_dump()

    # Resolver senha: se sentinel "****", carregar do banco
    resolved_pass = payload.config.resolved_password()
    if resolved_pass == "****" or not resolved_pass:
        stored = await db.system_settings.find_one({"_id": "email_config"})
        if stored:
            resolved_pass = stored.get("smtp_password") or stored.get("smtp_pass") or ""
    config["smtp_password"] = resolved_pass
    config["smtp_tls"]      = payload.config.resolved_tls()

    if not config.get("smtp_host"):
        return {"success": False, "step": "validation", "message": "SMTP_HOST é obrigatório para o teste."}

    html, text = _build_html(
        tenant_name="Lista da Vez (Sistema)",
        invite_link="https://listadavez.com",
        invite_type="TEST",
        to_name="Administrador",
    )

    # Diagnóstico faseado (sem expor credenciais na resposta)
    from email_service import send_smtp_raw
    try:
        await send_smtp_raw(
            config=config,
            to_email=payload.test_email,
            subject="E-mail de teste — Lista da Vez",
            html=html,
            text=text,
        )
        return {
            "success": True,
            "step": "accepted",
            "message": f"E-mail de teste ACEITO pelo servidor para {payload.test_email}. "
                       "Verifique a caixa de entrada (pode cair no spam).",
        }
    except Exception as exc:
        err_str = str(exc)
        step = "unknown"
        if any(k in err_str.lower() for k in ("535", "authentication", "username and password", "badcredential")):
            step = "authentication"
            msg  = "Autenticação falhou. Verifique usuário e senha (Gmail: use Senha de App)."
        elif any(k in err_str.lower() for k in ("connection", "connect", "enetunreach", "timeout", "timed out")):
            step = "connection"
            msg  = f"Não foi possível conectar ao servidor SMTP. Verifique host e porta."
        elif any(k in err_str.lower() for k in ("starttls", "tls", "ssl")):
            step = "tls"
            msg  = "Erro na negociação TLS/STARTTLS. Verifique as configurações de segurança."
        elif any(k in err_str.lower() for k in ("recipient", "user unknown", "no such user")):
            step = "recipient"
            msg  = f"Destinatário {payload.test_email} rejeitado pelo servidor."
        else:
            step = "smtp"
            msg  = f"Erro SMTP: {type(exc).__name__}."
        return {"success": False, "step": step, "message": msg}



class UnlockUserPayload(BaseModel):
    email: str
    tenant_slug: str = ""


@router.post("/system/unlock-user")
async def unlock_user_lockout(
    payload: UnlockUserPayload,
    actor: dict = Depends(require_super_admin),
):
    """Remove o lockout de login de um e-mail para um tenant específico.
    Útil quando o usuário bloqueou a conta por excesso de tentativas falhas.
    """
    from rate_limit_service import reset_email_lockout
    email = payload.email.lower().strip()
    tenant_slug = payload.tenant_slug.lower().strip()
    await reset_email_lockout(email, tenant_slug)
    return {"message": f"Lockout removido para {email}" + (f" no tenant {tenant_slug}" if tenant_slug else "") + "."}
