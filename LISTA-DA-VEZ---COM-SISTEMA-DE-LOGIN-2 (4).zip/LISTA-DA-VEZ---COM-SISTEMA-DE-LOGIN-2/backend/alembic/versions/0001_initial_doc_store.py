"""Initial doc-store schema — uma tabela genérica por coleção Mongo migrada.

Cada tabela usa o padrão (id, tenant_id, doc JSONB) mantendo compatibilidade
total com o adaptador pg_shim (Motor-like) usado pelo código de negócio.

Revision ID: 0001_initial_doc_store
Revises:
Create Date: 2026-08-13
"""
from alembic import op

# revision identifiers, used by Alembic.
revision = "0001_initial_doc_store"
down_revision = None
branch_labels = None
depends_on = None

COLLECTIONS = [
    "achievement_awards", "achievement_requests", "achievement_rules", "achievements",
    "alert_events", "alert_rules", "anonymization_jobs", "attendances", "audit_logs",
    "auth_sessions", "automation_executions", "automation_rules", "backup_jobs",
    "backup_snapshots", "consent_events", "consents", "customer_visits", "data_access_logs",
    "data_processing_records", "data_retention_policies", "data_subject_exports",
    "event_outbox", "export_jobs", "features", "feedbacks", "gamification_events", "goals",
    "grupos_motivos_perda", "historico_administrativo_motivos_perda", "idempotency_keys",
    "invite_tokens", "legal_holds", "loss_reasons", "mfa_configs", "motivation_events",
    "motivos_perda", "multiple_attendance_batches", "notification_deliveries",
    "notification_preferences", "notification_templates", "notifications",
    "password_reset_tokens", "plans", "privacy_requests", "privacy_settings",
    "proactive_approaches", "products", "push_subscriptions", "queue_entries",
    "queue_events", "queue_locks", "queues", "rankings", "refresh_tokens", "restore_jobs",
    "retention_jobs", "sale_items", "sales", "security_events", "seller_badges",
    "seller_profiles", "seller_status_logs", "store_settings", "stores",
    "subgrupos_motivos_perda", "system_settings", "teams", "technical_logs",
    "tenant_features", "tenant_memberships", "tenant_settings", "tenants", "users",
]


def upgrade() -> None:
    for name in COLLECTIONS:
        table = f"doc_{name}"
        op.execute(
            f'CREATE TABLE IF NOT EXISTS {table} ('
            f'row_seq BIGSERIAL PRIMARY KEY, '
            f'id TEXT, '
            f'tenant_id TEXT, '
            f'doc JSONB NOT NULL, '
            f'created_at TIMESTAMPTZ NOT NULL DEFAULT now(), '
            f'updated_at TIMESTAMPTZ NOT NULL DEFAULT now())'
        )
        op.execute(f'CREATE INDEX IF NOT EXISTS "ix_{table}_tenant" ON {table} (tenant_id)')
        op.execute(f'CREATE UNIQUE INDEX IF NOT EXISTS "ux_{table}_id" ON {table} (id) WHERE id IS NOT NULL')
        op.execute(f'CREATE INDEX IF NOT EXISTS "ix_{table}_doc_gin" ON {table} USING GIN (doc)')


def downgrade() -> None:
    for name in COLLECTIONS:
        op.execute(f'DROP TABLE IF EXISTS doc_{name}')
