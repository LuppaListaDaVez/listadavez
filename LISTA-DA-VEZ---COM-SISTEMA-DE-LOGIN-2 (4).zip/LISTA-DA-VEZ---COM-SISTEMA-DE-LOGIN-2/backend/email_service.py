"""Serviço de envio de e-mail transacional — v2.

Modos suportados via EMAIL_PROVIDER:
  smtp  — aiosmtplib (config via email_config ou banco)
  log   — somente desenvolvimento/CI — grava LOGGED, nunca ACCEPTED/DELIVERED

Status corretos:
  PENDING     — criado, aguardando processamento
  PROCESSING  — envio em andamento
  ACCEPTED    — aceito pelo servidor SMTP (não confirma entrega na caixa)
  FAILED      — tentativa falhou definitivamente
  RETRYING    — aguardando nova tentativa (backoff)
  LOGGED      — registrado localmente, sem envio real (modo log)
  DELIVERED   — RESERVADO para confirmação via webhook (nunca definido aqui)
  BOUNCED     — devolvido pelo servidor destinatário

Regras:
  - Modo log NUNCA retorna ACCEPTED ou DELIVERED — sempre LOGGED.
  - Falhas SMTP NUNCA retornam sucesso.
  - Senhas, tokens ou links sensíveis NUNCA aparecem nos logs.
  - Em modo log em produção: warning explícito (não erro silencioso).
"""
import asyncio
import logging
import re
import socket
from datetime import datetime, timezone, timedelta
from email.header import Header
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Optional, Callable, Awaitable

import email_config as cfg

logger = logging.getLogger("lista-da-vez.email")

# ── Aliases de compatibilidade (para testes legados que patcham email_service.SMTP_PASS) ──
EMAIL_PROVIDER = cfg.EMAIL_PROVIDER
SMTP_HOST      = cfg.SMTP_HOST
SMTP_PORT      = cfg.SMTP_PORT
SMTP_USER      = cfg.SMTP_USER
SMTP_PASS      = cfg.SMTP_PASSWORD        # alias legado
SMTP_SECURE    = cfg.SMTP_TLS             # alias legado
SMTP_FROM      = cfg.EMAIL_FROM

# Tipos de status
STATUS_LOGGED     = "LOGGED"
STATUS_ACCEPTED   = "ACCEPTED"
STATUS_FAILED     = "FAILED"
STATUS_RETRYING   = "RETRYING"
STATUS_PROCESSING = "PROCESSING"

# Erros permanentes — não retentáveis
_PERMANENT_ERRORS = (
    "authentication",
    "535",
    "username and password",
    "not accepted",
    "relay access denied",
    "user unknown",
    "invalid address",
    "bad destination",
)

# Regex simples de validação de e-mail (não RFC-completo, mas rejeita injeção)
_EMAIL_RE = re.compile(r"^[^@\s,;]+@[^@\s,;]+\.[^@\s,;]{2,}$")


def _is_smtp_configured() -> bool:
    """Compatibilidade com código legado que importa esta função."""
    return cfg.is_smtp_configured()


def _is_ses_configured() -> bool:
    """Compatibilidade com código legado."""
    return cfg.is_ses_configured()


def _validate_email(addr: str) -> None:
    """Levanta ValueError para endereços inválidos ou com tentativa de injeção."""
    if not addr or not _EMAIL_RE.match(addr.strip()):
        raise ValueError(f"Endereço de e-mail inválido: {addr!r}")
    # Rejeitar quebras de linha em cabeçalhos
    if "\n" in addr or "\r" in addr:
        raise ValueError("Cabeçalho com quebra de linha detectado.")


def _safe_header(value: str) -> str:
    """Codifica assunto/remetente em UTF-8 e rejeita injeção de cabeçalho."""
    if "\n" in value or "\r" in value:
        raise ValueError("Injeção de cabeçalho detectada.")
    return str(Header(value, "utf-8"))


def _is_permanent_error(exc: Exception) -> bool:
    msg = str(exc).lower()
    return any(kw in msg for kw in _PERMANENT_ERRORS)


def _build_message(
    *,
    from_: str,
    from_name: str,
    to_email: str,
    subject: str,
    html: str,
    text: str,
) -> MIMEMultipart:
    _validate_email(to_email)
    msg = MIMEMultipart("alternative")
    from_display = f"{_safe_header(from_name)} <{from_}>" if from_name else from_
    msg["From"]    = from_display
    msg["To"]      = to_email
    msg["Subject"] = _safe_header(subject)
    msg.attach(MIMEText(text, "plain", "utf-8"))
    msg.attach(MIMEText(html,  "html",  "utf-8"))
    return msg


async def _smtp_send_one_attempt(
    *,
    host: str,
    port: int,
    user: str,
    password: str,
    tls: bool,
    ssl: bool,
    timeout: int,
    message: MIMEMultipart,
) -> None:
    """Tenta enviar UMA vez. Levanta exceção em caso de falha (chamador decide retry)."""
    import aiosmtplib

    # start_tls logic:
    # - ssl=True  → SSL direto (porta 465): use_tls=True, start_tls=False
    # - tls=True  → STARTTLS explícito: start_tls=True
    # - ambos False → porta 587 padrão: start_tls=None (aiosmtplib auto-detecta STARTTLS)
    if ssl:
        _use_tls   = True
        _start_tls = False
    elif tls:
        _use_tls   = False
        _start_tls = True
    else:
        # Toggle desativado = porta 587 com STARTTLS automático
        _use_tls   = False
        _start_tls = None  # aiosmtplib negocia STARTTLS se o servidor suportar

    await aiosmtplib.send(
        message,
        hostname=host,
        port=port,
        username=user or None,
        password=password or None,
        use_tls=_use_tls,
        start_tls=_start_tls,
        timeout=timeout,
    )


async def _smtp_send_with_retry(
    *,
    host: str,
    port: int,
    user: str,
    password: str,
    tls: bool,
    ssl: bool,
    timeout: int,
    message: MIMEMultipart,
    max_retries: int = 3,
    on_retry: Optional[Callable[[int, Exception], Awaitable[None]]] = None,
) -> None:
    """Envia com backoff exponencial. Não retenta erros permanentes."""
    last_exc: Optional[Exception] = None
    for attempt in range(1, max_retries + 1):
        try:
            await _smtp_send_one_attempt(
                host=host, port=port, user=user, password=password,
                tls=tls, ssl=ssl, timeout=timeout, message=message,
            )
            return  # sucesso
        except Exception as exc:
            last_exc = exc
            if _is_permanent_error(exc):
                logger.error(
                    "EMAIL_PERMANENT_FAILURE attempt=%d host=%s — %s",
                    attempt, host, type(exc).__name__,
                )
                raise
            if attempt < max_retries:
                wait = 2 ** (attempt - 1)  # 1s, 2s, 4s, …
                logger.warning(
                    "EMAIL_RETRY attempt=%d/%d host=%s error=%s wait=%ds",
                    attempt, max_retries, host, type(exc).__name__, wait,
                )
                if on_retry:
                    await on_retry(attempt, exc)
                await asyncio.sleep(wait)
            else:
                logger.error(
                    "EMAIL_EXHAUSTED attempts=%d host=%s — %s",
                    max_retries, host, type(exc).__name__,
                )
    if last_exc:
        raise last_exc


async def send_smtp_raw(
    *,
    config: dict,
    to_email: str,
    subject: str,
    html: str,
    text: str,
) -> None:
    """Envia via SMTP usando um dict de config explícito (compatibilidade com código legado).

    Keys aceitas (novos nomes e aliases):
      smtp_host, smtp_port, smtp_user,
      smtp_password (novo) ou smtp_pass (alias),
      smtp_tls (novo) ou smtp_secure (alias),
      smtp_ssl, smtp_from, smtp_timeout
    Levanta exceção em caso de falha.
    """
    host    = config.get("smtp_host", "")
    port    = int(config.get("smtp_port", 587))
    user    = config.get("smtp_user", "") or ""
    # Novos nomes com fallback para aliases legados
    pwd     = config.get("smtp_password") or config.get("smtp_pass") or ""
    tls_raw = config.get("smtp_tls") if config.get("smtp_tls") is not None else config.get("smtp_secure", False)
    tls     = str(tls_raw).lower() in ("true", "1", "yes") if isinstance(tls_raw, str) else bool(tls_raw)
    ssl     = str(config.get("smtp_ssl", False)).lower() in ("true", "1", "yes")
    from_   = config.get("smtp_from") or user
    timeout = int(config.get("smtp_timeout", cfg.SMTP_TIMEOUT))

    msg = _build_message(
        from_=from_,
        from_name=cfg.EMAIL_FROM_NAME,
        to_email=to_email,
        subject=subject,
        html=html,
        text=text,
    )
    await _smtp_send_with_retry(
        host=host, port=port, user=user, password=pwd,
        tls=tls, ssl=ssl, timeout=timeout, message=msg,
        max_retries=cfg.EMAIL_MAX_RETRIES,
    )


# ─── Templates ────────────────────────────────────────────────────────────────

def _build_html(
    *,
    tenant_name: str,
    invite_link: str,
    invite_type: str,
    to_name: str,
) -> tuple[str, str]:
    """Retorna (html, text) para o e-mail de convite. Dados do usuário são escapados."""
    import html as _html_mod

    is_owner = invite_type == "TENANT_OWNER"
    is_test  = invite_type == "TEST"

    if is_test:
        tipo_str = "teste de configuração SMTP"
        acao_str = "verificar a configuração de e-mail"
    elif is_owner:
        tipo_str = "administrador da empresa"
        acao_str = "ativar sua conta de administrador"
    else:
        tipo_str = "funcionário"
        acao_str = "ativar sua conta"

    safe_name   = _html_mod.escape(to_name or "")
    safe_tenant = _html_mod.escape(tenant_name or "")
    greeting    = f"Olá{', ' + safe_name if safe_name else ''}!"

    html = f"""<!DOCTYPE html>
<html lang="pt-BR">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Convite — {safe_tenant}</title></head>
<body style="margin:0;padding:0;background:#f4f5f7;font-family:Arial,Helvetica,sans-serif">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f5f7;padding:40px 0">
<tr><td align="center">
  <table width="580" cellpadding="0" cellspacing="0"
         style="background:#ffffff;border-radius:8px;overflow:hidden;
                box-shadow:0 2px 8px rgba(0,0,0,.08)">
    <tr><td style="background:#1a1a2e;padding:32px 40px;text-align:center">
      <h1 style="margin:0;color:#ffffff;font-size:22px;font-weight:700">Lista da Vez</h1>
    </td></tr>
    <tr><td style="padding:40px 40px 24px">
      <p style="margin:0 0 16px;color:#333;font-size:16px">{greeting}</p>
      <p style="margin:0 0 24px;color:#555;font-size:15px;line-height:1.6">
        Você foi convidado como <strong>{tipo_str}</strong> da empresa
        <strong>{safe_tenant}</strong> no sistema <em>Lista da Vez</em>.<br>
        Clique no botão abaixo para {acao_str} e definir sua senha.
      </p>
      <table cellpadding="0" cellspacing="0" width="100%">
        <tr><td align="center" style="padding:8px 0 32px">
          <a href="{invite_link}"
             style="display:inline-block;background:#e63946;color:#ffffff;
                    text-decoration:none;padding:14px 36px;border-radius:6px;
                    font-size:16px;font-weight:700;letter-spacing:.3px">
            Ativar minha conta
          </a>
        </td></tr>
      </table>
      <p style="margin:0 0 8px;color:#777;font-size:13px">Ou copie o link abaixo no seu navegador:</p>
      <p style="margin:0 0 24px;word-break:break-all">
        <a href="{invite_link}" style="color:#3a86ff;font-size:13px">{invite_link}</a>
      </p>
      <hr style="border:none;border-top:1px solid #eee;margin:0 0 24px">
      <p style="margin:0;color:#999;font-size:12px;line-height:1.5">
        Este link expira em <strong>72 horas</strong>.<br>
        Se você não esperava este convite, ignore este e-mail — nenhuma conta será criada.
      </p>
    </td></tr>
    <tr><td style="background:#f9f9f9;padding:16px 40px;text-align:center">
      <p style="margin:0;color:#bbb;font-size:11px">&copy; Lista da Vez — Sistema de Gestão de Atendimento</p>
    </td></tr>
  </table>
</td></tr>
</table>
</body></html>"""

    text = (
        f"{greeting.replace('</p>', '').replace('<strong>', '').replace('</strong>', '')}\n\n"
        f"Você foi convidado como {tipo_str} da empresa '{tenant_name}' no Lista da Vez.\n\n"
        f"Para {acao_str} e definir sua senha, acesse:\n{invite_link}\n\n"
        f"Este link expira em 72 horas.\n\n"
        f"Se você não esperava este convite, ignore este e-mail."
    )
    return html, text


def _build_password_reset_html(
    *,
    reset_link: str,
    to_name: str = "",
    tenant_name: str = "",
) -> tuple[str, str]:
    """Retorna (html, text) para redefinição de senha. Link NÃO é logado."""
    import html as _html_mod

    safe_name   = _html_mod.escape(to_name or "")
    safe_tenant = _html_mod.escape(tenant_name or "")
    greeting    = f"Olá{', ' + safe_name if safe_name else ''}!"
    context     = f" da empresa <strong>{safe_tenant}</strong>" if safe_tenant else ""

    html = f"""<!DOCTYPE html>
<html lang="pt-BR">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Redefinição de Senha — Lista da Vez</title></head>
<body style="margin:0;padding:0;background:#f4f5f7;font-family:Arial,Helvetica,sans-serif">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f5f7;padding:40px 0">
<tr><td align="center">
  <table width="580" cellpadding="0" cellspacing="0"
         style="background:#ffffff;border-radius:8px;overflow:hidden;
                box-shadow:0 2px 8px rgba(0,0,0,.08)">
    <tr><td style="background:#1a1a2e;padding:32px 40px;text-align:center">
      <h1 style="margin:0;color:#ffffff;font-size:22px;font-weight:700">Lista da Vez</h1>
    </td></tr>
    <tr><td style="padding:40px 40px 24px">
      <p style="margin:0 0 16px;color:#333;font-size:16px">{greeting}</p>
      <p style="margin:0 0 24px;color:#555;font-size:15px;line-height:1.6">
        Recebemos uma solicitação para redefinir a senha da sua conta{context}.<br>
        Clique no botão abaixo para criar uma nova senha. O link é válido por <strong>1 hora</strong>.
      </p>
      <table cellpadding="0" cellspacing="0" width="100%">
        <tr><td align="center" style="padding:8px 0 32px">
          <a href="{reset_link}"
             style="display:inline-block;background:#e63946;color:#ffffff;
                    text-decoration:none;padding:14px 36px;border-radius:6px;
                    font-size:16px;font-weight:700;letter-spacing:.3px">
            Redefinir minha senha
          </a>
        </td></tr>
      </table>
      <p style="margin:0 0 8px;color:#777;font-size:13px">Ou copie o link abaixo no seu navegador:</p>
      <p style="margin:0 0 24px;word-break:break-all">
        <a href="{reset_link}" style="color:#3a86ff;font-size:13px">{reset_link}</a>
      </p>
      <hr style="border:none;border-top:1px solid #eee;margin:0 0 24px">
      <p style="margin:0;color:#999;font-size:12px;line-height:1.5">
        Se você não solicitou a redefinição de senha, ignore este e-mail — sua senha permanece a mesma.<br>
        Por segurança, este link expira em <strong>1 hora</strong>.
      </p>
    </td></tr>
    <tr><td style="background:#f9f9f9;padding:16px 40px;text-align:center">
      <p style="margin:0;color:#bbb;font-size:11px">&copy; Lista da Vez — Sistema de Gestão de Atendimento</p>
    </td></tr>
  </table>
</td></tr>
</table>
</body></html>"""

    text = (
        f"{greeting}\n\n"
        f"Recebemos uma solicitação para redefinir a senha da sua conta.\n\n"
        f"Para criar uma nova senha, acesse o link de redefinição enviado.\n\n"
        f"Este link expira em 1 hora.\n\n"
        f"Se você não solicitou esta redefinição, ignore este e-mail."
    )
    return html, text


# ─── Funções públicas ──────────────────────────────────────────────────────────

async def send_password_reset_email(
    *,
    to_email: str,
    to_name: str = "",
    reset_link: str,
    tenant_name: str = "",
    tenant_id: str = "",
    log_delivery_fn=None,
) -> bool:
    """Envia e-mail de redefinição de senha.

    Retorna True se ACEITO pelo provedor.
    Retorna False se falhou OU se foi somente registrado no log (modo log).
    Status de entrega: ACCEPTED (smtp ok) | FAILED (smtp erro) | LOGGED (modo log).
    """
    subject = "Redefinição de senha — Lista da Vez"
    html, text = _build_password_reset_html(
        reset_link=reset_link,
        to_name=to_name,
        tenant_name=tenant_name,
    )

    provider_used = EMAIL_PROVIDER
    status: str = STATUS_FAILED
    error_msg: Optional[str] = None
    success = False

    try:
        if EMAIL_PROVIDER == "smtp" and _is_smtp_configured():
            msg = _build_message(
                from_=cfg.EMAIL_FROM,
                from_name=cfg.EMAIL_FROM_NAME,
                to_email=to_email,
                subject=subject,
                html=html,
                text=text,
            )
            await _smtp_send_with_retry(
                host=cfg.SMTP_HOST, port=cfg.SMTP_PORT,
                user=cfg.SMTP_USER, password=cfg.SMTP_PASSWORD,
                tls=cfg.SMTP_TLS, ssl=cfg.SMTP_SSL,
                timeout=cfg.SMTP_TIMEOUT, message=msg,
                max_retries=cfg.EMAIL_MAX_RETRIES,
            )
            status = STATUS_ACCEPTED
            success = True
            logger.info(
                "EMAIL_ACCEPTED provider=smtp to=<masked> type=PASSWORD_RESET"
            )
        else:
            # Modo log ou smtp sem config: registra localmente, NÃO envia
            provider_used = "LOG"
            status = STATUS_LOGGED
            success = False   # log não é envio real
            if EMAIL_PROVIDER == "smtp":
                logger.warning(
                    "EMAIL_NOT_CONFIGURED type=PASSWORD_RESET — "
                    "EMAIL_PROVIDER=smtp mas SMTP_HOST/USER/PASSWORD ausentes. "
                    "Configure via painel Super Admin."
                )
            else:
                logger.info(
                    "DEV_EMAIL_RESET mode=log to=<masked> type=PASSWORD_RESET "
                    "[link omitido por segurança]"
                )

    except Exception as exc:
        error_msg = type(exc).__name__  # nunca logar a senha no stack trace
        status = STATUS_FAILED
        success = False
        logger.error(
            "EMAIL_FAILED provider=%s type=PASSWORD_RESET error=%s",
            provider_used, type(exc).__name__,
        )

    if log_delivery_fn is not None:
        try:
            await log_delivery_fn(
                tenant_id=tenant_id,
                event_type="PASSWORD_RESET",
                channel="EMAIL",
                recipient_user_id=f"reset:{to_email[:3]}***",  # mascarado
                status=status,
                provider=provider_used.upper(),
                error_message=error_msg,
            )
        except Exception as exc:
            logger.warning("log_delivery falhou: %s", type(exc).__name__)

    return success


async def send_invite_email(
    *,
    to_email: str,
    to_name: str = "",
    invite_link: str,
    invite_type: str,
    tenant_name: str,
    tenant_id: str,
    log_delivery_fn=None,
) -> bool:
    """Envia e-mail de convite.

    Retorna True se ACEITO pelo provedor SMTP.
    Retorna False se falhou OU somente registrado no log (modo log).
    Status de entrega: ACCEPTED | FAILED | LOGGED.
    """
    subject = f"Convite para ativar sua conta — {tenant_name}"
    html, text = _build_html(
        tenant_name=tenant_name,
        invite_link=invite_link,
        invite_type=invite_type,
        to_name=to_name,
    )

    provider_used = EMAIL_PROVIDER
    status: str = STATUS_FAILED
    error_msg: Optional[str] = None
    success = False

    try:
        if EMAIL_PROVIDER == "smtp" and _is_smtp_configured():
            msg = _build_message(
                from_=cfg.EMAIL_FROM,
                from_name=cfg.EMAIL_FROM_NAME,
                to_email=to_email,
                subject=subject,
                html=html,
                text=text,
            )
            await _smtp_send_with_retry(
                host=cfg.SMTP_HOST, port=cfg.SMTP_PORT,
                user=cfg.SMTP_USER, password=cfg.SMTP_PASSWORD,
                tls=cfg.SMTP_TLS, ssl=cfg.SMTP_SSL,
                timeout=cfg.SMTP_TIMEOUT, message=msg,
                max_retries=cfg.EMAIL_MAX_RETRIES,
            )
            status = STATUS_ACCEPTED
            success = True
            logger.info(
                "EMAIL_ACCEPTED provider=smtp to=<masked> type=%s", invite_type
            )
        else:
            provider_used = "LOG"
            status = STATUS_LOGGED
            success = False
            if EMAIL_PROVIDER == "smtp":
                logger.warning(
                    "EMAIL_NOT_CONFIGURED type=%s — "
                    "EMAIL_PROVIDER=smtp mas SMTP_HOST/USER/PASSWORD ausentes.",
                    invite_type,
                )
            else:
                logger.info(
                    "DEV_EMAIL_INVITE mode=log to=<masked> tenant=%s type=%s "
                    "[link omitido por segurança]",
                    tenant_id, invite_type,
                )

    except Exception as exc:
        error_msg = type(exc).__name__
        status = STATUS_FAILED
        success = False
        logger.error(
            "EMAIL_FAILED provider=%s type=%s error=%s",
            provider_used, invite_type, type(exc).__name__,
        )

    if log_delivery_fn is not None:
        try:
            await log_delivery_fn(
                tenant_id=tenant_id,
                event_type=f"INVITE_{invite_type}",
                channel="EMAIL",
                recipient_user_id=f"invite:{to_email[:3]}***",  # mascarado
                status=status,
                provider=provider_used.upper(),
                error_message=error_msg,
            )
        except Exception as exc:
            logger.warning("log_delivery falhou: %s", type(exc).__name__)

    return success
