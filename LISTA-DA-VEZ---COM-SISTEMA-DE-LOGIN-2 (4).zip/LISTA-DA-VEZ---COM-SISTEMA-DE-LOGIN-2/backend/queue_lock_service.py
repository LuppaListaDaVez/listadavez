"""Queue Lock Service — P1 Proteção de Concorrência.

Implementa soft lock por operação de fila para evitar:
- Dois atendimentos simultâneos para o mesmo vendedor
- Dois vendedores recebendo o mesmo cliente
- Race condition entre start_attendance concorrentes

Usa coleção `queue_locks` com:
- Unique index em lock_key
- TTL automático para limpeza (60 segundos)

Context manager async:
    async with seller_lock(tenant_id, seller_id, "START_ATTENDANCE"):
        # operação protegida
"""
import logging
from contextlib import asynccontextmanager
from datetime import datetime, timezone, timedelta

from fastapi import HTTPException
from db import db
from models import new_id

logger = logging.getLogger("lista-da-vez.queue_lock")

LOCK_TTL_SECONDS = 30  # locks expiram em 30s (timeout de segurança)


async def _try_acquire(lock_key: str, tenant_id: str, metadata: dict) -> str | None:
    """Tenta adquirir lock. Retorna lock_id ou None se já existe."""
    lock_id = new_id()
    expires_at = datetime.now(timezone.utc) + timedelta(seconds=LOCK_TTL_SECONDS)
    try:
        await db.queue_locks.insert_one({
            "lock_key": lock_key,
            "lock_id": lock_id,
            "tenant_id": tenant_id,
            "expires_at": expires_at,
            "created_at": datetime.now(timezone.utc).isoformat(),
            **metadata,
        })
        return lock_id
    except Exception:
        # DuplicateKeyError: lock já existe
        return None


async def _release(lock_key: str, lock_id: str):
    await db.queue_locks.delete_one({"lock_key": lock_key, "lock_id": lock_id})


async def _cleanup_expired_locks():
    """Remove locks expirados (segurança extra além do TTL index)."""
    now = datetime.now(timezone.utc)
    await db.queue_locks.delete_many({"expires_at": {"$lt": now}})


@asynccontextmanager
async def seller_lock(tenant_id: str, seller_id: str, operation: str):
    """Context manager que adquire lock de vendedor para uma operação."""
    lock_key = f"{tenant_id}:{seller_id}:{operation}"
    lock_id = await _try_acquire(
        lock_key,
        tenant_id,
        {"seller_id": seller_id, "operation": operation},
    )
    if not lock_id:
        # Limpar locks expirados e tentar novamente
        await _cleanup_expired_locks()
        lock_id = await _try_acquire(lock_key, tenant_id, {"seller_id": seller_id, "operation": operation})

    if not lock_id:
        logger.warning("QUEUE_LOCK_CONFLICT seller=%s op=%s", seller_id[:8], operation)
        raise HTTPException(
            status_code=409,
            detail={
                "error": "QUEUE_OPERATION_CONFLICT",
                "message": "Operação em andamento para este vendedor. Aguarde e tente novamente.",
            },
        )

    logger.debug("QUEUE_LOCK_ACQUIRED seller=%s op=%s", seller_id[:8], operation)
    try:
        yield lock_id
    finally:
        await _release(lock_key, lock_id)
        logger.debug("QUEUE_LOCK_RELEASED seller=%s op=%s", seller_id[:8], operation)
