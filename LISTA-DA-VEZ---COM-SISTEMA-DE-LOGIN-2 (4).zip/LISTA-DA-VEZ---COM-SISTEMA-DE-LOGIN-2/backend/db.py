"""Conexão de persistência — PostgreSQL (Supabase) via pg_shim.

Mantém a mesma superfície `db.<collection>.<metodo>()` usada em toda a
aplicação (antes backed by MongoDB/Motor); a persistência física agora é
PostgreSQL. Ver pg_shim/ para o adaptador de compatibilidade.
"""
from pg_shim.database import get_pg_database

db = get_pg_database()


class _AdminShim:
    async def command(self, name):
        if name == "ping":
            await db.execute("SELECT 1")
        return {"ok": 1}


class _ClientShim:
    def __init__(self):
        self.admin = _AdminShim()


client = _ClientShim()


async def init_indexes():
    """Conecta ao pool PostgreSQL e cria os índices no startup da aplicação."""
    await db.connect()
    await db.start_ttl_sweeper()
    # tenants
    await db.tenants.create_index("slug", unique=True)
    # Prompt 1 — CNPJ único: usa partialFilterExpression para ignorar documentos com cnpj=null/ausente
    await db.tenants.create_index(
        "cnpj",
        unique=True,
        partialFilterExpression={"cnpj": {"$type": "string"}},
    )
    # users
    await db.users.create_index("email", unique=True)
    # tenant_memberships
    await db.tenant_memberships.create_index("tenant_id")
    await db.tenant_memberships.create_index("user_id")
    await db.tenant_memberships.create_index(
        [("tenant_id", 1), ("user_id", 1)], unique=True
    )
    # tenant_features
    await db.tenant_features.create_index(
        [("tenant_id", 1), ("feature_key", 1)], unique=True
    )
    # stores
    await db.stores.create_index("tenant_id")
    await db.stores.create_index([("tenant_id", 1), ("code", 1)])
    # audit_logs
    await db.audit_logs.create_index([("tenant_id", 1), ("created_at", -1)])
    # refresh_tokens
    await db.refresh_tokens.create_index("token_hash", unique=True)
    await db.refresh_tokens.create_index("user_id")
    # features
    await db.features.create_index("key", unique=True)
    # Etapa 2
    await db.teams.create_index("tenant_id")
    await db.teams.create_index([("tenant_id", 1), ("store_id", 1)])
    await db.seller_profiles.create_index("tenant_id")
    await db.seller_profiles.create_index([("tenant_id", 1), ("store_id", 1)])
    await db.seller_profiles.create_index([("tenant_id", 1), ("user_id", 1)], unique=True)
    await db.seller_profiles.create_index([("tenant_id", 1), ("team_id", 1)])
    await db.seller_status_logs.create_index([("tenant_id", 1), ("store_id", 1), ("created_at", -1)])
    await db.seller_status_logs.create_index([("tenant_id", 1), ("seller_id", 1), ("created_at", -1)])
    await db.loss_reasons.create_index("tenant_id")
    await db.loss_reasons.create_index([("tenant_id", 1), ("store_id", 1)])
    await db.grupos_motivos_perda.create_index([("empresa_id", 1), ("nome_normalizado", 1)], unique=True)
    await db.grupos_motivos_perda.create_index([("empresa_id", 1), ("ordem", 1)])
    await db.subgrupos_motivos_perda.create_index([("empresa_id", 1), ("grupo_motivo_perda_id", 1), ("nome_normalizado", 1)], unique=True)
    await db.subgrupos_motivos_perda.create_index([("empresa_id", 1), ("grupo_motivo_perda_id", 1), ("ordem", 1)])
    await db.motivos_perda.create_index([("empresa_id", 1), ("subgrupo_motivo_perda_id", 1), ("nome_normalizado", 1)], unique=True)
    await db.motivos_perda.create_index([("empresa_id", 1), ("subgrupo_motivo_perda_id", 1), ("ordem", 1)])
    await db.historico_administrativo_motivos_perda.create_index([("empresa_id", 1), ("criado_em", -1)])
    await db.store_settings.create_index([("tenant_id", 1), ("store_id", 1)], unique=True)
    # Etapa 3 — Queue Engine
    await db.queues.create_index("tenant_id")
    await db.queues.create_index([("tenant_id", 1), ("store_id", 1)])
    await db.queues.create_index([("tenant_id", 1), ("store_id", 1), ("is_default", 1)])
    await db.queues.create_index([("tenant_id", 1), ("store_id", 1), ("status", 1)])
    await db.queue_entries.create_index([("tenant_id", 1), ("queue_id", 1)])
    await db.queue_entries.create_index([("tenant_id", 1), ("queue_id", 1), ("position", 1)])
    await db.queue_entries.create_index([("tenant_id", 1), ("queue_id", 1), ("seller_id", 1)])
    await db.queue_entries.create_index([("tenant_id", 1), ("store_id", 1), ("seller_id", 1)])
    await db.queue_events.create_index([("tenant_id", 1), ("store_id", 1), ("created_at", -1)])
    await db.queue_events.create_index([("tenant_id", 1), ("queue_id", 1), ("created_at", -1)])
    await db.queue_events.create_index([("tenant_id", 1), ("seller_id", 1), ("created_at", -1)])
    await db.customer_visits.create_index("tenant_id")
    await db.customer_visits.create_index([("tenant_id", 1), ("store_id", 1)])
    await db.customer_visits.create_index([("tenant_id", 1), ("seller_id", 1)])
    await db.customer_visits.create_index([("tenant_id", 1), ("created_at", -1)])
    await db.attendances.create_index("tenant_id")
    await db.attendances.create_index([("tenant_id", 1), ("store_id", 1)])
    await db.attendances.create_index([("tenant_id", 1), ("queue_id", 1)])
    await db.attendances.create_index([("tenant_id", 1), ("seller_id", 1)])
    await db.attendances.create_index([("tenant_id", 1), ("status", 1)])
    await db.attendances.create_index([("tenant_id", 1), ("created_at", -1)])
    await db.attendances.create_index([("tenant_id", 1), ("store_id", 1), ("created_at", -1)])
    # Etapa 5 — Registro comercial
    await db.products.create_index("tenant_id")
    await db.products.create_index([("tenant_id", 1), ("sku", 1)])
    await db.products.create_index([("tenant_id", 1), ("sku", 1)], unique=True, sparse=True)
    await db.products.create_index([("tenant_id", 1), ("active", 1)])
    await db.sales.create_index("tenant_id")
    await db.sales.create_index([("tenant_id", 1), ("store_id", 1), ("created_at", -1)])
    await db.sales.create_index([("tenant_id", 1), ("seller_id", 1), ("created_at", -1)])
    await db.sales.create_index([("tenant_id", 1), ("attendance_id", 1)])
    await db.sale_items.create_index([("tenant_id", 1), ("sale_id", 1)])
    await db.sale_items.create_index([("tenant_id", 1), ("product_id", 1)])
    # Etapa 9 — Goals, Rankings, Gamification
    await db.goals.create_index("tenant_id")
    await db.goals.create_index([("tenant_id", 1), ("store_id", 1)])
    await db.goals.create_index([("tenant_id", 1), ("team_id", 1)])
    await db.goals.create_index([("tenant_id", 1), ("seller_id", 1)])
    await db.goals.create_index([("tenant_id", 1), ("status", 1)])
    await db.goals.create_index([("tenant_id", 1), ("type", 1)])
    await db.goals.create_index([("tenant_id", 1), ("period_start", 1), ("period_end", 1)])
    await db.rankings.create_index("tenant_id")
    await db.rankings.create_index([("tenant_id", 1), ("store_id", 1)])
    await db.rankings.create_index([("tenant_id", 1), ("criteria", 1)])
    await db.rankings.create_index([("tenant_id", 1), ("period_start", 1), ("period_end", 1)])
    await db.seller_badges.create_index("tenant_id")
    await db.seller_badges.create_index([("tenant_id", 1), ("seller_id", 1)])
    await db.seller_badges.create_index([("tenant_id", 1), ("badge_key", 1)])
    await db.seller_badges.create_index(
        [("tenant_id", 1), ("seller_id", 1), ("badge_key", 1), ("period_start", 1), ("period_end", 1)],
    )
    await db.gamification_events.create_index("tenant_id")
    await db.gamification_events.create_index([("tenant_id", 1), ("seller_id", 1)])
    await db.gamification_events.create_index([("tenant_id", 1), ("event_type", 1)])
    await db.gamification_events.create_index([("tenant_id", 1), ("created_at", -1)])
    # Etapa 10 — Feedbacks e Notificações
    await db.feedbacks.create_index("tenant_id")
    await db.feedbacks.create_index([("tenant_id", 1), ("seller_id", 1)])
    await db.feedbacks.create_index([("tenant_id", 1), ("author_id", 1)])
    await db.feedbacks.create_index([("tenant_id", 1), ("store_id", 1)])
    await db.feedbacks.create_index([("tenant_id", 1), ("type", 1)])
    await db.feedbacks.create_index([("tenant_id", 1), ("is_acknowledged", 1)])
    await db.feedbacks.create_index([("tenant_id", 1), ("created_at", -1)])
    await db.notifications.create_index("tenant_id")
    await db.notifications.create_index([("tenant_id", 1), ("user_id", 1)])
    await db.notifications.create_index([("tenant_id", 1), ("user_id", 1), ("is_read", 1)])
    await db.notifications.create_index([("tenant_id", 1), ("user_id", 1), ("created_at", -1)])
    # Etapa 13 — Segurança
    await db.auth_sessions.create_index("user_id")
    await db.auth_sessions.create_index("tenant_id")
    await db.auth_sessions.create_index([("user_id", 1), ("revoked_at", 1)])
    await db.auth_sessions.create_index([("tenant_id", 1), ("revoked_at", 1)])
    await db.auth_sessions.create_index("expires_at")
    await db.refresh_tokens.create_index("family_id")
    await db.refresh_tokens.create_index([("family_id", 1), ("revoked_at", 1)])
    await db.refresh_tokens.create_index("session_id")
    await db.security_events.create_index([("tenant_id", 1), ("created_at", -1)])
    await db.security_events.create_index([("event_type", 1), ("created_at", -1)])
    await db.security_events.create_index([("severity", 1), ("created_at", -1)])
    await db.security_events.create_index("created_at")
    await db.idempotency_keys.create_index("scoped_key", unique=True)
    await db.idempotency_keys.create_index([("tenant_id", 1), ("created_at", -1)])
    await db.idempotency_keys.create_index("expires_at")
    await db.mfa_configs.create_index("user_id", unique=True)
    try:
        await db.technical_logs.create_index("created_at", expireAfterSeconds=86400 * 30)  # TTL 30 dias
    except Exception:
        await db.technical_logs.drop_index("created_at_1")
        await db.technical_logs.create_index("created_at", expireAfterSeconds=86400 * 30)
    await db.technical_logs.create_index("level")
    # Etapa 11 — Abordagem Proativa
    await db.proactive_approaches.create_index("tenant_id")
    await db.proactive_approaches.create_index([("tenant_id", 1), ("store_id", 1)])
    await db.proactive_approaches.create_index([("tenant_id", 1), ("seller_id", 1)])
    await db.proactive_approaches.create_index([("tenant_id", 1), ("team_id", 1)])
    await db.proactive_approaches.create_index([("tenant_id", 1), ("status", 1)])
    await db.proactive_approaches.create_index([("tenant_id", 1), ("result", 1)])
    await db.proactive_approaches.create_index([("tenant_id", 1), ("started_at", -1)])
    await db.proactive_approaches.create_index([("tenant_id", 1), ("linked_attendance_id", 1)])
    await db.proactive_approaches.create_index([("tenant_id", 1), ("linked_sale_id", 1)])
    # Etapa 12 — Automações, Alertas, Motivação
    await db.automation_rules.create_index("tenant_id")
    await db.automation_rules.create_index([("tenant_id", 1), ("is_active", 1)])
    await db.automation_executions.create_index([("tenant_id", 1), ("automation_rule_id", 1)])
    await db.automation_executions.create_index("executed_at")
    await db.alert_events.create_index("tenant_id")
    await db.alert_events.create_index([("tenant_id", 1), ("status", 1)])
    await db.alert_events.create_index([("tenant_id", 1), ("store_id", 1)])
    await db.alert_events.create_index([("tenant_id", 1), ("severity", 1)])
    await db.alert_rules.create_index("tenant_id")
    await db.motivation_events.create_index("tenant_id")
    await db.motivation_events.create_index([("tenant_id", 1), ("event_type", 1)])
    await db.motivation_events.create_index([("tenant_id", 1), ("created_at", -1)])
    await db.motivation_events.create_index("dedup_key", unique=True, sparse=True)
    await db.notification_templates.create_index([("tenant_id", 1), ("key", 1)])
    await db.notification_preferences.create_index([("tenant_id", 1), ("user_id", 1)], unique=True)
    await db.notification_deliveries.create_index([("tenant_id", 1), ("recipient_user_id", 1)])
    await db.notification_deliveries.create_index([("tenant_id", 1), ("status", 1)])
    await db.push_subscriptions.create_index([("tenant_id", 1), ("user_id", 1)])
    await db.push_subscriptions.create_index(
        [("tenant_id", 1), ("user_id", 1), ("endpoint", 1)], unique=True, sparse=True
    )
    # Etapa Super Admin — planos únicos por nome
    await db.plans.create_index("name", unique=True)
    # Etapa 14 — LGPD, Privacidade, Retenção, Backup
    await db.privacy_requests.create_index("tenant_id")
    await db.privacy_requests.create_index([("tenant_id", 1), ("status", 1)])
    await db.privacy_requests.create_index([("tenant_id", 1), ("request_type", 1)])
    await db.privacy_requests.create_index([("tenant_id", 1), ("created_at", -1)])
    await db.privacy_requests.create_index([("tenant_id", 1), ("requester_user_id", 1)])
    await db.consents.create_index("tenant_id")
    await db.consents.create_index([("tenant_id", 1), ("subject_user_id", 1)])
    await db.consents.create_index([("tenant_id", 1), ("purpose", 1)])
    await db.consents.create_index([("tenant_id", 1), ("status", 1)])
    await db.consent_events.create_index([("tenant_id", 1), ("consent_id", 1)])
    await db.consent_events.create_index([("tenant_id", 1), ("created_at", -1)])
    await db.data_processing_records.create_index("tenant_id")
    await db.data_processing_records.create_index([("tenant_id", 1), ("data_category", 1)])
    await db.data_retention_policies.create_index("tenant_id")
    await db.data_retention_policies.create_index([("tenant_id", 1), ("data_category", 1)], unique=True)
    await db.retention_jobs.create_index("tenant_id")
    await db.retention_jobs.create_index([("tenant_id", 1), ("status", 1)])
    await db.retention_jobs.create_index([("tenant_id", 1), ("created_at", -1)])
    await db.anonymization_jobs.create_index("tenant_id")
    await db.anonymization_jobs.create_index([("tenant_id", 1), ("status", 1)])
    await db.anonymization_jobs.create_index([("tenant_id", 1), ("request_id", 1)])
    await db.data_subject_exports.create_index("tenant_id")
    await db.data_subject_exports.create_index([("tenant_id", 1), ("status", 1)])
    await db.data_subject_exports.create_index([("tenant_id", 1), ("subject_user_id", 1)])
    await db.data_access_logs.create_index("tenant_id")
    await db.data_access_logs.create_index([("tenant_id", 1), ("actor_user_id", 1)])
    await db.data_access_logs.create_index([("tenant_id", 1), ("created_at", -1)])
    await db.data_access_logs.create_index([("tenant_id", 1), ("data_category", 1)])
    try:
        await db.data_access_logs.create_index("created_at", expireAfterSeconds=86400 * 90)  # TTL 90 dias
    except Exception:
        await db.data_access_logs.drop_index("created_at_1")
        await db.data_access_logs.create_index("created_at", expireAfterSeconds=86400 * 90)
    await db.privacy_settings.create_index("tenant_id", unique=True)
    await db.backup_snapshots.create_index("tenant_id")
    await db.backup_snapshots.create_index([("tenant_id", 1), ("status", 1)])
    await db.backup_snapshots.create_index([("tenant_id", 1), ("created_at", -1)])
    await db.backup_jobs.create_index("tenant_id")
    await db.backup_jobs.create_index([("tenant_id", 1), ("status", 1)])
    await db.restore_jobs.create_index("tenant_id")
    await db.restore_jobs.create_index([("tenant_id", 1), ("status", 1)])
    await db.legal_holds.create_index("tenant_id")
    await db.legal_holds.create_index([("tenant_id", 1), ("status", 1)])
    await db.legal_holds.create_index([("tenant_id", 1), ("entity_id", 1)])
    # ── P0.5 ─────────────────────────────────────────────────────────────────
    # P0.5: Índices essenciais adicionais
    # tenant_memberships — busca por role e status
    await db.tenant_memberships.create_index([("tenant_id", 1), ("role", 1)])
    await db.tenant_memberships.create_index([("tenant_id", 1), ("status", 1)])
    # stores — status e slug
    await db.stores.create_index([("tenant_id", 1), ("status", 1)])
    await db.stores.create_index([("tenant_id", 1), ("slug", 1)], sparse=True)
    # sales — source e status
    await db.sales.create_index([("tenant_id", 1), ("source", 1)], sparse=True)
    await db.sales.create_index([("tenant_id", 1), ("status", 1)])
    # notifications — event_type e type
    await db.notifications.create_index([("tenant_id", 1), ("event_type", 1)], sparse=True)
    await db.notifications.create_index([("tenant_id", 1), ("type", 1)], sparse=True)
    # goals — period
    await db.goals.create_index([("tenant_id", 1), ("period", 1)])
    # audit_logs — entity + action
    await db.audit_logs.create_index([("tenant_id", 1), ("entity", 1), ("created_at", -1)])
    await db.audit_logs.create_index([("tenant_id", 1), ("action", 1), ("created_at", -1)])
    await db.audit_logs.create_index([("tenant_id", 1), ("user_id", 1), ("created_at", -1)])
    # ── P1 ────────────────────────────────────────────────────────────────────
    # queue_locks — unique por lock_key + TTL automático
    await db.queue_locks.create_index("lock_key", unique=True)
    await db.queue_locks.create_index("expires_at", expireAfterSeconds=0)
    # event_outbox
    await db.event_outbox.create_index([("status", 1), ("created_at", 1)])
    await db.event_outbox.create_index("tenant_id")
    await db.event_outbox.create_index("created_at", expireAfterSeconds=86400 * 7)  # 7 dias TTL
    # attendances — source index
    await db.attendances.create_index([("tenant_id", 1), ("source", 1)], sparse=True)
    await db.attendances.create_index([("tenant_id", 1), ("origin", 1)], sparse=True)
    # cache stats (no index needed)
    # customer_visits — index para dashboard
    await db.customer_visits.create_index([("tenant_id", 1), ("store_id", 1), ("created_at", -1)])
    # export_jobs — P1 exportações assíncronas
    await db.export_jobs.create_index([("tenant_id", 1), ("requested_by", 1), ("created_at", -1)])
    await db.export_jobs.create_index([("status", 1), ("created_at", 1)])
    await db.export_jobs.create_index("expires_at", expireAfterSeconds=0)  # TTL automático
    # ── P3 — Índices de performance e segurança ───────────────────────────────    # Estes índices podem já existir com nomes explícitos (via verify_indexes.py).
    # Usamos try/except para ignorar conflitos de nome (IndexOptionsConflict code=85).
    _p3 = [
        ("tenants",         [("status", 1)],                                                          {}),
        ("users",           [("normalized_email", 1)],                                                {"unique": True, "sparse": True}),
        ("users",           [("is_super_admin", 1)],                                                  {}),
        ("stores",          [("tenant_id", 1), ("id", 1)],                                            {}),
        ("seller_profiles", [("tenant_id", 1), ("store_id", 1), ("current_status", 1)],               {}),
        ("queue_entries",   [("tenant_id", 1), ("queue_id", 1), ("status", 1), ("position", 1)],      {}),
        ("queue_entries",   [("tenant_id", 1), ("seller_id", 1), ("status", 1)],                      {}),
        ("attendances",     [("tenant_id", 1), ("store_id", 1), ("status", 1), ("created_at", -1)],   {}),
        ("attendances",     [("tenant_id", 1), ("seller_id", 1), ("status", 1)],                      {}),
        ("attendances",     [("tenant_id", 1), ("created_at", -1)],                                   {}),
        ("goals",           [("tenant_id", 1), ("status", 1), ("period_end", 1)],                     {}),
        ("goals",           [("tenant_id", 1), ("store_id", 1), ("type", 1)],                         {}),
        ("notifications",   [("tenant_id", 1), ("user_id", 1), ("is_read", 1), ("created_at", -1)],   {}),
        ("notifications",   [("tenant_id", 1), ("created_at", -1)],                                   {}),
        ("export_jobs",     [("tenant_id", 1), ("status", 1)],                                        {}),
        ("idempotency_keys",[("tenant_id", 1), ("key", 1)],                                           {"unique": True, "sparse": True}),
        ("idempotency_keys",[("created_at", 1)],                                                      {}),
        ("audit_logs",      [("entity", 1), ("entity_id", 1)],                                        {}),
        ("feedbacks",       [("tenant_id", 1), ("seller_id", 1), ("created_at", -1)],                 {}),
        ("loss_reasons",    [("tenant_id", 1), ("active", 1)],                                        {}),
        ("attendances",     [("tenant_id", 1), ("started_at", 1)],                                     {}),
        ("attendances",     [("tenant_id", 1), ("store_id", 1), ("started_at", 1)],                    {}),
        ("attendances",     [("tenant_id", 1), ("seller_id", 1), ("started_at", 1)],                   {}),
        ("sales",           [("tenant_id", 1), ("attendance_id", 1), ("status", 1)],                   {}),
        ("sales",           [("tenant_id", 1), ("created_at", 1), ("attendance_id", 1)],               {}),
        ("attendances",     [("tenant_id", 1), ("is_preference", 1), ("started_at", 1)],              {}),
        ("attendances",     [("tenant_id", 1), ("seller_id", 1), ("status", 1)],                     {}),
        ("queue_entries",   [("tenant_id", 1), ("queue_id", 1), ("seller_id", 1), ("status", 1)],    {}),
        ("multiple_attendance_batches", [("tenant_id", 1), ("idempotency_key", 1)],                  {}),
        ("attendances",     [("tenant_id", 1), ("multiple_batch_id", 1)],                            {}),
    ]
    for _coll, _keys, _opts in _p3:
        try:
            await db[_coll].create_index(_keys, **_opts)
        except Exception:
            pass  # Índice já existe (possivelmente com nome diferente)

    # ── Prompt 1 — Convites (invite_tokens) ──────────────────────────────────
    await db.invite_tokens.create_index("token_hash", unique=True)
    await db.invite_tokens.create_index([("tenant_id", 1), ("email", 1)])
    await db.invite_tokens.create_index("expires_at", expireAfterSeconds=0)  # TTL automático

    # ── Password Reset Tokens ─────────────────────────────────────────────────
    try:
        await db.password_reset_tokens.create_index("token_hash", unique=True)
        await db.password_reset_tokens.create_index([("user_id", 1), ("tenant_id", 1)])
        await db.password_reset_tokens.create_index("expires_at", expireAfterSeconds=0)  # TTL automático
    except Exception:
        pass

    # ── Achievements ──────────────────────────────────────────────────────────
    try:
        await db.achievements.create_index([("tenant_id", 1)])
        await db.achievements.create_index([("tenant_id", 1), ("status", 1)])
        await db.achievements.create_index([("tenant_id", 1), ("scope", 1)])
        await db.achievements.create_index([("tenant_id", 1), ("category", 1)])

        await db.achievement_rules.create_index([("tenant_id", 1), ("achievement_id", 1)])

        await db.achievement_awards.create_index([("tenant_id", 1), ("seller_id", 1)])
        await db.achievement_awards.create_index([("tenant_id", 1), ("achievement_id", 1)])
        await db.achievement_awards.create_index([("tenant_id", 1), ("store_id", 1)])
        await db.achievement_awards.create_index([("tenant_id", 1), ("earned_at", -1)])
        # Fix 4: índice único inclui period_end para granularidade correta
        # Tentar remover índice antigo (sem period_end) se existir
        try:
            await db.achievement_awards.drop_index(
                "tenant_id_1_seller_id_1_achievement_id_1_period_start_1"
            )
        except Exception:
            pass
        await db.achievement_awards.create_index(
            [
                ("tenant_id", 1),
                ("seller_id", 1),
                ("achievement_id", 1),
                ("period_start", 1),
                ("period_end", 1),
            ],
            unique=True,
            sparse=False,
        )

        await db.achievement_requests.create_index([("tenant_id", 1), ("status", 1)])
        await db.achievement_requests.create_index([("tenant_id", 1), ("seller_id", 1)])
        await db.achievement_requests.create_index([("tenant_id", 1), ("achievement_id", 1)])
    except Exception:
        pass

