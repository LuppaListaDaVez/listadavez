"""Endpoints globais Super Admin — Privacidade e Backup (Etapa 14)."""
from fastapi import APIRouter, Depends
from security import require_super_admin
from db import db

router = APIRouter(
    prefix="/admin",
    tags=["admin_privacy"],
    dependencies=[Depends(require_super_admin)],
)


@router.get("/data-protection/overview")
async def data_protection_overview():
    """Visão técnica global de privacidade — sem dados pessoais operacionais."""
    total_tenants = await db.tenants.count_documents({"status": {"$in": ["ACTIVE", "TRIAL"]}})
    tenants_with_settings = await db.privacy_settings.count_documents({})
    total_requests = await db.privacy_requests.count_documents({})
    open_requests = await db.privacy_requests.count_documents({"status": "OPEN"})
    total_holds = await db.legal_holds.count_documents({"status": "ACTIVE"})
    total_backups = await db.backup_snapshots.count_documents({"status": "COMPLETED"})
    return {
        "total_active_tenants": total_tenants,
        "tenants_with_privacy_settings": tenants_with_settings,
        "total_privacy_requests": total_requests,
        "open_privacy_requests": open_requests,
        "active_legal_holds": total_holds,
        "completed_backups": total_backups,
    }


@router.get("/backups/health")
async def backups_health():
    """Saúde técnica de backups — sem conteúdo de dados pessoais."""
    total = await db.backup_snapshots.count_documents({})
    completed = await db.backup_snapshots.count_documents({"status": "COMPLETED"})
    failed = await db.backup_snapshots.count_documents({"status": "FAILED"})
    expired = await db.backup_snapshots.count_documents({"status": "EXPIRED"})
    return {"total": total, "completed": completed, "failed": failed, "expired": expired}


@router.get("/backups/jobs")
async def backup_jobs_global():
    cursor = db.backup_jobs.find({}, {"_id": 0}).sort("created_at", -1).limit(50)
    return await cursor.to_list(length=50)


@router.get("/restore/jobs")
async def restore_jobs_global():
    cursor = db.restore_jobs.find({}, {"_id": 0}).sort("created_at", -1).limit(50)
    return await cursor.to_list(length=50)


@router.get("/privacy/system-data-map")
async def system_data_map():
    """Mapa técnico de dados — sem dados pessoais."""
    cursor = db.data_processing_records.find({}, {"_id": 0}).limit(200)
    return await cursor.to_list(length=200)
