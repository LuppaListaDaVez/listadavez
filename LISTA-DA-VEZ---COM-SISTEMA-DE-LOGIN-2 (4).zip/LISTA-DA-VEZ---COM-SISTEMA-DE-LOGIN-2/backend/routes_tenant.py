"""Tenant-scoped routes (/api/tenants/{tenant_slug})."""
import os
from datetime import datetime, timezone, timedelta

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse

from db import db
from features import get_tenant_features
from models import (
    AdminSetPassword,
    InviteCreate,
    SettingsUpdate,
    StoreCreate,
    StoreStatusUpdate,
    StoreUpdate,
    TenantUserCreate,
    TenantUserUpdate,
    UserStatusUpdate,
    new_id,
    utcnow_iso,
)
from security import (
    hash_password,
    resolve_tenant_context,
    require_roles,
    hash_token,
    create_refresh_token_raw,
)
from audit import log_audit
from security_event_service import log_security_event, SecurityEventType
from permissions import get_permissions_for_role
from permission_service import get_accessible_store_ids, can_access_store
from rate_limit_service import make_rate_limit_dep
from external_notification_service import send_invite_email

_INVITE_EXPIRES_HOURS = 72

router = APIRouter(prefix="/tenants/{tenant_slug}", tags=["tenant"])


# ---------- Public tenant info (for login screen) ----------
@router.get("/public")
async def public_tenant(tenant_slug: str):
    tenant = await db.tenants.find_one({"slug": tenant_slug})
    if not tenant:
        raise HTTPException(status_code=404, detail="Empresa não encontrada.")
    return {
        "name": tenant["name"],
        "slug": tenant["slug"],
        "status": tenant["status"],
        "logo_url": tenant.get("logo_url"),
        "primary_color": tenant.get("primary_color"),
    }


async def _clean(cursor):
    items = await cursor.to_list(length=500)
    for it in items:
        it.pop("_id", None)
    return items


# ---------- Context ----------
@router.get("/context")
async def get_context(ctx: dict = Depends(resolve_tenant_context)):
    tenant = ctx["tenant"]
    membership = ctx["membership"]
    user = ctx["user"]
    features = await get_tenant_features(tenant["id"])

    # Stores visíveis por role
    role = membership["role"]
    accessible_store_ids = await get_accessible_store_ids(membership, tenant["id"])
    stores_cursor = db.stores.find({"tenant_id": tenant["id"]}).sort("name", 1)
    all_stores = await _clean(stores_cursor)
    if role in ("STORE_MANAGER", "SUPERVISOR", "SELLER"):
        stores = [s for s in all_stores if s["id"] in accessible_store_ids]
    elif role == "REGIONAL_MANAGER":
        bound = membership.get("store_ids") or []
        stores = [s for s in all_stores if not bound or s["id"] in bound]
    else:
        stores = all_stores

    permissions = get_permissions_for_role(role)

    return {
        "tenant": {
            "id": tenant["id"],
            "name": tenant["name"],
            "slug": tenant["slug"],
            "status": tenant["status"],
            "logo_url": tenant.get("logo_url"),
            "primary_color": tenant.get("primary_color"),
        },
        "user": {
            "id": user["id"],
            "name": user.get("name"),
            "email": user.get("email"),
        },
        "membership": {
            "id": membership.get("id"),
            "role": role,
            "store_ids": membership.get("store_ids", []),
            "status": membership.get("status"),
        },
        "user_role": role,
        "permissions": permissions,
        "store_ids": membership.get("store_ids", []),
        "accessible_store_ids": accessible_store_ids,
        "features": features,
        "stores": stores,
    }


# ---------- Permissions ----------
@router.get("/permissions/me")
async def get_my_permissions(ctx: dict = Depends(resolve_tenant_context)):
    """Retorna permissões, features e stores acessíveis do usuário autenticado."""
    membership = ctx["membership"]
    tenant = ctx["tenant"]
    role = membership["role"]
    accessible_store_ids = await get_accessible_store_ids(membership, tenant["id"])
    return {
        "role": role,
        "permissions": get_permissions_for_role(role),
        "features": await get_tenant_features(tenant["id"]),
        "accessible_store_ids": accessible_store_ids,
    }


# ---------- Stores ----------
def _stores_visible_to_membership(membership: dict):
    base = {"tenant_id": membership["tenant_id"]}
    if membership["role"] == "STORE_MANAGER":
        ids = membership.get("store_ids") or []
        base["id"] = {"$in": ids}
    return base


@router.get("/stores")
async def list_stores(ctx: dict = Depends(resolve_tenant_context)):
    q = _stores_visible_to_membership(ctx["membership"])
    return await _clean(db.stores.find(q).sort("name", 1))


@router.post("/stores", status_code=201)
async def create_store(
    payload: StoreCreate,
    request: Request,
    ctx: dict = Depends(require_roles("TENANT_ADMIN", "REGIONAL_MANAGER")),
):
    tenant = ctx["tenant"]
    actor = ctx["user"]
    if await db.stores.find_one({"tenant_id": tenant["id"], "code": payload.code}):
        raise HTTPException(status_code=409, detail="Já existe uma unidade com este código.")
    now = utcnow_iso()
    store = {
        "id": new_id(),
        "tenant_id": tenant["id"],
        **payload.model_dump(),
        "status": "ACTIVE",
        "created_at": now,
        "updated_at": now,
    }
    await db.stores.insert_one(store)
    # Auto-create store_settings
    from routes_store_settings import ensure_settings
    await ensure_settings(tenant["id"], store["id"])
    await log_audit(
        action="STORE_CREATED",
        entity="store",
        entity_id=store["id"],
        tenant_id=tenant["id"],
        store_id=store["id"],
        user_id=actor["id"],
        new_value={"name": store["name"], "code": store["code"]},
        request=request,
    )
    store.pop("_id", None)
    return store


@router.get("/stores/{store_id}")
async def get_store(store_id: str, ctx: dict = Depends(resolve_tenant_context)):
    q = _stores_visible_to_membership(ctx["membership"])
    q["id"] = store_id
    store = await db.stores.find_one(q)
    if not store:
        raise HTTPException(status_code=404, detail="Unidade não encontrada.")
    store.pop("_id", None)
    return store


@router.put("/stores/{store_id}")
async def update_store(
    store_id: str,
    payload: StoreUpdate,
    request: Request,
    ctx: dict = Depends(require_roles("TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER")),
):
    tenant = ctx["tenant"]
    store = await db.stores.find_one({"tenant_id": tenant["id"], "id": store_id})
    if not store:
        raise HTTPException(status_code=404, detail="Unidade não encontrada.")
    updates = {k: v for k, v in payload.model_dump(exclude_none=True).items()}
    if updates:
        updates["updated_at"] = utcnow_iso()
        await db.stores.update_one({"id": store_id}, {"$set": updates})
    await log_audit(
        action="STORE_UPDATED",
        entity="store",
        entity_id=store_id,
        tenant_id=tenant["id"],
        store_id=store_id,
        user_id=ctx["user"]["id"],
        new_value=updates,
        request=request,
    )
    updated = await db.stores.find_one({"id": store_id})
    updated.pop("_id", None)
    return updated


@router.patch("/stores/{store_id}/status")
async def update_store_status(
    store_id: str,
    payload: StoreStatusUpdate,
    request: Request,
    ctx: dict = Depends(require_roles("TENANT_ADMIN", "REGIONAL_MANAGER")),
):
    tenant = ctx["tenant"]
    store = await db.stores.find_one({"tenant_id": tenant["id"], "id": store_id})
    if not store:
        raise HTTPException(status_code=404, detail="Unidade não encontrada.")
    await db.stores.update_one(
        {"id": store_id},
        {"$set": {"status": payload.status, "updated_at": utcnow_iso()}},
    )
    await log_audit(
        action="STORE_UPDATED",
        entity="store",
        entity_id=store_id,
        tenant_id=tenant["id"],
        store_id=store_id,
        user_id=ctx["user"]["id"],
        old_value={"status": store["status"]},
        new_value={"status": payload.status},
        request=request,
    )
    return {"id": store_id, "status": payload.status}


# ---------- Users ----------
@router.get("/users")
async def list_users(
    ctx: dict = Depends(require_roles("TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER", "SUPERVISOR")),
):
    tenant = ctx["tenant"]
    memberships = await _clean(db.tenant_memberships.find({"tenant_id": tenant["id"], "status": {"$ne": "DELETED"}}))
    user_ids = [m["user_id"] for m in memberships]
    users_map = {}
    async for u in db.users.find({"id": {"$in": user_ids}}):
        u.pop("_id", None)
        u.pop("password_hash", None)
        users_map[u["id"]] = u

    # Batch lookup seller_profiles to get team_id per user
    seller_profiles_map: dict = {}
    async for sp in db.seller_profiles.find(
        {"tenant_id": tenant["id"], "user_id": {"$in": user_ids}}
    ):
        sp.pop("_id", None)
        seller_profiles_map[sp["user_id"]] = sp

    result = []
    for m in memberships:
        u = users_map.get(m["user_id"])
        if not u:
            continue
        sp = seller_profiles_map.get(u["id"])
        result.append(
            {
                "id": u["id"],
                "name": u["name"],
                "email": u["email"],
                "phone": u.get("phone"),
                "avatar_url": u.get("avatar_url"),
                "status": u.get("status"),
                "membership_id": m["id"],
                "role": m["role"],
                "store_ids": m.get("store_ids", []),
                "team_id": sp.get("team_id") if sp else None,
                "seller_profile_id": sp.get("id") if sp else None,
                "created_at": u.get("created_at"),
            }
        )
    return result


@router.post("/users", status_code=201)
async def create_user(
    payload: TenantUserCreate,
    request: Request,
    ctx: dict = Depends(require_roles("TENANT_ADMIN", "REGIONAL_MANAGER")),
):
    """Criação direta de usuário com senha.

    ATENÇÃO: Este endpoint é mantido apenas para uso interno / seed de testes.
    Em ambiente de produção ele está bloqueado — use POST /users/invite em vez disso.
    """
    if os.environ.get("ENVIRONMENT") == "production":
        raise HTTPException(
            status_code=410,
            detail="Use POST /users/invite para convidar funcionários.",
        )
    tenant = ctx["tenant"]
    actor = ctx["user"]
    email = payload.email.lower().strip()
    now = utcnow_iso()
    existing = await db.users.find_one({"email": email})
    if existing:
        user = existing
        existing_mem = await db.tenant_memberships.find_one(
            {"tenant_id": tenant["id"], "user_id": user["id"]}
        )
        if existing_mem:
            raise HTTPException(
                status_code=409,
                detail="Usuário já é membro desta empresa.",
            )
    else:
        user = {
            "id": new_id(),
            "name": payload.name,
            "email": email,
            "normalized_email": email,
            "token_version": 1,
            "phone": payload.phone,
            "password_hash": hash_password(payload.password),
            "avatar_url": payload.avatar_url,
            "is_super_admin": False,
            "status": "ACTIVE",
            "last_login_at": None,
            "created_at": now,
            "updated_at": now,
        }
        await db.users.insert_one(user)

    membership = {
        "id": new_id(),
        "tenant_id": tenant["id"],
        "user_id": user["id"],
        "role": payload.role,
        "store_ids": payload.store_ids,
        "status": "ACTIVE",
        "created_at": now,
        "updated_at": now,
    }
    await db.tenant_memberships.insert_one(membership)

    # Auto-criar seller_profile para SELLER
    if payload.role == "SELLER" and payload.store_ids:
        existing_profile = await db.seller_profiles.find_one(
            {"tenant_id": tenant["id"], "user_id": user["id"]}
        )
        if not existing_profile:
            await db.seller_profiles.insert_one({
                "id": new_id(),
                "tenant_id": tenant["id"],
                "user_id": user["id"],
                "store_id": payload.store_ids[0],
                "team_id": payload.team_id if payload.team_id else None,
                "employee_code": None,
                "hire_date": None,
                "status": "ACTIVE",
                "current_status": "OFFLINE",
                "avatar_url": payload.avatar_url,
                "created_at": now,
                "updated_at": now,
            })

    await log_audit(
        action="USER_CREATED",
        entity="user",
        entity_id=user["id"],
        tenant_id=tenant["id"],
        user_id=actor["id"],
        new_value={"email": user["email"], "role": payload.role},
        request=request,
    )

    return {
        "id": user["id"],
        "name": user["name"],
        "email": user["email"],
        "phone": user.get("phone"),
        "avatar_url": user.get("avatar_url"),
        "status": user["status"],
        "role": payload.role,
        "store_ids": payload.store_ids,
    }


def _get_frontend_url() -> str:
    return os.environ.get("FRONTEND_URL", "http://localhost:3000").rstrip("/")


@router.post(
    "/users/invite",
    status_code=201,
    dependencies=[Depends(make_rate_limit_dep("INVITE_SEND"))],
)
async def invite_user(
    payload: InviteCreate,
    request: Request,
    ctx: dict = Depends(require_roles("TENANT_ADMIN", "REGIONAL_MANAGER")),
):
    """Convida um funcionário para o tenant pelo fluxo de e-mail/token."""
    tenant = ctx["tenant"]
    actor = ctx["user"]
    actor_membership = ctx["membership"]
    actor_role = actor_membership.get("role")
    email = payload.email.lower().strip()

    # REGIONAL_MANAGER não pode convidar TENANT_ADMIN
    if actor_role == "REGIONAL_MANAGER" and payload.role == "TENANT_ADMIN":
        raise HTTPException(
            status_code=403,
            detail="REGIONAL_MANAGER não pode convidar usuário com role TENANT_ADMIN.",
        )

    # Validar que todos os store_ids pertencem ao tenant
    if payload.store_ids:
        matching = await db.stores.count_documents(
            {"tenant_id": tenant["id"], "id": {"$in": payload.store_ids}}
        )
        if matching != len(payload.store_ids):
            raise HTTPException(
                status_code=422,
                detail="Um ou mais store_ids não pertencem a esta empresa.",
            )

    # REGIONAL_MANAGER só pode convidar para filiais que ele mesmo acessa
    if actor_role == "REGIONAL_MANAGER" and payload.store_ids:
        accessible = set(await get_accessible_store_ids(actor_membership, tenant["id"]))
        forbidden = [s for s in payload.store_ids if s not in accessible]
        if forbidden:
            raise HTTPException(
                status_code=403,
                detail="Você não tem acesso a uma ou mais filiais informadas.",
            )

    # Revogar convite pendente anterior para o mesmo email+tenant
    now_dt = datetime.now(timezone.utc)
    await db.invite_tokens.update_many(
        {
            "tenant_id": tenant["id"],
            "email": email,
            "invite_type": "TENANT_USER",
            "used_at": None,
            "revoked_at": None,
            "expires_at": {"$gt": now_dt},
        },
        {"$set": {"revoked_at": now_dt.isoformat()}},
    )

    # Gerar convite
    token_raw = create_refresh_token_raw()
    token_hash = hash_token(token_raw)
    store_ids = payload.store_ids if payload.role != "TENANT_ADMIN" else []
    await db.invite_tokens.insert_one({
        "id": new_id(),
        "token_hash": token_hash,
        "tenant_id": tenant["id"],
        "invite_type": "TENANT_USER",
        "email": email,
        "role": payload.role,
        "store_ids": store_ids,
        "all_stores": payload.all_stores if payload.role == "REGIONAL_MANAGER" else False,
        "created_by": actor["id"],
        "created_at": now_dt.isoformat(),
        "expires_at": now_dt + timedelta(hours=_INVITE_EXPIRES_HOURS),
        "used_at": None,
        "revoked_at": None,
    })

    invite_link = f"{_get_frontend_url()}/ativar-conta?token={token_raw}"
    await send_invite_email(
        to_email=email,
        invite_link=invite_link,
        tenant_name=tenant["name"],
        tenant_id=tenant["id"],
        invite_type="TENANT_USER",
    )

    await log_audit(
        action="USER_INVITE_SENT",
        entity="tenant",
        entity_id=tenant["id"],
        tenant_id=tenant["id"],
        user_id=actor["id"],
        new_value={"email": email, "role": payload.role, "store_ids": store_ids},
        request=request,
    )
    await log_security_event(
        event_type=SecurityEventType.INVITE_SENT,
        tenant_id=tenant["id"],
        user_id=actor["id"],
        metadata={"invite_type": "TENANT_USER", "role": payload.role},
        request=request,
    )

    return {
        "message": "Convite enviado com sucesso.",
        "invite_sent_to": email,
        "role": payload.role,
        "store_ids": store_ids,
    }


@router.post(
    "/users/invite/{invite_id}/resend",
    dependencies=[Depends(make_rate_limit_dep("INVITE_SEND"))],
)
async def resend_user_invite(
    invite_id: str,
    request: Request,
    ctx: dict = Depends(require_roles("TENANT_ADMIN", "REGIONAL_MANAGER")),
):
    """Revoga convite TENANT_USER anterior e reenvia novo."""
    tenant = ctx["tenant"]
    actor = ctx["user"]

    invite = await db.invite_tokens.find_one(
        {"id": invite_id, "tenant_id": tenant["id"], "invite_type": "TENANT_USER"}
    )
    if not invite:
        raise HTTPException(status_code=404, detail="Convite não encontrado.")

    # Revogar o convite atual
    now_dt = datetime.now(timezone.utc)
    await db.invite_tokens.update_one(
        {"id": invite_id},
        {"$set": {"revoked_at": now_dt.isoformat()}},
    )

    # Gerar novo convite com os mesmos dados
    token_raw = create_refresh_token_raw()
    token_hash = hash_token(token_raw)
    new_invite_id = new_id()
    await db.invite_tokens.insert_one({
        "id": new_invite_id,
        "token_hash": token_hash,
        "tenant_id": tenant["id"],
        "invite_type": "TENANT_USER",
        "email": invite["email"],
        "role": invite["role"],
        "store_ids": invite.get("store_ids", []),
        "all_stores": invite.get("all_stores", False),
        "created_by": actor["id"],
        "created_at": now_dt.isoformat(),
        "expires_at": now_dt + timedelta(hours=_INVITE_EXPIRES_HOURS),
        "used_at": None,
        "revoked_at": None,
    })

    invite_link = f"{_get_frontend_url()}/ativar-conta?token={token_raw}"
    await send_invite_email(
        to_email=invite["email"],
        invite_link=invite_link,
        tenant_name=tenant["name"],
        tenant_id=tenant["id"],
        invite_type="TENANT_USER",
    )

    await log_audit(
        action="USER_INVITE_RESENT",
        entity="tenant",
        entity_id=tenant["id"],
        tenant_id=tenant["id"],
        user_id=actor["id"],
        new_value={"email": invite["email"], "new_invite_id": new_invite_id},
        request=request,
    )

    return {
        "message": "Convite reenviado com sucesso.",
        "invite_sent_to": invite["email"],
        "new_invite_id": new_invite_id,
    }


@router.get("/users/invite/{invite_id}/preview", response_class=HTMLResponse)
async def preview_invite_email(
    invite_id: str,
    ctx: dict = Depends(require_roles("TENANT_ADMIN", "REGIONAL_MANAGER")),
):
    """Retorna HTML do e-mail de convite como prévia visual (apenas admins)."""
    from email_service import _build_html

    tenant = ctx["tenant"]
    invite = await db.invite_tokens.find_one(
        {"id": invite_id, "tenant_id": tenant["id"], "invite_type": "TENANT_USER"}
    )
    if not invite:
        raise HTTPException(status_code=404, detail="Convite não encontrado.")

    invite_link = f"{_get_frontend_url()}/ativar-conta?token=PREVIEW_APENAS"
    html, _ = _build_html(
        tenant_name=tenant["name"],
        invite_link=invite_link,
        invite_type="TENANT_USER",
        to_name="",
    )
    return html


@router.get("/users/invites")
async def list_pending_invites(
    ctx: dict = Depends(require_roles("TENANT_ADMIN", "REGIONAL_MANAGER")),
):
    """Lista convites TENANT_USER pendentes (não usados, não expirados)."""
    tenant = ctx["tenant"]
    now_dt = datetime.now(timezone.utc)
    cursor = db.invite_tokens.find(
        {
            "tenant_id": tenant["id"],
            "invite_type": "TENANT_USER",
            "used_at": None,
            "revoked_at": None,
            "expires_at": {"$gt": now_dt},
        }
    ).sort("created_at", -1)
    invites = await cursor.to_list(200)
    result = []
    for inv in invites:
        inv.pop("_id", None)
        inv.pop("token_hash", None)  # nunca expor o hash
        result.append(inv)
    return {"invites": result, "total": len(result)}


@router.get("/users/{user_id}")
async def get_user(
    user_id: str,
    ctx: dict = Depends(require_roles("TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER", "SUPERVISOR")),
):
    tenant = ctx["tenant"]
    membership = await db.tenant_memberships.find_one(
        {"tenant_id": tenant["id"], "user_id": user_id}
    )
    if not membership:
        raise HTTPException(status_code=404, detail="Usuário não encontrado.")
    user = await db.users.find_one({"id": user_id})
    user.pop("_id", None)
    user.pop("password_hash", None)
    membership.pop("_id", None)
    sp = await db.seller_profiles.find_one({"tenant_id": tenant["id"], "user_id": user_id})
    if sp:
        sp.pop("_id", None)
    return {
        "id": user["id"],
        "name": user["name"],
        "email": user["email"],
        "phone": user.get("phone"),
        "avatar_url": user.get("avatar_url"),
        "status": user["status"],
        "role": membership["role"],
        "store_ids": membership.get("store_ids", []),
        "team_id": sp.get("team_id") if sp else None,
        "seller_profile_id": sp.get("id") if sp else None,
    }


@router.put("/users/{user_id}")
async def update_user(
    user_id: str,
    payload: TenantUserUpdate,
    request: Request,
    ctx: dict = Depends(require_roles("TENANT_ADMIN", "REGIONAL_MANAGER")),
):
    tenant = ctx["tenant"]
    actor = ctx["user"]
    membership = await db.tenant_memberships.find_one(
        {"tenant_id": tenant["id"], "user_id": user_id}
    )
    if not membership:
        raise HTTPException(status_code=404, detail="Usuário não encontrado.")

    # Validação: apenas TENANT_ADMIN pode alterar role
    if payload.role is not None and ctx["membership"]["role"] != "TENANT_ADMIN":
        raise HTTPException(status_code=403, detail="Apenas TENANT_ADMIN pode alterar o papel de um usuário.")

    # Validação: não permitir remover o último TENANT_ADMIN ativo
    if payload.role is not None and membership["role"] == "TENANT_ADMIN" and payload.role != "TENANT_ADMIN":
        count = await db.tenant_memberships.count_documents(
            {"tenant_id": tenant["id"], "role": "TENANT_ADMIN", "status": "ACTIVE"}
        )
        if count <= 1:
            raise HTTPException(
                status_code=409,
                detail="Não é possível remover o último TENANT_ADMIN ativo do tenant.",
            )

    # Validação: STORE_MANAGER não pode criar TENANT_ADMIN
    if payload.role == "TENANT_ADMIN" and ctx["membership"]["role"] != "TENANT_ADMIN":
        raise HTTPException(status_code=403, detail="Apenas TENANT_ADMIN pode promover outro usuário a TENANT_ADMIN.")

    user_updates = {}
    if payload.name is not None:
        user_updates["name"] = payload.name
    # ── Alteração de e-mail ───────────────────────────────────────────────────
    if payload.email is not None:
        new_email = payload.email.lower().strip()
        # Verifica duplicidade: e-mail não pode pertencer a outro usuário
        conflict = await db.users.find_one({"email": new_email, "id": {"$ne": user_id}})
        if conflict:
            raise HTTPException(status_code=409, detail="Este e-mail já está em uso por outro usuário.")
        user_updates["email"] = new_email
    if payload.phone is not None:
        user_updates["phone"] = payload.phone
    if payload.avatar_url is not None:
        user_updates["avatar_url"] = payload.avatar_url
    if user_updates:
        user_updates["updated_at"] = utcnow_iso()
        await db.users.update_one({"id": user_id}, {"$set": user_updates})

    mem_updates = {}
    old_role = membership["role"]
    if payload.role is not None:
        mem_updates["role"] = payload.role
    if payload.store_ids is not None:
        mem_updates["store_ids"] = payload.store_ids
    if mem_updates:
        mem_updates["updated_at"] = utcnow_iso()
        await db.tenant_memberships.update_one(
            {"id": membership["id"]}, {"$set": mem_updates}
        )
        if payload.role is not None and payload.role != old_role:
            await log_audit(
                action="ROLE_CHANGED",
                entity="membership",
                entity_id=membership["id"],
                tenant_id=tenant["id"],
                user_id=actor["id"],
                old_value={"role": old_role},
                new_value={"role": payload.role},
                request=request,
            )
        if payload.store_ids is not None:
            await log_audit(
                action="USER_STORES_UPDATED",
                entity="membership",
                entity_id=membership["id"],
                tenant_id=tenant["id"],
                user_id=actor["id"],
                old_value={"store_ids": membership.get("store_ids", [])},
                new_value={"store_ids": payload.store_ids},
                request=request,
            )

    # Auto-criar seller_profile quando role muda para SELLER
    new_role = payload.role if payload.role is not None else old_role
    if new_role == "SELLER":
        effective_store_ids = (
            payload.store_ids if payload.store_ids is not None
            else membership.get("store_ids", [])
        )
        if effective_store_ids:
            existing_profile = await db.seller_profiles.find_one(
                {"tenant_id": tenant["id"], "user_id": user_id}
            )
            if not existing_profile:
                now_create = utcnow_iso()
                await db.seller_profiles.insert_one({
                    "id": new_id(),
                    "tenant_id": tenant["id"],
                    "user_id": user_id,
                    "store_id": effective_store_ids[0],
                    "team_id": payload.team_id if payload.team_id else None,
                    "employee_code": None,
                    "hire_date": None,
                    "status": "ACTIVE",
                    "current_status": "OFFLINE",
                    "avatar_url": payload.avatar_url,
                    "created_at": now_create,
                    "updated_at": now_create,
                })
            else:
                # Profile já existe — atualizar team_id se informado
                if payload.team_id is not None:
                    await db.seller_profiles.update_one(
                        {"id": existing_profile["id"]},
                        {"$set": {"team_id": payload.team_id or None, "updated_at": utcnow_iso()}},
                    )
    elif payload.team_id is not None:
        # Role não é SELLER mas team_id foi informado (troca de equipe mesmo sem mudar role)
        sp = await db.seller_profiles.find_one({"tenant_id": tenant["id"], "user_id": user_id})
        if sp:
            await db.seller_profiles.update_one(
                {"id": sp["id"]},
                {"$set": {"team_id": payload.team_id or None, "updated_at": utcnow_iso()}},
            )

    await log_audit(
        action="USER_UPDATED",
        entity="user",
        entity_id=user_id,
        tenant_id=tenant["id"],
        user_id=actor["id"],
        new_value={**user_updates, **mem_updates},
        request=request,
    )

    return await get_user(user_id, ctx)


@router.patch("/users/{user_id}/status")
async def update_user_status(
    user_id: str,
    payload: UserStatusUpdate,
    request: Request,
    ctx: dict = Depends(require_roles("TENANT_ADMIN", "REGIONAL_MANAGER")),
):
    tenant = ctx["tenant"]
    membership = await db.tenant_memberships.find_one(
        {"tenant_id": tenant["id"], "user_id": user_id}
    )
    if not membership:
        raise HTTPException(status_code=404, detail="Usuário não encontrado.")
    new_mem_status = "ACTIVE" if payload.status == "ACTIVE" else "INACTIVE"
    await db.tenant_memberships.update_one(
        {"id": membership["id"]},
        {"$set": {"status": new_mem_status, "updated_at": utcnow_iso()}},
    )
    await db.users.update_one(
        {"id": user_id},
        {"$set": {"status": payload.status, "updated_at": utcnow_iso()}},
    )
    await log_audit(
        action="USER_UPDATED",
        entity="user",
        entity_id=user_id,
        tenant_id=tenant["id"],
        user_id=ctx["user"]["id"],
        new_value={"status": payload.status},
        request=request,
    )
    return {"id": user_id, "status": payload.status}


@router.delete("/users/{user_id}", status_code=204)
async def delete_user(
    user_id: str,
    request: Request,
    ctx: dict = Depends(require_roles("TENANT_ADMIN")),
):
    """
    Exclusão de usuário (soft-delete): marca membership como DELETED.
    Dados históricos (vendas, atendimentos) são preservados.
    Restrito a TENANT_ADMIN.
    """
    tenant = ctx["tenant"]
    actor = ctx["user"]

    # Proteção: não pode excluir a si mesmo
    if user_id == actor["id"]:
        raise HTTPException(status_code=400, detail="Você não pode excluir sua própria conta.")

    membership = await db.tenant_memberships.find_one({"tenant_id": tenant["id"], "user_id": user_id})
    if not membership or membership.get("status") == "DELETED":
        raise HTTPException(status_code=404, detail="Usuário não encontrado nesta empresa.")

    # Proteção: não pode excluir o último TENANT_ADMIN ativo
    if membership.get("role") == "TENANT_ADMIN":
        remaining = await db.tenant_memberships.count_documents({
            "tenant_id": tenant["id"],
            "role": "TENANT_ADMIN",
            "status": "ACTIVE",
            "user_id": {"$ne": user_id},
        })
        if remaining == 0:
            raise HTTPException(
                status_code=400,
                detail="Não é possível excluir o único administrador ativo desta empresa.",
            )

    now = utcnow_iso()
    # Soft-delete: desativa a membership e o seller_profile (preserva dados históricos)
    await db.tenant_memberships.update_one(
        {"tenant_id": tenant["id"], "user_id": user_id},
        {"$set": {"status": "DELETED", "updated_at": now}},
    )
    await db.seller_profiles.update_many(
        {"tenant_id": tenant["id"], "user_id": user_id},
        {"$set": {"status": "DELETED", "updated_at": now}},
    )

    await log_audit(
        action="USER_DELETED",
        entity="user",
        entity_id=user_id,
        tenant_id=tenant["id"],
        user_id=actor["id"],
        new_value={"status": "DELETED"},
        request=request,
    )

    from fastapi.responses import Response
    return Response(status_code=204)


@router.post("/users/{user_id}/set-password", status_code=200)
async def admin_set_password(
    user_id: str,
    payload: AdminSetPassword,
    request: Request,
    ctx: dict = Depends(require_roles("TENANT_ADMIN")),
):
    """Admin define nova senha para qualquer usuário do tenant."""
    if not payload.new_password or len(payload.new_password) < 8:
        raise HTTPException(status_code=422, detail="A nova senha deve ter pelo menos 8 caracteres.")

    tenant = ctx["tenant"]
    actor = ctx["user"]
    membership = await db.tenant_memberships.find_one(
        {"tenant_id": tenant["id"], "user_id": user_id}
    )
    if not membership:
        raise HTTPException(status_code=404, detail="Usuário não encontrado.")

    new_hash = hash_password(payload.new_password)
    await db.users.update_one(
        {"id": user_id},
        {
            "$set": {"password_hash": new_hash, "updated_at": utcnow_iso()},
            "$inc": {"token_version": 1},
        },
    )

    await log_audit(
        action="USER_PASSWORD_RESET_BY_ADMIN",
        entity="user",
        entity_id=user_id,
        tenant_id=tenant["id"],
        user_id=actor["id"],
        request=request,
    )

    return {"message": "Senha alterada com sucesso."}


# ---------- Settings ----------
@router.get("/settings")
async def get_settings(ctx: dict = Depends(resolve_tenant_context)):
    tenant = ctx["tenant"]
    settings = await db.tenant_settings.find_one({"tenant_id": tenant["id"]})
    if not settings:
        settings = {
            "id": new_id(),
            "tenant_id": tenant["id"],
            "general_settings": {},
            "created_at": utcnow_iso(),
            "updated_at": utcnow_iso(),
        }
        await db.tenant_settings.insert_one(settings)
    settings.pop("_id", None)
    return settings


@router.put("/settings")
async def update_settings(
    payload: SettingsUpdate,
    ctx: dict = Depends(require_roles("TENANT_ADMIN")),
):
    tenant = ctx["tenant"]
    now = utcnow_iso()
    await db.tenant_settings.update_one(
        {"tenant_id": tenant["id"]},
        {
            "$set": {"general_settings": payload.general_settings, "updated_at": now},
            "$setOnInsert": {
                "id": new_id(),
                "tenant_id": tenant["id"],
                "created_at": now,
            },
        },
        upsert=True,
    )
    return await get_settings(ctx)
