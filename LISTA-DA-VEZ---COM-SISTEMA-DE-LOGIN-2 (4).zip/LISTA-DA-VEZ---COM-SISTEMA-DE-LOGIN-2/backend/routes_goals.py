"""Goals endpoints — Etapa 9."""
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel

from db import db
from security import resolve_tenant_context
from feature_guard import require_feature
from permission_service import get_accessible_store_ids
from permissions import (
    P_GOALS_VIEW_SELF, P_GOALS_VIEW_STORE, P_GOALS_VIEW_TENANT,
    P_GOALS_CREATE, P_GOALS_UPDATE, P_GOALS_CANCEL, P_GOALS_RECALCULATE,
)
import goals_service

router = APIRouter(prefix="/tenants/{tenant_slug}/goals", tags=["goals"])

VIEW_PERMS = (P_GOALS_VIEW_SELF, P_GOALS_VIEW_STORE, P_GOALS_VIEW_TENANT)


async def _notify_sellers_for_collective_goal(tenant_id: str, goal: dict):
    """Notifica os vendedores afetados por uma meta de STORE ou TEAM (cria notificação única por vendedor/meta)."""
    try:
        from models import new_id, utcnow_iso
        scope = goal.get("scope")
        goal_id = goal.get("id")
        title = goal.get("title", "Nova meta")
        period_start = goal.get("period_start", "")[:10]
        period_end = goal.get("period_end", "")[:10]

        # Busca os vendedores afetados
        seller_profiles = []
        if scope == "STORE" and goal.get("store_id"):
            async for sp in db.seller_profiles.find({"tenant_id": tenant_id, "store_id": goal["store_id"], "status": "ACTIVE"}):
                seller_profiles.append(sp)
        elif scope == "TEAM" and goal.get("team_id"):
            async for sp in db.seller_profiles.find({"tenant_id": tenant_id, "team_id": goal["team_id"], "status": "ACTIVE"}):
                seller_profiles.append(sp)

        now = utcnow_iso()
        scope_label = "de unidade" if scope == "STORE" else "de equipe"
        for sp in seller_profiles:
            user_id = sp.get("user_id")
            if not user_id:
                continue
            # Idempotência: não duplicar notificação para o mesmo vendedor/meta
            existing = await db.notifications.find_one({"user_id": user_id, "ref_id": goal_id, "type": "GOAL_CREATED"})
            if existing:
                continue
            await db.notifications.insert_one({
                "id": new_id(),
                "tenant_id": tenant_id,
                "user_id": user_id,
                "type": "GOAL_CREATED",
                "ref_id": goal_id,
                "title": f"Nova meta {scope_label} criada",
                "body": f"'{title}' · {period_start} → {period_end}",
                "read": False,
                "created_at": now,
            })
    except Exception:
        pass  # Notificações são não-críticas


def _has_view_perm(role: str) -> bool:
    from permissions import ROLE_PERMISSIONS
    return any(p in ROLE_PERMISSIONS.get(role, []) for p in VIEW_PERMS)


def _has_perm(role: str, perm: str) -> bool:
    from permissions import ROLE_PERMISSIONS
    return perm in ROLE_PERMISSIONS.get(role, [])


class GoalCreate(BaseModel):
    title: str
    description: Optional[str] = None
    type: str
    scope: str
    store_id: Optional[str] = None
    team_id: Optional[str] = None
    seller_id: Optional[str] = None
    period: str = "MONTHLY"
    target_value: int
    period_start: Optional[str] = None
    period_end: Optional[str] = None


class GoalUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    target_value: Optional[int] = None
    period_end: Optional[str] = None


class GoalStatusPatch(BaseModel):
    action: str  # CANCEL | RECALCULATE
    reason: Optional[str] = None


@router.get("")
async def list_goals(
    status: Optional[str] = None,
    type: Optional[str] = None,
    scope: Optional[str] = None,
    store_id: Optional[str] = None,
    team_id: Optional[str] = None,
    seller_id: Optional[str] = None,
    period_start: Optional[str] = None,
    period_end: Optional[str] = None,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "metas")
    role = ctx["membership"]["role"]
    if not _has_view_perm(role):
        raise HTTPException(403, "Sem permissão para visualizar metas.")

    tenant_id = ctx["tenant"]["id"]
    accessible_store_ids = await get_accessible_store_ids(ctx["membership"], tenant_id)

    filters: dict = {}
    if status:
        normalized_status = goals_service.normalize_goal_status_filter(status)
        if not normalized_status:
            raise HTTPException(400, "Status de meta inválido.")
        filters["status"] = normalized_status
    if type:
        filters["type"] = type.upper()
    if scope:
        filters["scope"] = scope.upper()
    if period_start:
        filters["period_start"] = period_start
    if period_end:
        filters["period_end"] = period_end

    # SELLER: vê metas individuais próprias + metas da sua unidade + metas da sua equipe
    if role == "SELLER":
        profile = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": ctx["user"]["id"]})
        return await goals_service.list_applicable_goals_for_seller(tenant_id, profile, filters=filters, limit=200)
    elif store_id:
        if accessible_store_ids and store_id not in accessible_store_ids:
            raise HTTPException(403, "Sem acesso a esta unidade.")
        filters["store_id"] = store_id
    elif team_id:
        filters["team_id"] = team_id
    elif seller_id and role not in ("TENANT_ADMIN",):
        filters["seller_id"] = seller_id

    # Scoping: roles de loja só veem dados das lojas acessíveis
    if role in ("STORE_MANAGER", "SUPERVISOR", "REGIONAL_MANAGER") and not filters.get("store_id") and not filters.get("seller_id") and not filters.get("team_id"):
        # Sem filtro específico: mostrar metas das stores acessíveis + metas do tenant
        goals = await db.goals.find({
            "tenant_id": tenant_id,
            "$or": [
                {"store_id": {"$in": accessible_store_ids}},
                {"scope": "TENANT"},
            ],
            **{k: v for k, v in filters.items()},
        }).sort("created_at", -1).limit(200).to_list(200)
        return await goals_service.refresh_and_decorate_goals(tenant_id, goals)

    return await goals_service.list_goals(tenant_id, filters)


@router.post("")
async def create_goal(payload: GoalCreate, request: Request, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "metas")
    role = ctx["membership"]["role"]
    if not _has_perm(role, P_GOALS_CREATE):
        raise HTTPException(403, "Sem permissão para criar metas.")

    tenant_id = ctx["tenant"]["id"]
    accessible_store_ids = await get_accessible_store_ids(ctx["membership"], tenant_id)

    data = payload.model_dump()

    # Validar acesso ao store_id
    if data.get("store_id") and accessible_store_ids and data["store_id"] not in accessible_store_ids:
        raise HTTPException(403, "Sem acesso a esta unidade.")

    result = await goals_service.create_goal(
        tenant_id=tenant_id,
        actor_user_id=ctx["user"]["id"],
        data=data,
        request=request,
    )

    # Notifica vendedores afetados por metas de STORE ou TEAM (uma vez por meta, por vendedor)
    scope = data.get("scope", "")
    goal_id_created = result.get("id")
    if scope in ("STORE", "TEAM") and goal_id_created:
        import asyncio
        asyncio.ensure_future(
            _notify_sellers_for_collective_goal(tenant_id, result)
        )

    return result


@router.get("/{goal_id}")
async def get_goal(goal_id: str, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "metas")
    role = ctx["membership"]["role"]
    if not _has_view_perm(role):
        raise HTTPException(403, "Sem permissão para visualizar metas.")

    tenant_id = ctx["tenant"]["id"]
    goal = await goals_service.get_goal(tenant_id, goal_id)

    # SELLER: só pode ver metas próprias
    if role == "SELLER":
        profile = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": ctx["user"]["id"]})
        if not goals_service.goal_applies_to_seller(goal, profile):
            raise HTTPException(403, "Sem permissão para visualizar esta meta.")

    return goal


@router.put("/{goal_id}")
async def update_goal(goal_id: str, payload: GoalUpdate, request: Request, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "metas")
    role = ctx["membership"]["role"]
    if not _has_perm(role, P_GOALS_UPDATE):
        raise HTTPException(403, "Sem permissão para editar metas.")
    return await goals_service.update_goal(
        tenant_id=ctx["tenant"]["id"],
        goal_id=goal_id,
        actor_user_id=ctx["user"]["id"],
        data=payload.model_dump(exclude_none=True),
        request=request,
    )


@router.patch("/{goal_id}/status")
async def patch_goal_status(goal_id: str, payload: GoalStatusPatch, request: Request, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "metas")
    role = ctx["membership"]["role"]
    tenant_id = ctx["tenant"]["id"]

    if payload.action == "CANCEL":
        if not _has_perm(role, P_GOALS_CANCEL):
            raise HTTPException(403, "Sem permissão para cancelar metas.")
        return await goals_service.cancel_goal(
            tenant_id=tenant_id, goal_id=goal_id,
            actor_user_id=ctx["user"]["id"], reason=payload.reason, request=request,
        )
    elif payload.action == "RECALCULATE":
        if not _has_perm(role, P_GOALS_RECALCULATE):
            raise HTTPException(403, "Sem permissão para recalcular metas.")
        return await goals_service.recalculate_goal(
            tenant_id=tenant_id, goal_id=goal_id,
            actor_user_id=ctx["user"]["id"], request=request,
        )
    raise HTTPException(400, "Ação inválida. Use CANCEL ou RECALCULATE.")


@router.post("/{goal_id}/recalculate")
async def recalculate_goal(goal_id: str, request: Request, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "metas")
    role = ctx["membership"]["role"]
    if not _has_perm(role, P_GOALS_RECALCULATE):
        raise HTTPException(403, "Sem permissão para recalcular metas.")
    return await goals_service.recalculate_goal(
        tenant_id=ctx["tenant"]["id"], goal_id=goal_id,
        actor_user_id=ctx["user"]["id"], request=request,
    )
