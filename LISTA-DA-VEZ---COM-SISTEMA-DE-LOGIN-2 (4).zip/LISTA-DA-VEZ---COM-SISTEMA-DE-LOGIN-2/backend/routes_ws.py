"""WebSocket endpoint para eventos da Lista da Vez em tempo real (Etapa 4).

Rota final (via api_router /api): /api/ws/tenants/{tenant_slug}/stores/{store_id}
                                   /api/ws/tenants/{tenant_slug}  (tenant-level, Prompt 11)
Token JWT enviado por query param (?token=...). O token nunca é logado.
"""
import logging

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from db import db
from security import decode_token
from features import is_enabled
from realtime import event_bus, _now_iso

logger = logging.getLogger("lista-da-vez.ws")

router = APIRouter(prefix="/ws", tags=["realtime"])

MANAGER_ALL_STORES = {"TENANT_ADMIN", "REGIONAL_MANAGER"}


async def _authenticate(tenant_slug: str, store_id: str, token: str):
    if not token:
        return None, "no_token"
    try:
        payload = decode_token(token)
        if payload.get("type") != "access":
            return None, "bad_token_type"
    except Exception:  # noqa: BLE001
        return None, "invalid_token"

    user = await db.users.find_one({"id": payload.get("sub")})
    if not user or user.get("status") != "ACTIVE":
        return None, "invalid_user"

    tenant = await db.tenants.find_one({"slug": tenant_slug})
    if not tenant:
        return None, "tenant_not_found"
    if tenant.get("status") not in ("ACTIVE", "TRIAL"):
        return None, "tenant_inactive"

    if user.get("is_super_admin"):
        role, store_ids = "TENANT_ADMIN", []
    else:
        membership = await db.tenant_memberships.find_one(
            {"tenant_id": tenant["id"], "user_id": user["id"], "status": "ACTIVE"}
        )
        if not membership:
            return None, "no_membership"
        role = membership["role"]
        store_ids = membership.get("store_ids") or []

    store = await db.stores.find_one({"tenant_id": tenant["id"], "id": store_id})
    if not store:
        return None, "store_not_found"

    if role not in MANAGER_ALL_STORES and not user.get("is_super_admin"):
        if store_id not in store_ids:
            return None, "forbidden_store"

    if not await is_enabled(tenant["id"], "tempo_real"):
        return None, "feature_disabled"

    return {"user": user, "tenant": tenant, "role": role}, None


async def _authenticate_tenant(tenant_slug: str, token: str):
    """Autenticação para conexão tenant-level (sem loja)."""
    if not token:
        return None, "no_token"
    try:
        payload = decode_token(token)
        if payload.get("type") != "access":
            return None, "bad_token_type"
    except Exception:  # noqa: BLE001
        return None, "invalid_token"

    user = await db.users.find_one({"id": payload.get("sub")})
    if not user or user.get("status") != "ACTIVE":
        return None, "invalid_user"

    tenant = await db.tenants.find_one({"slug": tenant_slug})
    if not tenant:
        return None, "tenant_not_found"
    if tenant.get("status") not in ("ACTIVE", "TRIAL"):
        return None, "tenant_inactive"

    if not user.get("is_super_admin"):
        membership = await db.tenant_memberships.find_one(
            {"tenant_id": tenant["id"], "user_id": user["id"], "status": "ACTIVE"}
        )
        if not membership:
            return None, "no_membership"
        role = membership["role"]
    else:
        role = "TENANT_ADMIN"

    return {"user": user, "tenant": tenant, "role": role}, None


@router.websocket("/tenants/{tenant_slug}/stores/{store_id}")
async def ws_store(websocket: WebSocket, tenant_slug: str, store_id: str):
    token = websocket.query_params.get("token")
    ctx, err = await _authenticate(tenant_slug, store_id, token)
    if err:
        reason = "WEBSOCKET_FORBIDDEN" if err in ("forbidden_store", "feature_disabled", "no_membership", "tenant_inactive") else "WEBSOCKET_AUTH_FAILED"
        logger.warning("%s reason=%s tenant=%s store=%s", reason, err, tenant_slug, store_id)
        await websocket.close(code=4403)
        return

    tenant = ctx["tenant"]
    user = ctx["user"]
    await websocket.accept()
    await event_bus.subscribe_to_store(
        tenant_id=tenant["id"], store_id=store_id, websocket=websocket,
        user_id=user["id"], metadata={"role": ctx["role"]},
    )
    await websocket.send_json({
        "event_type": "connection.ready",
        "tenant_id": tenant["id"], "store_id": store_id, "queue_id": None,
        "timestamp": _now_iso(),
        "payload": {"message": "Conexão em tempo real estabelecida."},
    })
    try:
        while True:
            msg = await websocket.receive_text()
            if msg == "ping":
                await websocket.send_json({"event_type": "pong", "timestamp": _now_iso(), "payload": {}})
    except WebSocketDisconnect:
        pass
    except Exception as e:  # noqa: BLE001
        logger.warning("WEBSOCKET_DISCONNECTED unexpected err=%s", e)
    finally:
        event_bus.unsubscribe(websocket)


@router.websocket("/tenants/{tenant_slug}")
async def ws_tenant(websocket: WebSocket, tenant_slug: str):
    """WebSocket tenant-level: recebe notificações pessoais e eventos motivacionais."""
    token = websocket.query_params.get("token")
    ctx, err = await _authenticate_tenant(tenant_slug, token)
    if err:
        logger.warning("WS_TENANT_AUTH_FAILED reason=%s tenant=%s", err, tenant_slug)
        await websocket.close(code=4403)
        return

    tenant = ctx["tenant"]
    user = ctx["user"]
    await websocket.accept()
    await event_bus.subscribe_to_tenant(
        tenant_id=tenant["id"],
        websocket=websocket,
        user_id=user["id"],
        metadata={"role": ctx["role"]},
    )
    await websocket.send_json({
        "event_type": "connection.ready",
        "tenant_id": tenant["id"],
        "timestamp": _now_iso(),
        "payload": {"message": "Conexão tenant em tempo real estabelecida."},
    })
    try:
        while True:
            msg = await websocket.receive_text()
            if msg == "ping":
                await websocket.send_json({"event_type": "pong", "timestamp": _now_iso(), "payload": {}})
    except WebSocketDisconnect:
        pass
    except Exception as e:  # noqa: BLE001
        logger.warning("WS_TENANT_DISCONNECTED err=%s", e)
    finally:
        event_bus.unsubscribe(websocket)

