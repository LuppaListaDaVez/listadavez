"""Lista da Vez — Catálogo de permissões e matriz de permissões por role (Etapa 6)."""

# ─── Tenant & settings ────────────────────────────────────────────────────────
P_TENANT_VIEW = "tenant.view"
P_TENANT_UPDATE = "tenant.update"
P_TENANT_SETTINGS_VIEW = "tenant.settings.view"
P_TENANT_SETTINGS_UPDATE = "tenant.settings.update"

# ─── Stores ──────────────────────────────────────────────────────────────────
P_STORES_VIEW = "stores.view"
P_STORES_CREATE = "stores.create"
P_STORES_UPDATE = "stores.update"
P_STORES_STATUS_CHANGE = "stores.status_change"

# ─── Users & memberships ──────────────────────────────────────────────────────
P_USERS_VIEW = "users.view"
P_USERS_CREATE = "users.create"
P_USERS_UPDATE = "users.update"
P_USERS_STATUS_CHANGE = "users.status_change"
P_USERS_CHANGE_ROLE = "users.change_role"
P_USERS_ASSIGN_STORES = "users.assign_stores"

# ─── Teams ────────────────────────────────────────────────────────────────────
P_TEAMS_VIEW = "teams.view"
P_TEAMS_CREATE = "teams.create"
P_TEAMS_UPDATE = "teams.update"
P_TEAMS_STATUS_CHANGE = "teams.status_change"

# ─── Sellers ─────────────────────────────────────────────────────────────────
P_SELLERS_VIEW = "sellers.view"
P_SELLERS_CREATE = "sellers.create"
P_SELLERS_UPDATE = "sellers.update"
P_SELLERS_STATUS_CHANGE = "sellers.status_change"
P_SELLERS_VIEW_STATUS_LOGS = "sellers.view_status_logs"

# ─── Queue ────────────────────────────────────────────────────────────────────
P_QUEUE_VIEW = "queue.view"
P_QUEUE_JOIN_SELF = "queue.join_self"
P_QUEUE_LEAVE_SELF = "queue.leave_self"
P_QUEUE_JOIN_ANY = "queue.join_any"
P_QUEUE_LEAVE_ANY = "queue.leave_any"
P_QUEUE_START_SELF = "queue.start_self"
P_QUEUE_START_ANY = "queue.start_any"
P_QUEUE_FINISH_SELF = "queue.finish_self"
P_QUEUE_FINISH_ANY = "queue.finish_any"
P_QUEUE_REORDER = "queue.reorder"
P_QUEUE_MARK_AWAY = "queue.mark_away"
P_QUEUE_RETURN_SELLER = "queue.return_seller"
P_QUEUE_CANCEL_ATTENDANCE = "queue.cancel_attendance"
P_QUEUE_CREATE_QUEUE = "queue.create_queue"
P_QUEUE_UPDATE_QUEUE = "queue.update_queue"
P_QUEUE_STATUS_CHANGE_QUEUE = "queue.status_change_queue"

# ─── Attendances ──────────────────────────────────────────────────────────────
P_ATTENDANCES_VIEW_SELF = "attendances.view_self"
P_ATTENDANCES_VIEW_STORE = "attendances.view_store"
P_ATTENDANCES_VIEW_TENANT = "attendances.view_tenant"
P_ATTENDANCES_FINISH_SELF = "attendances.finish_self"
P_ATTENDANCES_FINISH_ANY = "attendances.finish_any"
P_ATTENDANCES_CANCEL = "attendances.cancel"
P_ATTENDANCES_DETAIL = "attendances.detail"

# ─── Sales ────────────────────────────────────────────────────────────────────
P_SALES_VIEW_SELF = "sales.view_self"
P_SALES_VIEW_STORE = "sales.view_store"
P_SALES_VIEW_TENANT = "sales.view_tenant"
P_SALES_CREATE_SELF = "sales.create_self"
P_SALES_CREATE_MANUAL = "sales.create_manual"
P_SALES_DETAIL = "sales.detail"
P_SALES_UPDATE = "sales.update"
P_SALES_CANCEL = "sales.cancel"

# ─── Products ─────────────────────────────────────────────────────────────────
P_PRODUCTS_VIEW = "products.view"
P_PRODUCTS_CREATE = "products.create"
P_PRODUCTS_UPDATE = "products.update"
P_PRODUCTS_STATUS_CHANGE = "products.status_change"

# ─── Loss reasons ─────────────────────────────────────────────────────────────
P_LOSS_REASONS_VIEW = "loss_reasons.view"
P_LOSS_REASONS_CREATE = "loss_reasons.create"
P_LOSS_REASONS_UPDATE = "loss_reasons.update"
P_LOSS_REASONS_STATUS_CHANGE = "loss_reasons.status_change"

# ─── Dashboard ────────────────────────────────────────────────────────────────
P_DASHBOARD_VIEW_SELF = "dashboard.view_self"
P_DASHBOARD_VIEW_STORE = "dashboard.view_store"
P_DASHBOARD_VIEW_TENANT = "dashboard.view_tenant"
P_DASHBOARD_VIEW_SUPER_ADMIN = "dashboard.view_super_admin"

# ─── Reports ─────────────────────────────────────────────────────────────────
P_REPORTS_VIEW_SELF = "reports.view_self"
P_REPORTS_VIEW_STORE = "reports.view_store"
P_REPORTS_VIEW_TENANT = "reports.view_tenant"
P_REPORTS_EXPORT = "reports.export"

# ─── Goals (Etapa 9) ─────────────────────────────────────────────────────────
P_GOALS_VIEW_SELF = "goals.view_self"
P_GOALS_VIEW_STORE = "goals.view_store"
P_GOALS_VIEW_TENANT = "goals.view_tenant"
P_GOALS_CREATE = "goals.create"
P_GOALS_UPDATE = "goals.update"
P_GOALS_CANCEL = "goals.cancel"
P_GOALS_RECALCULATE = "goals.recalculate"

# ─── Rankings (Etapa 9) ───────────────────────────────────────────────────────
P_RANKINGS_VIEW_SELF = "rankings.view_self"
P_RANKINGS_VIEW_STORE = "rankings.view_store"
P_RANKINGS_VIEW_TENANT = "rankings.view_tenant"
P_RANKINGS_GENERATE = "rankings.generate"

# ─── Gamification (Etapa 9) ───────────────────────────────────────────────────
P_GAMIFICATION_VIEW_SELF = "gamification.view_self"
P_GAMIFICATION_VIEW_STORE = "gamification.view_store"
P_GAMIFICATION_VIEW_TENANT = "gamification.view_tenant"
P_GAMIFICATION_EVALUATE = "gamification.evaluate"
# Conquistas configuráveis
P_GAMIFICATION_CREATE = "gamification.create"
P_GAMIFICATION_UPDATE = "gamification.update"
P_GAMIFICATION_ARCHIVE = "gamification.archive"
P_GAMIFICATION_GRANT = "gamification.grant"
P_GAMIFICATION_APPROVE = "gamification.approve"
P_GAMIFICATION_VIEW_REPORTS = "gamification.view_reports"
P_GAMIFICATION_MANAGE_SETTINGS = "gamification.manage_settings"

# ─── My Performance (Etapa 9) ─────────────────────────────────────────────────
P_PERFORMANCE_VIEW_SELF = "performance.view_self"
P_PERFORMANCE_VIEW_STORE = "performance.view_store"
P_PERFORMANCE_VIEW_TENANT = "performance.view_tenant"

# ─── Feedbacks (Etapa 10) ─────────────────────────────────────────────────────
P_FEEDBACKS_VIEW_SELF = "feedbacks.view_self"
P_FEEDBACKS_VIEW_STORE = "feedbacks.view_store"
P_FEEDBACKS_VIEW_TENANT = "feedbacks.view_tenant"
P_FEEDBACKS_CREATE = "feedbacks.create"
P_FEEDBACKS_UPDATE = "feedbacks.update"
P_FEEDBACKS_ACKNOWLEDGE = "feedbacks.acknowledge"

# ─── Notifications (Etapa 10) ─────────────────────────────────────────────────
P_NOTIFICATIONS_VIEW_SELF = "notifications.view_self"
P_NOTIFICATIONS_MARK_READ = "notifications.mark_read"

# ─── Proactivity (Etapa 11) ───────────────────────────────────────────────────
P_PROACTIVITY_VIEW_SELF = "proactivity.view_self"
P_PROACTIVITY_VIEW_STORE = "proactivity.view_store"
P_PROACTIVITY_VIEW_TENANT = "proactivity.view_tenant"
P_PROACTIVITY_CREATE_SELF = "proactivity.create_self"
P_PROACTIVITY_CREATE_ANY = "proactivity.create_any"
P_PROACTIVITY_UPDATE_SELF = "proactivity.update_self"
P_PROACTIVITY_UPDATE_ANY = "proactivity.update_any"
P_PROACTIVITY_CANCEL_SELF = "proactivity.cancel_self"
P_PROACTIVITY_CANCEL_ANY = "proactivity.cancel_any"
P_PROACTIVITY_CONVERT_TO_ATTENDANCE_SELF = "proactivity.convert_to_attendance_self"
P_PROACTIVITY_CONVERT_TO_ATTENDANCE_ANY = "proactivity.convert_to_attendance_any"
P_PROACTIVITY_CONVERT_TO_SALE_SELF = "proactivity.convert_to_sale_self"
P_PROACTIVITY_CONVERT_TO_SALE_ANY = "proactivity.convert_to_sale_any"
P_PROACTIVITY_CLOSE_NO_SALE_SELF = "proactivity.close_no_sale_self"
P_PROACTIVITY_CLOSE_NO_SALE_ANY = "proactivity.close_no_sale_any"
P_PROACTIVITY_REPORTS_VIEW = "proactivity.reports_view"
P_PROACTIVITY_EXPORT = "proactivity.export"
P_PROACTIVITY_SETTINGS_UPDATE = "proactivity.settings_update"

# ─── Notifications (Etapa 12) ─────────────────────────────────────────────────
P_NOTIF_VIEW_STORE = "notifications.view_store"
P_NOTIF_VIEW_TENANT = "notifications.view_tenant"
P_NOTIF_MARK_READ_ANY = "notifications.mark_read_any"
P_NOTIF_MANAGE = "notifications.manage"
P_NOTIF_PREFERENCES_SELF = "notifications.preferences_update_self"
P_NOTIF_PREFERENCES_ANY = "notifications.preferences_update_any"
P_NOTIF_TEMPLATES_VIEW = "notifications.templates_view"
P_NOTIF_TEMPLATES_MANAGE = "notifications.templates_manage"
P_NOTIF_DELIVERY_LOGS = "notifications.delivery_logs_view"

# ─── Automation (Etapa 12) ────────────────────────────────────────────────────
P_AUTOMATION_VIEW = "automation.view"
P_AUTOMATION_CREATE = "automation.create"
P_AUTOMATION_UPDATE = "automation.update"
P_AUTOMATION_DELETE = "automation.delete"
P_AUTOMATION_ENABLE_DISABLE = "automation.enable_disable"
P_AUTOMATION_EXECUTE = "automation.execute_manual"
P_AUTOMATION_LOGS = "automation.logs_view"

# ─── Alerts (Etapa 12) ────────────────────────────────────────────────────────
P_ALERTS_VIEW_SELF = "alerts.view_self"
P_ALERTS_VIEW_STORE = "alerts.view_store"
P_ALERTS_VIEW_TENANT = "alerts.view_tenant"
P_ALERTS_ACK_SELF = "alerts.acknowledge_self"
P_ALERTS_ACK_ANY = "alerts.acknowledge_any"
P_ALERTS_RESOLVE = "alerts.resolve"
P_ALERTS_SETTINGS_VIEW = "alerts.settings_view"
P_ALERTS_SETTINGS_UPDATE = "alerts.settings_update"

# ─── External Notifications (Etapa 12) ───────────────────────────────────────
P_EXT_NOTIF_VIEW = "external_notifications.view"
P_EXT_NOTIF_TEST = "external_notifications.send_test"
P_EXT_NOTIF_SETTINGS = "external_notifications.settings_view"
P_EXT_NOTIF_SETTINGS_UPDATE = "external_notifications.settings_update"
P_EXT_NOTIF_LOGS = "external_notifications.delivery_logs_view"

# ─── Motivation Events (Etapa 12) ─────────────────────────────────────────────
P_MOTIVATION_VIEW = "motivation_events.view"
P_MOTIVATION_MANAGE = "motivation_events.manage"
P_MOTIVATION_SETTINGS = "motivation_events.settings_update"

# ─── Privacidade e LGPD (Etapa 14) ───────────────────────────────────────────
P_PRIVACY_REQUESTS_VIEW = "privacy.requests.view"
P_PRIVACY_REQUESTS_CREATE = "privacy.requests.create"
P_PRIVACY_REQUESTS_UPDATE = "privacy.requests.update"
P_PRIVACY_REQUESTS_ASSIGN = "privacy.requests.assign"
P_PRIVACY_REQUESTS_RESOLVE = "privacy.requests.resolve"
P_PRIVACY_REQUESTS_EXPORT = "privacy.requests.export"
P_PRIVACY_REQUESTS_ANONYMIZE = "privacy.requests.anonymize"
P_PRIVACY_CONSENTS_VIEW = "privacy.consents.view"
P_PRIVACY_CONSENTS_MANAGE = "privacy.consents.manage"
P_PRIVACY_DATA_MAP_VIEW = "privacy.data_map.view"
P_PRIVACY_DATA_MAP_MANAGE = "privacy.data_map.manage"
P_PRIVACY_SETTINGS_VIEW = "privacy.settings.view"
P_PRIVACY_SETTINGS_UPDATE = "privacy.settings.update"
P_PRIVACY_ACCESS_LOGS_VIEW = "privacy.access_logs.view"

# ─── Retenção (Etapa 14) ──────────────────────────────────────────────────────
P_RETENTION_POLICIES_VIEW = "retention.policies.view"
P_RETENTION_POLICIES_UPDATE = "retention.policies.update"
P_RETENTION_JOBS_VIEW = "retention.jobs.view"
P_RETENTION_JOBS_RUN = "retention.jobs.run"
P_RETENTION_JOBS_CANCEL = "retention.jobs.cancel"
P_LEGAL_HOLD_VIEW = "legal_hold.view"
P_LEGAL_HOLD_CREATE = "legal_hold.create"
P_LEGAL_HOLD_RELEASE = "legal_hold.release"

# ─── Exportação de dados do titular (Etapa 14) ────────────────────────────────
P_DATA_SUBJECT_EXPORT = "data_subject.export"
P_DATA_SUBJECT_EXPORT_SELF = "data_subject.export_self"
P_DATA_SUBJECT_PORTABILITY = "data_subject.portability"
P_DATA_SUBJECT_ANONYMIZE = "data_subject.anonymize"
P_DATA_SUBJECT_DELETE = "data_subject.delete"

# ─── Backup e Restore (Etapa 14) ──────────────────────────────────────────────
P_BACKUP_VIEW = "backup.view"
P_BACKUP_CREATE = "backup.create"
P_BACKUP_DOWNLOAD = "backup.download"
P_BACKUP_DELETE = "backup.delete"
P_BACKUP_RESTORE_PREVIEW = "backup.restore_preview"
P_BACKUP_RESTORE_EXECUTE = "backup.restore_execute"
P_BACKUP_LOGS_VIEW = "backup.logs_view"

# ─── Features & Planos ────────────────────────────────────────────────────────
P_FEATURES_VIEW = "features.view"
P_FEATURES_UPDATE_TENANT = "features.update_tenant"
P_PLANS_VIEW = "plans.view"
P_PLANS_CREATE = "plans.create"
P_PLANS_UPDATE = "plans.update"

# ─── Audit ────────────────────────────────────────────────────────────────────
P_AUDIT_VIEW_TENANT = "audit.view_tenant"
P_AUDIT_VIEW_GLOBAL = "audit.view_global"


# ─── Matriz: Role → Permissões ───────────────────────────────────────────────
ROLE_PERMISSIONS: dict[str, list[str]] = {
    "SUPER_ADMIN": [
        P_DASHBOARD_VIEW_SUPER_ADMIN,
        P_TENANT_VIEW, P_TENANT_UPDATE,
        P_FEATURES_VIEW, P_FEATURES_UPDATE_TENANT,
        P_PLANS_VIEW, P_PLANS_CREATE, P_PLANS_UPDATE,
        P_AUDIT_VIEW_GLOBAL,
    ],
    "TENANT_ADMIN": [
        P_TENANT_VIEW, P_TENANT_UPDATE,
        P_TENANT_SETTINGS_VIEW, P_TENANT_SETTINGS_UPDATE,
        P_STORES_VIEW, P_STORES_CREATE, P_STORES_UPDATE, P_STORES_STATUS_CHANGE,
        P_USERS_VIEW, P_USERS_CREATE, P_USERS_UPDATE, P_USERS_STATUS_CHANGE,
        P_USERS_CHANGE_ROLE, P_USERS_ASSIGN_STORES,
        P_TEAMS_VIEW, P_TEAMS_CREATE, P_TEAMS_UPDATE, P_TEAMS_STATUS_CHANGE,
        P_SELLERS_VIEW, P_SELLERS_CREATE, P_SELLERS_UPDATE,
        P_SELLERS_STATUS_CHANGE, P_SELLERS_VIEW_STATUS_LOGS,
        P_QUEUE_VIEW, P_QUEUE_JOIN_ANY, P_QUEUE_LEAVE_ANY,
        P_QUEUE_START_ANY, P_QUEUE_FINISH_ANY, P_QUEUE_REORDER,
        P_QUEUE_MARK_AWAY, P_QUEUE_RETURN_SELLER,
        P_QUEUE_CANCEL_ATTENDANCE, P_QUEUE_CREATE_QUEUE,
        P_QUEUE_UPDATE_QUEUE, P_QUEUE_STATUS_CHANGE_QUEUE,
        P_ATTENDANCES_VIEW_TENANT, P_ATTENDANCES_FINISH_ANY,
        P_ATTENDANCES_CANCEL, P_ATTENDANCES_DETAIL,
        P_SALES_VIEW_TENANT, P_SALES_CREATE_MANUAL,
        P_SALES_DETAIL, P_SALES_UPDATE, P_SALES_CANCEL,
        P_PRODUCTS_VIEW, P_PRODUCTS_CREATE, P_PRODUCTS_UPDATE, P_PRODUCTS_STATUS_CHANGE,
        P_LOSS_REASONS_VIEW, P_LOSS_REASONS_CREATE,
        P_LOSS_REASONS_UPDATE, P_LOSS_REASONS_STATUS_CHANGE,
        P_DASHBOARD_VIEW_TENANT,
        P_REPORTS_VIEW_TENANT, P_REPORTS_EXPORT,
        P_AUDIT_VIEW_TENANT,
        # Etapa 9
        P_GOALS_VIEW_TENANT, P_GOALS_CREATE, P_GOALS_UPDATE, P_GOALS_CANCEL, P_GOALS_RECALCULATE,
        P_RANKINGS_VIEW_TENANT, P_RANKINGS_GENERATE,
        P_GAMIFICATION_VIEW_TENANT, P_GAMIFICATION_EVALUATE,
        P_GAMIFICATION_CREATE, P_GAMIFICATION_UPDATE, P_GAMIFICATION_ARCHIVE,
        P_GAMIFICATION_GRANT, P_GAMIFICATION_APPROVE, P_GAMIFICATION_VIEW_REPORTS,
        P_GAMIFICATION_MANAGE_SETTINGS,
        P_PERFORMANCE_VIEW_TENANT,
        # Etapa 10
        P_FEEDBACKS_VIEW_TENANT, P_FEEDBACKS_CREATE, P_FEEDBACKS_UPDATE,
        P_NOTIFICATIONS_VIEW_SELF, P_NOTIFICATIONS_MARK_READ,
        # Etapa 11
        P_PROACTIVITY_VIEW_TENANT, P_PROACTIVITY_CREATE_ANY, P_PROACTIVITY_UPDATE_ANY,
        P_PROACTIVITY_CANCEL_ANY, P_PROACTIVITY_CONVERT_TO_ATTENDANCE_ANY,
        P_PROACTIVITY_CONVERT_TO_SALE_ANY, P_PROACTIVITY_CLOSE_NO_SALE_ANY,
        P_PROACTIVITY_REPORTS_VIEW, P_PROACTIVITY_EXPORT, P_PROACTIVITY_SETTINGS_UPDATE,
        # Etapa 12
        P_NOTIF_VIEW_STORE, P_NOTIF_VIEW_TENANT, P_NOTIF_MARK_READ_ANY, P_NOTIF_MANAGE,
        P_NOTIF_PREFERENCES_SELF, P_NOTIF_PREFERENCES_ANY,
        P_NOTIF_TEMPLATES_VIEW, P_NOTIF_TEMPLATES_MANAGE, P_NOTIF_DELIVERY_LOGS,
        P_AUTOMATION_VIEW, P_AUTOMATION_CREATE, P_AUTOMATION_UPDATE,
        P_AUTOMATION_DELETE, P_AUTOMATION_ENABLE_DISABLE, P_AUTOMATION_EXECUTE, P_AUTOMATION_LOGS,
        P_ALERTS_VIEW_SELF, P_ALERTS_VIEW_STORE, P_ALERTS_VIEW_TENANT,
        P_ALERTS_ACK_SELF, P_ALERTS_ACK_ANY, P_ALERTS_RESOLVE,
        P_ALERTS_SETTINGS_VIEW, P_ALERTS_SETTINGS_UPDATE,
        P_EXT_NOTIF_VIEW, P_EXT_NOTIF_TEST, P_EXT_NOTIF_SETTINGS,
        P_EXT_NOTIF_SETTINGS_UPDATE, P_EXT_NOTIF_LOGS,
        P_MOTIVATION_VIEW, P_MOTIVATION_MANAGE, P_MOTIVATION_SETTINGS,
        # Etapa 14 — LGPD, Retenção, Backup
        P_PRIVACY_REQUESTS_VIEW, P_PRIVACY_REQUESTS_CREATE, P_PRIVACY_REQUESTS_UPDATE,
        P_PRIVACY_REQUESTS_ASSIGN, P_PRIVACY_REQUESTS_RESOLVE, P_PRIVACY_REQUESTS_EXPORT,
        P_PRIVACY_REQUESTS_ANONYMIZE,
        P_PRIVACY_CONSENTS_VIEW, P_PRIVACY_CONSENTS_MANAGE,
        P_PRIVACY_DATA_MAP_VIEW, P_PRIVACY_DATA_MAP_MANAGE,
        P_PRIVACY_SETTINGS_VIEW, P_PRIVACY_SETTINGS_UPDATE,
        P_PRIVACY_ACCESS_LOGS_VIEW,
        P_RETENTION_POLICIES_VIEW, P_RETENTION_POLICIES_UPDATE,
        P_RETENTION_JOBS_VIEW, P_RETENTION_JOBS_RUN, P_RETENTION_JOBS_CANCEL,
        P_LEGAL_HOLD_VIEW, P_LEGAL_HOLD_CREATE, P_LEGAL_HOLD_RELEASE,
        P_DATA_SUBJECT_EXPORT, P_DATA_SUBJECT_PORTABILITY, P_DATA_SUBJECT_ANONYMIZE, P_DATA_SUBJECT_DELETE,
        P_BACKUP_VIEW, P_BACKUP_CREATE, P_BACKUP_DOWNLOAD, P_BACKUP_DELETE,
        P_BACKUP_RESTORE_PREVIEW, P_BACKUP_RESTORE_EXECUTE, P_BACKUP_LOGS_VIEW,
    ],
    "REGIONAL_MANAGER": [
        P_STORES_VIEW, P_USERS_VIEW, P_TEAMS_VIEW,
        P_SELLERS_VIEW, P_SELLERS_STATUS_CHANGE, P_SELLERS_VIEW_STATUS_LOGS,
        P_QUEUE_VIEW, P_QUEUE_JOIN_ANY, P_QUEUE_LEAVE_ANY,
        P_QUEUE_START_ANY, P_QUEUE_FINISH_ANY,
        P_QUEUE_MARK_AWAY, P_QUEUE_RETURN_SELLER,
        P_ATTENDANCES_VIEW_STORE, P_ATTENDANCES_DETAIL,
        P_SALES_VIEW_STORE, P_SALES_DETAIL,
        P_PRODUCTS_VIEW, P_LOSS_REASONS_VIEW,
        P_DASHBOARD_VIEW_STORE,
        P_REPORTS_VIEW_STORE,
        # Etapa 9
        P_GOALS_VIEW_STORE,
        P_RANKINGS_VIEW_STORE,
        P_GAMIFICATION_VIEW_STORE,
        P_PERFORMANCE_VIEW_STORE,
        # Etapa 10
        P_FEEDBACKS_VIEW_STORE, P_FEEDBACKS_CREATE,
        P_NOTIFICATIONS_VIEW_SELF, P_NOTIFICATIONS_MARK_READ,
        # Etapa 11
        P_PROACTIVITY_VIEW_STORE, P_PROACTIVITY_REPORTS_VIEW, P_PROACTIVITY_EXPORT,
        # Etapa 12
        P_NOTIF_VIEW_STORE, P_NOTIF_PREFERENCES_SELF, P_AUTOMATION_VIEW, P_AUTOMATION_LOGS,
        P_ALERTS_VIEW_STORE, P_ALERTS_ACK_ANY, P_EXT_NOTIF_VIEW, P_MOTIVATION_VIEW,
        # Etapa 14
        P_PRIVACY_REQUESTS_VIEW, P_PRIVACY_CONSENTS_VIEW, P_RETENTION_POLICIES_VIEW,
        P_BACKUP_VIEW, P_BACKUP_LOGS_VIEW,
    ],
    "STORE_MANAGER": [
        P_STORES_VIEW, P_TENANT_SETTINGS_VIEW,
        P_TEAMS_VIEW, P_TEAMS_CREATE, P_TEAMS_UPDATE, P_TEAMS_STATUS_CHANGE,
        P_SELLERS_VIEW, P_SELLERS_CREATE, P_SELLERS_UPDATE,
        P_SELLERS_STATUS_CHANGE, P_SELLERS_VIEW_STATUS_LOGS,
        P_QUEUE_VIEW, P_QUEUE_JOIN_ANY, P_QUEUE_LEAVE_ANY,
        P_QUEUE_START_ANY, P_QUEUE_FINISH_ANY,
        P_QUEUE_REORDER, P_QUEUE_MARK_AWAY, P_QUEUE_RETURN_SELLER,
        P_QUEUE_CANCEL_ATTENDANCE, P_QUEUE_CREATE_QUEUE, P_QUEUE_UPDATE_QUEUE,
        P_ATTENDANCES_VIEW_STORE, P_ATTENDANCES_FINISH_ANY,
        P_ATTENDANCES_CANCEL, P_ATTENDANCES_DETAIL,
        P_SALES_VIEW_STORE, P_SALES_CREATE_MANUAL, P_SALES_DETAIL,
        P_PRODUCTS_VIEW,
        P_LOSS_REASONS_VIEW, P_LOSS_REASONS_CREATE, P_LOSS_REASONS_UPDATE,
        P_DASHBOARD_VIEW_STORE,
        P_REPORTS_VIEW_STORE,
        # Etapa 9
        P_GOALS_VIEW_STORE, P_GOALS_CREATE, P_GOALS_UPDATE, P_GOALS_CANCEL, P_GOALS_RECALCULATE,
        P_RANKINGS_VIEW_STORE, P_RANKINGS_GENERATE,
        P_GAMIFICATION_VIEW_STORE, P_GAMIFICATION_EVALUATE,
        P_GAMIFICATION_CREATE, P_GAMIFICATION_UPDATE, P_GAMIFICATION_GRANT,
        P_GAMIFICATION_APPROVE, P_GAMIFICATION_VIEW_REPORTS,
        P_PERFORMANCE_VIEW_STORE,
        # Etapa 10
        P_FEEDBACKS_VIEW_STORE, P_FEEDBACKS_CREATE, P_FEEDBACKS_UPDATE,
        P_NOTIFICATIONS_VIEW_SELF, P_NOTIFICATIONS_MARK_READ,
        # Etapa 11
        P_PROACTIVITY_VIEW_STORE, P_PROACTIVITY_CREATE_ANY, P_PROACTIVITY_UPDATE_ANY,
        P_PROACTIVITY_CANCEL_ANY, P_PROACTIVITY_CONVERT_TO_ATTENDANCE_ANY,
        P_PROACTIVITY_CONVERT_TO_SALE_ANY, P_PROACTIVITY_CLOSE_NO_SALE_ANY,
        P_PROACTIVITY_REPORTS_VIEW, P_PROACTIVITY_EXPORT,
        # Etapa 12
        P_NOTIF_VIEW_STORE, P_NOTIF_PREFERENCES_SELF, P_NOTIF_TEMPLATES_VIEW,
        P_AUTOMATION_VIEW, P_AUTOMATION_CREATE, P_AUTOMATION_UPDATE,
        P_AUTOMATION_ENABLE_DISABLE, P_AUTOMATION_EXECUTE, P_AUTOMATION_LOGS,
        P_ALERTS_VIEW_STORE, P_ALERTS_ACK_ANY, P_ALERTS_RESOLVE,
        P_ALERTS_SETTINGS_VIEW, P_ALERTS_SETTINGS_UPDATE,
        P_EXT_NOTIF_VIEW, P_MOTIVATION_VIEW,
        # Etapa 14
        P_PRIVACY_REQUESTS_VIEW, P_PRIVACY_REQUESTS_CREATE,
        P_PRIVACY_CONSENTS_VIEW, P_PRIVACY_ACCESS_LOGS_VIEW,
        P_RETENTION_POLICIES_VIEW, P_BACKUP_VIEW,
    ],
    "SUPERVISOR": [
        P_STORES_VIEW, P_TEAMS_VIEW,
        P_SELLERS_VIEW, P_SELLERS_STATUS_CHANGE,
        P_QUEUE_VIEW, P_QUEUE_JOIN_ANY, P_QUEUE_LEAVE_ANY,
        P_QUEUE_MARK_AWAY, P_QUEUE_RETURN_SELLER,
        P_ATTENDANCES_VIEW_STORE, P_ATTENDANCES_DETAIL,
        P_SALES_VIEW_STORE,
        P_PRODUCTS_VIEW, P_LOSS_REASONS_VIEW,
        P_DASHBOARD_VIEW_STORE,
        P_REPORTS_VIEW_STORE,
        # Etapa 9
        P_GOALS_VIEW_STORE,
        P_RANKINGS_VIEW_STORE,
        P_GAMIFICATION_VIEW_STORE,
        P_PERFORMANCE_VIEW_STORE,
        # Etapa 10
        P_FEEDBACKS_VIEW_STORE,
        P_NOTIFICATIONS_VIEW_SELF, P_NOTIFICATIONS_MARK_READ,
        # Etapa 11
        P_PROACTIVITY_VIEW_STORE, P_PROACTIVITY_CREATE_ANY, P_PROACTIVITY_UPDATE_ANY,
        P_PROACTIVITY_CONVERT_TO_ATTENDANCE_ANY, P_PROACTIVITY_CLOSE_NO_SALE_ANY,
        P_PROACTIVITY_REPORTS_VIEW,
        # Etapa 12
        P_NOTIF_VIEW_STORE, P_NOTIF_PREFERENCES_SELF, P_AUTOMATION_VIEW, P_AUTOMATION_LOGS,
        P_ALERTS_VIEW_STORE, P_ALERTS_ACK_ANY, P_MOTIVATION_VIEW,
        # Etapa 14
        P_PRIVACY_REQUESTS_VIEW, P_PRIVACY_REQUESTS_CREATE,
    ],
    "SELLER": [
        P_STORES_VIEW, P_SELLERS_VIEW,
        P_QUEUE_VIEW, P_QUEUE_JOIN_SELF, P_QUEUE_LEAVE_SELF,
        P_QUEUE_START_SELF, P_QUEUE_FINISH_SELF,
        P_ATTENDANCES_VIEW_SELF, P_ATTENDANCES_FINISH_SELF, P_ATTENDANCES_DETAIL,
        P_SALES_VIEW_SELF, P_SALES_CREATE_SELF, P_SALES_DETAIL,
        P_PRODUCTS_VIEW, P_LOSS_REASONS_VIEW,
        P_DASHBOARD_VIEW_SELF,
        # P_REPORTS_VIEW_SELF removido: Relatórios restrito a Admin/Gerente (Prompt 7)
        # Etapa 9
        P_GOALS_VIEW_SELF,
        P_RANKINGS_VIEW_SELF,
        P_GAMIFICATION_VIEW_SELF,
        P_PERFORMANCE_VIEW_SELF,
        # Etapa 10
        P_FEEDBACKS_VIEW_SELF, P_FEEDBACKS_ACKNOWLEDGE,
        P_NOTIFICATIONS_VIEW_SELF, P_NOTIFICATIONS_MARK_READ,
        # Etapa 11
        P_PROACTIVITY_VIEW_SELF, P_PROACTIVITY_CREATE_SELF, P_PROACTIVITY_UPDATE_SELF,
        P_PROACTIVITY_CANCEL_SELF, P_PROACTIVITY_CONVERT_TO_ATTENDANCE_SELF,
        P_PROACTIVITY_CONVERT_TO_SALE_SELF, P_PROACTIVITY_CLOSE_NO_SALE_SELF,
        # Etapa 12
        P_NOTIF_PREFERENCES_SELF, P_ALERTS_VIEW_SELF, P_ALERTS_ACK_SELF, P_MOTIVATION_VIEW,
        # Etapa 14
        P_DATA_SUBJECT_EXPORT_SELF, P_PRIVACY_REQUESTS_CREATE,
    ],
}


def get_permissions_for_role(role: str) -> list[str]:
    """Retorna as permission keys para um role."""
    return list(ROLE_PERMISSIONS.get(role, []))
