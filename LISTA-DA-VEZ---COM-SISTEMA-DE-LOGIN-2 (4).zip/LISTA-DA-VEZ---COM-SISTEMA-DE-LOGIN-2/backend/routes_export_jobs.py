"""Rotas de Exportação Assíncrona — P1.

Endpoints:
  POST   /api/tenants/{slug}/reports/export/async          → cria job
  GET    /api/tenants/{slug}/reports/export/jobs           → lista jobs do usuário
  GET    /api/tenants/{slug}/reports/export/jobs/{job_id}  → status do job
  GET    /api/tenants/{slug}/reports/export/jobs/{job_id}/download → download CSV
"""
import os

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel
from typing import Optional

from db import db
from security import resolve_tenant_context
from feature_guard import require_feature
from permission_service import get_accessible_store_ids
from permissions import P_REPORTS_EXPORT
import export_job_service as svc

router = APIRouter(prefix="/tenants/{tenant_slug}/reports/export", tags=["export-async"])


def _has_export_perm(role: str) -> bool:
    from permissions import ROLE_PERMISSIONS
    return P_REPORTS_EXPORT in ROLE_PERMISSIONS.get(role, [])


def _safe_job(job: dict) -> dict:
    """Retorna campos públicos do job (sem file_path interno)."""
    return {
        "id": job["id"],
        "report_type": job["report_type"],
        "status": job["status"],
        "row_count": job.get("row_count"),
        "filename": job.get("filename"),
        "error": job.get("error"),
        "created_at": job.get("created_at"),
        "started_at": job.get("started_at"),
        "finished_at": job.get("finished_at"),
        "expires_at": job.get("expires_at"),
    }


class AsyncExportRequest(BaseModel):
    report_type: str
    date_start: Optional[str] = None
    date_end: Optional[str] = None
    store_id: Optional[str] = None
    seller_id: Optional[str] = None
    result: Optional[str] = None


@router.post("/async")
async def create_async_export(
    body: AsyncExportRequest,
    ctx: dict = Depends(resolve_tenant_context),
):
    """Cria job de exportação assíncrona. Retorna imediatamente com job_id."""
    await require_feature(ctx["tenant"]["id"], "exportacao")
    role = ctx["membership"]["role"]
    if not _has_export_perm(role):
        raise HTTPException(status_code=403, detail="Sem permissão para exportar relatórios.")
    if body.report_type not in svc.REPORT_TYPES:
        raise HTTPException(status_code=400, detail=f"Tipo inválido. Use: {', '.join(svc.REPORT_TYPES)}")

    tenant_id = ctx["tenant"]["id"]
    accessible_store_ids = await get_accessible_store_ids(ctx["membership"], tenant_id)

    if body.store_id and body.store_id not in accessible_store_ids:
        raise HTTPException(status_code=403, detail="Sem acesso a esta unidade.")

    effective_store_ids = [body.store_id] if body.store_id else accessible_store_ids

    # Captura seller_filter para SELLER role
    seller_filter_id = None
    if role == "SELLER":
        profile = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": ctx["user"]["id"]})
        seller_filter_id = profile["id"] if profile else "__none__"

    filters = {
        "accessible_store_ids": effective_store_ids,
        "date_start": body.date_start,
        "date_end": body.date_end,
        "seller_id": body.seller_id,
        "seller_filter_id": seller_filter_id,
        "result": body.result,
    }

    job = await svc.create_export_job(
        tenant_id=tenant_id,
        requested_by=ctx["user"]["id"],
        report_type=body.report_type,
        filters=filters,
    )
    return _safe_job(job)


@router.get("/jobs")
async def list_export_jobs(
    ctx: dict = Depends(resolve_tenant_context),
):
    """Lista os últimos 10 jobs de exportação do usuário autenticado."""
    await require_feature(ctx["tenant"]["id"], "exportacao")
    jobs = await svc.list_export_jobs(
        tenant_id=ctx["tenant"]["id"],
        requested_by=ctx["user"]["id"],
    )
    return [_safe_job(j) for j in jobs]


@router.get("/jobs/{job_id}")
async def get_export_job_status(
    job_id: str,
    ctx: dict = Depends(resolve_tenant_context),
):
    """Retorna o status atual do job."""
    job = await svc.get_export_job(job_id, ctx["tenant"]["id"])
    if not job:
        raise HTTPException(status_code=404, detail="Job não encontrado.")
    # Verifica que o job pertence ao usuário ou é admin
    role = ctx["membership"]["role"]
    if job["requested_by"] != ctx["user"]["id"] and role not in ("TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER"):
        raise HTTPException(status_code=403, detail="Sem acesso a este job.")
    return _safe_job(job)


@router.get("/jobs/{job_id}/download")
async def download_export_job(
    job_id: str,
    ctx: dict = Depends(resolve_tenant_context),
):
    """Download do CSV gerado. Só disponível quando status == DONE."""
    job = await svc.get_export_job(job_id, ctx["tenant"]["id"])
    if not job:
        raise HTTPException(status_code=404, detail="Job não encontrado.")
    role = ctx["membership"]["role"]
    if job["requested_by"] != ctx["user"]["id"] and role not in ("TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER"):
        raise HTTPException(status_code=403, detail="Sem acesso a este job.")
    if job["status"] != "DONE":
        raise HTTPException(status_code=409, detail=f"Job não está pronto. Status atual: {job['status']}")

    file_path = job.get("file_path")
    if not file_path or not os.path.exists(file_path):
        raise HTTPException(status_code=410, detail="Arquivo expirado ou não encontrado.")

    filename = job.get("filename") or "export.csv"
    return FileResponse(
        path=file_path,
        media_type="text/csv; charset=utf-8",
        filename=filename,
        headers={
            "Content-Disposition": f"attachment; filename={filename}",
            "Access-Control-Expose-Headers": "Content-Disposition",
        },
    )
