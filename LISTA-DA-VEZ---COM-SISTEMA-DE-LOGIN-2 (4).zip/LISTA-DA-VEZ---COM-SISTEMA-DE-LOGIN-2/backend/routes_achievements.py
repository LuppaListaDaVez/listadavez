"""routes_achievements.py — Conquistas configuráveis (MVP)."""
import logging
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request

from achievement_service import (
    evaluate_active_achievements,
    get_progress_for_seller,
    grant_achievement,
    _get_dedup_period,
    evaluate_operator,
    calculate_metric_for_seller,
    _get_achievement_period,
)
from audit import log_audit
from db import db
from models import (
    AchievementCreate,
    AchievementGrantPayload,
    AchievementRequestCreate,
    AchievementRequestReview,
    AchievementStatusUpdate,
    AchievementUpdate,
    ACHIEVEMENT_METRICS,
    ACHIEVEMENT_OPERATORS,
    new_id,
    utcnow_iso,
)
from security import require_roles, resolve_tenant_context

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/tenants/{tenant_slug}/achievements", tags=["achievements"])
awards_router = APIRouter(prefix="/tenants/{tenant_slug}/achievement-awards", tags=["achievement-awards"])
rankings_router = APIRouter(prefix="/tenants/{tenant_slug}/achievement-rankings", tags=["achievement-rankings"])
requests_router = APIRouter(prefix="/tenants/{tenant_slug}/achievement-requests", tags=["achievement-requests"])


# ── Helpers ────────────────────────────────────────────────────────────────────
def _clean(doc: dict) -> dict:
    doc.pop("_id", None)
    return doc


async def _resolve_seller_id(ctx: dict) -> Optional[str]:
    """Retorna o seller_profile_id do usuário logado (se for SELLER)."""
    if ctx["membership"]["role"] != "SELLER":
        return None
    sp = await db.seller_profiles.find_one(
        {"tenant_id": ctx["tenant"]["id"], "user_id": ctx["user"]["id"]}
    )
    return sp["id"] if sp else None


# ─────────────────────────────────────────────────────────────────────────────
# CRUD de conquistas
# ─────────────────────────────────────────────────────────────────────────────
@router.get("/metadata/metrics")
async def list_metrics(ctx: dict = Depends(resolve_tenant_context)):
    """Lista métricas e operadores disponíveis."""
    return {
        "metrics": [
            {"value": "REVENUE",          "label": "Receita total",       "unit": "centavos"},
            {"value": "SALES_COUNT",      "label": "Quantidade de vendas","unit": "unidade"},
            {"value": "ATTENDANCE_COUNT", "label": "Atendimentos",        "unit": "unidade"},
            {"value": "CONVERSION",       "label": "Conversão",           "unit": "%"},
            {"value": "AVERAGE_TICKET",   "label": "Ticket médio",        "unit": "centavos"},
            {"value": "ITEMS_SOLD",       "label": "Itens vendidos",      "unit": "unidade"},
        ],
        "operators": [
            {"value": "GTE", "label": "≥ (maior ou igual)"},
            {"value": "GT",  "label": "> (maior que)"},
            {"value": "EQ",  "label": "= (igual a)"},
            {"value": "LTE", "label": "≤ (menor ou igual)"},
            {"value": "LT",  "label": "< (menor que)"},
        ],
    }


@router.get("")
async def list_achievements(
    ctx: dict = Depends(resolve_tenant_context),
    status: Optional[str] = Query(None),
    category: Optional[str] = Query(None),
    scope: Optional[str] = Query(None),
):
    """Lista conquistas do tenant."""
    q: dict = {"tenant_id": ctx["tenant"]["id"]}
    if status:
        q["status"] = status
    if category:
        q["category"] = category
    if scope:
        q["scope"] = scope
    # SELLER vê apenas conquistas PUBLIC e ACTIVE
    if ctx["membership"]["role"] == "SELLER":
        q["status"] = "ACTIVE"
        q["visibility"] = "PUBLIC"

    achievements = await db.achievements.find(q).sort("created_at", -1).to_list(500)
    for a in achievements:
        a.pop("_id", None)
        rule = await db.achievement_rules.find_one(
            {"tenant_id": ctx["tenant"]["id"], "achievement_id": a["id"]}
        )
        a["rule"] = _clean(rule) if rule else None
        a["awarded_count"] = await db.achievement_awards.count_documents(
            {"tenant_id": ctx["tenant"]["id"], "achievement_id": a["id"]}
        )
    return achievements


@router.post("", status_code=201)
async def create_achievement(
    payload: AchievementCreate,
    request: Request,
    ctx: dict = Depends(require_roles("TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER")),
):
    tenant = ctx["tenant"]
    now = utcnow_iso()
    achievement = {
        "id": new_id(),
        "tenant_id": tenant["id"],
        "name": payload.name,
        "description": payload.description,
        "category": payload.category,
        "icon": payload.icon or "award",
        "points": payload.points,
        "difficulty": payload.difficulty or "MEDIUM",
        "visibility": payload.visibility,
        "scope": payload.scope,
        "period_type": payload.period_type,
        "period_start": payload.period_start,
        "period_end": payload.period_end,
        "recurrence": payload.recurrence,
        "approval_mode": payload.approval_mode,
        "reward": payload.reward,
        "status": "DRAFT",
        "created_by": ctx["user"]["id"],
        "created_at": now,
        "updated_at": now,
        "archived_at": None,
    }
    await db.achievements.insert_one(achievement)
    achievement.pop("_id", None)

    # Criar regra inline se fornecida
    rule = None
    if payload.rule_metric and payload.rule_operator and payload.rule_target_value is not None:
        rule = {
            "id": new_id(),
            "tenant_id": tenant["id"],
            "achievement_id": achievement["id"],
            "metric": payload.rule_metric,
            "operator": payload.rule_operator,
            "target_value": payload.rule_target_value,
            "period_type": payload.period_type,
            "conditions": {},
            "created_at": now,
            "updated_at": now,
        }
        await db.achievement_rules.insert_one(rule)
        rule.pop("_id", None)

    achievement["rule"] = rule
    achievement["awarded_count"] = 0

    await log_audit(
        action="ACHIEVEMENT_CREATED",
        entity="achievement",
        entity_id=achievement["id"],
        tenant_id=tenant["id"],
        user_id=ctx["user"]["id"],
        new_value={"name": achievement["name"]},
        request=request,
    )
    return achievement


@router.get("/{achievement_id}")
async def get_achievement(achievement_id: str, ctx: dict = Depends(resolve_tenant_context)):
    ach = await db.achievements.find_one(
        {"tenant_id": ctx["tenant"]["id"], "id": achievement_id}
    )
    if not ach:
        raise HTTPException(status_code=404, detail="Conquista não encontrada.")
    ach.pop("_id", None)
    rule = await db.achievement_rules.find_one(
        {"tenant_id": ctx["tenant"]["id"], "achievement_id": achievement_id}
    )
    ach["rule"] = _clean(rule) if rule else None
    ach["awarded_count"] = await db.achievement_awards.count_documents(
        {"tenant_id": ctx["tenant"]["id"], "achievement_id": achievement_id}
    )
    return ach


@router.put("/{achievement_id}")
async def update_achievement(
    achievement_id: str,
    payload: AchievementUpdate,
    request: Request,
    ctx: dict = Depends(require_roles("TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER")),
):
    ach = await db.achievements.find_one(
        {"tenant_id": ctx["tenant"]["id"], "id": achievement_id}
    )
    if not ach:
        raise HTTPException(status_code=404, detail="Conquista não encontrada.")
    if ach.get("status") == "ARCHIVED":
        raise HTTPException(status_code=400, detail="Conquista arquivada não pode ser editada.")

    now = utcnow_iso()
    updates = {k: v for k, v in payload.model_dump(exclude_none=True).items()
               if k not in {"rule_metric", "rule_operator", "rule_target_value"}}
    if updates:
        updates["updated_at"] = now
        await db.achievements.update_one({"id": achievement_id}, {"$set": updates})

    # Atualizar ou criar regra
    if any([payload.rule_metric, payload.rule_operator, payload.rule_target_value is not None]):
        existing_rule = await db.achievement_rules.find_one(
            {"tenant_id": ctx["tenant"]["id"], "achievement_id": achievement_id}
        )
        rule_updates: dict = {"updated_at": now}
        if payload.rule_metric:
            rule_updates["metric"] = payload.rule_metric
        if payload.rule_operator:
            rule_updates["operator"] = payload.rule_operator
        if payload.rule_target_value is not None:
            rule_updates["target_value"] = payload.rule_target_value
        if existing_rule:
            await db.achievement_rules.update_one(
                {"id": existing_rule["id"]}, {"$set": rule_updates}
            )
        else:
            new_rule = {
                "id": new_id(), "tenant_id": ctx["tenant"]["id"],
                "achievement_id": achievement_id,
                "metric": payload.rule_metric or "SALES_COUNT",
                "operator": payload.rule_operator or "GTE",
                "target_value": payload.rule_target_value or 1,
                "period_type": ach.get("period_type"),
                "conditions": {}, "created_at": now, "updated_at": now,
            }
            await db.achievement_rules.insert_one(new_rule)

    await log_audit(action="ACHIEVEMENT_UPDATED", entity="achievement", entity_id=achievement_id,
        tenant_id=ctx["tenant"]["id"], user_id=ctx["user"]["id"],
        new_value=updates, request=request)
    return await get_achievement(achievement_id, ctx)


@router.patch("/{achievement_id}/status")
async def update_achievement_status(
    achievement_id: str,
    payload: AchievementStatusUpdate,
    request: Request,
    ctx: dict = Depends(require_roles("TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER")),
):
    ach = await db.achievements.find_one(
        {"tenant_id": ctx["tenant"]["id"], "id": achievement_id}
    )
    if not ach:
        raise HTTPException(status_code=404, detail="Conquista não encontrada.")
    now = utcnow_iso()
    extra = {"archived_at": now} if payload.status == "ARCHIVED" else {}
    await db.achievements.update_one(
        {"id": achievement_id},
        {"$set": {"status": payload.status, "updated_at": now, **extra}},
    )
    await log_audit(action="ACHIEVEMENT_STATUS_CHANGED", entity="achievement", entity_id=achievement_id,
        tenant_id=ctx["tenant"]["id"], user_id=ctx["user"]["id"],
        old_value={"status": ach["status"]}, new_value={"status": payload.status}, request=request)
    return {"id": achievement_id, "status": payload.status}


# ─────────────────────────────────────────────────────────────────────────────
# Progresso e concessão
# ─────────────────────────────────────────────────────────────────────────────
@router.get("/{achievement_id}/progress")
async def get_achievement_progress(
    achievement_id: str,
    ctx: dict = Depends(resolve_tenant_context),
    seller_id: Optional[str] = Query(None),
):
    """Retorna o progresso de um vendedor para uma conquista."""
    tenant = ctx["tenant"]
    ach = await db.achievements.find_one({"tenant_id": tenant["id"], "id": achievement_id})
    if not ach:
        raise HTTPException(status_code=404)
    ach.pop("_id", None)

    if ctx["membership"]["role"] == "SELLER":
        sp = await db.seller_profiles.find_one(
            {"tenant_id": tenant["id"], "user_id": ctx["user"]["id"]}
        )
        if not sp:
            raise HTTPException(status_code=404, detail="Perfil de vendedor não encontrado.")
        sid = sp["id"]
        store_id = sp["store_id"]
    else:
        if not seller_id:
            raise HTTPException(status_code=422, detail="seller_id obrigatório para gestores.")
        sp = await db.seller_profiles.find_one({"tenant_id": tenant["id"], "id": seller_id})
        if not sp:
            raise HTTPException(status_code=404)
        sid = sp["id"]
        store_id = sp["store_id"]

    return await get_progress_for_seller(tenant["id"], sid, store_id, ach)


@router.post("/{achievement_id}/grant", status_code=201)
async def grant_achievement_manual(
    achievement_id: str,
    payload: AchievementGrantPayload,
    request: Request,
    ctx: dict = Depends(require_roles("TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER", "SUPERVISOR")),
):
    """Concede uma conquista manualmente a um vendedor."""
    tenant = ctx["tenant"]
    ach = await db.achievements.find_one({"tenant_id": tenant["id"], "id": achievement_id})
    if not ach:
        raise HTTPException(status_code=404, detail="Conquista não encontrada.")

    sp = await db.seller_profiles.find_one({"tenant_id": tenant["id"], "id": payload.seller_id})
    if not sp:
        raise HTTPException(status_code=404, detail="Vendedor não encontrado.")

    ach.pop("_id", None)
    ps_dedup, pe_dedup = _get_dedup_period(ach)

    award = await grant_achievement(
        tenant_id=tenant["id"],
        achievement_id=achievement_id,
        seller_id=payload.seller_id,
        store_id=sp["store_id"],
        team_id=sp.get("team_id"),
        award_type="MANUAL",
        awarded_by=ctx["user"]["id"],
        period_start_dedup=ps_dedup,
        period_end_dedup=pe_dedup,
        reason=payload.reason,
    )

    if not award:
        raise HTTPException(status_code=409, detail="Conquista já concedida neste período.")

    await log_audit(action="ACHIEVEMENT_GRANTED_MANUAL", entity="achievement_award",
        entity_id=award["id"], tenant_id=tenant["id"], user_id=ctx["user"]["id"],
        new_value={"seller_id": payload.seller_id, "achievement": ach["name"]}, request=request)

    points_override = payload.override_points
    if points_override:
        await db.achievement_awards.update_one(
            {"id": award["id"]}, {"$set": {"points_awarded": points_override}}
        )
    return award


@router.post("/{achievement_id}/evaluate", status_code=200)
async def evaluate_achievement(
    achievement_id: str,
    request: Request,
    ctx: dict = Depends(require_roles("TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER")),
    seller_id: Optional[str] = Query(None),
):
    """Dispara avaliação manual da conquista para um ou todos os vendedores."""
    tenant = ctx["tenant"]
    ach = await db.achievements.find_one({"tenant_id": tenant["id"], "id": achievement_id})
    if not ach:
        raise HTTPException(status_code=404)
    ach.pop("_id", None)

    rule = await db.achievement_rules.find_one(
        {"tenant_id": tenant["id"], "achievement_id": achievement_id}
    )
    if not rule:
        raise HTTPException(status_code=422, detail="Conquista sem regra configurada.")

    q: dict = {"tenant_id": tenant["id"], "status": "ACTIVE"}
    if seller_id:
        q["id"] = seller_id
    sellers = await db.seller_profiles.find(q).to_list(500)

    awarded = []
    ps, pe = _get_achievement_period(ach)
    ps_dedup, pe_dedup = _get_dedup_period(ach)
    for sp in sellers:
        current = await calculate_metric_for_seller(
            tenant["id"], sp["id"], sp["store_id"], rule["metric"], ps, pe
        )
        if not evaluate_operator(current, rule["operator"], rule["target_value"]):
            continue
        award = await grant_achievement(
            tenant_id=tenant["id"],
            achievement_id=achievement_id,
            seller_id=sp["id"],
            store_id=sp["store_id"],
            team_id=sp.get("team_id"),
            award_type="AUTOMATIC",
            awarded_by=ctx["user"]["id"],
            period_start_dedup=ps_dedup,
            period_end_dedup=pe_dedup,
            metadata={"metric": rule["metric"], "current_value": current},
        )
        if award:
            awarded.append(award)

    return {"evaluated": len(sellers), "awarded": len(awarded), "awards": awarded}


# ─────────────────────────────────────────────────────────────────────────────
# Awards
# ─────────────────────────────────────────────────────────────────────────────
@awards_router.get("")
async def list_awards(
    ctx: dict = Depends(require_roles("TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER")),
    seller_id: Optional[str] = Query(None),
    achievement_id: Optional[str] = Query(None),
    limit: int = Query(default=50, le=200),
):
    """Lista todos os awards do tenant (gestores)."""
    q: dict = {"tenant_id": ctx["tenant"]["id"]}
    if seller_id:
        q["seller_id"] = seller_id
    if achievement_id:
        q["achievement_id"] = achievement_id
    awards = await db.achievement_awards.find(q).sort("earned_at", -1).to_list(limit)
    for a in awards:
        a.pop("_id", None)
    return awards


@awards_router.get("/my")
async def list_my_awards(ctx: dict = Depends(resolve_tenant_context)):
    """Lista as conquistas do vendedor logado."""
    tenant = ctx["tenant"]
    sp = await db.seller_profiles.find_one(
        {"tenant_id": tenant["id"], "user_id": ctx["user"]["id"]}
    )
    if not sp:
        return []
    awards = await db.achievement_awards.find(
        {"tenant_id": tenant["id"], "seller_id": sp["id"]}
    ).sort("earned_at", -1).to_list(100)
    for a in awards:
        a.pop("_id", None)
    return awards


@awards_router.get("/my-progress")
async def my_progress(ctx: dict = Depends(resolve_tenant_context)):
    """Retorna conquistas ativas + progresso do vendedor logado."""
    tenant = ctx["tenant"]
    sp = await db.seller_profiles.find_one(
        {"tenant_id": tenant["id"], "user_id": ctx["user"]["id"]}
    )
    if not sp:
        return []
    achievements = await db.achievements.find(
        {"tenant_id": tenant["id"], "status": "ACTIVE"}
    ).to_list(100)
    result = []
    for ach in achievements:
        ach.pop("_id", None)
        progress = await get_progress_for_seller(tenant["id"], sp["id"], sp["store_id"], ach)
        result.append(progress)
    return result


# ─────────────────────────────────────────────────────────────────────────────
# Ranking
# ─────────────────────────────────────────────────────────────────────────────
@rankings_router.get("")
async def achievement_rankings(
    ctx: dict = Depends(resolve_tenant_context),
    period: str = Query(default="month"),
    store_id: Optional[str] = Query(None),
    limit: int = Query(default=20, le=100),
):
    """Ranking de vendedores por pontos de conquistas."""
    from datetime import datetime, timezone, timedelta
    tenant_id = ctx["tenant"]["id"]
    now = datetime.now(timezone.utc)

    if period == "week":
        start_iso = (now - timedelta(days=now.weekday())).replace(
            hour=0, minute=0, second=0, microsecond=0
        ).isoformat()
    elif period == "month":
        start_iso = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0).isoformat()
    else:
        start_iso = None

    q: dict = {"tenant_id": tenant_id}
    if start_iso:
        q["earned_at"] = {"$gte": start_iso}
    if store_id:
        q["store_id"] = store_id

    pipeline = [
        {"$match": q},
        {"$group": {
            "_id": "$seller_id",
            "points": {"$sum": "$points_awarded"},
            "count": {"$sum": 1},
        }},
        {"$sort": {"points": -1}},
        {"$limit": limit},
    ]

    rows = []
    async for doc in db.achievement_awards.aggregate(pipeline):
        sp = await db.seller_profiles.find_one({"id": doc["_id"]})
        if not sp:
            continue
        user = await db.users.find_one({"id": sp["user_id"]})
        rows.append({
            "rank": len(rows) + 1,
            "seller_id": doc["_id"],
            "name": user["name"] if user else "–",
            "avatar_url": user.get("avatar_url") if user else None,
            "points": doc["points"],
            "achievements_count": doc["count"],
            "store_id": sp.get("store_id"),
            "team_id": sp.get("team_id"),
        })

    return rows


# ─────────────────────────────────────────────────────────────────────────────
# Requests (solicitações de aprovação)
# ─────────────────────────────────────────────────────────────────────────────
@requests_router.get("")
async def list_requests(
    ctx: dict = Depends(require_roles("TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER")),
    status: Optional[str] = Query(None, description="PENDING | APPROVED | REJECTED"),
):
    q: dict = {"tenant_id": ctx["tenant"]["id"]}
    if status:
        q["status"] = status
    else:
        q["status"] = "PENDING"
    reqs = await db.achievement_requests.find(q).sort("requested_at", -1).to_list(200)
    for r in reqs:
        r.pop("_id", None)
    return reqs


@requests_router.post("", status_code=201)
async def create_request(
    payload: AchievementRequestCreate,
    request: Request,
    ctx: dict = Depends(resolve_tenant_context),
):
    """Vendedor solicita uma conquista que requer aprovação."""
    tenant = ctx["tenant"]
    ach = await db.achievements.find_one({"tenant_id": tenant["id"], "id": payload.achievement_id})
    if not ach:
        raise HTTPException(status_code=404)
    if ach.get("approval_mode") not in {"MANUAL", "REQUIRES_APPROVAL"}:
        raise HTTPException(status_code=400, detail="Esta conquista não requer aprovação.")

    sp = await db.seller_profiles.find_one(
        {"tenant_id": tenant["id"], "user_id": ctx["user"]["id"]}
    )
    seller_id = sp["id"] if sp else None
    store_id = sp["store_id"] if sp else None

    now = utcnow_iso()
    req = {
        "id": new_id(),
        "tenant_id": tenant["id"],
        "achievement_id": payload.achievement_id,
        "seller_id": seller_id,
        "store_id": store_id,
        "status": "PENDING",
        "requested_by": ctx["user"]["id"],
        "reviewed_by": None,
        "requested_at": now,
        "reviewed_at": None,
        "reason": payload.reason,
        "review_note": None,
        "created_at": now,
    }
    await db.achievement_requests.insert_one(req)
    req.pop("_id", None)
    return req


@requests_router.post("/{request_id}/approve", status_code=200)
async def approve_request(
    request_id: str,
    payload: AchievementRequestReview,
    request: Request,
    ctx: dict = Depends(require_roles("TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER")),
):
    tenant = ctx["tenant"]
    req = await db.achievement_requests.find_one({"tenant_id": tenant["id"], "id": request_id})
    if not req:
        raise HTTPException(status_code=404)
    if req["status"] != "PENDING":
        raise HTTPException(status_code=400, detail="Solicitação não está pendente.")

    now = utcnow_iso()
    await db.achievement_requests.update_one(
        {"id": request_id},
        {"$set": {
            "status": "APPROVED", "reviewed_by": ctx["user"]["id"],
            "reviewed_at": now, "review_note": payload.review_note,
        }},
    )

    sp = await db.seller_profiles.find_one({"tenant_id": tenant["id"], "id": req["seller_id"]})
    if sp:
        ach = await db.achievements.find_one({"tenant_id": tenant["id"], "id": req["achievement_id"]})
        if ach:
            ach.pop("_id", None)
            ps_d, pe_d = _get_dedup_period(ach)
            await grant_achievement(
                tenant_id=tenant["id"],
                achievement_id=req["achievement_id"],
                seller_id=req["seller_id"],
                store_id=sp["store_id"],
                team_id=sp.get("team_id"),
                award_type="APPROVAL",
                awarded_by=ctx["user"]["id"],
                period_start_dedup=ps_d,
                period_end_dedup=pe_d,
                reason=payload.review_note,
            )

    return {"id": request_id, "status": "APPROVED"}


@requests_router.post("/{request_id}/reject", status_code=200)
async def reject_request(
    request_id: str,
    payload: AchievementRequestReview,
    request: Request,
    ctx: dict = Depends(require_roles("TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER")),
):
    tenant = ctx["tenant"]
    req = await db.achievement_requests.find_one({"tenant_id": tenant["id"], "id": request_id})
    if not req:
        raise HTTPException(status_code=404)
    if req["status"] != "PENDING":
        raise HTTPException(status_code=400, detail="Solicitação não está pendente.")
    now = utcnow_iso()
    await db.achievement_requests.update_one(
        {"id": request_id},
        {"$set": {
            "status": "REJECTED", "reviewed_by": ctx["user"]["id"],
            "reviewed_at": now, "review_note": payload.review_note,
        }},
    )
    return {"id": request_id, "status": "REJECTED"}
