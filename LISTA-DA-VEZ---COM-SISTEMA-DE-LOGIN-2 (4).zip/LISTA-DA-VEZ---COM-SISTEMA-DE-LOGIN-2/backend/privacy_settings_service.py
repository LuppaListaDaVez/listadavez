"""PrivacySettingsService — Configurações de privacidade do tenant (Etapa 14)."""
from typing import Optional
from db import db
from models import new_id, utcnow_iso
from audit import log_audit


DEFAULT_SETTINGS = {
    "privacy_contact_name": None,
    "privacy_contact_email": None,
    "dpo_name": None,
    "dpo_email": None,
    "default_retention_profile": "STANDARD",
    "mask_customer_phone_by_default": True,
    "mask_customer_email_by_default": True,
    "allow_public_sales_amounts": False,
    "allow_motivation_financial_values": False,
    "privacy_policy_url": None,
    "terms_url": None,
}


async def get_settings(tenant_id: str) -> dict:
    doc = await db.privacy_settings.find_one({"tenant_id": tenant_id})
    if not doc:
        return {"id": None, "tenant_id": tenant_id, **DEFAULT_SETTINGS}
    doc.pop("_id", None)
    return doc


async def upsert_settings(tenant_id: str, data: dict, user_id: str, request=None) -> dict:
    allowed = list(DEFAULT_SETTINGS.keys())
    now = utcnow_iso()
    updates = {k: data[k] for k in allowed if k in data}
    updates["updated_at"] = now
    
    existing = await db.privacy_settings.find_one({"tenant_id": tenant_id})
    if existing:
        old = {k: existing.get(k) for k in updates}
        await db.privacy_settings.update_one({"tenant_id": tenant_id}, {"$set": updates})
    else:
        doc = {"id": new_id(), "tenant_id": tenant_id, **DEFAULT_SETTINGS, **updates, "created_at": now}
        await db.privacy_settings.insert_one(doc)
        old = {}
    
    await log_audit(action="PRIVACY_SETTINGS_UPDATED", entity="privacy_settings",
                    tenant_id=tenant_id, user_id=user_id,
                    old_value=old, new_value=updates, request=request)
    return await get_settings(tenant_id)


async def seed_default(tenant_id: str, created_by: str = "system"):
    existing = await db.privacy_settings.find_one({"tenant_id": tenant_id})
    if not existing:
        now = utcnow_iso()
        await db.privacy_settings.insert_one({
            "id": new_id(), "tenant_id": tenant_id, **DEFAULT_SETTINGS,
            "privacy_contact_name": "Responsável de Privacidade",
            "privacy_contact_email": "privacidade@demo.com",
            "dpo_name": "DPO Demo",
            "dpo_email": "dpo@demo.com",
            "created_at": now, "updated_at": now,
        })
