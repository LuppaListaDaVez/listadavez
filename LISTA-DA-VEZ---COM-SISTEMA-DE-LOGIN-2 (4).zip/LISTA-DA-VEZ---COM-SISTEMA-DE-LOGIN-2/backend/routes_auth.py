"""Autenticação global (Super Admin) + refresh/logout — Etapa 13."""
from datetime import datetime, timezone, timedelta

from fastapi import APIRouter, Depends, HTTPException, Request

from db import db
from models import LoginRequest, RefreshRequest, new_id, utcnow_iso
from security import (
    REFRESH_TOKEN_EXPIRES_DAYS,
    create_super_admin_access_token,
    create_access_token,
    create_refresh_token_raw,
    create_tenant_access_token,
    decode_token,
    get_current_user,
    hash_token,
    verify_password,
)
from session_service import (
    create_session,
    get_session,
    is_session_valid,
    revoke_session,
    revoke_all_user_sessions,
)
from security_event_service import log_security_event, SecurityEventType
from rate_limit_service import (
    check_rate_limit, get_client_ip,
    check_email_lockout, record_failed_login, reset_email_lockout,
)
from audit import log_audit

router = APIRouter(prefix="/auth", tags=["auth"])

_GENERIC_ERROR = "Credenciais inválidas."


async def _build_memberships(user_id: str):
    cursor = db.tenant_memberships.find({"user_id": user_id, "status": "ACTIVE"})
    result = []
    async for m in cursor:
        tenant = await db.tenants.find_one({"id": m["tenant_id"]})
        if not tenant:
            continue
        result.append(
            {
                "tenant_id": tenant["id"],
                "tenant_slug": tenant["slug"],
                "tenant_name": tenant["name"],
                "role": m["role"],
                "store_ids": m.get("store_ids", []),
            }
        )
    return result


async def _issue_tokens_with_session(
    *,
    user: dict,
    auth_context: str,
    session_id: str,
    tenant_id: str = None,
    tenant_slug: str = None,
    membership_id: str = None,
    role: str = None,
    family_id: str = None,
    ip: str = None,
    user_agent: str = None,
) -> tuple:
    """Emite access_token + refresh_token vinculados à sessão."""
    if auth_context == "SUPER_ADMIN":
        access_token = create_super_admin_access_token(
            user_id=user["id"], email=user["email"], session_id=session_id
        )
    else:
        access_token = create_tenant_access_token(
            user_id=user["id"],
            email=user["email"],
            tenant_id=tenant_id,
            tenant_slug=tenant_slug,
            membership_id=membership_id,
            role=role,
            session_id=session_id,
        )

    refresh_raw = create_refresh_token_raw()
    refresh_hash = hash_token(refresh_raw)
    new_family_id = family_id or new_id()
    expires_at = (
        datetime.now(timezone.utc) + timedelta(days=REFRESH_TOKEN_EXPIRES_DAYS)
    ).isoformat()

    await db.refresh_tokens.insert_one(
        {
            "id": new_id(),
            "session_id": session_id,
            "user_id": user["id"],
            "tenant_id": tenant_id,
            "token_hash": refresh_hash,
            "family_id": new_family_id,
            "created_at": utcnow_iso(),
            "expires_at": expires_at,
            "rotated_at": None,
            "revoked_at": None,
            "reuse_detected_at": None,
            "ip": ip,
            "user_agent": user_agent,
        }
    )
    return access_token, refresh_raw


# ─── Login Global (Super Admin) ─────────────────────────────────────────────
@router.post("/login")
async def login(payload: LoginRequest, request: Request):
    ip = get_client_ip(request)
    user_agent = request.headers.get("user-agent")
    email = payload.email.lower().strip()

    # Rate limit por IP (Super Admin login é mais restrito)
    rl_allowed, rl_retry = await check_rate_limit(ip or "unknown", "SUPER_ADMIN_LOGIN")
    if not rl_allowed:
        await log_security_event(
            event_type=SecurityEventType.RATE_LIMIT_EXCEEDED,
            ip=ip, metadata={"group": "SUPER_ADMIN_LOGIN"}, request=request,
        )
        raise HTTPException(
            status_code=429,
            headers={"Retry-After": str(rl_retry or 60)},
            detail={
                "error": "RATE_LIMIT_EXCEEDED",
                "message": "Muitas tentativas. Tente novamente em alguns instantes.",
                "retry_after_seconds": rl_retry or 60,
            },
        )

    # Lockout por conta: verificar se e-mail já atingiu o limite de falhas
    lockout_ok, _lockout_retry = await check_email_lockout(email, "super_admin")
    if not lockout_ok:
        await log_security_event(
            event_type=SecurityEventType.SUPER_ADMIN_LOGIN_FAILED,
            ip=ip, user_agent=user_agent,
            metadata={"reason": "account_lockout"},
            request=request,
        )
        raise HTTPException(status_code=401, detail={"error": "INVALID_CREDENTIALS", "message": _GENERIC_ERROR})

    user = await db.users.find_one({"email": email})

    # Verificar se é super admin (não revelar existência de conta)
    if not user or user.get("status") != "ACTIVE":
        await record_failed_login(email, "super_admin")
        await log_security_event(
            event_type=SecurityEventType.SUPER_ADMIN_LOGIN_FAILED,
            ip=ip, user_agent=user_agent,
            metadata={"reason": "user_not_found"},
            request=request,
        )
        raise HTTPException(status_code=401, detail={"error": "INVALID_CREDENTIALS", "message": _GENERIC_ERROR})

    if not user.get("is_super_admin"):
        # Usuários não-super-admin devem usar o login da empresa
        # Não incrementa lockout: não é tentativa de força bruta, é redirecionamento de UX
        await log_security_event(
            event_type=SecurityEventType.LOGIN_FAILED,
            user_id=user["id"], ip=ip,
            metadata={"reason": "not_super_admin_via_global_login"},
            request=request,
        )
        raise HTTPException(
            status_code=403,
            detail={
                "error": "USE_TENANT_LOGIN",
                "message": "Use o login da sua empresa para entrar. Ex: /empresa/login",
            },
        )

    if not verify_password(payload.password, user["password_hash"]):
        await record_failed_login(email, "super_admin")
        await log_security_event(
            event_type=SecurityEventType.SUPER_ADMIN_LOGIN_FAILED,
            user_id=user["id"], ip=ip, user_agent=user_agent,
            metadata={"reason": "wrong_password"},
            request=request,
        )
        raise HTTPException(status_code=401, detail={"error": "INVALID_CREDENTIALS", "message": _GENERIC_ERROR})

    # Criar sessão SUPER_ADMIN
    # Login bem-sucedido: resetar contador de tentativas falhadas
    await reset_email_lockout(email, "super_admin")

    session = await create_session(
        user_id=user["id"],
        auth_context="SUPER_ADMIN",
        ip=ip,
        user_agent=user_agent,
    )

    access_token, refresh_token = await _issue_tokens_with_session(
        user=user,
        auth_context="SUPER_ADMIN",
        session_id=session["id"],
        ip=ip,
        user_agent=user_agent,
    )

    await db.users.update_one(
        {"id": user["id"]},
        {"$set": {"last_login_at": utcnow_iso(), "updated_at": utcnow_iso()}},
    )

    await log_security_event(
        event_type=SecurityEventType.SUPER_ADMIN_LOGIN_SUCCESS,
        user_id=user["id"], session_id=session["id"],
        ip=ip, user_agent=user_agent, request=request,
    )
    await log_audit(action="LOGIN", entity="user", entity_id=user["id"], user_id=user["id"], request=request)

    memberships = await _build_memberships(user["id"])

    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer",
        "auth_context": "SUPER_ADMIN",
        "session_id": session["id"],
        "user": {
            "id": user["id"],
            "name": user["name"],
            "email": user["email"],
            "is_super_admin": user.get("is_super_admin", False),
        },
        "memberships": memberships,
    }


# ─── Logout Global ─────────────────────────────────────────────────────────
@router.post("/logout")
async def logout(
    payload: RefreshRequest | None = None,
    request: Request = None,
    user: dict = Depends(get_current_user),
):
    token_payload = getattr(request.state, "token_payload", {}) if request else {}
    session_id = token_payload.get("session_id")

    if session_id:
        await revoke_session(session_id, "LOGOUT")

    if payload and payload.refresh_token:
        token_hash = hash_token(payload.refresh_token)
        await db.refresh_tokens.update_one(
            {"token_hash": token_hash},
            {"$set": {"revoked_at": utcnow_iso()}},
        )

    await log_security_event(
        event_type=SecurityEventType.LOGOUT,
        user_id=user["id"], session_id=session_id, request=request,
    )
    await log_audit(action="LOGOUT", entity="user", entity_id=user["id"], user_id=user["id"], request=request)
    return {"message": "Logout efetuado."}


# ─── Logout All ─────────────────────────────────────────────────────────────
@router.post("/logout-all")
async def logout_all(
    request: Request = None,
    user: dict = Depends(get_current_user),
):
    token_payload = getattr(request.state, "token_payload", {}) if request else {}
    tenant_id = token_payload.get("tenant_id")

    await revoke_all_user_sessions(user["id"], tenant_id=tenant_id, reason="LOGOUT_ALL")
    await db.refresh_tokens.update_many(
        {"user_id": user["id"], "revoked_at": None, **({"tenant_id": tenant_id} if tenant_id else {})},
        {"$set": {"revoked_at": utcnow_iso()}},
    )

    await log_security_event(
        event_type=SecurityEventType.LOGOUT_ALL,
        user_id=user["id"], tenant_id=tenant_id, request=request,
    )
    return {"message": "Todas as sessões foram encerradas."}


# ─── Refresh Token ──────────────────────────────────────────────────────────
@router.post("/refresh")
async def refresh(payload: RefreshRequest, request: Request = None):
    ip = get_client_ip(request) if request else "unknown"

    # Rate limit
    rl_key = ip or "unknown"
    rl_allowed, rl_retry = await check_rate_limit(rl_key, "AUTH_REFRESH")
    if not rl_allowed:
        raise HTTPException(
            status_code=429,
            headers={"Retry-After": str(rl_retry or 60)},
            detail={
                "error": "RATE_LIMIT_EXCEEDED",
                "message": "Muitas tentativas. Tente novamente.",
                "retry_after_seconds": rl_retry or 60,
            },
        )

    token_hash = hash_token(payload.refresh_token)
    stored = await db.refresh_tokens.find_one({"token_hash": token_hash})

    if not stored:
        # Pode ser reuse de token antigo (rotated ou revogado)
        revoked_or_rotated = await db.refresh_tokens.find_one(
            {"token_hash": token_hash, "$or": [{"rotated_at": {"$ne": None}}, {"revoked_at": {"$ne": None}}]}
        )
        if revoked_or_rotated and revoked_or_rotated.get("family_id"):
            # REUSE DETECTED: revogar família inteira
            await _handle_refresh_reuse(revoked_or_rotated, request)
        raise HTTPException(status_code=401, detail="Refresh token inválido")

    # Verificar se já foi rotacionado (REUSE)
    if stored.get("rotated_at") is not None:
        await _handle_refresh_reuse(stored, request)
        raise HTTPException(status_code=401, detail="Refresh token inválido")

    if stored.get("revoked_at") is not None:
        raise HTTPException(status_code=401, detail="Refresh token revogado")

    # Verificar expiração
    try:
        exp = datetime.fromisoformat(stored["expires_at"])
        if exp.tzinfo is None:
            exp = exp.replace(tzinfo=timezone.utc)
        if exp < datetime.now(timezone.utc):
            raise HTTPException(status_code=401, detail="Refresh token expirado")
    except (KeyError, ValueError):
        raise HTTPException(status_code=401, detail="Refresh token inválido")

    # Verificar sessão
    session_id = stored.get("session_id")
    session = await get_session(session_id) if session_id else None
    if session and session.get("revoked_at"):
        raise HTTPException(status_code=401, detail="Sessão revogada")

    user = await db.users.find_one({"id": stored["user_id"]})
    if not user or user.get("status") != "ACTIVE":
        raise HTTPException(status_code=401, detail="Usuário inválido")

    auth_context = (session or {}).get("auth_context", "SUPER_ADMIN" if user.get("is_super_admin") else "LEGACY")
    tenant_id = stored.get("tenant_id") or (session or {}).get("tenant_id")
    tenant_slug = (session or {}).get("tenant_slug")
    membership_id = (session or {}).get("membership_id")
    role = (session or {}).get("role")

    # Validações tenant-scoped (se aplicável)
    if auth_context == "TENANT" and tenant_id:
        tenant = await db.tenants.find_one({"id": tenant_id})
        if not tenant or tenant.get("status") not in ("ACTIVE", "TRIAL"):
            raise HTTPException(status_code=401, detail="Empresa inativa")
        tenant_slug = tenant_slug or tenant.get("slug")
        membership = await db.tenant_memberships.find_one(
            {"tenant_id": tenant_id, "user_id": user["id"], "status": "ACTIVE"}
        )
        if not membership:
            raise HTTPException(status_code=401, detail="Sem acesso à empresa")
        membership.pop("_id", None)
        membership_id = membership.get("id", membership_id)
        role = membership["role"]

    # Rotacionar refresh token (marcar como usado)
    await db.refresh_tokens.update_one(
        {"id": stored["id"]},
        {"$set": {"rotated_at": utcnow_iso()}},
    )

    # Emitir novo token com mesma sessão (ou criar nova se não há sessão)
    actual_session_id = session_id or new_id()
    new_access_token, new_refresh = await _issue_tokens_with_session(
        user=user,
        auth_context=auth_context,
        session_id=actual_session_id,
        tenant_id=tenant_id,
        tenant_slug=tenant_slug,
        membership_id=membership_id,
        role=role,
        family_id=stored.get("family_id"),
        ip=ip,
    )

    # Atualizar last_seen da sessão
    if session:
        from session_service import update_session_last_seen
        await update_session_last_seen(actual_session_id)

    await log_security_event(
        event_type=SecurityEventType.TOKEN_REFRESHED,
        user_id=user["id"],
        session_id=actual_session_id,
        tenant_id=tenant_id,
        tenant_slug=tenant_slug,
        request=request,
    )

    return {
        "access_token": new_access_token,
        "refresh_token": new_refresh,
        "token_type": "bearer",
    }


async def _handle_refresh_reuse(stored_token: dict, request):
    """Detecta reuse de refresh token: revoga toda a família."""
    family_id = stored_token.get("family_id")
    if family_id:
        await db.refresh_tokens.update_many(
            {"family_id": family_id},
            {"$set": {"revoked_at": utcnow_iso(), "reuse_detected_at": utcnow_iso()}},
        )
    session_id = stored_token.get("session_id")
    if session_id:
        await revoke_session(session_id, "REFRESH_TOKEN_REUSE")

    await log_security_event(
        event_type=SecurityEventType.REFRESH_TOKEN_REUSE_DETECTED,
        user_id=stored_token.get("user_id"),
        tenant_id=stored_token.get("tenant_id"),
        session_id=session_id,
        metadata={"family_id": family_id},
        request=request,
    )


# ─── Me ─────────────────────────────────────────────────────────────────────
@router.get("/me")
async def me(user: dict = Depends(get_current_user)):
    memberships = await _build_memberships(user["id"])
    return {
        "user": {
            "id": user["id"],
            "name": user["name"],
            "email": user["email"],
            "phone": user.get("phone"),
            "avatar_url": user.get("avatar_url"),
            "is_super_admin": user.get("is_super_admin", False),
            "status": user.get("status"),
        },
        "memberships": memberships,
    }
