"""Motivos de perda hierárquicos — Grupo → Subgrupo → Motivo."""
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request

from audit import log_audit
from db import db
from feature_guard import require_feature
from models import (
    GrupoMotivoPerdaCreate,
    GrupoMotivoPerdaUpdate,
    MotivoPerdaCreate,
    MotivoPerdaMoverRequest,
    MotivoPerdaStatusUpdate,
    MotivoPerdaUpdate,
    SubgrupoMotivoPerdaCreate,
    SubgrupoMotivoPerdaUpdate,
    new_id,
    utcnow_iso,
)
from motivos_perda_service import limpar_texto, normalizar_nome
from security import resolve_tenant_context, require_roles


router = APIRouter(prefix="/tenants/{tenant_slug}/motivos-perda", tags=["motivos-perda"])
ROLES_ADMINISTRACAO = ("TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER")


def _sem_id(doc: dict | None) -> dict | None:
    if doc:
        doc.pop("_id", None)
    return doc


async def _historico(*, empresa_id, usuario_id, tipo, elemento_id, acao, anterior=None, novo=None, request=None):
    await db.historico_administrativo_motivos_perda.insert_one({
        "identificador": new_id(),
        "empresa_id": empresa_id,
        "usuario_responsavel_id": usuario_id,
        "tipo_elemento": tipo,
        "elemento_id": elemento_id,
        "acao": acao,
        "valor_anterior": anterior,
        "valor_novo": novo,
        "criado_em": utcnow_iso(),
    })


async def _proxima_ordem(colecao, filtro: dict) -> int:
    doc = await colecao.find(filtro, {"_id": 0, "ordem": 1}).sort("ordem", -1).limit(1).to_list(1)
    return int((doc[0] or {}).get("ordem", 0)) + 1 if doc else 1


async def _garantir_nome_unico(colecao, filtro: dict, nome: str, ignorar_id: Optional[str] = None):
    nome_normalizado = normalizar_nome(nome)
    if not nome_normalizado:
        raise HTTPException(status_code=400, detail="Nome é obrigatório.")
    q = {**filtro, "nome_normalizado": nome_normalizado}
    if ignorar_id:
        q["identificador"] = {"$ne": ignorar_id}
    existente = await colecao.find_one(q, {"_id": 0, "identificador": 1})
    if existente:
        raise HTTPException(status_code=409, detail="Já existe um item com este nome neste nível.")
    return nome_normalizado


async def _contar_uso(empresa_id: str, campo: str, valor: str) -> int:
    return await db.attendances.count_documents({"tenant_id": empresa_id, campo: valor})


async def _contagens(empresa_id: str):
    grupos = await db.attendances.aggregate([
        {"$match": {"tenant_id": empresa_id, "grupo_motivo_perda_id": {"$ne": None}}},
        {"$group": {"_id": "$grupo_motivo_perda_id", "total": {"$sum": 1}}},
    ]).to_list(1000)
    subgrupos = await db.attendances.aggregate([
        {"$match": {"tenant_id": empresa_id, "subgrupo_motivo_perda_id": {"$ne": None}}},
        {"$group": {"_id": "$subgrupo_motivo_perda_id", "total": {"$sum": 1}}},
    ]).to_list(1000)
    motivos = await db.attendances.aggregate([
        {"$match": {"tenant_id": empresa_id, "motivo_perda_id": {"$ne": None}}},
        {"$group": {"_id": "$motivo_perda_id", "total": {"$sum": 1}}},
    ]).to_list(1000)
    return (
        {r["_id"]: r["total"] for r in grupos},
        {r["_id"]: r["total"] for r in subgrupos},
        {r["_id"]: r["total"] for r in motivos},
    )


async def _montar_estrutura(empresa_id: str, ativos_apenas: bool = False, termo: Optional[str] = None):
    filtro = {"empresa_id": empresa_id}
    if ativos_apenas:
        filtro["ativo"] = True
    grupos = await db.grupos_motivos_perda.find(filtro, {"_id": 0}).sort("ordem", 1).to_list(1000)
    sub_filtro = {"empresa_id": empresa_id}
    mot_filtro = {"empresa_id": empresa_id}
    if ativos_apenas:
        sub_filtro["ativo"] = True
        mot_filtro["ativo"] = True
    subgrupos = await db.subgrupos_motivos_perda.find(sub_filtro, {"_id": 0}).sort("ordem", 1).to_list(2000)
    motivos = await db.motivos_perda.find(mot_filtro, {"_id": 0}).sort("ordem", 1).to_list(4000)

    uso_grupos, uso_subgrupos, uso_motivos = await _contagens(empresa_id)
    motivos_por_subgrupo: dict[str, list] = {}
    for motivo in motivos:
        motivo["quantidade_registros_vinculados"] = uso_motivos.get(motivo["identificador"], 0)
        motivos_por_subgrupo.setdefault(motivo["subgrupo_motivo_perda_id"], []).append(motivo)
    subgrupos_por_grupo: dict[str, list] = {}
    for subgrupo in subgrupos:
        subgrupo["quantidade_registros_vinculados"] = uso_subgrupos.get(subgrupo["identificador"], 0)
        subgrupo["motivos"] = motivos_por_subgrupo.get(subgrupo["identificador"], [])
        subgrupos_por_grupo.setdefault(subgrupo["grupo_motivo_perda_id"], []).append(subgrupo)

    termo_normalizado = normalizar_nome(termo or "")
    saida = []
    for grupo in grupos:
        grupo["quantidade_registros_vinculados"] = uso_grupos.get(grupo["identificador"], 0)
        grupo["subgrupos"] = subgrupos_por_grupo.get(grupo["identificador"], [])
        if termo_normalizado:
            texto = " ".join([
                grupo.get("nome", ""),
                *(s.get("nome", "") for s in grupo["subgrupos"]),
                *(m.get("nome", "") for s in grupo["subgrupos"] for m in s.get("motivos", [])),
            ])
            if termo_normalizado not in normalizar_nome(texto):
                continue
        saida.append(grupo)
    return saida


@router.get("/estrutura")
async def estrutura(ativos_apenas: bool = False, termo: Optional[str] = None, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "motivos_nao_venda")
    return {"grupos": await _montar_estrutura(ctx["tenant"]["id"], ativos_apenas, termo)}


@router.get("/opcoes")
async def opcoes(ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "motivos_nao_venda")
    grupos = await _montar_estrutura(ctx["tenant"]["id"], True)
    completos = []
    for grupo in grupos:
        subgrupos = []
        for subgrupo in grupo.get("subgrupos", []):
            motivos = [m for m in subgrupo.get("motivos", []) if m.get("ativo")]
            if motivos:
                subgrupos.append({**subgrupo, "motivos": motivos})
        if subgrupos:
            completos.append({**grupo, "subgrupos": subgrupos})
    return {
        "hierarquia_ativa": bool(completos),
        "grupos": completos,
        "mensagem_sem_configuracao": "Cadastre ao menos um grupo, um subgrupo e um motivo ativo para utilizar a classificação de perdas.",
    }


@router.post("/grupos", status_code=201)
async def criar_grupo(payload: GrupoMotivoPerdaCreate, request: Request,
                      ctx: dict = Depends(require_roles(*ROLES_ADMINISTRACAO))):
    empresa_id = ctx["tenant"]["id"]
    await require_feature(empresa_id, "motivos_nao_venda")
    nome = limpar_texto(payload.nome)
    nome_normalizado = await _garantir_nome_unico(db.grupos_motivos_perda, {"empresa_id": empresa_id}, nome)
    agora = utcnow_iso()
    doc = {
        "identificador": new_id(), "empresa_id": empresa_id, "nome": nome,
        "nome_normalizado": nome_normalizado, "descricao": limpar_texto(payload.descricao),
        "ordem": await _proxima_ordem(db.grupos_motivos_perda, {"empresa_id": empresa_id}),
        "ativo": bool(payload.ativo), "criado_em": agora, "atualizado_em": agora,
        "usuario_responsavel_id": ctx["user"]["id"],
    }
    await db.grupos_motivos_perda.insert_one(doc)
    await _historico(empresa_id=empresa_id, usuario_id=ctx["user"]["id"], tipo="grupo", elemento_id=doc["identificador"], acao="criacao", novo=doc, request=request)
    await log_audit(action="GRUPO_MOTIVO_PERDA_CRIADO", entity="grupo_motivo_perda", entity_id=doc["identificador"], tenant_id=empresa_id, user_id=ctx["user"]["id"], new_value={"nome": nome}, request=request)
    return _sem_id(doc)


@router.put("/grupos/{identificador}")
async def editar_grupo(identificador: str, payload: GrupoMotivoPerdaUpdate, request: Request,
                       ctx: dict = Depends(require_roles(*ROLES_ADMINISTRACAO))):
    empresa_id = ctx["tenant"]["id"]
    atual = await db.grupos_motivos_perda.find_one({"empresa_id": empresa_id, "identificador": identificador}, {"_id": 0})
    if not atual:
        raise HTTPException(status_code=404, detail="Grupo não encontrado.")
    updates = {k: limpar_texto(v) for k, v in payload.model_dump(exclude_none=True).items()}
    if "nome" in updates:
        updates["nome_normalizado"] = await _garantir_nome_unico(db.grupos_motivos_perda, {"empresa_id": empresa_id}, updates["nome"], identificador)
    updates["atualizado_em"] = utcnow_iso()
    await db.grupos_motivos_perda.update_one({"empresa_id": empresa_id, "identificador": identificador}, {"$set": updates})
    novo = await db.grupos_motivos_perda.find_one({"empresa_id": empresa_id, "identificador": identificador}, {"_id": 0})
    await _historico(empresa_id=empresa_id, usuario_id=ctx["user"]["id"], tipo="grupo", elemento_id=identificador, acao="edicao", anterior=atual, novo=updates, request=request)
    return novo


@router.patch("/grupos/{identificador}/status")
async def status_grupo(identificador: str, payload: MotivoPerdaStatusUpdate, request: Request,
                       ctx: dict = Depends(require_roles(*ROLES_ADMINISTRACAO))):
    empresa_id = ctx["tenant"]["id"]
    atual = await db.grupos_motivos_perda.find_one({"empresa_id": empresa_id, "identificador": identificador}, {"_id": 0})
    if not atual:
        raise HTTPException(status_code=404, detail="Grupo não encontrado.")
    await db.grupos_motivos_perda.update_one({"empresa_id": empresa_id, "identificador": identificador}, {"$set": {"ativo": payload.ativo, "atualizado_em": utcnow_iso()}})
    await _historico(empresa_id=empresa_id, usuario_id=ctx["user"]["id"], tipo="grupo", elemento_id=identificador, acao="ativacao" if payload.ativo else "desativacao", anterior={"ativo": atual.get("ativo")}, novo={"ativo": payload.ativo}, request=request)
    return {"identificador": identificador, "ativo": payload.ativo}


@router.post("/subgrupos", status_code=201)
async def criar_subgrupo(payload: SubgrupoMotivoPerdaCreate, request: Request,
                         ctx: dict = Depends(require_roles(*ROLES_ADMINISTRACAO))):
    empresa_id = ctx["tenant"]["id"]
    grupo = await db.grupos_motivos_perda.find_one({"empresa_id": empresa_id, "identificador": payload.grupo_motivo_perda_id}, {"_id": 0})
    if not grupo:
        raise HTTPException(status_code=404, detail="Grupo relacionado não encontrado.")
    nome = limpar_texto(payload.nome)
    nome_normalizado = await _garantir_nome_unico(db.subgrupos_motivos_perda, {"empresa_id": empresa_id, "grupo_motivo_perda_id": payload.grupo_motivo_perda_id}, nome)
    agora = utcnow_iso()
    doc = {
        "identificador": new_id(), "empresa_id": empresa_id,
        "grupo_motivo_perda_id": payload.grupo_motivo_perda_id,
        "nome": nome, "nome_normalizado": nome_normalizado,
        "descricao": limpar_texto(payload.descricao),
        "ordem": await _proxima_ordem(db.subgrupos_motivos_perda, {"empresa_id": empresa_id, "grupo_motivo_perda_id": payload.grupo_motivo_perda_id}),
        "ativo": bool(payload.ativo), "criado_em": agora, "atualizado_em": agora,
        "usuario_responsavel_id": ctx["user"]["id"],
    }
    await db.subgrupos_motivos_perda.insert_one(doc)
    await _historico(empresa_id=empresa_id, usuario_id=ctx["user"]["id"], tipo="subgrupo", elemento_id=doc["identificador"], acao="criacao", novo=doc, request=request)
    return _sem_id(doc)


@router.put("/subgrupos/{identificador}")
async def editar_subgrupo(identificador: str, payload: SubgrupoMotivoPerdaUpdate, request: Request,
                          ctx: dict = Depends(require_roles(*ROLES_ADMINISTRACAO))):
    empresa_id = ctx["tenant"]["id"]
    atual = await db.subgrupos_motivos_perda.find_one({"empresa_id": empresa_id, "identificador": identificador}, {"_id": 0})
    if not atual:
        raise HTTPException(status_code=404, detail="Subgrupo não encontrado.")
    updates = {k: limpar_texto(v) if isinstance(v, str) else v for k, v in payload.model_dump(exclude_none=True).items()}
    novo_grupo_id = updates.get("grupo_motivo_perda_id", atual["grupo_motivo_perda_id"])
    grupo = await db.grupos_motivos_perda.find_one({"empresa_id": empresa_id, "identificador": novo_grupo_id}, {"_id": 0})
    if not grupo:
        raise HTTPException(status_code=404, detail="Grupo relacionado não encontrado.")
    nome_validar = updates.get("nome", atual["nome"])
    if "nome" in updates or novo_grupo_id != atual["grupo_motivo_perda_id"]:
        updates["nome_normalizado"] = await _garantir_nome_unico(db.subgrupos_motivos_perda, {"empresa_id": empresa_id, "grupo_motivo_perda_id": novo_grupo_id}, nome_validar, identificador)
    if novo_grupo_id != atual["grupo_motivo_perda_id"]:
        updates["ordem"] = await _proxima_ordem(db.subgrupos_motivos_perda, {"empresa_id": empresa_id, "grupo_motivo_perda_id": novo_grupo_id})
    updates["atualizado_em"] = utcnow_iso()
    await db.subgrupos_motivos_perda.update_one({"empresa_id": empresa_id, "identificador": identificador}, {"$set": updates})
    await _historico(empresa_id=empresa_id, usuario_id=ctx["user"]["id"], tipo="subgrupo", elemento_id=identificador, acao="transferencia" if novo_grupo_id != atual["grupo_motivo_perda_id"] else "edicao", anterior=atual, novo=updates, request=request)
    return await db.subgrupos_motivos_perda.find_one({"empresa_id": empresa_id, "identificador": identificador}, {"_id": 0})


@router.patch("/subgrupos/{identificador}/status")
async def status_subgrupo(identificador: str, payload: MotivoPerdaStatusUpdate, request: Request,
                          ctx: dict = Depends(require_roles(*ROLES_ADMINISTRACAO))):
    empresa_id = ctx["tenant"]["id"]
    atual = await db.subgrupos_motivos_perda.find_one({"empresa_id": empresa_id, "identificador": identificador}, {"_id": 0})
    if not atual:
        raise HTTPException(status_code=404, detail="Subgrupo não encontrado.")
    if payload.ativo:
        grupo = await db.grupos_motivos_perda.find_one({"empresa_id": empresa_id, "identificador": atual["grupo_motivo_perda_id"], "ativo": True}, {"_id": 0})
        if not grupo:
            raise HTTPException(status_code=409, detail="Não é possível ativar o subgrupo enquanto o grupo estiver inativo.")
    await db.subgrupos_motivos_perda.update_one({"empresa_id": empresa_id, "identificador": identificador}, {"$set": {"ativo": payload.ativo, "atualizado_em": utcnow_iso()}})
    await _historico(empresa_id=empresa_id, usuario_id=ctx["user"]["id"], tipo="subgrupo", elemento_id=identificador, acao="ativacao" if payload.ativo else "desativacao", anterior={"ativo": atual.get("ativo")}, novo={"ativo": payload.ativo}, request=request)
    return {"identificador": identificador, "ativo": payload.ativo}


@router.post("/motivos", status_code=201)
async def criar_motivo(payload: MotivoPerdaCreate, request: Request,
                       ctx: dict = Depends(require_roles(*ROLES_ADMINISTRACAO))):
    empresa_id = ctx["tenant"]["id"]
    subgrupo = await db.subgrupos_motivos_perda.find_one({"empresa_id": empresa_id, "identificador": payload.subgrupo_motivo_perda_id}, {"_id": 0})
    if not subgrupo:
        raise HTTPException(status_code=404, detail="Subgrupo relacionado não encontrado.")
    nome = limpar_texto(payload.nome)
    nome_normalizado = await _garantir_nome_unico(db.motivos_perda, {"empresa_id": empresa_id, "subgrupo_motivo_perda_id": payload.subgrupo_motivo_perda_id}, nome)
    limite = int(payload.limite_descricao_complementar or 300)
    if limite < 1 or limite > 2000:
        raise HTTPException(status_code=400, detail="O limite da descrição complementar deve ficar entre 1 e 2000 caracteres.")
    agora = utcnow_iso()
    doc = {
        "identificador": new_id(), "empresa_id": empresa_id,
        "subgrupo_motivo_perda_id": payload.subgrupo_motivo_perda_id,
        "grupo_motivo_perda_id": subgrupo["grupo_motivo_perda_id"],
        "nome": nome, "nome_normalizado": nome_normalizado,
        "descricao": limpar_texto(payload.descricao),
        "ordem": await _proxima_ordem(db.motivos_perda, {"empresa_id": empresa_id, "subgrupo_motivo_perda_id": payload.subgrupo_motivo_perda_id}),
        "ativo": bool(payload.ativo),
        "exige_descricao_complementar": bool(payload.exige_descricao_complementar),
        "limite_descricao_complementar": limite,
        "criado_em": agora, "atualizado_em": agora,
        "usuario_responsavel_id": ctx["user"]["id"],
    }
    await db.motivos_perda.insert_one(doc)
    await _historico(empresa_id=empresa_id, usuario_id=ctx["user"]["id"], tipo="motivo", elemento_id=doc["identificador"], acao="criacao", novo=doc, request=request)
    return _sem_id(doc)


@router.put("/motivos/{identificador}")
async def editar_motivo(identificador: str, payload: MotivoPerdaUpdate, request: Request,
                        ctx: dict = Depends(require_roles(*ROLES_ADMINISTRACAO))):
    empresa_id = ctx["tenant"]["id"]
    atual = await db.motivos_perda.find_one({"empresa_id": empresa_id, "identificador": identificador}, {"_id": 0})
    if not atual:
        raise HTTPException(status_code=404, detail="Motivo não encontrado.")
    updates = {k: limpar_texto(v) if isinstance(v, str) else v for k, v in payload.model_dump(exclude_none=True).items()}
    novo_subgrupo_id = updates.get("subgrupo_motivo_perda_id", atual["subgrupo_motivo_perda_id"])
    subgrupo = await db.subgrupos_motivos_perda.find_one({"empresa_id": empresa_id, "identificador": novo_subgrupo_id}, {"_id": 0})
    if not subgrupo:
        raise HTTPException(status_code=404, detail="Subgrupo relacionado não encontrado.")
    nome_validar = updates.get("nome", atual["nome"])
    if "nome" in updates or novo_subgrupo_id != atual["subgrupo_motivo_perda_id"]:
        updates["nome_normalizado"] = await _garantir_nome_unico(db.motivos_perda, {"empresa_id": empresa_id, "subgrupo_motivo_perda_id": novo_subgrupo_id}, nome_validar, identificador)
    if novo_subgrupo_id != atual["subgrupo_motivo_perda_id"]:
        updates["grupo_motivo_perda_id"] = subgrupo["grupo_motivo_perda_id"]
        updates["ordem"] = await _proxima_ordem(db.motivos_perda, {"empresa_id": empresa_id, "subgrupo_motivo_perda_id": novo_subgrupo_id})
    if "limite_descricao_complementar" in updates:
        limite = int(updates["limite_descricao_complementar"] or 300)
        if limite < 1 or limite > 2000:
            raise HTTPException(status_code=400, detail="O limite da descrição complementar deve ficar entre 1 e 2000 caracteres.")
        updates["limite_descricao_complementar"] = limite
    updates["atualizado_em"] = utcnow_iso()
    await db.motivos_perda.update_one({"empresa_id": empresa_id, "identificador": identificador}, {"$set": updates})
    await _historico(empresa_id=empresa_id, usuario_id=ctx["user"]["id"], tipo="motivo", elemento_id=identificador, acao="transferencia" if novo_subgrupo_id != atual["subgrupo_motivo_perda_id"] else "edicao", anterior=atual, novo=updates, request=request)
    return await db.motivos_perda.find_one({"empresa_id": empresa_id, "identificador": identificador}, {"_id": 0})


@router.patch("/motivos/{identificador}/status")
async def status_motivo(identificador: str, payload: MotivoPerdaStatusUpdate, request: Request,
                        ctx: dict = Depends(require_roles(*ROLES_ADMINISTRACAO))):
    empresa_id = ctx["tenant"]["id"]
    atual = await db.motivos_perda.find_one({"empresa_id": empresa_id, "identificador": identificador}, {"_id": 0})
    if not atual:
        raise HTTPException(status_code=404, detail="Motivo não encontrado.")
    if payload.ativo:
        subgrupo = await db.subgrupos_motivos_perda.find_one({"empresa_id": empresa_id, "identificador": atual["subgrupo_motivo_perda_id"], "ativo": True}, {"_id": 0})
        grupo = await db.grupos_motivos_perda.find_one({"empresa_id": empresa_id, "identificador": atual["grupo_motivo_perda_id"], "ativo": True}, {"_id": 0})
        if not subgrupo or not grupo:
            raise HTTPException(status_code=409, detail="Não é possível ativar o motivo enquanto o grupo ou subgrupo estiver inativo.")
    await db.motivos_perda.update_one({"empresa_id": empresa_id, "identificador": identificador}, {"$set": {"ativo": payload.ativo, "atualizado_em": utcnow_iso()}})
    await _historico(empresa_id=empresa_id, usuario_id=ctx["user"]["id"], tipo="motivo", elemento_id=identificador, acao="ativacao" if payload.ativo else "desativacao", anterior={"ativo": atual.get("ativo")}, novo={"ativo": payload.ativo}, request=request)
    return {"identificador": identificador, "ativo": payload.ativo}


@router.patch("/{tipo}/{identificador}/mover")
async def mover(tipo: str, identificador: str, payload: MotivoPerdaMoverRequest, request: Request,
                ctx: dict = Depends(require_roles(*ROLES_ADMINISTRACAO))):
    empresa_id = ctx["tenant"]["id"]
    mapa = {
        "grupos": (db.grupos_motivos_perda, {"empresa_id": empresa_id}, "grupo"),
        "subgrupos": (db.subgrupos_motivos_perda, None, "subgrupo"),
        "motivos": (db.motivos_perda, None, "motivo"),
    }
    if tipo not in mapa:
        raise HTTPException(status_code=404, detail="Tipo inválido.")
    colecao, filtro_base, tipo_hist = mapa[tipo]
    atual = await colecao.find_one({"empresa_id": empresa_id, "identificador": identificador}, {"_id": 0})
    if not atual:
        raise HTTPException(status_code=404, detail="Elemento não encontrado.")
    if tipo == "subgrupos":
        filtro_base = {"empresa_id": empresa_id, "grupo_motivo_perda_id": atual["grupo_motivo_perda_id"]}
    if tipo == "motivos":
        filtro_base = {"empresa_id": empresa_id, "subgrupo_motivo_perda_id": atual["subgrupo_motivo_perda_id"]}
    comparador = "$lt" if payload.direcao == "cima" else "$gt"
    ordenacao = -1 if payload.direcao == "cima" else 1
    alvo = await colecao.find_one({**filtro_base, "ordem": {comparador: atual.get("ordem", 0)}}, {"_id": 0}, sort=[("ordem", ordenacao)])
    if not alvo:
        return {"movido": False}
    await colecao.update_one({"empresa_id": empresa_id, "identificador": atual["identificador"]}, {"$set": {"ordem": alvo.get("ordem", 0), "atualizado_em": utcnow_iso()}})
    await colecao.update_one({"empresa_id": empresa_id, "identificador": alvo["identificador"]}, {"$set": {"ordem": atual.get("ordem", 0), "atualizado_em": utcnow_iso()}})
    await _historico(empresa_id=empresa_id, usuario_id=ctx["user"]["id"], tipo=tipo_hist, elemento_id=identificador, acao="ordenacao", anterior={"ordem": atual.get("ordem")}, novo={"ordem": alvo.get("ordem")}, request=request)
    return {"movido": True}


@router.get("/{tipo}/{identificador}/uso")
async def visualizar_uso(tipo: str, identificador: str, ctx: dict = Depends(resolve_tenant_context)):
    empresa_id = ctx["tenant"]["id"]
    campos = {"grupos": "grupo_motivo_perda_id", "subgrupos": "subgrupo_motivo_perda_id", "motivos": "motivo_perda_id"}
    if tipo not in campos:
        raise HTTPException(status_code=404, detail="Tipo inválido.")
    campo = campos[tipo]
    filtro = {"tenant_id": empresa_id, campo: identificador}
    total = await db.attendances.count_documents(filtro)
    raw = await db.attendances.find(filtro, {"_id": 0}).sort("finished_at", -1).limit(100).to_list(100)
    store_ids = list({a.get("store_id") for a in raw if a.get("store_id")})
    seller_ids = list({a.get("seller_id") for a in raw if a.get("seller_id")})
    lojas = await db.stores.find({"id": {"$in": store_ids}}, {"_id": 0, "id": 1, "name": 1}).to_list(200)
    vendedores = []
    if seller_ids:
        perfis = await db.seller_profiles.find({"id": {"$in": seller_ids}}, {"_id": 0, "id": 1, "user_id": 1}).to_list(200)
        users = await db.users.find({"id": {"$in": [p["user_id"] for p in perfis]}}, {"_id": 0, "id": 1, "name": 1}).to_list(200)
        nomes = {u["id"]: u.get("name") for u in users}
        vendedores = [{"id": p["id"], "nome": nomes.get(p["user_id"], "—")} for p in perfis]
    datas = [a.get("finished_at") or a.get("created_at") for a in raw if a.get("finished_at") or a.get("created_at")]
    return {
        "quantidade_atendimentos": total,
        "unidades": [{"id": l["id"], "nome": l.get("name")} for l in lojas],
        "vendedores": vendedores,
        "primeira_utilizacao": min(datas) if datas else None,
        "ultima_utilizacao": max(datas) if datas else None,
        "atendimentos": raw,
    }


@router.delete("/{tipo}/{identificador}")
async def excluir(tipo: str, identificador: str, request: Request,
                  ctx: dict = Depends(require_roles(*ROLES_ADMINISTRACAO))):
    empresa_id = ctx["tenant"]["id"]
    configuracao = {
        "grupos": (db.grupos_motivos_perda, "grupo", "grupo_motivo_perda_id"),
        "subgrupos": (db.subgrupos_motivos_perda, "subgrupo", "subgrupo_motivo_perda_id"),
        "motivos": (db.motivos_perda, "motivo", "motivo_perda_id"),
    }
    if tipo not in configuracao:
        raise HTTPException(status_code=404, detail="Tipo inválido.")
    colecao, tipo_hist, campo_uso = configuracao[tipo]
    atual = await colecao.find_one({"empresa_id": empresa_id, "identificador": identificador}, {"_id": 0})
    if not atual:
        raise HTTPException(status_code=404, detail="Elemento não encontrado.")

    if tipo == "grupos":
        filhos = await db.subgrupos_motivos_perda.count_documents({"empresa_id": empresa_id, "grupo_motivo_perda_id": identificador})
    elif tipo == "subgrupos":
        filhos = await db.motivos_perda.count_documents({"empresa_id": empresa_id, "subgrupo_motivo_perda_id": identificador})
    else:
        filhos = 0
    if filhos:
        await _historico(empresa_id=empresa_id, usuario_id=ctx["user"]["id"], tipo=tipo_hist, elemento_id=identificador, acao="exclusao_bloqueada", anterior={"motivo": "possui_elementos_inferiores", "quantidade": filhos}, request=request)
        raise HTTPException(status_code=409, detail={
            "error": "EXCLUSAO_BLOQUEADA_POR_FILHOS",
            "message": "Não é possível excluir definitivamente porque existem elementos inferiores vinculados.",
            "quantidade_vinculada": filhos,
        })

    uso = await _contar_uso(empresa_id, campo_uso, identificador)
    if uso:
        await colecao.update_one({"empresa_id": empresa_id, "identificador": identificador}, {"$set": {"ativo": False, "atualizado_em": utcnow_iso()}})
        await _historico(empresa_id=empresa_id, usuario_id=ctx["user"]["id"], tipo=tipo_hist, elemento_id=identificador, acao="exclusao_substituida_por_desativacao", anterior=atual, novo={"ativo": False, "quantidade_vinculada": uso}, request=request)
        return {
            "excluido": False,
            "desativado": True,
            "quantidade_vinculada": uso,
            "mensagem": "Este elemento já foi utilizado. Ele foi desativado para novos atendimentos e o histórico foi preservado.",
        }

    await colecao.delete_one({"empresa_id": empresa_id, "identificador": identificador})
    await _historico(empresa_id=empresa_id, usuario_id=ctx["user"]["id"], tipo=tipo_hist, elemento_id=identificador, acao="exclusao_definitiva", anterior=atual, request=request)
    return {"excluido": True, "desativado": False, "quantidade_vinculada": 0}