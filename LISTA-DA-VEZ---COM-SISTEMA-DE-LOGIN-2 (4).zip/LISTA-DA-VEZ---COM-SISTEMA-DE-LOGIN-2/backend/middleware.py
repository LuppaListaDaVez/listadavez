"""Middleware global: Request ID + headers de segurança + logging estruturado — P0/P3."""
import logging
import os
import time
import uuid

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

logger = logging.getLogger("lista-da-vez.requests")

# Paths que não devem ser logados para reduzir ruído
_SILENT_PATHS = {"/api/health", "/api/health/live", "/api/health/ready", "/"}

# CSP configurável por variável de ambiente (permite relaxar em dev se necessário)
_CSP_EXTRA = os.environ.get("CSP_EXTRA_SOURCES", "")
_CSP = (
    "default-src 'self'; "
    f"script-src 'self' 'unsafe-inline' 'unsafe-eval' {_CSP_EXTRA}; "
    f"style-src 'self' 'unsafe-inline' {_CSP_EXTRA}; "
    "img-src 'self' data: https:; "
    "connect-src 'self' wss: ws: https:; "
    "font-src 'self' data:; "
    "worker-src 'self' blob:; "
    "frame-ancestors 'none'; "
    "base-uri 'self'; "
    "form-action 'self';"
).strip()


class RequestContextMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        request_id = request.headers.get("X-Request-Id") or str(uuid.uuid4())[:12]
        request.state.request_id = request_id

        start = time.time()

        try:
            response: Response = await call_next(request)
        except Exception as exc:
            logger.error(
                "UNHANDLED_ERROR req=%s path=%s err=%s",
                request_id,
                request.url.path,
                type(exc).__name__,
                exc_info=False,  # stack trace apenas em log técnico, não exposto ao cliente
            )
            raise

        duration_ms = int((time.time() - start) * 1000)

        # Request ID em toda resposta
        response.headers["X-Request-Id"] = request_id

        # Headers de segurança (P0/P3)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        response.headers["Content-Security-Policy"] = _CSP
        response.headers["X-Permitted-Cross-Domain-Policies"] = "none"

        # Log estruturado (exceto health-checks e root)
        path = request.url.path
        if path not in _SILENT_PATHS and not path.endswith("/live") and not path.endswith("/ready"):
            # Extrai contexto de segurança do state (definido por get_current_user)
            token_payload = getattr(request.state, "token_payload", {}) or {}
            tenant_id = token_payload.get("tenant_id", "")
            tenant_slug = token_payload.get("tenant_slug", "")
            user_id = getattr(request.state, "user_id", "") or token_payload.get("user_id", "") or ""
            session_id = getattr(request.state, "session_id", "") or token_payload.get("session_id", "") or ""

            logger.info(
                "HTTP %s %s %d %dms req=%s tenant=%s user=%s session=%s",
                request.method,
                path,
                response.status_code,
                duration_ms,
                request_id,
                tenant_slug or tenant_id or "-",
                user_id[:8] if user_id else "-",
                session_id[:8] if session_id else "-",
            )

        return response
