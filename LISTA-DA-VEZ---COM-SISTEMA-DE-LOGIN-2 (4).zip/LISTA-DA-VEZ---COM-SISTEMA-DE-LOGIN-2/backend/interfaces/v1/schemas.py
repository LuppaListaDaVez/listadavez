"""Schemas padronizados para a API v1.

Contrato de resposta:
  Sucesso:  { "data": {...}, "meta": {...}, "request_id": "..." }
  Erro:     { "error": "CODE", "message": "...", "request_id": "...", "details": {} }

Paginação:
  "meta": { "page": 1, "page_size": 20, "total": 100, "pages": 5 }
"""
import math
from typing import Any, Dict, Generic, List, Optional, TypeVar
from pydantic import BaseModel

T = TypeVar("T")


class PaginationMeta(BaseModel):
    page: int
    page_size: int
    total: int
    pages: int

    @classmethod
    def create(cls, page: int, page_size: int, total: int) -> "PaginationMeta":
        pages = math.ceil(total / max(page_size, 1))
        return cls(page=page, page_size=page_size, total=total, pages=pages)


class ApiResponse(BaseModel):
    """Envelope padrão para respostas da API v1."""
    data: Any = None
    meta: Optional[Dict[str, Any]] = None
    request_id: Optional[str] = None

    @classmethod
    def ok(
        cls,
        data: Any,
        request_id: Optional[str] = None,
        meta: Optional[Dict] = None,
    ) -> "ApiResponse":
        return cls(data=data, meta=meta, request_id=request_id)

    @classmethod
    def paginated(
        cls,
        data: List,
        pagination: PaginationMeta,
        request_id: Optional[str] = None,
        extra_meta: Optional[Dict] = None,
    ) -> "ApiResponse":
        meta = pagination.model_dump()
        if extra_meta:
            meta.update(extra_meta)
        return cls(data=data, meta=meta, request_id=request_id)


class ApiError(BaseModel):
    """Envelope padrão para erros da API v1."""
    error: str
    message: str
    request_id: Optional[str] = None
    details: Optional[Dict[str, Any]] = None
