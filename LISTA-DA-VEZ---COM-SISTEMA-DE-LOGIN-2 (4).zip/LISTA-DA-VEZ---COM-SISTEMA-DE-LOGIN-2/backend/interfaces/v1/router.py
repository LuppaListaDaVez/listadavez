"""API v1 Router — versiona os endpoints sem quebrar rotas existentes.

Estratégia:
- Todas as rotas antigas continuam em /api/tenants/{slug}/...
- Novas integrações devem usar /api/v1/tenants/{slug}/...
- Os handlers são os mesmos (DRY — sem duplicação de lógica).
- Resposta no envelope padrão { data, meta, request_id }.
- Erros de domínio são convertidos para ApiError automaticamente.

Migração:
- Frontend atualiza para /api/v1 gradualmente por domínio.
- Rotas antigas ficam como aliases até deprecação formal.
"""
import logging
from typing import Any, Dict

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import JSONResponse

from interfaces.v1.schemas import ApiResponse, ApiError
from domain.base import DomainError

# Import routers existentes para re-exportar com prefixo v1
from routes_queue import router as queue_router_original
from routes_tenant import router as tenant_router_original
from routes_tenant_auth import router as tenant_auth_router
from routes_reports import router as reports_router
from routes_export_jobs import router as export_jobs_router
from routes_health import health_router, metrics_router

logger = logging.getLogger("lista-da-vez.v1")

v1_router = APIRouter(prefix="/v1")

# ── Health (sem tenant context) ───────────────────────────────────────────────
v1_router.include_router(health_router, tags=["v1:health"])

# ── Tenant auth & resources ───────────────────────────────────────────────────
# As rotas originais já têm prefixo /tenants/{slug}
# O v1_router adiciona /v1 antes, resultado: /api/v1/tenants/{slug}/...
v1_router.include_router(tenant_auth_router, tags=["v1:auth"])
v1_router.include_router(tenant_router_original, tags=["v1:tenant"])
v1_router.include_router(queue_router_original, tags=["v1:queue"])
v1_router.include_router(reports_router, tags=["v1:reports"])
v1_router.include_router(export_jobs_router, tags=["v1:export"])


# ── Exception handler para DomainErrors na v1 ────────────────────────────────

async def domain_error_handler(request: Request, exc: DomainError) -> JSONResponse:
    """Converte DomainError para ApiError padronizado."""
    request_id = request.state.request_id if hasattr(request.state, "request_id") else None
    error_body = ApiError(
        error=exc.code,
        message=exc.message,
        request_id=request_id,
    )
    return JSONResponse(
        status_code=exc.status_code,
        content=error_body.model_dump(exclude_none=True),
    )
