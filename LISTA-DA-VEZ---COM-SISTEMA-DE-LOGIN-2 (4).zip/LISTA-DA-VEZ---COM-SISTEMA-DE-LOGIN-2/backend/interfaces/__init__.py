"""Interfaces layer — HTTP controllers, routes, schemas, middleware."""
