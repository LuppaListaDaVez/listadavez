"""Pydantic models for documents and API payloads."""
from datetime import datetime, timezone
from typing import Optional, List, Literal, Dict, Any
import uuid

from pydantic import BaseModel, EmailStr, Field, ConfigDict, field_validator, model_validator

from cnpj_utils import validar_cnpj, normalizar_cnpj


def utcnow_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def new_id() -> str:
    return str(uuid.uuid4())


# ===== Auth =====
class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class RefreshRequest(BaseModel):
    refresh_token: str


# ===== Tenant =====
TenantStatus = Literal["ACTIVE", "SUSPENDED", "CANCELLED", "TRIAL"]


class TenantCreate(BaseModel):
    name: str
    slug: str
    cnpj: str  # obrigatório — validado pelo algoritmo de dígito verificador
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    plan_id: Optional[str] = None
    logo_url: Optional[str] = None
    primary_color: Optional[str] = None
    admin_name: Optional[str] = None
    admin_email: Optional[EmailStr] = None
    admin_password: Optional[str] = None

    @field_validator("cnpj")
    @classmethod
    def cnpj_valido(cls, v: str) -> str:
        if not validar_cnpj(v):
            raise ValueError(
                f"CNPJ inválido: '{v}'. Informe um CNPJ com dígito verificador correto."
            )
        return normalizar_cnpj(v)  # armazena apenas os 14 dígitos


class TenantUpdate(BaseModel):
    name: Optional[str] = None
    cnpj: Optional[str] = None
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    plan_id: Optional[str] = None
    logo_url: Optional[str] = None
    primary_color: Optional[str] = None


class TenantStatusUpdate(BaseModel):
    status: TenantStatus


# ===== Plans / Features =====
class PlanCreate(BaseModel):
    name: str
    description: Optional[str] = None
    status: Literal["ACTIVE", "INACTIVE"] = "ACTIVE"
    limits: Dict[str, Any] = Field(default_factory=dict)


class FeatureCreate(BaseModel):
    key: str
    name: str
    description: Optional[str] = None


class FeatureToggleItem(BaseModel):
    feature_key: str
    enabled: bool


class TenantFeaturesUpdate(BaseModel):
    features: List[FeatureToggleItem]


# ===== Stores =====
StoreStatus = Literal["ACTIVE", "INACTIVE"]


class StoreCreate(BaseModel):
    name: str
    code: str
    address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    country: Optional[str] = "Brasil"
    timezone: Optional[str] = "America/Sao_Paulo"
    phone: Optional[str] = None


class StoreUpdate(BaseModel):
    name: Optional[str] = None
    code: Optional[str] = None
    address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    country: Optional[str] = None
    timezone: Optional[str] = None
    phone: Optional[str] = None


class StoreStatusUpdate(BaseModel):
    status: StoreStatus


# ===== Users =====
Role = Literal[
    "TENANT_ADMIN",
    "REGIONAL_MANAGER",
    "STORE_MANAGER",
    "SUPERVISOR",
    "SELLER",
]
UserStatus = Literal["ACTIVE", "INACTIVE", "BLOCKED"]


class TenantUserCreate(BaseModel):
    name: str
    email: EmailStr
    phone: Optional[str] = None
    password: str
    role: Role
    store_ids: List[str] = Field(default_factory=list)
    avatar_url: Optional[str] = None
    team_id: Optional[str] = None


class TenantUserUpdate(BaseModel):
    name: Optional[str] = None
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    role: Optional[Role] = None
    store_ids: Optional[List[str]] = None
    avatar_url: Optional[str] = None
    team_id: Optional[str] = None


class AdminSetPassword(BaseModel):
    new_password: str


class UserStatusUpdate(BaseModel):
    status: UserStatus


# ===== Settings =====
class SettingsUpdate(BaseModel):
    general_settings: Dict[str, Any] = Field(default_factory=dict)


# ===== Teams =====
class TeamCreate(BaseModel):
    store_id: str
    name: str
    description: Optional[str] = None


class TeamUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    store_id: Optional[str] = None


class TeamStatusUpdate(BaseModel):
    status: Literal["ACTIVE", "INACTIVE"]


class TeamMembersUpdate(BaseModel):
    seller_profile_ids: List[str] = Field(default_factory=list)


# ===== Sellers =====
SellerOperationalStatus = Literal[
    "OFFLINE", "AVAILABLE", "WAITING_IN_QUEUE", "SERVING",
    "BREAK", "LUNCH", "MEETING", "TRAINING", "ABSENT", "BLOCKED",
]


class SellerCreate(BaseModel):
    user_id: Optional[str] = None
    name: Optional[str] = None
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    password: Optional[str] = None
    store_id: str
    team_id: Optional[str] = None
    employee_code: Optional[str] = None
    hire_date: Optional[str] = None
    status: Optional[Literal["ACTIVE", "INACTIVE"]] = "ACTIVE"
    current_status: Optional[SellerOperationalStatus] = "OFFLINE"


class SellerUpdate(BaseModel):
    team_id: Optional[str] = None
    employee_code: Optional[str] = None
    hire_date: Optional[str] = None
    status: Optional[Literal["ACTIVE", "INACTIVE"]] = None
    avatar_url: Optional[str] = None


class SellerStatusChange(BaseModel):
    new_status: SellerOperationalStatus
    reason: Optional[str] = None


# ===== Loss reasons =====
class LossReasonCreate(BaseModel):
    store_id: Optional[str] = None
    name: str
    description: Optional[str] = None
    active: Optional[bool] = True


class LossReasonUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    store_id: Optional[str] = None


class LossReasonStatusUpdate(BaseModel):
    active: bool


# ===== Motivos de perda hierárquicos (Prompt 3) =====
class GrupoMotivoPerdaCreate(BaseModel):
    nome: str
    descricao: Optional[str] = None
    ativo: Optional[bool] = True


class GrupoMotivoPerdaUpdate(BaseModel):
    nome: Optional[str] = None
    descricao: Optional[str] = None


class SubgrupoMotivoPerdaCreate(BaseModel):
    grupo_motivo_perda_id: str
    nome: str
    descricao: Optional[str] = None
    ativo: Optional[bool] = True


class SubgrupoMotivoPerdaUpdate(BaseModel):
    grupo_motivo_perda_id: Optional[str] = None
    nome: Optional[str] = None
    descricao: Optional[str] = None


class MotivoPerdaCreate(BaseModel):
    subgrupo_motivo_perda_id: str
    nome: str
    descricao: Optional[str] = None
    ativo: Optional[bool] = True
    exige_descricao_complementar: Optional[bool] = False
    limite_descricao_complementar: Optional[int] = 300


class MotivoPerdaUpdate(BaseModel):
    subgrupo_motivo_perda_id: Optional[str] = None
    nome: Optional[str] = None
    descricao: Optional[str] = None
    exige_descricao_complementar: Optional[bool] = None
    limite_descricao_complementar: Optional[int] = None


class MotivoPerdaStatusUpdate(BaseModel):
    ativo: bool


class MotivoPerdaMoverRequest(BaseModel):
    direcao: Literal["cima", "baixo"]


# ===== Store settings =====
class StoreSettingsUpdate(BaseModel):
    queue_settings: Optional[Dict[str, Any]] = None
    realtime_settings: Optional[Dict[str, Any]] = None
    notification_settings: Optional[Dict[str, Any]] = None


# ===== Queues (Etapa 3) =====
QueueType = Literal["GENERAL", "DEPARTMENT", "TEAM", "SERVICE_TYPE", "PRIORITY", "CUSTOM"]


class QueueCreate(BaseModel):
    name: str
    type: QueueType = "GENERAL"
    is_default: Optional[bool] = False
    department_name: Optional[str] = None
    team_id: Optional[str] = None
    priority_level: Optional[int] = None
    routing_rules: Optional[Dict[str, Any]] = None
    settings: Optional[Dict[str, Any]] = None


class QueueUpdate(BaseModel):
    name: Optional[str] = None
    department_name: Optional[str] = None
    team_id: Optional[str] = None
    priority_level: Optional[int] = None
    routing_rules: Optional[Dict[str, Any]] = None
    settings: Optional[Dict[str, Any]] = None


class QueueStatusUpdate(BaseModel):
    status: Literal["ACTIVE", "INACTIVE"]


class QueueJoinRequest(BaseModel):
    queue_id: Optional[str] = None
    seller_id: str


class QueueLeaveRequest(BaseModel):
    queue_id: Optional[str] = None
    seller_id: str
    reason: Optional[str] = None


class StartAttendanceRequest(BaseModel):
    queue_id: Optional[str] = None
    seller_id: str
    source: Optional[Literal["WALK_IN", "MANUAL", "RETURNING_CUSTOMER"]] = "WALK_IN"
    customer_name: Optional[str] = None
    customer_phone: Optional[str] = None
    notes: Optional[str] = None


class StartPreferenceAttendanceRequest(BaseModel):
    queue_id: Optional[str] = None
    seller_id: Optional[str] = None
    customer_name: str
    customer_phone: Optional[str] = None
    notes: Optional[str] = None


class SaleItemInput(BaseModel):
    product_id: Optional[str] = None
    name: Optional[str] = None
    sku: Optional[str] = None
    quantity: int = 1
    unit_price_cents: Optional[int] = None
    discount_cents: Optional[int] = 0


class PaymentMethodInput(BaseModel):
    method: str
    amount_cents: int


class SaleInput(BaseModel):
    items: List[SaleItemInput] = Field(default_factory=list)
    gross_amount_cents: Optional[int] = None
    discount_amount_cents: Optional[int] = 0
    payment_methods: List[PaymentMethodInput] = Field(default_factory=list)
    notes: Optional[str] = None


class FinishAttendanceRequest(BaseModel):
    attendance_id: str
    result: Literal["SALE", "NO_SALE", "FOLLOW_UP", "INVALID"]
    sale_amount_cents: Optional[int] = None
    sale: Optional[SaleInput] = None
    loss_reason_id: Optional[str] = None
    grupo_motivo_perda_id: Optional[str] = None
    subgrupo_motivo_perda_id: Optional[str] = None
    motivo_perda_id: Optional[str] = None
    descricao_complementar: Optional[str] = None
    notes: Optional[str] = None
    product_quantity: Optional[int] = None

    @field_validator("sale_amount_cents")
    @classmethod
    def validate_sale_amount(cls, v):
        if v is not None and v > 100_000_000_00:
            raise ValueError("sale_amount_cents excede o máximo permitido")
        if v is not None and v < 0:
            raise ValueError("sale_amount_cents não pode ser negativo")
        return v


class MultipleAttendanceDetailedRow(BaseModel):
    customer_name: Optional[str] = None
    customer_phone: Optional[str] = None
    result: Literal["SALE", "NO_SALE"]
    sale_amount_cents: Optional[int] = 0
    product_quantity: Optional[int] = 0
    loss_reason_id: Optional[str] = None
    grupo_motivo_perda_id: Optional[str] = None
    subgrupo_motivo_perda_id: Optional[str] = None
    motivo_perda_id: Optional[str] = None
    descricao_complementar: Optional[str] = None
    notes: Optional[str] = None


class FinishMultipleAttendancesRequest(BaseModel):
    attendance_id: str
    mode: Literal["AGGREGATED", "DETAILED"]
    total_customers: Optional[int] = None
    successes: Optional[int] = None
    no_sales: Optional[int] = None
    total_amount_cents: Optional[int] = 0
    total_product_quantity: Optional[int] = 0
    loss_reason_id: Optional[str] = None
    grupo_motivo_perda_id: Optional[str] = None
    subgrupo_motivo_perda_id: Optional[str] = None
    motivo_perda_id: Optional[str] = None
    descricao_complementar: Optional[str] = None
    notes: Optional[str] = None
    rows: Optional[List[MultipleAttendanceDetailedRow]] = None


# ===== Products (Etapa 5) =====
class ProductCreate(BaseModel):
    sku: Optional[str] = None
    name: str
    description: Optional[str] = None
    price_cents: int
    category: Optional[str] = None
    active: Optional[bool] = True


class ProductUpdate(BaseModel):
    sku: Optional[str] = None
    name: Optional[str] = None
    description: Optional[str] = None
    price_cents: Optional[int] = None
    category: Optional[str] = None


class ProductStatusUpdate(BaseModel):
    active: bool


class ReorderQueueRequest(BaseModel):
    queue_id: Optional[str] = None
    ordered_seller_ids: List[str]


class MarkAwayRequest(BaseModel):
    seller_id: str
    new_status: Literal["BREAK", "LUNCH", "MEETING", "TRAINING", "ABSENT", "OFFLINE"]
    reason: Optional[str] = None


class ReturnSellerRequest(BaseModel):
    seller_id: str
    reason: Optional[str] = None
    join_queue: Optional[bool] = False
    queue_id: Optional[str] = None


class PreferenceReportFilters(BaseModel):
    date_start: Optional[str] = None
    date_end: Optional[str] = None
    store_id: Optional[str] = None


# ───── Novos endpoints em português (Prompt 2) ─────────────────────────────────
MOTIVOS_SAIDA_VALIDOS = Literal["LANCHE_OU_ALMOCO", "ATIVIDADE_OPERACIONAL", "ENCERRAR_DIA"]

class SairDaFilaRequest(BaseModel):
    """Vendedor sai da Fila Geral; motivo obrigatório via Janela de Saída."""
    seller_id: str
    motivo: Literal["LANCHE_OU_ALMOCO", "ATIVIDADE_OPERACIONAL", "ENCERRAR_DIA"]
    queue_id: Optional[str] = None


class RetornarOperacaoRequest(BaseModel):
    """Vendedor em Atividade Operacional retorna à Fila Geral ativa."""
    seller_id: str


class NovaJornadaRequest(BaseModel):
    """Inicia nova jornada para vendedor que encerrou o dia."""
    seller_id: str


class RetornarDaForaRequest(BaseModel):
    """Vendedor retorna do estado Fora (almoço) para o final da Fila Geral."""
    seller_id: str
    queue_id: Optional[str] = None


class AttendanceCancelRequest(BaseModel):
    reason: str


# ===== Registro Rápido (Etapa 6) =====
class QuickAttendanceRequest(BaseModel):
    seller_id: str
    result: Literal["SALE", "NO_SALE", "FOLLOW_UP", "INVALID"]
    customer_name: Optional[str] = None
    customer_phone: Optional[str] = None
    sale_amount_cents: Optional[int] = None
    sale: Optional[SaleInput] = None
    loss_reason_id: Optional[str] = None
    grupo_motivo_perda_id: Optional[str] = None
    subgrupo_motivo_perda_id: Optional[str] = None
    motivo_perda_id: Optional[str] = None
    descricao_complementar: Optional[str] = None
    notes: Optional[str] = None
    product_quantity: Optional[int] = None



# ===== Convites (Prompt 1 — Fundação) =====
InviteType = Literal["TENANT_OWNER", "TENANT_USER"]


class InviteCreate(BaseModel):
    """Payload para criar um convite de usuário dentro de um tenant.

    Regras de store_ids por role:
    - TENANT_ADMIN       : store_ids e all_stores ignorados (admin acessa tudo).
    - REGIONAL_MANAGER   : all_stores=True → store_ids=[]; all_stores=False → store_ids ≥ 1.
    - STORE_MANAGER      : store_ids obrigatório (≥ 1), all_stores ignorado.
    - SUPERVISOR         : store_ids obrigatório (≥ 1), all_stores ignorado.
    - SELLER             : store_ids deve ter exatamente 1 item.
    """
    email: EmailStr
    role: Role
    store_ids: List[str] = Field(default_factory=list)
    all_stores: bool = False

    @model_validator(mode="after")
    def validar_store_ids_por_role(self) -> "InviteCreate":
        role = self.role
        store_ids = self.store_ids or []
        all_stores = self.all_stores

        if role == "TENANT_ADMIN":
            # Admin ignora store_ids — normaliza para lista vazia
            self.store_ids = []
            self.all_stores = False
            return self

        if role == "REGIONAL_MANAGER":
            if all_stores:
                # all_stores=True → lista vazia representa "todas as filiais"
                self.store_ids = []
            else:
                if not store_ids:
                    raise ValueError(
                        "REGIONAL_MANAGER com all_stores=False exige pelo menos 1 store_id."
                    )
            return self

        if role in ("STORE_MANAGER", "SUPERVISOR"):
            if not store_ids:
                raise ValueError(
                    f"{role} exige pelo menos 1 store_id (esse cargo não tem acesso global)."
                )
            return self

        if role == "SELLER":
            if len(store_ids) != 1:
                raise ValueError(
                    "SELLER deve pertencer a exatamente 1 loja (store_ids deve ter 1 item)."
                )
            return self

        return self


class InviteAccept(BaseModel):
    """Payload para aceitar um convite e definir senha/nome."""
    name: str
    password: str



# ===== Achievements =====
ACHIEVEMENT_METRICS = {"REVENUE", "CONVERSION", "AVERAGE_TICKET", "SALES_COUNT", "ATTENDANCE_COUNT", "ITEMS_SOLD"}
ACHIEVEMENT_OPERATORS = {"GT", "GTE", "LT", "LTE", "EQ"}
ACHIEVEMENT_STATUSES = {"DRAFT", "ACTIVE", "PAUSED", "ARCHIVED"}
ACHIEVEMENT_SCOPES = {"TENANT", "STORE", "TEAM", "SELLER"}
ACHIEVEMENT_RECURRENCES = {"ONCE", "DAILY", "WEEKLY", "MONTHLY", "ALWAYS"}
ACHIEVEMENT_VISIBILITIES = {"PUBLIC", "MANAGERS_ONLY", "PARTICIPANTS_ONLY", "SECRET"}
ACHIEVEMENT_APPROVAL_MODES = {"AUTOMATIC", "MANUAL", "REQUIRES_APPROVAL"}
ACHIEVEMENT_DIFFICULTIES = {"EASY", "MEDIUM", "HARD", "LEGENDARY"}


class AchievementCreate(BaseModel):
    name: str
    description: Optional[str] = None
    category: Optional[str] = None
    icon: str = "award"
    points: int = 50
    difficulty: Optional[str] = "MEDIUM"
    visibility: str = "PUBLIC"
    scope: str = "SELLER"
    period_type: Optional[str] = None      # DAILY | WEEKLY | MONTHLY | CUSTOM | None
    period_start: Optional[str] = None
    period_end: Optional[str] = None
    recurrence: str = "ONCE"
    approval_mode: str = "AUTOMATIC"
    reward: Optional[str] = None
    # Regra inline (uma por conquista no MVP)
    rule_metric: Optional[str] = None
    rule_operator: Optional[str] = None
    rule_target_value: Optional[int] = None


class AchievementUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    category: Optional[str] = None
    icon: Optional[str] = None
    points: Optional[int] = None
    difficulty: Optional[str] = None
    visibility: Optional[str] = None
    scope: Optional[str] = None
    period_type: Optional[str] = None
    period_start: Optional[str] = None
    period_end: Optional[str] = None
    recurrence: Optional[str] = None
    approval_mode: Optional[str] = None
    reward: Optional[str] = None
    rule_metric: Optional[str] = None
    rule_operator: Optional[str] = None
    rule_target_value: Optional[int] = None


class AchievementStatusUpdate(BaseModel):
    status: Literal["DRAFT", "ACTIVE", "PAUSED", "ARCHIVED"]


class AchievementGrantPayload(BaseModel):
    seller_id: str      # seller_profile_id
    reason: Optional[str] = None
    override_points: Optional[int] = None


class AchievementRequestCreate(BaseModel):
    achievement_id: str
    reason: Optional[str] = None


class AchievementRequestReview(BaseModel):
    review_note: Optional[str] = None
