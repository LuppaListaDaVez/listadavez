"""Backend tests for Etapa 11 — Módulo de Abordagem Proativa."""
import pytest
import requests
import os

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")

ADMIN_EMAIL = "admin@demo.com"
ADMIN_PASS = "Admin@123456"
SELLER_EMAIL = "joao@demo.com"
SELLER_PASS = "Admin@123456"
SELLER2_EMAIL = "maria@demo.com"
SELLER2_PASS = "Admin@123456"
TENANT_SLUG = "demo"

# ── Fixtures ─────────────────────────────────────────────────────────────────

@pytest.fixture(scope="module")
def admin_token():
    """Login como admin@demo.com e retorna token."""
    res = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT_SLUG}/auth/login",
        json={"email": ADMIN_EMAIL, "password": ADMIN_PASS},
    )
    assert res.status_code == 200, f"Admin login failed: {res.text}"
    return res.json().get("access_token")


@pytest.fixture(scope="module")
def seller_token():
    """Login como joao@demo.com (SELLER) e retorna token."""
    res = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT_SLUG}/auth/login",
        json={"email": SELLER_EMAIL, "password": SELLER_PASS},
    )
    assert res.status_code == 200, f"Seller login failed: {res.text}"
    return res.json().get("access_token")


@pytest.fixture(scope="module")
def seller2_token():
    """Login como maria@demo.com (SELLER) e retorna token."""
    res = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT_SLUG}/auth/login",
        json={"email": SELLER2_EMAIL, "password": SELLER2_PASS},
    )
    assert res.status_code == 200, f"Seller2 login failed: {res.text}"
    return res.json().get("access_token")


@pytest.fixture(scope="module")
def admin_headers(admin_token):
    return {"Authorization": f"Bearer {admin_token}", "Content-Type": "application/json"}


@pytest.fixture(scope="module")
def seller_headers(seller_token):
    return {"Authorization": f"Bearer {seller_token}", "Content-Type": "application/json"}


@pytest.fixture(scope="module")
def seller2_headers(seller2_token):
    return {"Authorization": f"Bearer {seller2_token}", "Content-Type": "application/json"}


@pytest.fixture(scope="module")
def store_id(admin_headers):
    """Obter o primeiro store do tenant demo."""
    res = requests.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores", headers=admin_headers)
    assert res.status_code == 200
    stores = res.json()
    assert len(stores) > 0, "No stores found in tenant demo"
    return stores[0]["id"]


@pytest.fixture(scope="module")
def seller_profile_id(admin_headers, store_id):
    """Obter o seller_id de um vendedor da primeira loja."""
    res = requests.get(
        f"{BASE_URL}/api/tenants/{TENANT_SLUG}/sellers?store_id={store_id}",
        headers=admin_headers,
    )
    assert res.status_code == 200
    sellers = res.json()
    assert len(sellers) > 0, "No sellers found in store"
    return sellers[0]["id"]


# ── Tests: Feature Flag ───────────────────────────────────────────────────────

class TestFeatureFlag:
    """Verificar se feature abordagem_proativa está ativa no tenant demo."""
    
    def test_feature_active_via_approaches_list(self, admin_headers):
        """GET /proactive-approaches deve funcionar (feature ativa)."""
        res = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/proactive-approaches",
            headers=admin_headers,
        )
        # 200 = feature ativa; 403/404 poderia indicar feature inativa
        assert res.status_code == 200, f"Feature may be inactive or error: {res.text}"
        print(f"PASS: Feature abordagem_proativa está ativa - {len(res.json())} approaches found")


# ── Tests: List Approaches ────────────────────────────────────────────────────

class TestListApproaches:
    """GET /api/tenants/demo/proactive-approaches."""

    def test_admin_can_list_approaches(self, admin_headers):
        """Admin pode listar todas as abordagens."""
        res = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/proactive-approaches",
            headers=admin_headers,
        )
        assert res.status_code == 200
        data = res.json()
        assert isinstance(data, list)
        print(f"PASS: Admin list approaches = {len(data)} items")

    def test_list_approaches_has_enriched_fields(self, admin_headers):
        """Abordagens listadas devem ter seller_name e store_name."""
        res = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/proactive-approaches",
            headers=admin_headers,
        )
        assert res.status_code == 200
        data = res.json()
        if len(data) > 0:
            first = data[0]
            assert "seller_name" in first, "Missing seller_name in response"
            assert "store_name" in first, "Missing store_name in response"
            assert "status" in first, "Missing status in response"
            print(f"PASS: Enriched fields present. seller_name={first.get('seller_name')}, store_name={first.get('store_name')}")
        else:
            print("SKIP: No approaches found to validate enriched fields")

    def test_seller_can_list_own_approaches(self, seller_headers):
        """Vendedor pode listar abordagens (verá apenas as suas)."""
        res = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/proactive-approaches",
            headers=seller_headers,
        )
        assert res.status_code == 200
        data = res.json()
        assert isinstance(data, list)
        print(f"PASS: Seller list approaches = {len(data)} items")

    def test_list_with_status_filter(self, admin_headers):
        """Filtro por status OPEN deve funcionar."""
        res = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/proactive-approaches?status=OPEN",
            headers=admin_headers,
        )
        assert res.status_code == 200
        data = res.json()
        for item in data:
            assert item["status"] == "OPEN", f"Expected OPEN, got {item['status']}"
        print(f"PASS: Status filter OPEN = {len(data)} items, all OPEN")


# ── Tests: Create Approach ────────────────────────────────────────────────────

class TestCreateApproach:
    """POST /api/tenants/demo/proactive-approaches."""

    def test_admin_create_approach(self, admin_headers, store_id, seller_profile_id):
        """Admin pode criar abordagem com status OPEN (deve especificar seller_id)."""
        payload = {
            "store_id": store_id,
            "seller_id": seller_profile_id,
            "customer_name": "TEST_Cliente Admin",
            "source": "STORE_FLOOR",
            "approach_type": "ACTIVE_APPROACH",
            "notes": "TEST abordagem criada por admin",
        }
        res = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/proactive-approaches",
            json=payload,
            headers=admin_headers,
        )
        assert res.status_code == 200, f"Create failed: {res.text}"
        data = res.json()
        assert data["status"] == "OPEN", f"Expected OPEN, got {data.get('status')}"
        assert data["store_id"] == store_id
        assert data["customer_name"] == "TEST_Cliente Admin"
        print(f"PASS: Created approach id={data['id']}, status={data['status']}")
        # Store for cleanup
        TestCreateApproach._created_id_admin = data["id"]

    def test_seller_create_approach(self, seller_headers, store_id):
        """Vendedor pode criar sua própria abordagem."""
        payload = {
            "store_id": store_id,
            "customer_name": "TEST_Cliente Seller",
            "source": "WHATSAPP",
            "approach_type": "CUSTOMER_REENGAGEMENT",
            "notes": "TEST abordagem criada por vendedor",
        }
        res = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/proactive-approaches",
            json=payload,
            headers=seller_headers,
        )
        assert res.status_code == 200, f"Seller create failed: {res.text}"
        data = res.json()
        assert data["status"] == "OPEN"
        assert data["customer_name"] == "TEST_Cliente Seller"
        print(f"PASS: Seller created approach id={data['id']}")
        TestCreateApproach._created_id_seller = data["id"]

    def test_create_approach_without_store_fails(self, admin_headers):
        """Criar abordagem sem store_id deve retornar 400."""
        res = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/proactive-approaches",
            json={"customer_name": "Test"},
            headers=admin_headers,
        )
        assert res.status_code in (400, 422), f"Expected 400/422, got {res.status_code}"
        print(f"PASS: Missing store_id returns {res.status_code}")

    def test_create_approach_unauthenticated_fails(self):
        """Criar abordagem sem token deve falhar."""
        res = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/proactive-approaches",
            json={"store_id": "any"},
        )
        assert res.status_code in (401, 403), f"Expected 401/403, got {res.status_code}"
        print(f"PASS: Unauthenticated create returns {res.status_code}")


# ── Tests: Get Approach Detail ────────────────────────────────────────────────

class TestGetApproach:
    """GET /api/tenants/demo/proactive-approaches/:id."""

    def test_admin_get_first_approach(self, admin_headers):
        """Admin pode buscar detalhes de qualquer abordagem."""
        list_res = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/proactive-approaches",
            headers=admin_headers,
        )
        assert list_res.status_code == 200
        items = list_res.json()
        if not items:
            pytest.skip("No approaches to test detail view")
        
        approach_id = items[0]["id"]
        res = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/proactive-approaches/{approach_id}",
            headers=admin_headers,
        )
        assert res.status_code == 200, f"Get detail failed: {res.text}"
        data = res.json()
        assert data["id"] == approach_id
        assert "seller_name" in data, "Missing seller_name"
        assert "store_name" in data, "Missing store_name"
        print(f"PASS: Get approach detail id={approach_id}, seller={data.get('seller_name')}, store={data.get('store_name')}")

    def test_get_nonexistent_approach_returns_404(self, admin_headers):
        """Abordagem inexistente retorna 404."""
        res = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/proactive-approaches/nonexistent-id-xxx",
            headers=admin_headers,
        )
        assert res.status_code == 404, f"Expected 404, got {res.status_code}"
        print("PASS: 404 for nonexistent approach")


# ── Tests: Convert to Sale ────────────────────────────────────────────────────

class TestConvertToSale:
    """POST /api/tenants/demo/proactive-approaches/:id/convert-to-sale."""

    def test_admin_convert_open_approach_to_sale(self, admin_headers, store_id, seller_profile_id):
        """Admin pode converter abordagem aberta em venda."""
        # First create an approach
        payload = {
            "store_id": store_id,
            "seller_id": seller_profile_id,
            "customer_name": "TEST_Sale Convert Customer",
            "source": "REFERRAL",
            "approach_type": "ACTIVE_APPROACH",
        }
        create_res = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/proactive-approaches",
            json=payload,
            headers=admin_headers,
        )
        assert create_res.status_code == 200
        approach_id = create_res.json()["id"]

        # Convert to sale
        sale_payload = {
            "gross_amount_cents": 19990,
            "discount_amount_cents": 0,
            "net_amount_cents": 19990,
            "payment_method": "CREDIT_CARD",
            "notes": "Venda de teste",
            "items": [],
        }
        res = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/proactive-approaches/{approach_id}/convert-to-sale",
            json=sale_payload,
            headers=admin_headers,
        )
        assert res.status_code == 200, f"Convert to sale failed: {res.text}"
        data = res.json()
        assert data["status"] == "CONVERTED_TO_SALE"
        assert data["result"] == "SALE"
        assert data.get("linked_sale_id") is not None
        assert data.get("sale") is not None
        sale = data["sale"]
        assert sale["net_amount_cents"] == 19990
        print(f"PASS: Converted to sale. approach status={data['status']}, sale_id={data['linked_sale_id']}")

    def test_cannot_convert_closed_approach(self, admin_headers, store_id, seller_profile_id):
        """Não é possível converter uma abordagem já fechada."""
        # Create and close an approach
        create_res = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/proactive-approaches",
            json={"store_id": store_id, "seller_id": seller_profile_id, "customer_name": "TEST_ClosedSale"},
            headers=admin_headers,
        )
        assert create_res.status_code == 200
        approach_id = create_res.json()["id"]

        # Cancel first
        requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/proactive-approaches/{approach_id}/cancel",
            json={"reason": "test"},
            headers=admin_headers,
        )

        # Try to convert to sale — should fail
        res = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/proactive-approaches/{approach_id}/convert-to-sale",
            json={"gross_amount_cents": 100},
            headers=admin_headers,
        )
        assert res.status_code == 400, f"Expected 400, got {res.status_code}: {res.text}"
        print("PASS: Cannot convert cancelled approach to sale")


# ── Tests: Proactivity Summary ────────────────────────────────────────────────

class TestProactivitySummary:
    """GET /api/tenants/demo/proactivity/summary."""

    def test_admin_get_summary(self, admin_headers):
        """Admin pode obter KPIs de proatividade."""
        res = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/proactivity/summary",
            headers=admin_headers,
        )
        assert res.status_code == 200, f"Summary failed: {res.text}"
        data = res.json()
        assert "total_approaches" in data
        assert "open" in data
        assert "converted_to_sale" in data
        assert "proactive_revenue_cents" in data
        assert "conversion_to_sale_pct" in data
        assert "by_seller" in data
        print(f"PASS: Summary - total={data['total_approaches']}, open={data['open']}, sales={data['converted_to_sale']}, revenue={data['proactive_revenue_cents']}")

    def test_summary_total_is_numeric(self, admin_headers):
        """KPIs numéricos devem ser inteiros."""
        res = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/proactivity/summary",
            headers=admin_headers,
        )
        assert res.status_code == 200
        data = res.json()
        assert isinstance(data["total_approaches"], int)
        assert isinstance(data["open"], int)
        assert isinstance(data["converted_to_sale"], int)
        assert isinstance(data["proactive_revenue_cents"], int)
        print(f"PASS: All numeric KPIs are integers")

    def test_seller_gets_own_summary(self, seller_headers):
        """Vendedor obtém KPIs apenas das suas abordagens."""
        res = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/proactivity/summary",
            headers=seller_headers,
        )
        assert res.status_code == 200
        data = res.json()
        assert "total_approaches" in data
        print(f"PASS: Seller summary total_approaches={data['total_approaches']}")


# ── Tests: My Proactive Approaches ───────────────────────────────────────────

class TestMyApproaches:
    """GET /api/tenants/demo/my-proactive-approaches."""

    def test_seller_list_own_approaches(self, seller_headers):
        """Vendedor lista suas próprias abordagens."""
        res = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/my-proactive-approaches",
            headers=seller_headers,
        )
        assert res.status_code == 200, f"My approaches failed: {res.text}"
        data = res.json()
        assert isinstance(data, list)
        print(f"PASS: Seller my-approaches = {len(data)} items")

    def test_sellers_see_only_own_approaches(self, seller_headers, seller2_headers):
        """Dois vendedores diferentes não vêem abordagens um do outro."""
        res1 = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/my-proactive-approaches",
            headers=seller_headers,
        )
        res2 = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/my-proactive-approaches",
            headers=seller2_headers,
        )
        assert res1.status_code == 200
        assert res2.status_code == 200
        
        ids1 = {a["id"] for a in res1.json()}
        ids2 = {a["id"] for a in res2.json()}
        overlap = ids1 & ids2
        assert len(overlap) == 0, f"Sellers share approach IDs (data isolation issue): {overlap}"
        print(f"PASS: No overlap between seller1 ({len(ids1)} approaches) and seller2 ({len(ids2)} approaches)")


# ── Tests: Proactivity Report ─────────────────────────────────────────────────

class TestProactivityReport:
    """GET /api/tenants/demo/reports/proactivity."""

    def test_admin_get_proactivity_report(self, admin_headers):
        """Admin pode ver relatório de proatividade completo."""
        res = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/reports/proactivity",
            headers=admin_headers,
        )
        assert res.status_code == 200, f"Report failed: {res.text}"
        data = res.json()
        assert "total_approaches" in data
        assert "by_seller" in data
        assert "conversion_to_sale_pct" in data
        assert "proactive_revenue_cents" in data
        print(f"PASS: Proactivity report total={data['total_approaches']}, by_seller={len(data['by_seller'])} entries")

    def test_report_by_seller_is_list(self, admin_headers):
        """by_seller no relatório deve ser uma lista."""
        res = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/reports/proactivity",
            headers=admin_headers,
        )
        assert res.status_code == 200
        data = res.json()
        assert isinstance(data["by_seller"], list), "by_seller should be a list"
        if len(data["by_seller"]) > 0:
            first_seller = data["by_seller"][0]
            assert "seller_id" in first_seller
            assert "seller_name" in first_seller
            assert "total_approaches" in first_seller
            assert "sales" in first_seller
            assert "conversion_pct" in first_seller
            print(f"PASS: by_seller[0] = {first_seller}")
        else:
            print("PASS: by_seller is empty list (OK if no data)")

    def test_report_with_date_filter(self, admin_headers):
        """Relatório com filtro de data deve funcionar."""
        res = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/reports/proactivity?date_start=2025-01-01&date_end=2026-12-31",
            headers=admin_headers,
        )
        assert res.status_code == 200, f"Report with date filter failed: {res.text}"
        data = res.json()
        assert "total_approaches" in data
        print(f"PASS: Report with date filter total={data['total_approaches']}")


# ── Tests: Cancel Approach ────────────────────────────────────────────────────

class TestCancelApproach:
    """POST /api/tenants/demo/proactive-approaches/:id/cancel."""

    def test_admin_cancel_open_approach(self, admin_headers, store_id, seller_profile_id):
        """Admin pode cancelar abordagem aberta."""
        create_res = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/proactive-approaches",
            json={"store_id": store_id, "seller_id": seller_profile_id, "customer_name": "TEST_CancelMe"},
            headers=admin_headers,
        )
        assert create_res.status_code == 200
        approach_id = create_res.json()["id"]

        res = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/proactive-approaches/{approach_id}/cancel",
            json={"reason": "Teste de cancelamento"},
            headers=admin_headers,
        )
        assert res.status_code == 200, f"Cancel failed: {res.text}"
        data = res.json()
        assert data["status"] == "CANCELLED"
        print(f"PASS: Approach cancelled, status={data['status']}")


# ── Tests: Close No Sale ──────────────────────────────────────────────────────

class TestCloseNoSale:
    """POST /api/tenants/demo/proactive-approaches/:id/close-no-sale."""

    def test_admin_close_no_sale(self, admin_headers, store_id, seller_profile_id):
        """Admin pode encerrar abordagem sem venda."""
        create_res = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/proactive-approaches",
            json={"store_id": store_id, "seller_id": seller_profile_id, "customer_name": "TEST_NoSaleMe"},
            headers=admin_headers,
        )
        assert create_res.status_code == 200
        approach_id = create_res.json()["id"]

        res = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/proactive-approaches/{approach_id}/close-no-sale",
            json={"notes": "Cliente não tinha interesse"},
            headers=admin_headers,
        )
        assert res.status_code == 200, f"Close no-sale failed: {res.text}"
        data = res.json()
        assert data["status"] == "NO_SALE"
        assert data["result"] == "NO_SALE"
        print(f"PASS: Approach closed no-sale, status={data['status']}")


# ── Tests: Seller Isolation ───────────────────────────────────────────────────

class TestSellerIsolation:
    """Verificar que vendedor não vê abordagens de outro vendedor."""

    def test_seller_proactive_list_isolated(self, seller_headers, seller2_headers):
        """Duas listas de sellers diferentes devem ser disjuntas."""
        res1 = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/proactive-approaches",
            headers=seller_headers,
        )
        res2 = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/proactive-approaches",
            headers=seller2_headers,
        )
        assert res1.status_code == 200
        assert res2.status_code == 200
        
        ids1 = {a["id"] for a in res1.json()}
        ids2 = {a["id"] for a in res2.json()}
        overlap = ids1 & ids2
        assert len(overlap) == 0, f"Sellers share approach IDs! {overlap}"
        print(f"PASS: Seller isolation confirmed - seller1={len(ids1)}, seller2={len(ids2)}, overlap={len(overlap)}")


# ── Tests: Convert to Attendance ─────────────────────────────────────────────

class TestConvertToAttendance:
    """POST /api/tenants/demo/proactive-approaches/:id/convert-to-attendance."""

    def test_admin_convert_to_attendance(self, admin_headers, store_id, seller_profile_id):
        """Admin pode converter abordagem em atendimento."""
        create_res = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/proactive-approaches",
            json={"store_id": store_id, "seller_id": seller_profile_id, "customer_name": "TEST_ConvertAtt"},
            headers=admin_headers,
        )
        assert create_res.status_code == 200
        approach_id = create_res.json()["id"]

        res = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/proactive-approaches/{approach_id}/convert-to-attendance",
            json={"customer_name": "TEST_ConvertAtt"},
            headers=admin_headers,
        )
        assert res.status_code == 200, f"Convert to attendance failed: {res.text}"
        data = res.json()
        assert data["status"] == "CONVERTED_TO_ATTENDANCE"
        assert data.get("linked_attendance_id") is not None
        print(f"PASS: Converted to attendance. attendance_id={data['linked_attendance_id']}")
