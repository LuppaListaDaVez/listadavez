"""conftest.py — Configuração global da suite P2.5
Garante que credenciais de teste não estejam bloqueadas por rate limit antes
de iniciar os testes (útil em ambientes de CI onde os testes rodam frequentemente).
"""
import os
import pytest


def pytest_configure(config):
    """Limpa chaves de rate limit para credenciais de teste reais antes da suíte P2.5."""
    try:
        import redis
        redis_url = os.environ.get("REDIS_URL", "redis://127.0.0.1:6379/0")
        r = redis.from_url(redis_url, decode_responses=True, socket_connect_timeout=2)
        r.ping()

        # IPs conhecidos do ambiente de CI/preview
        test_ips = ["34.7.135.173", "127.0.0.1", "::1"]
        # Credenciais que devem ser desbloqueadas antes dos testes
        test_creds = [
            ("admin@demo.com", "demo"),
            ("admin@demo-b.com", "demo-b"),
            ("joao@demo.com", "demo"),
            ("admin@listadavez.com", "SUPER"),
            ("maria@demo.com", "demo"),
        ]

        cleared = 0
        for ip in test_ips:
            for email, tenant in test_creds:
                key = f"rl:AUTH_LOGIN:{ip}:{email}:{tenant}"
                if r.delete(key):
                    cleared += 1
            # Super admin key (diferente formato)
            super_key = f"rl:SUPER_ADMIN_LOGIN:{ip}"
            if r.delete(super_key):
                cleared += 1
            # Prompt 2: limpar rate limit de criação de convites
            invite_key = f"rl:INVITE_SEND:{ip}"
            if r.delete(invite_key):
                cleared += 1

        if cleared:
            print(f"\n[conftest] Rate limit pré-limpeza: {cleared} chaves removidas para testes clean.")

    except Exception:
        # Redis não disponível ou erro — continuar sem limpeza
        pass
