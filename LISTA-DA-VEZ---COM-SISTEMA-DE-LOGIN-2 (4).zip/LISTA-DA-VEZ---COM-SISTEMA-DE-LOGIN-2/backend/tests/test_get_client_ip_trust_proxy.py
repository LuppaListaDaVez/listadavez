"""
Unit tests for get_client_ip() — TRUST_PROXY_HEADERS security fix
===================================================================
Verifica:
1. TRUST_PROXY_HEADERS=false (padrão): get_client_ip() retorna request.client.host,
   IGNORANDO X-Forwarded-For e X-Real-IP.
2. TRUST_PROXY_HEADERS=true: get_client_ip() usa X-Real-IP → X-Forwarded-For → client.host.
3. Que _TRUST_PROXY_HEADERS não está definido em .env (padrão false será usado).
4. Que as demais funções do módulo (make_rate_limit_dep, check_rate_limit, etc.) não foram
   alteradas.

Estratégia: importa rate_limit_service e faz monkey-patch em _TRUST_PROXY_HEADERS
para testar ambos os comportamentos sem reinicializar o módulo.
"""
import os
import sys
import pytest
from unittest.mock import MagicMock, patch

# Garante que o backend está no sys.path
BACKEND_DIR = os.path.join(os.path.dirname(__file__), "..")
if BACKEND_DIR not in sys.path:
    sys.path.insert(0, BACKEND_DIR)

import rate_limit_service


# ── Helpers ───────────────────────────────────────────────────────────────────

def make_request(client_host: str, x_real_ip: str = None, x_forwarded_for: str = None):
    """Cria um mock de FastAPI Request com os atributos necessários."""
    request = MagicMock()
    request.client = MagicMock()
    request.client.host = client_host

    # Simula headers como dict-like
    headers = {}
    if x_real_ip is not None:
        headers["X-Real-IP"] = x_real_ip
    if x_forwarded_for is not None:
        headers["X-Forwarded-For"] = x_forwarded_for

    def get_header(key, default=None):
        return headers.get(key, default)

    request.headers.get = get_header
    return request


# ── Testes: TRUST_PROXY_HEADERS = false (padrão) ─────────────────────────────

class TestGetClientIpTrustProxyFalse:
    """Quando TRUST_PROXY_HEADERS=false, get_client_ip() deve ignorar headers de proxy."""

    def test_returns_client_host_without_proxy_headers(self):
        """Sem headers de proxy, deve retornar request.client.host."""
        req = make_request("192.168.1.1")
        with patch.object(rate_limit_service, "_TRUST_PROXY_HEADERS", False):
            ip = rate_limit_service.get_client_ip(req)
        assert ip == "192.168.1.1", f"Esperado '192.168.1.1', recebeu '{ip}'"
        print("PASS: retorna client.host corretamente")

    def test_ignores_x_real_ip_header(self):
        """Deve IGNORAR X-Real-IP e retornar request.client.host."""
        req = make_request("10.0.0.1", x_real_ip="203.0.113.42")
        with patch.object(rate_limit_service, "_TRUST_PROXY_HEADERS", False):
            ip = rate_limit_service.get_client_ip(req)
        assert ip == "10.0.0.1", (
            f"BYPASS de rate limit! X-Real-IP não deveria ser usado. Retornou '{ip}'"
        )
        print("PASS: X-Real-IP ignorado corretamente")

    def test_ignores_x_forwarded_for_header(self):
        """Deve IGNORAR X-Forwarded-For e retornar request.client.host."""
        req = make_request("10.0.0.2", x_forwarded_for="1.2.3.4, 5.6.7.8")
        with patch.object(rate_limit_service, "_TRUST_PROXY_HEADERS", False):
            ip = rate_limit_service.get_client_ip(req)
        assert ip == "10.0.0.2", (
            f"BYPASS de rate limit! X-Forwarded-For não deveria ser usado. Retornou '{ip}'"
        )
        print("PASS: X-Forwarded-For ignorado corretamente")

    def test_ignores_both_proxy_headers_simultaneously(self):
        """Deve IGNORAR X-Real-IP E X-Forwarded-For simultaneamente."""
        req = make_request("172.16.0.1", x_real_ip="9.9.9.9", x_forwarded_for="8.8.8.8")
        with patch.object(rate_limit_service, "_TRUST_PROXY_HEADERS", False):
            ip = rate_limit_service.get_client_ip(req)
        assert ip == "172.16.0.1", (
            f"Ambos os headers proxy ignorados. Retornou '{ip}', esperado '172.16.0.1'"
        )
        print("PASS: Ambos os proxy headers ignorados")

    def test_returns_unknown_when_client_is_none(self):
        """Quando request.client é None, retorna 'unknown'."""
        req = MagicMock()
        req.client = None
        req.headers.get = lambda key, default=None: None
        with patch.object(rate_limit_service, "_TRUST_PROXY_HEADERS", False):
            ip = rate_limit_service.get_client_ip(req)
        assert ip == "unknown", f"Esperado 'unknown', recebeu '{ip}'"
        print("PASS: retorna 'unknown' quando client é None")

    def test_returns_unknown_when_client_host_is_empty(self):
        """Quando client.host é string vazia, retorna 'unknown'."""
        req = make_request("")
        with patch.object(rate_limit_service, "_TRUST_PROXY_HEADERS", False):
            ip = rate_limit_service.get_client_ip(req)
        assert ip == "unknown", f"Esperado 'unknown', recebeu '{ip}'"
        print("PASS: retorna 'unknown' quando host é string vazia")


# ── Testes: TRUST_PROXY_HEADERS = true ───────────────────────────────────────

class TestGetClientIpTrustProxyTrue:
    """Quando TRUST_PROXY_HEADERS=true, get_client_ip() deve usar X-Real-IP → X-Forwarded-For → client.host."""

    def test_uses_x_real_ip_when_present(self):
        """X-Real-IP deve ser retornado quando presente."""
        req = make_request("10.0.0.1", x_real_ip="203.0.113.42")
        with patch.object(rate_limit_service, "_TRUST_PROXY_HEADERS", True):
            ip = rate_limit_service.get_client_ip(req)
        assert ip == "203.0.113.42", f"Esperado X-Real-IP '203.0.113.42', recebeu '{ip}'"
        print("PASS: X-Real-IP usado corretamente")

    def test_uses_x_forwarded_for_first_ip_when_x_real_ip_absent(self):
        """X-Forwarded-For (primeiro IP) usado quando X-Real-IP ausente."""
        req = make_request("10.0.0.2", x_forwarded_for="1.2.3.4, 5.6.7.8, 9.9.9.9")
        with patch.object(rate_limit_service, "_TRUST_PROXY_HEADERS", True):
            ip = rate_limit_service.get_client_ip(req)
        assert ip == "1.2.3.4", (
            f"Esperado primeiro IP de X-Forwarded-For '1.2.3.4', recebeu '{ip}'"
        )
        print("PASS: X-Forwarded-For (primeiro IP) usado corretamente")

    def test_x_real_ip_takes_priority_over_x_forwarded_for(self):
        """X-Real-IP tem prioridade sobre X-Forwarded-For."""
        req = make_request("10.0.0.3", x_real_ip="203.0.113.1", x_forwarded_for="1.2.3.4")
        with patch.object(rate_limit_service, "_TRUST_PROXY_HEADERS", True):
            ip = rate_limit_service.get_client_ip(req)
        assert ip == "203.0.113.1", (
            f"X-Real-IP deve ter prioridade. Recebeu '{ip}'"
        )
        print("PASS: X-Real-IP tem prioridade sobre X-Forwarded-For")

    def test_falls_back_to_client_host_when_no_proxy_headers(self):
        """Fallback para client.host quando nenhum header de proxy presente."""
        req = make_request("192.0.2.1")
        with patch.object(rate_limit_service, "_TRUST_PROXY_HEADERS", True):
            ip = rate_limit_service.get_client_ip(req)
        assert ip == "192.0.2.1", f"Fallback para client.host falhou. Recebeu '{ip}'"
        print("PASS: fallback para client.host funciona")

    def test_returns_unknown_when_all_sources_empty(self):
        """Retorna 'unknown' quando todos os sources são vazios/None."""
        req = MagicMock()
        req.client = None
        req.headers.get = lambda key, default=None: default
        with patch.object(rate_limit_service, "_TRUST_PROXY_HEADERS", True):
            ip = rate_limit_service.get_client_ip(req)
        assert ip == "unknown", f"Esperado 'unknown', recebeu '{ip}'"
        print("PASS: retorna 'unknown' quando tudo vazio")

    def test_x_forwarded_for_with_spaces_trimmed(self):
        """Primeiro IP de X-Forwarded-For deve ter espaços removidos."""
        req = make_request("10.0.0.1", x_forwarded_for="  203.0.113.99 , 5.5.5.5")
        with patch.object(rate_limit_service, "_TRUST_PROXY_HEADERS", True):
            ip = rate_limit_service.get_client_ip(req)
        assert ip == "203.0.113.99", f"IP com espaços não foi trimado. Recebeu '{ip}'"
        print("PASS: espaços em X-Forwarded-For são removidos")


# ── Testes: Variável de ambiente ──────────────────────────────────────────────

class TestTrustProxyHeadersEnvVar:
    """Verifica comportamento do _TRUST_PROXY_HEADERS no ambiente atual."""

    def test_trust_proxy_headers_not_set_in_env_defaults_to_false(self):
        """TRUST_PROXY_HEADERS não está no .env → _TRUST_PROXY_HEADERS deve ser False (padrão)."""
        env_value = os.environ.get("TRUST_PROXY_HEADERS", "NOT_SET")
        print(f"INFO: TRUST_PROXY_HEADERS env var = '{env_value}'")
        if env_value == "NOT_SET":
            print("PASS: TRUST_PROXY_HEADERS não configurado no ambiente (padrão false)")
        else:
            # Se estiver configurado, verificar que o valor é 'false'
            assert env_value.lower() != "true", (
                f"TRUST_PROXY_HEADERS={env_value} — esperado ausente ou 'false' no ambiente de produção"
            )

    def test_module_trust_proxy_default_is_false(self):
        """O valor real de _TRUST_PROXY_HEADERS no módulo deve ser False (sem TRUST_PROXY_HEADERS no .env)."""
        # Verifica o valor lido na inicialização do módulo
        assert rate_limit_service._TRUST_PROXY_HEADERS is False, (
            f"_TRUST_PROXY_HEADERS = {rate_limit_service._TRUST_PROXY_HEADERS}. "
            "Esperado False (padrão seguro) quando TRUST_PROXY_HEADERS não está no .env"
        )
        print(f"PASS: _TRUST_PROXY_HEADERS = {rate_limit_service._TRUST_PROXY_HEADERS} (False por padrão)")

    def test_env_false_produces_trust_proxy_false(self):
        """os.environ.get('TRUST_PROXY_HEADERS', 'false').lower() == 'true' → False para valores falsy."""
        for falsy in ["false", "False", "FALSE", "0", "", "no"]:
            result = falsy.strip().lower() == "true"
            assert result is False, f"Valor '{falsy}' deveria resultar em False, recebeu {result}"
        print("PASS: todos os valores falsy resultam em False")

    def test_env_true_produces_trust_proxy_true(self):
        """'true' (case-insensitive) deve resultar em True."""
        for truthy in ["true", "True", "TRUE"]:
            result = truthy.strip().lower() == "true"
            assert result is True, f"Valor '{truthy}' deveria resultar em True, recebeu {result}"
        print("PASS: 'true' case-insensitive resulta em True")


# ── Testes: Integridade das outras funções ────────────────────────────────────

class TestOtherFunctionsIntact:
    """Verifica que as outras funções de rate_limit_service não foram alteradas."""

    def test_make_rate_limit_dep_exists_and_callable(self):
        """make_rate_limit_dep() existe e retorna uma função callable."""
        assert hasattr(rate_limit_service, "make_rate_limit_dep"), "make_rate_limit_dep não encontrado"
        dep = rate_limit_service.make_rate_limit_dep("AUTH_LOGIN")
        assert callable(dep), "make_rate_limit_dep deve retornar um callable"
        import asyncio
        assert asyncio.iscoroutinefunction(dep), "Dependency deve ser async"
        print("PASS: make_rate_limit_dep intacta")

    def test_check_rate_limit_exists_and_is_coroutine(self):
        """check_rate_limit() existe e é uma coroutine."""
        import asyncio
        assert hasattr(rate_limit_service, "check_rate_limit"), "check_rate_limit não encontrado"
        assert asyncio.iscoroutinefunction(rate_limit_service.check_rate_limit), (
            "check_rate_limit deve ser async"
        )
        print("PASS: check_rate_limit intacta")

    def test_in_memory_rate_limiter_class_exists(self):
        """InMemoryRateLimiter existe e tem método check."""
        assert hasattr(rate_limit_service, "InMemoryRateLimiter"), "InMemoryRateLimiter não encontrado"
        limiter = rate_limit_service.InMemoryRateLimiter()
        import asyncio
        assert asyncio.iscoroutinefunction(limiter.check), "InMemoryRateLimiter.check deve ser async"
        print("PASS: InMemoryRateLimiter intacta")

    def test_redis_rate_limiter_class_exists(self):
        """RedisRateLimiter existe e tem método check."""
        assert hasattr(rate_limit_service, "RedisRateLimiter"), "RedisRateLimiter não encontrado"
        limiter = rate_limit_service.RedisRateLimiter("redis://localhost:6379")
        import asyncio
        assert asyncio.iscoroutinefunction(limiter.check), "RedisRateLimiter.check deve ser async"
        print("PASS: RedisRateLimiter intacta")

    def test_rate_limits_dict_has_required_groups(self):
        """RATE_LIMITS contém todos os grupos esperados."""
        required_groups = [
            "AUTH_LOGIN", "AUTH_REFRESH", "SUPER_ADMIN_LOGIN",
            "QUEUE_ACTIONS", "SALES_CREATE", "ATTENDANCE_START",
            "ATTENDANCE_FINISH", "ATTENDANCE_CANCEL", "REPORT_EXPORT",
            "NOTIFICATIONS", "GENERAL_API", "INVITE_SEND",
        ]
        for group in required_groups:
            assert group in rate_limit_service.RATE_LIMITS, (
                f"Grupo '{group}' não encontrado em RATE_LIMITS"
            )
        print(f"PASS: todos os {len(required_groups)} grupos de RATE_LIMITS presentes")

    def test_rate_limiter_singleton_exists(self):
        """rate_limiter singleton está instanciado."""
        assert hasattr(rate_limit_service, "rate_limiter"), "rate_limiter singleton não encontrado"
        limiter = rate_limit_service.rate_limiter
        assert limiter is not None
        print(f"PASS: rate_limiter singleton = {type(limiter).__name__}")

    def test_get_client_ip_is_defined(self):
        """get_client_ip() está definida e é callable (não async)."""
        import asyncio
        assert hasattr(rate_limit_service, "get_client_ip"), "get_client_ip não encontrado"
        assert callable(rate_limit_service.get_client_ip), "get_client_ip deve ser callable"
        assert not asyncio.iscoroutinefunction(rate_limit_service.get_client_ip), (
            "get_client_ip não deve ser async (é chamada em contexto síncrono na dependency)"
        )
        print("PASS: get_client_ip definida corretamente")


# ── Teste de regressão: check_rate_limit funcional ────────────────────────────

class TestCheckRateLimitFunctional:
    """Verifica que check_rate_limit() ainda funciona normalmente."""

    @pytest.mark.asyncio
    async def test_check_rate_limit_unknown_group_allows(self):
        """Grupo desconhecido → permite (retorna True)."""
        allowed, retry = await rate_limit_service.check_rate_limit("1.2.3.4", "UNKNOWN_GROUP_XYZ")
        assert allowed is True, "Grupo desconhecido deve ser permitido"
        assert retry is None
        print("PASS: grupo desconhecido → permitido")

    @pytest.mark.asyncio
    async def test_in_memory_rate_limiter_allows_first_requests(self):
        """InMemoryRateLimiter permite requests dentro do limite."""
        limiter = rate_limit_service.InMemoryRateLimiter()
        # AUTH_LOGIN: limite 50/900s — primeira tentativa deve ser permitida
        allowed, retry = await limiter.check("test_regression_ip_unique_99999", "AUTH_LOGIN")
        assert allowed is True, f"Primeira tentativa deve ser permitida. retry={retry}"
        assert retry is None
        print("PASS: primeira tentativa no InMemoryRateLimiter permitida")
