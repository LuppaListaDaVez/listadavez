"""Dashboard API tests — iteration 19"""
import pytest
import requests
import os

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")

# ── Helpers ──────────────────────────────────────────────────────────────────

def get_token(email, password, slug="demo"):
    r = requests.post(f"{BASE_URL}/api/tenants/{slug}/auth/login",
                      json={"email": email, "password": password})
    if r.status_code == 200:
        return r.json().get("access_token") or r.json().get("token")
    return None


def auth_headers(token):
    return {"Authorization": f"Bearer {token}"}


# ── Tests ─────────────────────────────────────────────────────────────────────

class TestDashboardSummary:
    """GET /api/tenants/demo/dashboard/summary"""

    def test_admin_no_params_returns_kpis(self):
        """Admin sem params → retorna kpis com todas as chaves esperadas"""
        token = get_token("admin@demo.com", "Admin@123456")
        assert token, "Login de admin falhou"

        r = requests.get(f"{BASE_URL}/api/tenants/demo/dashboard/summary",
                         headers=auth_headers(token))
        print(f"Status: {r.status_code} | Body: {r.text[:300]}")
        assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text}"

        data = r.json()
        assert "kpis" in data, "Missing kpis"
        kpis = data["kpis"]
        expected_keys = [
            "atendimentos_hoje", "em_andamento", "finalizados_hoje",
            "vendas_hoje", "total_vendido_cents", "ticket_medio_cents",
            "conversao_pct", "tempo_medio_segundos"
        ]
        for k in expected_keys:
            assert k in kpis, f"Missing kpi key: {k}"

        assert "week_trend" in data
        assert "sellers_status" in data
        print("PASS: admin no-params KPIs returned")

    def test_date_filter_30_days_returns_30_items_week_trend(self):
        """date_from/date_to com 30 dias → week_trend com 30 itens"""
        token = get_token("admin@demo.com", "Admin@123456")
        assert token

        r = requests.get(
            f"{BASE_URL}/api/tenants/demo/dashboard/summary",
            params={"date_from": "2026-06-01", "date_to": "2026-06-30"},
            headers=auth_headers(token)
        )
        print(f"Status: {r.status_code} | Body: {r.text[:300]}")
        assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text}"

        data = r.json()
        trend = data.get("week_trend", [])
        print(f"week_trend length: {len(trend)}")
        assert len(trend) == 30, f"Expected 30 trend items, got {len(trend)}"
        print("PASS: 30-day filter returns 30 week_trend items")

    def test_seller_role_returns_403(self):
        """SELLER token → 403 Sem permissão"""
        token = get_token("joao@demo.com", "Admin@123456")
        if not token:
            pytest.skip("joao@demo.com não existe ou senha errada")

        r = requests.get(f"{BASE_URL}/api/tenants/demo/dashboard/summary",
                         headers=auth_headers(token))
        print(f"Status: {r.status_code} | Body: {r.text[:300]}")
        assert r.status_code == 403, f"Expected 403 for SELLER, got {r.status_code}: {r.text}"
        assert "permiss" in r.text.lower() or "sem permiss" in r.text.lower(), \
            f"Expected 'Sem permissão' message, got: {r.text}"
        print("PASS: SELLER gets 403")

    def test_seller_id_filter(self):
        """Filtrar por seller_id válido → 200"""
        token = get_token("admin@demo.com", "Admin@123456")
        assert token

        # Get a valid seller_id from seller_profiles
        sellers_r = requests.get(f"{BASE_URL}/api/tenants/demo/sellers",
                                  headers=auth_headers(token))
        print(f"Sellers status: {sellers_r.status_code}")
        if sellers_r.status_code != 200 or not sellers_r.json():
            pytest.skip("No sellers found")

        sellers = sellers_r.json()
        seller_id = sellers[0].get("id")
        print(f"Testing with seller_id: {seller_id}")

        r = requests.get(
            f"{BASE_URL}/api/tenants/demo/dashboard/summary",
            params={"seller_id": seller_id},
            headers=auth_headers(token)
        )
        print(f"Status: {r.status_code} | Body: {r.text[:300]}")
        assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text}"

        data = r.json()
        assert "kpis" in data
        print(f"PASS: seller_id filter returns kpis for seller {seller_id}")

    def test_unauthenticated_returns_401_or_403(self):
        """Sem token → 401 ou 403"""
        r = requests.get(f"{BASE_URL}/api/tenants/demo/dashboard/summary")
        print(f"Status: {r.status_code}")
        assert r.status_code in (401, 403), f"Expected 401/403, got {r.status_code}"
        print("PASS: unauthenticated blocked")

    def test_tenant_context_check_features(self):
        """Verificar se feature dashboards está habilitada para tenant demo"""
        token = get_token("admin@demo.com", "Admin@123456")
        assert token

        r = requests.get(f"{BASE_URL}/api/tenants/demo/context",
                         headers=auth_headers(token))
        print(f"Context status: {r.status_code}")
        if r.status_code == 200:
            data = r.json()
            features = data.get("features", {})
            dashboards_enabled = features.get("dashboards", False)
            print(f"features.dashboards = {dashboards_enabled}")
            if not dashboards_enabled:
                print("WARNING: dashboards feature NOT enabled for demo tenant — KPIs won't show!")
            else:
                print("PASS: dashboards feature is enabled")
        else:
            print(f"Could not get context: {r.text[:200]}")
