"""
Password Reset Flow Tests
Tests: request reset, confirm reset, invalid tokens, change-password
"""
import pytest
import requests
import os
import sys
import motor.motor_asyncio
import asyncio

sys.path.insert(0, '/app/backend')
os.chdir('/app/backend')

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')
TENANT_SLUG = "demo"
ADMIN_EMAIL = "admin@demo.com"
ADMIN_PASSWORD = "Admin@123456"

# Mongo helper
def get_db():
    from dotenv import load_dotenv
    load_dotenv('/app/backend/.env')
    client = motor.motor_asyncio.AsyncIOMotorClient(os.environ['MONGO_URL'])
    return client[os.environ['DB_NAME']]

def get_latest_token(email: str):
    """Fetch latest unused token from MongoDB"""
    async def _get():
        db = get_db()
        token = await db.password_reset_tokens.find_one(
            {"email": email, "used_at": None, "revoked_at": None},
            sort=[("created_at", -1)]
        )
        return token
    return asyncio.run(_get())

def reset_admin_password(new_password: str):
    """Reset admin password directly via DB (for cleanup)"""
    async def _reset():
        import bcrypt
        db = get_db()
        hashed = bcrypt.hashpw(new_password.encode(), bcrypt.gensalt(12)).decode()
        await db.users.update_one({"email": ADMIN_EMAIL}, {"$set": {"password_hash": hashed}})
    asyncio.run(_reset())


class TestPasswordResetRequest:
    """Tests for POST /api/tenants/{slug}/auth/password-reset/request"""

    def test_request_existing_email_returns_200(self):
        """Existing email returns 200 with generic message"""
        r = requests.post(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/auth/password-reset/request",
                          json={"email": ADMIN_EMAIL})
        assert r.status_code == 200
        data = r.json()
        assert "message" in data
        print(f"✓ request existing email: {data['message']}")

    def test_request_nonexistent_email_returns_200(self):
        """Non-existent email also returns 200 (no info disclosure)"""
        r = requests.post(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/auth/password-reset/request",
                          json={"email": "nonexistent_xyz@example.com"})
        assert r.status_code == 200
        data = r.json()
        assert "message" in data
        print(f"✓ request non-existent email: {data['message']}")

    def test_token_created_in_db(self):
        """After requesting, a token exists in password_reset_tokens"""
        # Request reset
        requests.post(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/auth/password-reset/request",
                      json={"email": ADMIN_EMAIL})
        token_doc = get_latest_token(ADMIN_EMAIL)
        assert token_doc is not None
        assert token_doc.get("email") == ADMIN_EMAIL
        assert token_doc.get("used_at") is None
        print(f"✓ token created in DB: {token_doc.get('id')}")


class TestPasswordResetConfirm:
    """Tests for POST /api/tenants/{slug}/auth/password-reset/confirm"""

    def test_invalid_token_returns_400(self):
        """Invalid token returns 400"""
        r = requests.post(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/auth/password-reset/confirm",
                          json={"token": "invalid_token_xyz", "new_password": "NewPass@123"})
        assert r.status_code == 400
        print(f"✓ invalid token: {r.json()}")

    def test_short_password_returns_422(self):
        """Password shorter than 8 chars returns 422"""
        r = requests.post(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/auth/password-reset/confirm",
                          json={"token": "some_token", "new_password": "short"})
        assert r.status_code == 422
        print(f"✓ short password validation: {r.json()}")

    def test_full_flow_request_then_confirm(self):
        """Full flow: request → get token from DB → confirm → verify login works"""
        NEW_PASS = "NewPass@Reset1"

        # Step 1: request reset
        r = requests.post(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/auth/password-reset/request",
                          json={"email": ADMIN_EMAIL})
        assert r.status_code == 200

        # Step 2: get token from DB
        token_doc = get_latest_token(ADMIN_EMAIL)
        assert token_doc is not None, "Token not found in DB after request"

        # Need raw token - we stored hash; but the API calls insert_one with raw token in a test approach
        # We need to fetch raw token from a fresh request, but we stored hash
        # The approach: request a NEW token and capture it from the backend logs or by patching
        # Actually: Let's fetch via a special approach - insert a known token manually
        import secrets, hashlib
        raw_token = secrets.token_urlsafe(32)
        token_hash = hashlib.sha256(raw_token.encode()).hexdigest()

        async def _insert_known_token():
            from datetime import datetime, timezone, timedelta
            db = get_db()
            user = await db.users.find_one({"email": ADMIN_EMAIL})
            tenant = await db.tenants.find_one({"slug": TENANT_SLUG})
            import uuid
            now = datetime.now(timezone.utc)
            await db.password_reset_tokens.insert_one({
                "id": str(uuid.uuid4()),
                "token_hash": token_hash,
                "user_id": user["id"],
                "tenant_id": tenant["id"],
                "email": ADMIN_EMAIL,
                "created_at": now.isoformat(),
                "expires_at": now + timedelta(hours=1),
                "used_at": None,
                "revoked_at": None,
            })
            return raw_token

        raw_token = asyncio.run(_insert_known_token())

        # Step 3: confirm with known token
        r = requests.post(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/auth/password-reset/confirm",
                          json={"token": raw_token, "new_password": NEW_PASS})
        assert r.status_code == 200, f"Confirm failed: {r.text}"
        print(f"✓ confirm reset: {r.json()['message']}")

        # Step 4: verify new password works
        r_login = requests.post(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/auth/login",
                                json={"email": ADMIN_EMAIL, "password": NEW_PASS})
        assert r_login.status_code == 200, f"Login with new password failed: {r_login.text}"
        print("✓ login with new password works")

        # Step 5: verify old password no longer works
        r_old = requests.post(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/auth/login",
                              json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD})
        assert r_old.status_code == 401 or r_old.status_code == 400
        print("✓ old password no longer works")

        # Cleanup: restore old password
        reset_admin_password(ADMIN_PASSWORD)
        print("✓ cleanup: restored original password")

    def test_used_token_returns_400(self):
        """Already used token returns 400 with 'já foi utilizado'"""
        import secrets, hashlib, uuid, asyncio
        from datetime import datetime, timezone, timedelta

        raw_token = secrets.token_urlsafe(32)
        token_hash = hashlib.sha256(raw_token.encode()).hexdigest()

        async def _insert_used_token():
            db = get_db()
            user = await db.users.find_one({"email": ADMIN_EMAIL})
            tenant = await db.tenants.find_one({"slug": TENANT_SLUG})
            now = datetime.now(timezone.utc)
            await db.password_reset_tokens.insert_one({
                "id": str(uuid.uuid4()),
                "token_hash": token_hash,
                "user_id": user["id"],
                "tenant_id": tenant["id"],
                "email": ADMIN_EMAIL,
                "created_at": now.isoformat(),
                "expires_at": now + timedelta(hours=1),
                "used_at": now.isoformat(),  # already used
                "revoked_at": None,
            })

        asyncio.run(_insert_used_token())

        r = requests.post(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/auth/password-reset/confirm",
                          json={"token": raw_token, "new_password": "NewPass@999"})
        assert r.status_code == 400
        detail = r.json().get("detail", "")
        assert "utilizado" in detail.lower() or "used" in detail.lower()
        print(f"✓ used token: {detail}")


class TestChangePassword:
    """Tests for POST /api/tenants/{slug}/auth/change-password"""

    def test_change_password_with_correct_current_password(self):
        """Authenticated user can change password with correct current password"""
        NEW_PASS = "ChangedPass@99"

        # Login first
        r_login = requests.post(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/auth/login",
                                json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD})
        assert r_login.status_code == 200, f"Login failed: {r_login.text}"
        token = r_login.json().get("access_token")
        assert token

        # Change password
        r = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/auth/change-password",
            json={"current_password": ADMIN_PASSWORD, "new_password": NEW_PASS},
            headers={"Authorization": f"Bearer {token}"}
        )
        assert r.status_code == 200, f"Change password failed: {r.text}"
        print(f"✓ change password: {r.json()['message']}")

        # Cleanup: restore old password
        reset_admin_password(ADMIN_PASSWORD)
        print("✓ cleanup: restored original password")
