"""Regressões do relatório Fluxo de Oportunidades por Horário (API pública)."""
import io
import os
import zipfile
from datetime import datetime, timedelta

import pytest
import requests


BASE_URL = os.environ.get("REACT_APP_BACKEND_URL")
TENANT = "demo"


def _base_url() -> str:
    if not BASE_URL:
        pytest.skip("REACT_APP_BACKEND_URL não definido")
    return BASE_URL.rstrip("/")


# Auth fixtures por perfil
@pytest.fixture(scope="module")
def admin_headers():
    res = requests.post(
        f"{_base_url()}/api/tenants/{TENANT}/auth/login",
        json={"email": "admin@demo.com", "password": "Admin@123456"},
        timeout=20,
    )
    assert res.status_code == 200, res.text
    return {"Authorization": f"Bearer {res.json()['access_token']}"}


@pytest.fixture(scope="module")
def regional_headers():
    res = requests.post(
        f"{_base_url()}/api/tenants/{TENANT}/auth/login",
        json={"email": "regional@demo.com", "password": "Admin@123456"},
        timeout=20,
    )
    assert res.status_code == 200, res.text
    return {"Authorization": f"Bearer {res.json()['access_token']}"}


@pytest.fixture(scope="module")
def seller_headers():
    res = requests.post(
        f"{_base_url()}/api/tenants/{TENANT}/auth/login",
        json={"email": "joao@demo.com", "password": "Admin@123456"},
        timeout=20,
    )
    assert res.status_code == 200, res.text
    return {"Authorization": f"Bearer {res.json()['access_token']}"}


def _date(days_delta: int) -> str:
    return (datetime.utcnow() + timedelta(days=days_delta)).strftime("%Y-%m-%d")


# Estrutura principal + regras de conversão
def test_opportunity_flow_response_shape_and_rules(admin_headers):
    params = {"date_start": _date(-7), "date_end": _date(0)}
    res = requests.get(
        f"{_base_url()}/api/tenants/{TENANT}/reports/opportunity-flow",
        headers=admin_headers,
        params=params,
        timeout=60,
    )
    assert res.status_code == 200, res.text
    data = res.json()

    for key in ["period", "filters", "totals", "comparison", "series", "heatmap", "data_quality"]:
        assert key in data
    assert data["period"]["attendance_time_field"] == "started_at"
    assert data["period"]["timezone"] == "America/Sao_Paulo"
    assert data["rules"]["valid_attendance_statuses"] == ["IN_PROGRESS", "FINISHED"]
    assert "CANCELLED" in data["rules"]["invalid_attendance_statuses"]
    assert data["totals"]["opportunities"] >= data["totals"]["converted_opportunities"]
    assert 0 <= data["totals"]["conversion_rate"] <= 100
    assert isinstance(data["data_quality"]["sales_without_attendance"], int)

    for item in data["series"]:
        assert item["opportunities"] >= item["converted_opportunities"]
        assert 0 <= item["conversion_rate"] <= 100


# Granularidade automática
@pytest.mark.parametrize(
    "days_span,expected",
    [
        (0, "hour"),
        (2, "day"),
        (40, "week"),
        (220, "month"),
    ],
)
def test_opportunity_flow_granularity(admin_headers, days_span, expected):
    params = {"date_start": _date(-days_span), "date_end": _date(0)}
    res = requests.get(
        f"{_base_url()}/api/tenants/{TENANT}/reports/opportunity-flow",
        headers=admin_headers,
        params=params,
        timeout=60,
    )
    assert res.status_code == 200, res.text
    assert res.json()["period"]["granularity"] == expected


# Período sem dados não pode gerar NaN/infinito
def test_opportunity_flow_empty_period_no_nan(admin_headers):
    params = {"date_start": "2010-01-01", "date_end": "2010-01-02"}
    res = requests.get(
        f"{_base_url()}/api/tenants/{TENANT}/reports/opportunity-flow",
        headers=admin_headers,
        params=params,
        timeout=60,
    )
    assert res.status_code == 200, res.text
    data = res.json()
    assert isinstance(data["series"], list)
    for item in data["series"]:
        assert item["conversion_rate"] == 0
        assert item["opportunities"] == 0


# Scoping por filtros organizacionais
@pytest.mark.parametrize("param_key,param_value", [("store_id", "store-inexistente"), ("team_id", "team-inexistente"), ("seller_id", "seller-inexistente")])
def test_opportunity_flow_blocks_out_of_scope_filters(admin_headers, param_key, param_value):
    res = requests.get(
        f"{_base_url()}/api/tenants/{TENANT}/reports/opportunity-flow",
        headers=admin_headers,
        params={param_key: param_value},
        timeout=30,
    )
    assert res.status_code in (403, 404)


# Isolamento multi-tenant
def test_opportunity_flow_blocks_tenant_context_leak(admin_headers):
    res = requests.get(
        f"{_base_url()}/api/tenants/demo-b/reports/opportunity-flow",
        headers=admin_headers,
        timeout=30,
    )
    assert res.status_code in (401, 403, 404)


# Permissão financeira para perfil com acesso
def test_opportunity_flow_financial_fields_visible_for_regional(regional_headers):
    res = requests.get(
        f"{_base_url()}/api/tenants/{TENANT}/reports/opportunity-flow",
        headers=regional_headers,
        params={"date_start": _date(-7), "date_end": _date(0)},
        timeout=60,
    )
    assert res.status_code == 200, res.text
    data = res.json()
    assert data["can_view_financial"] is True
    assert "revenue" in data["totals"]
    assert "average_ticket" in data["totals"]


# Perfil sem permissão de relatório não deve acessar endpoint
def test_opportunity_flow_seller_cannot_access_report(seller_headers):
    res = requests.get(
        f"{_base_url()}/api/tenants/{TENANT}/reports/opportunity-flow",
        headers=seller_headers,
        timeout=30,
    )
    assert res.status_code == 403


# Exportações CSV/XLSX válidas e coerentes com filtros
def test_opportunity_flow_exports(admin_headers):
    params = {"date_start": _date(-2), "date_end": _date(0), "attendance_type": "QUEUE"}
    report_res = requests.get(
        f"{_base_url()}/api/tenants/{TENANT}/reports/opportunity-flow",
        headers=admin_headers,
        params=params,
        timeout=60,
    )
    assert report_res.status_code == 200, report_res.text
    report_data = report_res.json()

    csv_res = requests.get(
        f"{_base_url()}/api/tenants/{TENANT}/reports/opportunity-flow/export.csv",
        headers=admin_headers,
        params=params,
        timeout=60,
    )
    assert csv_res.status_code == 200, csv_res.text
    assert "text/csv" in csv_res.headers.get("content-type", "")
    csv_text = csv_res.content.decode("utf-8-sig")
    assert "Fluxo de Oportunidades por Horário" in csv_text
    assert "Vendas sem atendimento vinculado" in csv_text
    assert str(report_data["data_quality"]["sales_without_attendance"]) in csv_text

    xlsx_res = requests.get(
        f"{_base_url()}/api/tenants/{TENANT}/reports/opportunity-flow/export.xlsx",
        headers=admin_headers,
        params=params,
        timeout=60,
    )
    assert xlsx_res.status_code == 200, xlsx_res.text
    assert xlsx_res.content[:2] == b"PK"
    zf = zipfile.ZipFile(io.BytesIO(xlsx_res.content))
    names = set(zf.namelist())
    assert "xl/workbook.xml" in names
    assert "xl/worksheets/sheet1.xml" in names