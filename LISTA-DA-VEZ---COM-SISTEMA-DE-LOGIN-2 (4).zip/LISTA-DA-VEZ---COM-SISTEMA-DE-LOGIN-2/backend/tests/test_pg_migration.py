"""
Post-migration regression tests (MongoDB -> Postgres/Supabase via pg_shim).
Focus: confirm the previously-working behaviors still work over the new persistence layer.
Higher timeouts to tolerate remote Supabase latency.
"""
import os
import time
import uuid
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "https://queue-mgmt-3.preview.emergentagent.com").rstrip("/")
API = f"{BASE_URL}/api"

TIMEOUT = 90  # remote DB latency tolerant

# ---------- Fixtures ----------

@pytest.fixture(scope="session")
def super_admin_token():
    r = requests.post(f"{API}/auth/login",
                      json={"email": "admin@listadavez.com", "password": "Admin@123456"},
                      timeout=TIMEOUT)
    assert r.status_code == 200, r.text
    return r.json()["access_token"]

@pytest.fixture(scope="session")
def tenant_admin_token():
    r = requests.post(f"{API}/tenants/demo/auth/login",
                      json={"email": "admin@demo.com", "password": "Admin@123456"},
                      timeout=TIMEOUT)
    assert r.status_code == 200, r.text
    return r.json()["access_token"]

@pytest.fixture(scope="session")
def seller_joao_token():
    r = requests.post(f"{API}/tenants/demo/auth/login",
                      json={"email": "joao@demo.com", "password": "Admin@123456"},
                      timeout=TIMEOUT)
    assert r.status_code == 200, r.text
    return r.json()["access_token"]

def auth(tok):
    return {"Authorization": f"Bearer {tok}"}

# ---------- Health / basic ----------

def test_health():
    r = requests.get(f"{API}/health", timeout=TIMEOUT)
    assert r.status_code == 200

# ---------- Auth ----------

def test_super_admin_login_invalid():
    r = requests.post(f"{API}/auth/login",
                      json={"email": "admin@listadavez.com", "password": "wrong"},
                      timeout=TIMEOUT)
    assert r.status_code in (400, 401, 403)

def test_tenant_admin_login_ok(tenant_admin_token):
    assert isinstance(tenant_admin_token, str) and len(tenant_admin_token) > 20

def test_seller_login_ok(seller_joao_token):
    assert isinstance(seller_joao_token, str) and len(seller_joao_token) > 20

# ---------- Super admin dashboard ----------

def test_super_admin_dashboard(super_admin_token):
    # Try common paths
    tried = []
    for path in ["/super-admin/dashboard", "/super-admin/dashboard/summary",
                 "/super-admin/tenants", "/super-admin/metrics"]:
        r = requests.get(f"{API}{path}", headers=auth(super_admin_token), timeout=TIMEOUT)
        tried.append((path, r.status_code))
        if r.status_code == 200:
            return
    pytest.fail(f"No super admin dashboard endpoint returned 200. Tried: {tried}")

def test_super_admin_list_tenants(super_admin_token):
    r = requests.get(f"{API}/super-admin/tenants", headers=auth(super_admin_token), timeout=TIMEOUT)
    assert r.status_code == 200, r.text
    data = r.json()
    # allow either list or object with list
    items = data if isinstance(data, list) else data.get("items") or data.get("tenants") or []
    assert any((t.get("slug") == "demo") for t in items), f"demo tenant not found in: {items}"

# ---------- Tenant demo dashboard ----------

def test_tenant_dashboard_summary(tenant_admin_token):
    r = requests.get(f"{API}/tenants/demo/dashboard/summary",
                     headers=auth(tenant_admin_token), timeout=TIMEOUT)
    assert r.status_code == 200, r.text
    data = r.json()
    assert isinstance(data, dict)
    # Should contain some KPI keys (be lenient about exact naming)
    keys = set(data.keys())
    assert any(k in keys for k in ("attendances_today", "sales_today", "conversion_rate",
                                    "kpis", "totals", "summary")), f"unexpected keys: {keys}"

# ---------- Sellers / Queue state ----------

def _get_stores(token):
    r = requests.get(f"{API}/tenants/demo/stores", headers=auth(token), timeout=TIMEOUT)
    if r.status_code != 200:
        return []
    d = r.json()
    return d if isinstance(d, list) else d.get("items", [])

def test_list_stores(tenant_admin_token):
    stores = _get_stores(tenant_admin_token)
    assert len(stores) > 0, "expected at least 1 store"

def test_list_sellers(tenant_admin_token):
    r = requests.get(f"{API}/tenants/demo/sellers", headers=auth(tenant_admin_token), timeout=TIMEOUT)
    assert r.status_code == 200, r.text
    d = r.json()
    items = d if isinstance(d, list) else d.get("items", [])
    assert len(items) >= 5

def test_queue_state(tenant_admin_token):
    stores = _get_stores(tenant_admin_token)
    assert stores
    store_id = stores[0]["id"]
    r = requests.get(f"{API}/tenants/demo/stores/{store_id}/queue",
                     headers=auth(tenant_admin_token), timeout=TIMEOUT)
    assert r.status_code == 200, r.text

# ---------- Rankings ----------

def test_rankings_items_sold(tenant_admin_token):
    r = requests.get(f"{API}/tenants/demo/rankings?metric=ITEMS_SOLD&period=today",
                     headers=auth(tenant_admin_token), timeout=TIMEOUT)
    assert r.status_code in (200, 422), r.text  # 422 possible if params differ
    if r.status_code == 422:
        # try alternative param name
        r = requests.get(f"{API}/tenants/demo/rankings?type=ITEMS_SOLD",
                         headers=auth(tenant_admin_token), timeout=TIMEOUT)
    assert r.status_code == 200, r.text

def test_rankings_revenue(tenant_admin_token):
    r = requests.get(f"{API}/tenants/demo/rankings?metric=REVENUE&period=month",
                     headers=auth(tenant_admin_token), timeout=TIMEOUT)
    assert r.status_code in (200, 422), r.text

# ---------- Opportunity flow report (uses aggregation pipeline in pg_shim) ----------

def test_opportunity_flow_report(tenant_admin_token):
    r = requests.get(f"{API}/tenants/demo/reports/opportunity-flow",
                     headers=auth(tenant_admin_token), timeout=TIMEOUT)
    assert r.status_code == 200, r.text
    d = r.json()
    # Validate schema
    assert "totals" in d or "opportunities" in d, f"unexpected shape: {list(d.keys())}"
    totals = d.get("totals", d)
    for k in ("opportunities", "converted_opportunities", "revenue"):
        assert k in totals, f"missing {k} in totals: {totals}"

# ---------- Goals & achievements ----------

def test_goals_list(tenant_admin_token):
    r = requests.get(f"{API}/tenants/demo/goals", headers=auth(tenant_admin_token), timeout=TIMEOUT)
    assert r.status_code == 200, r.text

def test_achievements_list(tenant_admin_token):
    r = requests.get(f"{API}/tenants/demo/achievements", headers=auth(tenant_admin_token), timeout=TIMEOUT)
    assert r.status_code == 200, r.text

# ---------- Loss reasons hierarchy ----------

def test_loss_reasons_hierarchy(tenant_admin_token):
    r = requests.get(f"{API}/tenants/demo/loss-reasons", headers=auth(tenant_admin_token), timeout=TIMEOUT)
    assert r.status_code == 200, r.text
    d = r.json()
    items = d if isinstance(d, list) else d.get("items", [])
    assert isinstance(items, list)

# ---------- Products & sales listings (for aggregation sanity) ----------

def test_products_list(tenant_admin_token):
    r = requests.get(f"{API}/tenants/demo/products", headers=auth(tenant_admin_token), timeout=TIMEOUT)
    assert r.status_code == 200, r.text

def test_sales_list(tenant_admin_token):
    r = requests.get(f"{API}/tenants/demo/sales", headers=auth(tenant_admin_token), timeout=TIMEOUT)
    assert r.status_code == 200, r.text
    d = r.json()
    items = d if isinstance(d, list) else d.get("items", [])
    assert len(items) >= 1, "expected seeded sales"

def test_attendances_list(tenant_admin_token):
    r = requests.get(f"{API}/tenants/demo/attendances", headers=auth(tenant_admin_token), timeout=TIMEOUT)
    assert r.status_code == 200, r.text

# ---------- Multi-tenant isolation ----------

def test_cross_tenant_forbidden(tenant_admin_token):
    # tenant admin from demo tries to access super-admin only endpoint
    r = requests.get(f"{API}/super-admin/tenants",
                     headers=auth(tenant_admin_token), timeout=TIMEOUT)
    assert r.status_code in (401, 403), f"expected forbidden, got {r.status_code}"

def test_wrong_tenant_slug_forbidden(tenant_admin_token):
    # use demo admin token on a different tenant path
    r = requests.get(f"{API}/tenants/nonexistent-tenant-xyz/dashboard/summary",
                     headers=auth(tenant_admin_token), timeout=TIMEOUT)
    assert r.status_code in (401, 403, 404), r.status_code
