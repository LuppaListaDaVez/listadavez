"""Backend tests for SMTP Settings endpoints (Super Admin)"""
import pytest
import requests
import os

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")

SA_EMAIL = "admin@listadavez.com"
SA_PASS = "Admin@123456"


@pytest.fixture(scope="module")
def sa_token():
    r = requests.post(f"{BASE_URL}/api/auth/login",
                      json={"email": SA_EMAIL, "password": SA_PASS})
    assert r.status_code == 200, f"SA login failed: {r.text}"
    return r.json().get("token") or r.json().get("access_token")


@pytest.fixture(scope="module")
def sa_client(sa_token):
    s = requests.Session()
    s.headers.update({"Authorization": f"Bearer {sa_token}", "Content-Type": "application/json"})
    return s


class TestEmailStatus:
    """GET /api/super-admin/system/email-status"""

    def test_email_status_returns_200(self, sa_client):
        r = sa_client.get(f"{BASE_URL}/api/super-admin/system/email-status")
        assert r.status_code == 200
        data = r.json()
        assert "configured" in data
        assert "provider" in data
        print(f"Email status: {data}")

    def test_email_status_structure(self, sa_client):
        r = sa_client.get(f"{BASE_URL}/api/super-admin/system/email-status")
        data = r.json()
        assert isinstance(data["configured"], bool)
        assert isinstance(data.get("missing_vars", []), list)


class TestSmtpConfigCRUD:
    """GET/PUT/DELETE /api/super-admin/system/smtp-config"""

    def test_get_smtp_config(self, sa_client):
        r = sa_client.get(f"{BASE_URL}/api/super-admin/system/smtp-config")
        assert r.status_code == 200
        data = r.json()
        assert "source" in data
        assert data["source"] in ("database", "environment")
        assert "smtp_host" in data
        assert "smtp_port" in data
        print(f"SMTP config source: {data['source']}, host: {data['smtp_host']}")

    def test_save_smtp_config(self, sa_client):
        payload = {
            "smtp_host": "smtp.test-example.com",
            "smtp_port": 587,
            "smtp_secure": False,
            "smtp_user": "test@test-example.com",
            "smtp_pass": "TestPassword123",
            "smtp_from": "noreply@test-example.com",
        }
        r = sa_client.put(f"{BASE_URL}/api/super-admin/system/smtp-config", json=payload)
        assert r.status_code == 200
        data = r.json()
        assert data.get("success") is True
        print(f"Save response: {data}")

    def test_get_after_save_shows_database_source(self, sa_client):
        r = sa_client.get(f"{BASE_URL}/api/super-admin/system/smtp-config")
        assert r.status_code == 200
        data = r.json()
        assert data["source"] == "database"
        assert data["smtp_host"] == "smtp.test-example.com"
        assert data["smtp_pass"] == "****"  # password masked
        print(f"After save: source={data['source']}, host={data['smtp_host']}")

    def test_delete_smtp_config(self, sa_client):
        r = sa_client.delete(f"{BASE_URL}/api/super-admin/system/smtp-config")
        assert r.status_code == 200
        data = r.json()
        assert data.get("success") is True

    def test_get_after_delete_shows_environment_source(self, sa_client):
        r = sa_client.get(f"{BASE_URL}/api/super-admin/system/smtp-config")
        assert r.status_code == 200
        data = r.json()
        assert data["source"] == "environment"
        print(f"After delete: source={data['source']}")


class TestSmtpConfigTest:
    """POST /api/super-admin/system/smtp-config/test"""

    def test_test_smtp_with_invalid_config_returns_error_not_crash(self, sa_client):
        """With invalid SMTP, should return {success: false, message: ...} not 500"""
        payload = {
            "config": {
                "smtp_host": "smtp.gmail.com",
                "smtp_port": 587,
                "smtp_secure": False,
                "smtp_user": "test@gmail.com",
                "smtp_pass": "wrong_password",
                "smtp_from": "test@gmail.com",
            },
            "test_email": "destination@example.com",
        }
        r = sa_client.post(f"{BASE_URL}/api/super-admin/system/smtp-config/test", json=payload)
        assert r.status_code == 200  # NOT 500 crash
        data = r.json()
        assert "success" in data
        assert data["success"] is False  # expected failure with wrong creds
        assert "message" in data
        assert len(data["message"]) > 0
        print(f"Test SMTP error response: {data}")

    def test_test_smtp_without_host_returns_error(self, sa_client):
        payload = {
            "config": {
                "smtp_host": "",
                "smtp_port": 587,
                "smtp_secure": False,
                "smtp_user": "",
                "smtp_pass": "",
                "smtp_from": "",
            },
            "test_email": "test@example.com",
        }
        r = sa_client.post(f"{BASE_URL}/api/super-admin/system/smtp-config/test", json=payload)
        assert r.status_code == 200
        data = r.json()
        assert data.get("success") is False
        print(f"No-host test response: {data}")
