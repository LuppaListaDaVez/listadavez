"""Testes — Prompt 2: Cadastro de tenant com convite + aceite de convite.

Cobre:
- POST /super-admin/tenants cria tenant com status PENDING_ACTIVATION
- Convite TENANT_OWNER inserido em invite_tokens (token hash, TTL, campos corretos)
- Tenant PENDING_ACTIVATION bloqueia login (403)
- POST /invites/{token}/accept — fluxo novo usuário: ativa tenant, retorna tokens
- POST /invites/{token}/accept — token já usado retorna 400
- POST /invites/{token}/accept — token inexistente retorna 400
- POST /invites/{token}/accept — e-mail já existente em outro tenant: só cria membership
- POST /super-admin/tenants/{id}/resend-invite — revoga antigo e gera novo
- Regressão: login no tenant demo (ACTIVE) continua funcionando
"""
import sys, os, asyncio, hashlib, secrets
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import pytest
import httpx
from datetime import datetime, timezone, timedelta
from motor.motor_asyncio import AsyncIOMotorClient

BASE = "http://localhost:8001/api"
SUPER_CREDS = {"email": "admin@listadavez.com", "password": "Admin@123456"}

# CNPJs válidos calculados com dígito verificador correto — um por teste
CNPJ_PENDING   = "82000100000182"   # test_tenant_criado_com_pending_activation
CNPJ_NO_EMAIL  = "78000010000114"   # test_tenant_sem_admin_email_rejeitado (422 → não insere)
CNPJ_INVITE_DB = "33592510000154"   # test_invite_token_criado_no_banco
CNPJ_PENDING_C = "07526557000100"   # test_login_tenant_pending_activation_bloqueado
CNPJ_ACCEPT    = "91000100000173"   # accept_tenant fixture
CNPJ_RESEND    = "82222700000195"   # TestResendInvite
CNPJ_EXISTING  = "29979036000140"   # test_email_existente


def _db():
    MONGO_URL = os.environ.get("MONGO_URL", "mongodb://localhost:27017")
    DB_NAME = os.environ.get("DB_NAME", "test_database")
    return AsyncIOMotorClient(MONGO_URL)[DB_NAME]


@pytest.fixture(scope="module")
def client():
    with httpx.Client(base_url=BASE, timeout=20) as c:
        yield c


@pytest.fixture(scope="module")
def super_token(client):
    r = client.post("/auth/login", json=SUPER_CREDS)
    assert r.status_code == 200, f"Super admin login: {r.text}"
    return r.json()["access_token"]


def _headers(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


def _cleanup_tenants(client, token, *slugs):
    """Limpeza direta no MongoDB — garante idempotência independente de endpoints."""
    async def _do():
        db = _db()
        await db.tenants.delete_many({"slug": {"$in": list(slugs)}})
    asyncio.run(_do())


def _insert_test_invite(tenant_id: str, email: str) -> str:
    """Insere convite com token conhecido no banco para teste. Retorna token raw."""
    raw = secrets.token_urlsafe(48)
    token_hash = hashlib.sha256(raw.encode()).hexdigest()
    now = datetime.now(timezone.utc)

    async def _do():
        db = _db()
        await db.invite_tokens.insert_one({
            "id": "test-" + raw[:8],
            "token_hash": token_hash,
            "tenant_id": tenant_id,
            "invite_type": "TENANT_OWNER",
            "email": email.lower(),
            "role": "TENANT_ADMIN",
            "store_ids": [],
            "all_stores": False,
            "created_by": "SUPER_ADMIN",
            "created_at": now.isoformat(),
            "expires_at": now + timedelta(hours=72),
            "used_at": None,
            "revoked_at": None,
        })
    asyncio.run(_do())
    return raw


# ─────────────────────────────────────────────────────────────────────────────

class TestCreateTenantWithInvite:

    def test_tenant_criado_com_pending_activation(self, client, super_token):
        slug = "p2-create-a"
        _cleanup_tenants(client, super_token, slug)
        r = client.post(
            "/super-admin/tenants",
            json={"name": "Empresa P2-A", "slug": slug, "cnpj": CNPJ_PENDING,
                  "admin_email": "dono-a@empresa.com", "admin_name": "Dono A"},
            headers=_headers(super_token),
        )
        assert r.status_code == 201, f"Esperava 201: {r.text}"
        body = r.json()
        assert body["status"] == "PENDING_ACTIVATION", f"Status errado: {body}"
        assert body.get("invite_sent_to") == "dono-a@empresa.com"

    def test_tenant_sem_admin_email_rejeitado(self, client, super_token):
        r = client.post(
            "/super-admin/tenants",
            json={"name": "Sem Email", "slug": "p2-no-email", "cnpj": CNPJ_NO_EMAIL},
            headers=_headers(super_token),
        )
        assert r.status_code == 422, f"Esperava 422: {r.text}"

    def test_invite_token_criado_no_banco(self, client, super_token):
        slug = "p2-create-b"
        _cleanup_tenants(client, super_token, slug)
        r = client.post(
            "/super-admin/tenants",
            json={"name": "Empresa P2-B", "slug": slug, "cnpj": CNPJ_INVITE_DB,
                  "admin_email": "dono-b@empresa.com"},
            headers=_headers(super_token),
        )
        assert r.status_code == 201
        tenant_id = r.json()["id"]

        async def _check():
            db = _db()
            invite = await db.invite_tokens.find_one({"tenant_id": tenant_id, "invite_type": "TENANT_OWNER"})
            return invite

        invite = asyncio.run(_check())
        assert invite is not None, "invite_token não encontrado"
        assert invite["email"] == "dono-b@empresa.com"
        assert invite["role"] == "TENANT_ADMIN"
        assert invite["used_at"] is None
        assert invite["revoked_at"] is None
        assert len(invite["token_hash"]) == 64   # sha256 → 64 hex chars
        assert invite["expires_at"] is not None


class TestPendingTenantLogin:

    def test_login_tenant_pending_activation_bloqueado(self, client, super_token):
        slug = "p2-pending-c"
        _cleanup_tenants(client, super_token, slug)
        r = client.post(
            "/super-admin/tenants",
            json={"name": "Empresa P2-C", "slug": slug, "cnpj": CNPJ_PENDING_C,
                  "admin_email": "dono-c@empresa.com"},
            headers=_headers(super_token),
        )
        assert r.status_code == 201

        r_login = client.post(
            f"/tenants/{slug}/auth/login",
            json={"email": "dono-c@empresa.com", "password": "qualquer"},
        )
        assert r_login.status_code == 403, (
            f"Esperava 403 para tenant PENDING_ACTIVATION, got {r_login.status_code}: {r_login.text}"
        )


# ─── Fixtures de módulo para TestAcceptInvite ─────────────────────────────────

@pytest.fixture(scope="module")
def accept_tenant(client, super_token):
    """Cria o tenant de accept e retorna (tenant_id, tenant_slug)."""
    slug = "p2-accept-d"
    email = "novo-dono@accept.com"

    # Limpeza: remover tenant e usuário de runs anteriores (apenas para este email de teste)
    async def _pre_clean():
        db = _db()
        await db.tenants.delete_many({"slug": slug})
        # Remover usuário de teste e suas memberships
        user = await db.users.find_one({"email": email})
        if user:
            await db.tenant_memberships.delete_many({"user_id": user["id"]})
            await db.users.delete_many({"email": email})

    asyncio.run(_pre_clean())

    r = client.post(
        "/super-admin/tenants",
        json={"name": "Empresa Accept", "slug": slug, "cnpj": CNPJ_ACCEPT,
              "admin_email": email},
        headers=_headers(super_token),
    )
    assert r.status_code == 201, f"Criação do tenant accept falhou: {r.text}"
    return r.json()["id"], r.json()["slug"]


class TestAcceptInvite:

    def test_aceitar_convite_novo_usuario(self, client, super_token, accept_tenant):
        tenant_id, tenant_slug = accept_tenant
        raw_token = _insert_test_invite(tenant_id, "novo-dono@accept.com")

        r = client.post(
            f"/invites/{raw_token}/accept",
            json={"token": raw_token, "name": "Dono Ativado", "password": "Senha@123456"},
        )
        assert r.status_code == 200, f"Aceite falhou: {r.status_code} {r.text}"
        body = r.json()
        assert "access_token" in body, f"access_token ausente: {body}"
        assert "refresh_token" in body
        assert body.get("tenant_slug") == tenant_slug
        assert body.get("message") == "Conta ativada com sucesso."

        # Verificar que o tenant está ACTIVE agora
        r2 = client.get(f"/super-admin/tenants/{tenant_id}", headers=_headers(super_token))
        assert r2.json()["status"] == "ACTIVE", f"Tenant deveria ser ACTIVE: {r2.json()}"

    def test_convite_usado_nao_pode_ser_reusado(self, client, accept_tenant):
        tenant_id, _ = accept_tenant
        raw_token = _insert_test_invite(tenant_id, "novo-dono@accept.com")

        r1 = client.post(
            f"/invites/{raw_token}/accept",
            json={"token": raw_token, "name": "Dono 1", "password": "Senha@123456"},
        )
        assert r1.status_code == 200

        # Segunda tentativa → 400
        r2 = client.post(
            f"/invites/{raw_token}/accept",
            json={"token": raw_token, "name": "Tentativa 2", "password": "Senha@123456"},
        )
        assert r2.status_code == 400, f"Segunda tentativa deveria ser 400: {r2.text}"
        msg = r2.json()["detail"].lower()
        assert "inválido" in msg or "expirado" in msg

    def test_token_inexistente_retorna_400(self, client):
        fake = secrets.token_urlsafe(48)
        r = client.post(
            f"/invites/{fake}/accept",
            json={"token": fake, "name": "X", "password": "Senha@123456"},
        )
        assert r.status_code == 400
        msg = r.json()["detail"].lower()
        assert "inválido" in msg or "expirado" in msg

    def test_email_existente_cria_membership_sem_mudar_senha(self, client, super_token):
        """E-mail já cadastrado → só membership, sem mudar senha."""
        existing_email = "admin@demo.com"

        async def _get_hash():
            db = _db()
            user = await db.users.find_one({"email": existing_email})
            return user["password_hash"] if user else None

        original_hash = asyncio.run(_get_hash())
        if not original_hash:
            pytest.skip("admin@demo.com não encontrado")

        # Criar tenant novo com e-mail existente
        slug = "p2-existing-e"
        _cleanup_tenants(client, super_token, slug)
        r_create = client.post(
            "/super-admin/tenants",
            json={"name": "Empresa Existing", "slug": slug, "cnpj": CNPJ_EXISTING,
                  "admin_email": existing_email},
            headers=_headers(super_token),
        )
        assert r_create.status_code == 201, f"Criação falhou: {r_create.text}"
        tenant_id = r_create.json()["id"]

        raw_token = _insert_test_invite(tenant_id, existing_email)
        r_accept = client.post(
            f"/invites/{raw_token}/accept",
            json={"token": raw_token, "name": "Novo Nome", "password": "NOVA-SENHA-999"},
        )
        assert r_accept.status_code == 200, f"Accept falhou: {r_accept.text}"
        body = r_accept.json()
        assert body.get("existing_user") is True, f"Deveria indicar existing_user=True: {body}"
        # Senha NÃO deve ter mudado
        new_hash = asyncio.run(_get_hash())
        assert new_hash == original_hash, "FALHA DE SEGURANÇA: senha do usuário existente foi alterada!"


class TestResendInvite:

    def test_resend_revoga_antigo_e_gera_novo(self, client, super_token):
        slug = "p2-resend-f"
        _cleanup_tenants(client, super_token, slug)
        r = client.post(
            "/super-admin/tenants",
            json={"name": "Empresa Resend", "slug": slug, "cnpj": CNPJ_RESEND,
                  "admin_email": "resend@empresa.com"},
            headers=_headers(super_token),
        )
        assert r.status_code == 201, f"Criação falhou: {r.text}"
        tenant_id = r.json()["id"]

        async def _get_original():
            db = _db()
            return await db.invite_tokens.find_one(
                {"tenant_id": tenant_id, "invite_type": "TENANT_OWNER"},
                sort=[("created_at", -1)],
            )

        original = asyncio.run(_get_original())
        assert original, "Invite original não encontrado"

        r_resend = client.post(
            f"/super-admin/tenants/{tenant_id}/resend-invite",
            headers=_headers(super_token),
        )
        assert r_resend.status_code == 200, f"resend-invite falhou: {r_resend.status_code} {r_resend.text}"
        assert "reenviado" in r_resend.json()["message"].lower()

        async def _check():
            db = _db()
            revoked = await db.invite_tokens.find_one({"token_hash": original["token_hash"]})
            new_inv = await db.invite_tokens.find_one(
                {"tenant_id": tenant_id, "invite_type": "TENANT_OWNER", "revoked_at": None},
                sort=[("created_at", -1)],
            )
            return revoked, new_inv

        revoked, new_inv = asyncio.run(_check())
        assert revoked.get("revoked_at") is not None, "Convite antigo deveria estar revogado"
        assert new_inv is not None, "Novo convite não encontrado"
        assert new_inv["token_hash"] != original["token_hash"], "Hash deveria ser diferente"


class TestLoginRegressao:

    def test_login_demo_continua_funcionando(self, client):
        r = client.post(
            "/tenants/demo/auth/login",
            json={"email": "admin@demo.com", "password": "Admin@123456"},
        )
        assert r.status_code == 200, f"Login demo falhou: {r.text}"
        assert "access_token" in r.json()
        assert r.json()["tenant_slug"] == "demo"
