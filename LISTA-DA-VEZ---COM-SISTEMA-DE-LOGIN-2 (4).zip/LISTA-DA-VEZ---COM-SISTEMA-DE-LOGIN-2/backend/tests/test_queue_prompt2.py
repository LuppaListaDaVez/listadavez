"""Tests for Prompt 2 queue endpoints: sair-da-fila, retornar-da-fora, nova-jornada, retornar-operacao"""
import pytest
import requests
import os

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")
TENANT = "demo"
ADMIN_EMAIL = "admin@demo.com"
ADMIN_PASS = "Admin@123456"
SELLER_EMAIL = "joao@demo.com"
SELLER_PASS = "Admin@123456"


@pytest.fixture(scope="module")
def admin_token():
    r = requests.post(f"{BASE_URL}/api/tenants/{TENANT}/auth/login",
                      json={"email": ADMIN_EMAIL, "password": ADMIN_PASS})
    assert r.status_code == 200, f"Admin login failed: {r.text}"
    return r.json()["access_token"]


@pytest.fixture(scope="module")
def store_id(admin_token):
    r = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/stores",
                     headers={"Authorization": f"Bearer {admin_token}"})
    assert r.status_code == 200, f"Get stores failed: {r.text}"
    stores = r.json()
    assert len(stores) > 0, "No stores found"
    return stores[0]["id"]


@pytest.fixture(scope="module")
def seller_info(admin_token, store_id):
    """Get João's seller profile id from queue state"""
    r = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/queue",
                     headers={"Authorization": f"Bearer {admin_token}"})
    assert r.status_code == 200
    state = r.json()
    all_sellers = state.get("entries", []) + state.get("available_sellers", [])
    for s in all_sellers:
        name = (s.get("name") or "").lower()
        if "jo" in name:
            return {"id": s["seller_id"], "name": s.get("name")}
    # fallback: first available
    all_sellers2 = state.get("entries", []) + state.get("available_sellers", []) + state.get("away_sellers", [])
    assert len(all_sellers2) > 0, "No sellers found in queue state"
    return {"id": all_sellers2[0]["seller_id"], "name": all_sellers2[0].get("name")}


@pytest.fixture(scope="module")
def queue_id(admin_token, store_id):
    r = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/queues",
                     headers={"Authorization": f"Bearer {admin_token}"})
    assert r.status_code == 200, f"Get queues failed: {r.text}"
    queues = r.json()
    assert len(queues) > 0, "No queues found"
    return queues[0]["id"]


def get_queue_state(admin_token, store_id):
    r = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/queue",
                     headers={"Authorization": f"Bearer {admin_token}"})
    assert r.status_code == 200
    return r.json()


class TestSairDaFila:
    """Test sair-da-fila endpoint with all 3 motivos"""

    def test_sair_da_fila_lanche(self, admin_token, store_id, seller_info, queue_id):
        """LANCHE_OU_ALMOCO: seller should go to BREAK state"""
        seller_id = seller_info["id"]
        headers = {"Authorization": f"Bearer {admin_token}"}

        # First ensure seller is in queue (join)
        requests.post(f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/queue/join",
                      json={"queue_id": queue_id, "seller_id": seller_id},
                      headers=headers)

        r = requests.post(f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/queue/sair-da-fila",
                          json={"seller_id": seller_id, "motivo": "LANCHE_OU_ALMOCO", "queue_id": queue_id},
                          headers=headers)
        print(f"sair-da-fila LANCHE response: {r.status_code} {r.text[:200]}")
        assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text}"
        data = r.json()
        # Response is full queue state
        assert "store" in data or "seller_id" in data or "status" in data

    def test_retornar_da_fora(self, admin_token, store_id, seller_info, queue_id):
        """Seller returns from BREAK state to end of queue"""
        seller_id = seller_info["id"]
        headers = {"Authorization": f"Bearer {admin_token}"}

        r = requests.post(f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/queue/retornar-da-fora",
                          json={"seller_id": seller_id, "queue_id": queue_id},
                          headers=headers)
        print(f"retornar-da-fora response: {r.status_code} {r.text[:200]}")
        assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text}"

    def test_sair_da_fila_atividade_operacional(self, admin_token, store_id, seller_info, queue_id):
        """ATIVIDADE_OPERACIONAL: seller stays in queue with sub-state"""
        seller_id = seller_info["id"]
        headers = {"Authorization": f"Bearer {admin_token}"}

        # Ensure seller is in queue
        requests.post(f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/queue/join",
                      json={"queue_id": queue_id, "seller_id": seller_id},
                      headers=headers)

        r = requests.post(f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/queue/sair-da-fila",
                          json={"seller_id": seller_id, "motivo": "ATIVIDADE_OPERACIONAL", "queue_id": queue_id},
                          headers=headers)
        print(f"sair-da-fila ATIVIDADE response: {r.status_code} {r.text[:200]}")
        assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text}"

    def test_retornar_operacao(self, admin_token, store_id, seller_info):
        """Remove ATIVIDADE_OPERACIONAL sub-state"""
        seller_id = seller_info["id"]
        headers = {"Authorization": f"Bearer {admin_token}"}

        r = requests.post(f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/queue/retornar-operacao",
                          json={"seller_id": seller_id},
                          headers=headers)
        print(f"retornar-operacao response: {r.status_code} {r.text[:200]}")
        assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text}"

    def test_sair_da_fila_encerrar_dia(self, admin_token, store_id, seller_info, queue_id):
        """ENCERRAR_DIA: seller's jornada_encerrada=true"""
        seller_id = seller_info["id"]
        headers = {"Authorization": f"Bearer {admin_token}"}

        # Ensure seller is in queue
        requests.post(f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/queue/join",
                      json={"queue_id": queue_id, "seller_id": seller_id},
                      headers=headers)

        r = requests.post(f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/queue/sair-da-fila",
                          json={"seller_id": seller_id, "motivo": "ENCERRAR_DIA", "queue_id": queue_id},
                          headers=headers)
        print(f"sair-da-fila ENCERRAR_DIA response: {r.status_code} {r.text[:200]}")
        assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text}"

    def test_nova_jornada(self, admin_token, store_id, seller_info):
        """nova-jornada: seller returns to AVAILABLE"""
        seller_id = seller_info["id"]
        headers = {"Authorization": f"Bearer {admin_token}"}

        r = requests.post(f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/queue/nova-jornada",
                          json={"seller_id": seller_id},
                          headers=headers)
        print(f"nova-jornada response: {r.status_code} {r.text[:200]}")
        assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text}"

    def test_queue_state_accessible(self, admin_token, store_id):
        """Queue state endpoint returns data"""
        state = get_queue_state(admin_token, store_id)
        print(f"Queue state keys: {list(state.keys()) if isinstance(state, dict) else type(state)}")
        assert state is not None
