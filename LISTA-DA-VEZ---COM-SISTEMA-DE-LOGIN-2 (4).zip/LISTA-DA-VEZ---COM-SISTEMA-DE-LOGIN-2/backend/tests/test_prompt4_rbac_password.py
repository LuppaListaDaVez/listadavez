"""
Tests for PROMPT 4 — RBAC Stores, set-password endpoint, auto-sync seller_profile
"""
import pytest
import requests
import os

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")

ADMIN_EMAIL = "admin@demo.com"
ADMIN_PASS = "Admin@123456"
SELLER_EMAIL = "joao@demo.com"
SELLER_PASS = "Admin@123456"
TENANT_SLUG = "demo"


def login(email, password):
    r = requests.post(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/auth/login", json={
        "email": email,
        "password": password,
    })
    assert r.status_code == 200, f"Login failed for {email}: {r.text}"
    return r.json()["access_token"]


@pytest.fixture(scope="module")
def admin_token():
    return login(ADMIN_EMAIL, ADMIN_PASS)


@pytest.fixture(scope="module")
def seller_token():
    return login(SELLER_EMAIL, SELLER_PASS)


@pytest.fixture(scope="module")
def seller_id(admin_token):
    """Get joao@demo.com user id"""
    r = requests.get(
        f"{BASE_URL}/api/tenants/{TENANT_SLUG}/users",
        headers={"Authorization": f"Bearer {admin_token}"}
    )
    assert r.status_code == 200
    users = r.json()
    for u in users:
        if u["email"] == SELLER_EMAIL:
            return u["id"]
    pytest.skip("Seller user not found")


# ── Test 1: RBAC — GET /stores as SELLER should 403 ─────────────────────────
def test_rbac_seller_cannot_access_stores(seller_token):
    r = requests.get(
        f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores",
        headers={"Authorization": f"Bearer {seller_token}"}
    )
    # SELLER should not have stores.create permission → should be 403
    assert r.status_code == 403, f"Expected 403 for SELLER on /stores, got {r.status_code}: {r.text}"
    print(f"PASS: SELLER gets {r.status_code} on /stores")


# ── Test 2: RBAC — GET /stores as TENANT_ADMIN should 200 ───────────────────
def test_rbac_admin_can_access_stores(admin_token):
    r = requests.get(
        f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores",
        headers={"Authorization": f"Bearer {admin_token}"}
    )
    assert r.status_code == 200, f"Expected 200 for ADMIN on /stores, got {r.status_code}: {r.text}"
    print(f"PASS: ADMIN gets 200 on /stores, stores count: {len(r.json())}")


# ── Test 3: set-password as ADMIN should succeed ─────────────────────────────
def test_admin_can_set_password(admin_token, seller_id):
    r = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT_SLUG}/users/{seller_id}/set-password",
        headers={"Authorization": f"Bearer {admin_token}"},
        json={"new_password": "Admin@123456"}  # reset back to same password
    )
    assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text}"
    data = r.json()
    assert "message" in data
    assert data["message"] == "Senha alterada com sucesso."
    print(f"PASS: Admin set-password → {data}")


# ── Test 4: set-password as SELLER should be 403 ─────────────────────────────
def test_seller_cannot_set_password(seller_token, seller_id):
    r = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT_SLUG}/users/{seller_id}/set-password",
        headers={"Authorization": f"Bearer {seller_token}"},
        json={"new_password": "NewPassword@123"}
    )
    assert r.status_code == 403, f"Expected 403 for SELLER, got {r.status_code}: {r.text}"
    print(f"PASS: SELLER gets 403 on set-password")


# ── Test 5: Auto-sync seller_profile when creating SELLER user ───────────────
def test_auto_sync_seller_profile_on_create(admin_token):
    import uuid
    test_email = f"TEST_autoseller_{uuid.uuid4().hex[:6]}@demo.com"

    # First get a store_id
    r = requests.get(
        f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores",
        headers={"Authorization": f"Bearer {admin_token}"}
    )
    assert r.status_code == 200
    stores = r.json()
    if not stores:
        pytest.skip("No stores available")
    store_id = stores[0]["id"]

    # Get seller count before
    r_before = requests.get(
        f"{BASE_URL}/api/tenants/{TENANT_SLUG}/sellers",
        headers={"Authorization": f"Bearer {admin_token}"}
    )
    assert r_before.status_code == 200
    sellers_before = r_before.json()
    count_before = len(sellers_before) if isinstance(sellers_before, list) else sellers_before.get("total", 0)

    # Create user with SELLER role
    r_create = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT_SLUG}/users",
        headers={"Authorization": f"Bearer {admin_token}"},
        json={
            "name": "Test AutoSeller",
            "email": test_email,
            "password": "Admin@123456",
            "role": "SELLER",
            "store_ids": [store_id],
            "phone": ""
        }
    )
    assert r_create.status_code in [200, 201], f"Failed to create SELLER user: {r_create.text}"
    created_user = r_create.json()
    user_id = created_user.get("id")
    print(f"Created SELLER user: {test_email} with id={user_id}")

    # Get seller count after
    r_after = requests.get(
        f"{BASE_URL}/api/tenants/{TENANT_SLUG}/sellers",
        headers={"Authorization": f"Bearer {admin_token}"}
    )
    assert r_after.status_code == 200
    sellers_after = r_after.json()
    count_after = len(sellers_after) if isinstance(sellers_after, list) else sellers_after.get("total", 0)

    assert count_after > count_before, f"seller_profile was not auto-created. Before: {count_before}, After: {count_after}"
    print(f"PASS: Auto-sync seller_profile. Before: {count_before}, After: {count_after}")

    # Cleanup: deactivate user
    if user_id:
        requests.patch(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/users/{user_id}/status",
            headers={"Authorization": f"Bearer {admin_token}"},
            json={"status": "INACTIVE"}
        )


# ── Test 6: set-password with short password should fail ─────────────────────
def test_set_password_too_short(admin_token, seller_id):
    r = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT_SLUG}/users/{seller_id}/set-password",
        headers={"Authorization": f"Bearer {admin_token}"},
        json={"new_password": "short"}
    )
    assert r.status_code in [400, 422], f"Expected 400/422 for short password, got {r.status_code}"
    print(f"PASS: Short password returns {r.status_code}")
