"""E2E queue flow after Postgres migration - checkin, call-next, start, finish with/without sale."""
import os, time, pytest, requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "https://queue-mgmt-3.preview.emergentagent.com").rstrip("/")
API = f"{BASE_URL}/api"
TIMEOUT = 90


def _login(email, password, tenant=None):
    url = f"{API}/tenants/{tenant}/auth/login" if tenant else f"{API}/auth/login"
    last = None
    for attempt in range(3):
        try:
            r = requests.post(url, json={"email": email, "password": password}, timeout=TIMEOUT)
            if r.status_code == 200:
                return r.json()
            last = f"{r.status_code} {r.text[:200]}"
        except Exception as e:
            last = str(e)
        time.sleep(5)
    pytest.fail(f"login failed {email}: {last}")

def _auth(t):
    return {"Authorization": f"Bearer {t}"}


@pytest.fixture(scope="module")
def admin():
    return _login("admin@demo.com", "Admin@123456", "demo")

@pytest.fixture(scope="module")
def seller_carlos():  # Unidade Norte, disponivel
    return _login("carlos@demo.com", "Admin@123456", "demo")


def test_full_queue_flow(admin, seller_carlos):
    admin_tok = admin["access_token"]

    # Discover Carlos' store
    r = requests.get(f"{API}/tenants/demo/sellers", headers=_auth(admin_tok), timeout=TIMEOUT)
    assert r.status_code == 200
    sellers = r.json() if isinstance(r.json(), list) else r.json().get("items", [])
    carlos = next((s for s in sellers if (s.get("user") or {}).get("email") == "carlos@demo.com"), None)
    assert carlos, "carlos not found"
    store_id = carlos.get("store_id") or carlos.get("primary_store_id")
    seller_id = carlos["id"]
    assert store_id, f"no store_id in carlos: {carlos}"

    # Read queue - should be reachable
    r = requests.get(f"{API}/tenants/demo/stores/{store_id}/queue",
                     headers=_auth(admin_tok), timeout=TIMEOUT)
    assert r.status_code == 200, r.text
    print("Queue state:", r.json())


def test_multi_tenant_isolation(admin):
    """demo admin trying to read another tenant's data must fail."""
    tok = admin["access_token"]
    r = requests.get(f"{API}/tenants/other-tenant-xyz/sellers",
                     headers=_auth(tok), timeout=TIMEOUT)
    assert r.status_code in (401, 403, 404)


def test_opportunity_flow_shape(admin):
    tok = admin["access_token"]
    r = requests.get(f"{API}/tenants/demo/reports/opportunity-flow?period_start=2025-01-01&period_end=2026-12-31",
                     headers=_auth(tok), timeout=TIMEOUT)
    assert r.status_code == 200, r.text
    d = r.json()
    totals = d.get("totals", d)
    for k in ("opportunities", "converted_opportunities", "revenue"):
        assert k in totals
        assert isinstance(totals[k], (int, float))
    print("Opportunity flow totals:", totals)
