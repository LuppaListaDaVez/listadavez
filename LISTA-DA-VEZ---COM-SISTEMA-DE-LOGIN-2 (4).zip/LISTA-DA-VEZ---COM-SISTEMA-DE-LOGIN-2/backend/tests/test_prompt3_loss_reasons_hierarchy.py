"""Prompt 3 — Motivos de perda hierárquicos (Grupo → Subgrupo → Motivo).
Cobertura: CRUD administrativo, validações de combinação, quick attendance/finish attendance,
regras de ativação, exclusão segura e isolamento de tenant.
"""

import os
import uuid
from typing import Dict, List, Tuple

import pytest
import requests


BASE_URL = os.environ.get("REACT_APP_BACKEND_URL")
TENANT = "demo"
ADMIN_EMAIL = "admin@demo.com"
ADMIN_PASS = "Admin@123456"


def _hdr(token: str) -> Dict[str, str]:
    return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}


def _uniq(prefix: str) -> str:
    return f"TEST_{prefix}_{uuid.uuid4().hex[:8]}"


@pytest.fixture(scope="module")
def env_ready():
    if not BASE_URL:
        pytest.skip("REACT_APP_BACKEND_URL não definido")


@pytest.fixture(scope="module")
def admin_token(env_ready):
    response = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT}/auth/login",
        json={"email": ADMIN_EMAIL, "password": ADMIN_PASS},
    )
    assert response.status_code == 200, f"Login admin falhou: {response.status_code} {response.text}"
    data = response.json()
    assert isinstance(data.get("access_token"), str) and data["access_token"]
    return data["access_token"]


@pytest.fixture(scope="module")
def store_and_seller(admin_token):
    headers = _hdr(admin_token)
    stores_response = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/stores", headers=headers)
    assert stores_response.status_code == 200, stores_response.text
    stores = stores_response.json()
    assert stores and stores[0].get("id")
    store_id = stores[0]["id"]

    state_response = requests.get(
        f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/queue",
        headers=headers,
    )
    assert state_response.status_code == 200, state_response.text
    state = state_response.json()
    candidates = (
        (state.get("available_sellers") or [])
        + (state.get("entries") or [])
        + (state.get("away_sellers") or [])
        + [a.get("seller") for a in (state.get("active_attendances") or []) if a.get("seller")]
    )
    assert candidates, "Nenhum vendedor encontrado para testes"

    preferred = None
    for seller in candidates:
        name = (seller.get("name") or "").casefold()
        if "jo" in name or "carl" in name:
            preferred = seller
            break
    seller = preferred or candidates[0]
    seller_id = seller.get("seller_id") or seller.get("id")
    assert seller_id

    # Best effort: deixar vendedor disponível para quick attendance
    requests.post(
        f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/queue/return",
        headers=headers,
        json={"seller_id": seller_id, "join_queue": False, "queue_id": state.get("queue", {}).get("id"), "reason": "setup_test"},
    )

    return {"store_id": store_id, "seller_id": seller_id}


@pytest.fixture
def created_items(admin_token):
    """Rastreia entidades criadas para cleanup no fim de cada teste."""
    items: List[Tuple[str, str]] = []
    yield items
    headers = _hdr(admin_token)
    for tipo, identificador in reversed(items):
        requests.delete(
            f"{BASE_URL}/api/tenants/{TENANT}/motivos-perda/{tipo}/{identificador}",
            headers=headers,
        )


def _create_group(token: str, nome: str, descricao: str = "", ativo: bool = True) -> Dict:
    response = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT}/motivos-perda/grupos",
        headers=_hdr(token),
        json={"nome": nome, "descricao": descricao or None, "ativo": ativo},
    )
    assert response.status_code == 201, response.text
    data = response.json()
    assert data.get("identificador") and data.get("nome") == nome
    return data


def _create_subgroup(token: str, group_id: str, nome: str, descricao: str = "", ativo: bool = True) -> Dict:
    response = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT}/motivos-perda/subgrupos",
        headers=_hdr(token),
        json={
            "grupo_motivo_perda_id": group_id,
            "nome": nome,
            "descricao": descricao or None,
            "ativo": ativo,
        },
    )
    assert response.status_code == 201, response.text
    data = response.json()
    assert data.get("identificador") and data.get("grupo_motivo_perda_id") == group_id
    return data


def _create_reason(
    token: str,
    subgroup_id: str,
    nome: str,
    exige_descricao: bool = False,
    limite: int = 300,
    ativo: bool = True,
) -> Dict:
    response = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT}/motivos-perda/motivos",
        headers=_hdr(token),
        json={
            "subgrupo_motivo_perda_id": subgroup_id,
            "nome": nome,
            "descricao": None,
            "ativo": ativo,
            "exige_descricao_complementar": exige_descricao,
            "limite_descricao_complementar": limite,
        },
    )
    assert response.status_code == 201, response.text
    data = response.json()
    assert data.get("identificador") and data.get("subgrupo_motivo_perda_id") == subgroup_id
    return data


def test_admin_estrutura_and_transition_message(admin_token):
    response = requests.get(
        f"{BASE_URL}/api/tenants/{TENANT}/motivos-perda/opcoes",
        headers=_hdr(admin_token),
    )
    assert response.status_code == 200, response.text
    data = response.json()
    assert "hierarquia_ativa" in data and isinstance(data.get("grupos"), list)
    assert "mensagem_sem_configuracao" in data


def test_seeded_hierarchy_exists_and_is_usable(admin_token):
    response = requests.get(
        f"{BASE_URL}/api/tenants/{TENANT}/motivos-perda/estrutura",
        headers=_hdr(admin_token),
    )
    assert response.status_code == 200, response.text
    groups = response.json().get("grupos", [])
    roupa = next((g for g in groups if (g.get("nome") or "").strip().casefold() == "roupa"), None)
    assert roupa is not None
    calcas = next((s for s in roupa.get("subgrupos", []) if (s.get("nome") or "").strip().casefold() == "calça"), None)
    assert calcas is not None
    motivo = next((m for m in calcas.get("motivos", []) if (m.get("nome") or "").strip().casefold() == "faltou tamanho"), None)
    assert motivo is not None


def test_duplicate_name_same_level_ignores_case_and_extra_spaces(admin_token, created_items):
    group_name = _uniq("DUP_GRUPO")
    g1 = _create_group(admin_token, group_name)
    created_items.append(("grupos", g1["identificador"]))

    duplicate_response = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT}/motivos-perda/grupos",
        headers=_hdr(admin_token),
        json={"nome": f"  {group_name.lower()}   ", "descricao": "x", "ativo": True},
    )
    assert duplicate_response.status_code == 409, duplicate_response.text


def test_same_name_allowed_under_different_parents(admin_token, created_items):
    g1 = _create_group(admin_token, _uniq("PARENT_A"))
    g2 = _create_group(admin_token, _uniq("PARENT_B"))
    created_items.extend([("grupos", g1["identificador"]), ("grupos", g2["identificador"])])

    same_name = _uniq("SUB_IGUAL")
    s1 = _create_subgroup(admin_token, g1["identificador"], same_name)
    s2 = _create_subgroup(admin_token, g2["identificador"], same_name)
    created_items.extend([("subgrupos", s1["identificador"]), ("subgrupos", s2["identificador"])])

    assert s1["nome"] == s2["nome"]
    assert s1["grupo_motivo_perda_id"] != s2["grupo_motivo_perda_id"]


def test_edit_move_status_and_usage_endpoints(admin_token):
    estrutura = requests.get(
        f"{BASE_URL}/api/tenants/{TENANT}/motivos-perda/estrutura",
        headers=_hdr(admin_token),
    ).json().get("grupos", [])
    assert estrutura, "Estrutura vazia; sem alvo para smoke administrativo"
    group = estrutura[0]

    edit_response = requests.put(
        f"{BASE_URL}/api/tenants/{TENANT}/motivos-perda/grupos/{group['identificador']}",
        headers=_hdr(admin_token),
        json={"nome": group.get("nome"), "descricao": "Descrição editada via teste"},
    )
    assert edit_response.status_code == 200, edit_response.text
    assert edit_response.json().get("descricao") == "Descrição editada via teste"

    move_response = requests.patch(
        f"{BASE_URL}/api/tenants/{TENANT}/motivos-perda/grupos/{group['identificador']}/mover",
        headers=_hdr(admin_token),
        json={"direcao": "baixo"},
    )
    assert move_response.status_code == 200, move_response.text
    assert "movido" in move_response.json()

    status_response = requests.patch(
        f"{BASE_URL}/api/tenants/{TENANT}/motivos-perda/grupos/{group['identificador']}/status",
        headers=_hdr(admin_token),
        json={"ativo": bool(group.get("ativo", True))},
    )
    assert status_response.status_code == 200, status_response.text
    assert status_response.json().get("identificador") == group["identificador"]

    usage_response = requests.get(
        f"{BASE_URL}/api/tenants/{TENANT}/motivos-perda/grupos/{group['identificador']}/uso",
        headers=_hdr(admin_token),
    )
    assert usage_response.status_code == 200, usage_response.text
    usage_data = usage_response.json()
    assert "quantidade_atendimentos" in usage_data and "atendimentos" in usage_data


def test_activation_blocked_when_parent_inactive(admin_token, created_items):
    group = _create_group(admin_token, _uniq("BLOCK_PARENT"), ativo=True)
    subgroup = _create_subgroup(admin_token, group["identificador"], _uniq("BLOCK_SUB"), ativo=True)
    reason = _create_reason(admin_token, subgroup["identificador"], _uniq("BLOCK_REASON"), ativo=True)
    created_items.extend([
        ("motivos", reason["identificador"]),
        ("subgrupos", subgroup["identificador"]),
        ("grupos", group["identificador"]),
    ])

    deactivate_reason = requests.patch(
        f"{BASE_URL}/api/tenants/{TENANT}/motivos-perda/motivos/{reason['identificador']}/status",
        headers=_hdr(admin_token),
        json={"ativo": False},
    )
    assert deactivate_reason.status_code == 200, deactivate_reason.text

    deactivate_group = requests.patch(
        f"{BASE_URL}/api/tenants/{TENANT}/motivos-perda/grupos/{group['identificador']}/status",
        headers=_hdr(admin_token),
        json={"ativo": False},
    )
    assert deactivate_group.status_code == 200, deactivate_group.text

    activate_reason = requests.patch(
        f"{BASE_URL}/api/tenants/{TENANT}/motivos-perda/motivos/{reason['identificador']}/status",
        headers=_hdr(admin_token),
        json={"ativo": True},
    )
    assert activate_reason.status_code == 409, activate_reason.text


def test_delete_blocked_when_has_children(admin_token, created_items):
    group = _create_group(admin_token, _uniq("DEL_GROUP"))
    subgroup = _create_subgroup(admin_token, group["identificador"], _uniq("DEL_SUB"))
    created_items.extend([("subgrupos", subgroup["identificador"]), ("grupos", group["identificador"])])

    delete_group = requests.delete(
        f"{BASE_URL}/api/tenants/{TENANT}/motivos-perda/grupos/{group['identificador']}",
        headers=_hdr(admin_token),
    )
    assert delete_group.status_code == 409, delete_group.text
    detail = delete_group.json().get("detail", {})
    assert isinstance(detail, dict) and detail.get("error") == "EXCLUSAO_BLOQUEADA_POR_FILHOS"


def test_quick_attendance_requires_and_trims_complementary_description(admin_token, store_and_seller):
    headers = _hdr(admin_token)
    estrutura = requests.get(
        f"{BASE_URL}/api/tenants/{TENANT}/motivos-perda/estrutura",
        headers=headers,
    ).json().get("grupos", [])

    target = None
    for g in estrutura:
        for s in g.get("subgrupos", []):
            for m in s.get("motivos", []):
                if m.get("exige_descricao_complementar"):
                    target = (g, s, m)
                    break
            if target:
                break
        if target:
            break
    assert target, "Nenhum motivo com exige_descricao_complementar=true encontrado"
    grupo, subgrupo, motivo = target

    missing_desc = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_and_seller['store_id']}/queue/quick-attendance",
        headers=headers,
        json={
            "seller_id": store_and_seller["seller_id"],
            "result": "NO_SALE",
            "grupo_motivo_perda_id": grupo["identificador"],
            "subgrupo_motivo_perda_id": subgrupo["identificador"],
            "motivo_perda_id": motivo["identificador"],
            "descricao_complementar": "   ",
        },
    )
    assert missing_desc.status_code == 400, missing_desc.text

    ok = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_and_seller['store_id']}/queue/quick-attendance",
        headers=headers,
        json={
            "seller_id": store_and_seller["seller_id"],
            "result": "NO_SALE",
            "grupo_motivo_perda_id": grupo["identificador"],
            "subgrupo_motivo_perda_id": subgrupo["identificador"],
            "motivo_perda_id": motivo["identificador"],
            "descricao_complementar": "   teste trim   ",
        },
    )
    assert ok.status_code == 201, ok.text
    att = ok.json().get("attendance", {})
    assert att.get("grupo_motivo_perda_id") == grupo["identificador"]
    assert att.get("subgrupo_motivo_perda_id") == subgrupo["identificador"]
    assert att.get("motivo_perda_id") == motivo["identificador"]
    assert att.get("descricao_complementar") == "teste trim"


def test_invalid_hierarchy_combination_returns_400(admin_token, store_and_seller, created_items):
    g1 = _create_group(admin_token, _uniq("INV_G1"))
    s1 = _create_subgroup(admin_token, g1["identificador"], _uniq("INV_S1"))
    m1 = _create_reason(admin_token, s1["identificador"], _uniq("INV_M1"), exige_descricao=False)
    g2 = _create_group(admin_token, _uniq("INV_G2"))
    s2 = _create_subgroup(admin_token, g2["identificador"], _uniq("INV_S2"))
    created_items.extend([
        ("motivos", m1["identificador"]),
        ("subgrupos", s1["identificador"]),
        ("subgrupos", s2["identificador"]),
        ("grupos", g1["identificador"]),
        ("grupos", g2["identificador"]),
    ])

    invalid = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_and_seller['store_id']}/queue/quick-attendance",
        headers=_hdr(admin_token),
        json={
            "seller_id": store_and_seller["seller_id"],
            "result": "NO_SALE",
            "grupo_motivo_perda_id": g1["identificador"],
            "subgrupo_motivo_perda_id": s2["identificador"],
            "motivo_perda_id": m1["identificador"],
        },
    )
    assert invalid.status_code == 400, invalid.text


def test_queue_finish_attendance_persists_historical_fields(admin_token, store_and_seller, created_items):
    headers = _hdr(admin_token)
    store_id = store_and_seller["store_id"]
    seller_id = store_and_seller["seller_id"]

    group = _create_group(admin_token, _uniq("FIN_G"))
    subgroup = _create_subgroup(admin_token, group["identificador"], _uniq("FIN_S"))
    reason = _create_reason(admin_token, subgroup["identificador"], _uniq("FIN_M"), exige_descricao=False)
    created_items.extend([
        ("motivos", reason["identificador"]),
        ("subgrupos", subgroup["identificador"]),
        ("grupos", group["identificador"]),
    ])

    queue_state = requests.get(
        f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/queue",
        headers=headers,
    ).json()
    queue_id = queue_state.get("queue", {}).get("id")
    assert queue_id

    requests.post(
        f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/queue/return",
        headers=headers,
        json={"seller_id": seller_id, "join_queue": False, "queue_id": queue_id, "reason": "setup_finish"},
    )

    join = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/queue/join",
        headers=headers,
        json={"queue_id": queue_id, "seller_id": seller_id},
    )
    assert join.status_code == 200, join.text

    start = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/queue/start-attendance",
        headers=headers,
        json={"queue_id": queue_id, "seller_id": seller_id, "source": "MANUAL"},
    )
    assert start.status_code == 200, start.text
    attendance_id = start.json().get("attendance", {}).get("id")
    assert attendance_id

    finish = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/queue/finish-attendance",
        headers={**headers, "Idempotency-Key": _uniq("idem")},
        json={
            "attendance_id": attendance_id,
            "result": "NO_SALE",
            "grupo_motivo_perda_id": group["identificador"],
            "subgrupo_motivo_perda_id": subgroup["identificador"],
            "motivo_perda_id": reason["identificador"],
            "descricao_complementar": "  histórico ok  ",
        },
    )
    assert finish.status_code == 200, finish.text
    attendance = finish.json().get("attendance", {})
    assert attendance.get("grupo_motivo_perda_id") == group["identificador"]
    assert attendance.get("subgrupo_motivo_perda_id") == subgroup["identificador"]
    assert attendance.get("motivo_perda_id") == reason["identificador"]
    assert attendance.get("grupo_motivo_perda_nome_historico") == group["nome"]
    assert attendance.get("subgrupo_motivo_perda_nome_historico") == subgroup["nome"]
    assert attendance.get("motivo_perda_nome_historico") == reason["nome"]
    assert attendance.get("descricao_complementar") == "histórico ok"


def test_reports_endpoints_include_hierarchy_or_legacy_without_break(admin_token):
    headers = _hdr(admin_token)
    att_report = requests.get(
        f"{BASE_URL}/api/tenants/{TENANT}/reports/attendances?limit=30",
        headers=headers,
    )
    assert att_report.status_code == 200, att_report.text
    rows = att_report.json()
    assert isinstance(rows, list)
    if rows:
        sample = rows[0]
        assert "loss_reason" in sample
        assert "grupo_motivo_perda_nome_historico" in sample

    loss_report = requests.get(
        f"{BASE_URL}/api/tenants/{TENANT}/reports/loss-reasons",
        headers=headers,
    )
    assert loss_report.status_code == 200, loss_report.text
    payload = loss_report.json()
    assert "items" in payload and "total_no_sale" in payload


def test_multitenant_isolation_blocks_cross_tenant_access(admin_token):
    estrutura = requests.get(
        f"{BASE_URL}/api/tenants/{TENANT}/motivos-perda/estrutura",
        headers=_hdr(admin_token),
    ).json().get("grupos", [])
    if not estrutura:
        pytest.skip("Sem grupos para validar isolamento")
    group_id = estrutura[0]["identificador"]

    # Token do tenant demo não deve acessar rota de outro tenant (demo-b)
    cross = requests.put(
        f"{BASE_URL}/api/tenants/demo-b/motivos-perda/grupos/{group_id}",
        headers=_hdr(admin_token),
        json={"nome": "NAO_DEVE_EDITAR"},
    )
    assert cross.status_code in (401, 403, 404), cross.text
