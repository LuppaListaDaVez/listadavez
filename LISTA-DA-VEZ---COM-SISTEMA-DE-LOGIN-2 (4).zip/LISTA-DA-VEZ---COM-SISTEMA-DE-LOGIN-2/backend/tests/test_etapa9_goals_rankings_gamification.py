"""Etapa 9 — Goals, Rankings, Gamification backend tests."""
import pytest
import requests
import os

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")


def get_token(email: str, password: str = "Admin@123456") -> str:
    r = requests.post(f"{BASE_URL}/api/auth/login", json={"email": email, "password": password, "tenant_slug": "demo"})
    if r.status_code == 200:
        d = r.json()
        return d.get("access_token") or d.get("token", "")
    return ""


@pytest.fixture(scope="module")
def admin_token():
    t = get_token("admin@demo.com")
    if not t:
        pytest.skip("Admin login failed")
    return t


@pytest.fixture(scope="module")
def joao_token():
    t = get_token("joao@demo.com")
    if not t:
        pytest.skip("Joao login failed")
    return t


@pytest.fixture(scope="module")
def gerente_token():
    t = get_token("gerente@demo.com")
    if not t:
        pytest.skip("Gerente login failed")
    return t


# ─── Goals ───────────────────────────────────────────────────────────────────

class TestGoals:
    """Goals CRUD and RBAC tests"""

    def test_admin_list_goals_returns_3_demo(self, admin_token):
        """Admin sees all 3 demo goals"""
        r = requests.get(f"{BASE_URL}/api/tenants/demo/goals",
                         headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text[:300]}"
        goals = r.json()
        assert isinstance(goals, list)
        assert len(goals) >= 3, f"Expected >= 3 goals, got {len(goals)}"

    def test_admin_list_goals_active(self, admin_token):
        """Goals status filter works"""
        r = requests.get(f"{BASE_URL}/api/tenants/demo/goals?status=ACTIVE",
                         headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code == 200
        goals = r.json()
        assert all(g["status"] == "ACTIVE" for g in goals), "Non-active goals returned"

    def test_create_goal_revenue(self, admin_token):
        """Create a REVENUE goal with target in cents"""
        payload = {
            "title": "TEST_Meta de Receita",
            "type": "REVENUE",
            "scope": "STORE",
            "period": "MONTHLY",
            "target_value": 500000,  # R$ 5000 in cents
        }
        r = requests.post(f"{BASE_URL}/api/tenants/demo/goals",
                          json=payload,
                          headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code in (200, 201), f"Expected 200/201, got {r.status_code}: {r.text[:300]}"
        data = r.json()
        assert data.get("target_value") == 500000
        assert data.get("type") == "REVENUE"
        assert "id" in data
        return data["id"]

    def test_get_goal_detail(self, admin_token):
        """GET goal by ID returns detail"""
        # First list to get an ID
        r = requests.get(f"{BASE_URL}/api/tenants/demo/goals",
                         headers={"Authorization": f"Bearer {admin_token}"})
        goals = r.json()
        assert len(goals) > 0
        goal_id = goals[0]["id"]

        r2 = requests.get(f"{BASE_URL}/api/tenants/demo/goals/{goal_id}",
                          headers={"Authorization": f"Bearer {admin_token}"})
        assert r2.status_code == 200
        data = r2.json()
        assert data["id"] == goal_id
        assert "target_value" in data
        assert "current_value" in data

    def test_recalculate_goal(self, admin_token):
        """POST /goals/{id}/recalculate works"""
        r = requests.get(f"{BASE_URL}/api/tenants/demo/goals?status=ACTIVE",
                         headers={"Authorization": f"Bearer {admin_token}"})
        goals = r.json()
        if not goals:
            pytest.skip("No active goals to recalculate")
        goal_id = goals[0]["id"]

        r2 = requests.post(f"{BASE_URL}/api/tenants/demo/goals/{goal_id}/recalculate",
                           headers={"Authorization": f"Bearer {admin_token}"})
        assert r2.status_code == 200, f"Expected 200, got {r2.status_code}: {r2.text[:300]}"
        data = r2.json()
        assert "current_value" in data

    # RBAC: SELLER (João) sees only own goals
    def test_seller_sees_only_own_goals(self, joao_token):
        """João (SELLER) sees only his own goals"""
        r = requests.get(f"{BASE_URL}/api/tenants/demo/goals",
                         headers={"Authorization": f"Bearer {joao_token}"})
        assert r.status_code == 200
        goals = r.json()
        # All goals should be scoped to João's seller_id or be his personal goals
        # According to spec: João sees only 1 goal (Meta de vendas João)
        for g in goals:
            # seller goals should not belong to maria or store-only goals
            assert g.get("seller_id") is not None or g.get("scope") in ("TENANT",), \
                f"Seller got non-personal goal: {g}"

    def test_seller_cannot_see_other_seller_goal(self, joao_token, admin_token):
        """João cannot see Maria's personal goal"""
        # Get all goals as admin, find one with a different seller_id
        r_admin = requests.get(f"{BASE_URL}/api/tenants/demo/goals",
                               headers={"Authorization": f"Bearer {admin_token}"})
        all_goals = r_admin.json()

        # Find João's seller_id
        r_joao = requests.get(f"{BASE_URL}/api/tenants/demo/goals",
                               headers={"Authorization": f"Bearer {joao_token}"})
        joao_goals = r_joao.json()
        joao_seller_ids = {g.get("seller_id") for g in joao_goals}

        # Find a goal with seller_id not in João's set
        other_goal = None
        for g in all_goals:
            if g.get("seller_id") and g["seller_id"] not in joao_seller_ids and g.get("scope") == "SELLER":
                other_goal = g
                break

        if not other_goal:
            pytest.skip("No other seller goal to test RBAC isolation")

        r = requests.get(f"{BASE_URL}/api/tenants/demo/goals/{other_goal['id']}",
                         headers={"Authorization": f"Bearer {joao_token}"})
        assert r.status_code == 403, f"Expected 403, got {r.status_code}"


# ─── Rankings ────────────────────────────────────────────────────────────────

class TestRankings:
    """Rankings endpoint tests"""

    def test_rankings_revenue(self, admin_token):
        """GET /rankings?criteria=REVENUE returns ordered list"""
        r = requests.get(f"{BASE_URL}/api/tenants/demo/rankings?criteria=REVENUE",
                         headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text[:300]}"
        data = r.json()
        assert "items" in data
        assert isinstance(data["items"], list)
        if len(data["items"]) > 1:
            # Check sorted by value descending
            values = [i["value"] for i in data["items"]]
            assert values == sorted(values, reverse=True), "Not sorted by value"

    def test_rankings_conversion(self, admin_token):
        """GET /rankings?criteria=CONVERSION returns conversion data"""
        r = requests.get(f"{BASE_URL}/api/tenants/demo/rankings?criteria=CONVERSION",
                         headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text[:300]}"
        data = r.json()
        assert "items" in data
        for item in data["items"]:
            assert "conversion_rate" in item or "seller_id" in item

    def test_rankings_has_position_field(self, admin_token):
        """Rankings items have position field"""
        r = requests.get(f"{BASE_URL}/api/tenants/demo/rankings?criteria=REVENUE",
                         headers={"Authorization": f"Bearer {admin_token}"})
        data = r.json()
        for item in data.get("items", []):
            assert "position" in item, f"Missing position in ranking item: {item}"

    def test_seller_can_view_rankings(self, joao_token):
        """SELLER can view rankings (see full ranking, frontend highlights own position)"""
        r = requests.get(f"{BASE_URL}/api/tenants/demo/rankings?criteria=REVENUE",
                         headers={"Authorization": f"Bearer {joao_token}"})
        # SELLER should have rankings.view_self or similar permission
        assert r.status_code in (200, 403)
        if r.status_code == 200:
            data = r.json()
            assert "items" in data


# ─── My Performance ──────────────────────────────────────────────────────────

class TestMyPerformance:
    """My Performance endpoint tests"""

    def test_joao_my_performance(self, joao_token):
        """João (SELLER) gets my-performance with kpis, goals, ranking_position, badges"""
        r = requests.get(f"{BASE_URL}/api/tenants/demo/my-performance",
                         headers={"Authorization": f"Bearer {joao_token}"})
        assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text[:300]}"
        data = r.json()
        assert "kpis" in data
        assert "goals" in data
        assert "ranking_position" in data
        assert "badges" in data
        assert "seller" in data

        kpis = data["kpis"]
        assert "sales_count" in kpis
        assert "conversion_rate" in kpis
        assert "sales_total_cents" in kpis
        assert "average_ticket_cents" in kpis

    def test_admin_my_performance_returns_404(self, admin_token):
        """Admin (no seller_profile) gets 404 from my-performance"""
        r = requests.get(f"{BASE_URL}/api/tenants/demo/my-performance",
                         headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code == 404, f"Expected 404 for admin, got {r.status_code}: {r.text[:200]}"


# ─── Gamification / Badges ───────────────────────────────────────────────────

class TestGamification:
    """Gamification badges tests"""

    def test_joao_my_badges(self, joao_token):
        """João can get his badges"""
        r = requests.get(f"{BASE_URL}/api/tenants/demo/gamification/my-badges",
                         headers={"Authorization": f"Bearer {joao_token}"})
        assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text[:300]}"
        data = r.json()
        assert isinstance(data, list), "Expected list of badges"

    def test_admin_my_badges_returns_404(self, admin_token):
        """Admin (no seller_profile) gets 404 from my-badges"""
        r = requests.get(f"{BASE_URL}/api/tenants/demo/gamification/my-badges",
                         headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code == 404, f"Expected 404 for admin, got {r.status_code}"


# ─── Regression ──────────────────────────────────────────────────────────────

class TestRegression:
    """Regression: Etapas 1-8 still working"""

    def test_queue_still_works(self, admin_token):
        """GET /stores still accessible (queue requires store_id in path)"""
        r = requests.get(f"{BASE_URL}/api/tenants/demo/stores",
                         headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code == 200, f"Stores endpoint broken: {r.status_code}"

    def test_attendances_still_works(self, admin_token):
        """GET /attendances still works"""
        r = requests.get(f"{BASE_URL}/api/tenants/demo/attendances",
                         headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code == 200, f"Attendances broken: {r.status_code}"

    def test_conversion_report_still_works(self, admin_token):
        """GET /reports/conversion still works"""
        r = requests.get(f"{BASE_URL}/api/tenants/demo/reports/conversion",
                         headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code == 200, f"Conversion report broken: {r.status_code}: {r.text[:200]}"
