"""Testes de Concorrência P1-Validação — Lista da Vez SaaS.

Valida que operações críticas da fila são seguras contra race conditions:
- join_queue: dois requests simultâneos não criam duplicata (lock + P1-Validação fix)
- start_attendance: dois requests simultâneos não criam dois atendimentos
- finish_attendance: dois finalizações simultâneas retornam apenas 1 sucesso
- Idempotência de finish: mesma Idempotency-Key retorna mesmo resultado

Todos os testes usam asyncio.gather para simular concorrência real.
"""
import asyncio
import os
import pytest
import httpx
from motor.motor_asyncio import AsyncIOMotorClient

# ── Configuração ─────────────────────────────────────────────────────────────
BACKEND_URL = os.environ.get(
    "BACKEND_URL",
    "https://queue-mgmt-3.preview.emergentagent.com",
)
API = f"{BACKEND_URL}/api"
TENANT_SLUG = "demo"
ADMIN_EMAIL = "admin@demo.com"
ADMIN_PASSWORD = "Admin@123456"

# Strip quotes from env vars (e.g., MONGO_URL="mongodb://..." in .env)
_raw_mongo = os.environ.get("MONGO_URL", "mongodb://localhost:27017")
MONGO_URL = _raw_mongo.strip("\"'")
_raw_db = os.environ.get("DB_NAME", "test_database")
DB_NAME = _raw_db.strip("\"'")


# ── Fixtures ─────────────────────────────────────────────────────────────────

@pytest.fixture(scope="function")
async def mongo():
    client = AsyncIOMotorClient(MONGO_URL)
    yield client[DB_NAME]
    client.close()


# ── Helpers ───────────────────────────────────────────────────────────────────

async def _admin_token() -> str:
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.post(f"{API}/tenants/{TENANT_SLUG}/auth/login",
                         json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD})
        assert r.status_code == 200, f"Login failed: {r.text}"
        return r.json()["access_token"]


async def _get_first_store(token: str) -> str:
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.get(f"{API}/tenants/{TENANT_SLUG}/stores",
                        headers={"Authorization": f"Bearer {token}"})
        assert r.status_code == 200
        stores = r.json()
        assert stores, "Nenhuma loja encontrada no tenant demo"
        return stores[0]["id"]


async def _get_any_active_seller(token: str, store_id: str) -> str | None:
    """Retorna seller_id de qualquer vendedor ATIVO desta loja (independente de status atual)."""
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.get(
            f"{API}/tenants/{TENANT_SLUG}/sellers",
            headers={"Authorization": f"Bearer {token}"},
        )
        if r.status_code != 200:
            return None
        sellers = r.json()
        if isinstance(sellers, dict):
            sellers = sellers.get("sellers", sellers.get("data", []))
        # Filter to active sellers in this store
        store_sellers = [s for s in sellers if s.get("store_id") == store_id and s.get("status") == "ACTIVE"]
        return store_sellers[0]["id"] if store_sellers else None


async def _cancel_active_attendances(token: str, store_id: str, seller_id: str):
    """Cancela qualquer atendimento ativo do vendedor."""
    base = f"{API}/tenants/{TENANT_SLUG}/stores/{store_id}"
    headers = {"Authorization": f"Bearer {token}"}
    async with httpx.AsyncClient(timeout=30) as c:
        state_r = await c.get(f"{base}/queue", headers=headers)
        if state_r.status_code == 200:
            active = state_r.json().get("active_attendances", [])
            for att in active:
                if att["seller_id"] == seller_id:
                    await c.post(
                        f"{API}/tenants/{TENANT_SLUG}/attendances/{att['id']}/cancel",
                        json={"reason": "Reset pré-teste de concorrência"},
                        headers=headers,
                    )
    await asyncio.sleep(0.2)


async def _reset_seller_to_available(token: str, store_id: str, seller_id: str):
    """Cancela atendimento ativo, sai da fila e coloca vendedor em AVAILABLE."""
    await _cancel_active_attendances(token, store_id, seller_id)
    base = f"{API}/tenants/{TENANT_SLUG}/stores/{store_id}"
    headers = {"Authorization": f"Bearer {token}"}
    async with httpx.AsyncClient(timeout=30) as c:
        # Sai da fila (ignora erros — pode já estar fora)
        await c.post(f"{base}/queue/leave",
                     json={"seller_id": seller_id},
                     headers=headers)
        await asyncio.sleep(0.1)
        # Retorna a AVAILABLE
        await c.post(f"{base}/queue/return",
                     json={"seller_id": seller_id, "join_queue": False, "reason": "Reset pré-teste"},
                     headers=headers)
    await asyncio.sleep(0.3)


# ── Testes de Concorrência da Fila ───────────────────────────────────────────

@pytest.mark.asyncio
async def test_join_queue_no_duplicate_concurrent():
    """
    5 requests simultâneos de join_queue para o MESMO seller.
    ESPERADO: 1 sucesso (200/201) e os demais retornam 409 (já na fila ou lock conflict).
    A fila deve ter exatamente 1 entrada para o seller após o teste.
    """
    token = await _admin_token()
    store_id = await _get_first_store(token)
    seller_id = await _get_any_active_seller(token, store_id)
    if not seller_id:
        pytest.skip("Nenhum vendedor ATIVO disponível para teste de concorrência")

    await _reset_seller_to_available(token, store_id, seller_id)

    base = f"{API}/tenants/{TENANT_SLUG}/stores/{store_id}"
    headers = {"Authorization": f"Bearer {token}"}

    async def join_request(client):
        return await client.post(
            f"{base}/queue/join",
            json={"seller_id": seller_id},
            headers=headers,
        )

    async with httpx.AsyncClient(timeout=30) as c:
        # 5 requests simultâneos
        results = await asyncio.gather(*[join_request(c) for _ in range(5)], return_exceptions=True)
        status_codes = [r.status_code for r in results if hasattr(r, "status_code")]

    ok_count = sum(1 for s in status_codes if s in (200, 201))
    conflict_count = sum(1 for s in status_codes if s == 409)

    assert ok_count == 1, (
        f"RACE CONDITION: {ok_count} requests de join_queue retornaram sucesso "
        f"(esperado 1). Status codes: {status_codes}"
    )
    assert conflict_count == len(status_codes) - 1, (
        f"Esperado {len(status_codes)-1} conflitos (409), obtido {conflict_count}. "
        f"Status codes: {status_codes}"
    )

    # Verificar via state da fila que o seller aparece exatamente 1x
    async with httpx.AsyncClient(timeout=30) as c:
        state_r = await c.get(f"{base}/queue", headers=headers)
        assert state_r.status_code == 200
        entries_for_seller = [
            e for e in state_r.json().get("entries", [])
            if e["seller_id"] == seller_id
        ]
        assert len(entries_for_seller) == 1, (
            f"Duplicata na fila: {len(entries_for_seller)} entradas para o mesmo seller"
        )

    # Cleanup
    async with httpx.AsyncClient(timeout=30) as c:
        await c.post(f"{base}/queue/leave",
                     json={"seller_id": seller_id},
                     headers=headers)


@pytest.mark.asyncio
async def test_start_attendance_no_duplicate_concurrent():
    """
    Vendedor entra na fila, depois 5 requests simultâneos de start_attendance.
    ESPERADO: 1 sucesso e os demais retornam 409 (seller_lock protege).
    """
    token = await _admin_token()
    store_id = await _get_first_store(token)
    seller_id = await _get_any_active_seller(token, store_id)
    if not seller_id:
        pytest.skip("Nenhum vendedor ATIVO disponível")

    await _reset_seller_to_available(token, store_id, seller_id)

    base = f"{API}/tenants/{TENANT_SLUG}/stores/{store_id}"
    headers = {"Authorization": f"Bearer {token}"}

    # Coloca seller na fila (posição 1)
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.post(f"{base}/queue/join",
                         json={"seller_id": seller_id},
                         headers=headers)
        assert r.status_code == 200, f"join_queue falhou: {r.text}"
    await asyncio.sleep(0.2)

    # 5 requests simultâneos de start-attendance
    async def start_request(client):
        return await client.post(
            f"{base}/queue/start-attendance",
            json={"seller_id": seller_id},
            headers=headers,
        )

    async with httpx.AsyncClient(timeout=30) as c:
        results = await asyncio.gather(*[start_request(c) for _ in range(5)], return_exceptions=True)
        status_codes = [r.status_code for r in results if hasattr(r, "status_code")]

    ok_count = sum(1 for s in status_codes if s in (200, 201))
    conflict_count = sum(1 for s in status_codes if s == 409)

    assert ok_count == 1, (
        f"RACE CONDITION: {ok_count} start-attendance retornaram sucesso. "
        f"Status codes: {status_codes}"
    )
    assert conflict_count >= 1

    # Cleanup: finalizar atendimento se estiver em andamento
    async with httpx.AsyncClient(timeout=30) as c:
        state_r = await c.get(f"{base}/queue", headers=headers)
        if state_r.status_code == 200:
            active = state_r.json().get("active_attendances", [])
            for att in active:
                if att["seller_id"] == seller_id:
                    await c.post(
                        f"{API}/tenants/{TENANT_SLUG}/attendances/{att['id']}/cancel",
                        json={"reason": "Cleanup pós-teste de concorrência"},
                        headers=headers,
                    )


@pytest.mark.asyncio
async def test_finish_attendance_duplicate_prevented():
    """
    Cria um atendimento e envia 5 requests simultâneos de finish.
    ESPERADO: 1 sucesso (200) e os demais retornam 409 (MongoDB atomic update).
    """
    token = await _admin_token()
    store_id = await _get_first_store(token)
    seller_id = await _get_any_active_seller(token, store_id)
    if not seller_id:
        pytest.skip("Nenhum vendedor ATIVO disponível")

    await _reset_seller_to_available(token, store_id, seller_id)

    base = f"{API}/tenants/{TENANT_SLUG}/stores/{store_id}"
    headers = {"Authorization": f"Bearer {token}"}

    # Setup: join + start
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.post(f"{base}/queue/join",
                         json={"seller_id": seller_id}, headers=headers)
        assert r.status_code == 200, f"join falhou: {r.text}"
        await asyncio.sleep(0.1)
        r = await c.post(f"{base}/queue/start-attendance",
                         json={"seller_id": seller_id}, headers=headers)
        assert r.status_code == 200, f"start falhou: {r.text}"
        att_id = r.json()["attendance"]["id"]

    await asyncio.sleep(0.2)

    # 5 requests simultâneos de finish (chaves diferentes = 5 tentativas reais)
    async def finish_request(client, idx):
        return await client.post(
            f"{base}/queue/finish-attendance",
            json={
                "attendance_id": att_id,
                "result": "INVALID",
                "notes": f"Teste concorrência {idx}",
            },
            headers={
                **headers,
                "Idempotency-Key": f"concurrency-finish-test-{att_id}-{idx}",
            },
        )

    async with httpx.AsyncClient(timeout=30) as c:
        results = await asyncio.gather(*[finish_request(c, i) for i in range(5)], return_exceptions=True)
        status_codes = [r.status_code for r in results if hasattr(r, "status_code")]

    ok_count = sum(1 for s in status_codes if s in (200, 201))
    conflict_count = sum(1 for s in status_codes if s == 409)

    assert ok_count == 1, (
        f"RACE CONDITION finish: {ok_count} requests retornaram sucesso. "
        f"Status codes: {status_codes}"
    )
    assert conflict_count >= 1


@pytest.mark.asyncio
async def test_finish_attendance_idempotency_key():
    """
    Dois requests de finish com a MESMA Idempotency-Key.
    ESPERADO: ambos retornam 200 com o MESMO resultado (idempotência).
    """
    token = await _admin_token()
    store_id = await _get_first_store(token)
    seller_id = await _get_any_active_seller(token, store_id)
    if not seller_id:
        pytest.skip("Nenhum vendedor ATIVO disponível")

    await _reset_seller_to_available(token, store_id, seller_id)

    base = f"{API}/tenants/{TENANT_SLUG}/stores/{store_id}"
    headers = {"Authorization": f"Bearer {token}"}

    async with httpx.AsyncClient(timeout=30) as c:
        await c.post(f"{base}/queue/join",
                     json={"seller_id": seller_id}, headers=headers)
        await asyncio.sleep(0.1)
        r = await c.post(f"{base}/queue/start-attendance",
                         json={"seller_id": seller_id}, headers=headers)
        assert r.status_code == 200
        att_id = r.json()["attendance"]["id"]

    idem_key = f"idempotency-test-{att_id}"

    async def finish_idempotent(client):
        return await client.post(
            f"{base}/queue/finish-attendance",
            json={"attendance_id": att_id, "result": "INVALID", "notes": "Teste idempotência"},
            headers={**headers, "Idempotency-Key": idem_key},
        )

    # Primeiro request
    async with httpx.AsyncClient(timeout=30) as c:
        r1 = await finish_idempotent(c)
    assert r1.status_code == 200, f"Primeiro finish falhou: {r1.text}"

    # Segundo request com mesma key — deve retornar 200 (idempotente) ou 409 (já finalizado)
    await asyncio.sleep(0.2)
    async with httpx.AsyncClient(timeout=30) as c:
        r2 = await finish_idempotent(c)
    assert r2.status_code in (200, 409), (
        f"Segundo finish com mesma key: esperado 200 ou 409, obtido {r2.status_code}. Body: {r2.text}"
    )


# ── Testes do Outbox Pattern ─────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_outbox_event_has_tenant_id(mongo):
    """Eventos no outbox devem ter tenant_id preenchido (sem vazar entre tenants)."""
    events = await mongo.event_outbox.find().sort("created_at", -1).limit(50).to_list(50)
    if not events:
        pytest.skip("Outbox vazio — nenhum evento para validar (estado limpo é OK)")
    for ev in events:
        assert ev.get("tenant_id"), f"Evento sem tenant_id: {ev.get('id')}"
        assert ev["tenant_id"] not in (None, "", "none", "null"), (
            f"tenant_id inválido '{ev['tenant_id']}' no evento {ev.get('id')}"
        )


@pytest.mark.asyncio
async def test_outbox_no_dead_letters(mongo):
    """Não deve haver eventos em DEAD_LETTER — indica falha persistente no outbox."""
    dead_letters = await mongo.event_outbox.count_documents({"status": "DEAD_LETTER"})
    assert dead_letters <= 3, (
        f"{dead_letters} eventos em DEAD_LETTER no outbox. "
        "Investigar via /api/admin/observability"
    )


@pytest.mark.asyncio
async def test_outbox_no_stale_pending(mongo):
    """Não deve haver eventos PENDING há mais de 60s (dispatcher deve ter processado)."""
    from datetime import datetime, timezone, timedelta
    threshold = (datetime.now(timezone.utc) - timedelta(seconds=60)).isoformat()
    stale = await mongo.event_outbox.count_documents({
        "status": "PENDING",
        "created_at": {"$lt": threshold},
    })
    assert stale == 0, (
        f"{stale} eventos PENDING há mais de 60s. "
        "Outbox dispatcher pode estar travado."
    )


@pytest.mark.asyncio
async def test_outbox_events_tenant_isolation(mongo):
    """Eventos do outbox devem sempre ter tenant_id — sem cross-tenant leakage."""
    events = await mongo.event_outbox.find(
        {"status": {"$in": ["PUBLISHED", "PENDING"]}}
    ).sort("created_at", -1).limit(100).to_list(100)

    if not events:
        pytest.skip("Outbox vazio — sem eventos PUBLISHED/PENDING para validar")

    for ev in events:
        assert ev.get("tenant_id"), f"Evento {ev.get('id')} sem tenant_id"


# ── Testes de Isolamento Tenant (Anti-Leakage) ───────────────────────────────

@pytest.mark.asyncio
async def test_cross_tenant_api_access_denied():
    """Usuário do tenant demo não pode acessar dados de outro tenant via API."""
    token = await _admin_token()

    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.get(
            f"{API}/tenants/outro-tenant-inexistente/dashboard/summary",
            headers={"Authorization": f"Bearer {token}"},
        )
    assert r.status_code in (403, 404), (
        f"Cross-tenant access: esperado 403/404, obtido {r.status_code}"
    )


# ── Testes de Export Jobs ────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_export_job_lifecycle():
    """Export job: QUEUED → DONE em menos de 20s, download autenticado."""
    token = await _admin_token()
    headers = {"Authorization": f"Bearer {token}"}

    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.post(
            f"{API}/tenants/{TENANT_SLUG}/reports/export/async",
            json={"report_type": "conversion"},
            headers=headers,
        )
        assert r.status_code == 200, f"Criar job falhou: {r.text}"
        job = r.json()
        assert job["status"] == "QUEUED"
        job_id = job["id"]

    # Aguardar processamento (máx 20s)
    final_job = None
    for _ in range(10):
        await asyncio.sleep(2)
        async with httpx.AsyncClient(timeout=30) as c:
            r = await c.get(
                f"{API}/tenants/{TENANT_SLUG}/reports/export/jobs/{job_id}",
                headers=headers,
            )
            assert r.status_code == 200
            j = r.json()
            if j["status"] in ("DONE", "FAILED"):
                final_job = j
                break

    assert final_job is not None, "Export job não concluiu em 20s"
    assert final_job["status"] == "DONE", (
        f"Export job falhou: {final_job.get('error')}"
    )

    # Download deve retornar 200
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.get(
            f"{API}/tenants/{TENANT_SLUG}/reports/export/jobs/{job_id}/download",
            headers=headers,
        )
        assert r.status_code == 200
        assert "csv" in r.headers.get("content-type", "").lower(), (
            f"Content-Type inesperado: {r.headers.get('content-type')}"
        )


@pytest.mark.asyncio
async def test_export_job_no_auth_denied():
    """Download de export job sem autenticação deve ser negado (403/401)."""
    token = await _admin_token()

    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.post(
            f"{API}/tenants/{TENANT_SLUG}/reports/export/async",
            json={"report_type": "loss-reasons"},
            headers={"Authorization": f"Bearer {token}"},
        )
        job_id = r.json()["id"]

    await asyncio.sleep(8)

    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.get(
            f"{API}/tenants/{TENANT_SLUG}/reports/export/jobs/{job_id}/download",
            # Sem Authorization header
        )
    assert r.status_code in (401, 403), (
        f"Download sem auth: esperado 401/403, obtido {r.status_code}"
    )


# ── Testes de Health e Dashboard ─────────────────────────────────────────────

@pytest.mark.asyncio
async def test_health_ready_fields():
    """/api/health/ready deve retornar db:connected e export_dispatcher:ok."""
    async with httpx.AsyncClient(timeout=15) as c:
        r = await c.get(f"{API}/health/ready")
    assert r.status_code == 200
    data = r.json()
    assert data["status"] == "ok"
    assert data["db"] == "connected"
    assert data.get("export_dispatcher") == "ok"


@pytest.mark.asyncio
async def test_dashboard_summary_performance():
    """Dashboard summary deve responder em < 2s (N+1 eliminado via aggregation)."""
    token = await _admin_token()
    import time

    async with httpx.AsyncClient(timeout=30) as c:
        start = time.monotonic()
        r = await c.get(
            f"{API}/tenants/{TENANT_SLUG}/dashboard/summary",
            headers={"Authorization": f"Bearer {token}"},
        )
        elapsed = time.monotonic() - start

    assert r.status_code == 200, f"Dashboard falhou: {r.text}"
    assert elapsed < 2.0, (
        f"Dashboard demorou {elapsed:.2f}s (esperado < 2.0s). "
        "Possível N+1 ainda presente."
    )


@pytest.mark.asyncio
async def test_cache_tenant_scoped():
    """Cache e observability endpoint estão acessíveis (verificação básica de saúde)."""
    token = await _admin_token()

    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.get(
            f"{API}/admin/observability",
            headers={"Authorization": f"Bearer {token}"},
        )
    # Observability requer super admin — pode retornar 403 para admin de tenant
    assert r.status_code in (200, 403), f"Observability endpoint: {r.status_code}"


# ── Suite completa ────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import subprocess
    import sys
    sys.exit(subprocess.call(["pytest", __file__, "-v", "--tb=short", "--no-header"]))
