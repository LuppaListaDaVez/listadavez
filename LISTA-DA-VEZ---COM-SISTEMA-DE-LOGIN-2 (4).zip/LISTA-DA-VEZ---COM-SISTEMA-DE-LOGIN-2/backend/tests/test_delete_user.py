"""
Tests for user delete (soft-delete) feature.
- DELETE /tenants/{slug}/users/{user_id}  (TENANT_ADMIN)
- DELETE /super-admin/tenants/{tenant_id}/users/{user_id}  (Super Admin)
"""
import pytest
import requests
import os

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")

TENANT_SLUG = "demo"
ADMIN_EMAIL = "admin@demo.com"
ADMIN_PASS = "Admin@123456"
SA_EMAIL = "admin@listadavez.com"
SA_PASS = "Admin@123456"
# User to delete (not admin)
JOAO_EMAIL = "joao@demo.com"
MARIA_EMAIL = "maria@demo.com"


def get_tenant_token(email=ADMIN_EMAIL, password=ADMIN_PASS):
    r = requests.post(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/auth/login",
                      json={"email": email, "password": password})
    if r.status_code == 200:
        return r.json().get("access_token")
    return None


def get_sa_token():
    r = requests.post(f"{BASE_URL}/api/auth/login",
                      json={"email": SA_EMAIL, "password": SA_PASS})
    if r.status_code == 200:
        return r.json().get("access_token")
    return None


@pytest.fixture(scope="module")
def admin_headers():
    token = get_tenant_token()
    if not token:
        pytest.skip("Could not get tenant admin token")
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture(scope="module")
def sa_headers():
    token = get_sa_token()
    if not token:
        pytest.skip("Could not get super admin token")
    return {"Authorization": f"Bearer {token}"}


class TestTenantDeleteUser:
    """Tests for tenant admin deleting users"""

    def test_list_users_returns_users(self, admin_headers):
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/users", headers=admin_headers)
        assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text}"
        data = r.json()
        assert isinstance(data, list)
        assert len(data) > 0, "Expected at least one user"
        print(f"Users listed: {[u['email'] for u in data]}")

    def test_list_users_excludes_deleted(self, admin_headers):
        """Verify DELETED users don't appear in the list"""
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/users", headers=admin_headers)
        assert r.status_code == 200
        data = r.json()
        for u in data:
            assert u.get("status") != "DELETED", f"DELETED user {u['email']} should not be in list"
        print(f"OK: No DELETED users in list ({len(data)} users)")

    def test_cannot_delete_self(self, admin_headers):
        """Admin cannot delete their own account"""
        # Get admin user id
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/users", headers=admin_headers)
        users = r.json()
        admin = next((u for u in users if u["email"] == ADMIN_EMAIL), None)
        if not admin:
            pytest.skip("Admin user not found in list")
        r2 = requests.delete(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/users/{admin['id']}",
                             headers=admin_headers)
        assert r2.status_code == 400, f"Expected 400, got {r2.status_code}: {r2.text}"
        print(f"OK: Cannot delete self - {r2.json()}")

    def test_delete_user_soft_delete(self, admin_headers):
        """Delete maria@demo.com and verify she's removed from list"""
        # Get users list first
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/users", headers=admin_headers)
        users = r.json()
        target = next((u for u in users if u["email"] == MARIA_EMAIL), None)
        if not target:
            pytest.skip(f"{MARIA_EMAIL} not found or already deleted")

        # Delete
        r2 = requests.delete(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/users/{target['id']}",
                             headers=admin_headers)
        assert r2.status_code == 204, f"Expected 204, got {r2.status_code}: {r2.text}"
        print(f"OK: User {MARIA_EMAIL} deleted (204)")

        # Verify excluded from list
        r3 = requests.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/users", headers=admin_headers)
        users_after = r3.json()
        assert not any(u["email"] == MARIA_EMAIL for u in users_after), \
            f"{MARIA_EMAIL} still appears in list after delete"
        print(f"OK: {MARIA_EMAIL} no longer in list")

    def test_cannot_delete_last_admin(self, admin_headers):
        """Cannot delete the last TENANT_ADMIN"""
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/users", headers=admin_headers)
        users = r.json()
        admins = [u for u in users if u.get("role") == "TENANT_ADMIN"]
        if len(admins) > 1:
            pytest.skip("Multiple admins, can't test last-admin protection this way")
        if not admins:
            pytest.skip("No admin found")
        admin = admins[0]
        r2 = requests.delete(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/users/{admin['id']}",
                             headers=admin_headers)
        # Should fail - either 400 (last admin) or 400 (self)
        assert r2.status_code == 400, f"Expected 400, got {r2.status_code}: {r2.text}"
        print(f"OK: Cannot delete last admin - {r2.json()}")


class TestSuperAdminDeleteUser:
    """Tests for super admin deleting tenant users"""

    def test_sa_list_tenants(self, sa_headers):
        r = requests.get(f"{BASE_URL}/api/super-admin/tenants", headers=sa_headers)
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, list)
        print(f"Tenants: {[t['name'] for t in data[:3]]}")

    def test_sa_list_tenant_users(self, sa_headers):
        """Get demo tenant users via super-admin endpoint"""
        r = requests.get(f"{BASE_URL}/api/super-admin/tenants", headers=sa_headers)
        tenants = r.json()
        demo = next((t for t in tenants if t["slug"] == "demo"), None)
        if not demo:
            pytest.skip("Demo tenant not found")
        r2 = requests.get(f"{BASE_URL}/api/super-admin/tenants/{demo['id']}/users", headers=sa_headers)
        assert r2.status_code == 200, f"Expected 200, got {r2.status_code}: {r2.text}"
        users = r2.json()
        assert isinstance(users, list)
        print(f"SA view demo users: {[u['email'] for u in users]}")

    def test_sa_delete_user(self, sa_headers):
        """SA can delete a user from a tenant"""
        r = requests.get(f"{BASE_URL}/api/super-admin/tenants", headers=sa_headers)
        tenants = r.json()
        demo = next((t for t in tenants if t["slug"] == "demo"), None)
        if not demo:
            pytest.skip("Demo tenant not found")
        tenant_id = demo["id"]

        r2 = requests.get(f"{BASE_URL}/api/super-admin/tenants/{tenant_id}/users", headers=sa_headers)
        users = r2.json()
        target = next((u for u in users if u["email"] == JOAO_EMAIL), None)
        if not target:
            pytest.skip(f"{JOAO_EMAIL} not found or already deleted")

        r3 = requests.delete(f"{BASE_URL}/api/super-admin/tenants/{tenant_id}/users/{target['id']}",
                             headers=sa_headers)
        assert r3.status_code == 204, f"Expected 204, got {r3.status_code}: {r3.text}"
        print(f"OK: SA deleted {JOAO_EMAIL}")

        # Verify excluded from list
        r4 = requests.get(f"{BASE_URL}/api/super-admin/tenants/{tenant_id}/users", headers=sa_headers)
        users_after = r4.json()
        assert not any(u["email"] == JOAO_EMAIL for u in users_after), \
            f"{JOAO_EMAIL} still appears after SA delete"
        print(f"OK: {JOAO_EMAIL} no longer in SA users list")
