"""P1.5 Backend regression + new health endpoint tests"""
import pytest
import requests
import os
import time

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')

# --- Health endpoints ---

def test_health_live():
    r = requests.get(f"{BASE_URL}/api/health/live")
    assert r.status_code == 200
    data = r.json()
    assert data.get("status") == "ok"
    print("PASS: /health/live")

def test_health_root():
    r = requests.get(f"{BASE_URL}/api/health")
    assert r.status_code == 200
    data = r.json()
    assert data.get("status") == "ok"
    assert "service" in data
    assert "version" in data
    print(f"PASS: /health => {data}")

def test_health_ready():
    r = requests.get(f"{BASE_URL}/api/health/ready")
    assert r.status_code == 200
    data = r.json()
    assert data.get("status") == "ok"
    assert data.get("db") == "connected"
    assert "redis" in data
    assert "export_dispatcher" in data
    assert "export_jobs_queued" in data
    print(f"PASS: /health/ready => {data}")

# --- Auth regression ---

def test_tenant_login():
    r = requests.post(f"{BASE_URL}/api/tenants/demo/auth/login",
                      json={"email": "admin@demo.com", "password": "Admin@123456"})
    assert r.status_code == 200
    data = r.json()
    assert "access_token" in data
    print("PASS: tenant login")
    return data["access_token"]

# --- Observability regression ---

def test_admin_observability():
    # login as super admin
    r = requests.post(f"{BASE_URL}/api/auth/login",
                      json={"email": "admin@listadavez.com", "password": "Admin@123456"})
    assert r.status_code == 200
    token = r.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}
    r2 = requests.get(f"{BASE_URL}/api/admin/observability", headers=headers)
    assert r2.status_code == 200
    data = r2.json()
    for field in ["websocket", "cache", "outbox", "db_status"]:
        assert field in data, f"Missing field: {field}"
    print(f"PASS: /admin/observability => keys: {list(data.keys())}")

# --- Export job regression ---

def test_export_job_async():
    # login
    r = requests.post(f"{BASE_URL}/api/tenants/demo/auth/login",
                      json={"email": "admin@demo.com", "password": "Admin@123456"})
    token = r.json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}

    # create export
    r2 = requests.post(f"{BASE_URL}/api/tenants/demo/reports/export/async",
                       json={"report_type": "attendances"},
                       headers=headers)
    assert r2.status_code in [200, 202]
    job_id = r2.json().get("id")
    assert job_id, "No job id returned"
    print(f"Export job created: {job_id}")

    # poll until DONE
    deadline = time.time() + 15
    status = None
    while time.time() < deadline:
        r3 = requests.get(f"{BASE_URL}/api/tenants/demo/reports/export/jobs/{job_id}", headers=headers)
        assert r3.status_code == 200
        status = r3.json().get("status")
        if status == "DONE":
            break
        time.sleep(1)
    assert status == "DONE", f"Export not DONE in 15s, last status={status}"
    print("PASS: export job DONE")
