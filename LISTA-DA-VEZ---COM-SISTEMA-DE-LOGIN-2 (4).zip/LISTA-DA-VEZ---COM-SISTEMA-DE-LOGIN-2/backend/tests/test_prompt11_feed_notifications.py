"""Prompt 11 — Feed Motivacional e Sistema de Notificações backend tests."""
import pytest
import requests
import os
import websockets
import asyncio

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")
WS_BASE = BASE_URL.replace("https://", "wss://").replace("http://", "ws://")

ADMIN_EMAIL = "admin@demo.com"
ADMIN_PASS = "Admin@123456"
SELLER_EMAIL = "joao@demo.com"
SELLER_PASS = "Admin@123456"
TENANT_SLUG = "demo"


@pytest.fixture(scope="module")
def admin_token():
    r = requests.post(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/auth/login",
                      json={"email": ADMIN_EMAIL, "password": ADMIN_PASS})
    assert r.status_code == 200, f"Admin login failed: {r.text}"
    return r.json()["access_token"]


@pytest.fixture(scope="module")
def seller_token():
    r = requests.post(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/auth/login",
                      json={"email": SELLER_EMAIL, "password": SELLER_PASS})
    assert r.status_code == 200, f"Seller login failed: {r.text}"
    return r.json()["access_token"]


def auth(token):
    return {"Authorization": f"Bearer {token}"}


# ─── Motivation Events Feed ───────────────────────────────────────────────────

class TestMotivationFeed:
    """Tests for GET /api/tenants/demo/motivation-events/feed"""

    def test_feed_returns_200(self, admin_token):
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/motivation-events/feed", headers=auth(admin_token))
        assert r.status_code == 200, r.text

    def test_feed_returns_list(self, admin_token):
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/motivation-events/feed", headers=auth(admin_token))
        data = r.json()
        assert isinstance(data, list), f"Expected list, got {type(data)}"

    def test_feed_event_fields(self, admin_token):
        """Each event must have required fields."""
        # First create an announcement so we have data
        requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/motivation-events/announce",
            json={"message": "TEST_feed_fields_check", "event_type": "ADMIN_ANNOUNCEMENT"},
            headers=auth(admin_token)
        )
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/motivation-events/feed", headers=auth(admin_token))
        data = r.json()
        if not data:
            pytest.skip("No events in feed")
        event = data[0]
        required_fields = ["id", "event_type", "title", "message", "seller_name", "seller_photo", "icon", "created_at"]
        for f in required_fields:
            assert f in event, f"Missing field: {f}"

    def test_feed_requires_auth(self):
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/motivation-events/feed")
        assert r.status_code in (401, 403), r.text


# ─── Admin Announcement ───────────────────────────────────────────────────────

class TestAdminAnnouncement:
    """Tests for POST /api/tenants/demo/motivation-events/announce"""

    def test_admin_can_post_announcement(self, admin_token):
        r = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/motivation-events/announce",
            json={"message": "TEST_admin_announce_123", "event_type": "ADMIN_ANNOUNCEMENT"},
            headers=auth(admin_token)
        )
        assert r.status_code == 201, r.text

    def test_announcement_seller_name_is_admin(self, admin_token):
        """seller_name should be admin's name, not 'Vendedor'."""
        r = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/motivation-events/announce",
            json={"message": "TEST_seller_name_check", "event_type": "ADMIN_ANNOUNCEMENT"},
            headers=auth(admin_token)
        )
        assert r.status_code == 201, r.text
        data = r.json()
        assert data.get("seller_name") != "Vendedor", f"seller_name should not be 'Vendedor', got: {data.get('seller_name')}"
        assert data.get("seller_name"), "seller_name should not be empty"

    def test_announcement_appears_in_feed(self, admin_token):
        """After posting, event should appear in feed."""
        unique_msg = "TEST_unique_announce_check_xyz"
        r = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/motivation-events/announce",
            json={"message": unique_msg, "event_type": "ADMIN_ANNOUNCEMENT"},
            headers=auth(admin_token)
        )
        assert r.status_code == 201
        new_id = r.json()["id"]
        feed = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/motivation-events/feed",
            headers=auth(admin_token)
        )
        ids_in_feed = [e["id"] for e in feed.json()]
        assert new_id in ids_in_feed, "New announcement not found in feed"

    def test_seller_cannot_post_announcement(self, seller_token):
        """Sellers should get 403."""
        r = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/motivation-events/announce",
            json={"message": "TEST_seller_tries_announce", "event_type": "ADMIN_ANNOUNCEMENT"},
            headers=auth(seller_token)
        )
        assert r.status_code == 403, f"Expected 403, got {r.status_code}: {r.text}"


# ─── Notifications ────────────────────────────────────────────────────────────

class TestNotifications:
    """Tests for notification endpoints."""

    def test_list_notifications_200(self, admin_token):
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/notifications", headers=auth(admin_token))
        assert r.status_code == 200, r.text

    def test_list_notifications_structure(self, admin_token):
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/notifications", headers=auth(admin_token))
        data = r.json()
        assert "notifications" in data, f"Missing 'notifications' key: {data.keys()}"
        assert "unread_count" in data
        assert "pagination" in data
        assert isinstance(data["notifications"], list)

    def test_notification_fields(self, admin_token):
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/notifications", headers=auth(admin_token))
        notifs = r.json()["notifications"]
        if not notifs:
            pytest.skip("No notifications to check fields")
        n = notifs[0]
        for field in ["id", "type", "title", "body", "is_read", "created_at"]:
            assert field in n, f"Missing field: {field}"

    def test_unread_count_endpoint(self, admin_token):
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/notifications/unread-count", headers=auth(admin_token))
        assert r.status_code == 200, r.text
        data = r.json()
        assert "count" in data, f"Missing 'count' key: {data}"
        assert isinstance(data["count"], int)

    def test_mark_all_read(self, admin_token):
        r = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/notifications/mark-all-read",
            headers=auth(admin_token)
        )
        assert r.status_code == 200, r.text
        # After mark-all-read, unread count should be 0
        count_r = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/notifications/unread-count",
            headers=auth(admin_token)
        )
        assert count_r.json()["count"] == 0

    def test_mark_single_notification_read(self, seller_token):
        """Mark a specific notification as read."""
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/notifications", headers=auth(seller_token))
        notifs = r.json()["notifications"]
        unread = [n for n in notifs if not n["is_read"]]
        if not unread:
            pytest.skip("No unread notifications for seller")
        notif_id = unread[0]["id"]
        patch_r = requests.patch(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/notifications/{notif_id}/read",
            headers=auth(seller_token)
        )
        assert patch_r.status_code == 200, patch_r.text

    def test_unread_only_filter(self, seller_token):
        r = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/notifications?unread_only=true",
            headers=auth(seller_token)
        )
        assert r.status_code == 200, r.text
        data = r.json()
        for n in data["notifications"]:
            assert not n["is_read"], f"Unread filter returned read notification: {n['id']}"


# ─── WebSocket ────────────────────────────────────────────────────────────────

class TestWebSocket:
    """WebSocket tests for /api/ws/tenants/demo"""

    def test_ws_accepts_valid_token(self, admin_token):
        """WS should accept valid JWT and return connection.ready."""
        async def _test():
            uri = f"{WS_BASE}/api/ws/tenants/{TENANT_SLUG}?token={admin_token}"
            try:
                async with websockets.connect(uri, open_timeout=10) as ws:
                    msg = await asyncio.wait_for(ws.recv(), timeout=5)
                    import json
                    data = json.loads(msg)
                    assert data.get("event_type") == "connection.ready", f"Expected connection.ready, got: {data}"
                    return True
            except Exception as e:
                raise AssertionError(f"WebSocket connection failed: {e}")
        asyncio.run(_test())

    def test_ws_rejects_no_token(self):
        """WS should reject (HTTP 403 or close code 4403) when no token."""
        async def _test():
            uri = f"{WS_BASE}/api/ws/tenants/{TENANT_SLUG}"
            try:
                async with websockets.connect(uri, open_timeout=10) as ws:
                    await ws.recv()
                    raise AssertionError("Should have been rejected")
            except websockets.exceptions.ConnectionClosedError as e:
                # Accepted via WS then closed with code 4403
                assert e.code == 4403, f"Expected code 4403, got {e.code}"
            except websockets.exceptions.InvalidStatus as e:
                # Rejected at HTTP level (403) — also acceptable
                assert e.response.status_code in (403, 401), f"Expected 403/401, got {e.response.status_code}"
            except Exception as e:
                raise AssertionError(f"Unexpected error: {e}")
        asyncio.run(_test())
