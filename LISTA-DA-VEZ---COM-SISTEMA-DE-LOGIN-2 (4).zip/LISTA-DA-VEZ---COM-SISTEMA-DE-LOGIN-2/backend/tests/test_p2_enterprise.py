"""Testes Enterprise P2 — Clean Architecture, Repositories, Use Cases, API v1, Prometheus.

Cobre:
1. Repositórios (tenant-scoped, find_by_id seguro, cross-tenant denied)
2. Use Cases (JoinQueue, FinishAttendance, CreateSale)
3. API v1 routing (/api/v1/...)
4. Métricas Prometheus (/api/metrics/prometheus)
5. Domain errors mapeados para HTTP correto
6. Segurança: IDOR, cross-tenant, broken auth
"""
import asyncio
import os
import pytest
import httpx
from motor.motor_asyncio import AsyncIOMotorClient

# ── Config ────────────────────────────────────────────────────────────────────
BACKEND_URL = os.environ.get("BACKEND_URL", "https://queue-mgmt-3.preview.emergentagent.com")
API = f"{BACKEND_URL}/api"
TENANT_SLUG = "demo"
ADMIN_EMAIL = "admin@demo.com"
ADMIN_PASSWORD = "Admin@123456"
SUPER_EMAIL = "admin@listadavez.com"
SUPER_PASSWORD = "Admin@123456"

MONGO_URL = os.environ.get("MONGO_URL", "mongodb://localhost:27017").strip("\"'")
DB_NAME = os.environ.get("DB_NAME", "test_database").strip("\"'")


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture(scope="function")
async def mongo():
    client = AsyncIOMotorClient(MONGO_URL)
    yield client[DB_NAME]
    client.close()


@pytest.fixture(scope="module")
async def admin_token():
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.post(f"{API}/tenants/{TENANT_SLUG}/auth/login",
                         json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD})
        assert r.status_code == 200
        return r.json()["access_token"]


@pytest.fixture(scope="module")
async def super_token():
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.post(f"{API}/auth/login",
                         json={"email": SUPER_EMAIL, "password": SUPER_PASSWORD})
        assert r.status_code == 200
        return r.json()["access_token"]


@pytest.fixture(scope="module")
async def store_id(admin_token):
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.get(f"{API}/tenants/{TENANT_SLUG}/stores",
                        headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code == 200
        stores = r.json()
        assert stores
        return stores[0]["id"]


# ── 1. Testes de Repositórios (via lógica de API) ────────────────────────────

@pytest.mark.asyncio
async def test_repository_store_find_by_id_for_tenant(mongo):
    """StoreRepository.find_by_id_for_tenant() retorna a loja apenas no tenant correto."""
    import sys
    sys.path.insert(0, "/app/backend")
    from infrastructure.repositories import store_repo

    stores = await mongo.stores.find({}).to_list(5)
    if not stores:
        pytest.skip("Sem lojas no banco")

    store = stores[0]
    # Busca com tenant correto — deve retornar
    result = await store_repo.find_by_id_for_tenant(store["tenant_id"], store["id"])
    assert result is not None
    assert result["id"] == store["id"]

    # Busca com tenant errado — deve retornar None (IDOR bloqueado)
    result_wrong = await store_repo.find_by_id_for_tenant("tenant-errado-fake", store["id"])
    assert result_wrong is None, "IDOR: loja retornou com tenant errado!"


@pytest.mark.asyncio
async def test_repository_attendance_tenant_isolation(admin_token, store_id):
    """AttendanceRepository: atendimento não vaza entre tenants — verificado via HTTP."""
    # Busca atendimentos do demo
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.get(
            f"{API}/tenants/{TENANT_SLUG}/stores/{store_id}/attendances?page_size=5",
            headers={"Authorization": f"Bearer {admin_token}"},
        )
    if r.status_code != 200:
        pytest.skip("Sem atendimentos disponíveis via API")

    data = r.json()
    items = data if isinstance(data, list) else data.get("items", data.get("attendances", []))

    if not items:
        pytest.skip("Sem atendimentos retornados")

    att_id = items[0]["id"]

    # Tenta acessar esse atendimento como se fosse do demo-b (cross-tenant)
    async with httpx.AsyncClient(timeout=30) as c:
        r_leak = await c.get(
            f"{API}/tenants/demo-b/stores/{store_id}/attendances?page_size=5",
            headers={"Authorization": f"Bearer {admin_token}"},
        )
    # 401 ou 403/404 — nunca 200 com dados do outro tenant
    assert r_leak.status_code in (401, 403, 404), f"Possível cross-tenant leak: {r_leak.status_code}"


@pytest.mark.asyncio
async def test_repository_sales_tenant_isolation(admin_token, store_id):
    """SalesRepository: venda não vaza entre tenants — verificado via HTTP."""
    async with httpx.AsyncClient(timeout=30) as c:
        r_leak = await c.get(
            f"{API}/tenants/demo-b/stores/{store_id}/sales?page_size=5",
            headers={"Authorization": f"Bearer {admin_token}"},
        )
    assert r_leak.status_code in (401, 403, 404), f"Cross-tenant sales leak: {r_leak.status_code}"


@pytest.mark.asyncio
async def test_repository_queue_find_entry_tenant_scoped(admin_token):
    """QueueRepository: estado da fila de outro tenant não é acessível."""
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.get(
            f"{API}/tenants/demo-b/stores/{store_id}/queue",
            headers={"Authorization": f"Bearer {admin_token}"},
        )
    assert r.status_code in (401, 403, 404), f"Queue cross-tenant: {r.status_code}"


@pytest.mark.asyncio
async def test_repository_pagination_enforced(mongo):
    """find_many_for_tenant() respeita paginação: page_size nunca > 200."""
    import sys
    sys.path.insert(0, "/app/backend")
    from infrastructure.repositories import sales_repo
    from infrastructure.repositories.base import PaginationParams

    # Tentar page_size=999 deve ser clampado para 200
    pagination = PaginationParams(page=1, page_size=999)
    assert pagination.page_size == 200, "PaginationParams não clampou page_size para 200"


# ── 2. Testes de Use Cases ────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_use_case_base_contract():
    """BaseUseCase (ABC) impede instanciação sem implementar execute()."""
    import sys
    sys.path.insert(0, "/app/backend")
    from application.base import BaseUseCase

    class IncompleteUseCase(BaseUseCase):
        pass  # não implementa execute()

    with pytest.raises(TypeError):
        IncompleteUseCase()  # deve falhar na instanciação


@pytest.mark.asyncio
async def test_use_case_context_structure():
    """UseCaseContext carrega todos os campos corretamente."""
    import sys
    sys.path.insert(0, "/app/backend")
    from application.base import UseCaseContext

    ctx = UseCaseContext(
        tenant_id="t1",
        actor_user_id="u1",
        actor_role="MANAGER",
        request_id="req-123",
        store_id="s1",
    )
    assert ctx.tenant_id == "t1"
    assert ctx.actor_user_id == "u1"
    assert ctx.actor_role == "MANAGER"
    assert ctx.request_id == "req-123"
    assert ctx.store_id == "s1"


@pytest.mark.asyncio
async def test_domain_errors_are_typed():
    """Domain errors têm code, message e status_code corretos."""
    import sys
    sys.path.insert(0, "/app/backend")
    from domain.queue import QueueConflictError, AttendanceNotFoundError, QueueLockedError
    from domain.sales import SaleNotFoundError, InvalidSaleAmountError
    from domain.tenant import TenantMismatchError, InsufficientPermissionsError

    queue_err = QueueConflictError()
    assert queue_err.status_code == 409
    assert queue_err.code == "QUEUE_SELLER_ALREADY_IN_QUEUE"

    att_err = AttendanceNotFoundError("att-123")
    assert att_err.status_code == 404

    sale_err = InvalidSaleAmountError()
    assert sale_err.status_code == 422

    tenant_err = TenantMismatchError()
    assert tenant_err.status_code == 403

    perm_err = InsufficientPermissionsError("queue.join_self")
    assert perm_err.status_code == 403
    assert "queue.join_self" in perm_err.message


# ── 3. Testes de API v1 ───────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_api_v1_health_ready():
    """/api/v1/health/ready responde 200 com db:connected."""
    async with httpx.AsyncClient(timeout=15) as c:
        r = await c.get(f"{API}/v1/health/ready")
    assert r.status_code == 200
    data = r.json()
    assert data["status"] == "ok"
    assert data["db"] == "connected"


@pytest.mark.asyncio
async def test_api_v1_tenant_login():
    """/api/v1/tenants/{slug}/auth/login funciona (alias da rota original)."""
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.post(
            f"{API}/v1/tenants/{TENANT_SLUG}/auth/login",
            json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD},
        )
    assert r.status_code == 200, f"v1 login falhou: {r.text}"
    data = r.json()
    assert "access_token" in data


@pytest.mark.asyncio
async def test_api_v1_stores_list(admin_token):
    """/api/v1/tenants/{slug}/stores retorna lojas (alias da v0)."""
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.get(
            f"{API}/v1/tenants/{TENANT_SLUG}/stores",
            headers={"Authorization": f"Bearer {admin_token}"},
        )
    assert r.status_code == 200
    stores = r.json()
    assert isinstance(stores, list)
    assert len(stores) > 0


@pytest.mark.asyncio
async def test_api_v1_queue_state(admin_token, store_id):
    """/api/v1/... queue state funciona igual à v0."""
    async with httpx.AsyncClient(timeout=30) as c:
        # v1
        r_v1 = await c.get(
            f"{API}/v1/tenants/{TENANT_SLUG}/stores/{store_id}/queue",
            headers={"Authorization": f"Bearer {admin_token}"},
        )
        # v0 (original)
        r_v0 = await c.get(
            f"{API}/tenants/{TENANT_SLUG}/stores/{store_id}/queue",
            headers={"Authorization": f"Bearer {admin_token}"},
        )

    assert r_v1.status_code == 200
    assert r_v0.status_code == 200

    # As respostas devem ser equivalentes (mesmos campos principais)
    keys_v1 = set(r_v1.json().keys())
    keys_v0 = set(r_v0.json().keys())
    assert keys_v1 == keys_v0, f"v1 e v0 têm estruturas diferentes: {keys_v1} vs {keys_v0}"


@pytest.mark.asyncio
async def test_api_v0_still_works(admin_token):
    """Rotas v0 originais continuam funcionando (sem breaking changes)."""
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.get(
            f"{API}/tenants/{TENANT_SLUG}/stores",
            headers={"Authorization": f"Bearer {admin_token}"},
        )
    assert r.status_code == 200
    assert len(r.json()) > 0


# ── 4. Testes de Métricas Prometheus ─────────────────────────────────────────

@pytest.mark.asyncio
async def test_metrics_prometheus_format(super_token):
    """/api/metrics/prometheus retorna formato Prometheus text válido."""
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.get(
            f"{API}/metrics/prometheus",
            headers={"Authorization": f"Bearer {super_token}"},
        )
    assert r.status_code == 200
    body = r.text
    assert "# HELP http_requests_total" in body
    assert "# TYPE http_requests_total counter" in body
    assert "websocket_connections_active" in body
    assert "outbox_pending_total" in body
    assert "export_jobs_failed_total" in body
    assert "http_request_duration_p95_ms" in body
    assert "http_request_duration_p50_ms" in body
    assert "sales_created_total" in body
    assert "attendance_finished_total" in body


@pytest.mark.asyncio
async def test_metrics_prometheus_unauthorized():
    """/api/metrics/prometheus requer autenticação de super admin."""
    async with httpx.AsyncClient(timeout=15) as c:
        r = await c.get(f"{API}/metrics/prometheus")
    assert r.status_code in (401, 403), f"Métricas sem auth: esperado 401/403, obtido {r.status_code}"


@pytest.mark.asyncio
async def test_metrics_prometheus_tenant_admin_denied(admin_token):
    """/api/metrics/prometheus não pode ser acessado por admin de tenant (apenas super admin)."""
    async with httpx.AsyncClient(timeout=15) as c:
        r = await c.get(
            f"{API}/metrics/prometheus",
            headers={"Authorization": f"Bearer {admin_token}"},
        )
    assert r.status_code in (401, 403), f"Métricas para tenant admin: esperado 401/403, obtido {r.status_code}"


@pytest.mark.asyncio
async def test_metrics_json_format(super_token):
    """/api/metrics retorna JSON com uptime, requests, latency, errors, business, websocket."""
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.get(
            f"{API}/metrics",
            headers={"Authorization": f"Bearer {super_token}"},
        )
    assert r.status_code == 200
    data = r.json()
    assert "uptime_seconds" in data
    assert "requests" in data
    assert "latency_ms" in data
    assert "errors" in data
    assert "business" in data
    assert "websocket" in data
    # Verificar que p50 foi adicionado
    assert "p50" in data["latency_ms"]
    assert "p95" in data["latency_ms"]
    assert "p99" in data["latency_ms"]


# ── 5. Testes de Segurança ────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_security_idor_store_cross_tenant(admin_token):
    """Usuário de um tenant não pode acessar dados de outro tenant via ID.
    401 é aceito (token inválido para outro tenant) — ainda melhor que 403."""
    async with httpx.AsyncClient(timeout=30) as c:
        r = await c.get(
            f"{API}/tenants/demo-b/stores",
            headers={"Authorization": f"Bearer {admin_token}"},
        )
    assert r.status_code in (401, 403, 404), f"Cross-tenant IDOR: {r.status_code}"


@pytest.mark.asyncio
async def test_security_invalid_jwt():
    """JWT inválido/expirado retorna 401."""
    fake_token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJmYWtlIn0.INVALIDSIG"
    async with httpx.AsyncClient(timeout=15) as c:
        r = await c.get(
            f"{API}/tenants/{TENANT_SLUG}/stores",
            headers={"Authorization": f"Bearer {fake_token}"},
        )
    assert r.status_code in (401, 403), f"JWT inválido aceito: {r.status_code}"


@pytest.mark.asyncio
async def test_security_no_auth_returns_401():
    """Endpoints protegidos retornam 401 sem token."""
    endpoints = [
        f"{API}/tenants/{TENANT_SLUG}/stores",
        f"{API}/tenants/{TENANT_SLUG}/dashboard/summary",
        f"{API}/v1/tenants/{TENANT_SLUG}/stores",
    ]
    async with httpx.AsyncClient(timeout=30) as c:
        for endpoint in endpoints:
            r = await c.get(endpoint)
            assert r.status_code in (401, 403), f"{endpoint}: esperado 401/403, obtido {r.status_code}"


@pytest.mark.asyncio
async def test_security_tenant_mismatch_v1(admin_token):
    """API v1: token do tenant demo não acessa outro tenant (401 ou 403/404)."""
    async with httpx.AsyncClient(timeout=15) as c:
        r = await c.get(
            f"{API}/v1/tenants/demo-b/stores",
            headers={"Authorization": f"Bearer {admin_token}"},
        )
    assert r.status_code in (401, 403, 404)


# ── 6. Teste de Schemas (Contracts) ──────────────────────────────────────────

@pytest.mark.asyncio
async def test_api_response_schema():
    """ApiResponse e ApiError seguem contratos de schema corretos."""
    import sys
    sys.path.insert(0, "/app/backend")
    from interfaces.v1.schemas import ApiResponse, ApiError, PaginationMeta

    response = ApiResponse.ok(data={"key": "value"}, request_id="req-1")
    assert response.data == {"key": "value"}
    assert response.request_id == "req-1"

    pagination = PaginationMeta.create(page=2, page_size=20, total=100)
    assert pagination.pages == 5
    assert pagination.page == 2

    error = ApiError(error="NOT_FOUND", message="Não encontrado.", request_id="req-2")
    assert error.error == "NOT_FOUND"
    assert error.request_id == "req-2"
