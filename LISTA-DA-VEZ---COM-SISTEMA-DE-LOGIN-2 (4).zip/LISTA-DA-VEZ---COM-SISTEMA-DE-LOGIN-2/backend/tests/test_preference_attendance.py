"""Regressões do Atendimento por Preferência.

Módulos cobertos: queue start/finish/cancel preference, store settings rule,
idempotência, escopo multi-tenant e relatório preference-attendances.
"""
import os
import time
import uuid

import pytest
import requests


BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")
TENANT = "demo"
ADMIN_EMAIL = "admin@demo.com"
ADMIN_PASS = "Admin@123456"
JOAO_EMAIL = "joao@demo.com"
CARLOS_EMAIL = "carlos@demo.com"


def _h(token: str):
    return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}


def _queue_url(ctx: dict) -> str:
    return f"{BASE_URL}/api/tenants/{TENANT}/stores/{ctx['store_id']}/queue"


def _state(ctx: dict) -> dict:
    r = requests.get(_queue_url(ctx), headers=_h(ctx["token"]), params={"queue_id": ctx["queue_id"]}, timeout=30)
    assert r.status_code == 200, r.text
    data = r.json()
    assert isinstance(data.get("entries"), list)
    return data


def _all_sellers_from_state(state: dict) -> list:
    sellers = []
    for section in ("entries", "available_sellers", "away_sellers", "serving_sellers"):
        sellers.extend(state.get(section) or [])
    for att in state.get("active_attendances") or []:
        if att.get("seller"):
            sellers.append(att["seller"])
    out = []
    seen = set()
    for s in sellers:
        sid = s.get("seller_id") or s.get("id")
        if sid and sid not in seen:
            seen.add(sid)
            out.append({**s, "seller_id": sid})
    return out


def _find_in_state(state: dict, seller_id: str):
    for section in ("entries", "available_sellers", "away_sellers", "serving_sellers"):
        for item in state.get(section) or []:
            if item.get("seller_id") == seller_id:
                return {**item, "_section": section}
    for att in state.get("active_attendances") or []:
        if att.get("seller_id") == seller_id:
            return {"_section": "active_attendances", "attendance_id": att.get("id"), **att}
    return None


def _cancel_if_serving(ctx: dict, seller_id: str):
    st = _state(ctx)
    for att in st.get("active_attendances") or []:
        if att.get("seller_id") == seller_id:
            r = requests.post(
                f"{BASE_URL}/api/tenants/{TENANT}/attendances/{att['id']}/cancel",
                headers=_h(ctx["token"]),
                json={"reason": "TEST_cleanup_preference"},
                timeout=30,
            )
            assert r.status_code in (200, 409), r.text


def _ensure_in_queue(ctx: dict, seller_id: str, attempts: int = 6):
    headers = _h(ctx["token"])
    _cancel_if_serving(ctx, seller_id)
    for _ in range(attempts):
        st = _state(ctx)
        info = _find_in_state(st, seller_id)
        assert info is not None, "Seller alvo não encontrado no estado da fila"
        section = info.get("_section")
        if section == "entries" and not info.get("em_atividade_operacional"):
            return
        if section == "entries" and info.get("em_atividade_operacional"):
            requests.post(
                f"{_queue_url(ctx)}/retornar-operacao",
                headers=headers,
                json={"seller_id": seller_id},
                timeout=30,
            )
            continue
        if section == "available_sellers":
            requests.post(
                f"{_queue_url(ctx)}/join",
                headers=headers,
                json={"seller_id": seller_id, "queue_id": ctx["queue_id"]},
                timeout=30,
            )
            continue
        if section == "away_sellers":
            if info.get("jornada_encerrada"):
                requests.post(
                    f"{_queue_url(ctx)}/nova-jornada",
                    headers=headers,
                    json={"seller_id": seller_id},
                    timeout=30,
                )
            else:
                requests.post(
                    f"{_queue_url(ctx)}/retornar-da-fora",
                    headers=headers,
                    json={"seller_id": seller_id, "queue_id": ctx["queue_id"]},
                    timeout=30,
                )
            continue
    final = _find_in_state(_state(ctx), seller_id)
    assert final and final.get("_section") == "entries" and not final.get("em_atividade_operacional")


def _normalize_test_sellers(ctx: dict):
    _ensure_in_queue(ctx, ctx["joao_seller_id"])
    _ensure_in_queue(ctx, ctx["carlos_seller_id"])


@pytest.fixture(scope="module")
def ctx():
    if not BASE_URL:
        pytest.skip("REACT_APP_BACKEND_URL não definido")

    login = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT}/auth/login",
        json={"email": ADMIN_EMAIL, "password": ADMIN_PASS},
        timeout=30,
    )
    assert login.status_code == 200, login.text
    token = login.json().get("access_token")
    assert isinstance(token, str) and token

    stores = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/stores", headers=_h(token), timeout=30)
    assert stores.status_code == 200, stores.text
    store_id = stores.json()[0]["id"]

    qstate = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/queue", headers=_h(token), timeout=30)
    assert qstate.status_code == 200, qstate.text
    state = qstate.json()
    queue_id = state.get("queue", {}).get("id")
    assert queue_id

    sellers = _all_sellers_from_state(state)
    assert sellers, "Sem vendedores no estado da fila"

    def pick_by_email(email: str):
        for s in sellers:
            if (s.get("email") or "").lower() == email:
                return s["seller_id"]
        return None

    joao_id = pick_by_email(JOAO_EMAIL)
    carlos_id = pick_by_email(CARLOS_EMAIL)
    if not joao_id or not carlos_id:
        fallback = [s["seller_id"] for s in sellers[:2]]
        assert len(fallback) == 2
        joao_id = joao_id or fallback[0]
        carlos_id = carlos_id or fallback[1]

    settings_resp = requests.get(
        f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/settings",
        headers=_h(token),
        timeout=30,
    )
    assert settings_resp.status_code == 200, settings_resp.text
    original_rule = (settings_resp.json().get("queue_settings") or {}).get("preference_return_rule", "PREVIOUS_POSITION")

    data = {
        "token": token,
        "store_id": store_id,
        "queue_id": queue_id,
        "joao_seller_id": joao_id,
        "carlos_seller_id": carlos_id,
        "original_preference_rule": original_rule,
    }
    _normalize_test_sellers(data)

    yield data

    requests.put(
        f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/settings",
        headers=_h(token),
        json={"queue_settings": {"preference_return_rule": original_rule}},
        timeout=30,
    )
    _normalize_test_sellers(data)


def _start_preference(ctx: dict, seller_id: str, customer: str, idem_key: str):
    return requests.post(
        f"{_queue_url(ctx)}/start-preference-attendance",
        headers={**_h(ctx["token"]), "Idempotency-Key": idem_key},
        json={
            "queue_id": ctx["queue_id"],
            "seller_id": seller_id,
            "customer_name": customer,
            "customer_phone": "11999999999",
            "notes": "Teste preferencia",
        },
        timeout=30,
    )


def _finish_preference(ctx: dict, attendance_id: str):
    return requests.post(
        f"{_queue_url(ctx)}/finish-attendance",
        headers={**_h(ctx["token"]), "Idempotency-Key": f"finish-{attendance_id}-{uuid.uuid4()}"},
        json={"attendance_id": attendance_id, "result": "INVALID", "notes": "Fechando teste preferência"},
        timeout=30,
    )


def test_start_preference_requires_customer_name(ctx):
    """Valida erro 400 quando cliente não é informado no start preference."""
    _normalize_test_sellers(ctx)
    r = requests.post(
        f"{_queue_url(ctx)}/start-preference-attendance",
        headers={**_h(ctx["token"]), "Idempotency-Key": f"empty-name-{uuid.uuid4()}"},
        json={"queue_id": ctx["queue_id"], "seller_id": ctx["carlos_seller_id"], "customer_name": "   "},
        timeout=30,
    )
    assert r.status_code == 400, r.text


def test_start_preference_rejects_seller_outside_queue(ctx):
    """Valida bloqueio para vendedor fora da fila."""
    _normalize_test_sellers(ctx)
    headers = _h(ctx["token"])
    leave = requests.post(
        f"{_queue_url(ctx)}/leave",
        headers=headers,
        json={"queue_id": ctx["queue_id"], "seller_id": ctx["joao_seller_id"], "reason": "TEST_out_of_queue"},
        timeout=30,
    )
    assert leave.status_code == 200, leave.text

    r = _start_preference(ctx, ctx["joao_seller_id"], "Cliente Fora Fila", f"outside-queue-{uuid.uuid4()}")
    assert r.status_code == 409, r.text
    detail = r.json().get("detail")
    if isinstance(detail, dict):
        assert detail.get("error") in {"VENDEDOR_INDISPONIVEL", "VENDEDOR_FORA_DA_FILA"}

    _ensure_in_queue(ctx, ctx["joao_seller_id"])


def test_start_preference_idempotency_and_finish_previous_position(ctx):
    """Valida start idempotente + finish aplicando retorno PREVIOUS_POSITION sem posição fantasma."""
    _normalize_test_sellers(ctx)

    # Garante regra padrão do escopo deste teste
    set_rule = requests.put(
        f"{BASE_URL}/api/tenants/{TENANT}/stores/{ctx['store_id']}/settings",
        headers=_h(ctx["token"]),
        json={"queue_settings": {"preference_return_rule": "PREVIOUS_POSITION"}},
        timeout=30,
    )
    assert set_rule.status_code == 200, set_rule.text

    before = _state(ctx)
    target_entry = next(e for e in before["entries"] if e["seller_id"] == ctx["carlos_seller_id"])
    original_pos = target_entry["position"]

    idem_key = f"pref-idem-{int(time.time())}-{uuid.uuid4()}"
    start_1 = _start_preference(ctx, ctx["carlos_seller_id"], "Cliente Idempotente", idem_key)
    assert start_1.status_code == 200, start_1.text
    data_1 = start_1.json()
    att_1 = data_1["attendance"]
    assert att_1["is_preference"] is True
    assert att_1["source"] == "PREFERENCE"
    assert att_1["origin"] == "PREFERENCE"
    assert att_1["attendance_type"] == "PREFERENCE"
    assert att_1["preference_previous_position"] == original_pos
    assert att_1["preference_queue_snapshot"]["queue_size_at_start"] >= 1

    start_2 = _start_preference(ctx, ctx["carlos_seller_id"], "Cliente Idempotente", idem_key)
    assert start_2.status_code == 200, start_2.text
    att_2 = start_2.json()["attendance"]
    assert att_2["id"] == att_1["id"]

    during = _state(ctx)
    active_for_target = [a for a in during.get("active_attendances") or [] if a.get("seller_id") == ctx["carlos_seller_id"]]
    assert len(active_for_target) == 1
    assert active_for_target[0].get("is_preference") is True
    assert all(e["seller_id"] != ctx["carlos_seller_id"] for e in during["entries"])

    finish = _finish_preference(ctx, att_1["id"])
    assert finish.status_code == 200, finish.text
    finished = finish.json()["attendance"]
    assert finished["preference_return_applied"] is True
    assert finished["preference_return_rule_applied"] == "PREVIOUS_POSITION"
    assert finished["preference_final_position"] is not None

    after = _state(ctx)
    positions = [e["position"] for e in after["entries"]]
    assert len(positions) == len(set(positions))
    seller_rows = [e for e in after["entries"] if e["seller_id"] == ctx["carlos_seller_id"]]
    assert len(seller_rows) == 1


def test_preference_cancel_applies_return_and_unserves(ctx):
    """Valida cancelamento preference aplicando retorno e removendo status SERVING."""
    _normalize_test_sellers(ctx)
    start = _start_preference(ctx, ctx["joao_seller_id"], "Cliente Cancelamento", f"pref-cancel-{uuid.uuid4()}")
    assert start.status_code == 200, start.text
    attendance_id = start.json()["attendance"]["id"]

    cancel = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT}/attendances/{attendance_id}/cancel",
        headers=_h(ctx["token"]),
        json={"reason": "Cancelamento de teste"},
        timeout=30,
    )
    assert cancel.status_code == 200, cancel.text
    cancelled = cancel.json()["attendance"]
    assert cancelled["status"] == "CANCELLED"
    assert cancelled["preference_return_applied"] is True

    after = _state(ctx)
    seller_entry = [e for e in after["entries"] if e["seller_id"] == ctx["joao_seller_id"]]
    assert len(seller_entry) == 1
    assert not any(a.get("seller_id") == ctx["joao_seller_id"] for a in after.get("active_attendances") or [])


def test_preference_rejects_operational_activity(ctx):
    """Valida bloqueio para vendedor em atividade operacional."""
    _normalize_test_sellers(ctx)
    headers = _h(ctx["token"])
    sair = requests.post(
        f"{_queue_url(ctx)}/sair-da-fila",
        headers=headers,
        json={"seller_id": ctx["joao_seller_id"], "motivo": "ATIVIDADE_OPERACIONAL", "queue_id": ctx["queue_id"]},
        timeout=30,
    )
    assert sair.status_code == 200, sair.text

    r = _start_preference(ctx, ctx["joao_seller_id"], "Cliente Operacao", f"pref-oper-{uuid.uuid4()}")
    assert r.status_code == 409, r.text
    detail = r.json().get("detail")
    if isinstance(detail, dict):
        assert detail.get("error") == "VENDEDOR_EM_PAUSA"

    voltar = requests.post(
        f"{_queue_url(ctx)}/retornar-operacao",
        headers=headers,
        json={"seller_id": ctx["joao_seller_id"]},
        timeout=30,
    )
    assert voltar.status_code == 200, voltar.text


def test_preference_rejects_jornada_encerrada(ctx):
    """Valida bloqueio quando jornada foi encerrada."""
    _normalize_test_sellers(ctx)
    headers = _h(ctx["token"])
    sair = requests.post(
        f"{_queue_url(ctx)}/sair-da-fila",
        headers=headers,
        json={"seller_id": ctx["carlos_seller_id"], "motivo": "ENCERRAR_DIA", "queue_id": ctx["queue_id"]},
        timeout=30,
    )
    assert sair.status_code == 200, sair.text

    r = _start_preference(ctx, ctx["carlos_seller_id"], "Cliente Jornada", f"pref-jornada-{uuid.uuid4()}")
    assert r.status_code == 409, r.text
    detail = r.json().get("detail")
    if isinstance(detail, dict):
        assert detail.get("error") in {"VENDEDOR_INDISPONIVEL", "JORNADA_ENCERRADA"}

    nova = requests.post(
        f"{_queue_url(ctx)}/nova-jornada",
        headers=headers,
        json={"seller_id": ctx["carlos_seller_id"]},
        timeout=30,
    )
    assert nova.status_code == 200, nova.text
    _ensure_in_queue(ctx, ctx["carlos_seller_id"])


def test_preference_consume_turn_rule_returns_to_end(ctx):
    """Valida regra CONSUME_TURN (Perder a vez) com retorno ao fim e flag consumida."""
    _normalize_test_sellers(ctx)
    set_rule = requests.put(
        f"{BASE_URL}/api/tenants/{TENANT}/stores/{ctx['store_id']}/settings",
        headers=_h(ctx["token"]),
        json={"queue_settings": {"preference_return_rule": "CONSUME_TURN"}},
        timeout=30,
    )
    assert set_rule.status_code == 200, set_rule.text

    before = _state(ctx)
    max_before = max((e["position"] for e in before["entries"]), default=0)

    start = _start_preference(ctx, ctx["joao_seller_id"], "Cliente Perde Vez", f"pref-consume-{uuid.uuid4()}")
    assert start.status_code == 200, start.text
    att = start.json()["attendance"]
    assert att["preference_return_rule"] == "CONSUME_TURN"

    finish = _finish_preference(ctx, att["id"])
    assert finish.status_code == 200, finish.text
    finished = finish.json()["attendance"]
    assert finished["preference_return_rule_applied"] == "CONSUME_TURN"
    assert finished["preference_turn_consumed"] is True

    after = _state(ctx)
    target = next(e for e in after["entries"] if e["seller_id"] == ctx["joao_seller_id"])
    max_after = max((e["position"] for e in after["entries"]), default=0)
    assert target["position"] == max_after
    assert max_after >= max_before


def test_preference_emits_queue_events(ctx):
    """Valida emissão de eventos de preferência e queue.updated após start/finish."""
    _normalize_test_sellers(ctx)
    start = _start_preference(ctx, ctx["carlos_seller_id"], "Cliente Eventos", f"pref-events-{uuid.uuid4()}")
    assert start.status_code == 200, start.text
    attendance_id = start.json()["attendance"]["id"]

    finish = _finish_preference(ctx, attendance_id)
    assert finish.status_code == 200, finish.text

    events = requests.get(
        f"{_queue_url(ctx)}/events",
        headers=_h(ctx["token"]),
        params={"queue_id": ctx["queue_id"], "limit": 40},
        timeout=30,
    )
    assert events.status_code == 200, events.text
    ev_types = [e.get("event_type") for e in events.json()]
    assert "PREFERENCE_ATTENDANCE_STARTED" in ev_types
    assert "PREFERENCE_RETURN_APPLIED" in ev_types
    assert "ATTENDANCE_FINISHED" in ev_types


def test_preference_report_payload_and_exports(ctx):
    """Valida payload do relatório de preferência e exportações CSV/XLSX."""
    report = requests.get(
        f"{BASE_URL}/api/tenants/{TENANT}/reports/preference-attendances",
        headers=_h(ctx["token"]),
        timeout=30,
    )
    assert report.status_code == 200, report.text
    data = report.json()
    assert isinstance(data.get("totals"), dict)
    assert isinstance(data.get("items"), list)
    assert isinstance(data.get("by_rule"), dict)
    assert isinstance(data.get("top_sellers"), list)
    ids = [it.get("id") for it in data["items"] if it.get("id")]
    assert len(ids) == len(set(ids))

    csv = requests.get(
        f"{BASE_URL}/api/tenants/{TENANT}/reports/preference-attendances/export.csv",
        headers=_h(ctx["token"]),
        timeout=30,
    )
    assert csv.status_code == 200, csv.text
    assert "text/csv" in csv.headers.get("content-type", "")

    xlsx = requests.get(
        f"{BASE_URL}/api/tenants/{TENANT}/reports/preference-attendances/export.xlsx",
        headers=_h(ctx["token"]),
        timeout=30,
    )
    assert xlsx.status_code == 200, xlsx.text
    assert xlsx.content[:2] == b"PK"


def test_multi_tenant_scope_blocks_cross_tenant_access(ctx):
    """Valida bloqueio de escopo quando token demo tenta rota de outro tenant slug."""
    r = requests.get(
        f"{BASE_URL}/api/tenants/demo-b/stores/{ctx['store_id']}/queue",
        headers=_h(ctx["token"]),
        timeout=30,
    )
    assert r.status_code in (401, 403, 404), r.text


def test_seller_can_start_preference_for_self_outside_turn_and_cannot_target_other(ctx):
    """Valida perfil SELLER: vê/inicia para si, mesmo fora do topo, e não envia outro seller_id."""
    _normalize_test_sellers(ctx)
    state = _state(ctx)
    entries = state.get("entries") or []
    others = [e["seller_id"] for e in entries if e.get("seller_id") not in {ctx["joao_seller_id"], ctx["carlos_seller_id"]}]
    reorder = requests.patch(
        f"{_queue_url(ctx)}/reorder",
        headers=_h(ctx["token"]),
        json={"queue_id": ctx["queue_id"], "ordered_seller_ids": [ctx["joao_seller_id"], ctx["carlos_seller_id"], *others]},
        timeout=30,
    )
    assert reorder.status_code in (200, 409), reorder.text

    seller_login = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT}/auth/login",
        json={"email": CARLOS_EMAIL, "password": ADMIN_PASS},
        timeout=30,
    )
    assert seller_login.status_code == 200, seller_login.text
    seller_token = seller_login.json()["access_token"]

    other = requests.post(
        f"{_queue_url(ctx)}/start-preference-attendance",
        headers={**_h(seller_token), "Idempotency-Key": f"seller-other-{uuid.uuid4()}"},
        json={"queue_id": ctx["queue_id"], "seller_id": ctx["joao_seller_id"], "customer_name": "Cliente outro vendedor"},
        timeout=30,
    )
    assert other.status_code == 403, other.text

    own = requests.post(
        f"{_queue_url(ctx)}/start-preference-attendance",
        headers={**_h(seller_token), "Idempotency-Key": f"seller-self-{uuid.uuid4()}"},
        json={"queue_id": ctx["queue_id"], "customer_name": "Cliente próprio preferência"},
        timeout=30,
    )
    assert own.status_code == 200, own.text
    att = own.json()["attendance"]
    assert att["is_preference"] is True
    assert att["attendance_type"] == "PREFERENCE"
    assert att["seller_id"] == ctx["carlos_seller_id"]
    assert att.get("preference_previous_position", 0) >= 2

    finish = requests.post(
        f"{_queue_url(ctx)}/finish-attendance",
        headers={**_h(seller_token), "Idempotency-Key": f"seller-self-finish-{uuid.uuid4()}"},
        json={"attendance_id": att["id"], "result": "INVALID", "notes": "Teste vendedor preferência"},
        timeout=30,
    )
    assert finish.status_code == 200, finish.text
    assert finish.json()["attendance"].get("preference_return_applied") is True