"""Prompt 71 — Goals in seller panel (backend regression).

Modules/features under test:
- goals routes/service seller visibility and PT-BR status behavior
- my-performance goals source consistency
- admin regression for create/recalculate/list goals
"""
from datetime import date, timedelta
import os
import time

import pytest
import requests


BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")
TENANT_SLUG = "demo"
ADMIN_EMAIL = "admin@demo.com"
SELLER_EMAIL = "joao@demo.com"
PASSWORD = "Admin@123456"

ALLOWED_PT_LABELS = {
    "Agendada",
    "Em andamento",
    "Atingida",
    "Encerrada sem atingir",
    "Pausada",
    "Cancelada",
}


def _auth_token(email: str, password: str = PASSWORD) -> str:
    resp = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT_SLUG}/auth/login",
        json={"email": email, "password": password},
        timeout=20,
    )
    if resp.status_code != 200:
        return ""
    data = resp.json()
    return data.get("access_token") or data.get("token") or ""


def _month_window() -> tuple[str, str]:
    today = date.today()
    start = today.replace(day=1)
    if start.month == 12:
        next_month = start.replace(year=start.year + 1, month=1, day=1)
    else:
        next_month = start.replace(month=start.month + 1, day=1)
    end = next_month - timedelta(days=1)
    return start.isoformat(), end.isoformat()


def _next_month_window() -> tuple[str, str]:
    today = date.today().replace(day=1)
    if today.month == 12:
        nm = today.replace(year=today.year + 1, month=1, day=1)
    else:
        nm = today.replace(month=today.month + 1, day=1)
    if nm.month == 12:
        after = nm.replace(year=nm.year + 1, month=1, day=1)
    else:
        after = nm.replace(month=nm.month + 1, day=1)
    return nm.isoformat(), (after - timedelta(days=1)).isoformat()


@pytest.fixture(scope="module")
def admin_session():
    if not BASE_URL:
        pytest.skip("REACT_APP_BACKEND_URL missing")
    token = _auth_token(ADMIN_EMAIL)
    if not token:
        pytest.skip("Admin login failed")
    s = requests.Session()
    s.headers.update({"Authorization": f"Bearer {token}", "Content-Type": "application/json"})
    return s


@pytest.fixture(scope="module")
def seller_session():
    if not BASE_URL:
        pytest.skip("REACT_APP_BACKEND_URL missing")
    token = _auth_token(SELLER_EMAIL)
    if not token:
        pytest.skip("Seller login failed")
    s = requests.Session()
    s.headers.update({"Authorization": f"Bearer {token}", "Content-Type": "application/json"})
    return s


@pytest.fixture(scope="module")
def seller_profile(admin_session):
    resp = admin_session.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/sellers", timeout=20)
    assert resp.status_code == 200, resp.text
    sellers = resp.json()
    joao = next((s for s in sellers if (s.get("user") or {}).get("email") == SELLER_EMAIL), None)
    assert joao, "Seller profile for joao@demo.com not found"
    return joao


@pytest.fixture(scope="module")
def other_seller_profile(admin_session, seller_profile):
    resp = admin_session.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/sellers", timeout=20)
    assert resp.status_code == 200
    sellers = resp.json()
    other = next((s for s in sellers if s.get("id") != seller_profile["id"]), None)
    assert other, "No secondary seller profile available for isolation test"
    return other


@pytest.fixture(scope="module")
def seeded_goals(admin_session, seller_profile, other_seller_profile):
    created_ids = []
    suffix = str(int(time.time()))
    start, end = _month_window()
    future_start, future_end = _next_month_window()

    def _create(payload: dict) -> dict:
        r = admin_session.post(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/goals", json=payload, timeout=25)
        assert r.status_code in (200, 201), r.text
        data = r.json()
        created_ids.append(data["id"])
        return data

    seller_goal = _create({
        "title": f"TEST_P71_SELLER_{suffix}",
        "type": "SALES_COUNT",
        "scope": "SELLER",
        "seller_id": seller_profile["id"],
        "period": "CUSTOM",
        "target_value": 999999,
        "period_start": start,
        "period_end": end,
    })

    store_goal = _create({
        "title": f"TEST_P71_STORE_{suffix}",
        "type": "ATTENDANCES",
        "scope": "STORE",
        "store_id": seller_profile.get("store_id"),
        "period": "CUSTOM",
        "target_value": 999999,
        "period_start": start,
        "period_end": end,
    })

    team_goal = None
    if seller_profile.get("team_id"):
        team_goal = _create({
            "title": f"TEST_P71_TEAM_{suffix}",
            "type": "SALES_COUNT",
            "scope": "TEAM",
            "team_id": seller_profile.get("team_id"),
            "period": "CUSTOM",
            "target_value": 999999,
            "period_start": start,
            "period_end": end,
        })

    other_seller_goal = _create({
        "title": f"TEST_P71_OTHER_{suffix}",
        "type": "SALES_COUNT",
        "scope": "SELLER",
        "seller_id": other_seller_profile["id"],
        "period": "CUSTOM",
        "target_value": 999999,
        "period_start": start,
        "period_end": end,
    })

    scheduled_goal = _create({
        "title": f"TEST_P71_SCHEDULED_{suffix}",
        "type": "SALES_COUNT",
        "scope": "SELLER",
        "seller_id": seller_profile["id"],
        "period": "CUSTOM",
        "target_value": 999999,
        "period_start": future_start,
        "period_end": future_end,
    })

    yield {
        "seller_goal": seller_goal,
        "store_goal": store_goal,
        "team_goal": team_goal,
        "other_seller_goal": other_seller_goal,
        "scheduled_goal": scheduled_goal,
    }

    for gid in created_ids:
        try:
            admin_session.patch(
                f"{BASE_URL}/api/tenants/{TENANT_SLUG}/goals/{gid}/status",
                json={"action": "CANCEL", "reason": "TEST_CLEANUP"},
                timeout=20,
            )
        except Exception:
            pass


class TestSellerGoalsPanelBackend:
    """Seller goals applicability, PT-BR labels/filter, consistency and regression checks."""

    def test_seller_gets_applicable_goals_only(self, seller_session, seller_profile, seeded_goals):
        resp = seller_session.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/goals", timeout=20)
        assert resp.status_code == 200, resp.text
        goals = resp.json()

        ids = {g["id"] for g in goals}
        assert seeded_goals["seller_goal"]["id"] in ids
        assert seeded_goals["store_goal"]["id"] in ids
        if seeded_goals["team_goal"]:
            assert seeded_goals["team_goal"]["id"] in ids
        assert seeded_goals["other_seller_goal"]["id"] not in ids

        for goal in goals:
            if goal.get("scope") == "SELLER":
                assert goal.get("seller_id") == seller_profile["id"], "Other seller personal goal leaked"

    def test_goals_return_ptbr_labels_and_progress_alias(self, seller_session):
        resp = seller_session.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/goals", timeout=20)
        assert resp.status_code == 200
        for goal in resp.json():
            assert goal.get("status_label") in ALLOWED_PT_LABELS
            assert goal.get("progress_pct") == goal.get("progress_percent")

    def test_goals_status_filter_accepts_internal_and_ptbr(self, seller_session):
        active = seller_session.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/goals?status=ACTIVE", timeout=20)
        assert active.status_code == 200, active.text
        active_ids = {g["id"] for g in active.json()}
        assert all(g.get("status") == "ACTIVE" for g in active.json())

        pt = seller_session.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/goals?status=Em%20andamento", timeout=20)
        assert pt.status_code == 200, pt.text
        pt_ids = {g["id"] for g in pt.json()}
        assert all(g.get("status") == "ACTIVE" for g in pt.json())
        assert pt_ids == active_ids

    def test_scheduled_status_filter_accepts_ptbr(self, seller_session, seeded_goals):
        pt = seller_session.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/goals?status=Agendada", timeout=20)
        assert pt.status_code == 200, pt.text
        ids = {g["id"] for g in pt.json()}
        assert seeded_goals["scheduled_goal"]["id"] in ids
        assert all(g.get("status") == "SCHEDULED" for g in pt.json())

    def test_my_performance_uses_same_goal_source(self, seller_session, seeded_goals):
        list_resp = seller_session.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/goals", timeout=20)
        perf_resp = seller_session.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/my-performance", timeout=20)
        assert list_resp.status_code == 200
        assert perf_resp.status_code == 200

        list_goals = {g["id"]: g for g in list_resp.json()}
        perf_goals = {g["id"]: g for g in perf_resp.json().get("goals", [])}

        ref_id = seeded_goals["seller_goal"]["id"]
        assert ref_id in list_goals
        assert ref_id in perf_goals
        assert perf_goals[ref_id]["current_value"] == list_goals[ref_id]["current_value"]
        assert perf_goals[ref_id]["progress_percent"] == list_goals[ref_id]["progress_percent"]
        assert perf_goals[ref_id]["status_label"] == list_goals[ref_id]["status_label"]
        assert perf_goals[ref_id]["progress_pct"] == perf_goals[ref_id]["progress_percent"]

        assert seeded_goals["other_seller_goal"]["id"] not in perf_goals

    def test_seller_cannot_recalculate_but_my_performance_still_updates(self, seller_session, seeded_goals):
        goal_id = seeded_goals["seller_goal"]["id"]
        recalc = seller_session.post(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/goals/{goal_id}/recalculate", timeout=20)
        assert recalc.status_code == 403

        perf = seller_session.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/my-performance", timeout=20)
        assert perf.status_code == 200
        goals = perf.json().get("goals", [])
        own = next((g for g in goals if g.get("id") == goal_id), None)
        assert own is not None
        assert isinstance(own.get("current_value"), int)
        assert isinstance(own.get("progress_percent"), int)
        assert own.get("status_label") in ALLOWED_PT_LABELS

    def test_admin_regression_list_create_recalculate_still_works(self, admin_session, seller_profile):
        list_resp = admin_session.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/goals", timeout=20)
        assert list_resp.status_code == 200, list_resp.text
        assert isinstance(list_resp.json(), list)

        start, end = _month_window()
        payload = {
            "title": f"TEST_P71_ADMIN_REG_{int(time.time())}",
            "type": "SALES_COUNT",
            "scope": "SELLER",
            "seller_id": seller_profile["id"],
            "period": "CUSTOM",
            "target_value": 999999,
            "period_start": start,
            "period_end": end,
        }
        created = admin_session.post(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/goals", json=payload, timeout=25)
        assert created.status_code in (200, 201), created.text
        gid = created.json()["id"]

        recalc = admin_session.post(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/goals/{gid}/recalculate", timeout=20)
        assert recalc.status_code == 200, recalc.text
        body = recalc.json()
        assert body.get("status_label") in ALLOWED_PT_LABELS
        assert body.get("progress_pct") == body.get("progress_percent")

        admin_session.patch(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/goals/{gid}/status",
            json={"action": "CANCEL", "reason": "TEST_CLEANUP"},
            timeout=20,
        )
