"""Tests for Etapas 7/8: Dashboard enriched, Reports, CSV Export."""
import pytest
import requests
import os

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")

ADMIN = {"email": "admin@demo.com", "password": "Admin@123456"}
GERENTE = {"email": "gerente@demo.com", "password": "Admin@123456"}
SUPERVISOR = {"email": "supervisor@demo.com", "password": "Admin@123456"}
SELLER = {"email": "joao@demo.com", "password": "Admin@123456"}
SLUG = "demo"


def login(creds):
    r = requests.post(f"{BASE_URL}/api/auth/login", json=creds)
    assert r.status_code == 200, f"Login failed: {r.text}"
    return r.json()["access_token"]


@pytest.fixture(scope="module")
def admin_token():
    return login(ADMIN)


@pytest.fixture(scope="module")
def gerente_token():
    return login(GERENTE)


@pytest.fixture(scope="module")
def supervisor_token():
    return login(SUPERVISOR)


@pytest.fixture(scope="module")
def seller_token():
    return login(SELLER)


def auth(token):
    return {"Authorization": f"Bearer {token}"}


# ─── Dashboard Summary ────────────────────────────────────────────────────────

class TestDashboardSummary:
    def test_admin_gets_dashboard(self, admin_token):
        r = requests.get(f"{BASE_URL}/api/tenants/{SLUG}/dashboard/summary", headers=auth(admin_token))
        assert r.status_code == 200, r.text
        data = r.json()
        assert "kpis" in data
        assert "sellers_status" in data
        assert "week_trend" in data
        kpis = data["kpis"]
        assert "atendimentos_hoje" in kpis
        assert "vendas_hoje" in kpis
        assert "conversao_pct" in kpis
        assert "ticket_medio_cents" in kpis
        assert "tempo_medio_segundos" in kpis

    def test_week_trend_has_7_days(self, admin_token):
        r = requests.get(f"{BASE_URL}/api/tenants/{SLUG}/dashboard/summary", headers=auth(admin_token))
        assert r.status_code == 200
        week = r.json()["week_trend"]
        assert len(week) == 7

    def test_gerente_can_access_dashboard(self, gerente_token):
        r = requests.get(f"{BASE_URL}/api/tenants/{SLUG}/dashboard/summary", headers=auth(gerente_token))
        assert r.status_code == 200, r.text

    def test_supervisor_can_access_dashboard(self, supervisor_token):
        r = requests.get(f"{BASE_URL}/api/tenants/{SLUG}/dashboard/summary", headers=auth(supervisor_token))
        assert r.status_code == 200, r.text

    def test_seller_can_access_dashboard(self, seller_token):
        r = requests.get(f"{BASE_URL}/api/tenants/{SLUG}/dashboard/summary", headers=auth(seller_token))
        assert r.status_code == 200, r.text


# ─── Reports: Attendances ─────────────────────────────────────────────────────

class TestReportAttendances:
    def test_admin_gets_attendances(self, admin_token):
        r = requests.get(f"{BASE_URL}/api/tenants/{SLUG}/reports/attendances", headers=auth(admin_token))
        assert r.status_code == 200, r.text
        data = r.json()
        assert isinstance(data, list)

    def test_attendances_fields(self, admin_token):
        r = requests.get(f"{BASE_URL}/api/tenants/{SLUG}/reports/attendances", headers=auth(admin_token))
        assert r.status_code == 200
        data = r.json()
        if data:
            item = data[0]
            assert "id" in item
            assert "seller_name" in item
            assert "store_name" in item
            assert "result" in item

    def test_gerente_can_view_attendances(self, gerente_token):
        r = requests.get(f"{BASE_URL}/api/tenants/{SLUG}/reports/attendances", headers=auth(gerente_token))
        assert r.status_code == 200, r.text

    def test_supervisor_can_view_attendances(self, supervisor_token):
        r = requests.get(f"{BASE_URL}/api/tenants/{SLUG}/reports/attendances", headers=auth(supervisor_token))
        assert r.status_code == 200, r.text

    def test_filter_by_result(self, admin_token):
        r = requests.get(f"{BASE_URL}/api/tenants/{SLUG}/reports/attendances?result=SALE", headers=auth(admin_token))
        assert r.status_code == 200
        data = r.json()
        for item in data:
            assert item["result"] == "SALE"


# ─── Reports: Conversion ─────────────────────────────────────────────────────

class TestReportConversion:
    def test_admin_gets_conversion(self, admin_token):
        r = requests.get(f"{BASE_URL}/api/tenants/{SLUG}/reports/conversion", headers=auth(admin_token))
        assert r.status_code == 200, r.text
        data = r.json()
        assert "by_seller" in data
        assert "by_store" in data
        assert "total" in data

    def test_by_seller_has_fields(self, admin_token):
        r = requests.get(f"{BASE_URL}/api/tenants/{SLUG}/reports/conversion", headers=auth(admin_token))
        data = r.json()
        if data["by_seller"]:
            s = data["by_seller"][0]
            assert "seller_name" in s
            assert "atendimentos" in s
            assert "vendas" in s
            assert "conversao_pct" in s

    def test_by_store_has_fields(self, admin_token):
        r = requests.get(f"{BASE_URL}/api/tenants/{SLUG}/reports/conversion", headers=auth(admin_token))
        data = r.json()
        if data["by_store"]:
            s = data["by_store"][0]
            assert "store_name" in s
            assert "conversao_pct" in s

    def test_gerente_gets_conversion(self, gerente_token):
        r = requests.get(f"{BASE_URL}/api/tenants/{SLUG}/reports/conversion", headers=auth(gerente_token))
        assert r.status_code == 200

    def test_supervisor_gets_conversion(self, supervisor_token):
        r = requests.get(f"{BASE_URL}/api/tenants/{SLUG}/reports/conversion", headers=auth(supervisor_token))
        assert r.status_code == 200


# ─── Reports: Loss Reasons ────────────────────────────────────────────────────

class TestReportLossReasons:
    def test_admin_gets_loss_reasons(self, admin_token):
        r = requests.get(f"{BASE_URL}/api/tenants/{SLUG}/reports/loss-reasons", headers=auth(admin_token))
        assert r.status_code == 200, r.text
        data = r.json()
        assert "items" in data
        assert "total_no_sale" in data

    def test_gerente_gets_loss_reasons(self, gerente_token):
        r = requests.get(f"{BASE_URL}/api/tenants/{SLUG}/reports/loss-reasons", headers=auth(gerente_token))
        assert r.status_code == 200


# ─── Reports: Seller Performance ─────────────────────────────────────────────

class TestReportSellerPerformance:
    def test_admin_gets_seller_perf(self, admin_token):
        r = requests.get(f"{BASE_URL}/api/tenants/{SLUG}/reports/seller-performance", headers=auth(admin_token))
        assert r.status_code == 200, r.text
        data = r.json()
        assert isinstance(data, list)

    def test_seller_perf_fields(self, admin_token):
        r = requests.get(f"{BASE_URL}/api/tenants/{SLUG}/reports/seller-performance", headers=auth(admin_token))
        data = r.json()
        if data:
            item = data[0]
            assert "seller_name" in item
            assert "atendimentos" in item
            assert "vendas" in item
            assert "conversao_pct" in item
            assert "ticket_medio_cents" in item


# ─── Reports: Products ───────────────────────────────────────────────────────

class TestReportProducts:
    def test_admin_gets_products(self, admin_token):
        r = requests.get(f"{BASE_URL}/api/tenants/{SLUG}/reports/products", headers=auth(admin_token))
        assert r.status_code == 200, r.text
        data = r.json()
        assert isinstance(data, list)


# ─── Export CSV ──────────────────────────────────────────────────────────────

class TestExportCSV:
    def test_export_attendances_csv(self, admin_token):
        r = requests.get(
            f"{BASE_URL}/api/tenants/{SLUG}/reports/export/csv?report_type=attendances",
            headers=auth(admin_token)
        )
        assert r.status_code == 200, r.text
        assert "text/csv" in r.headers.get("content-type", "")

    def test_export_conversion_csv(self, admin_token):
        r = requests.get(
            f"{BASE_URL}/api/tenants/{SLUG}/reports/export/csv?report_type=conversion",
            headers=auth(admin_token)
        )
        assert r.status_code == 200, r.text
        assert "text/csv" in r.headers.get("content-type", "")

    def test_export_seller_performance_csv(self, admin_token):
        r = requests.get(
            f"{BASE_URL}/api/tenants/{SLUG}/reports/export/csv?report_type=seller-performance",
            headers=auth(admin_token)
        )
        assert r.status_code == 200, r.text

    def test_export_loss_reasons_csv(self, admin_token):
        r = requests.get(
            f"{BASE_URL}/api/tenants/{SLUG}/reports/export/csv?report_type=loss-reasons",
            headers=auth(admin_token)
        )
        assert r.status_code == 200, r.text

    def test_export_products_csv(self, admin_token):
        r = requests.get(
            f"{BASE_URL}/api/tenants/{SLUG}/reports/export/csv?report_type=products",
            headers=auth(admin_token)
        )
        assert r.status_code == 200, r.text

    def test_export_invalid_type_returns_400(self, admin_token):
        r = requests.get(
            f"{BASE_URL}/api/tenants/{SLUG}/reports/export/csv?report_type=invalid",
            headers=auth(admin_token)
        )
        assert r.status_code == 400


# ─── Regression: old endpoints still work ────────────────────────────────────

class TestRegression:
    def test_queue_endpoint_requires_store(self, admin_token):
        # Queue requires store_id in path — without it, 404 is expected
        r = requests.get(f"{BASE_URL}/api/tenants/{SLUG}/queue", headers=auth(admin_token))
        assert r.status_code == 404  # path doesn't exist without store_id

    def test_attendances_endpoint(self, admin_token):
        r = requests.get(f"{BASE_URL}/api/tenants/{SLUG}/attendances", headers=auth(admin_token))
        assert r.status_code == 200

    def test_sales_endpoint(self, admin_token):
        r = requests.get(f"{BASE_URL}/api/tenants/{SLUG}/sales", headers=auth(admin_token))
        assert r.status_code == 200

    def test_sellers_endpoint(self, admin_token):
        r = requests.get(f"{BASE_URL}/api/tenants/{SLUG}/sellers", headers=auth(admin_token))
        assert r.status_code == 200
