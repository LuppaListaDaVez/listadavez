"""P2.5 — Testes de Concorrência e Fila
Cobre:
1. 10 vendedores em join simultâneo → sem race condition
2. Finish-attendance duplo com mesmo Idempotency-Key → idempotente
3. Operações concorrentes não causam estado inconsistente
4. Outbox: eventos publicados corretamente
5. Queue lock: operações serializam corretamente
"""
import os
import time
import uuid
import threading
import pytest
import httpx
from collections import Counter

# ── Configuração ──────────────────────────────────────────────────────────────
BACKEND_URL = os.environ.get(
    "BACKEND_URL",
    os.environ.get("REACT_APP_BACKEND_URL", "https://queue-mgmt-3.preview.emergentagent.com"),
).rstrip("/")
API = f"{BACKEND_URL}/api"

TENANT_SLUG = "demo"
ADMIN_EMAIL = "admin@demo.com"
ADMIN_PASS = "Admin@123456"

SELLER_EMAILS = [
    "joao@demo.com",
    "maria@demo.com",
    "carlos@demo.com",
    "ana@demo.com",
]
SELLER_PASS = "Admin@123456"


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture(scope="module")
def admin_token():
    r = httpx.post(f"{API}/tenants/{TENANT_SLUG}/auth/login",
                   json={"email": ADMIN_EMAIL, "password": ADMIN_PASS},
                   timeout=30)
    assert r.status_code == 200
    return r.json()["access_token"]


@pytest.fixture(scope="module")
def store_id(admin_token):
    r = httpx.get(f"{API}/tenants/{TENANT_SLUG}/stores",
                  headers={"Authorization": f"Bearer {admin_token}"},
                  timeout=30)
    assert r.status_code == 200 and r.json()
    return r.json()[0]["id"]


@pytest.fixture(scope="module")
def seller_tokens():
    """Login de múltiplos vendedores para testes de concorrência."""
    tokens = {}
    for email in SELLER_EMAILS:
        try:
            r = httpx.post(f"{API}/tenants/{TENANT_SLUG}/auth/login",
                           json={"email": email, "password": SELLER_PASS},
                           timeout=15)
            if r.status_code == 200:
                tokens[email] = r.json()["access_token"]
        except Exception:
            pass
    return tokens


@pytest.fixture(scope="module")
def seller_ids(admin_token):
    """Mapa email → seller_id dos vendedores do tenant demo."""
    r = httpx.get(f"{API}/tenants/{TENANT_SLUG}/sellers",
                  headers={"Authorization": f"Bearer {admin_token}"},
                  timeout=30)
    if r.status_code != 200:
        return {}

    sellers = r.json()
    if isinstance(sellers, dict):
        sellers = sellers.get("sellers", sellers.get("items", []))

    return {s.get("email", ""): s.get("id") for s in sellers if s.get("id")}


# ── Helpers ───────────────────────────────────────────────────────────────────

def leave_all_sellers(admin_token, store_id, seller_ids_map):
    """Remove todos os vendedores da fila antes de um teste de concorrência."""
    for email, sid in seller_ids_map.items():
        if not sid:
            continue
        try:
            httpx.post(
                f"{API}/tenants/{TENANT_SLUG}/stores/{store_id}/queue/leave",
                json={"seller_id": sid},
                headers={"Authorization": f"Bearer {admin_token}"},
                timeout=10,
            )
        except Exception:
            pass


def get_queue_state(admin_token, store_id) -> dict:
    try:
        r = httpx.get(
            f"{API}/tenants/{TENANT_SLUG}/stores/{store_id}/queue",
            headers={"Authorization": f"Bearer {admin_token}"},
            timeout=15,
        )
        return r.json() if r.status_code == 200 else {}
    except Exception:
        return {}


# ── 1. Join simultâneo ────────────────────────────────────────────────────────

class TestConcurrentQueueJoin:
    """Múltiplos vendedores entram na fila ao mesmo tempo."""

    def test_concurrent_join_no_duplicates(self, admin_token, store_id, seller_ids):
        """N threads fazendo join ao mesmo tempo — cada vendedor entra apenas 1 vez."""
        if len(seller_ids) < 2:
            pytest.skip("Precisa de pelo menos 2 vendedores para teste de concorrência")

        # Limpar fila primeiro
        leave_all_sellers(admin_token, store_id, seller_ids)
        time.sleep(0.5)

        results = {}
        seller_list = [(email, sid) for email, sid in seller_ids.items() if sid][:4]

        def do_join(email, seller_id):
            try:
                r = httpx.post(
                    f"{API}/tenants/{TENANT_SLUG}/stores/{store_id}/queue/join",
                    json={"seller_id": seller_id},
                    headers={"Authorization": f"Bearer {admin_token}"},
                    timeout=15,
                )
                results[email] = r.status_code
            except Exception as e:
                results[email] = -1

        threads = [threading.Thread(target=do_join, args=(email, sid))
                   for email, sid in seller_list]

        # Disparar todos ao mesmo tempo
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=20)

        # Verificar resultados
        status_counts = Counter(results.values())
        successes = status_counts.get(200, 0) + status_counts.get(201, 0)
        conflicts = status_counts.get(409, 0)

        print(f"Concurrent join results: {dict(status_counts)}")

        # Nenhum 500 (erro de servidor)
        assert 500 not in status_counts, f"500 em join concorrente: {results}"

        # Pelo menos 1 join bem-sucedido
        assert successes >= 1, f"Nenhum join bem-sucedido: {results}"

        # Verificar estado final da fila — sem duplicatas
        state = get_queue_state(admin_token, store_id)
        waiting = state.get("waiting_sellers", [])
        waiting_ids = [w.get("seller_id") for w in waiting]

        # IDs únicos na fila
        assert len(waiting_ids) == len(set(waiting_ids)), (
            f"Duplicatas na fila após join concorrente: {waiting_ids}"
        )

    def test_concurrent_join_same_seller_idempotent(
        self, admin_token, store_id, seller_ids
    ):
        """Mesmo vendedor tentando join 3x ao mesmo tempo → apenas 1 sucesso."""
        if not seller_ids:
            pytest.skip("Nenhum vendedor disponível")

        email, seller_id = next(iter(seller_ids.items()))
        if not seller_id:
            pytest.skip("seller_id inválido")

        # Deixar o vendedor fora da fila
        httpx.post(
            f"{API}/tenants/{TENANT_SLUG}/stores/{store_id}/queue/leave",
            json={"seller_id": seller_id},
            headers={"Authorization": f"Bearer {admin_token}"},
            timeout=10,
        )
        time.sleep(0.3)

        results = []

        def do_join():
            try:
                r = httpx.post(
                    f"{API}/tenants/{TENANT_SLUG}/stores/{store_id}/queue/join",
                    json={"seller_id": seller_id},
                    headers={"Authorization": f"Bearer {admin_token}"},
                    timeout=15,
                )
                results.append(r.status_code)
            except Exception:
                results.append(-1)

        # 3 threads simultaneas para o mesmo vendedor
        threads = [threading.Thread(target=do_join) for _ in range(3)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=20)

        status_counts = Counter(results)
        successes = status_counts.get(200, 0) + status_counts.get(201, 0)
        conflicts = status_counts.get(409, 0)

        print(f"Same-seller concurrent join: {dict(status_counts)}")

        # 500 não é tolerado
        assert 500 not in status_counts, f"500 em join concorrente mesmo vendedor: {results}"

        # Exatamente 1 sucesso (ou o 409 indica que o conflito foi detectado)
        assert successes <= 1, (
            f"Mais de 1 join bem-sucedido para o mesmo vendedor: {results}"
        )
        assert successes + conflicts == len(results), (
            f"Resultados inesperados: {results}"
        )


# ── 2. Finish-Attendance Duplo ────────────────────────────────────────────────

class TestConcurrentFinishAttendance:
    """Finish-attendance duplo com mesmo Idempotency-Key é idempotente."""

    def _setup_attendance(self, admin_token, store_id, seller_ids) -> tuple[str, str]:
        """Cria um atendimento e retorna (att_id, seller_id)."""
        if not seller_ids:
            return None, None

        email, seller_id = next(iter(seller_ids.items()))
        if not seller_id:
            return None, None

        # Leave first
        httpx.post(
            f"{API}/tenants/{TENANT_SLUG}/stores/{store_id}/queue/leave",
            json={"seller_id": seller_id},
            headers={"Authorization": f"Bearer {admin_token}"},
            timeout=10,
        )
        time.sleep(0.3)

        # Join
        r_join = httpx.post(
            f"{API}/tenants/{TENANT_SLUG}/stores/{store_id}/queue/join",
            json={"seller_id": seller_id},
            headers={"Authorization": f"Bearer {admin_token}"},
            timeout=15,
        )
        if r_join.status_code not in (200, 201):
            return None, None

        # Start
        r_start = httpx.post(
            f"{API}/tenants/{TENANT_SLUG}/stores/{store_id}/queue/start-attendance",
            json={"seller_id": seller_id},
            headers={"Authorization": f"Bearer {admin_token}"},
            timeout=15,
        )
        if r_start.status_code != 200:
            return None, None

        data = r_start.json()
        att = data.get("attendance") or data
        return att.get("id"), seller_id

    def test_double_finish_with_same_idempotency_key(
        self, admin_token, store_id, seller_ids
    ):
        """2 threads chamam finish com o mesmo Idempotency-Key — nenhuma 500."""
        att_id, seller_id = self._setup_attendance(admin_token, store_id, seller_ids)
        if not att_id:
            pytest.skip("Não foi possível criar atendimento para teste")

        idem_key = f"concurrent-finish-{uuid.uuid4()}"
        payload = {
            "attendance_id": att_id,
            "result": "INVALID",
            "notes": "Teste concorrência duplo finish",
        }

        results = []

        def do_finish():
            try:
                r = httpx.post(
                    f"{API}/tenants/{TENANT_SLUG}/stores/{store_id}/queue/finish-attendance",
                    json=payload,
                    headers={
                        "Authorization": f"Bearer {admin_token}",
                        "Idempotency-Key": idem_key,
                    },
                    timeout=20,
                )
                results.append(r.status_code)
            except Exception:
                results.append(-1)

        threads = [threading.Thread(target=do_finish) for _ in range(2)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=30)

        status_counts = Counter(results)
        print(f"Double finish concurrent: {dict(status_counts)}")

        # Nenhum 500
        assert 500 not in status_counts, f"500 em finish concorrente: {results}"

        # Deve ter sucesso ou idempotência
        successes = status_counts.get(200, 0) + status_counts.get(201, 0)
        idempotent = status_counts.get(200, 0) + status_counts.get(201, 0)
        assert successes >= 1, f"Nenhum finish bem-sucedido: {results}"


# ── 3. Concorrência de Estado da Fila ────────────────────────────────────────

class TestQueueStateConsistency:
    """Estado da fila é sempre consistente mesmo sob concorrência."""

    def test_queue_state_never_500_under_concurrent_reads(
        self, admin_token, store_id
    ):
        """10 threads lendo estado da fila ao mesmo tempo — sem 500."""
        results = []

        def do_get():
            try:
                r = httpx.get(
                    f"{API}/tenants/{TENANT_SLUG}/stores/{store_id}/queue",
                    headers={"Authorization": f"Bearer {admin_token}"},
                    timeout=15,
                )
                results.append(r.status_code)
            except Exception:
                results.append(-1)

        threads = [threading.Thread(target=do_get) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=30)

        status_counts = Counter(results)
        print(f"Concurrent queue reads: {dict(status_counts)}")

        assert 500 not in status_counts, f"500 em leitura concorrente: {results}"
        successes = status_counts.get(200, 0)
        assert successes >= 8, f"Menos de 8/10 leituras bem-sucedidas: {results}"

    def test_queue_positions_are_unique_and_sequential(
        self, admin_token, store_id
    ):
        """Posições na fila são únicas e sequenciais (1, 2, 3...)."""
        state = get_queue_state(admin_token, store_id)
        waiting = state.get("waiting_sellers", [])

        if not waiting:
            pytest.skip("Fila vazia — nada a verificar")

        positions = [w.get("position") for w in waiting if w.get("position") is not None]

        if not positions:
            pytest.skip("Posições não disponíveis na resposta da fila")

        # Posições devem ser únicas
        assert len(positions) == len(set(positions)), (
            f"Posições duplicadas na fila: {positions}"
        )

        # Posições devem começar em 1
        assert min(positions) == 1, f"Posição mínima não é 1: {positions}"

    def test_dashboard_consistent_after_concurrent_ops(
        self, admin_token, store_id
    ):
        """Dashboard retorna dados consistentes após operações concorrentes."""
        r = httpx.get(
            f"{API}/tenants/{TENANT_SLUG}/dashboard/summary",
            headers={"Authorization": f"Bearer {admin_token}"},
            timeout=20,
        )
        assert r.status_code == 200, f"Dashboard falhou após concorrência: {r.status_code}"
        data = r.json()
        # Verificar que campos numéricos são não-negativos
        for key in ["total_attendances_today", "total_sales_today",
                    "waiting_in_queue", "serving_count"]:
            value = data.get(key)
            if value is not None:
                assert value >= 0, f"Campo {key} negativo: {value}"
