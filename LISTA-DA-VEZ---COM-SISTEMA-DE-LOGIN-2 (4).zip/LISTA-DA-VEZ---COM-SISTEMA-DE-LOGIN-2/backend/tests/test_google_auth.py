"""
Tests for Google OAuth endpoints (routes_google_auth.py).
Tests both Super Admin and Tenant Google login flows.
Focuses on what's testable without real Google OAuth: invalid session_id handling.
"""
import pytest
import requests
import os

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")

INVALID_SESSION_ID = "invalid_fake_session_id_12345"


class TestSuperAdminGoogleCallback:
    """Tests for POST /api/auth/google/callback"""

    def test_invalid_session_id_returns_401(self):
        """Invalid session_id should return 401 - Emergent Auth rejects it."""
        resp = requests.post(
            f"{BASE_URL}/api/auth/google/callback",
            json={"session_id": INVALID_SESSION_ID},
        )
        assert resp.status_code in (401, 503), (
            f"Expected 401 or 503 (503 if Emergent Auth unreachable), got {resp.status_code}: {resp.text}"
        )
        data = resp.json()
        # If 401: invalid session
        if resp.status_code == 401:
            assert "detail" in data
            print(f"PASS: 401 returned with detail: {data['detail']}")
        else:
            # 503 if external service down — acceptable for this test
            print(f"PASS (503): External auth service unreachable — {data.get('detail')}")

    def test_missing_session_id_returns_422(self):
        """Missing session_id body field should return 422 validation error."""
        resp = requests.post(
            f"{BASE_URL}/api/auth/google/callback",
            json={},
        )
        assert resp.status_code == 422, f"Expected 422, got {resp.status_code}: {resp.text}"
        print(f"PASS: 422 returned for missing session_id")

    def test_empty_session_id_returns_error(self):
        """Empty session_id should return 401 or validation error."""
        resp = requests.post(
            f"{BASE_URL}/api/auth/google/callback",
            json={"session_id": ""},
        )
        # Empty string passes Pydantic validation but Emergent Auth will reject it
        assert resp.status_code in (401, 422, 503), (
            f"Expected 401/422/503, got {resp.status_code}: {resp.text}"
        )
        print(f"PASS: {resp.status_code} returned for empty session_id")


class TestTenantGoogleCallback:
    """Tests for POST /api/tenants/demo/auth/google/callback"""

    def test_invalid_session_id_returns_401(self):
        """Invalid session_id for tenant should return 401."""
        resp = requests.post(
            f"{BASE_URL}/api/tenants/demo/auth/google/callback",
            json={"session_id": INVALID_SESSION_ID},
        )
        assert resp.status_code in (401, 503), (
            f"Expected 401 or 503, got {resp.status_code}: {resp.text}"
        )
        data = resp.json()
        if resp.status_code == 401:
            assert "detail" in data
            print(f"PASS: 401 returned with detail: {data['detail']}")
        else:
            print(f"PASS (503): External auth service unreachable — {data.get('detail')}")

    def test_invalid_tenant_slug_returns_404(self):
        """Non-existent tenant slug should return 404 after session is validated.
        Note: 401 may come first if session validation fails before tenant lookup."""
        resp = requests.post(
            f"{BASE_URL}/api/tenants/nonexistent-tenant-xyz/auth/google/callback",
            json={"session_id": INVALID_SESSION_ID},
        )
        # Returns 401 (invalid session) or 404 (tenant not found) depending on order
        assert resp.status_code in (401, 404, 503), (
            f"Expected 401/404/503, got {resp.status_code}: {resp.text}"
        )
        print(f"PASS: {resp.status_code} returned for non-existent tenant with invalid session")

    def test_missing_session_id_returns_422(self):
        """Missing session_id should return 422 validation error."""
        resp = requests.post(
            f"{BASE_URL}/api/tenants/demo/auth/google/callback",
            json={},
        )
        assert resp.status_code == 422, f"Expected 422, got {resp.status_code}: {resp.text}"
        print(f"PASS: 422 returned for missing session_id on tenant endpoint")


class TestPasswordLoginRegression:
    """Regression tests: ensure password login still works after Google OAuth was added."""

    def test_super_admin_password_login_success(self):
        """Super Admin can still login with password."""
        resp = requests.post(
            f"{BASE_URL}/api/auth/login",
            json={
                "email": "admin@listadavez.com",
                "password": "SuperAdmin!2025",
            },
        )
        assert resp.status_code == 200, f"Expected 200, got {resp.status_code}: {resp.text}"
        data = resp.json()
        assert "access_token" in data, "No access_token in response"
        assert "refresh_token" in data, "No refresh_token in response"
        assert data.get("user", {}).get("is_super_admin") is True, "User is not super admin"
        assert data["user"]["email"] == "admin@listadavez.com"
        print(f"PASS: Super Admin password login works. Token prefix: {data['access_token'][:20]}...")

    def test_tenant_password_login_success(self):
        """Tenant admin can still login with password."""
        resp = requests.post(
            f"{BASE_URL}/api/tenants/demo/auth/login",
            json={
                "email": "admin@demo.com",
                "password": "Admin@123456",
            },
        )
        assert resp.status_code == 200, f"Expected 200, got {resp.status_code}: {resp.text}"
        data = resp.json()
        assert "access_token" in data, "No access_token in response"
        assert data.get("user", {}).get("email") == "admin@demo.com"
        print(f"PASS: Tenant Admin password login works. Tenant: {data.get('tenant_slug')}")

    def test_super_admin_wrong_password_returns_401(self):
        """Wrong password for Super Admin should return 401."""
        resp = requests.post(
            f"{BASE_URL}/api/auth/login",
            json={
                "email": "admin@listadavez.com",
                "password": "WrongPassword!",
            },
        )
        assert resp.status_code in (401, 403), f"Expected 401/403, got {resp.status_code}: {resp.text}"
        print(f"PASS: Wrong password returns {resp.status_code}")

    def test_tenant_wrong_password_returns_401(self):
        """Wrong password for tenant should return 401."""
        resp = requests.post(
            f"{BASE_URL}/api/tenants/demo/auth/login",
            json={
                "email": "admin@demo.com",
                "password": "WrongPassword!",
            },
        )
        assert resp.status_code in (401, 403), f"Expected 401/403, got {resp.status_code}: {resp.text}"
        print(f"PASS: Tenant wrong password returns {resp.status_code}")
