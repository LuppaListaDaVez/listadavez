"""Audit — testes reais de concorrência e duplicidade (AUDIT_TEST prefix)."""
import asyncio
import os
import httpx

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")


async def get_token(client, tenant_slug, email, password):
    r = await client.post(f"{BASE_URL}/api/tenants/{tenant_slug}/auth/login",
                           json={"email": email, "password": password})
    r.raise_for_status()
    return r.json()["access_token"]


async def main():
    async with httpx.AsyncClient(timeout=60) as client:
        token = await get_token(client, "demo", "admin@demo.com", "Admin@123456")
        headers = {"Authorization": f"Bearer {token}"}

        sku = "AUDIT_TEST-CONCURRENCY-SKU-002"
        # limpar produto de teste anterior, se houver (via PATCH status pois não há DELETE)
        r = await client.get(f"{BASE_URL}/api/tenants/demo/products", headers=headers)
        stale = [p for p in r.json() if p.get("sku") == sku]
        if stale:
            print("AVISO: SKU de teste anterior ainda presente, use outro sufixo:", [p["id"] for p in stale])

        payload = {"sku": sku, "name": "AUDIT_TEST Produto Concorrente", "price_cents": 1000}

        async def create():
            return await client.post(f"{BASE_URL}/api/tenants/demo/products", headers=headers, json=payload)

        results = await asyncio.gather(*[create() for _ in range(5)], return_exceptions=True)
        statuses = [r.status_code if not isinstance(r, Exception) else str(r) for r in results]
        print("CONCURRENT_CREATE_PRODUCT_STATUSES:", statuses)

        r = await client.get(f"{BASE_URL}/api/tenants/demo/products", headers=headers)
        matches = [p for p in r.json() if p.get("sku") == sku]
        print("PRODUCTS_WITH_SAME_SKU_AFTER_RACE:", len(matches))
        for p in matches:
            print("  ->", p["id"], p["sku"])

        # cleanup dos produtos de teste via SQL direto (não há endpoint DELETE de produto)
        import asyncpg
        conn = await asyncpg.connect(os.environ["DATABASE_URL"].replace("postgresql+asyncpg://", "postgresql://"))
        await conn.execute("DELETE FROM doc_products WHERE doc->>'sku' LIKE 'AUDIT_TEST%'")

        # --- Teste 2: cinco vendedores concorrentes com o MESMO e-mail novo ---
        email = "audit-test-concurrent-seller@demo.com"
        await conn.execute("DELETE FROM doc_users WHERE doc->>'email' = $1", email)
        stores_r = await client.get(f"{BASE_URL}/api/tenants/demo/stores", headers=headers)
        store_id = stores_r.json()[0]["id"]

        async def create_seller():
            return await client.post(f"{BASE_URL}/api/tenants/demo/sellers", headers=headers, json={
                "name": "AUDIT_TEST Vendedor Concorrente", "email": email, "password": "Teste@123456",
                "store_id": store_id, "employee_code": f"AUDIT-{os.getpid()}",
            })

        results2 = await asyncio.gather(*[create_seller() for _ in range(5)], return_exceptions=True)
        statuses2 = [r.status_code if not isinstance(r, Exception) else str(r) for r in results2]
        print("CONCURRENT_CREATE_SELLER_STATUSES:", statuses2)

        users = await conn.fetch("SELECT id FROM doc_users WHERE doc->>'email' = $1", email)
        print("USERS_WITH_SAME_EMAIL_AFTER_RACE:", len(users))
        seller_profiles = await conn.fetch(
            "SELECT sp.id FROM doc_seller_profiles sp JOIN doc_users u ON u.id = sp.doc->>'user_id' WHERE u.doc->>'email' = $1",
            email,
        )
        print("SELLER_PROFILES_FOR_THAT_USER_AFTER_RACE:", len(seller_profiles))

        # cleanup
        await conn.execute("DELETE FROM doc_seller_profiles WHERE doc->>'user_id' IN (SELECT id FROM doc_users WHERE doc->>'email' = $1)", email)
        await conn.execute("DELETE FROM doc_tenant_memberships WHERE doc->>'user_id' IN (SELECT id FROM doc_users WHERE doc->>'email' = $1)", email)
        await conn.execute("DELETE FROM doc_users WHERE doc->>'email' = $1", email)
        await conn.close()

if __name__ == "__main__":
    asyncio.run(main())
