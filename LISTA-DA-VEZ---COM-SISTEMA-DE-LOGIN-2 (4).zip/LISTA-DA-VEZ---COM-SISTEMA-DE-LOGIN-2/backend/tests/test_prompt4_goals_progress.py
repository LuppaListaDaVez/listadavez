"""
Test Prompt 4: Goal progress calculation fix.
Tests: current_value and progress_percent are non-zero, no cap at 100%, recalculate endpoint,
future period returns 0, ITEMS_SOLD, ATTENDANCES, CONVERSION types.
"""
import pytest
import requests
import os
import time

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")
TENANT = "demo"
STORE_ID = "37480f61-f035-41e7-831c-6e2db1bcc7a4"
JOAO_SELLER_ID = "df1ee4f8-ccd1-4d4e-a532-c2c8d2ee40c3"
ADMIN_EMAIL = "admin@demo.com"
ADMIN_PASSWORD = "Admin@123456"


@pytest.fixture(scope="module")
def auth_token():
    r = requests.post(f"{BASE_URL}/api/tenants/{TENANT}/auth/login", json={
        "email": ADMIN_EMAIL, "password": ADMIN_PASSWORD
    })
    assert r.status_code == 200, f"Login failed: {r.text}"
    data = r.json()
    return data.get("access_token") or data.get("token")


@pytest.fixture(scope="module")
def client(auth_token):
    s = requests.Session()
    s.headers.update({"Authorization": f"Bearer {auth_token}", "Content-Type": "application/json"})
    return s


# Track created goal IDs for cleanup
created_goals = []


def create_goal(client, payload):
    r = client.post(f"{BASE_URL}/api/tenants/{TENANT}/goals", json=payload)
    if r.status_code == 200:
        created_goals.append(r.json().get("id"))
    return r


class TestGoalsListNonZero:
    """GET /goals returns existing goals with correct values"""

    def test_list_goals_returns_200(self, client):
        r = client.get(f"{BASE_URL}/api/tenants/{TENANT}/goals")
        assert r.status_code == 200, r.text
        data = r.json()
        assert isinstance(data, list)
        print(f"Total goals: {len(data)}")

    def test_list_goals_no_zero_progress_on_completed(self, client):
        """COMPLETED goals should not have progress_percent=0"""
        r = client.get(f"{BASE_URL}/api/tenants/{TENANT}/goals?status=COMPLETED")
        assert r.status_code == 200
        goals = r.json()
        for g in goals:
            if g["status"] == "COMPLETED":
                assert g["progress_percent"] >= 100, (
                    f"COMPLETED goal {g['id']} has progress_percent={g['progress_percent']}"
                )
        print(f"COMPLETED goals checked: {len(goals)}")


class TestGoalSalesCount:
    """SALES_COUNT goal with target=1 and Aug 2026 period should show progress"""

    def test_create_sales_count_goal_aug2026(self, client):
        r = create_goal(client, {
            "title": "TEST_SalesCount Aug2026",
            "type": "SALES_COUNT",
            "scope": "TENANT",
            "period": "CUSTOM",
            "target_value": 1,
            "period_start": "2026-08-01",
            "period_end": "2026-08-31",
        })
        assert r.status_code == 200, r.text
        data = r.json()
        print(f"SALES_COUNT current_value={data['current_value']}, progress_percent={data['progress_percent']}")
        assert data["current_value"] > 0, f"Expected current_value > 0, got {data['current_value']}"
        assert data["progress_percent"] >= 100, f"Expected progress_percent >= 100, got {data['progress_percent']}"


class TestGoalRevenuNoCap:
    """REVENUE goal for João with target=10 (R$0.10) should show > 100% (no cap)"""

    def test_create_revenue_no_cap(self, client):
        r = create_goal(client, {
            "title": "TEST_Revenue NoCap João",
            "type": "REVENUE",
            "scope": "SELLER",
            "seller_id": JOAO_SELLER_ID,
            "period": "CUSTOM",
            "target_value": 10,  # R$0.10 in cents
            "period_start": "2026-08-01",
            "period_end": "2026-08-31",
        })
        assert r.status_code == 200, r.text
        data = r.json()
        print(f"REVENUE current_value={data['current_value']}, progress_percent={data['progress_percent']}")
        assert data["progress_percent"] > 100, f"Expected progress_percent > 100 (no cap), got {data['progress_percent']}"


class TestGoalFuturePeriod:
    """Goal with future period should have current_value=0 and progress_percent=0"""

    def test_create_goal_future_period(self, client):
        r = create_goal(client, {
            "title": "TEST_Future 2099",
            "type": "SALES_COUNT",
            "scope": "TENANT",
            "period": "CUSTOM",
            "target_value": 100,
            "period_start": "2099-01-01",
            "period_end": "2099-01-31",
        })
        assert r.status_code == 200, r.text
        data = r.json()
        print(f"Future goal current_value={data['current_value']}, progress_percent={data['progress_percent']}")
        assert data["current_value"] == 0, f"Expected 0, got {data['current_value']}"
        assert data["progress_percent"] == 0, f"Expected 0%, got {data['progress_percent']}"


class TestRecalculateEndpoint:
    """POST /goals/{id}/recalculate returns correct data"""

    def test_recalculate_goal(self, client):
        # Use large target so goal stays ACTIVE (not auto-completed)
        r = create_goal(client, {
            "title": "TEST_Recalculate",
            "type": "SALES_COUNT",
            "scope": "TENANT",
            "period": "CUSTOM",
            "target_value": 999999,
            "period_start": "2026-08-01",
            "period_end": "2026-08-31",
        })
        assert r.status_code == 200
        goal_id = r.json()["id"]
        assert r.json()["status"] == "ACTIVE", "Goal should be ACTIVE with large target"

        r2 = client.post(f"{BASE_URL}/api/tenants/{TENANT}/goals/{goal_id}/recalculate")
        assert r2.status_code == 200, r2.text
        data = r2.json()
        print(f"Recalculate: current_value={data['current_value']}, progress_percent={data['progress_percent']}")
        assert data["current_value"] > 0


class TestGoalUpdateRecalculates:
    """PATCH goal with new target_value recalculates progress_percent"""

    def test_patch_target_value_recalculates(self, client):
        r = create_goal(client, {
            "title": "TEST_Update Target",
            "type": "SALES_COUNT",
            "scope": "TENANT",
            "period": "CUSTOM",
            "target_value": 999999,  # Large so it stays ACTIVE
            "period_start": "2026-08-01",
            "period_end": "2026-08-31",
        })
        assert r.status_code == 200
        goal = r.json()
        goal_id = goal["id"]
        initial_pct = goal["progress_percent"]
        print(f"Initial progress_percent={initial_pct}")
        assert goal["status"] == "ACTIVE"

        # Update with even larger target - progress % should change but remain low
        r2 = client.put(f"{BASE_URL}/api/tenants/{TENANT}/goals/{goal_id}", json={"target_value": 9999999})
        assert r2.status_code == 200, r2.text
        updated = r2.json()
        print(f"After update target=9999999: progress_percent={updated['progress_percent']}")
        # The progress should still be a valid number
        assert isinstance(updated["progress_percent"], int)


class TestGoalItemsSold:
    """ITEMS_SOLD goal returns item_count from COMPLETED sales"""

    def test_items_sold_non_zero(self, client):
        r = create_goal(client, {
            "title": "TEST_ItemsSold Aug2026",
            "type": "ITEMS_SOLD",
            "scope": "TENANT",
            "period": "CUSTOM",
            "target_value": 1,
            "period_start": "2026-08-01",
            "period_end": "2026-08-31",
        })
        assert r.status_code == 200, r.text
        data = r.json()
        print(f"ITEMS_SOLD current_value={data['current_value']}, progress_percent={data['progress_percent']}")
        # We can't guarantee items exist but the API should return valid structure
        assert "current_value" in data
        assert "progress_percent" in data


class TestGoalAttendances:
    """ATTENDANCES goal excludes INVALID results"""

    def test_attendances_goal(self, client):
        r = create_goal(client, {
            "title": "TEST_Attendances Aug2026",
            "type": "ATTENDANCES",
            "scope": "TENANT",
            "period": "CUSTOM",
            "target_value": 1,
            "period_start": "2026-08-01",
            "period_end": "2026-08-31",
        })
        assert r.status_code == 200, r.text
        data = r.json()
        print(f"ATTENDANCES current_value={data['current_value']}, progress_percent={data['progress_percent']}")
        assert "current_value" in data


class TestGoalConversion:
    """CONVERSION goal returns basis points 0-10000"""

    def test_conversion_goal_basis_points(self, client):
        r = create_goal(client, {
            "title": "TEST_Conversion Aug2026",
            "type": "CONVERSION",
            "scope": "TENANT",
            "period": "CUSTOM",
            "target_value": 5000,  # 50% target
            "period_start": "2026-08-01",
            "period_end": "2026-08-31",
        })
        assert r.status_code == 200, r.text
        data = r.json()
        print(f"CONVERSION current_value={data['current_value']}, progress_percent={data['progress_percent']}")
        assert 0 <= data["current_value"] <= 20000, f"CONVERSION current_value should be in basis points range, got {data['current_value']}"
