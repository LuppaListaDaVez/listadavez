"""
test_prompt10_my_painel.py — Backend tests for Prompt 10: Meu Painel (My Panel)

Tests:
1. GET /api/tenants/demo/my-performance — returns seller data with current_status
2. GET /api/tenants/demo/my-performance?period=today|week|month — period filtering
3. PATCH /api/tenants/demo/sellers/{seller_id}/status — seller can change own status
4. Status change: only 6 statuses allowed (AVAILABLE, OFFLINE, BREAK, MEETING, LUNCH, ABSENT)
5. Status change: seller cannot change another seller's status
"""
import pytest
import requests
import os

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")

# ─── Fixtures ────────────────────────────────────────────────────────────────

@pytest.fixture(scope="module")
def seller_token():
    """Get joao@demo.com (SELLER) token."""
    resp = requests.post(f"{BASE_URL}/api/tenants/demo/auth/login", json={
        "email": "joao@demo.com",
        "password": "Admin@123456",
    })
    assert resp.status_code == 200, f"Seller login failed: {resp.text}"
    return resp.json()["access_token"]


@pytest.fixture(scope="module")
def admin_token():
    """Get admin@demo.com token."""
    resp = requests.post(f"{BASE_URL}/api/tenants/demo/auth/login", json={
        "email": "admin@demo.com",
        "password": "Admin@123456",
    })
    assert resp.status_code == 200, f"Admin login failed: {resp.text}"
    return resp.json()["access_token"]


@pytest.fixture(scope="module")
def seller_headers(seller_token):
    return {"Authorization": f"Bearer {seller_token}"}


@pytest.fixture(scope="module")
def admin_headers(admin_token):
    return {"Authorization": f"Bearer {admin_token}"}


@pytest.fixture(scope="module")
def seller_id(seller_headers):
    """Get the seller_id for joao@demo.com from my-performance."""
    resp = requests.get(f"{BASE_URL}/api/tenants/demo/my-performance", headers=seller_headers)
    assert resp.status_code == 200, f"my-performance failed: {resp.text}"
    data = resp.json()
    sid = data.get("seller", {}).get("id")
    assert sid, "seller.id not found in my-performance response"
    return sid


# ─── 1. My Performance endpoint ───────────────────────────────────────────────

class TestMyPerformance:
    """GET /api/tenants/demo/my-performance"""

    def test_my_performance_returns_200(self, seller_headers):
        resp = requests.get(f"{BASE_URL}/api/tenants/demo/my-performance", headers=seller_headers)
        assert resp.status_code == 200, f"Expected 200, got {resp.status_code}: {resp.text}"
        print("PASS: my-performance returns 200")

    def test_my_performance_has_seller_data(self, seller_headers):
        resp = requests.get(f"{BASE_URL}/api/tenants/demo/my-performance", headers=seller_headers)
        data = resp.json()
        assert "seller" in data, "Response missing 'seller' field"
        seller = data["seller"]
        assert "id" in seller, "seller.id missing"
        assert "name" in seller, "seller.name missing"
        print(f"PASS: seller data present — id={seller['id']}, name={seller['name']}")

    def test_my_performance_has_current_status(self, seller_headers):
        """current_status must be returned in seller object (Prompt 10 requirement)."""
        resp = requests.get(f"{BASE_URL}/api/tenants/demo/my-performance", headers=seller_headers)
        data = resp.json()
        seller = data.get("seller", {})
        assert "current_status" in seller, "seller.current_status missing from response"
        status = seller["current_status"]
        assert isinstance(status, str), f"current_status should be str, got {type(status)}"
        print(f"PASS: current_status present — {status}")

    def test_my_performance_has_kpis(self, seller_headers):
        resp = requests.get(f"{BASE_URL}/api/tenants/demo/my-performance", headers=seller_headers)
        data = resp.json()
        assert "kpis" in data, "Response missing 'kpis' field"
        kpis = data["kpis"]
        required_kpi_keys = ["sales_total_cents", "sales_count", "attendances_finished",
                              "conversion_rate", "average_ticket_cents"]
        for key in required_kpi_keys:
            assert key in kpis, f"kpis.{key} missing"
        print(f"PASS: all 5 KPIs present — {list(kpis.keys())}")

    def test_my_performance_has_goals(self, seller_headers):
        resp = requests.get(f"{BASE_URL}/api/tenants/demo/my-performance", headers=seller_headers)
        data = resp.json()
        assert "goals" in data, "Response missing 'goals' field"
        assert isinstance(data["goals"], list), "goals should be a list"
        print(f"PASS: goals present — count={len(data['goals'])}")

    def test_my_performance_has_ranking_position_field(self, seller_headers):
        resp = requests.get(f"{BASE_URL}/api/tenants/demo/my-performance", headers=seller_headers)
        data = resp.json()
        assert "ranking_position" in data, "Response missing 'ranking_position' field"
        print(f"PASS: ranking_position field present — {data['ranking_position']}")

    def test_my_performance_has_period_info(self, seller_headers):
        resp = requests.get(f"{BASE_URL}/api/tenants/demo/my-performance", headers=seller_headers)
        data = resp.json()
        assert "period" in data, "Response missing 'period' field"
        period = data["period"]
        assert "type" in period, "period.type missing"
        assert "start" in period, "period.start missing"
        assert "end" in period, "period.end missing"
        print(f"PASS: period info present — {period}")

    def test_my_performance_unauthenticated_returns_401(self):
        resp = requests.get(f"{BASE_URL}/api/tenants/demo/my-performance")
        assert resp.status_code in [401, 403], f"Expected 401/403, got {resp.status_code}"
        print(f"PASS: unauthenticated returns {resp.status_code}")


# ─── 2. Period filtering ───────────────────────────────────────────────────────

class TestPeriodFiltering:
    """GET /api/tenants/demo/my-performance?period=today|week|month"""

    @pytest.mark.parametrize("period", ["today", "week", "month"])
    def test_period_filter_returns_200(self, seller_headers, period):
        resp = requests.get(f"{BASE_URL}/api/tenants/demo/my-performance?period={period}",
                            headers=seller_headers)
        assert resp.status_code == 200, f"Period {period} returned {resp.status_code}: {resp.text}"
        data = resp.json()
        assert data["period"]["type"] == period, f"period.type mismatch: {data['period']}"
        print(f"PASS: period={period} returns 200 with correct period.type")

    def test_custom_date_range_returns_200(self, seller_headers):
        """Custom date range query (used for delta KPI comparison)."""
        resp = requests.get(
            f"{BASE_URL}/api/tenants/demo/my-performance?date_start=2025-01-01&date_end=2025-01-31",
            headers=seller_headers
        )
        assert resp.status_code == 200, f"Custom date range returned {resp.status_code}: {resp.text}"
        print("PASS: custom date range returns 200")


# ─── 3. Status change ────────────────────────────────────────────────────────

class TestStatusChange:
    """PATCH /api/tenants/demo/sellers/{seller_id}/status"""

    def test_seller_can_change_own_status_to_offline(self, seller_headers, seller_id):
        resp = requests.patch(
            f"{BASE_URL}/api/tenants/demo/sellers/{seller_id}/status",
            headers=seller_headers,
            json={"new_status": "OFFLINE", "reason": "test-offline"}
        )
        assert resp.status_code == 200, f"Status change to OFFLINE failed: {resp.text}"
        data = resp.json()
        assert data.get("current_status") == "OFFLINE", f"current_status not OFFLINE: {data}"
        print(f"PASS: seller changed own status to OFFLINE — {data.get('current_status')}")

    def test_seller_can_change_own_status_to_available(self, seller_headers, seller_id):
        resp = requests.patch(
            f"{BASE_URL}/api/tenants/demo/sellers/{seller_id}/status",
            headers=seller_headers,
            json={"new_status": "AVAILABLE"}
        )
        assert resp.status_code == 200, f"Status change to AVAILABLE failed: {resp.text}"
        data = resp.json()
        assert data.get("current_status") == "AVAILABLE", f"current_status not AVAILABLE: {data}"
        print(f"PASS: seller changed own status to AVAILABLE")

    def test_seller_can_change_to_break(self, seller_headers, seller_id):
        resp = requests.patch(
            f"{BASE_URL}/api/tenants/demo/sellers/{seller_id}/status",
            headers=seller_headers,
            json={"new_status": "BREAK", "reason": "coffee break"}
        )
        assert resp.status_code == 200, f"Status change to BREAK failed: {resp.text}"
        print("PASS: seller changed status to BREAK")

    def test_seller_can_change_to_meeting(self, seller_headers, seller_id):
        resp = requests.patch(
            f"{BASE_URL}/api/tenants/demo/sellers/{seller_id}/status",
            headers=seller_headers,
            json={"new_status": "MEETING"}
        )
        assert resp.status_code == 200, f"Status change to MEETING failed: {resp.text}"
        print("PASS: seller changed status to MEETING")

    def test_seller_can_change_to_lunch(self, seller_headers, seller_id):
        resp = requests.patch(
            f"{BASE_URL}/api/tenants/demo/sellers/{seller_id}/status",
            headers=seller_headers,
            json={"new_status": "LUNCH"}
        )
        assert resp.status_code == 200, f"Status change to LUNCH failed: {resp.text}"
        print("PASS: seller changed status to LUNCH")

    def test_seller_can_change_to_absent(self, seller_headers, seller_id):
        resp = requests.patch(
            f"{BASE_URL}/api/tenants/demo/sellers/{seller_id}/status",
            headers=seller_headers,
            json={"new_status": "ABSENT"}
        )
        assert resp.status_code == 200, f"Status change to ABSENT failed: {resp.text}"
        print("PASS: seller changed status to ABSENT")

    def test_status_change_persists_in_my_performance(self, seller_headers, seller_id):
        """After status change, my-performance should reflect updated current_status."""
        # Change to OFFLINE first
        requests.patch(
            f"{BASE_URL}/api/tenants/demo/sellers/{seller_id}/status",
            headers=seller_headers,
            json={"new_status": "OFFLINE"}
        )
        # Check my-performance reflects this
        resp = requests.get(f"{BASE_URL}/api/tenants/demo/my-performance", headers=seller_headers)
        data = resp.json()
        assert data["seller"]["current_status"] == "OFFLINE", \
            f"my-performance did not reflect status change: {data['seller']['current_status']}"
        print("PASS: my-performance reflects updated status OFFLINE")
        # Restore to AVAILABLE
        requests.patch(
            f"{BASE_URL}/api/tenants/demo/sellers/{seller_id}/status",
            headers=seller_headers,
            json={"new_status": "AVAILABLE"}
        )

    def test_seller_cannot_change_another_sellers_status(self, seller_headers, admin_headers):
        """A seller cannot change another seller's status (403)."""
        # Get another seller's ID via admin
        sellers_resp = requests.get(f"{BASE_URL}/api/tenants/demo/sellers", headers=admin_headers)
        if sellers_resp.status_code != 200:
            pytest.skip("Cannot get sellers list")
        
        sellers = sellers_resp.json()
        # Find a seller that is NOT joao@demo.com
        my_resp = requests.get(f"{BASE_URL}/api/tenants/demo/my-performance", headers=seller_headers)
        my_seller_id = my_resp.json()["seller"]["id"]
        
        other_sellers = [s for s in sellers if s["id"] != my_seller_id]
        if not other_sellers:
            pytest.skip("No other sellers to test against")
        
        other_id = other_sellers[0]["id"]
        resp = requests.patch(
            f"{BASE_URL}/api/tenants/demo/sellers/{other_id}/status",
            headers=seller_headers,
            json={"new_status": "OFFLINE"}
        )
        assert resp.status_code in [403, 401], \
            f"Expected 403/401, got {resp.status_code}: {resp.text}"
        print(f"PASS: seller cannot change another seller's status — got {resp.status_code}")

    def test_status_change_without_auth_returns_401(self, seller_id):
        resp = requests.patch(
            f"{BASE_URL}/api/tenants/demo/sellers/{seller_id}/status",
            json={"new_status": "OFFLINE"}
        )
        assert resp.status_code in [401, 403], \
            f"Expected 401/403, got {resp.status_code}"
        print(f"PASS: unauthenticated status change returns {resp.status_code}")


# ─── 4. Admin access to my-performance ───────────────────────────────────────

class TestAdminAccess:
    """Admin should NOT see seller's my-performance (no seller profile)."""

    def test_admin_my_performance_returns_404(self, admin_headers):
        """Admin user has no seller profile → 404."""
        resp = requests.get(f"{BASE_URL}/api/tenants/demo/my-performance", headers=admin_headers)
        # Admin has no seller profile, so should get 404
        # However if admin has performance.view_tenant, they might get 200 or 404
        assert resp.status_code in [200, 404], \
            f"Unexpected status for admin: {resp.status_code}: {resp.text}"
        print(f"PASS: Admin my-performance returns {resp.status_code}")


# ─── 5. Supplementary endpoints used by dashboard ────────────────────────────

class TestSupplementaryEndpoints:
    """Endpoints used by the dashboard's supplementary data loading."""

    def test_achievement_awards_my(self, seller_headers):
        """GET /achievement-awards/my used for unlocked badges."""
        resp = requests.get(f"{BASE_URL}/api/tenants/demo/achievement-awards/my",
                            headers=seller_headers)
        assert resp.status_code in [200, 404], \
            f"achievement-awards/my returned {resp.status_code}: {resp.text}"
        if resp.status_code == 200:
            data = resp.json()
            assert isinstance(data, list), "Expected list response"
        print(f"PASS: achievement-awards/my returns {resp.status_code}")

    def test_achievement_awards_my_progress(self, seller_headers):
        """GET /achievement-awards/my-progress used for next achievements."""
        resp = requests.get(f"{BASE_URL}/api/tenants/demo/achievement-awards/my-progress",
                            headers=seller_headers)
        assert resp.status_code in [200, 404], \
            f"achievement-awards/my-progress returned {resp.status_code}: {resp.text}"
        print(f"PASS: achievement-awards/my-progress returns {resp.status_code}")

    def test_feedbacks_list(self, seller_headers):
        """GET /feedbacks?page_size=5 used for latest feedbacks."""
        resp = requests.get(f"{BASE_URL}/api/tenants/demo/feedbacks?page_size=5",
                            headers=seller_headers)
        assert resp.status_code == 200, f"feedbacks returned {resp.status_code}: {resp.text}"
        data = resp.json()
        # Can be list or paginated response
        assert isinstance(data, (list, dict)), "Unexpected response type"
        print(f"PASS: feedbacks endpoint returns 200")
