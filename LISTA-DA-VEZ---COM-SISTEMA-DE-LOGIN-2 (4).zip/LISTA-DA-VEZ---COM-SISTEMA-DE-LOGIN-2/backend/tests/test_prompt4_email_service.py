"""Testes — Prompt 4: Serviço de e-mail transacional (SMTP, SES, log).

Cobre:
- _is_smtp_configured: True apenas quando SMTP_HOST + SMTP_USER + SMTP_PASS presentes
- _is_ses_configured: True quando AWS_REGION e SES_FROM_EMAIL presentes
- _build_html: HTML/texto contém link, nome do tenant e tipo de convite correto
- Modo log: retorna True sem chamada de rede
- Modo smtp: delega para _send_via_smtp, retorna True em sucesso
- Modo smtp: falha → retorna False, sem exceção propagada (API não quebra)
- Modo ses: delega para _send_via_ses, retorna True em sucesso
- Modo ses: falha → retorna False, sem exceção propagada
- log_delivery_fn chamado com status=DELIVERED em sucesso
- log_delivery_fn chamado com status=FAILED + error_message em falha
- Falha na log_delivery_fn não propaga exceção
- _send_via_smtp chama aiosmtplib.send com hostname/port/tls corretos
- _send_via_ses chama boto3.client("ses").send_email com destino e corpos corretos

Para rodar:
    cd /app/backend
    pytest tests/test_prompt4_email_service.py -v
"""
import asyncio
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from dotenv import load_dotenv
load_dotenv(os.path.join(os.path.dirname(os.path.dirname(__file__)), ".env"))

import pytest
from unittest.mock import patch, AsyncMock, MagicMock


# ─── helpers ──────────────────────────────────────────────────────────────────

def run(coro):
    """Executa corrotina em contexto síncrono (evita conflito de event loop nos testes)."""
    return asyncio.run(coro)


INVITE_KWARGS = dict(
    to_email="convite@exemplo.com.br",
    to_name="João Silva",
    invite_link="https://app.listadavez.com/invites/TOKEN123",
    invite_type="TENANT_OWNER",
    tenant_name="Loja Exemplo LTDA",
    tenant_id="tenant_abc123",
)


# ─────────────────────────────────────────────────────────────────────────────
# 1. _is_smtp_configured
# ─────────────────────────────────────────────────────────────────────────────

class TestSmtpConfigured:
    def test_falso_quando_tudo_vazio(self):
        import email_service
        with (
            patch.object(email_service, "SMTP_HOST", ""),
            patch.object(email_service, "SMTP_USER", ""),
            patch.object(email_service, "SMTP_PASS", ""),
        ):
            assert email_service._is_smtp_configured() is False

    def test_verdadeiro_quando_tudo_preenchido(self):
        import email_service
        with (
            patch.object(email_service, "SMTP_HOST", "smtp.exemplo.com"),
            patch.object(email_service, "SMTP_USER", "user@exemplo.com"),
            patch.object(email_service, "SMTP_PASS", "senha123"),
        ):
            assert email_service._is_smtp_configured() is True

    def test_falso_quando_so_host(self):
        import email_service
        with (
            patch.object(email_service, "SMTP_HOST", "smtp.exemplo.com"),
            patch.object(email_service, "SMTP_USER", ""),
            patch.object(email_service, "SMTP_PASS", ""),
        ):
            assert email_service._is_smtp_configured() is False


# ─────────────────────────────────────────────────────────────────────────────
# 2. _is_ses_configured
# ─────────────────────────────────────────────────────────────────────────────

class TestSesConfigured:
    def test_verdadeiro_quando_region_e_from_preenchidos(self):
        import email_service
        with (
            patch.object(email_service, "AWS_REGION", "us-east-1"),
            patch.object(email_service, "SES_FROM_EMAIL", "noreply@listadavez.com"),
        ):
            assert email_service._is_ses_configured() is True

    def test_falso_quando_region_vazio(self):
        import email_service
        with (
            patch.object(email_service, "AWS_REGION", ""),
            patch.object(email_service, "SES_FROM_EMAIL", "noreply@listadavez.com"),
        ):
            assert email_service._is_ses_configured() is False

    def test_falso_quando_from_email_vazio(self):
        import email_service
        with (
            patch.object(email_service, "AWS_REGION", "us-east-1"),
            patch.object(email_service, "SES_FROM_EMAIL", ""),
        ):
            assert email_service._is_ses_configured() is False


# ─────────────────────────────────────────────────────────────────────────────
# 3. _build_html
# ─────────────────────────────────────────────────────────────────────────────

class TestBuildHtml:
    def test_html_e_texto_contem_link_de_convite(self):
        import email_service
        html, text = email_service._build_html(
            tenant_name="Empresa Teste",
            invite_link="https://app.listadavez.com/invites/LINK_TESTE",
            invite_type="TENANT_OWNER",
            to_name="Maria",
        )
        assert "LINK_TESTE" in html
        assert "LINK_TESTE" in text

    def test_html_contem_nome_do_tenant(self):
        import email_service
        html, text = email_service._build_html(
            tenant_name="Loja Alfa LTDA",
            invite_link="https://exemplo.com",
            invite_type="TENANT_OWNER",
            to_name="",
        )
        assert "Loja Alfa LTDA" in html
        assert "Loja Alfa LTDA" in text

    def test_tipo_owner_menciona_dono_da_empresa(self):
        import email_service
        html, _ = email_service._build_html(
            tenant_name="Empresa X",
            invite_link="https://x.com",
            invite_type="TENANT_OWNER",
            to_name="",
        )
        assert "dono da empresa" in html

    def test_tipo_user_menciona_funcionario(self):
        import email_service
        html, _ = email_service._build_html(
            tenant_name="Empresa X",
            invite_link="https://x.com",
            invite_type="TENANT_USER",
            to_name="",
        )
        assert "funcionário" in html

    def test_saudacao_inclui_nome_quando_fornecido(self):
        import email_service
        html, text = email_service._build_html(
            tenant_name="Empresa X",
            invite_link="https://x.com",
            invite_type="TENANT_USER",
            to_name="Ana",
        )
        assert "Ana" in html
        assert "Ana" in text

    def test_html_e_texto_retornados_como_tuple(self):
        import email_service
        result = email_service._build_html(
            tenant_name="X", invite_link="https://x.com",
            invite_type="TENANT_OWNER", to_name="",
        )
        assert isinstance(result, tuple)
        assert len(result) == 2
        html, text = result
        assert "<html" in html.lower()
        assert len(text) > 10


# ─────────────────────────────────────────────────────────────────────────────
# 4. Modo log (fallback seguro em dev/CI)
# ─────────────────────────────────────────────────────────────────────────────

class TestModoLog:
    def test_retorna_true_sem_chamada_de_rede(self):
        import email_service
        with patch.object(email_service, "EMAIL_PROVIDER", "log"):
            resultado = run(email_service.send_invite_email(**INVITE_KWARGS))
        assert resultado is True

    def test_log_delivery_fn_chamado_com_delivered(self):
        import email_service
        delivery_calls = []

        async def mock_delivery(**kwargs):
            delivery_calls.append(kwargs)

        with patch.object(email_service, "EMAIL_PROVIDER", "log"):
            run(email_service.send_invite_email(
                **INVITE_KWARGS,
                log_delivery_fn=mock_delivery,
            ))

        assert len(delivery_calls) == 1
        assert delivery_calls[0]["status"] == "DELIVERED"
        assert delivery_calls[0]["tenant_id"] == "tenant_abc123"
        assert delivery_calls[0]["channel"] == "EMAIL"

    def test_provider_log_quando_smtp_sem_config(self):
        """EMAIL_PROVIDER=smtp sem variáveis → cai para modo log, retorna True."""
        import email_service
        with (
            patch.object(email_service, "EMAIL_PROVIDER", "smtp"),
            patch.object(email_service, "SMTP_HOST", ""),
            patch.object(email_service, "SMTP_USER", ""),
            patch.object(email_service, "SMTP_PASS", ""),
        ):
            resultado = run(email_service.send_invite_email(**INVITE_KWARGS))
        assert resultado is True


# ─────────────────────────────────────────────────────────────────────────────
# 5. Modo SMTP — via mock em _send_via_smtp
# ─────────────────────────────────────────────────────────────────────────────

class TestModoSmtp:
    def test_chama_send_via_smtp_e_retorna_true(self):
        import email_service
        mock_smtp = AsyncMock(return_value=None)
        with (
            patch.object(email_service, "EMAIL_PROVIDER", "smtp"),
            patch.object(email_service, "SMTP_HOST", "smtp.test.com"),
            patch.object(email_service, "SMTP_USER", "user@test.com"),
            patch.object(email_service, "SMTP_PASS", "senha"),
            patch.object(email_service, "_send_via_smtp", mock_smtp),
        ):
            resultado = run(email_service.send_invite_email(**INVITE_KWARGS))

        assert resultado is True
        assert mock_smtp.called
        # verifica que chamou com to_email correto (primeiro arg posicional)
        args = mock_smtp.call_args[0]
        assert args[0] == "convite@exemplo.com.br"

    def test_falha_smtp_retorna_false_sem_excecao(self):
        import email_service
        mock_smtp = AsyncMock(side_effect=Exception("Connection refused"))
        with (
            patch.object(email_service, "EMAIL_PROVIDER", "smtp"),
            patch.object(email_service, "SMTP_HOST", "smtp.test.com"),
            patch.object(email_service, "SMTP_USER", "user@test.com"),
            patch.object(email_service, "SMTP_PASS", "senha"),
            patch.object(email_service, "_send_via_smtp", mock_smtp),
        ):
            # Não deve lançar exceção
            resultado = run(email_service.send_invite_email(**INVITE_KWARGS))

        assert resultado is False

    def test_log_delivery_fn_com_delivered_em_sucesso_smtp(self):
        import email_service
        delivery_calls = []

        async def mock_delivery(**kwargs):
            delivery_calls.append(kwargs)

        mock_smtp = AsyncMock(return_value=None)
        with (
            patch.object(email_service, "EMAIL_PROVIDER", "smtp"),
            patch.object(email_service, "SMTP_HOST", "smtp.test.com"),
            patch.object(email_service, "SMTP_USER", "user@test.com"),
            patch.object(email_service, "SMTP_PASS", "senha"),
            patch.object(email_service, "_send_via_smtp", mock_smtp),
        ):
            run(email_service.send_invite_email(
                **INVITE_KWARGS,
                log_delivery_fn=mock_delivery,
            ))

        assert len(delivery_calls) == 1
        assert delivery_calls[0]["status"] == "DELIVERED"
        assert delivery_calls[0]["provider"] == "SMTP"

    def test_log_delivery_fn_com_failed_em_erro_smtp(self):
        import email_service
        delivery_calls = []

        async def mock_delivery(**kwargs):
            delivery_calls.append(kwargs)

        mock_smtp = AsyncMock(side_effect=ConnectionError("SMTP down"))
        with (
            patch.object(email_service, "EMAIL_PROVIDER", "smtp"),
            patch.object(email_service, "SMTP_HOST", "smtp.test.com"),
            patch.object(email_service, "SMTP_USER", "user@test.com"),
            patch.object(email_service, "SMTP_PASS", "senha"),
            patch.object(email_service, "_send_via_smtp", mock_smtp),
        ):
            run(email_service.send_invite_email(
                **INVITE_KWARGS,
                log_delivery_fn=mock_delivery,
            ))

        assert len(delivery_calls) == 1
        assert delivery_calls[0]["status"] == "FAILED"
        assert "SMTP down" in (delivery_calls[0]["error_message"] or "")


# ─────────────────────────────────────────────────────────────────────────────
# 6. Modo SES — via mock em _send_via_ses
# ─────────────────────────────────────────────────────────────────────────────

class TestModoSes:
    def test_chama_send_via_ses_e_retorna_true(self):
        import email_service
        mock_ses = AsyncMock(return_value=None)
        with (
            patch.object(email_service, "EMAIL_PROVIDER", "ses"),
            patch.object(email_service, "AWS_REGION", "us-east-1"),
            patch.object(email_service, "SES_FROM_EMAIL", "noreply@listadavez.com"),
            patch.object(email_service, "_send_via_ses", mock_ses),
        ):
            resultado = run(email_service.send_invite_email(**INVITE_KWARGS))

        assert resultado is True
        assert mock_ses.called

    def test_falha_ses_retorna_false_sem_excecao(self):
        import email_service
        mock_ses = AsyncMock(side_effect=Exception("SES quota exceeded"))
        with (
            patch.object(email_service, "EMAIL_PROVIDER", "ses"),
            patch.object(email_service, "AWS_REGION", "us-east-1"),
            patch.object(email_service, "SES_FROM_EMAIL", "noreply@listadavez.com"),
            patch.object(email_service, "_send_via_ses", mock_ses),
        ):
            resultado = run(email_service.send_invite_email(**INVITE_KWARGS))

        assert resultado is False

    def test_log_delivery_fn_com_failed_em_ses_error(self):
        import email_service
        delivery_calls = []

        async def mock_delivery(**kwargs):
            delivery_calls.append(kwargs)

        mock_ses = AsyncMock(side_effect=Exception("SES AuthFailure"))
        with (
            patch.object(email_service, "EMAIL_PROVIDER", "ses"),
            patch.object(email_service, "AWS_REGION", "us-east-1"),
            patch.object(email_service, "SES_FROM_EMAIL", "noreply@listadavez.com"),
            patch.object(email_service, "_send_via_ses", mock_ses),
        ):
            run(email_service.send_invite_email(
                **INVITE_KWARGS,
                log_delivery_fn=mock_delivery,
            ))

        assert len(delivery_calls) == 1
        assert delivery_calls[0]["status"] == "FAILED"
        assert "AuthFailure" in (delivery_calls[0]["error_message"] or "")


# ─────────────────────────────────────────────────────────────────────────────
# 7. Robustez do log_delivery_fn
# ─────────────────────────────────────────────────────────────────────────────

class TestLogDeliveryFnRobusto:
    def test_falha_na_callback_nao_propaga_excecao(self):
        """Mesmo que log_delivery_fn levante exceção, send_invite_email deve retornar."""
        import email_service

        async def delivery_falha(**kwargs):
            raise RuntimeError("DB indisponível")

        with patch.object(email_service, "EMAIL_PROVIDER", "log"):
            resultado = run(email_service.send_invite_email(
                **INVITE_KWARGS,
                log_delivery_fn=delivery_falha,
            ))
        # Envio ocorreu (modo log = True), callback falhou mas não propagou
        assert resultado is True

    def test_sem_callback_funciona_normalmente(self):
        import email_service
        with patch.object(email_service, "EMAIL_PROVIDER", "log"):
            resultado = run(email_service.send_invite_email(**INVITE_KWARGS))
        assert resultado is True


# ─────────────────────────────────────────────────────────────────────────────
# 8. _send_via_smtp — integração com aiosmtplib
# ─────────────────────────────────────────────────────────────────────────────

class TestSendViaSmtp:
    def test_chama_aiosmtplib_send_com_hostname_correto(self):
        import email_service
        import aiosmtplib

        mock_send = AsyncMock(return_value=None)
        with (
            patch.object(email_service, "SMTP_HOST", "smtp.custom.com"),
            patch.object(email_service, "SMTP_PORT", 465),
            patch.object(email_service, "SMTP_USER", "user@custom.com"),
            patch.object(email_service, "SMTP_PASS", "pass"),
            patch.object(email_service, "SMTP_FROM", "noreply@custom.com"),
            patch.object(email_service, "SMTP_SECURE", True),
            patch.object(aiosmtplib, "send", mock_send),
        ):
            run(email_service._send_via_smtp(
                to_email="dest@custom.com",
                subject="Assunto Teste",
                html="<p>HTML</p>",
                text="Texto puro",
            ))

        mock_send.assert_called_once()
        kwargs = mock_send.call_args[1]
        assert kwargs["hostname"] == "smtp.custom.com"
        assert kwargs["port"] == 465
        assert kwargs["use_tls"] is True

    def test_mensagem_mime_contem_destinatario(self):
        import email_service
        import aiosmtplib

        mock_send = AsyncMock(return_value=None)
        with (
            patch.object(email_service, "SMTP_HOST", "smtp.custom.com"),
            patch.object(email_service, "SMTP_PORT", 587),
            patch.object(email_service, "SMTP_USER", "u"),
            patch.object(email_service, "SMTP_PASS", "p"),
            patch.object(email_service, "SMTP_FROM", "from@custom.com"),
            patch.object(email_service, "SMTP_SECURE", False),
            patch.object(aiosmtplib, "send", mock_send),
        ):
            run(email_service._send_via_smtp(
                to_email="destinatario@exemplo.com",
                subject="Sub",
                html="<b>OK</b>",
                text="OK",
            ))

        # Primeiro argumento posicional é a mensagem MIME
        msg = mock_send.call_args[0][0]
        assert msg["To"] == "destinatario@exemplo.com"


# ─────────────────────────────────────────────────────────────────────────────
# 9. _send_via_ses — integração com boto3
# ─────────────────────────────────────────────────────────────────────────────

class TestSendViaSes:
    def test_chama_boto3_ses_com_destino_correto(self):
        import email_service
        import boto3

        mock_ses_client = MagicMock()
        mock_ses_client.send_email.return_value = {"MessageId": "msg-001"}

        with (
            patch.object(email_service, "AWS_REGION", "sa-east-1"),
            patch.object(email_service, "SES_FROM_EMAIL", "noreply@listadavez.com"),
            patch.object(boto3, "client", return_value=mock_ses_client),
        ):
            run(email_service._send_via_ses(
                to_email="cliente@empresa.com.br",
                subject="Convite",
                html="<p>HTML</p>",
                text="Texto",
            ))

        mock_ses_client.send_email.assert_called_once()
        call_kwargs = mock_ses_client.send_email.call_args[1]
        assert call_kwargs["Destination"]["ToAddresses"] == ["cliente@empresa.com.br"]
        assert call_kwargs["Source"] == "noreply@listadavez.com"

    def test_ses_levanta_excecao_quando_boto3_falha(self):
        import email_service
        import boto3

        mock_ses_client = MagicMock()
        mock_ses_client.send_email.side_effect = Exception("SES error")

        with (
            patch.object(email_service, "AWS_REGION", "us-east-1"),
            patch.object(email_service, "SES_FROM_EMAIL", "from@test.com"),
            patch.object(boto3, "client", return_value=mock_ses_client),
        ):
            with pytest.raises(Exception, match="SES error"):
                run(email_service._send_via_ses(
                    to_email="t@test.com", subject="S",
                    html="<p>h</p>", text="t",
                ))
