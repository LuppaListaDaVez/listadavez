"""
Testes Etapa 6 (P0 + P1):
- P0: quick-attendance endpoint
- P1: Edição e soft delete de Stores e Users
"""
import os
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")

# ─── Fixtures ────────────────────────────────────────────────────────────────

@pytest.fixture(scope="module")
def admin_headers():
    """Autentica como admin@demo.com e retorna headers."""
    r = requests.post(f"{BASE_URL}/api/auth/login", json={"email": "admin@demo.com", "password": "Admin@123456"})
    assert r.status_code == 200, f"Login admin falhou: {r.text}"
    token = r.json()["access_token"]
    return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}


@pytest.fixture(scope="module")
def seller_headers():
    """Autentica como joao@demo.com (SELLER) e retorna headers."""
    r = requests.post(f"{BASE_URL}/api/auth/login", json={"email": "joao@demo.com", "password": "Admin@123456"})
    assert r.status_code == 200, f"Login seller falhou: {r.text}"
    token = r.json()["access_token"]
    return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}


@pytest.fixture(scope="module")
def store_id(admin_headers):
    """Retorna o primeiro store_id da loja CENTRO."""
    r = requests.get(f"{BASE_URL}/api/tenants/demo/stores", headers=admin_headers)
    assert r.status_code == 200
    stores = r.json()
    centro = next((s for s in stores if s["code"] == "CENTRO"), None) or stores[0]
    return centro["id"]


@pytest.fixture(scope="module")
def queue_state(admin_headers, store_id):
    """Retorna o estado da fila."""
    r = requests.get(f"{BASE_URL}/api/tenants/demo/stores/{store_id}/queue", headers=admin_headers)
    assert r.status_code == 200
    return r.json()


@pytest.fixture(scope="module")
def available_seller_id(queue_state):
    """Retorna o seller_id de Ana Lima (AVAILABLE)."""
    avail = queue_state.get("available_sellers", [])
    assert len(avail) > 0, "Nenhum vendedor AVAILABLE encontrado. Verifique o estado da fila."
    return avail[0]["seller_id"]


@pytest.fixture(scope="module")
def waiting_seller_id(queue_state):
    """Retorna o seller_id de um vendedor WAITING_IN_QUEUE."""
    entries = queue_state.get("entries", [])
    assert len(entries) > 0, "Nenhum vendedor WAITING_IN_QUEUE encontrado."
    return entries[0]["seller_id"]


@pytest.fixture(scope="module")
def loss_reason_id(admin_headers):
    """Retorna um loss_reason_id ativo."""
    r = requests.get(f"{BASE_URL}/api/tenants/demo/loss-reasons", headers=admin_headers)
    assert r.status_code == 200
    reasons = [lr for lr in r.json() if lr.get("active") is not False]
    assert len(reasons) > 0, "Nenhum motivo de perda ativo encontrado."
    return reasons[0]["id"]


# ─── P0: quick-attendance ──────────────────────────────────────────────────

class TestQuickAttendance:
    """Testa o endpoint POST /queue/quick-attendance (P0)."""

    def test_quick_sale_returns_201_with_finished_quick(self, admin_headers, store_id, available_seller_id):
        """Venda rápida com vendedor AVAILABLE → 201, status=FINISHED, origin=QUICK."""
        payload = {
            "seller_id": available_seller_id,
            "result": "SALE",
            "sale_amount_cents": 15000,
            "customer_name": "Cliente Teste",
        }
        r = requests.post(
            f"{BASE_URL}/api/tenants/demo/stores/{store_id}/queue/quick-attendance",
            json=payload,
            headers=admin_headers,
        )
        assert r.status_code == 201, f"Esperado 201, got {r.status_code}: {r.text}"
        data = r.json()
        att = data.get("attendance", {})
        assert att.get("status") == "FINISHED", f"attendance.status deveria ser FINISHED, got: {att.get('status')}"
        assert att.get("origin") == "QUICK", f"attendance.origin deveria ser QUICK, got: {att.get('origin')}"
        assert att.get("result") == "SALE", f"attendance.result deveria ser SALE, got: {att.get('result')}"
        assert att.get("sale_amount_cents") == 15000, f"sale_amount_cents deveria ser 15000, got: {att.get('sale_amount_cents')}"

    def test_quick_sale_seller_returns_available_after(self, admin_headers, store_id, available_seller_id):
        """Após registro rápido, o vendedor volta para AVAILABLE."""
        r = requests.get(
            f"{BASE_URL}/api/tenants/demo/stores/{store_id}/queue",
            headers=admin_headers,
        )
        assert r.status_code == 200
        state = r.json()
        avail_ids = [s["seller_id"] for s in state.get("available_sellers", [])]
        assert available_seller_id in avail_ids, f"Vendedor {available_seller_id} deveria estar AVAILABLE após quick-attendance, mas não está."

    def test_quick_no_sale_with_loss_reason_returns_201(self, admin_headers, store_id, available_seller_id, loss_reason_id):
        """Não-venda com motivo → 201."""
        payload = {
            "seller_id": available_seller_id,
            "result": "NO_SALE",
            "loss_reason_id": loss_reason_id,
            "customer_name": "Cliente Teste NS",
        }
        r = requests.post(
            f"{BASE_URL}/api/tenants/demo/stores/{store_id}/queue/quick-attendance",
            json=payload,
            headers=admin_headers,
        )
        assert r.status_code == 201, f"Esperado 201, got {r.status_code}: {r.text}"
        att = r.json().get("attendance", {})
        assert att.get("status") == "FINISHED"
        assert att.get("result") == "NO_SALE"
        assert att.get("origin") == "QUICK"

    def test_quick_waiting_seller_returns_409(self, admin_headers, store_id, waiting_seller_id):
        """Vendedor em WAITING_IN_QUEUE → 409."""
        payload = {
            "seller_id": waiting_seller_id,
            "result": "SALE",
            "sale_amount_cents": 10000,
        }
        r = requests.post(
            f"{BASE_URL}/api/tenants/demo/stores/{store_id}/queue/quick-attendance",
            json=payload,
            headers=admin_headers,
        )
        assert r.status_code == 409, f"Esperado 409, got {r.status_code}: {r.text}"

    def test_quick_seller_role_returns_403(self, seller_headers, store_id, available_seller_id):
        """Role SELLER → 403."""
        payload = {
            "seller_id": available_seller_id,
            "result": "SALE",
            "sale_amount_cents": 5000,
        }
        r = requests.post(
            f"{BASE_URL}/api/tenants/demo/stores/{store_id}/queue/quick-attendance",
            json=payload,
            headers=seller_headers,
        )
        assert r.status_code == 403, f"Esperado 403, got {r.status_code}: {r.text}"

    def test_quick_no_sale_missing_loss_reason_returns_400(self, admin_headers, store_id, available_seller_id):
        """NO_SALE sem loss_reason quando require_loss_reason=True → 400."""
        payload = {
            "seller_id": available_seller_id,
            "result": "NO_SALE",
        }
        r = requests.post(
            f"{BASE_URL}/api/tenants/demo/stores/{store_id}/queue/quick-attendance",
            json=payload,
            headers=admin_headers,
        )
        # settings.require_loss_reason=True → 400
        assert r.status_code == 400, f"Esperado 400, got {r.status_code}: {r.text}"


# ─── P1: Stores edit + soft delete ────────────────────────────────────────

class TestStoresP1:
    """Testa edição (PUT) e soft delete (PATCH status) de Stores."""

    def test_list_stores_returns_200(self, admin_headers):
        """GET /stores → 200 com lista."""
        r = requests.get(f"{BASE_URL}/api/tenants/demo/stores", headers=admin_headers)
        assert r.status_code == 200
        stores = r.json()
        assert isinstance(stores, list)
        assert len(stores) > 0

    def test_update_store_name(self, admin_headers, store_id):
        """PUT /stores/{id} com novo nome → 200 com dados atualizados."""
        # Busca estado atual
        r = requests.get(f"{BASE_URL}/api/tenants/demo/stores/{store_id}", headers=admin_headers)
        orig_name = r.json()["name"]
        new_name = f"{orig_name} (Editado)"

        r2 = requests.put(
            f"{BASE_URL}/api/tenants/demo/stores/{store_id}",
            json={"name": new_name},
            headers=admin_headers,
        )
        assert r2.status_code == 200, f"Esperado 200, got {r2.status_code}: {r2.text}"
        assert r2.json()["name"] == new_name, f"Nome não atualizado: {r2.json()}"

    def test_update_store_verifies_persistence(self, admin_headers, store_id):
        """Após PUT, GET confirma que o novo nome persiste."""
        r = requests.get(f"{BASE_URL}/api/tenants/demo/stores/{store_id}", headers=admin_headers)
        assert r.status_code == 200
        assert "(Editado)" in r.json()["name"]

    def test_restore_store_name(self, admin_headers, store_id):
        """Restaura o nome original da unidade."""
        r = requests.put(
            f"{BASE_URL}/api/tenants/demo/stores/{store_id}",
            json={"name": "Unidade Centro"},
            headers=admin_headers,
        )
        assert r.status_code == 200
        assert r.json()["name"] == "Unidade Centro"

    def test_toggle_store_status_inactive(self, admin_headers, store_id):
        """PATCH /stores/{id}/status com INACTIVE → 200."""
        r = requests.patch(
            f"{BASE_URL}/api/tenants/demo/stores/{store_id}/status",
            json={"status": "INACTIVE"},
            headers=admin_headers,
        )
        assert r.status_code == 200, f"Esperado 200, got {r.status_code}: {r.text}"
        data = r.json()
        assert data["status"] == "INACTIVE"

    def test_toggle_store_status_back_to_active(self, admin_headers, store_id):
        """PATCH /stores/{id}/status com ACTIVE → 200."""
        r = requests.patch(
            f"{BASE_URL}/api/tenants/demo/stores/{store_id}/status",
            json={"status": "ACTIVE"},
            headers=admin_headers,
        )
        assert r.status_code == 200, f"Esperado 200, got {r.status_code}: {r.text}"
        assert r.json()["status"] == "ACTIVE"

    def test_store_status_persists_after_toggle(self, admin_headers, store_id):
        """GET após toggles confirma status ACTIVE final."""
        r = requests.get(f"{BASE_URL}/api/tenants/demo/stores/{store_id}", headers=admin_headers)
        assert r.status_code == 200
        assert r.json()["status"] == "ACTIVE"


# ─── P1: Users edit + soft delete ────────────────────────────────────────

class TestUsersP1:
    """Testa edição (PUT) e soft delete (PATCH status) de Users."""

    @pytest.fixture(scope="class")
    def joao_id(self, admin_headers):
        """Retorna o user_id de joao@demo.com."""
        r = requests.get(f"{BASE_URL}/api/tenants/demo/users", headers=admin_headers)
        assert r.status_code == 200
        users = r.json()
        joao = next((u for u in users if u["email"] == "joao@demo.com"), None)
        assert joao, "joao@demo.com não encontrado na lista de usuários"
        return joao["id"]

    def test_list_users_returns_200(self, admin_headers):
        """GET /users → 200 com lista."""
        r = requests.get(f"{BASE_URL}/api/tenants/demo/users", headers=admin_headers)
        assert r.status_code == 200
        assert isinstance(r.json(), list)
        assert len(r.json()) > 0

    def test_update_user_phone(self, admin_headers, joao_id):
        """PUT /users/{id} com novo telefone → 200."""
        r = requests.put(
            f"{BASE_URL}/api/tenants/demo/users/{joao_id}",
            json={"phone": "11999990001"},
            headers=admin_headers,
        )
        assert r.status_code == 200, f"Esperado 200, got {r.status_code}: {r.text}"
        assert r.json().get("phone") == "11999990001", f"Telefone não atualizado: {r.json()}"

    def test_update_user_verifies_persistence(self, admin_headers, joao_id):
        """Após PUT, GET confirma que o telefone persiste."""
        r = requests.get(f"{BASE_URL}/api/tenants/demo/users/{joao_id}", headers=admin_headers)
        assert r.status_code == 200
        assert r.json().get("phone") == "11999990001"

    def test_update_user_name(self, admin_headers, joao_id):
        """PUT /users/{id} com novo nome → 200."""
        r = requests.put(
            f"{BASE_URL}/api/tenants/demo/users/{joao_id}",
            json={"name": "João Silva (Editado)"},
            headers=admin_headers,
        )
        assert r.status_code == 200
        assert "Editado" in r.json()["name"]

    def test_restore_user_name(self, admin_headers, joao_id):
        """Restaura o nome original do usuário."""
        r = requests.put(
            f"{BASE_URL}/api/tenants/demo/users/{joao_id}",
            json={"name": "João Silva"},
            headers=admin_headers,
        )
        assert r.status_code == 200
        assert r.json()["name"] == "João Silva"

    def test_toggle_user_status_inactive(self, admin_headers, joao_id):
        """PATCH /users/{id}/status com INACTIVE → 200."""
        r = requests.patch(
            f"{BASE_URL}/api/tenants/demo/users/{joao_id}/status",
            json={"status": "INACTIVE"},
            headers=admin_headers,
        )
        assert r.status_code == 200, f"Esperado 200, got {r.status_code}: {r.text}"
        assert r.json()["status"] == "INACTIVE"

    def test_toggle_user_status_back_to_active(self, admin_headers, joao_id):
        """PATCH /users/{id}/status com ACTIVE → 200."""
        r = requests.patch(
            f"{BASE_URL}/api/tenants/demo/users/{joao_id}/status",
            json={"status": "ACTIVE"},
            headers=admin_headers,
        )
        assert r.status_code == 200, f"Esperado 200, got {r.status_code}: {r.text}"
        assert r.json()["status"] == "ACTIVE"

    def test_user_status_persists_after_toggle(self, admin_headers, joao_id):
        """GET após toggles confirma status ACTIVE final."""
        r = requests.get(f"{BASE_URL}/api/tenants/demo/users/{joao_id}", headers=admin_headers)
        assert r.status_code == 200
        assert r.json()["status"] == "ACTIVE"
