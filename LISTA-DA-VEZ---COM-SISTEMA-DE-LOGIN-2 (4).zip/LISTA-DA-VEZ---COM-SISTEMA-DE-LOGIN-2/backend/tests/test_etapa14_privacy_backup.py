"""
Tests for Etapa 14: Privacy/LGPD, Retention, Backup/Restore
"""
import pytest
import requests
import os
import time

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', 'https://queue-mgmt-3.preview.emergentagent.com').rstrip('/')

ADMIN_CREDS = {"email": "admin@demo.com", "password": "Admin@123456"}
SELLER_CREDS = {"email": "joao@demo.com", "password": "Admin@123456"}
TENANT = "demo"


@pytest.fixture(scope="module")
def admin_token():
    r = requests.post(f"{BASE_URL}/api/tenants/{TENANT}/auth/login", json=ADMIN_CREDS)
    assert r.status_code == 200, f"Admin login failed: {r.text}"
    return r.json()["access_token"]


@pytest.fixture(scope="module")
def seller_token():
    r = requests.post(f"{BASE_URL}/api/tenants/{TENANT}/auth/login", json=SELLER_CREDS)
    assert r.status_code == 200, f"Seller login failed: {r.text}"
    return r.json()["access_token"]


@pytest.fixture(scope="module")
def admin_headers(admin_token):
    return {"Authorization": f"Bearer {admin_token}"}


@pytest.fixture(scope="module")
def seller_headers(seller_token):
    return {"Authorization": f"Bearer {seller_token}"}


# ── Privacy Requests ──────────────────────────────────────────────────────────

class TestPrivacyRequests:
    """LGPD Privacy Request endpoints"""

    def test_list_requests_admin(self, admin_headers):
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/privacy/requests", headers=admin_headers)
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, list)
        assert len(data) >= 3, f"Expected >= 3 seed requests, got {len(data)}"
        print(f"PASS: list_requests_admin — {len(data)} requests")

    def test_list_requests_stats(self, admin_headers):
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/privacy/requests/stats", headers=admin_headers)
        assert r.status_code == 200
        data = r.json()
        assert "total" in data
        assert data["total"] >= 3
        print(f"PASS: requests stats — {data}")

    def test_create_request(self, admin_headers):
        payload = {
            "request_type": "ACCESS",
            "requester_type": "SELF",
            "data_subject_type": "USER",
            "description": "TEST_E2E request",
            "priority": "NORMAL"
        }
        r = requests.post(f"{BASE_URL}/api/tenants/{TENANT}/privacy/requests", json=payload, headers=admin_headers)
        assert r.status_code == 200
        data = r.json()
        assert "id" in data
        assert data["request_type"] == "ACCESS"
        print(f"PASS: create_request — id={data['id']}")
        return data["id"]

    def test_get_request_detail(self, admin_headers):
        # Get list to find OPEN request
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/privacy/requests?status=OPEN", headers=admin_headers)
        assert r.status_code == 200
        data = r.json()
        assert len(data) >= 1, "Expected at least 1 OPEN request"
        req_id = data[0]["id"]
        r2 = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/privacy/requests/{req_id}", headers=admin_headers)
        assert r2.status_code == 200
        detail = r2.json()
        assert detail["id"] == req_id
        print(f"PASS: get_request_detail — {req_id}")

    def test_filter_by_status(self, admin_headers):
        for status in ["OPEN", "IN_REVIEW", "RESOLVED"]:
            r = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/privacy/requests?status={status}", headers=admin_headers)
            assert r.status_code == 200
            data = r.json()
            for item in data:
                assert item["status"] == status
        print("PASS: filter_by_status")

    def test_seller_can_create_own_request(self, seller_headers):
        payload = {
            "request_type": "ACCESS",
            "description": "TEST_seller own request",
            "priority": "NORMAL"
        }
        r = requests.post(f"{BASE_URL}/api/tenants/{TENANT}/privacy/requests", json=payload, headers=seller_headers)
        assert r.status_code == 200
        data = r.json()
        assert "id" in data
        print(f"PASS: seller_create_own_request — id={data['id']}")

    def test_seller_cannot_see_all_requests(self, seller_headers, admin_headers):
        admin_r = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/privacy/requests", headers=admin_headers)
        seller_r = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/privacy/requests", headers=seller_headers)
        assert admin_r.status_code == 200
        assert seller_r.status_code == 200
        admin_count = len(admin_r.json())
        seller_count = len(seller_r.json())
        # Seller should see fewer requests (only own) vs admin sees all
        assert seller_count <= admin_count, "Seller should not see more requests than admin"
        print(f"PASS: isolation — admin={admin_count}, seller={seller_count}")


# ── Consents ───────────────────────────────────────────────────────────────────

class TestConsents:
    def test_list_consents(self, admin_headers):
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/privacy/consents", headers=admin_headers)
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, list)
        assert len(data) >= 2
        print(f"PASS: list_consents — {len(data)} consents")

    def test_consent_events(self, admin_headers):
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/privacy/consent-events", headers=admin_headers)
        assert r.status_code == 200
        print(f"PASS: consent_events — {len(r.json())} events")


# ── Data Map ───────────────────────────────────────────────────────────────────

class TestDataMap:
    def test_data_map_6_categories(self, admin_headers):
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/privacy/data-map", headers=admin_headers)
        assert r.status_code == 200
        data = r.json()
        assert len(data) >= 6
        print(f"PASS: data_map — {len(data)} categories")


# ── Data Exports ───────────────────────────────────────────────────────────────

class TestDataExports:
    def test_create_export(self, admin_headers):
        # Get admin user id from me endpoint or just use None to export self
        r = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT}/privacy/data-exports",
            json={"file_format": "JSON"},
            headers=admin_headers
        )
        assert r.status_code == 200
        data = r.json()
        assert "id" in data
        # Verify no password_hash in export data
        if "data" in data:
            assert "password_hash" not in str(data.get("data", ""))
        print(f"PASS: create_export — id={data['id']}")

    def test_list_exports(self, admin_headers):
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/privacy/data-exports", headers=admin_headers)
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, list)
        print(f"PASS: list_exports — {len(data)} exports")


# ── Privacy Settings ────────────────────────────────────────────────────────────

class TestPrivacySettings:
    def test_get_settings(self, admin_headers):
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/settings/data-protection", headers=admin_headers)
        assert r.status_code == 200
        data = r.json()
        assert "dpo_name" in data or "tenant_id" in data
        print(f"PASS: get_settings — {data}")

    def test_update_settings(self, admin_headers):
        r = requests.put(
            f"{BASE_URL}/api/tenants/{TENANT}/settings/data-protection",
            json={"dpo_name": "DPO Demo", "dpo_email": "dpo@demo.com"},
            headers=admin_headers
        )
        assert r.status_code == 200
        data = r.json()
        assert data["dpo_name"] == "DPO Demo"
        print(f"PASS: update_settings")


# ── Retention ───────────────────────────────────────────────────────────────────

class TestRetention:
    def test_list_policies(self, admin_headers):
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/retention/policies", headers=admin_headers)
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, list)
        assert len(data) >= 12
        print(f"PASS: list_retention_policies — {len(data)} policies")

    def test_retention_preview(self, admin_headers):
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/retention/policies", headers=admin_headers)
        policies = r.json()
        if policies:
            policy_id = policies[0]["id"]
            r2 = requests.post(
                f"{BASE_URL}/api/tenants/{TENANT}/retention/policies/{policy_id}/preview",
                json={},
                headers=admin_headers
            )
            assert r2.status_code == 200
            print(f"PASS: retention_preview — {r2.json()}")


# ── Backups ─────────────────────────────────────────────────────────────────────

class TestBackups:
    def test_list_backups(self, admin_headers):
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/backups", headers=admin_headers)
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, list)
        assert len(data) >= 1
        completed = [b for b in data if b.get("status") == "COMPLETED"]
        assert len(completed) >= 1, "Expected at least 1 COMPLETED backup"
        print(f"PASS: list_backups — {len(data)} backups, {len(completed)} completed")

    def test_create_backup(self, admin_headers):
        r = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT}/backups",
            json={"backup_type": "TENANT_FULL"},
            headers=admin_headers
        )
        assert r.status_code == 200
        data = r.json()
        # Response is {"snapshot": {...}, "job": {...}}
        snap = data.get("snapshot", data)
        assert "id" in snap
        assert snap.get("status") in ["COMPLETED", "RUNNING", "PENDING"]
        print(f"PASS: create_backup — id={snap['id']}, status={snap.get('status')}")

    def test_restore_preview(self, admin_headers):
        # Get first completed backup
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/backups", headers=admin_headers)
        backups = r.json()
        completed = [b for b in backups if b.get("status") == "COMPLETED"]
        assert len(completed) >= 1
        backup_id = completed[0]["id"]
        r2 = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT}/restore/preview",
            json={"snapshot_id": backup_id, "mode": "RESTORE_CONFIG_ONLY"},
            headers=admin_headers
        )
        assert r2.status_code == 200
        data = r2.json()
        assert "id" in data or "restore_job_id" in data or "snapshot_id" in data
        print(f"PASS: restore_preview — {data}")


# ── Legal Hold ───────────────────────────────────────────────────────────────────

class TestLegalHold:
    def test_list_legal_holds(self, admin_headers):
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/retention/legal-holds", headers=admin_headers)
        assert r.status_code in [200, 404], f"Unexpected: {r.status_code} {r.text}"
        if r.status_code == 200:
            data = r.json()
            print(f"PASS: legal_holds — {len(data)} holds")
        else:
            print(f"INFO: legal-holds endpoint not found (404)")
