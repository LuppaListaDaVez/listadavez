"""Etapa 4 — Realtime / WebSocket regression tests.

Cobre:
- /api/health version 1.0.0-etapa-4
- /api/metrics retorna chaves de realtime
- WS conecta com token válido e recebe connection.ready
- WS recusa conexão sem token / token inválido / feature desativada
- Broadcast: ação HTTP de fila gera eventos no WS
- Isolamento: WS de uma store NÃO recebe eventos de outra store
"""
import asyncio
import json
import os
import re
import time

import pytest
import requests
import websockets

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")
assert BASE_URL, "REACT_APP_BACKEND_URL not set"
# WS URL = wss replacing https
WS_BASE = re.sub(r"^http", "ws", BASE_URL)
# Internal backend (bypass Cloudflare 1010 block on python User-Agent)
INTERNAL_BASE = "http://localhost:8001"
BROWSER_UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"
TENANT_SLUG = "demo"
STORE_CODE = "CENTRO"


def _login(email, password, tenant_slug=None, base=BASE_URL):
    payload = {"email": email, "password": password}
    if tenant_slug:
        payload["tenant_slug"] = tenant_slug
    r = requests.post(f"{base}/api/auth/login", json=payload, timeout=15, headers={"User-Agent": BROWSER_UA})
    assert r.status_code == 200, f"login {email} failed: {r.status_code} {r.text[:300]}"
    return r.json()["access_token"]


def _h(token):
    return {"Authorization": f"Bearer {token}", "Content-Type": "application/json", "User-Agent": BROWSER_UA}


@pytest.fixture(scope="module")
def super_token():
    return _login("admin@listadavez.com", "Admin@123456")


@pytest.fixture(scope="module")
def admin_token():
    return _login("admin@demo.com", "Admin@123456", TENANT_SLUG)


@pytest.fixture(scope="module")
def store(admin_token):
    r = requests.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores", headers=_h(admin_token), timeout=15)
    assert r.status_code == 200, r.text
    stores = r.json()
    return next((s for s in stores if s.get("code") == STORE_CODE), stores[0])


@pytest.fixture(scope="module")
def tenant_id(super_token):
    r = requests.get(f"{BASE_URL}/api/super-admin/tenants", headers=_h(super_token), timeout=15)
    assert r.status_code == 200
    t = next(t for t in r.json() if t.get("slug") == TENANT_SLUG)
    return t["id"]


@pytest.fixture(scope="module")
def joao(admin_token, store):
    r = requests.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/sellers?store_id={store['id']}",
                     headers=_h(admin_token), timeout=15)
    assert r.status_code == 200
    data = r.json()
    for s in data:
        if (s.get("user") or {}).get("email") == "joao@demo.com":
            return s
    raise AssertionError("joao seller missing")


def _set_feature(super_token, tenant_id, key, enabled):
    r = requests.patch(
        f"{BASE_URL}/api/super-admin/tenants/{tenant_id}/features",
        headers=_h(super_token),
        json={"features": [{"feature_key": key, "enabled": enabled}]},
        timeout=15,
    )
    assert r.status_code in (200, 204), r.text


# ============ Health / Metrics ============
class TestHealthMetrics:
    def test_health_version(self):
        r = requests.get(f"{BASE_URL}/api/health", timeout=10, headers={"User-Agent": BROWSER_UA})
        assert r.status_code == 200
        assert r.json().get("version") == "1.0.0-etapa-4"

    def test_metrics_has_realtime_keys(self):
        r = requests.get(f"{BASE_URL}/api/metrics", timeout=10, headers={"User-Agent": BROWSER_UA})
        assert r.status_code == 200, r.text
        data = r.json()
        for k in ("active_websocket_connections", "active_websocket_connections_by_store",
                  "realtime_mode", "events_published_count", "events_failed_count"):
            assert k in data, f"missing key {k}"
        assert data["realtime_mode"] == "in_memory"


# ============ WS auth ============
class TestWebSocketAuth:
    @pytest.mark.asyncio
    async def test_ws_connects_and_receives_ready(self, admin_token, store):
        url = f"{WS_BASE}/api/ws/tenants/{TENANT_SLUG}/stores/{store['id']}?token={admin_token}"
        async with websockets.connect(url, open_timeout=15) as ws:
            msg = await asyncio.wait_for(ws.recv(), timeout=10)
            data = json.loads(msg)
            assert data["event_type"] == "connection.ready"
            assert data["store_id"] == store["id"]

    @pytest.mark.asyncio
    async def test_ws_rejects_without_token(self, store):
        url = f"{WS_BASE}/api/ws/tenants/{TENANT_SLUG}/stores/{store['id']}"
        with pytest.raises(Exception):
            async with websockets.connect(url, open_timeout=10) as ws:
                await asyncio.wait_for(ws.recv(), timeout=5)

    @pytest.mark.asyncio
    async def test_ws_rejects_invalid_token(self, store):
        url = f"{WS_BASE}/api/ws/tenants/{TENANT_SLUG}/stores/{store['id']}?token=invalid.jwt.token"
        with pytest.raises(Exception):
            async with websockets.connect(url, open_timeout=10) as ws:
                await asyncio.wait_for(ws.recv(), timeout=5)

    @pytest.mark.asyncio
    async def test_ws_rejects_when_feature_disabled(self, super_token, admin_token, store, tenant_id):
        _set_feature(super_token, tenant_id, "tempo_real", False)
        try:
            url = f"{WS_BASE}/api/ws/tenants/{TENANT_SLUG}/stores/{store['id']}?token={admin_token}"
            with pytest.raises(Exception):
                async with websockets.connect(url, open_timeout=10) as ws:
                    await asyncio.wait_for(ws.recv(), timeout=5)
        finally:
            _set_feature(super_token, tenant_id, "tempo_real", True)


# ============ Broadcast & Isolation ============
def _reset_seller(admin_token, store_id, seller_id):
    requests.post(
        f"{INTERNAL_BASE}/api/tenants/{TENANT_SLUG}/stores/{store_id}/queue/leave",
        headers=_h(admin_token), json={"seller_id": seller_id}, timeout=15,
    )
    requests.post(
        f"{INTERNAL_BASE}/api/tenants/{TENANT_SLUG}/stores/{store_id}/queue/return",
        headers=_h(admin_token), json={"seller_id": seller_id, "join_queue": False}, timeout=15,
    )


class TestRealtimeBroadcast:
    @pytest.mark.asyncio
    async def test_join_broadcasts_to_ws(self, admin_token, store, joao):
        # ensure clean state via internal (avoids Cloudflare 1010)
        _reset_seller(admin_token, store["id"], joao["id"])

        url = f"{WS_BASE}/api/ws/tenants/{TENANT_SLUG}/stores/{store['id']}?token={admin_token}"
        async with websockets.connect(url, open_timeout=15) as ws:
            ready = json.loads(await asyncio.wait_for(ws.recv(), timeout=10))
            assert ready["event_type"] == "connection.ready"

            # Trigger join via internal backend with browser UA
            r = requests.post(
                f"{INTERNAL_BASE}/api/tenants/{TENANT_SLUG}/stores/{store['id']}/queue/join",
                headers=_h(admin_token), json={"seller_id": joao["id"]}, timeout=15,
            )
            assert r.status_code == 200, r.text

            # collect events for up to ~4s
            received = []
            deadline = time.time() + 4
            while time.time() < deadline:
                try:
                    raw = await asyncio.wait_for(ws.recv(), timeout=1.5)
                    received.append(json.loads(raw))
                except asyncio.TimeoutError:
                    break

            types = {e["event_type"] for e in received}
            assert "queue.seller_joined" in types or "queue.updated" in types, f"got types={types}"
            assert "queue.updated" in types
            assert "dashboard.updated" in types

        _reset_seller(admin_token, store["id"], joao["id"])

    @pytest.mark.asyncio
    async def test_isolation_other_store_does_not_receive(self, admin_token, store, joao):
        # Find another store (or skip if only one)
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores",
                         headers=_h(admin_token), timeout=15)
        all_stores = r.json()
        other = next((s for s in all_stores if s["id"] != store["id"]), None)
        if not other:
            pytest.skip("No second store available for isolation test")

        _reset_seller(admin_token, store["id"], joao["id"])
        url_other = f"{WS_BASE}/api/ws/tenants/{TENANT_SLUG}/stores/{other['id']}?token={admin_token}"
        async with websockets.connect(url_other, open_timeout=15) as ws:
            ready = json.loads(await asyncio.wait_for(ws.recv(), timeout=10))
            assert ready["event_type"] == "connection.ready"

            # Trigger action on STORE (not other)
            r = requests.post(
                f"{INTERNAL_BASE}/api/tenants/{TENANT_SLUG}/stores/{store['id']}/queue/join",
                headers=_h(admin_token), json={"seller_id": joao["id"]}, timeout=15,
            )
            assert r.status_code == 200, r.text

            received = []
            deadline = time.time() + 3
            while time.time() < deadline:
                try:
                    raw = await asyncio.wait_for(ws.recv(), timeout=1.0)
                    received.append(json.loads(raw))
                except asyncio.TimeoutError:
                    break

            # OTHER store WS must not receive events from STORE
            for ev in received:
                assert ev.get("store_id") != store["id"], f"cross-store leak: {ev}"

        _reset_seller(admin_token, store["id"], joao["id"])
