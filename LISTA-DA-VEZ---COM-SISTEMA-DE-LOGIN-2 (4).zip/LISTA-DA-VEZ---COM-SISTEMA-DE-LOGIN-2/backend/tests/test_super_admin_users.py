"""Tests for GET /api/super-admin/tenants/{tenant_id}/users endpoint."""
import pytest
import requests
import os

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")

SUPER_ADMIN_EMAIL = "admin@listadavez.com"
SUPER_ADMIN_PASS = "Admin@123456"

TENANT_USER_EMAIL = "joao@demo.com"
TENANT_USER_PASS = "Admin@123456"
TENANT_SLUG = "demo"

DEMO_TENANT_ID = "5198f594-9af3-4654-90f8-4648ad9fe43b"


def get_super_admin_token():
    resp = requests.post(f"{BASE_URL}/api/auth/login", json={
        "email": SUPER_ADMIN_EMAIL,
        "password": SUPER_ADMIN_PASS,
    })
    if resp.status_code == 200:
        return resp.json().get("access_token")
    return None


def get_tenant_user_token():
    resp = requests.post(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/auth/login", json={
        "email": TENANT_USER_EMAIL,
        "password": TENANT_USER_PASS,
    })
    if resp.status_code == 200:
        return resp.json().get("access_token")
    return None


class TestSuperAdminTenantUsers:
    """Tests for the tenant users listing endpoint."""

    def test_super_admin_login_succeeds(self):
        token = get_super_admin_token()
        assert token is not None, "Super admin login failed"
        print("PASS: Super admin login OK")

    def test_list_tenants_returns_200(self):
        token = get_super_admin_token()
        assert token, pytest.skip("No super admin token")
        resp = requests.get(
            f"{BASE_URL}/api/super-admin/tenants",
            headers={"Authorization": f"Bearer {token}"}
        )
        assert resp.status_code == 200
        data = resp.json()
        assert isinstance(data, list)
        print(f"PASS: list tenants returned {len(data)} tenants")

    def test_get_tenant_users_returns_200(self):
        token = get_super_admin_token()
        assert token, pytest.skip("No super admin token")
        resp = requests.get(
            f"{BASE_URL}/api/super-admin/tenants/{DEMO_TENANT_ID}/users",
            headers={"Authorization": f"Bearer {token}"}
        )
        assert resp.status_code == 200
        data = resp.json()
        assert isinstance(data, list)
        print(f"PASS: get tenant users returned {len(data)} users")

    def test_tenant_users_no_password_field(self):
        token = get_super_admin_token()
        assert token, pytest.skip("No super admin token")
        resp = requests.get(
            f"{BASE_URL}/api/super-admin/tenants/{DEMO_TENANT_ID}/users",
            headers={"Authorization": f"Bearer {token}"}
        )
        assert resp.status_code == 200
        data = resp.json()
        assert isinstance(data, list)
        for user in data:
            assert "password" not in user, f"password field found in user: {user}"
            assert "password_hash" not in user, f"password_hash found in user: {user}"
            assert "hashed_password" not in user, f"hashed_password found in user: {user}"
        print(f"PASS: No password fields in {len(data)} users")

    def test_tenant_users_have_required_fields(self):
        token = get_super_admin_token()
        assert token, pytest.skip("No super admin token")
        resp = requests.get(
            f"{BASE_URL}/api/super-admin/tenants/{DEMO_TENANT_ID}/users",
            headers={"Authorization": f"Bearer {token}"}
        )
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) > 0, "Expected at least one user in demo tenant"
        for user in data:
            assert "name" in user
            assert "email" in user
            assert "role" in user
        print(f"PASS: All users have name/email/role fields")

    def test_tenant_user_cannot_access_endpoint(self):
        """Tenant user (joao@demo.com) should get 401/403."""
        token = get_tenant_user_token()
        if not token:
            pytest.skip("Could not get tenant user token")
        resp = requests.get(
            f"{BASE_URL}/api/super-admin/tenants/{DEMO_TENANT_ID}/users",
            headers={"Authorization": f"Bearer {token}"}
        )
        assert resp.status_code in [401, 403], f"Expected 401/403, got {resp.status_code}"
        print(f"PASS: Tenant user got {resp.status_code} (forbidden)")

    def test_unauthenticated_access_rejected(self):
        resp = requests.get(f"{BASE_URL}/api/super-admin/tenants/{DEMO_TENANT_ID}/users")
        assert resp.status_code in [401, 403]
        print(f"PASS: Unauthenticated got {resp.status_code}")

    def test_nonexistent_tenant_returns_404(self):
        token = get_super_admin_token()
        assert token, pytest.skip("No super admin token")
        resp = requests.get(
            f"{BASE_URL}/api/super-admin/tenants/nonexistent-tenant-id/users",
            headers={"Authorization": f"Bearer {token}"}
        )
        assert resp.status_code == 404
        print("PASS: nonexistent tenant returns 404")
