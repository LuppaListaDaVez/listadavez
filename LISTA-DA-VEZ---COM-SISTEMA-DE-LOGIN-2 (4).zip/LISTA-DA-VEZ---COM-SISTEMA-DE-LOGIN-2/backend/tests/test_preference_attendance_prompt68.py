"""Prompt 68 regression: preferência desabilitada deve bloquear start para vendedor."""

import os

import pytest
import requests


BASE_URL = (os.environ.get("REACT_APP_BACKEND_URL") or "").rstrip("/")
TENANT = "demo"
ADMIN_EMAIL = "admin@demo.com"
SELLER_EMAIL = "carlos@demo.com"
PASSWORD = "Admin@123456"


def _h(token: str):
    return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}


def _collect_sellers(state: dict) -> list[dict]:
    rows = []
    for section in ("entries", "available_sellers", "serving_sellers", "away_sellers"):
        rows.extend(state.get(section) or [])
    out = []
    seen = set()
    for row in rows:
        sid = row.get("seller_id") or row.get("id")
        if sid and sid not in seen:
            seen.add(sid)
            out.append({**row, "seller_id": sid})
    return out


@pytest.fixture(scope="module")
def ctx():
    """Configura contexto admin/seller e restaura setting ao final."""
    if not BASE_URL:
        pytest.skip("REACT_APP_BACKEND_URL não definido")

    admin_login = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT}/auth/login",
        json={"email": ADMIN_EMAIL, "password": PASSWORD},
        timeout=30,
    )
    assert admin_login.status_code == 200, admin_login.text
    admin_token = admin_login.json().get("access_token")
    assert admin_token

    seller_login = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT}/auth/login",
        json={"email": SELLER_EMAIL, "password": PASSWORD},
        timeout=30,
    )
    assert seller_login.status_code == 200, seller_login.text
    seller_token = seller_login.json().get("access_token")
    assert seller_token

    stores = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/stores", headers=_h(admin_token), timeout=30)
    assert stores.status_code == 200, stores.text
    store_id = stores.json()[0]["id"]

    queue_state = requests.get(
        f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/queue",
        headers=_h(admin_token),
        timeout=30,
    )
    assert queue_state.status_code == 200, queue_state.text
    state = queue_state.json()
    queue_id = state.get("queue", {}).get("id")
    assert queue_id

    sellers = _collect_sellers(state)
    carlos = next((s for s in sellers if (s.get("email") or "").lower() == SELLER_EMAIL), None)
    if not carlos:
        pytest.skip("Carlos não encontrado no estado da fila")

    settings_url = f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/settings"
    settings = requests.get(settings_url, headers=_h(admin_token), timeout=30)
    assert settings.status_code == 200, settings.text
    original_enabled = (settings.json().get("queue_settings") or {}).get("preference_enabled", True)

    data = {
        "admin_token": admin_token,
        "seller_token": seller_token,
        "store_id": store_id,
        "queue_id": queue_id,
        "carlos_seller_id": carlos["seller_id"],
        "original_enabled": original_enabled,
    }

    yield data

    requests.put(
        settings_url,
        headers=_h(admin_token),
        json={"queue_settings": {"preference_enabled": original_enabled}},
        timeout=30,
    )


def test_seller_preference_disabled_returns_403_preference_disabled(ctx):
    """Módulo queue/settings: com preferência OFF, start-preference deve retornar 403 PREFERENCE_DISABLED."""
    settings_url = f"{BASE_URL}/api/tenants/{TENANT}/stores/{ctx['store_id']}/settings"
    disable = requests.put(
        settings_url,
        headers=_h(ctx["admin_token"]),
        json={"queue_settings": {"preference_enabled": False}},
        timeout=30,
    )
    assert disable.status_code == 200, disable.text
    assert disable.json().get("queue_settings", {}).get("preference_enabled") is False

    start = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT}/stores/{ctx['store_id']}/queue/start-preference-attendance",
        headers=_h(ctx["seller_token"]),
        json={"queue_id": ctx["queue_id"], "customer_name": "Cliente Bloqueado Preferência"},
        timeout=30,
    )
    assert start.status_code == 403, start.text
    detail = start.json().get("detail")
    assert isinstance(detail, dict)
    assert detail.get("error") == "PREFERENCE_DISABLED"
