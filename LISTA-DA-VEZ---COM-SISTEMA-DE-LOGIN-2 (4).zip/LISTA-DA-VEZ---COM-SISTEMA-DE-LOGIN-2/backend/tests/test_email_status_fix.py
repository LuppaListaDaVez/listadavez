"""Tests for email status endpoint fix - checks DB config, not just env vars."""
import pytest
import requests
import os

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")

SUPER_ADMIN_EMAIL = "admin@listadavez.com"
SUPER_ADMIN_PASS = "Admin@123456"


@pytest.fixture(scope="module")
def sa_token():
    resp = requests.post(f"{BASE_URL}/api/auth/login", json={
        "email": SUPER_ADMIN_EMAIL,
        "password": SUPER_ADMIN_PASS
    })
    assert resp.status_code == 200, f"Login failed: {resp.text}"
    return resp.json().get("access_token") or resp.json().get("token")


@pytest.fixture(scope="module")
def sa_client(sa_token):
    s = requests.Session()
    s.headers.update({"Authorization": f"Bearer {sa_token}", "Content-Type": "application/json"})
    return s


class TestEmailStatus:
    """Verify GET /api/super-admin/system/email-status checks DB config."""

    def test_email_status_returns_200(self, sa_client):
        resp = sa_client.get(f"{BASE_URL}/api/super-admin/system/email-status")
        assert resp.status_code == 200, f"Expected 200, got {resp.status_code}: {resp.text}"
        print("PASS: email-status returns 200")

    def test_email_status_has_configured_field(self, sa_client):
        resp = sa_client.get(f"{BASE_URL}/api/super-admin/system/email-status")
        data = resp.json()
        assert "configured" in data, f"Missing 'configured' field in response: {data}"
        print(f"PASS: configured={data['configured']}")

    def test_email_status_configured_true_from_db(self, sa_client):
        """DB has smtp_host=smtp.gmail.com, smtp_pass=INVALID → should still report configured=True."""
        resp = sa_client.get(f"{BASE_URL}/api/super-admin/system/email-status")
        data = resp.json()
        assert data["configured"] is True, f"Expected configured=True (DB has smtp config), got: {data}"
        print(f"PASS: configured=True ✓")

    def test_email_status_source_is_database(self, sa_client):
        """Source should be 'database' since config is in DB, not env vars."""
        resp = sa_client.get(f"{BASE_URL}/api/super-admin/system/email-status")
        data = resp.json()
        assert data.get("source") == "database", f"Expected source='database', got: {data}"
        print(f"PASS: source=database ✓")

    def test_email_status_has_smtp_host(self, sa_client):
        resp = sa_client.get(f"{BASE_URL}/api/super-admin/system/email-status")
        data = resp.json()
        assert data.get("smtp_host"), f"Expected smtp_host in response: {data}"
        print(f"PASS: smtp_host={data.get('smtp_host')} ✓")


class TestSmtpSettingsGet:
    """Verify GET /api/super-admin/system/smtp-config returns DB config."""

    def test_smtp_config_returns_200(self, sa_client):
        resp = sa_client.get(f"{BASE_URL}/api/super-admin/system/smtp-config")
        assert resp.status_code == 200, f"Got {resp.status_code}: {resp.text}"
        print("PASS: smtp-config 200")

    def test_smtp_config_has_smtp_host(self, sa_client):
        resp = sa_client.get(f"{BASE_URL}/api/super-admin/system/smtp-config")
        data = resp.json()
        assert data.get("smtp_host"), f"No smtp_host in: {data}"
        print(f"PASS: smtp_host={data.get('smtp_host')}")

    def test_smtp_config_source_database(self, sa_client):
        resp = sa_client.get(f"{BASE_URL}/api/super-admin/system/smtp-config")
        data = resp.json()
        assert data.get("source") == "database", f"Expected database source: {data}"
        print(f"PASS: source=database ✓")
