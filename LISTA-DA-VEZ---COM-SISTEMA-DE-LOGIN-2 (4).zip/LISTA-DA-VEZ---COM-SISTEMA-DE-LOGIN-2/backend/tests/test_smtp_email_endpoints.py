"""Integration tests for SMTP/Email configuration endpoints and auth flows.

Covers:
  - Super Admin login
  - Tenant Demo login
  - GET /api/super-admin/system/email-status
  - GET /api/super-admin/system/smtp-config
  - PUT /api/super-admin/system/smtp-config (saves with smtp_password / smtp_tls)
  - POST /api/super-admin/system/smtp-config/test — 403 during impersonation
  - POST /api/super-admin/system/smtp-config/test — {success:false, step:'validation'} when empty host
  - POST /api/super-admin/tenants/{id}/impersonate — returns is_impersonation=true
"""

import os
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")
TENANT_ID_DEMO = "8408ccb7-e39e-49ab-8718-b3b95421cbd6"


# ─────────────────────────────────────────────────────────────────────────────
# Fixtures
# ─────────────────────────────────────────────────────────────────────────────

@pytest.fixture(scope="module")
def sa_token():
    """Authenticate as Super Admin and return the access token."""
    resp = requests.post(
        f"{BASE_URL}/api/auth/login",
        json={"email": "admin@listadavez.com", "password": "SuperAdmin!2025"},
    )
    assert resp.status_code == 200, f"SA login failed: {resp.status_code} {resp.text[:300]}"
    data = resp.json()
    token = data.get("access_token") or data.get("token")
    assert token, f"No token in SA login response: {data}"
    return token


@pytest.fixture(scope="module")
def sa_headers(sa_token):
    return {"Authorization": f"Bearer {sa_token}", "Content-Type": "application/json"}


@pytest.fixture(scope="module")
def impersonation_token(sa_token):
    """Obtain an impersonation token for tenant demo."""
    resp = requests.post(
        f"{BASE_URL}/api/super-admin/tenants/{TENANT_ID_DEMO}/impersonate",
        headers={"Authorization": f"Bearer {sa_token}"},
    )
    assert resp.status_code == 200, f"Impersonate failed: {resp.status_code} {resp.text[:300]}"
    data = resp.json()
    token = data.get("access_token") or data.get("token")
    assert token, f"No token in impersonation response: {data}"
    assert data.get("is_impersonation") is True, "is_impersonation must be True"
    return token


# ─────────────────────────────────────────────────────────────────────────────
# 1. Auth Tests
# ─────────────────────────────────────────────────────────────────────────────

class TestAuth:
    """Super Admin and Tenant Admin login."""

    def test_super_admin_login_success(self):
        """Super Admin login returns 200 with access_token."""
        resp = requests.post(
            f"{BASE_URL}/api/auth/login",
            json={"email": "admin@listadavez.com", "password": "SuperAdmin!2025"},
        )
        assert resp.status_code == 200, f"Expected 200, got {resp.status_code}: {resp.text[:200]}"
        data = resp.json()
        token = data.get("access_token") or data.get("token")
        assert token, "Response must contain access_token"

    def test_super_admin_login_wrong_password(self):
        """Wrong password returns 401."""
        resp = requests.post(
            f"{BASE_URL}/api/auth/login",
            json={"email": "admin@listadavez.com", "password": "WRONG_PASS"},
        )
        assert resp.status_code in (401, 403), f"Expected 401/403, got {resp.status_code}"

    def test_tenant_demo_login_success(self):
        """Tenant admin (demo slug) login returns 200 with access_token."""
        resp = requests.post(
            f"{BASE_URL}/api/tenants/demo/auth/login",
            json={"email": "admin@demo.com", "password": "Admin@123456"},
        )
        assert resp.status_code == 200, f"Expected 200, got {resp.status_code}: {resp.text[:200]}"
        data = resp.json()
        token = data.get("access_token") or data.get("token")
        assert token, "Response must contain access_token"


# ─────────────────────────────────────────────────────────────────────────────
# 2. Impersonation
# ─────────────────────────────────────────────────────────────────────────────

class TestImpersonation:
    """POST /api/super-admin/tenants/{id}/impersonate."""

    def test_impersonate_returns_200_and_is_impersonation(self, sa_token):
        resp = requests.post(
            f"{BASE_URL}/api/super-admin/tenants/{TENANT_ID_DEMO}/impersonate",
            headers={"Authorization": f"Bearer {sa_token}"},
        )
        assert resp.status_code == 200, f"Expected 200, got {resp.status_code}: {resp.text[:200]}"
        data = resp.json()
        assert data.get("is_impersonation") is True, "is_impersonation must be True"
        assert data.get("access_token") or data.get("token"), "Must return access_token"

    def test_impersonate_returns_tenant_slug(self, sa_token):
        resp = requests.post(
            f"{BASE_URL}/api/super-admin/tenants/{TENANT_ID_DEMO}/impersonate",
            headers={"Authorization": f"Bearer {sa_token}"},
        )
        data = resp.json()
        assert data.get("tenant_slug") == "demo", f"Expected slug='demo', got {data.get('tenant_slug')}"

    def test_impersonate_nonexistent_tenant_returns_404(self, sa_token):
        resp = requests.post(
            f"{BASE_URL}/api/super-admin/tenants/nonexistent-tenant-id/impersonate",
            headers={"Authorization": f"Bearer {sa_token}"},
        )
        assert resp.status_code == 404, f"Expected 404, got {resp.status_code}"

    def test_impersonate_requires_super_admin(self):
        """Unauthenticated request returns 401/403."""
        resp = requests.post(
            f"{BASE_URL}/api/super-admin/tenants/{TENANT_ID_DEMO}/impersonate",
        )
        assert resp.status_code in (401, 403), f"Expected 401/403, got {resp.status_code}"


# ─────────────────────────────────────────────────────────────────────────────
# 3. GET /api/super-admin/system/email-status
# ─────────────────────────────────────────────────────────────────────────────

class TestEmailStatus:
    """GET /api/super-admin/system/email-status."""

    def test_email_status_returns_200(self, sa_headers):
        resp = requests.get(f"{BASE_URL}/api/super-admin/system/email-status", headers=sa_headers)
        assert resp.status_code == 200, f"Expected 200, got {resp.status_code}: {resp.text[:200]}"

    def test_email_status_has_required_fields(self, sa_headers):
        resp = requests.get(f"{BASE_URL}/api/super-admin/system/email-status", headers=sa_headers)
        data = resp.json()
        assert "provider" in data, f"Missing 'provider' field: {data}"
        assert "configured" in data, f"Missing 'configured' field: {data}"
        assert "source" in data, f"Missing 'source' field: {data}"

    def test_email_status_source_is_valid(self, sa_headers):
        resp = requests.get(f"{BASE_URL}/api/super-admin/system/email-status", headers=sa_headers)
        data = resp.json()
        assert data["source"] in ("database", "environment"), f"Invalid source: {data['source']}"

    def test_email_status_configured_is_bool(self, sa_headers):
        resp = requests.get(f"{BASE_URL}/api/super-admin/system/email-status", headers=sa_headers)
        data = resp.json()
        assert isinstance(data["configured"], bool), f"'configured' must be bool: {data}"

    def test_email_status_requires_auth(self):
        resp = requests.get(f"{BASE_URL}/api/super-admin/system/email-status")
        assert resp.status_code in (401, 403), f"Expected 401/403 without auth, got {resp.status_code}"


# ─────────────────────────────────────────────────────────────────────────────
# 4. GET /api/super-admin/system/smtp-config
# ─────────────────────────────────────────────────────────────────────────────

class TestSmtpConfigGet:
    """GET /api/super-admin/system/smtp-config."""

    def test_get_smtp_config_returns_200(self, sa_headers):
        resp = requests.get(f"{BASE_URL}/api/super-admin/system/smtp-config", headers=sa_headers)
        assert resp.status_code == 200, f"Expected 200, got {resp.status_code}: {resp.text[:200]}"

    def test_get_smtp_config_has_smtp_tls_field(self, sa_headers):
        """Response must include smtp_tls (new canonical name)."""
        resp = requests.get(f"{BASE_URL}/api/super-admin/system/smtp-config", headers=sa_headers)
        data = resp.json()
        assert "smtp_tls" in data, f"Missing 'smtp_tls' field: {data}"

    def test_get_smtp_config_password_is_masked_or_empty(self, sa_headers):
        """smtp_password must be masked ('****') or empty — never plaintext."""
        resp = requests.get(f"{BASE_URL}/api/super-admin/system/smtp-config", headers=sa_headers)
        data = resp.json()
        assert "smtp_password" in data, f"Missing 'smtp_password' field: {data}"
        pwd_val = data["smtp_password"]
        assert pwd_val == "" or pwd_val == "****", (
            f"Password must be masked or empty, got: {pwd_val!r}"
        )

    def test_get_smtp_config_has_source_field(self, sa_headers):
        resp = requests.get(f"{BASE_URL}/api/super-admin/system/smtp-config", headers=sa_headers)
        data = resp.json()
        assert "source" in data, f"Missing 'source' field: {data}"
        assert data["source"] in ("database", "environment"), f"Invalid source: {data['source']}"

    def test_get_smtp_config_requires_auth(self):
        resp = requests.get(f"{BASE_URL}/api/super-admin/system/smtp-config")
        assert resp.status_code in (401, 403), f"Expected 401/403 without auth, got {resp.status_code}"


# ─────────────────────────────────────────────────────────────────────────────
# 5. PUT /api/super-admin/system/smtp-config
# ─────────────────────────────────────────────────────────────────────────────

class TestSmtpConfigSave:
    """PUT /api/super-admin/system/smtp-config."""

    _saved_host = "smtp.test-iteration-48.example.com"

    def test_save_smtp_config_returns_success(self, sa_headers):
        """Saving SMTP config with new field names returns success:true."""
        payload = {
            "smtp_host": self._saved_host,
            "smtp_port": 587,
            "smtp_user": "user@test.example.com",
            "smtp_password": "TestPassword!123",
            "smtp_tls": True,
            "smtp_ssl": False,
            "smtp_from": "noreply@test.example.com",
        }
        resp = requests.put(
            f"{BASE_URL}/api/super-admin/system/smtp-config",
            json=payload,
            headers=sa_headers,
        )
        assert resp.status_code == 200, f"Expected 200, got {resp.status_code}: {resp.text[:200]}"
        data = resp.json()
        assert data.get("success") is True, f"Expected success:true, got: {data}"

    def test_save_smtp_config_persists_to_db(self, sa_headers):
        """After PUT, GET must return saved values from database."""
        # Save first
        payload = {
            "smtp_host": self._saved_host,
            "smtp_port": 465,
            "smtp_user": "user2@test.example.com",
            "smtp_password": "AnotherSecret!456",
            "smtp_tls": False,
            "smtp_ssl": True,
        }
        put_resp = requests.put(
            f"{BASE_URL}/api/super-admin/system/smtp-config",
            json=payload,
            headers=sa_headers,
        )
        assert put_resp.status_code == 200

        # Verify GET returns saved values
        get_resp = requests.get(f"{BASE_URL}/api/super-admin/system/smtp-config", headers=sa_headers)
        assert get_resp.status_code == 200
        data = get_resp.json()
        assert data.get("source") == "database", f"Expected source=database after save, got: {data.get('source')}"
        assert data.get("smtp_host") == self._saved_host, f"Saved host mismatch: {data.get('smtp_host')}"
        assert data.get("smtp_port") == 465, f"Saved port mismatch: {data.get('smtp_port')}"
        # Password must be masked
        assert data.get("smtp_password") == "****", f"Saved password must be masked: {data.get('smtp_password')}"
        # smtp_tls field present
        assert "smtp_tls" in data, "smtp_tls field must be in response"

    def test_save_smtp_config_with_alias_smtp_pass(self, sa_headers):
        """Saving with legacy alias smtp_pass also works and returns success:true."""
        payload = {
            "smtp_host": "smtp.alias-test.example.com",
            "smtp_port": 587,
            "smtp_user": "u@alias.com",
            "smtp_pass": "LegacyPass!789",   # alias field
            "smtp_secure": True,              # alias for smtp_tls
        }
        resp = requests.put(
            f"{BASE_URL}/api/super-admin/system/smtp-config",
            json=payload,
            headers=sa_headers,
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data.get("success") is True, f"Expected success:true with alias fields, got: {data}"

    def test_save_smtp_config_sentinel_password_does_not_overwrite(self, sa_headers):
        """Sending smtp_password='****' should NOT overwrite an existing password."""
        # 1. Save with a real password
        payload1 = {
            "smtp_host": "smtp.sentinel-test.example.com",
            "smtp_port": 587,
            "smtp_user": "u@sentinel.com",
            "smtp_password": "RealPassword!000",
            "smtp_tls": False,
        }
        requests.put(f"{BASE_URL}/api/super-admin/system/smtp-config", json=payload1, headers=sa_headers)

        # 2. Update host only, send sentinel password
        payload2 = {
            "smtp_host": "smtp.sentinel-test.example.com",
            "smtp_port": 587,
            "smtp_user": "u@sentinel.com",
            "smtp_password": "****",  # sentinel — should not overwrite
            "smtp_tls": True,
        }
        resp = requests.put(
            f"{BASE_URL}/api/super-admin/system/smtp-config",
            json=payload2,
            headers=sa_headers,
        )
        assert resp.status_code == 200
        # GET → password still masked (meaning password was kept, not blanked)
        get_resp = requests.get(f"{BASE_URL}/api/super-admin/system/smtp-config", headers=sa_headers)
        data = get_resp.json()
        assert data.get("smtp_password") == "****", (
            f"Password should remain masked after sentinel update, got: {data.get('smtp_password')}"
        )


# ─────────────────────────────────────────────────────────────────────────────
# 6. POST /api/super-admin/system/smtp-config/test
# ─────────────────────────────────────────────────────────────────────────────

class TestSmtpConfigTest:
    """POST /api/super-admin/system/smtp-config/test."""

    def test_smtp_test_empty_host_returns_validation_failure(self, sa_headers):
        """When smtp_host is empty, returns {success:false, step:'validation'}."""
        payload = {
            "config": {
                "smtp_host": "",
                "smtp_port": 587,
                "smtp_user": "",
                "smtp_password": "",
            },
            "test_email": "test@example.com",
        }
        resp = requests.post(
            f"{BASE_URL}/api/super-admin/system/smtp-config/test",
            json=payload,
            headers=sa_headers,
        )
        assert resp.status_code == 200, f"Expected 200 for validation error, got {resp.status_code}: {resp.text[:200]}"
        data = resp.json()
        assert data.get("success") is False, f"Expected success:false, got: {data}"
        assert data.get("step") == "validation", f"Expected step='validation', got: {data.get('step')}"

    def test_smtp_test_during_impersonation_returns_403(self, impersonation_token):
        """Calling test endpoint during impersonation returns 403 with IMPERSONATION_BLOCKED."""
        imp_headers = {
            "Authorization": f"Bearer {impersonation_token}",
            "Content-Type": "application/json",
        }
        payload = {
            "config": {
                "smtp_host": "smtp.example.com",
                "smtp_port": 587,
                "smtp_user": "u@example.com",
                "smtp_password": "pass",
            },
            "test_email": "admin@example.com",
        }
        resp = requests.post(
            f"{BASE_URL}/api/super-admin/system/smtp-config/test",
            json=payload,
            headers=imp_headers,
        )
        assert resp.status_code == 403, f"Expected 403 during impersonation, got {resp.status_code}: {resp.text[:300]}"
        data = resp.json()
        # Detail may be nested {"detail": {"error": "IMPERSONATION_BLOCKED", ...}} or flat
        detail = data.get("detail") or data
        if isinstance(detail, dict):
            error_val = detail.get("error", "")
        else:
            error_val = str(detail)
        assert "IMPERSONATION_BLOCKED" in error_val, (
            f"Expected IMPERSONATION_BLOCKED in error, got: {data}"
        )

    def test_smtp_test_requires_auth(self):
        """Unauthenticated request returns 401/403."""
        payload = {
            "config": {"smtp_host": "smtp.example.com", "smtp_port": 587,
                       "smtp_user": "u@example.com", "smtp_password": "p"},
            "test_email": "t@example.com",
        }
        resp = requests.post(f"{BASE_URL}/api/super-admin/system/smtp-config/test", json=payload)
        assert resp.status_code in (401, 403), f"Expected 401/403 without auth, got {resp.status_code}"
