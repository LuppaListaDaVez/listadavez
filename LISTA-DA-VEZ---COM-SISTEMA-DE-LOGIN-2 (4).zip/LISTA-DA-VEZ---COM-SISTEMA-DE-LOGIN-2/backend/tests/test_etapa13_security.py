"""
Etapa 13 — Segurança Cibernética para SaaS multitenant 'Lista da Vez'.
Tests: tenant-scoped auth, TENANT_SESSION_MISMATCH, super admin auth, 
       refresh token rotation, rate limiting, security events/sessions panel,
       health endpoints, cross-tenant isolation.
"""
import pytest
import requests
import os
import jwt

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")

# Credentials
SUPER_ADMIN_EMAIL = "admin@listadavez.com"
SUPER_ADMIN_PWD = "Admin@123456"
DEMO_ADMIN_EMAIL = "admin@demo.com"
DEMO_ADMIN_PWD = "Admin@123456"
DEMO_B_ADMIN_EMAIL = "admin@demo-b.com"
DEMO_B_ADMIN_PWD = "Admin@123456"
JOAO_EMAIL = "joao@demo.com"
JOAO_PWD = "Admin@123456"
ANA_EMAIL = "ana@demo.com"
ANA_PWD = "Admin@123456"

# ─────────────────────────────────────────────────────────────────────────────
# HEALTH CHECKS
# ─────────────────────────────────────────────────────────────────────────────

class TestHealthEndpoints:
    """Health endpoint tests"""
    
    def test_health_root(self):
        """GET /api/health — deve retornar status ok"""
        r = requests.get(f"{BASE_URL}/api/health")
        assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text}"
        data = r.json()
        assert data.get("status") == "ok", f"Expected status=ok, got: {data}"
        print("✓ /api/health OK")

    def test_health_live(self):
        """GET /api/health/live — liveness probe"""
        r = requests.get(f"{BASE_URL}/api/health/live")
        assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text}"
        print("✓ /api/health/live OK")

    def test_health_ready(self):
        """GET /api/health/ready — readiness probe"""
        r = requests.get(f"{BASE_URL}/api/health/ready")
        assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text}"
        print("✓ /api/health/ready OK")


# ─────────────────────────────────────────────────────────────────────────────
# TENANT LOGIN — demo
# ─────────────────────────────────────────────────────────────────────────────

class TestTenantLogin:
    """Tenant login endpoint tests"""
    
    def test_demo_admin_login_returns_full_payload(self):
        """POST /api/tenants/demo/auth/login — token deve ter tenant_id, tenant_slug, auth_context=TENANT, session_id"""
        r = requests.post(
            f"{BASE_URL}/api/tenants/demo/auth/login",
            json={"email": DEMO_ADMIN_EMAIL, "password": DEMO_ADMIN_PWD}
        )
        assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text}"
        data = r.json()
        
        # Verificar campos da resposta
        assert "access_token" in data, "access_token not in response"
        assert "refresh_token" in data, "refresh_token not in response"
        assert data.get("auth_context") == "TENANT", f"Expected auth_context=TENANT, got: {data.get('auth_context')}"
        assert data.get("tenant_slug") == "demo", f"Expected tenant_slug=demo, got: {data.get('tenant_slug')}"
        assert "tenant_id" in data, "tenant_id not in response"
        assert "session_id" in data, "session_id not in response"
        assert data["session_id"] is not None, "session_id is None"
        
        # Verificar payload JWT
        token = data["access_token"]
        # Decode without verification to check claims (we don't have the secret here)
        payload = jwt.decode(token, options={"verify_signature": False})
        assert payload.get("auth_context") == "TENANT", f"JWT auth_context mismatch: {payload.get('auth_context')}"
        assert payload.get("tenant_slug") == "demo", f"JWT tenant_slug mismatch: {payload.get('tenant_slug')}"
        assert payload.get("tenant_id") == data["tenant_id"], "JWT tenant_id mismatch"
        assert payload.get("session_id") == data["session_id"], "JWT session_id mismatch"
        assert payload.get("is_super_admin") == False, "JWT is_super_admin should be False"
        
        print(f"✓ Tenant demo login OK — role={data.get('membership',{}).get('role')}, session_id={data['session_id'][:8]}...")
    
    def test_demo_invalid_credentials_return_generic_error(self):
        """Login com credenciais erradas retorna INVALID_CREDENTIALS (não revela se email existe)"""
        r = requests.post(
            f"{BASE_URL}/api/tenants/demo/auth/login",
            json={"email": DEMO_ADMIN_EMAIL, "password": "WRONG_PASSWORD_123"}
        )
        assert r.status_code == 401, f"Expected 401, got {r.status_code}: {r.text}"
        data = r.json()
        detail = data.get("detail", data)
        if isinstance(detail, dict):
            assert detail.get("error") == "INVALID_CREDENTIALS", f"Expected error=INVALID_CREDENTIALS, got: {detail}"
        print("✓ Invalid credentials returns INVALID_CREDENTIALS")

    def test_demo_nonexistent_email_returns_generic_error(self):
        """Email não existente retorna mesmo erro genérico (não revela existência)"""
        r = requests.post(
            f"{BASE_URL}/api/tenants/demo/auth/login",
            json={"email": "nonexistent_test@example.com", "password": "anything123"}
        )
        assert r.status_code == 401, f"Expected 401, got {r.status_code}: {r.text}"
        data = r.json()
        detail = data.get("detail", data)
        if isinstance(detail, dict):
            assert detail.get("error") == "INVALID_CREDENTIALS", f"Expected INVALID_CREDENTIALS, got: {detail}"
        print("✓ Nonexistent email returns same generic error (no info leak)")

    def test_joao_can_login_demo(self):
        """joao@demo.com pode logar em /demo"""
        r = requests.post(
            f"{BASE_URL}/api/tenants/demo/auth/login",
            json={"email": JOAO_EMAIL, "password": JOAO_PWD}
        )
        assert r.status_code == 200, f"joao login in demo failed: {r.status_code} - {r.text}"
        data = r.json()
        assert data.get("tenant_slug") == "demo"
        assert data.get("auth_context") == "TENANT"
        print("✓ joao@demo.com logged into demo")

    def test_ana_seller_login_demo(self):
        """ana@demo.com (SELLER) pode logar em /demo"""
        r = requests.post(
            f"{BASE_URL}/api/tenants/demo/auth/login",
            json={"email": ANA_EMAIL, "password": ANA_PWD}
        )
        assert r.status_code == 200, f"ana login failed: {r.status_code} - {r.text}"
        data = r.json()
        assert data["membership"]["role"] == "SELLER", f"Expected SELLER role, got: {data['membership']['role']}"
        print("✓ ana@demo.com (SELLER) logged into demo")


# ─────────────────────────────────────────────────────────────────────────────
# TENANT LOGIN — demo-b
# ─────────────────────────────────────────────────────────────────────────────

class TestTenantDemoBLogin:
    """Tenant demo-b login tests"""
    
    def test_demob_admin_login(self):
        """admin@demo-b.com pode logar em /demo-b"""
        r = requests.post(
            f"{BASE_URL}/api/tenants/demo-b/auth/login",
            json={"email": DEMO_B_ADMIN_EMAIL, "password": DEMO_B_ADMIN_PWD}
        )
        assert r.status_code == 200, f"demo-b admin login failed: {r.status_code} - {r.text}"
        data = r.json()
        assert data.get("tenant_slug") == "demo-b", f"Expected demo-b, got: {data.get('tenant_slug')}"
        assert data.get("auth_context") == "TENANT"
        print("✓ admin@demo-b.com logged into demo-b")
    
    def test_joao_can_login_demob(self):
        """joao@demo.com existe em demo E demo-b (mesmo email, dois tenants)"""
        r = requests.post(
            f"{BASE_URL}/api/tenants/demo-b/auth/login",
            json={"email": JOAO_EMAIL, "password": JOAO_PWD}
        )
        assert r.status_code == 200, f"joao login in demo-b failed: {r.status_code} - {r.text}"
        data = r.json()
        assert data.get("tenant_slug") == "demo-b"
        assert data.get("auth_context") == "TENANT"
        print("✓ joao@demo.com logged into demo-b (cross-tenant membership)")


# ─────────────────────────────────────────────────────────────────────────────
# SUPER ADMIN TOKEN FIXTURE — module-scoped, obtained FIRST
# ─────────────────────────────────────────────────────────────────────────────

@pytest.fixture(scope="module")
def super_admin_token():
    """Get Super Admin JWT token — obtained ONCE to respect rate limit (3/30min)"""
    r = requests.post(
        f"{BASE_URL}/api/auth/login",
        json={"email": SUPER_ADMIN_EMAIL, "password": SUPER_ADMIN_PWD}
    )
    if r.status_code == 429:
        pytest.skip("Super Admin login rate-limited (3/30min) — wait before re-running")
    if r.status_code != 200:
        pytest.skip(f"Super Admin login failed ({r.status_code}): {r.text}")
    return r.json()


# ─────────────────────────────────────────────────────────────────────────────
# SUPER ADMIN LOGIN (POST /api/auth/login)
# ─────────────────────────────────────────────────────────────────────────────

class TestSuperAdminLogin:
    """Super Admin global login tests — reuses fixture token to avoid extra logins"""
    
    def test_superadmin_login_returns_super_admin_context(self, super_admin_token):
        """POST /api/auth/login — Super Admin retorna auth_context=SUPER_ADMIN"""
        # Use token from fixture (already obtained) — verify claims
        data = super_admin_token
        
        assert data.get("auth_context") == "SUPER_ADMIN", f"Expected SUPER_ADMIN, got: {data.get('auth_context')}"
        assert "access_token" in data
        assert "refresh_token" in data
        assert "session_id" in data
        assert data.get("user", {}).get("is_super_admin") == True
        
        # Verificar JWT
        token = data["access_token"]
        payload = jwt.decode(token, options={"verify_signature": False})
        assert payload.get("auth_context") == "SUPER_ADMIN", f"JWT auth_context mismatch: {payload.get('auth_context')}"
        assert payload.get("is_super_admin") == True
        
        print(f"✓ Super Admin login OK — session_id={data['session_id'][:8]}...")
    
    def test_non_superadmin_global_login_rejected(self):
        """Usuário não-super-admin tentando login global recebe USE_TENANT_LOGIN"""
        r = requests.post(
            f"{BASE_URL}/api/auth/login",
            json={"email": DEMO_ADMIN_EMAIL, "password": DEMO_ADMIN_PWD}
        )
        assert r.status_code == 403, f"Expected 403, got {r.status_code}: {r.text}"
        data = r.json()
        detail = data.get("detail", data)
        if isinstance(detail, dict):
            assert detail.get("error") == "USE_TENANT_LOGIN", f"Expected USE_TENANT_LOGIN, got: {detail}"
        print("✓ Non-super-admin global login rejected with USE_TENANT_LOGIN")
    
    def test_superadmin_invalid_password_returns_generic_error(self):
        """Super Admin com senha errada retorna INVALID_CREDENTIALS — uses wrong password only"""
        # NOTE: This consumes 1 of the 3/30min SUPER_ADMIN_LOGIN rate limit slots
        r = requests.post(
            f"{BASE_URL}/api/auth/login",
            json={"email": SUPER_ADMIN_EMAIL, "password": "WrongPassword123"}
        )
        # May return 429 if rate limit is already exhausted — both are acceptable outcomes
        if r.status_code == 429:
            print("⚠ Super Admin login rate-limited — skipping wrong-password assertion")
            return
        assert r.status_code == 401, f"Expected 401, got {r.status_code}: {r.text}"
        data = r.json()
        detail = data.get("detail", data)
        if isinstance(detail, dict):
            assert detail.get("error") == "INVALID_CREDENTIALS", f"Expected INVALID_CREDENTIALS, got: {detail}"
        print("✓ Super Admin wrong password returns INVALID_CREDENTIALS")


# ─────────────────────────────────────────────────────────────────────────────
# TENANT SESSION MISMATCH
# ─────────────────────────────────────────────────────────────────────────────

class TestTenantSessionMismatch:
    """Cross-tenant isolation: TENANT_SESSION_MISMATCH"""
    
    def test_demo_token_rejected_in_demob(self):
        """Token de demo usado em /api/tenants/demo-b/* retorna 401 TENANT_SESSION_MISMATCH"""
        # 1. Login in demo
        login_r = requests.post(
            f"{BASE_URL}/api/tenants/demo/auth/login",
            json={"email": JOAO_EMAIL, "password": JOAO_PWD}
        )
        assert login_r.status_code == 200, f"Demo login failed: {login_r.text}"
        demo_token = login_r.json()["access_token"]
        
        # 2. Use demo token in demo-b endpoint (e.g., /api/tenants/demo-b/context)
        r = requests.get(
            f"{BASE_URL}/api/tenants/demo-b/context",
            headers={"Authorization": f"Bearer {demo_token}"}
        )
        assert r.status_code == 401, f"Expected 401 TENANT_SESSION_MISMATCH, got {r.status_code}: {r.text}"
        data = r.json()
        detail = data.get("detail", data)
        if isinstance(detail, dict):
            assert detail.get("error") == "TENANT_SESSION_MISMATCH", (
                f"Expected TENANT_SESSION_MISMATCH, got: {detail}"
            )
        print("✓ demo token rejected in demo-b with TENANT_SESSION_MISMATCH")
    
    def test_demob_token_rejected_in_demo(self):
        """Token de demo-b usado em /api/tenants/demo/* retorna 401 TENANT_SESSION_MISMATCH"""
        # 1. Login in demo-b (use admin to ensure access)
        login_r = requests.post(
            f"{BASE_URL}/api/tenants/demo-b/auth/login",
            json={"email": DEMO_B_ADMIN_EMAIL, "password": DEMO_B_ADMIN_PWD}
        )
        assert login_r.status_code == 200, f"Demo-b login failed: {login_r.text}"
        demob_token = login_r.json()["access_token"]
        
        # 2. Use demo-b token in demo endpoint
        r = requests.get(
            f"{BASE_URL}/api/tenants/demo/context",
            headers={"Authorization": f"Bearer {demob_token}"}
        )
        assert r.status_code == 401, f"Expected 401 TENANT_SESSION_MISMATCH, got {r.status_code}: {r.text}"
        data = r.json()
        detail = data.get("detail", data)
        if isinstance(detail, dict):
            assert detail.get("error") == "TENANT_SESSION_MISMATCH", (
                f"Expected TENANT_SESSION_MISMATCH, got: {detail}"
            )
        print("✓ demo-b token rejected in demo with TENANT_SESSION_MISMATCH")

    def test_demo_token_works_in_demo(self):
        """Token de demo funciona corretamente em /api/tenants/demo/*"""
        login_r = requests.post(
            f"{BASE_URL}/api/tenants/demo/auth/login",
            json={"email": DEMO_ADMIN_EMAIL, "password": DEMO_ADMIN_PWD}
        )
        assert login_r.status_code == 200, f"Demo login failed: {login_r.text}"
        demo_token = login_r.json()["access_token"]
        
        r = requests.get(
            f"{BASE_URL}/api/tenants/demo/context",
            headers={"Authorization": f"Bearer {demo_token}"}
        )
        assert r.status_code == 200, f"Expected 200 for demo token in demo, got {r.status_code}: {r.text}"
        data = r.json()
        print(f"✓ demo token works in demo — tenant: {data.get('tenant', {}).get('slug', 'N/A')}")


# ─────────────────────────────────────────────────────────────────────────────
# REFRESH TOKEN ROTATION WITH REUSE DETECTION
# ─────────────────────────────────────────────────────────────────────────────

class TestRefreshTokenRotation:
    """Refresh token rotation and reuse detection"""
    
    def test_first_refresh_works(self):
        """Primeiro uso do refresh token funciona e emite novo par"""
        # Login to get tokens
        login_r = requests.post(
            f"{BASE_URL}/api/tenants/demo/auth/login",
            json={"email": ANA_EMAIL, "password": ANA_PWD}
        )
        assert login_r.status_code == 200, f"Login failed: {login_r.text}"
        refresh_token = login_r.json()["refresh_token"]
        
        # Use refresh token
        r = requests.post(
            f"{BASE_URL}/api/auth/refresh",
            json={"refresh_token": refresh_token}
        )
        assert r.status_code == 200, f"Expected 200 for refresh, got {r.status_code}: {r.text}"
        data = r.json()
        assert "access_token" in data, "No access_token in refresh response"
        assert "refresh_token" in data, "No refresh_token in refresh response"
        # New refresh token should differ from old one
        assert data["refresh_token"] != refresh_token, "Refresh token should be rotated"
        print("✓ First refresh token use works, new tokens issued")
    
    def test_second_use_of_same_refresh_token_rejected(self):
        """Segundo uso do mesmo refresh token retorna 401 (reuse detection)"""
        # Login to get tokens
        login_r = requests.post(
            f"{BASE_URL}/api/tenants/demo/auth/login",
            json={"email": ANA_EMAIL, "password": ANA_PWD}
        )
        assert login_r.status_code == 200, f"Login failed: {login_r.text}"
        refresh_token = login_r.json()["refresh_token"]
        
        # First use — should succeed
        r1 = requests.post(
            f"{BASE_URL}/api/auth/refresh",
            json={"refresh_token": refresh_token}
        )
        assert r1.status_code == 200, f"First refresh failed: {r1.text}"
        
        # Second use of the same (now rotated) token — should fail
        r2 = requests.post(
            f"{BASE_URL}/api/auth/refresh",
            json={"refresh_token": refresh_token}
        )
        assert r2.status_code == 401, f"Expected 401 for reused refresh token, got {r2.status_code}: {r2.text}"
        print("✓ Second use of same refresh token rejected (reuse detection)")

    def test_invalid_refresh_token_rejected(self):
        """Token de refresh inválido retorna 401"""
        r = requests.post(
            f"{BASE_URL}/api/auth/refresh",
            json={"refresh_token": "completelyfaketoken123456789"}
        )
        assert r.status_code == 401, f"Expected 401 for invalid refresh, got {r.status_code}: {r.text}"
        print("✓ Invalid refresh token rejected")


# ─────────────────────────────────────────────────────────────────────────────
# SECURITY ADMIN PANEL (SUPER ADMIN ONLY)
# ─────────────────────────────────────────────────────────────────────────────

@pytest.fixture(scope="module")
def demo_token():
    """Get demo tenant token"""
    r = requests.post(
        f"{BASE_URL}/api/tenants/demo/auth/login",
        json={"email": DEMO_ADMIN_EMAIL, "password": DEMO_ADMIN_PWD}
    )
    if r.status_code != 200:
        pytest.skip(f"Demo login failed: {r.text}")
    return r.json()["access_token"]


class TestSecurityAdminPanel:
    """Security admin panel (Super Admin only)"""
    
    def test_security_events_with_super_admin(self, super_admin_token):
        """GET /api/admin/security/events — funciona com Super Admin"""
        token = super_admin_token["access_token"]
        r = requests.get(
            f"{BASE_URL}/api/admin/security/events",
            headers={"Authorization": f"Bearer {token}"}
        )
        assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text}"
        data = r.json()
        assert isinstance(data, list), f"Expected list, got: {type(data)}"
        print(f"✓ Security events accessible by Super Admin — {len(data)} events found")
    
    def test_security_events_rejected_for_tenant_user(self, demo_token):
        """GET /api/admin/security/events — rejeitado para usuário tenant"""
        r = requests.get(
            f"{BASE_URL}/api/admin/security/events",
            headers={"Authorization": f"Bearer {demo_token}"}
        )
        assert r.status_code == 403, f"Expected 403, got {r.status_code}: {r.text}"
        print("✓ Security events rejected for tenant user (403)")
    
    def test_security_sessions_with_super_admin(self, super_admin_token):
        """GET /api/admin/security/sessions — funciona com Super Admin"""
        token = super_admin_token["access_token"]
        r = requests.get(
            f"{BASE_URL}/api/admin/security/sessions",
            headers={"Authorization": f"Bearer {token}"}
        )
        assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text}"
        data = r.json()
        assert isinstance(data, list), f"Expected list, got: {type(data)}"
        print(f"✓ Security sessions accessible by Super Admin — {len(data)} active sessions")
    
    def test_security_sessions_rejected_for_tenant_user(self, demo_token):
        """GET /api/admin/security/sessions — rejeitado para usuário tenant"""
        r = requests.get(
            f"{BASE_URL}/api/admin/security/sessions",
            headers={"Authorization": f"Bearer {demo_token}"}
        )
        assert r.status_code == 403, f"Expected 403, got {r.status_code}: {r.text}"
        print("✓ Security sessions rejected for tenant user (403)")
    
    def test_security_events_rejected_without_auth(self):
        """GET /api/admin/security/events sem token retorna 401"""
        r = requests.get(f"{BASE_URL}/api/admin/security/events")
        assert r.status_code == 401, f"Expected 401, got {r.status_code}: {r.text}"
        print("✓ Security events rejected without auth (401)")
    
    def test_system_metrics_with_super_admin(self, super_admin_token):
        """GET /api/admin/system/metrics — retorna métricas com sessões, tenants, eventos 24h"""
        token = super_admin_token["access_token"]
        r = requests.get(
            f"{BASE_URL}/api/admin/system/metrics",
            headers={"Authorization": f"Bearer {token}"}
        )
        assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text}"
        data = r.json()
        
        # Verify metrics structure
        assert "tenants" in data, "Missing tenants in metrics"
        assert "users" in data, "Missing users in metrics"
        assert "sessions" in data, "Missing sessions in metrics"
        assert "last_24h" in data, "Missing last_24h in metrics"
        
        tenants = data["tenants"]
        assert "total" in tenants, "Missing tenants.total"
        assert "active" in tenants, "Missing tenants.active"
        assert tenants["total"] >= 2, f"Expected at least 2 tenants (demo + demo-b), got {tenants['total']}"
        
        sessions = data["sessions"]
        assert "total" in sessions, "Missing sessions.total"
        assert "active" in sessions, "Missing sessions.active"
        
        last_24h = data["last_24h"]
        assert "logins_success" in last_24h
        assert "logins_failed" in last_24h
        assert "rate_limit_exceeded" in last_24h
        assert "tenant_session_mismatch" in last_24h
        
        print(f"✓ System metrics OK — tenants={tenants}, sessions={sessions}, last_24h={last_24h}")


# ─────────────────────────────────────────────────────────────────────────────
# LOGOUT REVOKES SESSION
# ─────────────────────────────────────────────────────────────────────────────

class TestTenantLogout:
    """Tenant logout revokes session"""
    
    def test_tenant_logout_revokes_session(self):
        """POST /api/tenants/demo/auth/logout revoga sessão"""
        # Login
        login_r = requests.post(
            f"{BASE_URL}/api/tenants/demo/auth/login",
            json={"email": JOAO_EMAIL, "password": JOAO_PWD}
        )
        assert login_r.status_code == 200, f"Login failed: {login_r.text}"
        token = login_r.json()["access_token"]
        refresh_token = login_r.json()["refresh_token"]
        
        # Verify token works before logout
        check_before = requests.get(
            f"{BASE_URL}/api/tenants/demo/context",
            headers={"Authorization": f"Bearer {token}"}
        )
        assert check_before.status_code == 200, f"Token should work before logout: {check_before.text}"
        
        # Logout
        logout_r = requests.post(
            f"{BASE_URL}/api/tenants/demo/auth/logout",
            json={"refresh_token": refresh_token},
            headers={"Authorization": f"Bearer {token}"}
        )
        assert logout_r.status_code == 200, f"Logout failed: {logout_r.text}"
        assert "message" in logout_r.json()
        
        # Verify refresh token no longer works after logout
        refresh_r = requests.post(
            f"{BASE_URL}/api/auth/refresh",
            json={"refresh_token": refresh_token}
        )
        assert refresh_r.status_code == 401, f"Refresh should fail after logout, got: {refresh_r.status_code} - {refresh_r.text}"
        print("✓ Tenant logout revokes session and refresh token")


# ─────────────────────────────────────────────────────────────────────────────
# RATE LIMITING
# ─────────────────────────────────────────────────────────────────────────────

class TestRateLimit:
    """Rate limit tests (5 attempts per 15 min for login)
    NOTE: Tested directly against localhost to bypass Kubernetes ingress proxy IP issue.
    When called via public URL, backend sees multiple ingress pod IPs, so rate limit
    counter never accumulates for a single key (security bug — see report).
    """
    
    def test_rate_limit_triggers_after_multiple_failed_logins(self):
        """Rate limit retorna 429 após muitas tentativas (5 para AUTH_LOGIN)"""
        # Use internal URL to bypass proxy IP fragmentation issue
        internal_base = "http://localhost:8001"
        test_email = f"ratelimit_internaltest_{int(__import__('time').time()) % 10000}@test.com"
        
        blocked = False
        last_status = None
        for i in range(7):  # limit is 5, so 6th should be blocked
            r = requests.post(
                f"{internal_base}/api/tenants/demo/auth/login",
                json={"email": test_email, "password": f"wrong_pass_{i}"}
            )
            last_status = r.status_code
            if r.status_code == 429:
                blocked = True
                data = r.json()
                detail = data.get("detail", data)
                if isinstance(detail, dict):
                    assert detail.get("error") == "RATE_LIMIT_EXCEEDED", f"Expected RATE_LIMIT_EXCEEDED, got: {detail}"
                    assert "retry_after_seconds" in detail, "Missing retry_after_seconds in rate limit response"
                break
        
        assert blocked, (
            f"Expected 429 rate limit after 7 attempts, last status was {last_status}. "
            "NOTE: From public URL, rate limit may not work due to proxy IP fragmentation."
        )
        print("✓ Rate limit triggered after multiple failed login attempts (tested via localhost)")


# ─────────────────────────────────────────────────────────────────────────────
# REGRESSION — ETAPAS 1-10 (vendas, fila, atendimentos)
# ─────────────────────────────────────────────────────────────────────────────

class TestRegressionCoreFeatures:
    """Regression: Etapas 1-10 core features still work after auth changes"""
    
    def test_queue_accessible_with_tenant_token(self, demo_token):
        """GET /api/tenants/demo/sellers — valida que core endpoints tenant-scoped funcionam (queue needs store_id)"""
        # Queue endpoint requires store_id (/tenants/{slug}/stores/{store_id}/queue)
        # Test sellers as a proxy for tenant API access working
        r = requests.get(
            f"{BASE_URL}/api/tenants/demo/sellers",
            headers={"Authorization": f"Bearer {demo_token}"}
        )
        assert r.status_code == 200, f"Sellers endpoint failed: {r.status_code} - {r.text}"
        print(f"✓ Core tenant API (sellers) accessible with tenant-scoped token")
    
    def test_sellers_accessible_with_tenant_token(self, demo_token):
        """GET /api/tenants/demo/sellers — acessível com token tenant-scoped"""
        r = requests.get(
            f"{BASE_URL}/api/tenants/demo/sellers",
            headers={"Authorization": f"Bearer {demo_token}"}
        )
        assert r.status_code == 200, f"Sellers failed: {r.status_code} - {r.text}"
        data = r.json()
        assert isinstance(data, list), f"Expected list of sellers"
        print(f"✓ Sellers accessible with tenant token — {len(data)} sellers")
    
    def test_sales_accessible_with_tenant_token(self, demo_token):
        """GET /api/tenants/demo/sales — acessível com token tenant-scoped"""
        r = requests.get(
            f"{BASE_URL}/api/tenants/demo/sales",
            headers={"Authorization": f"Bearer {demo_token}"}
        )
        assert r.status_code == 200, f"Sales failed: {r.status_code} - {r.text}"
        print(f"✓ Sales accessible with tenant token")
    
    def test_attendances_accessible_with_tenant_token(self, demo_token):
        """GET /api/tenants/demo/attendances — acessível com token tenant-scoped"""
        r = requests.get(
            f"{BASE_URL}/api/tenants/demo/attendances",
            headers={"Authorization": f"Bearer {demo_token}"}
        )
        assert r.status_code == 200, f"Attendances failed: {r.status_code} - {r.text}"
        print(f"✓ Attendances accessible with tenant token")
    
    def test_dashboard_accessible_with_tenant_token(self, demo_token):
        """GET /api/tenants/demo/dashboard/summary — acessível com token tenant-scoped"""
        r = requests.get(
            f"{BASE_URL}/api/tenants/demo/dashboard/summary",
            headers={"Authorization": f"Bearer {demo_token}"}
        )
        assert r.status_code == 200, f"Dashboard failed: {r.status_code} - {r.text}"
        print(f"✓ Dashboard summary accessible with tenant token")
    
    def test_notifications_accessible_with_tenant_token(self, demo_token):
        """GET /api/tenants/demo/notifications — acessível com token tenant-scoped"""
        r = requests.get(
            f"{BASE_URL}/api/tenants/demo/notifications",
            headers={"Authorization": f"Bearer {demo_token}"}
        )
        assert r.status_code == 200, f"Notifications failed: {r.status_code} - {r.text}"
        print(f"✓ Notifications accessible with tenant token")


# ─────────────────────────────────────────────────────────────────────────────
# SUPER ADMIN SECURITY EVENTS FILTERING  
# ─────────────────────────────────────────────────────────────────────────────

class TestSecurityEventsFiltering:
    """Security events filtering and content"""
    
    def test_security_events_contain_login_success(self, super_admin_token):
        """Após login, deve haver eventos LOGIN_SUCCESS nos security_events"""
        # First do a login to generate an event
        requests.post(
            f"{BASE_URL}/api/tenants/demo/auth/login",
            json={"email": DEMO_ADMIN_EMAIL, "password": DEMO_ADMIN_PWD}
        )
        token = super_admin_token["access_token"]
        r = requests.get(
            f"{BASE_URL}/api/admin/security/events?event_type=LOGIN_SUCCESS&limit=10",
            headers={"Authorization": f"Bearer {token}"}
        )
        assert r.status_code == 200, f"Failed: {r.text}"
        data = r.json()
        assert isinstance(data, list)
        # Should have at least one LOGIN_SUCCESS from our tests
        login_events = [e for e in data if e.get("event_type") == "LOGIN_SUCCESS"]
        assert len(login_events) > 0, "No LOGIN_SUCCESS events found after multiple logins"
        print(f"✓ Security events contain {len(login_events)} LOGIN_SUCCESS events")
    
    def test_security_events_filter_by_tenant(self, super_admin_token):
        """Security events podem ser filtrados por tenant_slug"""
        token = super_admin_token["access_token"]
        r = requests.get(
            f"{BASE_URL}/api/admin/security/events?tenant_slug=demo&limit=50",
            headers={"Authorization": f"Bearer {token}"}
        )
        assert r.status_code == 200, f"Failed: {r.text}"
        data = r.json()
        assert isinstance(data, list)
        # All returned events should be from demo tenant (or have null tenant_slug for super admin events)
        for ev in data:
            assert ev.get("tenant_slug") == "demo" or ev.get("tenant_slug") is None
        print(f"✓ Security events filtered by tenant_slug=demo — {len(data)} events")
