"""Prompt 72 regression — demo dashboard/queue/auth presentation checks.

Coverage:
- Role login + tenant context
- Dashboard summary filters (store/seller) and ObjectId leakage guard
- Opportunity flow response shape and ObjectId leakage guard
- Demo seed presentation shape (3 stores, 7 demo sellers, recent 7-day data)
- Auth playbook checks (httpOnly cookie, CORS credentials, brute force lockout)
"""

import os
from datetime import datetime, timedelta, timezone

import pytest
import requests


BASE_URL = os.environ.get("REACT_APP_BACKEND_URL")
TENANT = "demo"


def _base_url() -> str:
    if not BASE_URL:
        pytest.skip("REACT_APP_BACKEND_URL não definido")
    return BASE_URL.rstrip("/")


def _login(email: str, password: str, slug: str = TENANT) -> requests.Response:
    return requests.post(
        f"{_base_url()}/api/tenants/{slug}/auth/login",
        json={"email": email, "password": password},
        timeout=25,
    )


def _auth(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


def _assert_no_object_id(value):
    if isinstance(value, dict):
        assert "_id" not in value, f"ObjectId leaked in payload: {value}"
        for v in value.values():
            _assert_no_object_id(v)
    elif isinstance(value, list):
        for item in value:
            _assert_no_object_id(item)


@pytest.fixture(scope="module")
def admin_session():
    response = _login("admin@demo.com", "Admin@123456")
    assert response.status_code == 200, response.text
    body = response.json()
    token = body.get("access_token")
    assert isinstance(token, str) and token
    return {"token": token, "body": body}


def test_role_logins_and_context(admin_session):
    """Role matrix: admin, gerente, seller log in and map to expected role."""
    role_cases = [
        ("admin@demo.com", "Admin@123456", "TENANT_ADMIN"),
        ("gerente@demo.com", "Admin@123456", "STORE_MANAGER"),
        ("joao@demo.com", "Admin@123456", "SELLER"),
    ]
    for email, password, expected_role in role_cases:
        resp = _login(email, password)
        assert resp.status_code == 200, f"Login failed for {email}: {resp.status_code} {resp.text}"
        data = resp.json()
        assert data.get("membership", {}).get("role") == expected_role
        assert isinstance(data.get("access_token"), str) and data.get("access_token")

        ctx_resp = requests.get(
            f"{_base_url()}/api/tenants/{TENANT}/context",
            headers=_auth(data["access_token"]),
            timeout=25,
        )
        assert ctx_resp.status_code == 200, ctx_resp.text
        ctx = ctx_resp.json()
        assert ctx.get("user_role") == expected_role


def test_dashboard_summary_last_7_days_with_store_and_seller_filters(admin_session):
    """Dashboard summary returns scoped data for last 7 days and no ObjectId leaks."""
    token = admin_session["token"]
    headers = _auth(token)

    stores_resp = requests.get(f"{_base_url()}/api/tenants/{TENANT}/stores", headers=headers, timeout=25)
    assert stores_resp.status_code == 200, stores_resp.text
    stores = stores_resp.json()
    assert isinstance(stores, list) and len(stores) >= 3
    store_id = stores[0]["id"]

    sellers_resp = requests.get(f"{_base_url()}/api/tenants/{TENANT}/sellers", headers=headers, timeout=25)
    assert sellers_resp.status_code == 200, sellers_resp.text
    sellers = sellers_resp.json()
    assert isinstance(sellers, list) and len(sellers) >= 7
    seller_id = sellers[0]["id"]

    today = datetime.now(timezone.utc).date()
    date_from = (today - timedelta(days=6)).isoformat()
    date_to = today.isoformat()

    summary_resp = requests.get(
        f"{_base_url()}/api/tenants/{TENANT}/dashboard/summary",
        headers=headers,
        params={
            "date_from": date_from,
            "date_to": date_to,
            "store_id": store_id,
            "seller_id": seller_id,
        },
        timeout=40,
    )
    assert summary_resp.status_code == 200, summary_resp.text
    payload = summary_resp.json()
    assert "kpis" in payload and isinstance(payload["kpis"], dict)
    assert "week_trend" in payload and isinstance(payload["week_trend"], list)
    assert len(payload["week_trend"]) == 7
    _assert_no_object_id(payload)


def test_dashboard_summary_seller_forbidden(admin_session):
    """SELLER cannot access dashboard summary endpoint."""
    seller_resp = _login("joao@demo.com", "Admin@123456")
    assert seller_resp.status_code == 200, seller_resp.text
    seller_token = seller_resp.json()["access_token"]

    resp = requests.get(
        f"{_base_url()}/api/tenants/{TENANT}/dashboard/summary",
        headers=_auth(seller_token),
        timeout=25,
    )
    assert resp.status_code == 403, resp.text


def test_opportunity_flow_response_shape_and_no_object_id(admin_session):
    """Opportunity-flow endpoint returns totals/series and no ObjectId in payload."""
    token = admin_session["token"]
    today = datetime.now(timezone.utc).date()
    date_start = (today - timedelta(days=6)).isoformat()
    date_end = today.isoformat()

    resp = requests.get(
        f"{_base_url()}/api/tenants/{TENANT}/reports/opportunity-flow",
        headers=_auth(token),
        params={"date_start": date_start, "date_end": date_end},
        timeout=45,
    )
    assert resp.status_code == 200, resp.text
    data = resp.json()
    assert "totals" in data and isinstance(data["totals"], dict)
    assert "series" in data and isinstance(data["series"], list)
    assert data["totals"].get("opportunities", 0) >= data["totals"].get("converted_opportunities", 0)
    _assert_no_object_id(data)


def test_presentation_seed_shape_three_stores_and_seven_demo_sellers(admin_session):
    """Presentation seed expected shape: 3 stores + 7 seller demo emails."""
    token = admin_session["token"]
    headers = _auth(token)

    stores_resp = requests.get(f"{_base_url()}/api/tenants/{TENANT}/stores", headers=headers, timeout=25)
    assert stores_resp.status_code == 200, stores_resp.text
    stores = stores_resp.json()
    assert len(stores) == 3, f"Expected 3 stores seeded, got {len(stores)}"

    sellers_resp = requests.get(f"{_base_url()}/api/tenants/{TENANT}/sellers", headers=headers, timeout=25)
    assert sellers_resp.status_code == 200, sellers_resp.text
    sellers = sellers_resp.json()
    emails = sorted({(s.get("user") or {}).get("email") for s in sellers if (s.get("user") or {}).get("email")})
    expected = sorted(
        [
            "joao@demo.com",
            "maria@demo.com",
            "carlos@demo.com",
            "ana@demo.com",
            "beatriz@demo.com",
            "rafael@demo.com",
            "paula@demo.com",
        ]
    )
    for email in expected:
        assert email in emails, f"Missing seeded demo seller email: {email}"


def test_presentation_seed_has_recent_7_day_activity(admin_session):
    """Recent realistic activity check via opportunity-flow series for 7-day window."""
    token = admin_session["token"]
    today = datetime.now(timezone.utc).date()
    date_start = (today - timedelta(days=6)).isoformat()
    date_end = today.isoformat()
    resp = requests.get(
        f"{_base_url()}/api/tenants/{TENANT}/reports/opportunity-flow",
        headers=_auth(token),
        params={"date_start": date_start, "date_end": date_end},
        timeout=45,
    )
    assert resp.status_code == 200, resp.text
    data = resp.json()
    assert len(data.get("series", [])) >= 7
    assert data.get("totals", {}).get("opportunities", 0) > 0


def test_auth_login_does_not_set_httponly_cookie_current_behavior():
    """Auth playbook check: verify if login sets HttpOnly cookies."""
    resp = _login("admin@demo.com", "Admin@123456")
    assert resp.status_code == 200, resp.text
    set_cookie = resp.headers.get("set-cookie", "")
    assert "httponly" in set_cookie.lower(), f"Expected HttpOnly cookie, got: {set_cookie}"


def test_auth_cors_allows_credentials_with_explicit_origin():
    """Auth playbook check: preflight should allow credentials for explicit origin."""
    origin = "https://queue-mgmt-3.preview.emergentagent.com"
    resp = requests.options(
        f"{_base_url()}/api/tenants/{TENANT}/auth/login",
        headers={
            "Origin": origin,
            "Access-Control-Request-Method": "POST",
            "Access-Control-Request-Headers": "content-type",
        },
        timeout=25,
    )
    assert resp.status_code in (200, 204), resp.text
    assert resp.headers.get("access-control-allow-origin") == origin
    assert resp.headers.get("access-control-allow-credentials") == "true"


def test_auth_bruteforce_lockout_after_five_failures():
    """Auth playbook check: lockout behavior after 5 failed attempts."""
    email = f"prompt72-lockout-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}@example.com"
    wrong_password = "WrongPassword_123!"
    for _ in range(5):
        r = _login(email, wrong_password)
        assert r.status_code == 401
    sixth = _login(email, wrong_password)
    assert sixth.status_code == 401
    detail = sixth.json().get("detail", {})
    msg = detail.get("message", "") if isinstance(detail, dict) else str(detail)
    assert "Credenciais inválidas" in msg