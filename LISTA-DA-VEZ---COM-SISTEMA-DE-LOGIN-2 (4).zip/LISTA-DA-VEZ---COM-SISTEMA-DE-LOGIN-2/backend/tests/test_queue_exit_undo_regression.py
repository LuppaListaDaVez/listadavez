"""Queue Prompt regression: Janela de Saída motivos + undo backend sequence.
Tests sair-da-fila (ENCERRAR_DIA/LANCHE/ATIVIDADE) and revert endpoints.
"""

import os
from typing import Dict, Optional

import pytest
import requests


BASE_URL = os.environ.get("REACT_APP_BACKEND_URL")
TENANT = "demo"
ADMIN_EMAIL = "admin@demo.com"
ADMIN_PASS = "Admin@123456"
SELLER_EMAIL = "joao@demo.com"


def _headers(token: str) -> Dict[str, str]:
    return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}


def _find_seller_in_state(state: dict, seller_id: str) -> Optional[dict]:
    for section in ("entries", "available_sellers", "away_sellers", "serving_sellers"):
        for item in state.get(section) or []:
            if item.get("seller_id") == seller_id:
                return {**item, "_section": section}
    return None


@pytest.fixture(scope="module")
def env_ready():
    if not BASE_URL:
        pytest.skip("REACT_APP_BACKEND_URL não definido")


@pytest.fixture(scope="module")
def admin_token(env_ready):
    response = requests.post(
        f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT}/auth/login",
        json={"email": ADMIN_EMAIL, "password": ADMIN_PASS},
    )
    assert response.status_code == 200, f"Admin login falhou: {response.status_code} {response.text}"
    payload = response.json()
    assert isinstance(payload.get("access_token"), str) and payload["access_token"]
    return payload["access_token"]


@pytest.fixture(scope="module")
def ctx(admin_token):
    headers = _headers(admin_token)
    stores_response = requests.get(
        f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT}/stores",
        headers=headers,
    )
    assert stores_response.status_code == 200, stores_response.text
    stores = stores_response.json()
    assert stores and stores[0].get("id")
    store_id = stores[0]["id"]

    state_response = requests.get(
        f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT}/stores/{store_id}/queue",
        headers=headers,
    )
    assert state_response.status_code == 200, state_response.text
    state = state_response.json()
    queue_id = state.get("queue", {}).get("id")
    assert queue_id

    all_sellers = (
        (state.get("entries") or [])
        + (state.get("available_sellers") or [])
        + (state.get("away_sellers") or [])
        + [a.get("seller") for a in (state.get("active_attendances") or []) if a.get("seller")]
    )
    assert all_sellers, "Nenhum vendedor encontrado"

    target = next((s for s in all_sellers if (s.get("email") or "").lower() == SELLER_EMAIL), None)
    if not target:
        target = next((s for s in all_sellers if "jo" in (s.get("name") or "").lower()), None)
    target = target or all_sellers[0]
    seller_id = target.get("seller_id") or target.get("id")
    assert seller_id

    return {"token": admin_token, "store_id": store_id, "queue_id": queue_id, "seller_id": seller_id}


def _get_state(ctx_data: dict) -> dict:
    response = requests.get(
        f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT}/stores/{ctx_data['store_id']}/queue",
        headers=_headers(ctx_data["token"]),
    )
    assert response.status_code == 200, response.text
    data = response.json()
    assert isinstance(data.get("entries"), list)
    return data


def _cancel_active_attendance_if_any(ctx_data: dict):
    state = _get_state(ctx_data)
    headers = _headers(ctx_data["token"])
    for att in state.get("active_attendances") or []:
        if att.get("seller_id") == ctx_data["seller_id"]:
            response = requests.post(
                f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT}/attendances/{att['id']}/cancel",
                headers=headers,
                json={"reason": "TEST_cleanup_queue_exit_undo"},
            )
            assert response.status_code in (200, 409), response.text


def _ensure_seller_in_queue(ctx_data: dict):
    headers = _headers(ctx_data["token"])
    _cancel_active_attendance_if_any(ctx_data)

    # Up to 4 attempts to normalize seller state for deterministic tests.
    for _ in range(4):
        state = _get_state(ctx_data)
        info = _find_seller_in_state(state, ctx_data["seller_id"])
        assert info is not None, "Vendedor alvo não encontrado no estado da fila"

        if info.get("_section") == "entries" and not info.get("em_atividade_operacional"):
            return

        if info.get("_section") == "entries" and info.get("em_atividade_operacional"):
            requests.post(
                f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT}/stores/{ctx_data['store_id']}/queue/retornar-operacao",
                headers=headers,
                json={"seller_id": ctx_data["seller_id"]},
            )
            continue

        if info.get("_section") == "away_sellers":
            if info.get("jornada_encerrada"):
                requests.post(
                    f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT}/stores/{ctx_data['store_id']}/queue/nova-jornada",
                    headers=headers,
                    json={"seller_id": ctx_data["seller_id"]},
                )
            else:
                requests.post(
                    f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT}/stores/{ctx_data['store_id']}/queue/retornar-da-fora",
                    headers=headers,
                    json={"seller_id": ctx_data["seller_id"], "queue_id": ctx_data["queue_id"]},
                )
            continue

        if info.get("_section") == "available_sellers":
            join_response = requests.post(
                f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT}/stores/{ctx_data['store_id']}/queue/join",
                headers=headers,
                json={"seller_id": ctx_data["seller_id"], "queue_id": ctx_data["queue_id"]},
            )
            assert join_response.status_code in (200, 409), join_response.text
            continue

    final_state = _get_state(ctx_data)
    final_info = _find_seller_in_state(final_state, ctx_data["seller_id"])
    assert final_info and final_info.get("_section") == "entries" and not final_info.get("em_atividade_operacional")


def test_encerrar_dia_sets_offline_and_jornada_encerrada(ctx):
    """ENCERRAR_DIA removes seller from queue and sets jornada_encerrada=true in away list."""
    _ensure_seller_in_queue(ctx)
    response = requests.post(
        f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT}/stores/{ctx['store_id']}/queue/sair-da-fila",
        headers=_headers(ctx["token"]),
        json={"seller_id": ctx["seller_id"], "motivo": "ENCERRAR_DIA", "queue_id": ctx["queue_id"]},
    )
    assert response.status_code == 200, response.text
    state = response.json()
    away = next((s for s in (state.get("away_sellers") or []) if s.get("seller_id") == ctx["seller_id"]), None)
    assert away is not None
    assert away.get("current_status") == "OFFLINE"
    assert away.get("jornada_encerrada") is True
    assert away.get("motivo_saida") == "ENCERRAR_DIA"


def test_undo_sequence_for_encerrar_dia_returns_to_queue(ctx):
    """Undo backend sequence for ENCERRAR_DIA: nova-jornada then join restores WAITING_IN_QUEUE."""
    headers = _headers(ctx["token"])
    nova_response = requests.post(
        f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT}/stores/{ctx['store_id']}/queue/nova-jornada",
        headers=headers,
        json={"seller_id": ctx["seller_id"]},
    )
    assert nova_response.status_code == 200, nova_response.text

    join_response = requests.post(
        f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT}/stores/{ctx['store_id']}/queue/join",
        headers=headers,
        json={"seller_id": ctx["seller_id"], "queue_id": ctx["queue_id"]},
    )
    assert join_response.status_code in (200, 409), join_response.text

    state = _get_state(ctx)
    entry = next((s for s in (state.get("entries") or []) if s.get("seller_id") == ctx["seller_id"]), None)
    assert entry is not None
    assert entry.get("current_status") == "WAITING_IN_QUEUE"
    assert entry.get("jornada_encerrada") is False
    assert entry.get("em_atividade_operacional") is False


def test_lanche_undo_regression_returns_to_queue(ctx):
    """Regression: LANCHE_OU_ALMOCO then retornar-da-fora should return seller to queue."""
    _ensure_seller_in_queue(ctx)
    headers = _headers(ctx["token"])

    sair_response = requests.post(
        f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT}/stores/{ctx['store_id']}/queue/sair-da-fila",
        headers=headers,
        json={"seller_id": ctx["seller_id"], "motivo": "LANCHE_OU_ALMOCO", "queue_id": ctx["queue_id"]},
    )
    assert sair_response.status_code == 200, sair_response.text
    away = next((s for s in (sair_response.json().get("away_sellers") or []) if s.get("seller_id") == ctx["seller_id"]), None)
    assert away is not None
    assert away.get("motivo_saida") == "LANCHE_OU_ALMOCO"

    voltar_response = requests.post(
        f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT}/stores/{ctx['store_id']}/queue/retornar-da-fora",
        headers=headers,
        json={"seller_id": ctx["seller_id"], "queue_id": ctx["queue_id"]},
    )
    assert voltar_response.status_code == 200, voltar_response.text

    state = _get_state(ctx)
    entry = next((s for s in (state.get("entries") or []) if s.get("seller_id") == ctx["seller_id"]), None)
    assert entry is not None
    assert entry.get("current_status") == "WAITING_IN_QUEUE"


def test_atividade_operacional_undo_regression_keeps_queue_position(ctx):
    """Regression: ATIVIDADE_OPERACIONAL marks flag and retornar-operacao removes it in queue."""
    _ensure_seller_in_queue(ctx)
    headers = _headers(ctx["token"])

    sair_response = requests.post(
        f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT}/stores/{ctx['store_id']}/queue/sair-da-fila",
        headers=headers,
        json={"seller_id": ctx["seller_id"], "motivo": "ATIVIDADE_OPERACIONAL", "queue_id": ctx["queue_id"]},
    )
    assert sair_response.status_code == 200, sair_response.text
    entry_oper = next((s for s in (sair_response.json().get("entries") or []) if s.get("seller_id") == ctx["seller_id"]), None)
    assert entry_oper is not None
    assert entry_oper.get("em_atividade_operacional") is True

    undo_response = requests.post(
        f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT}/stores/{ctx['store_id']}/queue/retornar-operacao",
        headers=headers,
        json={"seller_id": ctx["seller_id"]},
    )
    assert undo_response.status_code == 200, undo_response.text

    state = _get_state(ctx)
    entry = next((s for s in (state.get("entries") or []) if s.get("seller_id") == ctx["seller_id"]), None)
    assert entry is not None
    assert entry.get("current_status") == "WAITING_IN_QUEUE"
    assert entry.get("em_atividade_operacional") is False
