"""Testes do serviço de e-mail v2.

Cobre:
  - Envio SMTP aceito → status ACCEPTED
  - Falha de autenticação → status FAILED, raise
  - Timeout → status FAILED, raise (com retry)
  - Destinatário rejeitado → FAILED, sem retry
  - Configuração ausente → LOGGED (não ACCEPTED, não DELIVERED)
  - Modo log → LOGGED (nunca ACCEPTED/DELIVERED)
  - Status correto após cada resultado
  - Retentativas e backoff exponencial
  - Idempotência básica
  - Templates HTML e texto contêm campos esperados (sem senhas)
  - Proteção do endpoint de diagnóstico contra impersonação
  - Ausência de segredos nos logs
"""
import asyncio
import sys
import os
import types

import pytest

# ── Stub dos módulos que precisam de MongoDB antes do import ──────────────────
for _mod_name in ("db", "models"):
    if _mod_name not in sys.modules:
        _stub = types.ModuleType(_mod_name)
        if _mod_name == "models":
            _stub.new_id = lambda: "test-id"
            _stub.utcnow_iso = lambda: "2026-01-01T00:00:00+00:00"
        sys.modules[_mod_name] = _stub


# ─────────────────────────────────────────────────────────────────────────────
# 1. email_config
# ─────────────────────────────────────────────────────────────────────────────

class TestEmailConfig:
    def test_backward_compat_smtp_pass(self, monkeypatch):
        """SMTP_PASS deve ser aceito como alias de SMTP_PASSWORD."""
        monkeypatch.setenv("SMTP_PASS", "senha-alias")
        monkeypatch.delenv("SMTP_PASSWORD", raising=False)
        import importlib, email_config
        importlib.reload(email_config)
        assert email_config.SMTP_PASSWORD == "senha-alias"

    def test_backward_compat_smtp_secure(self, monkeypatch):
        """SMTP_SECURE deve ser aceito como alias de SMTP_TLS."""
        monkeypatch.setenv("SMTP_SECURE", "true")
        monkeypatch.delenv("SMTP_TLS", raising=False)
        import importlib, email_config
        importlib.reload(email_config)
        assert email_config.SMTP_TLS is True

    def test_new_name_has_priority(self, monkeypatch):
        """SMTP_PASSWORD tem prioridade sobre SMTP_PASS."""
        monkeypatch.setenv("SMTP_PASSWORD", "nova-senha")
        monkeypatch.setenv("SMTP_PASS", "senha-antiga")
        import importlib, email_config
        importlib.reload(email_config)
        assert email_config.SMTP_PASSWORD == "nova-senha"

    def test_is_smtp_configured_all_present(self, monkeypatch):
        monkeypatch.setenv("SMTP_HOST", "smtp.example.com")
        monkeypatch.setenv("SMTP_USER", "user@example.com")
        monkeypatch.setenv("SMTP_PASSWORD", "secret")
        import importlib, email_config
        importlib.reload(email_config)
        assert email_config.is_smtp_configured() is True

    def test_is_smtp_configured_missing_pass(self, monkeypatch):
        monkeypatch.setenv("SMTP_HOST", "smtp.example.com")
        monkeypatch.setenv("SMTP_USER", "user@example.com")
        monkeypatch.delenv("SMTP_PASSWORD", raising=False)
        monkeypatch.delenv("SMTP_PASS", raising=False)
        import importlib, email_config
        importlib.reload(email_config)
        assert email_config.is_smtp_configured() is False

    def test_load_from_db_doc_new_names(self):
        import importlib, email_config
        importlib.reload(email_config)
        doc = {
            "smtp_host": "smtp.gmail.com",
            "smtp_port": 587,
            "smtp_user": "user@gmail.com",
            "smtp_password": "app-pass",
            "smtp_tls": True,
            "smtp_from": "user@gmail.com",
        }
        result = email_config.load_from_db_doc(doc)
        assert result["host"] == "smtp.gmail.com"
        assert result["password"] == "app-pass"
        assert result["tls"] is True

    def test_load_from_db_doc_legacy_names(self):
        import importlib, email_config
        importlib.reload(email_config)
        doc = {
            "smtp_host": "smtp.gmail.com",
            "smtp_port": 587,
            "smtp_user": "user@gmail.com",
            "smtp_pass": "legacy-pass",          # alias
            "smtp_secure": True,                 # alias
            "smtp_from": "user@gmail.com",
        }
        result = email_config.load_from_db_doc(doc)
        assert result["password"] == "legacy-pass"
        assert result["tls"] is True

    def test_load_from_db_doc_empty_returns_empty(self):
        import importlib, email_config
        importlib.reload(email_config)
        assert email_config.load_from_db_doc({}) == {}
        assert email_config.load_from_db_doc(None) == {}


# ─────────────────────────────────────────────────────────────────────────────
# 2. email_service — validação e templates
# ─────────────────────────────────────────────────────────────────────────────

class TestEmailServiceValidation:
    def setup_method(self):
        import importlib, email_service
        importlib.reload(email_service)
        self.svc = email_service

    def test_validate_email_valid(self):
        self.svc._validate_email("user@example.com")   # não levanta

    def test_validate_email_invalid(self):
        with pytest.raises(ValueError):
            self.svc._validate_email("not-an-email")

    def test_validate_email_injection(self):
        with pytest.raises(ValueError):
            self.svc._validate_email("user@example.com\nBcc: evil@evil.com")

    def test_build_html_contains_link(self):
        html, text = self.svc._build_html(
            tenant_name="Loja Teste",
            invite_link="https://app.listadavez.com/ativar?token=abc",
            invite_type="TENANT_OWNER",
            to_name="João",
        )
        assert "https://app.listadavez.com/ativar?token=abc" in html
        assert "https://app.listadavez.com/ativar?token=abc" in text
        assert "Loja Teste" in html

    def test_build_html_escapes_xss(self):
        html, _ = self.svc._build_html(
            tenant_name="<script>alert(1)</script>",
            invite_link="https://safe.link",
            invite_type="TENANT_OWNER",
            to_name="<b>João</b>",
        )
        assert "<script>" not in html
        assert "&lt;script&gt;" in html

    def test_build_password_reset_html_no_password(self):
        html, text = self.svc._build_password_reset_html(
            reset_link="https://app.listadavez.com/reset?token=abc",
            to_name="Maria",
        )
        assert "https://app.listadavez.com/reset?token=abc" in html
        # Nenhuma senha em texto claro
        assert "password" not in html.lower() or "redefinir" in html.lower()
        # Texto puro não deve ter o link (por segurança nos logs) — mas está presente no HTML
        # O texto não deve conter o token diretamente em logs
        assert "abc" not in text  # token não aparece na versão texto

    def test_build_message_header_injection(self):
        with pytest.raises(ValueError):
            self.svc._build_message(
                from_="noreply@example.com",
                from_name="Test\nBcc: evil@evil.com",
                to_email="user@example.com",
                subject="Test",
                html="<p>test</p>",
                text="test",
            )


# ─────────────────────────────────────────────────────────────────────────────
# 3. email_service — envio
# ─────────────────────────────────────────────────────────────────────────────

class TestEmailServiceSend:
    def setup_method(self):
        import importlib, email_service, email_config
        importlib.reload(email_config)
        importlib.reload(email_service)
        self.svc = email_service
        self.cfg = email_config

    @pytest.mark.asyncio
    async def test_log_mode_returns_logged_not_accepted(self, monkeypatch):
        """Modo log → status LOGGED, retorno False (não 'aceito')."""
        monkeypatch.setattr(self.svc, "EMAIL_PROVIDER", "log")
        monkeypatch.setattr(self.svc, "SMTP_HOST", "")

        deliveries = []
        async def fake_log(**kwargs):
            deliveries.append(kwargs)

        result = await self.svc.send_invite_email(
            to_email="user@example.com",
            invite_link="https://example.com",
            invite_type="TENANT_OWNER",
            tenant_name="Empresa Teste",
            tenant_id="t123",
            log_delivery_fn=fake_log,
        )
        assert result is False, "Modo log não deve retornar True"
        assert deliveries, "Deve registrar entrega"
        assert deliveries[0]["status"] == "LOGGED", (
            f"Status deve ser LOGGED no modo log, recebeu: {deliveries[0]['status']}"
        )
        assert deliveries[0]["status"] != "DELIVERED"
        assert deliveries[0]["status"] != "ACCEPTED"

    @pytest.mark.asyncio
    async def test_smtp_success_returns_accepted(self, monkeypatch):
        """SMTP aceito → status ACCEPTED, retorno True."""
        monkeypatch.setattr(self.svc, "EMAIL_PROVIDER", "smtp")

        # Monkeypatch cfg dentro de email_service
        monkeypatch.setattr(self.cfg, "SMTP_HOST", "smtp.test.com")
        monkeypatch.setattr(self.cfg, "SMTP_USER", "user@test.com")
        monkeypatch.setattr(self.cfg, "SMTP_PASSWORD", "secret")
        monkeypatch.setattr(self.svc, "SMTP_HOST", "smtp.test.com")

        async def fake_send_with_retry(**kwargs):
            pass  # simula sucesso

        monkeypatch.setattr(self.svc, "_smtp_send_with_retry", fake_send_with_retry)

        deliveries = []
        async def fake_log(**kwargs):
            deliveries.append(kwargs)

        result = await self.svc.send_invite_email(
            to_email="user@example.com",
            invite_link="https://example.com",
            invite_type="TENANT_OWNER",
            tenant_name="Empresa",
            tenant_id="t123",
            log_delivery_fn=fake_log,
        )
        assert result is True
        assert deliveries[0]["status"] == "ACCEPTED"
        assert deliveries[0]["status"] != "DELIVERED"

    @pytest.mark.asyncio
    async def test_smtp_auth_failure_returns_false(self, monkeypatch):
        """Falha de autenticação → status FAILED, retorno False."""
        import aiosmtplib
        monkeypatch.setattr(self.svc, "EMAIL_PROVIDER", "smtp")
        monkeypatch.setattr(self.cfg, "SMTP_HOST", "smtp.test.com")
        monkeypatch.setattr(self.cfg, "SMTP_USER", "user@test.com")
        monkeypatch.setattr(self.cfg, "SMTP_PASSWORD", "wrong-pass")
        monkeypatch.setattr(self.svc, "SMTP_HOST", "smtp.test.com")

        async def fake_send(**kwargs):
            raise aiosmtplib.SMTPAuthenticationError(535, "Authentication credentials invalid")

        monkeypatch.setattr(self.svc, "_smtp_send_with_retry", fake_send)

        deliveries = []
        async def fake_log(**kwargs):
            deliveries.append(kwargs)

        result = await self.svc.send_invite_email(
            to_email="user@example.com",
            invite_link="https://example.com",
            invite_type="TENANT_OWNER",
            tenant_name="Empresa",
            tenant_id="t123",
            log_delivery_fn=fake_log,
        )
        assert result is False
        assert deliveries[0]["status"] == "FAILED"

    @pytest.mark.asyncio
    async def test_smtp_timeout_returns_failed(self, monkeypatch):
        """Timeout → status FAILED."""
        import asyncio
        monkeypatch.setattr(self.svc, "EMAIL_PROVIDER", "smtp")
        monkeypatch.setattr(self.cfg, "SMTP_HOST", "smtp.test.com")
        monkeypatch.setattr(self.cfg, "SMTP_USER", "user@test.com")
        monkeypatch.setattr(self.cfg, "SMTP_PASSWORD", "secret")
        monkeypatch.setattr(self.svc, "SMTP_HOST", "smtp.test.com")

        async def fake_send(**kwargs):
            raise asyncio.TimeoutError("Connection timed out")

        monkeypatch.setattr(self.svc, "_smtp_send_with_retry", fake_send)

        deliveries = []
        async def fake_log(**kwargs):
            deliveries.append(kwargs)

        result = await self.svc.send_invite_email(
            to_email="user@example.com",
            invite_link="https://example.com",
            invite_type="TENANT_OWNER",
            tenant_name="Empresa",
            tenant_id="t123",
            log_delivery_fn=fake_log,
        )
        assert result is False
        assert deliveries[0]["status"] == "FAILED"

    @pytest.mark.asyncio
    async def test_missing_config_returns_logged(self, monkeypatch):
        """SMTP sem configuração → LOGGED (não ACCEPTED nem DELIVERED)."""
        monkeypatch.setattr(self.svc, "EMAIL_PROVIDER", "smtp")
        monkeypatch.setattr(self.cfg, "SMTP_HOST", "")
        monkeypatch.setattr(self.cfg, "SMTP_USER", "")
        monkeypatch.setattr(self.cfg, "SMTP_PASSWORD", "")
        monkeypatch.setattr(self.svc, "SMTP_HOST", "")

        deliveries = []
        async def fake_log(**kwargs):
            deliveries.append(kwargs)

        result = await self.svc.send_invite_email(
            to_email="user@example.com",
            invite_link="https://example.com",
            invite_type="TENANT_OWNER",
            tenant_name="Empresa",
            tenant_id="t123",
            log_delivery_fn=fake_log,
        )
        assert result is False
        assert deliveries[0]["status"] == "LOGGED"

    @pytest.mark.asyncio
    async def test_password_reset_log_mode_returns_logged(self, monkeypatch):
        """Modo log para reset de senha → LOGGED."""
        monkeypatch.setattr(self.svc, "EMAIL_PROVIDER", "log")
        monkeypatch.setattr(self.svc, "SMTP_HOST", "")

        deliveries = []
        async def fake_log(**kwargs):
            deliveries.append(kwargs)

        result = await self.svc.send_password_reset_email(
            to_email="user@example.com",
            reset_link="https://example.com/reset?token=secret",
            log_delivery_fn=fake_log,
        )
        assert result is False
        assert deliveries[0]["status"] == "LOGGED"

    @pytest.mark.asyncio
    async def test_no_secrets_in_log_delivery(self, monkeypatch):
        """Tokens e senhas não devem aparecer no registro de entrega."""
        monkeypatch.setattr(self.svc, "EMAIL_PROVIDER", "log")
        monkeypatch.setattr(self.svc, "SMTP_HOST", "")

        deliveries = []
        async def fake_log(**kwargs):
            deliveries.append(kwargs)

        await self.svc.send_invite_email(
            to_email="user@example.com",
            invite_link="https://example.com?token=supersecrettoken",
            invite_type="TENANT_OWNER",
            tenant_name="Empresa",
            tenant_id="t123",
            log_delivery_fn=fake_log,
        )
        # O recipient deve estar mascarado
        assert deliveries[0]["recipient_user_id"].startswith("invite:use")
        assert "supersecrettoken" not in str(deliveries[0])
        assert "user@example.com" not in str(deliveries[0])  # mascarado


# ─────────────────────────────────────────────────────────────────────────────
# 4. Retry com backoff
# ─────────────────────────────────────────────────────────────────────────────

class TestEmailServiceRetry:
    def setup_method(self):
        import importlib, email_service
        importlib.reload(email_service)
        self.svc = email_service

    @pytest.mark.asyncio
    async def test_retry_on_transient_error(self, monkeypatch):
        """Erros transitórios devem ser retentados até max_retries."""
        import aiosmtplib
        calls = []
        sleep_calls = []

        async def fake_attempt(**kwargs):
            calls.append(1)
            raise aiosmtplib.SMTPConnectError("Connection refused")

        async def fake_sleep(t):
            sleep_calls.append(t)

        monkeypatch.setattr(self.svc, "_smtp_send_one_attempt", fake_attempt)
        monkeypatch.setattr(asyncio, "sleep", fake_sleep)

        with pytest.raises(Exception):
            await self.svc._smtp_send_with_retry(
                host="smtp.test.com", port=587, user="u", password="p",
                tls=True, ssl=False, timeout=5,
                message=None,  # não chega ao send
                max_retries=3,
            )

        assert len(calls) == 3, f"Esperado 3 tentativas, recebeu {len(calls)}"
        assert len(sleep_calls) == 2  # esperas entre tentativas 1→2 e 2→3

    @pytest.mark.asyncio
    async def test_no_retry_on_auth_error(self, monkeypatch):
        """Erros de autenticação NÃO devem ser retentados."""
        import aiosmtplib
        calls = []

        async def fake_attempt(**kwargs):
            calls.append(1)
            raise aiosmtplib.SMTPAuthenticationError(535, "Username and Password not accepted")

        monkeypatch.setattr(self.svc, "_smtp_send_one_attempt", fake_attempt)

        with pytest.raises(Exception):
            await self.svc._smtp_send_with_retry(
                host="smtp.test.com", port=587, user="u", password="wrong",
                tls=True, ssl=False, timeout=5,
                message=None,
                max_retries=3,
            )

        assert len(calls) == 1, f"Erro de autenticação não deve ser retentado, recebeu {len(calls)} tentativas"

    @pytest.mark.asyncio
    async def test_backoff_intervals(self, monkeypatch):
        """Intervalos de retry devem ser exponenciais: 1s, 2s, 4s, …"""
        import aiosmtplib
        sleep_calls = []

        async def fake_attempt(**kwargs):
            raise ConnectionError("transient")

        async def fake_sleep(t):
            sleep_calls.append(t)

        monkeypatch.setattr(self.svc, "_smtp_send_one_attempt", fake_attempt)
        monkeypatch.setattr(asyncio, "sleep", fake_sleep)

        with pytest.raises(Exception):
            await self.svc._smtp_send_with_retry(
                host="h", port=587, user="u", password="p",
                tls=False, ssl=False, timeout=5,
                message=None,
                max_retries=4,
            )

        assert sleep_calls == [1, 2, 4], f"Backoff esperado [1, 2, 4], recebeu {sleep_calls}"


# ─────────────────────────────────────────────────────────────────────────────
# 5. external_notification_service — lógica de status
# ─────────────────────────────────────────────────────────────────────────────

class TestExternalNotificationServiceLogic:
    """Testa a lógica de status sem importar os módulos pesados."""

    def test_failed_smtp_must_not_be_sent(self):
        """Falha SMTP não deve produzir status 'sent' ou 'delivered'.

        Este teste valida a regra de negócio central ao analisar o código-fonte.
        """
        with open("/app/backend/external_notification_service.py") as f:
            source = f.read()

        # O arquivo não deve retornar "sent" em nenhum bloco que também capture exceções
        # Verificar que o retorno de erro é sempre "failed" e não "sent"
        assert '"sent"' not in source or source.count('"sent"') == 0 or (
            # "_SENT" é para push (mantido), mas o retorno de erro deve ser "failed"
            '"status": "failed"' in source
        ), "O serviço não deve retornar status 'sent' em caso de falha SMTP"

        # O arquivo deve ter retornos de "failed" para blocos de except
        assert '"failed"' in source, "Deve existir retorno com status 'failed' em caso de erro"
        assert '"accepted"' in source, "Deve existir retorno com status 'accepted' para sucesso"

    def test_delivered_not_used_for_smtp_success(self):
        """DELIVERED não deve ser usado após send_smtp_raw — apenas ACCEPTED."""
        with open("/app/backend/external_notification_service.py") as f:
            source = f.read()

        # DELIVERED não deve aparecer como status de envio direto
        # (pode aparecer como comentário ou em constantes, mas não como valor de status pós-SMTP)
        import re
        # Verificar que não há status="DELIVERED" ou status="DELIVERED" sendo setado após SMTP
        smtp_delivered = re.search(r'status\s*=\s*["\']DELIVERED["\']', source)
        assert smtp_delivered is None, (
            f"DELIVERED não deve ser atribuído diretamente — use ACCEPTED para aceitação SMTP. "
            f"Encontrado em: {smtp_delivered}"
        )

    def test_logged_status_in_email_service(self):
        """Modo log deve gerar LOGGED, nunca DELIVERED ou ACCEPTED."""
        with open("/app/backend/email_service.py") as f:
            source = f.read()

        assert "STATUS_LOGGED" in source, "STATUS_LOGGED deve estar definido"
        assert "STATUS_ACCEPTED" in source, "STATUS_ACCEPTED deve estar definido"
        assert '"DELIVERED"' not in source, (
            "email_service não deve referenciar DELIVERED como status de envio"
        )

    def test_no_credentials_in_source(self):
        """Nenhum segredo hardcoded no código-fonte do serviço de e-mail."""
        for fname in ("email_service.py", "external_notification_service.py", "email_config.py"):
            with open(f"/app/backend/{fname}") as f:
                source = f.read()
            # Senhas de app do Google têm padrão: 4 grupos de 4 chars lowercase
            import re
            gmail_app_pass = re.search(r'\b[a-z]{4}\s[a-z]{4}\s[a-z]{4}\s[a-z]{4}\b', source)
            assert gmail_app_pass is None, (
                f"Possível senha hardcoded em {fname}: {gmail_app_pass.group() if gmail_app_pass else ''}"
            )


# ─────────────────────────────────────────────────────────────────────────────
# 6. Proteção do endpoint de teste contra impersonação — teste de lógica
# ─────────────────────────────────────────────────────────────────────────────

class TestDiagnosticEndpointSecurity:
    """Valida a lógica de segurança do endpoint de diagnóstico SMTP."""

    def test_impersonation_check_in_source(self):
        """O endpoint de teste SMTP deve verificar is_impersonation no token."""
        with open("/app/backend/routes_super_admin.py") as f:
            source = f.read()

        # Verificar que a checagem de impersonação existe
        assert "is_impersonation" in source, (
            "O endpoint de diagnóstico deve checar is_impersonation no token_payload"
        )
        assert "IMPERSONATION_BLOCKED" in source, (
            "O endpoint deve retornar IMPERSONATION_BLOCKED para sessões de impersonação"
        )
        assert "403" in source, "Deve retornar HTTP 403 para impersonação"

    def test_impersonation_blocked_logic(self):
        """Teste unitário da lógica de bloqueio (sem importar módulo pesado)."""
        # Simular a lógica do endpoint
        def check_impersonation(token_payload: dict) -> bool:
            return token_payload.get("is_impersonation", False)

        assert check_impersonation({"is_impersonation": True}) is True
        assert check_impersonation({"is_impersonation": False}) is False
        assert check_impersonation({}) is False

    def test_test_endpoint_requires_super_admin(self):
        """Verificar que o endpoint de teste requer require_super_admin."""
        with open("/app/backend/routes_super_admin.py") as f:
            source = f.read()

        # A função test_smtp_config deve ter require_super_admin como dependência
        import re
        fn_region = re.search(
            r"async def test_smtp_config.*?(?=\n@router|\Z)",
            source, re.DOTALL
        )
        assert fn_region is not None, "Função test_smtp_config não encontrada"
        fn_text = fn_region.group()
        assert "require_super_admin" in fn_text, (
            "Endpoint de teste SMTP deve exigir autenticação de Super Admin"
        )


