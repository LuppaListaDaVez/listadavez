"""Etapa 10 — Feedbacks e Notificações Internas."""
import os
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")


def login(email, password):
    r = requests.post(f"{BASE_URL}/api/auth/login", json={"email": email, "password": password})
    assert r.status_code == 200, f"Login failed for {email}: {r.text}"
    return r.json()["access_token"]


@pytest.fixture(scope="module")
def admin_token():
    return login("admin@demo.com", "Admin@123456")


@pytest.fixture(scope="module")
def gerente_token():
    return login("gerente@demo.com", "Admin@123456")


@pytest.fixture(scope="module")
def joao_token():
    return login("joao@demo.com", "Admin@123456")


@pytest.fixture(scope="module")
def maria_token():
    return login("maria@demo.com", "Admin@123456")


def ah(token):
    return {"Authorization": f"Bearer {token}"}


# ────────── Helper: get joao seller_profile.id ──────────

@pytest.fixture(scope="module")
def joao_seller_id(admin_token):
    r = requests.get(f"{BASE_URL}/api/tenants/demo/feedbacks", headers=ah(admin_token))
    assert r.status_code == 200
    feedbacks = r.json()
    for fb in feedbacks:
        if "João" in fb.get("seller_name", "") or "joao" in fb.get("seller_name", "").lower():
            return fb["seller_id"]
    # Fallback: query seller_profiles
    r2 = requests.get(f"{BASE_URL}/api/tenants/demo/sellers", headers=ah(admin_token))
    if r2.status_code == 200:
        for s in r2.json():
            if "jo" in s.get("name", "").lower():
                return s["id"]
    pytest.skip("Couldn't find joao seller_id")


@pytest.fixture(scope="module")
def maria_seller_id(admin_token):
    r = requests.get(f"{BASE_URL}/api/tenants/demo/feedbacks", headers=ah(admin_token))
    assert r.status_code == 200
    feedbacks = r.json()
    for fb in feedbacks:
        if "Maria" in fb.get("seller_name", ""):
            return fb["seller_id"]
    pytest.skip("Couldn't find maria seller_id")


# ────────── 1. List feedbacks ──────────

class TestListFeedbacks:
    """List feedbacks RBAC"""

    def test_admin_can_list_all_feedbacks(self, admin_token):
        r = requests.get(f"{BASE_URL}/api/tenants/demo/feedbacks", headers=ah(admin_token))
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, list)
        # Seed has at least 3 feedbacks
        assert len(data) >= 3, f"Expected >=3 feedbacks, got {len(data)}"
        print(f"Admin sees {len(data)} feedbacks")

    def test_gerente_can_list_feedbacks(self, gerente_token):
        r = requests.get(f"{BASE_URL}/api/tenants/demo/feedbacks", headers=ah(gerente_token))
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_seller_sees_only_own_feedbacks(self, joao_token, joao_seller_id):
        r = requests.get(f"{BASE_URL}/api/tenants/demo/feedbacks", headers=ah(joao_token))
        assert r.status_code == 200
        feedbacks = r.json()
        for fb in feedbacks:
            assert fb["seller_id"] == joao_seller_id, f"Joao should not see feedback for seller {fb['seller_id']}"
        print(f"Joao sees {len(feedbacks)} feedbacks (all his own)")

    def test_seller_cannot_see_other_sellers_feedbacks(self, joao_token, maria_seller_id):
        r = requests.get(f"{BASE_URL}/api/tenants/demo/feedbacks", headers=ah(joao_token))
        assert r.status_code == 200
        for fb in r.json():
            assert fb["seller_id"] != maria_seller_id, "Joao should NOT see Maria's feedbacks"


# ────────── 2. Create feedback ──────────

class TestCreateFeedback:
    """Create feedback"""
    created_id = None

    def test_admin_create_positive_feedback_no_action_plan(self, admin_token, joao_seller_id):
        r = requests.post(
            f"{BASE_URL}/api/tenants/demo/feedbacks",
            headers=ah(admin_token),
            json={
                "seller_id": joao_seller_id,
                "type": "POSITIVE",
                "title": "TEST_Ótimo atendimento",
                "content": "Você atendeu muito bem o cliente hoje.",
            },
        )
        assert r.status_code == 200, f"Create feedback failed: {r.text}"
        data = r.json()
        assert data["type"] == "POSITIVE"
        assert data["seller_id"] == joao_seller_id
        assert data["is_acknowledged"] is False
        assert data["action_plan"] is None
        TestCreateFeedback.created_id = data["id"]
        print(f"Created feedback id={data['id']}")

    def test_admin_create_action_plan_feedback(self, admin_token, joao_seller_id):
        r = requests.post(
            f"{BASE_URL}/api/tenants/demo/feedbacks",
            headers=ah(admin_token),
            json={
                "seller_id": joao_seller_id,
                "type": "ACTION_PLAN",
                "title": "TEST_Plano de melhoria",
                "content": "Precisa melhorar a taxa de conversão.",
                "action_plan": {
                    "description": "Treinar técnicas de fechamento",
                    "due_date": "2026-03-31",
                },
            },
        )
        assert r.status_code == 200, f"Create action_plan feedback failed: {r.text}"
        data = r.json()
        assert data["action_plan"] is not None
        assert data["action_plan"]["status"] == "PENDING"
        assert data["action_plan"]["description"] == "Treinar técnicas de fechamento"

    def test_seller_cannot_create_feedback(self, joao_token, joao_seller_id):
        r = requests.post(
            f"{BASE_URL}/api/tenants/demo/feedbacks",
            headers=ah(joao_token),
            json={
                "seller_id": joao_seller_id,
                "type": "POSITIVE",
                "title": "TEST_seller try",
                "content": "seller creating feedback",
            },
        )
        assert r.status_code == 403, f"Seller should not create feedback, got {r.status_code}"

    def test_action_plan_type_without_description_fails(self, admin_token, joao_seller_id):
        r = requests.post(
            f"{BASE_URL}/api/tenants/demo/feedbacks",
            headers=ah(admin_token),
            json={
                "seller_id": joao_seller_id,
                "type": "ACTION_PLAN",
                "title": "TEST_missing plan",
                "content": "content here",
            },
        )
        assert r.status_code == 400


# ────────── 3. Get feedback detail ──────────

class TestGetFeedback:
    def test_admin_get_feedback_detail(self, admin_token):
        r = requests.get(f"{BASE_URL}/api/tenants/demo/feedbacks", headers=ah(admin_token))
        feedbacks = r.json()
        assert len(feedbacks) > 0
        fb_id = feedbacks[0]["id"]
        r2 = requests.get(f"{BASE_URL}/api/tenants/demo/feedbacks/{fb_id}", headers=ah(admin_token))
        assert r2.status_code == 200
        assert r2.json()["id"] == fb_id

    def test_seller_cannot_get_others_feedback(self, joao_token, admin_token, maria_seller_id):
        # Get a feedback for Maria
        r = requests.get(f"{BASE_URL}/api/tenants/demo/feedbacks?seller_id={maria_seller_id}", headers=ah(admin_token))
        # If Maria has feedbacks, try to get one with João's token
        if r.status_code == 200 and r.json():
            fb_id = r.json()[0]["id"]
            r2 = requests.get(f"{BASE_URL}/api/tenants/demo/feedbacks/{fb_id}", headers=ah(joao_token))
            assert r2.status_code == 403


# ────────── 4. Acknowledge feedback ──────────

class TestAcknowledgeFeedback:
    def test_seller_acknowledge_own_feedback(self, joao_token):
        r = requests.get(f"{BASE_URL}/api/tenants/demo/feedbacks", headers=ah(joao_token))
        feedbacks = r.json()
        assert len(feedbacks) > 0
        fb_id = feedbacks[0]["id"]
        r2 = requests.patch(f"{BASE_URL}/api/tenants/demo/feedbacks/{fb_id}/acknowledge", headers=ah(joao_token))
        assert r2.status_code == 200, f"Acknowledge failed: {r2.text}"
        assert r2.json()["is_acknowledged"] is True
        print(f"Joao acknowledged feedback {fb_id}")

    def test_admin_cannot_acknowledge(self, admin_token):
        r = requests.get(f"{BASE_URL}/api/tenants/demo/feedbacks", headers=ah(admin_token))
        fb_id = r.json()[0]["id"]
        r2 = requests.patch(f"{BASE_URL}/api/tenants/demo/feedbacks/{fb_id}/acknowledge", headers=ah(admin_token))
        # Admin doesn't have P_FEEDBACKS_ACKNOWLEDGE
        assert r2.status_code == 403


# ────────── 5. Update action plan ──────────

class TestUpdateActionPlan:
    def test_seller_can_update_own_action_plan_status(self, joao_token, admin_token, joao_seller_id):
        # Get an action_plan feedback for joao
        r = requests.get(f"{BASE_URL}/api/tenants/demo/feedbacks", headers=ah(admin_token))
        ap_feedbacks = [fb for fb in r.json() if fb.get("action_plan") and fb["seller_id"] == joao_seller_id]
        if not ap_feedbacks:
            pytest.skip("No action_plan feedback for joao found")
        fb_id = ap_feedbacks[0]["id"]
        r2 = requests.put(
            f"{BASE_URL}/api/tenants/demo/feedbacks/{fb_id}/action-plan",
            headers=ah(joao_token),
            json={"status": "IN_PROGRESS"},
        )
        assert r2.status_code == 200, f"Update action plan failed: {r2.text}"
        assert r2.json()["action_plan"]["status"] == "IN_PROGRESS"

    def test_admin_can_update_action_plan_description(self, admin_token, joao_seller_id):
        r = requests.get(f"{BASE_URL}/api/tenants/demo/feedbacks", headers=ah(admin_token))
        ap_feedbacks = [fb for fb in r.json() if fb.get("action_plan") and fb["seller_id"] == joao_seller_id]
        if not ap_feedbacks:
            pytest.skip("No action_plan feedback for joao found")
        fb_id = ap_feedbacks[0]["id"]
        r2 = requests.put(
            f"{BASE_URL}/api/tenants/demo/feedbacks/{fb_id}/action-plan",
            headers=ah(admin_token),
            json={"status": "COMPLETED", "description": "TEST_Treinamento concluído"},
        )
        assert r2.status_code == 200
        data = r2.json()
        assert data["action_plan"]["status"] == "COMPLETED"


# ────────── 6-9. Notifications ──────────

class TestNotifications:
    def test_unread_count_returns_number(self, joao_token):
        r = requests.get(f"{BASE_URL}/api/tenants/demo/notifications/unread-count", headers=ah(joao_token))
        assert r.status_code == 200, f"Unread count failed: {r.text}"
        data = r.json()
        assert "count" in data
        assert isinstance(data["count"], int)
        print(f"Joao unread count: {data['count']}")

    def test_list_notifications(self, joao_token):
        r = requests.get(f"{BASE_URL}/api/tenants/demo/notifications", headers=ah(joao_token))
        assert r.status_code == 200
        data = r.json()
        assert "notifications" in data
        assert "unread_count" in data
        assert isinstance(data["notifications"], list)
        # Seed created 2 notifications for joao
        assert len(data["notifications"]) >= 2, f"Expected >=2 notifs for joao, got {len(data['notifications'])}"
        print(f"Joao has {len(data['notifications'])} notifications")

    def test_mark_notification_read(self, joao_token):
        r = requests.get(f"{BASE_URL}/api/tenants/demo/notifications?unread_only=true", headers=ah(joao_token))
        notifs = r.json().get("notifications", [])
        if not notifs:
            pytest.skip("No unread notifications for joao")
        notif_id = notifs[0]["id"]
        r2 = requests.patch(f"{BASE_URL}/api/tenants/demo/notifications/{notif_id}/read", headers=ah(joao_token))
        assert r2.status_code == 200, f"Mark read failed: {r2.text}"
        data = r2.json()
        assert data.get("is_read") is True
        print(f"Marked notification {notif_id} as read")

    def test_mark_all_read(self, joao_token):
        r = requests.post(f"{BASE_URL}/api/tenants/demo/notifications/mark-all-read", headers=ah(joao_token))
        assert r.status_code == 200
        data = r.json()
        assert "marked" in data or "updated" in data or "count" in data or data is not None
        # Verify unread count is now 0
        r2 = requests.get(f"{BASE_URL}/api/tenants/demo/notifications/unread-count", headers=ah(joao_token))
        assert r2.json()["count"] == 0

    def test_notifications_scoped_to_user(self, admin_token, joao_token):
        # Admin should have different notifications than joao
        r_admin = requests.get(f"{BASE_URL}/api/tenants/demo/notifications", headers=ah(admin_token))
        assert r_admin.status_code == 200

    def test_admin_unread_count(self, admin_token):
        r = requests.get(f"{BASE_URL}/api/tenants/demo/notifications/unread-count", headers=ah(admin_token))
        assert r.status_code == 200


# ────────── 10. Creating feedback triggers notification ──────────

class TestFeedbackTriggersNotification:
    def test_create_feedback_triggers_notification(self, admin_token, joao_token, joao_seller_id):
        # Get current unread count for joao
        r1 = requests.get(f"{BASE_URL}/api/tenants/demo/notifications/unread-count", headers=ah(joao_token))
        before = r1.json()["count"]

        # Admin creates a new feedback for joao
        r2 = requests.post(
            f"{BASE_URL}/api/tenants/demo/feedbacks",
            headers=ah(admin_token),
            json={
                "seller_id": joao_seller_id,
                "type": "CONSTRUCTIVE",
                "title": "TEST_Notif trigger test",
                "content": "Verificando se notificação é gerada automaticamente.",
            },
        )
        assert r2.status_code == 200

        # Check joao's unread count increased
        r3 = requests.get(f"{BASE_URL}/api/tenants/demo/notifications/unread-count", headers=ah(joao_token))
        after = r3.json()["count"]
        assert after > before, f"Notification was not triggered: before={before}, after={after}"
        print(f"Notification triggered: {before} → {after}")
