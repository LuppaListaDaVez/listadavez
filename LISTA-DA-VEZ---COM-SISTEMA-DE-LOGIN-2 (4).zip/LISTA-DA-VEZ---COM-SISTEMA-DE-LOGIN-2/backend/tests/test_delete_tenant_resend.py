"""
Tests for: DELETE /api/super-admin/tenants/{id} (cascade) and resend-invite invite_link
"""
import pytest
import requests
import os
import time
import random

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")


def gen_cnpj():
    """Generate a valid random CNPJ."""
    def calc(nums, weights):
        s = sum(n * w for n, w in zip(nums, weights))
        r = s % 11
        return 0 if r < 2 else 11 - r

    base = [random.randint(0, 9) for _ in range(8)] + [0, 0, 0, 1]
    w1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    w2 = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    d1 = calc(base[:12], w1)
    d2 = calc(base[:12] + [d1], w2)
    return "".join(map(str, base + [d1, d2]))

SA_EMAIL = "admin@listadavez.com"
SA_PASSWORD = "Admin@123456"


@pytest.fixture(scope="module")
def sa_token():
    r = requests.post(f"{BASE_URL}/api/auth/login", json={"email": SA_EMAIL, "password": SA_PASSWORD, "tenant_slug": "super-admin"})
    assert r.status_code == 200, f"SA login failed: {r.text}"
    return r.json()["access_token"]


@pytest.fixture(scope="module")
def sa_headers(sa_token):
    return {"Authorization": f"Bearer {sa_token}"}


@pytest.fixture(scope="module")
def dummy_tenant(sa_headers):
    """Create a tenant for delete/resend tests."""
    ts = int(time.time())
    payload = {
        "name": f"TEST_Delete_{ts}",
        "slug": f"test-del-{ts}",
        "cnpj": gen_cnpj(),
        "admin_name": "Admin Teste",
        "admin_email": f"admin.test.del.{ts}@example.com",
    }
    r = requests.post(f"{BASE_URL}/api/super-admin/tenants", json=payload, headers=sa_headers)
    assert r.status_code in (200, 201), f"Create tenant failed: {r.text}"
    data = r.json()
    tenant_id = data.get("id") or data.get("tenant_id")
    yield {"id": tenant_id, "slug": payload["slug"], "email": payload["admin_email"]}
    # cleanup if not deleted by test
    requests.delete(f"{BASE_URL}/api/super-admin/tenants/{tenant_id}", headers=sa_headers)


class TestResendInviteReturnsLink:
    """resend-invite must return invite_link"""

    def test_resend_invite_returns_invite_link(self, sa_headers, dummy_tenant):
        tenant_id = dummy_tenant["id"]
        r = requests.post(f"{BASE_URL}/api/super-admin/tenants/{tenant_id}/resend-invite", headers=sa_headers)
        assert r.status_code == 200, f"resend-invite failed: {r.text}"
        data = r.json()
        assert "invite_link" in data, f"invite_link missing in response: {data}"
        assert data["invite_link"].startswith("http"), f"invite_link not a URL: {data['invite_link']}"
        assert "ativar-conta" in data["invite_link"] or "token=" in data["invite_link"], \
            f"invite_link doesn't look like activation link: {data['invite_link']}"
        assert "invite_sent_to" in data
        assert "message" in data
        print(f"invite_link: {data['invite_link']}")


class TestDeleteTenant:
    """DELETE /api/super-admin/tenants/{id} cascade tests"""

    def test_delete_tenant_returns_success(self, sa_headers, dummy_tenant):
        tenant_id = dummy_tenant["id"]
        r = requests.delete(f"{BASE_URL}/api/super-admin/tenants/{tenant_id}", headers=sa_headers)
        assert r.status_code == 200, f"Delete failed: {r.text}"
        data = r.json()
        assert data.get("success") is True or data.get("message"), f"Unexpected response: {data}"

    def test_deleted_tenant_not_in_list(self, sa_headers, dummy_tenant):
        tenant_id = dummy_tenant["id"]
        r = requests.get(f"{BASE_URL}/api/super-admin/tenants", headers=sa_headers)
        assert r.status_code == 200
        ids = [t.get("id") for t in r.json()]
        assert tenant_id not in ids, "Deleted tenant still in list"

    def test_delete_nonexistent_tenant_returns_404(self, sa_headers):
        r = requests.delete(f"{BASE_URL}/api/super-admin/tenants/nonexistent-id-xyz", headers=sa_headers)
        assert r.status_code == 404, f"Expected 404, got {r.status_code}: {r.text}"
