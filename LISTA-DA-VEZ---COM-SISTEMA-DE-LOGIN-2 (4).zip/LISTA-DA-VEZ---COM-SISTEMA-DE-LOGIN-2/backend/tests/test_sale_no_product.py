"""
Tests for sale without product:
1. SALE sem produto cria registro em sales com gross_amount_cents correto
2. seller_name está preenchido no registro
3. NO_SALE não cria registro de venda

Cria seus próprios dados (loja, vendedor, motivo de perda) dinamicamente —
não depende de IDs fixos nem de dados pré-existentes no seed.
"""
import pytest
import requests
import os
import uuid

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")
TENANT = "demo"
RUN_ID = uuid.uuid4().hex[:8]
SELLER_EMAIL = f"audit_test_sale_{RUN_ID}@demo.com"
SELLER_PWD = "Admin@123456"


@pytest.fixture(scope="module")
def admin_hdrs():
    r = requests.post(f"{BASE_URL}/api/tenants/{TENANT}/auth/login",
                      json={"email": "admin@demo.com", "password": "Admin@123456"})
    assert r.status_code == 200, f"Admin login failed: {r.text}"
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


@pytest.fixture(scope="module")
def store_id(admin_hdrs):
    r = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/stores", headers=admin_hdrs)
    assert r.status_code == 200 and r.json(), f"No stores found: {r.text}"
    return r.json()[0]["id"]


@pytest.fixture(scope="module")
def loss_reason_id(admin_hdrs):
    r = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/motivos-perda/motivos", headers=admin_hdrs)
    if r.status_code == 200 and r.json():
        return r.json()[0]["id"]
    pytest.skip("Nenhum motivo de perda cadastrado no tenant demo")


@pytest.fixture(scope="module")
def seller_profile_id(admin_hdrs, store_id):
    """Cria um vendedor efêmero (AUDIT_TEST) só para esta suíte e remove ao final."""
    r = requests.post(f"{BASE_URL}/api/tenants/{TENANT}/sellers", headers=admin_hdrs, json={
        "name": f"AUDIT_TEST Vendedor {RUN_ID}", "email": SELLER_EMAIL, "password": SELLER_PWD,
        "store_id": store_id, "employee_code": f"AUDIT-{RUN_ID}",
    })
    assert r.status_code == 201, f"Falha ao criar vendedor de teste: {r.text}"
    seller_id = r.json()["id"]
    yield seller_id
    requests.patch(f"{BASE_URL}/api/tenants/{TENANT}/sellers/{seller_id}/status",
                   json={"new_status": "OFFLINE"}, headers=admin_hdrs)


@pytest.fixture(scope="module")
def seller_token(seller_profile_id):
    r = requests.post(f"{BASE_URL}/api/tenants/{TENANT}/auth/login",
                      json={"email": SELLER_EMAIL, "password": SELLER_PWD})
    assert r.status_code == 200, f"Seller login failed: {r.text}"
    return r.json()["access_token"]


def setup_seller_in_queue(admin_hdrs, seller_token, store_id, seller_profile_id):
    """Make seller WAITING_IN_QUEUE, return attendance_id"""
    seller_hdrs = {"Authorization": f"Bearer {seller_token}"}

    # Leave queue if already there (idempotent)
    requests.post(f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/queue/leave",
                  json={"seller_id": seller_profile_id}, headers=seller_hdrs)

    # Set AVAILABLE
    requests.patch(f"{BASE_URL}/api/tenants/{TENANT}/sellers/{seller_profile_id}/status",
                   json={"new_status": "AVAILABLE"}, headers=seller_hdrs)

    # Join queue
    jr = requests.post(f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/queue/join",
                       json={"seller_id": seller_profile_id}, headers=seller_hdrs)
    assert jr.status_code in [200, 201], f"Join queue failed: {jr.text}"

    # Start attendance (admin)
    sar = requests.post(f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/queue/start-attendance",
                        json={"seller_id": seller_profile_id}, headers=admin_hdrs)
    assert sar.status_code in [200, 201], f"Start attendance failed: {sar.text}"
    att_id = sar.json().get("attendance", {}).get("id")
    assert att_id, f"No attendance id: {sar.json()}"
    return att_id


def finish_attendance(admin_hdrs, store_id, att_id, result, sale_amount_cents=None, loss_reason_id=None):
    payload = {"attendance_id": att_id, "result": result}
    if sale_amount_cents is not None:
        payload["sale_amount_cents"] = sale_amount_cents
    if loss_reason_id:
        payload["loss_reason_id"] = loss_reason_id
    r = requests.post(f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/queue/finish-attendance",
                      json=payload, headers=admin_hdrs)
    return r


def get_latest_sale(admin_hdrs):
    r = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/sales", headers=admin_hdrs)
    assert r.status_code == 200
    data = r.json()
    items = data.get("items", data) if isinstance(data, dict) else data
    return items[0] if items else None


# ── Tests ─────────────────────────────────────────────────────────────────────

class TestSaleNoProduct:
    def test_sale_without_product_creates_record(self, admin_hdrs, seller_token, store_id, seller_profile_id):
        """SALE sem produto deve criar registro de venda com attendance_id"""
        att_id = setup_seller_in_queue(admin_hdrs, seller_token, store_id, seller_profile_id)
        print(f"att_id: {att_id}")

        r = finish_attendance(admin_hdrs, store_id, att_id, "SALE", 5000)
        assert r.status_code in [200, 201], f"Finish failed: {r.text}"
        result = r.json().get("attendance", {}).get("result")
        assert result == "SALE", f"Expected SALE, got {result}"

        # Verify sale in DB via attendance_id
        latest = get_latest_sale(admin_hdrs)
        assert latest is not None, "No sales found"
        assert latest.get("attendance_id") == att_id, \
            f"Sale not linked to attendance. attendance_id={latest.get('attendance_id')}, expected={att_id}"
        print(f"PASS: Sale created for attendance {att_id}, gross={latest.get('gross_amount_cents')}")

    def test_sale_gross_amount_correct(self, admin_hdrs, seller_token, store_id, seller_profile_id):
        """gross_amount_cents deve ser 7500 quando sale_amount_cents=7500 sem produto"""
        att_id = setup_seller_in_queue(admin_hdrs, seller_token, store_id, seller_profile_id)

        r = finish_attendance(admin_hdrs, store_id, att_id, "SALE", 7500)
        assert r.status_code in [200, 201], f"Finish failed: {r.text}"

        latest = get_latest_sale(admin_hdrs)
        assert latest is not None
        assert latest.get("attendance_id") == att_id
        gross = latest.get("gross_amount_cents")
        net = latest.get("net_amount_cents")
        assert gross == 7500 or net == 7500, f"Amount incorrect. gross={gross} net={net}"
        print(f"PASS: gross={gross}, net={net}")

    def test_seller_name_in_sale(self, admin_hdrs, seller_token, store_id, seller_profile_id):
        """seller_name deve estar preenchido no registro de venda"""
        att_id = setup_seller_in_queue(admin_hdrs, seller_token, store_id, seller_profile_id)

        r = finish_attendance(admin_hdrs, store_id, att_id, "SALE", 3000)
        assert r.status_code in [200, 201], f"Finish failed: {r.text}"

        latest = get_latest_sale(admin_hdrs)
        assert latest is not None
        assert latest.get("attendance_id") == att_id
        seller_name = latest.get("seller_name") or (latest.get("seller") or {}).get("name", "")
        assert seller_name, f"seller_name not filled: {latest}"
        print(f"PASS: seller_name='{seller_name}'")


class TestNoSaleNoRecord:
    def test_no_sale_does_not_create_record(self, admin_hdrs, seller_token, store_id, seller_profile_id, loss_reason_id):
        """NO_SALE não deve criar registro de venda"""
        att_id = setup_seller_in_queue(admin_hdrs, seller_token, store_id, seller_profile_id)

        r = finish_attendance(admin_hdrs, store_id, att_id, "NO_SALE", loss_reason_id=loss_reason_id)
        assert r.status_code in [200, 201], f"Finish failed: {r.text}"

        # Check latest sale is NOT this attendance
        latest = get_latest_sale(admin_hdrs)
        if latest:
            assert latest.get("attendance_id") != att_id, \
                f"NO_SALE created a sale record for attendance {att_id}!"
        print("PASS: NO_SALE did not create a sale record")
