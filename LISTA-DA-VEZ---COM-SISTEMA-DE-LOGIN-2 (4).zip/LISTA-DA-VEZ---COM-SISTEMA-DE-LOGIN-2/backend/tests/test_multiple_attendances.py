"""Regressões de Múltiplos Atendimentos."""
import asyncio
import os
import uuid

import pytest
import requests
from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient


load_dotenv("/app/backend/.env")
BASE_URL = os.environ.get("REACT_APP_BACKEND_URL")
TENANT = "demo"


@pytest.fixture(scope="module")
def auth():
    if not BASE_URL:
        pytest.skip("REACT_APP_BACKEND_URL não definido")
    res = requests.post(f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT}/auth/login", json={"email": "admin@demo.com", "password": "Admin@123456"}, timeout=20)
    assert res.status_code == 200, res.text
    return {"Authorization": f"Bearer {res.json()['access_token']}"}


async def _ctx(email="joao@demo.com"):
    client = AsyncIOMotorClient(os.environ["MONGO_URL"])
    db = client[os.environ["DB_NAME"]]
    tenant = await db.tenants.find_one({"slug": TENANT})
    store = await db.stores.find_one({"tenant_id": tenant["id"]})
    queue = await db.queues.find_one({"tenant_id": tenant["id"], "store_id": store["id"], "is_default": True})
    user = await db.users.find_one({"email": email})
    seller = await db.seller_profiles.find_one({"tenant_id": tenant["id"], "user_id": user["id"]})
    grupo = await db.grupos_motivos_perda.find_one({"empresa_id": tenant["id"], "nome": "Roupa"})
    sub = await db.subgrupos_motivos_perda.find_one({"empresa_id": tenant["id"], "grupo_motivo_perda_id": grupo["identificador"], "nome": "Calça"}) if grupo else None
    motivo = await db.motivos_perda.find_one({"empresa_id": tenant["id"], "subgrupo_motivo_perda_id": sub["identificador"], "nome": "Faltou tamanho"}) if sub else None
    await db.attendances.update_many({"tenant_id": tenant["id"], "seller_id": seller["id"], "status": "IN_PROGRESS"}, {"$set": {"status": "CANCELLED", "notes": "Limpeza teste múltiplos"}})
    await db.queue_entries.delete_many({"tenant_id": tenant["id"], "queue_id": queue["id"], "seller_id": seller["id"]})
    await db.seller_profiles.update_one({"id": seller["id"]}, {"$set": {"current_status": "AVAILABLE", "em_atividade_operacional": False, "jornada_encerrada": False, "motivo_saida": None}})
    client.close()
    return tenant, store, queue, seller, grupo, sub, motivo


async def _fetch_batch(tenant_id, batch_id):
    client = AsyncIOMotorClient(os.environ["MONGO_URL"])
    db = client[os.environ["DB_NAME"]]
    attendances = await db.attendances.find({"tenant_id": tenant_id, "multiple_batch_id": batch_id}, {"_id": 0}).to_list(10)
    sales = await db.sales.find({"tenant_id": tenant_id, "multiple_batch_id": batch_id}, {"_id": 0}).to_list(10)
    client.close()
    return attendances, sales


async def _cancel_attendance(attendance_id):
    client = AsyncIOMotorClient(os.environ["MONGO_URL"])
    db = client[os.environ["DB_NAME"]]
    await db.attendances.update_one({"id": attendance_id}, {"$set": {"status": "CANCELLED"}})
    client.close()


def _start_attendance(auth, store_id, queue_id, seller_id):
    requests.post(f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT}/stores/{store_id}/queue/join", headers=auth, json={"queue_id": queue_id, "seller_id": seller_id}, timeout=20)
    start = requests.post(f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT}/stores/{store_id}/queue/start-attendance", headers=auth, json={"queue_id": queue_id, "seller_id": seller_id, "customer_name": "Cliente lote"}, timeout=30)
    assert start.status_code == 200, start.text
    return start.json()["attendance"]


def test_required_example_5_clients_3_sales_600_9_products(auth):
    tenant, store, queue, seller, grupo, sub, motivo = asyncio.run(_ctx("joao@demo.com"))
    att = _start_attendance(auth, store["id"], queue["id"], seller["id"])
    payload = {
        "attendance_id": att["id"], "mode": "AGGREGATED", "total_customers": 5,
        "successes": 3, "no_sales": 2, "total_amount_cents": 60000,
        "total_product_quantity": 9, "notes": "Cenário obrigatório",
        "grupo_motivo_perda_id": grupo["identificador"], "subgrupo_motivo_perda_id": sub["identificador"],
        "motivo_perda_id": motivo["identificador"], "descricao_complementar": "Teste",
    }
    key = f"multi-test-{uuid.uuid4()}"
    res = requests.post(f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT}/stores/{store['id']}/queue/finish-multiple-attendances", headers={**auth, "Idempotency-Key": key}, json=payload, timeout=60)
    assert res.status_code == 200, res.text
    batch_id = res.json()["batch"]["id"]
    attendances, sales = asyncio.run(_fetch_batch(tenant["id"], batch_id))
    assert len(attendances) == 5
    assert sum(1 for a in attendances if a["result"] == "SALE") == 3
    assert sum(1 for a in attendances if a["result"] == "NO_SALE") == 2
    assert len(sales) == 3
    assert sum(s["net_amount_cents"] for s in sales) == 60000
    assert sum(s.get("item_count") or 0 for s in sales) == 9
    assert round(sum(s.get("item_count") or 0 for s in sales) / len(attendances), 1) == 1.8
    replay = requests.post(f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT}/stores/{store['id']}/queue/finish-multiple-attendances", headers={**auth, "Idempotency-Key": key}, json=payload, timeout=60)
    assert replay.status_code == 200, replay.text


def test_multiple_aggregate_validation(auth):
    tenant, store, queue, seller, grupo, sub, motivo = asyncio.run(_ctx("carlos@demo.com"))
    att = _start_attendance(auth, store["id"], queue["id"], seller["id"])
    res = requests.post(f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT}/stores/{store['id']}/queue/finish-multiple-attendances", headers={**auth, "Idempotency-Key": f"multi-invalid-{uuid.uuid4()}"}, json={"attendance_id": att["id"], "mode": "AGGREGATED", "total_customers": 5, "successes": 4, "no_sales": 2, "total_amount_cents": 0, "total_product_quantity": 0}, timeout=30)
    assert res.status_code == 400, res.text
    asyncio.run(_cancel_attendance(att["id"]))