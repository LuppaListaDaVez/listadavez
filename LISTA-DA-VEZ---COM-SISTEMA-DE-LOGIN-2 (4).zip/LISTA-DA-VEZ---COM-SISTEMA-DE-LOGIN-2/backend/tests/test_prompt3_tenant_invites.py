"""Testes — Prompt 3: Convite de funcionários (TENANT_USER) + seller_profile.

Cobre:
- POST /tenants/{slug}/users/invite cria convite TENANT_USER
- REGIONAL_MANAGER não pode convidar TENANT_ADMIN (403)
- REGIONAL_MANAGER não pode convidar para filial fora do seu escopo (403)
- POST /invites/{token}/accept para TENANT_USER: cria User + Membership
- Aceite de convite SELLER cria seller_profile e get_accessible_store_ids retorna filial certa
- Aceite de convite REGIONAL_MANAGER all_stores=True → store_ids=[] + can_access_store True
- GET /tenants/{slug}/users/invites lista convites pendentes (sem hash)
- POST /tenants/{slug}/users/invite/{id}/resend revoga e reenvia
- Regressão: POST /tenants/{slug}/users (old direct endpoint) bloqueado em produção
"""
import sys, os, asyncio, hashlib, secrets
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

# Carregar .env ANTES de qualquer import de módulo backend (dependem de MONGO_URL etc.)
from dotenv import load_dotenv
load_dotenv(os.path.join(os.path.dirname(os.path.dirname(__file__)), ".env"))

import pytest
import httpx
from datetime import datetime, timezone, timedelta
from pymongo import MongoClient

BASE = "http://localhost:8001/api"
DEMO_SLUG = "demo"
DEMO_ADMIN = {"email": "admin@demo.com", "password": "Admin@123456"}
SUPER_CREDS = {"email": "admin@listadavez.com", "password": "Admin@123456"}


def _db():
    """Retorna DB síncrono (PyMongo) — sem conflito de event loop em testes."""
    MONGO_URL = os.environ.get("MONGO_URL", "mongodb://localhost:27017")
    DB_NAME = os.environ.get("DB_NAME", "test_database")
    return MongoClient(MONGO_URL)[DB_NAME]


@pytest.fixture(scope="module")
def client():
    with httpx.Client(base_url=BASE, timeout=20) as c:
        yield c


@pytest.fixture(scope="module")
def admin_token(client):
    r = client.post(f"/tenants/{DEMO_SLUG}/auth/login", json=DEMO_ADMIN)
    assert r.status_code == 200, f"Admin login falhou: {r.text}"
    return r.json()["access_token"]


@pytest.fixture(scope="module")
def super_token(client):
    r = client.post("/auth/login", json=SUPER_CREDS)
    assert r.status_code == 200
    return r.json()["access_token"]


def _headers(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


def _insert_test_invite_user(tenant_id: str, email: str, role: str,
                              store_ids: list, all_stores: bool = False) -> str:
    """Insere convite TENANT_USER com token conhecido no banco. Retorna token raw."""
    raw = secrets.token_urlsafe(48)
    token_hash = hashlib.sha256(raw.encode()).hexdigest()
    now = datetime.now(timezone.utc)
    db = _db()
    db.invite_tokens.insert_one({
        "id": "tu-" + raw[:8],
        "token_hash": token_hash,
        "tenant_id": tenant_id,
        "invite_type": "TENANT_USER",
        "email": email.lower(),
        "role": role,
        "store_ids": store_ids,
        "all_stores": all_stores,
        "created_by": "TEST",
        "created_at": now.isoformat(),
        "expires_at": now + timedelta(hours=72),
        "used_at": None,
        "revoked_at": None,
    })
    return raw


def _get_demo_tenant_and_store():
    """Retorna (tenant_id, store_id) do tenant demo."""
    db = _db()
    tenant = db.tenants.find_one({"slug": DEMO_SLUG})
    store = db.stores.find_one({"tenant_id": tenant["id"]})
    return tenant["id"], store["id"] if store else None


def _cleanup_test_users(*emails):
    db = _db()
    for email in emails:
        user = db.users.find_one({"email": email})
        if user:
            db.tenant_memberships.delete_many({"user_id": user["id"]})
            db.seller_profiles.delete_many({"user_id": user["id"]})
            db.users.delete_many({"email": email})


def _cleanup_invite_tokens_for_emails(*emails):
    db = _db()
    db.invite_tokens.delete_many({"email": {"$in": list(emails)}, "invite_type": "TENANT_USER"})


# ─────────────────────────────────────────────────────────────────────────────

class TestInviteUserEndpoint:

    def setup_method(self):
        redis_cleanup()

    def test_invite_criado_com_sucesso(self, client, admin_token):
        tenant_id, store_id = _get_demo_tenant_and_store()
        if not store_id:
            pytest.skip("Demo sem filial")
        email = "convidado-store@teste.com"
        _cleanup_test_users(email)
        _cleanup_invite_tokens_for_emails(email)

        r = client.post(
            f"/tenants/{DEMO_SLUG}/users/invite",
            json={"email": email, "role": "STORE_MANAGER", "store_ids": [store_id]},
            headers=_headers(admin_token),
        )
        assert r.status_code == 201, f"Esperava 201: {r.text}"
        body = r.json()
        assert body["invite_sent_to"] == email
        assert body["role"] == "STORE_MANAGER"

    def test_regional_manager_nao_pode_convidar_tenant_admin(self, client):
        """REGIONAL_MANAGER tentando convidar TENANT_ADMIN → 403."""
        # Criar regional manager no demo
        tenant_id, store_id = _get_demo_tenant_and_store()
        if not store_id:
            pytest.skip("Demo sem filial")

        regional_email = "regional-test@demo.com"
        _cleanup_test_users(regional_email)
        regional_token = _create_user_and_login(client, DEMO_SLUG, regional_email,
                                                "REGIONAL_MANAGER", [], all_stores=True)

        r = client.post(
            f"/tenants/{DEMO_SLUG}/users/invite",
            json={"email": "novo-admin@demo.com", "role": "TENANT_ADMIN"},
            headers=_headers(regional_token),
        )
        assert r.status_code == 403, f"Esperava 403: {r.text}"
        assert "TENANT_ADMIN" in r.text or "não pode" in r.text.lower()

    def test_regional_manager_nao_pode_convidar_para_filial_fora_do_escopo(self, client):
        """REGIONAL_MANAGER não pode convidar para filial fora do seu acesso."""
        tenant_id, store_id = _get_demo_tenant_and_store()
        if not store_id:
            pytest.skip("Demo sem filial")

        # Criar outra filial fora do escopo do regional manager
        db = _db()
        all_stores = list(db.stores.find({"tenant_id": tenant_id}))
        second_store = next((s["id"] for s in all_stores if s["id"] != store_id), None)
        if not second_store:
            pytest.skip("Demo tem apenas 1 filial — pular teste de filial fora do escopo")

        # Regional com acesso apenas a store_id (não second_store)
        regional_email = "regional-scoped@demo.com"
        _cleanup_test_users(regional_email)
        regional_token = _create_user_and_login(client, DEMO_SLUG, regional_email,
                                                "REGIONAL_MANAGER", [store_id])

        r = client.post(
            f"/tenants/{DEMO_SLUG}/users/invite",
            json={"email": "convidado-fora@demo.com", "role": "SELLER",
                  "store_ids": [second_store]},
            headers=_headers(regional_token),
        )
        assert r.status_code == 403, f"Esperava 403: {r.text}"


def _create_user_and_login(client, slug, email, role, store_ids, all_stores=False):
    """Helper: cria usuário diretamente no banco e faz login."""
    from security import hash_password
    password = "Teste@123456"

    db = _db()
    tenant = db.tenants.find_one({"slug": slug})
    user = db.users.find_one({"email": email})
    now = datetime.now(timezone.utc).isoformat()
    if not user:
        user = {
            "id": f"test-{email[:8]}",
            "name": "Test User",
            "email": email,
            "normalized_email": email,
            "token_version": 1,
            "phone": None,
            "password_hash": hash_password(password),
            "avatar_url": None,
            "is_super_admin": False,
            "status": "ACTIVE",
            "last_login_at": None,
            "created_at": now,
            "updated_at": now,
        }
        db.users.insert_one(user)
    existing = db.tenant_memberships.find_one({"tenant_id": tenant["id"], "user_id": user["id"]})
    if not existing:
        db.tenant_memberships.insert_one({
            "id": f"mem-{email[:8]}",
            "tenant_id": tenant["id"],
            "user_id": user["id"],
            "role": role,
            "store_ids": store_ids,
            "status": "ACTIVE",
            "created_at": now,
            "updated_at": now,
        })

    r = client.post(f"/tenants/{slug}/auth/login", json={"email": email, "password": password})
    assert r.status_code == 200, f"Login de {email} falhou: {r.text}"
    return r.json()["access_token"]


def redis_cleanup():
    try:
        import redis
        r = redis.Redis(host="127.0.0.1", port=6379)
        for key in r.keys("rl:INVITE_SEND:*"):
            r.delete(key)
    except Exception:
        pass


# ─────────────────────────────────────────────────────────────────────────────

class TestAcceptInviteTenantUser:

    def test_aceitar_convite_seller_cria_seller_profile(self, client):
        """Aceitar convite SELLER cria User + Membership + seller_profile."""
        tenant_id, store_id = _get_demo_tenant_and_store()
        if not store_id:
            pytest.skip("Demo sem filial")

        seller_email = "seller-invite@demo.com"
        _cleanup_test_users(seller_email)

        raw_token = _insert_test_invite_user(tenant_id, seller_email, "SELLER", [store_id])
        r = client.post(
            f"/invites/{raw_token}/accept",
            json={"token": raw_token, "name": "Vendedor Convidado", "password": "Senha@123456"},
        )
        assert r.status_code == 200, f"Aceite falhou: {r.text}"
        body = r.json()
        assert "access_token" in body, f"access_token ausente: {body}"

        # Verificar seller_profile criado
        db = _db()
        user = db.users.find_one({"email": seller_email})
        assert user, "User não criado"
        profile = db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": user["id"]})
        assert profile, "seller_profile não criado"
        assert profile["store_id"] == store_id
        assert profile["current_status"] == "OFFLINE"
        assert profile["status"] == "ACTIVE"
        # Membership do SELLER tem store_ids preenchido
        membership = db.tenant_memberships.find_one({"tenant_id": tenant_id, "user_id": user["id"]})
        assert membership, "membership não encontrada"

    def test_aceitar_convite_regional_all_stores_membership_store_ids_vazio(self, client):
        """REGIONAL_MANAGER all_stores=True → store_ids=[] na membership + can_access_store qualquer filial."""
        tenant_id, store_id = _get_demo_tenant_and_store()
        if not store_id:
            pytest.skip("Demo sem filial")

        regional_email = "regional-allstores@demo.com"
        _cleanup_test_users(regional_email)

        raw_token = _insert_test_invite_user(
            tenant_id, regional_email, "REGIONAL_MANAGER",
            store_ids=[], all_stores=True,
        )
        r = client.post(
            f"/invites/{raw_token}/accept",
            json={"token": raw_token, "name": "Regional All", "password": "Senha@123456"},
        )
        assert r.status_code == 200, f"Aceite falhou: {r.text}"

        db = _db()
        user = db.users.find_one({"email": regional_email})
        assert user
        membership = db.tenant_memberships.find_one(
            {"tenant_id": tenant_id, "user_id": user["id"]}
        )
        assert membership["store_ids"] == [], (
            f"store_ids deveria ser [] para all_stores=True, got: {membership['store_ids']}"
        )
        from permission_service import can_access_store
        # Com store_ids=[], REGIONAL_MANAGER acessa QUALQUER filial
        assert can_access_store(membership, store_id) is True

    def test_aceitar_convite_seller_get_accessible_store_ids_correto(self, client):
        """Seller tem acesso verificado via seller_profile (query direta no DB)."""
        tenant_id, store_id = _get_demo_tenant_and_store()
        if not store_id:
            pytest.skip("Demo sem filial")

        seller_email2 = "seller-access@demo.com"
        _cleanup_test_users(seller_email2)

        raw_token = _insert_test_invite_user(tenant_id, seller_email2, "SELLER", [store_id])
        r = client.post(
            f"/invites/{raw_token}/accept",
            json={"token": raw_token, "name": "Seller Access", "password": "Senha@123456"},
        )
        assert r.status_code == 200

        db = _db()
        user = db.users.find_one({"email": seller_email2})
        assert user, "User não encontrado"
        # Para SELLER, a filial acessível vem do seller_profile
        profile = db.seller_profiles.find_one(
            {"tenant_id": tenant_id, "user_id": user["id"]}
        )
        assert profile, "seller_profile não encontrado"
        assert profile["store_id"] == store_id, (
            f"seller_profile.store_id deveria ser {store_id}, got {profile['store_id']}"
        )


class TestListAndResendInvites:

    def test_list_pending_invites(self, client, admin_token):
        """GET /users/invites retorna convites pendentes sem expor o hash."""
        tenant_id, store_id = _get_demo_tenant_and_store()
        if not store_id:
            pytest.skip("Demo sem filial")

        # Criar convite de teste
        email = "list-invite@demo.com"
        _cleanup_invite_tokens_for_emails(email)
        _insert_test_invite_user(tenant_id, email, "STORE_MANAGER", [store_id])

        r = client.get(
            f"/tenants/{DEMO_SLUG}/users/invites",
            headers=_headers(admin_token),
        )
        assert r.status_code == 200, f"Listagem falhou: {r.text}"
        body = r.json()
        assert "invites" in body
        # Não deve expor token_hash
        for inv in body["invites"]:
            assert "token_hash" not in inv, "token_hash não deve ser exposto!"
        # Deve conter o convite de teste
        emails_in_list = [i["email"] for i in body["invites"]]
        assert email in emails_in_list

    def test_resend_invite(self, client, admin_token):
        """POST /users/invite/{id}/resend revoga antigo e cria novo convite."""
        tenant_id, store_id = _get_demo_tenant_and_store()
        if not store_id:
            pytest.skip("Demo sem filial")
        redis_cleanup()

        email = "resend-user@demo.com"
        _cleanup_test_users(email)
        _cleanup_invite_tokens_for_emails(email)

        # Criar convite via API
        r_create = client.post(
            f"/tenants/{DEMO_SLUG}/users/invite",
            json={"email": email, "role": "SELLER", "store_ids": [store_id]},
            headers=_headers(admin_token),
        )
        assert r_create.status_code == 201

        # Obter o invite_id do convite criado
        db = _db()
        invites = list(db.invite_tokens.find(
            {"tenant_id": tenant_id, "email": email, "invite_type": "TENANT_USER"}
        ).sort("created_at", -1))
        assert invites, "Convite não encontrado"
        invite = invites[0]
        invite_id = invite["id"]
        original_hash = invite["token_hash"]

        r_resend = client.post(
            f"/tenants/{DEMO_SLUG}/users/invite/{invite_id}/resend",
            headers=_headers(admin_token),
        )
        assert r_resend.status_code == 200, f"Resend falhou: {r_resend.text}"
        assert "reenviado" in r_resend.json()["message"].lower()

        db = _db()
        old = db.invite_tokens.find_one({"token_hash": original_hash})
        new_inv = db.invite_tokens.find_one(
            {"tenant_id": tenant_id, "email": email, "revoked_at": None,
             "invite_type": "TENANT_USER"}
        )
        assert old.get("revoked_at") is not None, "Convite antigo deveria estar revogado"
        assert new_inv is not None, "Novo convite não encontrado"
        assert new_inv["token_hash"] != original_hash


class TestOldEndpointBlocking:

    def test_old_create_user_blocked_in_production(self, client, admin_token):
        """POST /users antigo é bloqueado em ENVIRONMENT=production."""
        # Não setamos ENVIRONMENT=production no ambiente de testes — apenas verificamos que
        # o endpoint ainda funciona (não-produção) ou é bloqueado (produção).
        # Como estamos em teste, esperamos que funcione OU retorne 410 (se forçado via env).
        env = os.environ.get("ENVIRONMENT", "development")
        if env == "production":
            r = client.post(
                f"/tenants/{DEMO_SLUG}/users",
                json={"name": "Test", "email": "test-old@demo.com",
                      "password": "Teste@123", "role": "SELLER",
                      "store_ids": []},
                headers=_headers(admin_token),
            )
            assert r.status_code == 410, f"Em produção deveria ser 410, got {r.status_code}"
        else:
            # Em dev/test: endpoint ainda acessível (compatibilidade seed)
            r = client.post(
                f"/tenants/{DEMO_SLUG}/users",
                json={"name": "Test", "email": "test-old@demo.com",
                      "password": "Teste@123", "role": "SELLER",
                      "store_ids": []},
                headers=_headers(admin_token),
            )
            assert r.status_code in (200, 201, 409), (
                f"Em dev deveria funcionar, got {r.status_code}: {r.text}"
            )
