"""Prompt 21 — regressões de múltiplos atendimentos (AGGREGATED/DETAILED)."""
import os
import uuid
from datetime import datetime

import pytest
import requests
from dotenv import load_dotenv
from pymongo import MongoClient


load_dotenv("/app/backend/.env")
load_dotenv("/app/frontend/.env")

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL")
TENANT = "demo"


def _base_url() -> str:
    if not BASE_URL:
        pytest.skip("REACT_APP_BACKEND_URL não definido")
    return BASE_URL.rstrip("/")


def _api(path: str) -> str:
    return f"{_base_url()}/api{path}"


def _db():
    client = MongoClient(os.environ["MONGO_URL"])
    return client, client[os.environ["DB_NAME"]]


@pytest.fixture(scope="module")
def auth_headers():
    res = requests.post(
        _api(f"/tenants/{TENANT}/auth/login"),
        json={"email": "admin@demo.com", "password": "Admin@123456"},
        timeout=25,
    )
    assert res.status_code == 200, res.text
    return {"Authorization": f"Bearer {res.json()['access_token']}"}


def _ctx(db):
    tenant = db.tenants.find_one({"slug": TENANT}, {"_id": 0})
    assert tenant, "Tenant demo não encontrado"
    store = db.stores.find_one({"tenant_id": tenant["id"]}, {"_id": 0})
    assert store, "Store demo não encontrada"
    queue = db.queues.find_one({"tenant_id": tenant["id"], "store_id": store["id"], "is_default": True}, {"_id": 0})
    assert queue, "Fila padrão não encontrada"
    return tenant, store, queue


def _seller_by_email(db, tenant_id: str, email: str):
    user = db.users.find_one({"email": email}, {"_id": 0})
    assert user, f"Usuário {email} não encontrado"
    seller = db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": user["id"]}, {"_id": 0})
    assert seller, f"Seller profile de {email} não encontrado"
    return seller


def _first_loss_combo(db, tenant_id: str):
    grupo = db.grupos_motivos_perda.find_one({"empresa_id": tenant_id, "ativo": True}, {"_id": 0})
    if not grupo:
        return None
    sub = db.subgrupos_motivos_perda.find_one(
        {"empresa_id": tenant_id, "grupo_motivo_perda_id": grupo["identificador"], "ativo": True}, {"_id": 0}
    )
    if not sub:
        return None
    motivo = db.motivos_perda.find_one(
        {"empresa_id": tenant_id, "subgrupo_motivo_perda_id": sub["identificador"], "ativo": True}, {"_id": 0}
    )
    if not motivo:
        return None
    return {
        "grupo_motivo_perda_id": grupo["identificador"],
        "subgrupo_motivo_perda_id": sub["identificador"],
        "motivo_perda_id": motivo["identificador"],
        "descricao_complementar": "Teste automático Prompt 21",
    }


def _cleanup_seller_state(db, tenant_id: str, queue_id: str, seller_id: str):
    db.attendances.update_many(
        {"tenant_id": tenant_id, "seller_id": seller_id, "status": "IN_PROGRESS"},
        {"$set": {"status": "CANCELLED", "notes": "Cleanup teste múltiplos"}},
    )
    db.queue_entries.delete_many({"tenant_id": tenant_id, "queue_id": queue_id, "seller_id": seller_id})
    db.seller_profiles.update_one(
        {"tenant_id": tenant_id, "id": seller_id},
        {"$set": {"current_status": "AVAILABLE", "em_atividade_operacional": False, "jornada_encerrada": False, "motivo_saida": None}},
    )


def _start_attendance(headers: dict, store_id: str, queue_id: str, seller_id: str) -> dict:
    requests.post(_api(f"/tenants/{TENANT}/stores/{store_id}/queue/join"), headers=headers, json={"queue_id": queue_id, "seller_id": seller_id}, timeout=25)
    start = requests.post(
        _api(f"/tenants/{TENANT}/stores/{store_id}/queue/start-attendance"),
        headers=headers,
        json={"queue_id": queue_id, "seller_id": seller_id, "customer_name": "Cliente Prompt21"},
        timeout=40,
    )
    assert start.status_code == 200, start.text
    return start.json()["attendance"]


def _today() -> str:
    return datetime.utcnow().strftime("%Y-%m-%d")


# API happy path AGGREGATED + idempotência + fila sem duplicidade
def test_multiple_aggregated_required_scenario_and_idempotency(auth_headers):
    client, db = _db()
    try:
        tenant, store, queue = _ctx(db)
        seller = _seller_by_email(db, tenant["id"], "joao@demo.com")
        _cleanup_seller_state(db, tenant["id"], queue["id"], seller["id"])
        loss_combo = _first_loss_combo(db, tenant["id"])
        if not loss_combo:
            pytest.skip("Sem hierarquia ativa de motivo de perda")

        first = _start_attendance(auth_headers, store["id"], queue["id"], seller["id"])
        idem_key = f"multi-required-{uuid.uuid4()}"
        payload = {
            "attendance_id": first["id"], "mode": "AGGREGATED", "total_customers": 5,
            "successes": 3, "no_sales": 2, "total_amount_cents": 60000,
            "total_product_quantity": 9, "notes": "Cenário obrigatório 5/3/2", **loss_combo,
        }
        res = requests.post(_api(f"/tenants/{TENANT}/stores/{store['id']}/queue/finish-multiple-attendances"), headers={**auth_headers, "Idempotency-Key": idem_key}, json=payload, timeout=70)
        assert res.status_code == 200, res.text
        body = res.json()
        batch_id = body["batch"]["id"]
        assert body["batch"]["status"] == "COMMITTED"

        replay = requests.post(_api(f"/tenants/{TENANT}/stores/{store['id']}/queue/finish-multiple-attendances"), headers={**auth_headers, "Idempotency-Key": idem_key}, json=payload, timeout=70)
        assert replay.status_code == 200, replay.text
        assert replay.json()["batch"]["id"] == batch_id

        docs = list(db.attendances.find({"tenant_id": tenant["id"], "multiple_batch_id": batch_id}, {"_id": 0}))
        sales = list(db.sales.find({"tenant_id": tenant["id"], "multiple_batch_id": batch_id}, {"_id": 0}))
        assert len(docs) == 5
        assert sum(1 for a in docs if a.get("result") == "SALE") == 3
        assert sum(1 for a in docs if a.get("result") == "NO_SALE") == 2
        assert len(sales) == 3
        assert sum(int(s.get("net_amount_cents") or 0) for s in sales) == 60000
        assert sum(int(s.get("item_count") or 0) for s in sales) == 9
        assert round(9 / 5, 1) == 1.8

        first_ids = [a["id"] for a in docs if a.get("multiple_sequence") == 1]
        assert first_ids == [first["id"]]
        assert len([a for a in docs if a["id"] == first["id"]]) == 1

        assert all(a.get("allocation_mode") == "AGGREGATED" for a in docs)
        assert all(a.get("allocation_method") == "EQUAL_WITH_REMAINDER" for a in docs)
        assert all(a.get("is_estimated_allocation") is True for a in docs)
        assert all(s.get("allocation_mode") == "AGGREGATED" for s in sales)
        assert all(s.get("allocation_method") == "EQUAL_WITH_REMAINDER" for s in sales)
        assert all(s.get("is_estimated_allocation") is True for s in sales)

        waiting_rows = list(db.queue_entries.find({"tenant_id": tenant["id"], "queue_id": queue["id"], "status": "WAITING"}, {"_id": 0}))
        seller_waiting = [q for q in waiting_rows if q.get("seller_id") == seller["id"]]
        assert len(seller_waiting) == 1
        positions = [q.get("position") for q in waiting_rows if q.get("position") is not None]
        assert len(positions) == len(set(positions))
    finally:
        client.close()


# API happy path DETAILED + linhas individuais
def test_multiple_detailed_mode_creates_exact_rows(auth_headers):
    client, db = _db()
    try:
        tenant, store, queue = _ctx(db)
        seller = _seller_by_email(db, tenant["id"], "carlos@demo.com")
        _cleanup_seller_state(db, tenant["id"], queue["id"], seller["id"])
        loss_combo = _first_loss_combo(db, tenant["id"])
        if not loss_combo:
            pytest.skip("Sem hierarquia ativa de motivo de perda")

        first = _start_attendance(auth_headers, store["id"], queue["id"], seller["id"])
        payload = {
            "attendance_id": first["id"],
            "mode": "DETAILED",
            "rows": [
                {"result": "SALE", "sale_amount_cents": 10000, "product_quantity": 2, "notes": "linha 1"},
                {"result": "NO_SALE", "sale_amount_cents": 0, "product_quantity": 0, "notes": "linha 2"},
                {"result": "SALE", "sale_amount_cents": 30000, "product_quantity": 4, "notes": "linha 3"},
                {"result": "NO_SALE", "sale_amount_cents": 0, "product_quantity": 0, "notes": "linha 4"},
            ],
            **loss_combo,
        }
        res = requests.post(_api(f"/tenants/{TENANT}/stores/{store['id']}/queue/finish-multiple-attendances"), headers={**auth_headers, "Idempotency-Key": f"multi-detailed-{uuid.uuid4()}"}, json=payload, timeout=70)
        assert res.status_code == 200, res.text
        batch_id = res.json()["batch"]["id"]

        docs = list(db.attendances.find({"tenant_id": tenant["id"], "multiple_batch_id": batch_id}, {"_id": 0}))
        sales = list(db.sales.find({"tenant_id": tenant["id"], "multiple_batch_id": batch_id}, {"_id": 0}))
        assert len(docs) == 4
        assert len(sales) == 2
        assert sum(int(s.get("net_amount_cents") or 0) for s in sales) == 40000
        assert sum(int(s.get("item_count") or 0) for s in sales) == 6
        assert all(a.get("allocation_mode") == "DETAILED" for a in docs)
        assert all(a.get("allocation_method") == "INDIVIDUAL" for a in docs)
        assert all(a.get("is_estimated_allocation") is False for a in docs)
        no_sales = [a for a in docs if a.get("result") == "NO_SALE"]
        assert all((a.get("sale_amount_cents") in (None, 0)) for a in no_sales)
        assert all((a.get("product_quantity") in (None, 0)) for a in no_sales)
    finally:
        client.close()


# Validações de payload e limites
@pytest.mark.parametrize(
    "payload_patch,expected_status",
    [
        ({"total_customers": 51, "successes": 30, "no_sales": 21}, 400),
        ({"total_customers": 0, "successes": 0, "no_sales": 0}, 400),
        ({"total_customers": 5, "successes": 4, "no_sales": 2}, 400),
        ({"total_customers": 5, "successes": -1, "no_sales": 6}, 400),
        ({"total_customers": 5, "successes": 0, "no_sales": 5, "total_amount_cents": 100, "total_product_quantity": 1}, 400),
    ],
)
def test_multiple_aggregated_validations(auth_headers, payload_patch, expected_status):
    client, db = _db()
    try:
        tenant, store, queue = _ctx(db)
        seller = _seller_by_email(db, tenant["id"], "joao@demo.com")
        _cleanup_seller_state(db, tenant["id"], queue["id"], seller["id"])
        first = _start_attendance(auth_headers, store["id"], queue["id"], seller["id"])
        payload = {
            "attendance_id": first["id"], "mode": "AGGREGATED", "total_customers": 5,
            "successes": 3, "no_sales": 2, "total_amount_cents": 0, "total_product_quantity": 0,
        }
        payload.update(payload_patch)
        res = requests.post(_api(f"/tenants/{TENANT}/stores/{store['id']}/queue/finish-multiple-attendances"), headers={**auth_headers, "Idempotency-Key": f"multi-invalid-{uuid.uuid4()}"}, json=payload, timeout=40)
        assert res.status_code == expected_status, res.text
        db.attendances.update_one({"id": first["id"]}, {"$set": {"status": "CANCELLED"}})
    finally:
        client.close()


# Validação: produtos devem ser inteiros
def test_multiple_detailed_product_quantity_must_be_integer(auth_headers):
    client, db = _db()
    try:
        tenant, store, queue = _ctx(db)
        seller = _seller_by_email(db, tenant["id"], "carlos@demo.com")
        _cleanup_seller_state(db, tenant["id"], queue["id"], seller["id"])
        first = _start_attendance(auth_headers, store["id"], queue["id"], seller["id"])
        res = requests.post(
            _api(f"/tenants/{TENANT}/stores/{store['id']}/queue/finish-multiple-attendances"),
            headers={**auth_headers, "Idempotency-Key": f"multi-float-{uuid.uuid4()}"},
            json={"attendance_id": first["id"], "mode": "DETAILED", "rows": [{"result": "SALE", "sale_amount_cents": 1000, "product_quantity": 1.5}]},
            timeout=35,
        )
        assert res.status_code in (400, 422), res.text
        db.attendances.update_one({"id": first["id"]}, {"$set": {"status": "CANCELLED"}})
    finally:
        client.close()


# Regra: motivo comum obrigatório quando há não sucessos
def test_multiple_loss_reason_required_when_no_sales(auth_headers):
    cfg = requests.get(_api(f"/tenants/{TENANT}/motivos-perda/opcoes"), headers=auth_headers, timeout=25)
    assert cfg.status_code == 200, cfg.text
    if not cfg.json().get("hierarquia_ativa"):
        pytest.skip("Hierarquia de motivo de perda não ativa")

    client, db = _db()
    try:
        tenant, store, queue = _ctx(db)
        seller = _seller_by_email(db, tenant["id"], "joao@demo.com")
        _cleanup_seller_state(db, tenant["id"], queue["id"], seller["id"])
        first = _start_attendance(auth_headers, store["id"], queue["id"], seller["id"])
        res = requests.post(
            _api(f"/tenants/{TENANT}/stores/{store['id']}/queue/finish-multiple-attendances"),
            headers={**auth_headers, "Idempotency-Key": f"multi-no-loss-{uuid.uuid4()}"},
            json={"attendance_id": first["id"], "mode": "AGGREGATED", "total_customers": 2, "successes": 0, "no_sales": 2, "total_amount_cents": 0, "total_product_quantity": 0},
            timeout=35,
        )
        assert res.status_code == 400, res.text
        db.attendances.update_one({"id": first["id"]}, {"$set": {"status": "CANCELLED"}})
    finally:
        client.close()


# Escopo multi-tenant/store
def test_multiple_tenant_store_scope(auth_headers):
    client, db = _db()
    try:
        demo_tenant = db.tenants.find_one({"slug": "demo"}, {"_id": 0})
        demo_store = db.stores.find_one({"tenant_id": demo_tenant["id"]}, {"_id": 0})
        seller = _seller_by_email(db, demo_tenant["id"], "joao@demo.com")
        queue = db.queues.find_one({"tenant_id": demo_tenant["id"], "store_id": demo_store["id"], "is_default": True}, {"_id": 0})
        _cleanup_seller_state(db, demo_tenant["id"], queue["id"], seller["id"])
        first = _start_attendance(auth_headers, demo_store["id"], queue["id"], seller["id"])

        other_tenant = db.tenants.find_one({"slug": "demo-b"}, {"_id": 0})
        if not other_tenant:
            pytest.skip("Tenant demo-b não encontrado")
        other_store = db.stores.find_one({"tenant_id": other_tenant["id"]}, {"_id": 0})
        if not other_store:
            pytest.skip("Store demo-b não encontrada")

        res = requests.post(
            _api(f"/tenants/{TENANT}/stores/{other_store['id']}/queue/finish-multiple-attendances"),
            headers={**auth_headers, "Idempotency-Key": f"multi-scope-{uuid.uuid4()}"},
            json={"attendance_id": first["id"], "mode": "AGGREGATED", "total_customers": 1, "successes": 1, "no_sales": 0, "total_amount_cents": 100, "total_product_quantity": 1},
            timeout=30,
        )
        assert res.status_code in (403, 404), res.text
        db.attendances.update_one({"id": first["id"]}, {"$set": {"status": "CANCELLED"}})
    finally:
        client.close()


# Relatórios e rankings: oportunidades MULTIPLE + ITEMS_SOLD por item_count
def test_multiple_reports_and_ranking_item_count(auth_headers):
    client, db = _db()
    try:
        tenant, store, queue = _ctx(db)
        seller = _seller_by_email(db, tenant["id"], "carlos@demo.com")
        _cleanup_seller_state(db, tenant["id"], queue["id"], seller["id"])
        loss_combo = _first_loss_combo(db, tenant["id"])
        if not loss_combo:
            pytest.skip("Sem hierarquia ativa de motivo de perda")

        params = {"date_start": _today(), "date_end": _today(), "store_id": store["id"], "seller_id": seller["id"], "attendance_type": "MULTIPLE"}
        before_report = requests.get(_api(f"/tenants/{TENANT}/reports/opportunity-flow"), headers=auth_headers, params=params, timeout=60)
        assert before_report.status_code == 200, before_report.text
        before_opp = int(before_report.json().get("totals", {}).get("opportunities", 0))

        before_rank = requests.get(_api(f"/tenants/{TENANT}/rankings"), headers=auth_headers, params={"criteria": "ITEMS_SOLD", "store_id": store["id"], "period_start": _today(), "period_end": _today()}, timeout=60)
        assert before_rank.status_code == 200, before_rank.text
        before_items = 0
        for it in before_rank.json().get("items", []):
            if it.get("seller_id") == seller["id"]:
                before_items = int(it.get("value") or 0)
                break

        first = _start_attendance(auth_headers, store["id"], queue["id"], seller["id"])
        payload = {"attendance_id": first["id"], "mode": "AGGREGATED", "total_customers": 3, "successes": 2, "no_sales": 1, "total_amount_cents": 30000, "total_product_quantity": 7, **loss_combo}
        res = requests.post(_api(f"/tenants/{TENANT}/stores/{store['id']}/queue/finish-multiple-attendances"), headers={**auth_headers, "Idempotency-Key": f"multi-reports-{uuid.uuid4()}"}, json=payload, timeout=70)
        assert res.status_code == 200, res.text
        batch_id = res.json()["batch"]["id"]

        created_sales = list(db.sales.find({"tenant_id": tenant["id"], "multiple_batch_id": batch_id}, {"_id": 0}))
        sale_ids = [s["id"] for s in created_sales]
        assert len(created_sales) == 2
        sale_items_count = db.sale_items.count_documents({"tenant_id": tenant["id"], "sale_id": {"$in": sale_ids}})
        assert sale_items_count == 0
        assert sum(int(s.get("item_count") or 0) for s in created_sales) == 7

        after_report = requests.get(_api(f"/tenants/{TENANT}/reports/opportunity-flow"), headers=auth_headers, params=params, timeout=60)
        assert after_report.status_code == 200, after_report.text
        after_opp = int(after_report.json().get("totals", {}).get("opportunities", 0))
        assert after_opp - before_opp == 3

        after_rank = requests.get(_api(f"/tenants/{TENANT}/rankings"), headers=auth_headers, params={"criteria": "ITEMS_SOLD", "store_id": store["id"], "period_start": _today(), "period_end": _today()}, timeout=60)
        assert after_rank.status_code == 200, after_rank.text
        after_items = 0
        for it in after_rank.json().get("items", []):
            if it.get("seller_id") == seller["id"]:
                after_items = int(it.get("value") or 0)
                break
        assert after_items - before_items >= 7
    finally:
        client.close()