"""Reteste final do Atendimento por Preferência (prompt atual).

Módulos cobertos: queue start/finish preference + store settings preference_enabled.
"""

import os
import uuid

import pytest
import requests


BASE_URL = (os.environ.get("REACT_APP_BACKEND_URL") or "").rstrip("/")
TENANT = "demo"
ADMIN_EMAIL = "admin@demo.com"
CARLOS_EMAIL = "carlos@demo.com"
JOAO_EMAIL = "joao@demo.com"
PASSWORD = "Admin@123456"


def _h(token: str):
    return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}


def _queue_url(ctx: dict) -> str:
    return f"{BASE_URL}/api/tenants/{TENANT}/stores/{ctx['store_id']}/queue"


def _state(ctx: dict, token: str | None = None) -> dict:
    auth = token or ctx["admin_token"]
    resp = requests.get(
        _queue_url(ctx),
        headers=_h(auth),
        params={"queue_id": ctx["queue_id"]},
        timeout=30,
    )
    assert resp.status_code == 200, resp.text
    data = resp.json()
    assert isinstance(data.get("entries"), list)
    return data


def _all_sellers(state: dict) -> list[dict]:
    rows = []
    for section in ("entries", "available_sellers", "serving_sellers", "away_sellers"):
        rows.extend(state.get(section) or [])
    out = []
    seen = set()
    for row in rows:
        sid = row.get("seller_id") or row.get("id")
        if sid and sid not in seen:
            seen.add(sid)
            out.append({**row, "seller_id": sid})
    return out


def _find_seller_in_state(state: dict, seller_id: str):
    for section in ("entries", "available_sellers", "serving_sellers", "away_sellers"):
        for item in state.get(section) or []:
            if item.get("seller_id") == seller_id:
                return {**item, "_section": section}
    return None


def _cancel_if_serving(ctx: dict, seller_id: str):
    st = _state(ctx)
    for att in st.get("active_attendances") or []:
        if att.get("seller_id") == seller_id:
            cancel = requests.post(
                f"{BASE_URL}/api/tenants/{TENANT}/attendances/{att['id']}/cancel",
                headers=_h(ctx["admin_token"]),
                json={"reason": "TEST_cleanup_final_retest"},
                timeout=30,
            )
            assert cancel.status_code in (200, 409), cancel.text


def _ensure_waiting_not_paused(ctx: dict, seller_id: str):
    _cancel_if_serving(ctx, seller_id)
    for _ in range(8):
        st = _state(ctx)
        info = _find_seller_in_state(st, seller_id)
        assert info is not None
        section = info.get("_section")
        if section == "entries" and not info.get("em_atividade_operacional"):
            return
        if section == "entries" and info.get("em_atividade_operacional"):
            back = requests.post(
                f"{_queue_url(ctx)}/retornar-operacao",
                headers=_h(ctx["admin_token"]),
                json={"seller_id": seller_id},
                timeout=30,
            )
            assert back.status_code == 200, back.text
            continue
        if section == "available_sellers":
            join = requests.post(
                f"{_queue_url(ctx)}/join",
                headers=_h(ctx["admin_token"]),
                json={"queue_id": ctx["queue_id"], "seller_id": seller_id},
                timeout=30,
            )
            assert join.status_code in (200, 409), join.text
            continue
        if section == "away_sellers":
            if info.get("jornada_encerrada"):
                nova = requests.post(
                    f"{_queue_url(ctx)}/nova-jornada",
                    headers=_h(ctx["admin_token"]),
                    json={"seller_id": seller_id},
                    timeout=30,
                )
                assert nova.status_code == 200, nova.text
            else:
                voltar = requests.post(
                    f"{_queue_url(ctx)}/retornar-da-fora",
                    headers=_h(ctx["admin_token"]),
                    json={"seller_id": seller_id, "queue_id": ctx["queue_id"]},
                    timeout=30,
                )
                assert voltar.status_code in (200, 409), voltar.text
            continue
    final = _find_seller_in_state(_state(ctx), seller_id)
    assert final and final.get("_section") == "entries" and not final.get("em_atividade_operacional")


def _set_preference_enabled(ctx: dict, enabled: bool):
    settings_url = f"{BASE_URL}/api/tenants/{TENANT}/stores/{ctx['store_id']}/settings"
    resp = requests.put(
        settings_url,
        headers=_h(ctx["admin_token"]),
        json={"queue_settings": {"preference_enabled": enabled}},
        timeout=30,
    )
    assert resp.status_code == 200, resp.text
    assert resp.json().get("queue_settings", {}).get("preference_enabled") is enabled


def _force_seller_status(ctx: dict, seller_id: str, new_status: str):
    resp = requests.patch(
        f"{BASE_URL}/api/tenants/{TENANT}/sellers/{seller_id}/status",
        headers=_h(ctx["admin_token"]),
        json={"new_status": new_status, "reason": "TEST_force_inconsistency"},
        timeout=30,
    )
    assert resp.status_code == 200, resp.text
    data = resp.json()
    assert data.get("current_status") == new_status


def _start_preference_with_single_retry(ctx: dict, *, token: str, customer_name: str, seller_id: str | None = None):
    payload = {"queue_id": ctx["queue_id"], "customer_name": customer_name}
    if seller_id:
        payload["seller_id"] = seller_id

    for attempt in range(2):
        resp = requests.post(
            f"{_queue_url(ctx)}/start-preference-attendance",
            headers={**_h(token), "Idempotency-Key": f"final-start-{uuid.uuid4()}"},
            json=payload,
            timeout=30,
        )
        if resp.status_code == 200:
            return resp
        # Retry único para instabilidade de estado concorrente do ambiente de preview
        if attempt == 0 and resp.status_code == 409:
            _ensure_waiting_not_paused(ctx, ctx["carlos_seller_id"])
            continue
        return resp
    return resp


@pytest.fixture(scope="module")
def ctx():
    if not BASE_URL:
        pytest.skip("REACT_APP_BACKEND_URL não definido")

    admin_login = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT}/auth/login",
        json={"email": ADMIN_EMAIL, "password": PASSWORD},
        timeout=30,
    )
    assert admin_login.status_code == 200, admin_login.text
    admin_token = admin_login.json().get("access_token")
    assert admin_token

    carlos_login = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT}/auth/login",
        json={"email": CARLOS_EMAIL, "password": PASSWORD},
        timeout=30,
    )
    assert carlos_login.status_code == 200, carlos_login.text
    carlos_token = carlos_login.json().get("access_token")
    assert carlos_token

    stores = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/stores", headers=_h(admin_token), timeout=30)
    assert stores.status_code == 200, stores.text
    store_id = stores.json()[0]["id"]

    st = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/queue", headers=_h(admin_token), timeout=30)
    assert st.status_code == 200, st.text
    state = st.json()
    queue_id = state.get("queue", {}).get("id")
    assert queue_id

    sellers = _all_sellers(state)
    carlos = next((s for s in sellers if (s.get("email") or "").lower() == CARLOS_EMAIL), None)
    joao = next((s for s in sellers if (s.get("email") or "").lower() == JOAO_EMAIL), None)
    assert carlos and joao, "Carlos/João não encontrados no estado da fila"

    settings_url = f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/settings"
    settings = requests.get(settings_url, headers=_h(admin_token), timeout=30)
    assert settings.status_code == 200, settings.text
    original_enabled = (settings.json().get("queue_settings") or {}).get("preference_enabled", True)

    data = {
        "admin_token": admin_token,
        "carlos_token": carlos_token,
        "store_id": store_id,
        "queue_id": queue_id,
        "carlos_seller_id": carlos["seller_id"],
        "joao_seller_id": joao["seller_id"],
        "original_enabled": original_enabled,
    }

    _ensure_waiting_not_paused(data, data["carlos_seller_id"])
    _ensure_waiting_not_paused(data, data["joao_seller_id"])
    _set_preference_enabled(data, True)

    yield data

    _set_preference_enabled(data, original_enabled)
    _ensure_waiting_not_paused(data, data["carlos_seller_id"])
    _ensure_waiting_not_paused(data, data["joao_seller_id"])


def test_seller_start_preference_without_seller_id_uses_session_seller(ctx):
    """queue/start-preference: SELLER sem seller_id usa vendedor autenticado."""
    _ensure_waiting_not_paused(ctx, ctx["carlos_seller_id"])
    start = _start_preference_with_single_retry(
        ctx,
        token=ctx["carlos_token"],
        customer_name="Cliente Final Self",
    )
    assert start.status_code == 200, start.text
    att = start.json().get("attendance") or {}
    assert att.get("seller_id") == ctx["carlos_seller_id"]
    assert att.get("is_preference") is True

    finish = requests.post(
        f"{_queue_url(ctx)}/finish-attendance",
        headers={**_h(ctx["carlos_token"]), "Idempotency-Key": f"final-self-finish-{uuid.uuid4()}"},
        json={"attendance_id": att["id"], "result": "INVALID", "notes": "Final retest"},
        timeout=30,
    )
    assert finish.status_code == 200, finish.text
    assert finish.json().get("attendance", {}).get("preference_return_applied") is True


def test_seller_cannot_start_preference_for_other_seller(ctx):
    """queue/start-preference: SELLER com seller_id de outro vendedor retorna 403."""
    _ensure_waiting_not_paused(ctx, ctx["carlos_seller_id"])
    _ensure_waiting_not_paused(ctx, ctx["joao_seller_id"])
    other = requests.post(
        f"{_queue_url(ctx)}/start-preference-attendance",
        headers={**_h(ctx["carlos_token"]), "Idempotency-Key": f"final-other-{uuid.uuid4()}"},
        json={
            "queue_id": ctx["queue_id"],
            "seller_id": ctx["joao_seller_id"],
            "customer_name": "Cliente Outro",
        },
        timeout=30,
    )
    assert other.status_code == 403, other.text


def test_preference_disabled_blocks_backend_with_preference_disabled_error(ctx):
    """store-settings + queue/start-preference: preference_enabled=False bloqueia com PREFERENCE_DISABLED."""
    _set_preference_enabled(ctx, False)
    blocked = requests.post(
        f"{_queue_url(ctx)}/start-preference-attendance",
        headers={**_h(ctx["carlos_token"]), "Idempotency-Key": f"final-disabled-{uuid.uuid4()}"},
        json={"queue_id": ctx["queue_id"], "customer_name": "Cliente Bloqueado"},
        timeout=30,
    )
    assert blocked.status_code == 403, blocked.text
    detail = blocked.json().get("detail")
    assert isinstance(detail, dict)
    assert detail.get("error") == "PREFERENCE_DISABLED"
    _set_preference_enabled(ctx, True)


def test_finish_preference_returns_seller_once_without_duplicate_queue_entries(ctx):
    """queue/finish-attendance: retorno de preferência não duplica vendedor na fila."""
    _ensure_waiting_not_paused(ctx, ctx["carlos_seller_id"])
    start = _start_preference_with_single_retry(
        ctx,
        token=ctx["carlos_token"],
        customer_name="Cliente Sem Duplicar",
    )
    assert start.status_code == 200, start.text
    attendance_id = start.json().get("attendance", {}).get("id")
    assert attendance_id

    finish = requests.post(
        f"{_queue_url(ctx)}/finish-attendance",
        headers={**_h(ctx["carlos_token"]), "Idempotency-Key": f"final-dup-finish-{uuid.uuid4()}"},
        json={"attendance_id": attendance_id, "result": "INVALID", "notes": "Retorno único"},
        timeout=30,
    )
    assert finish.status_code == 200, finish.text
    finished = finish.json().get("attendance") or {}
    assert finished.get("preference_return_applied") is True
    assert finished.get("preference_final_position") is not None

    st = _state(ctx)
    entries = st.get("entries") or []
    seller_entries = [e for e in entries if e.get("seller_id") == ctx["carlos_seller_id"]]
    assert len(seller_entries) == 1
    active_for_carlos = [a for a in st.get("active_attendances") or [] if a.get("seller_id") == ctx["carlos_seller_id"]]
    assert len(active_for_carlos) == 0


def test_start_preference_normalizes_available_profile_with_waiting_entry_for_seller(ctx):
    """Inconsistência real: profile AVAILABLE + queue_entry WAITING deve normalizar e iniciar preferência."""
    _ensure_waiting_not_paused(ctx, ctx["carlos_seller_id"])
    _force_seller_status(ctx, ctx["carlos_seller_id"], "AVAILABLE")

    before = _state(ctx)
    in_entries = [e for e in (before.get("entries") or []) if e.get("seller_id") == ctx["carlos_seller_id"]]
    assert len(in_entries) == 1

    start = _start_preference_with_single_retry(
        ctx,
        token=ctx["carlos_token"],
        customer_name="Cliente Normalize Start",
    )
    assert start.status_code == 200, start.text
    att = start.json().get("attendance") or {}
    assert att.get("seller_id") == ctx["carlos_seller_id"]
    assert att.get("is_preference") is True

    finish = requests.post(
        f"{_queue_url(ctx)}/finish-attendance",
        headers={**_h(ctx["carlos_token"]), "Idempotency-Key": f"final-normalize-finish-{uuid.uuid4()}"},
        json={"attendance_id": att["id"], "result": "INVALID", "notes": "Finalize normalize"},
        timeout=30,
    )
    assert finish.status_code == 200, finish.text
    assert finish.json().get("attendance", {}).get("preference_return_applied") is True


def test_sair_da_fila_operacional_normalizes_available_profile_with_waiting_entry(ctx):
    """/queue/sair-da-fila com ATIVIDADE_OPERACIONAL deve funcionar com profile AVAILABLE + WAITING entry."""
    _ensure_waiting_not_paused(ctx, ctx["carlos_seller_id"])
    _force_seller_status(ctx, ctx["carlos_seller_id"], "AVAILABLE")

    before = _state(ctx)
    in_entries = [e for e in (before.get("entries") or []) if e.get("seller_id") == ctx["carlos_seller_id"]]
    assert len(in_entries) == 1

    sair = requests.post(
        f"{_queue_url(ctx)}/sair-da-fila",
        headers=_h(ctx["carlos_token"]),
        json={"seller_id": ctx["carlos_seller_id"], "motivo": "ATIVIDADE_OPERACIONAL", "queue_id": ctx["queue_id"]},
        timeout=30,
    )
    assert sair.status_code == 200, sair.text
    state = sair.json()
    entries = state.get("entries") or []
    target = [e for e in entries if e.get("seller_id") == ctx["carlos_seller_id"]]
    assert len(target) == 1
    assert target[0].get("em_atividade_operacional") is True

    back = requests.post(
        f"{_queue_url(ctx)}/retornar-operacao",
        headers=_h(ctx["carlos_token"]),
        json={"seller_id": ctx["carlos_seller_id"]},
        timeout=30,
    )
    assert back.status_code == 200, back.text
