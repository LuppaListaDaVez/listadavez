"""Testes — Prompt 1: Fundação (CNPJ, invite_tokens, InviteCreate).

Cobre:
- validar_cnpj: CNPJs válidos e inválidos
- normalizar_cnpj: remove máscara
- TenantCreate: CNPJ obrigatório, validação pelo dígito verificador
- Índice único de CNPJ no MongoDB (via API do super admin)
- InviteCreate: validação de store_ids por role

Para rodar:
    cd /app/backend
    pytest tests/test_prompt1_foundation.py -v
"""
import sys
import os
import pytest

# Adicionar backend ao path para imports diretos
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import httpx
from pydantic import ValidationError

from cnpj_utils import validar_cnpj, normalizar_cnpj
from models import TenantCreate, InviteCreate

BASE = "http://localhost:8001/api"
SUPER_CREDS = {"email": "admin@listadavez.com", "password": "Admin@123456"}

# ─────────────────────────────────────────────────────────────
# Fixtures
# ─────────────────────────────────────────────────────────────

@pytest.fixture(scope="module")
def client():
    with httpx.Client(base_url=BASE, timeout=15) as c:
        yield c


@pytest.fixture(scope="module")
def super_token(client):
    r = client.post("/auth/login", json=SUPER_CREDS)
    assert r.status_code == 200, f"Super admin login falhou: {r.text}"
    return r.json()["access_token"]


# ─────────────────────────────────────────────────────────────
# 1. Testes de validar_cnpj
# ─────────────────────────────────────────────────────────────

class TestValidarCNPJ:
    """Testa a função validar_cnpj diretamente."""

    # CNPJs válidos (calculados com dígito verificador correto)
    @pytest.mark.parametrize("cnpj", [
        "11.222.333/0001-81",   # formatado com máscara
        "11222333000181",        # sem máscara
        "45.997.418/0001-53",   # outro CNPJ real válido
        "45997418000153",
        "00.623.904/0001-73",
        "00623904000173",
    ])
    def test_cnpj_valido(self, cnpj):
        assert validar_cnpj(cnpj) is True, f"Esperava CNPJ válido: {cnpj}"

    # CNPJs inválidos
    @pytest.mark.parametrize("cnpj", [
        "11.222.333/0001-99",   # dígito verificador errado
        "00000000000000",        # todos zeros
        "11111111111111",        # todos iguais
        "12345678901234",        # sequência inválida
        "123456789012",          # menos de 14 dígitos
        "123456789012345",       # mais de 14 dígitos
        "",                      # vazio
        "abc.def.ghi/jklm-no",  # não numérico
    ])
    def test_cnpj_invalido(self, cnpj):
        assert validar_cnpj(cnpj) is False, f"Esperava CNPJ inválido: {cnpj}"


# ─────────────────────────────────────────────────────────────
# 2. Testes de normalizar_cnpj
# ─────────────────────────────────────────────────────────────

class TestNormalizarCNPJ:
    def test_remove_mascara(self):
        assert normalizar_cnpj("11.222.333/0001-81") == "11222333000181"

    def test_sem_mascara_intacto(self):
        assert normalizar_cnpj("11222333000181") == "11222333000181"

    def test_espacos_e_tracos(self):
        # "11 222 333 0001 81" → remove espaços → "11222333000181" (14 dígitos)
        assert normalizar_cnpj("11 222 333 0001 81") == "11222333000181"

    def test_vazio(self):
        assert normalizar_cnpj("") == ""

    def test_none_like_empty(self):
        # normalizar_cnpj recebe str — testar que não estoura com string vazia
        assert normalizar_cnpj("") == ""


# ─────────────────────────────────────────────────────────────
# 3. Testes de TenantCreate (CNPJ obrigatório e validado)
# ─────────────────────────────────────────────────────────────

class TestTenantCreateCNPJ:
    VALID_PAYLOAD = {
        "name": "Empresa Teste",
        "slug": "empresa-teste",
        "cnpj": "11.222.333/0001-81",
        "admin_email": "admin@empresa-teste.com",
        "admin_password": "Senha@123",
    }

    def test_cnpj_valido_aceito(self):
        m = TenantCreate(**self.VALID_PAYLOAD)
        assert m.cnpj == "11222333000181"  # normalizado para 14 dígitos

    def test_cnpj_normalizado_sem_mascara(self):
        payload = {**self.VALID_PAYLOAD, "cnpj": "11222333000181"}
        m = TenantCreate(**payload)
        assert m.cnpj == "11222333000181"

    def test_cnpj_invalido_rejeitado_422(self):
        with pytest.raises(ValidationError) as exc_info:
            TenantCreate(**{**self.VALID_PAYLOAD, "cnpj": "11.222.333/0001-99"})
        errors = exc_info.value.errors()
        assert any("cnpj" in str(e.get("loc", "")).lower() for e in errors)
        assert any("inválido" in str(e.get("msg", "")).lower() or
                   "invalid" in str(e.get("msg", "")).lower() for e in errors)

    def test_cnpj_obrigatorio(self):
        """CNPJ é obrigatório — deve falhar sem ele."""
        payload = {k: v for k, v in self.VALID_PAYLOAD.items() if k != "cnpj"}
        with pytest.raises(ValidationError) as exc_info:
            TenantCreate(**payload)
        errors = exc_info.value.errors()
        assert any("cnpj" in str(e.get("loc", "")).lower() for e in errors)

    def test_todos_zeros_rejeitado(self):
        with pytest.raises(ValidationError):
            TenantCreate(**{**self.VALID_PAYLOAD, "cnpj": "00000000000000"})

    def test_todos_iguais_rejeitado(self):
        with pytest.raises(ValidationError):
            TenantCreate(**{**self.VALID_PAYLOAD, "cnpj": "11111111111111"})


# ─────────────────────────────────────────────────────────────
# 4. Índice único de CNPJ via API (requer backend rodando + super admin)
# ─────────────────────────────────────────────────────────────

class TestCNPJUnicoViaAPI:
    """Testa que CNPJ duplicado é rejeitado pelo índice único do MongoDB."""

    CNPJ_TESTE = "45997418000153"  # CNPJ válido para esse teste
    SLUG_A = "empresa-cnpj-a-prompt1"
    SLUG_B = "empresa-cnpj-b-prompt1"

    def _headers(self, token: str) -> dict:
        return {"Authorization": f"Bearer {token}"}

    def _criar_tenant(self, client, token: str, slug: str, cnpj: str):
        return client.post(
            "/super-admin/tenants",
            json={
                "name": f"Empresa {slug}",
                "slug": slug,
                "cnpj": cnpj,
                "admin_email": f"admin@{slug}.com",
                "admin_password": "Admin@123456",
            },
            headers=self._headers(token),
        )

    def _deletar_tenant_se_existir(self, client, token: str, slug: str):
        """Limpeza: remove tenant de teste para idempotência."""
        # Listar tenants e deletar se existir
        r = client.get("/super-admin/tenants", headers=self._headers(token))
        if r.status_code != 200:
            return
        tenants = r.json().get("tenants", r.json()) if isinstance(r.json(), dict) else r.json()
        if isinstance(tenants, dict):
            tenants = tenants.get("tenants", [])
        for t in (tenants or []):
            if t.get("slug") in (self.SLUG_A, self.SLUG_B):
                tid = t.get("id")
                if tid:
                    client.delete(
                        f"/super-admin/tenants/{tid}",
                        headers=self._headers(token)
                    )

    def test_cnpj_duplicado_rejeitado(self, client, super_token):
        """Criar dois tenants com o mesmo CNPJ deve falhar no segundo."""
        self._deletar_tenant_se_existir(client, super_token, self.SLUG_A)
        self._deletar_tenant_se_existir(client, super_token, self.SLUG_B)

        r1 = self._criar_tenant(client, super_token, self.SLUG_A, self.CNPJ_TESTE)
        # Pode ser 201 ou 200 dependendo da implementação
        assert r1.status_code in (200, 201, 409), (
            f"Criação do primeiro tenant falhou inesperadamente: {r1.status_code} {r1.text}"
        )

        if r1.status_code in (200, 201):
            # Segundo tenant com mesmo CNPJ deve falhar
            r2 = self._criar_tenant(client, super_token, self.SLUG_B, self.CNPJ_TESTE)
            assert r2.status_code in (400, 409, 422), (
                f"Segundo tenant com CNPJ duplicado deveria ser rejeitado, mas retornou "
                f"{r2.status_code}: {r2.text}"
            )

        # Limpeza
        self._deletar_tenant_se_existir(client, super_token, self.SLUG_A)
        self._deletar_tenant_se_existir(client, super_token, self.SLUG_B)


# ─────────────────────────────────────────────────────────────
# 5. Testes de InviteCreate — validação de store_ids por role
# ─────────────────────────────────────────────────────────────

class TestInviteCreate:

    # ── TENANT_ADMIN ──────────────────────────────────────────

    def test_admin_sem_store_ids(self):
        """Admin não precisa de store_ids."""
        m = InviteCreate(email="admin@teste.com", role="TENANT_ADMIN")
        assert m.store_ids == []
        assert m.all_stores is False

    def test_admin_ignora_store_ids_fornecidos(self):
        """Admin ignora store_ids mesmo que fornecidos."""
        m = InviteCreate(
            email="admin@teste.com",
            role="TENANT_ADMIN",
            store_ids=["store-1", "store-2"],
            all_stores=True,
        )
        assert m.store_ids == []
        assert m.all_stores is False

    # ── REGIONAL_MANAGER ─────────────────────────────────────

    def test_regional_all_stores_true(self):
        """all_stores=True → store_ids normalizado para []."""
        m = InviteCreate(
            email="regional@teste.com",
            role="REGIONAL_MANAGER",
            all_stores=True,
        )
        assert m.store_ids == []

    def test_regional_all_stores_false_com_stores(self):
        """all_stores=False com store_ids ≥ 1 → válido."""
        m = InviteCreate(
            email="regional@teste.com",
            role="REGIONAL_MANAGER",
            store_ids=["store-1"],
            all_stores=False,
        )
        assert "store-1" in m.store_ids

    def test_regional_all_stores_false_sem_stores_erro(self):
        """all_stores=False sem store_ids → ValidationError."""
        with pytest.raises(ValidationError) as exc_info:
            InviteCreate(
                email="regional@teste.com",
                role="REGIONAL_MANAGER",
                store_ids=[],
                all_stores=False,
            )
        assert any(
            "regional_manager" in str(e.get("msg", "")).lower() or
            "all_stores" in str(e.get("msg", "")).lower() or
            "store_id" in str(e.get("msg", "")).lower()
            for e in exc_info.value.errors()
        )

    # ── STORE_MANAGER ─────────────────────────────────────────

    def test_store_manager_com_store_ids(self):
        m = InviteCreate(
            email="gerente@teste.com",
            role="STORE_MANAGER",
            store_ids=["store-1"],
        )
        assert "store-1" in m.store_ids

    def test_store_manager_sem_store_ids_erro(self):
        """STORE_MANAGER sem store_ids → ValidationError."""
        with pytest.raises(ValidationError) as exc_info:
            InviteCreate(email="gerente@teste.com", role="STORE_MANAGER")
        assert any(
            "store_id" in str(e.get("msg", "")).lower() or
            "store_manager" in str(e.get("msg", "")).lower()
            for e in exc_info.value.errors()
        )

    def test_store_manager_all_stores_nao_libera_lista_vazia(self):
        """STORE_MANAGER não tem conceito de all_stores — lista vazia ainda é erro."""
        with pytest.raises(ValidationError):
            InviteCreate(
                email="gerente@teste.com",
                role="STORE_MANAGER",
                store_ids=[],
                all_stores=True,
            )

    # ── SUPERVISOR ────────────────────────────────────────────

    def test_supervisor_com_store_ids(self):
        m = InviteCreate(
            email="supervisor@teste.com",
            role="SUPERVISOR",
            store_ids=["store-1", "store-2"],
        )
        assert len(m.store_ids) >= 1

    def test_supervisor_sem_store_ids_erro(self):
        with pytest.raises(ValidationError):
            InviteCreate(email="supervisor@teste.com", role="SUPERVISOR")

    # ── SELLER ────────────────────────────────────────────────

    def test_seller_exatamente_uma_loja(self):
        m = InviteCreate(
            email="vendedor@teste.com",
            role="SELLER",
            store_ids=["store-1"],
        )
        assert m.store_ids == ["store-1"]

    def test_seller_zero_lojas_erro(self):
        with pytest.raises(ValidationError) as exc_info:
            InviteCreate(email="vendedor@teste.com", role="SELLER", store_ids=[])
        assert any(
            "seller" in str(e.get("msg", "")).lower() or
            "1 loja" in str(e.get("msg", "")).lower() or
            "1 item" in str(e.get("msg", "")).lower()
            for e in exc_info.value.errors()
        )

    def test_seller_duas_lojas_erro(self):
        with pytest.raises(ValidationError) as exc_info:
            InviteCreate(
                email="vendedor@teste.com",
                role="SELLER",
                store_ids=["store-1", "store-2"],
            )
        assert any(
            "seller" in str(e.get("msg", "")).lower() or
            "1 loja" in str(e.get("msg", "")).lower() or
            "1 item" in str(e.get("msg", "")).lower()
            for e in exc_info.value.errors()
        )

    def test_seller_sem_store_ids_erro(self):
        """SELLER sem store_ids (usa default []) → erro."""
        with pytest.raises(ValidationError):
            InviteCreate(email="vendedor@teste.com", role="SELLER")
