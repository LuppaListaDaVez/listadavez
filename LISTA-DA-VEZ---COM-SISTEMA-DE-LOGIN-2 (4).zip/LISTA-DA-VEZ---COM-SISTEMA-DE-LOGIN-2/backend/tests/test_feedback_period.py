"""
Test suite for Feedback Period Feature (Prompt 9).
Tests the new seller-context endpoint and period_start/period_end fields in feedback creation.
"""
import os
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")

# Known seller IDs from demo tenant (João Silva)
JOAO_SELLER_ID = "80383623-afe9-49c6-a13d-9b2e7d03b3f8"
CARLOS_SELLER_ID = "edec9723-f0b7-46a2-bacd-b22fe5903231"


@pytest.fixture(scope="module")
def gerente_token():
    """Get auth token for gerente (STORE_MANAGER)."""
    resp = requests.post(
        f"{BASE_URL}/api/tenants/demo/auth/login",
        json={"email": "gerente@demo.com", "password": "Admin@123456"},
    )
    assert resp.status_code == 200, f"Login failed: {resp.text}"
    return resp.json()["access_token"]


@pytest.fixture(scope="module")
def admin_token():
    """Get auth token for admin."""
    resp = requests.post(
        f"{BASE_URL}/api/tenants/demo/auth/login",
        json={"email": "admin@demo.com", "password": "Admin@123456"},
    )
    assert resp.status_code == 200, f"Login failed: {resp.text}"
    return resp.json()["access_token"]


@pytest.fixture(scope="module")
def gerente_headers(gerente_token):
    return {"Authorization": f"Bearer {gerente_token}"}


@pytest.fixture(scope="module")
def admin_headers(admin_token):
    return {"Authorization": f"Bearer {admin_token}"}


# ─── seller-context endpoint ──────────────────────────────────────────────────

class TestSellerContextEndpoint:
    """Tests for GET /api/tenants/demo/feedbacks/seller-context"""

    def test_seller_context_returns_200(self, gerente_headers):
        """Endpoint returns 200 with valid params."""
        resp = requests.get(
            f"{BASE_URL}/api/tenants/demo/feedbacks/seller-context",
            headers=gerente_headers,
            params={
                "seller_id": JOAO_SELLER_ID,
                "date_from": "2026-01-01",
                "date_to": "2026-07-31",
            },
        )
        assert resp.status_code == 200, f"Expected 200, got {resp.status_code}: {resp.text}"

    def test_seller_context_response_structure(self, gerente_headers):
        """Response contains required fields: kpis, goals, ranking, seller_name, period."""
        resp = requests.get(
            f"{BASE_URL}/api/tenants/demo/feedbacks/seller-context",
            headers=gerente_headers,
            params={
                "seller_id": JOAO_SELLER_ID,
                "date_from": "2026-01-01",
                "date_to": "2026-07-31",
            },
        )
        assert resp.status_code == 200
        data = resp.json()

        # Check top-level fields
        assert "seller_id" in data, "Missing seller_id"
        assert "seller_name" in data, "Missing seller_name"
        assert "period_start" in data, "Missing period_start"
        assert "period_end" in data, "Missing period_end"
        assert "kpis" in data, "Missing kpis"
        assert "goals" in data, "Missing goals"
        assert "ranking" in data, "Missing ranking"

    def test_seller_context_kpis_structure(self, gerente_headers):
        """KPIs object has all required metrics."""
        resp = requests.get(
            f"{BASE_URL}/api/tenants/demo/feedbacks/seller-context",
            headers=gerente_headers,
            params={
                "seller_id": JOAO_SELLER_ID,
                "date_from": "2026-01-01",
                "date_to": "2026-07-31",
            },
        )
        assert resp.status_code == 200
        kpis = resp.json()["kpis"]

        required_kpis = [
            "total_atendimentos", "finalizados", "vendas",
            "conversao_pct", "receita_total_cents", "ticket_medio_cents"
        ]
        for key in required_kpis:
            assert key in kpis, f"Missing KPI: {key}"
        # Values should be numeric
        assert isinstance(kpis["total_atendimentos"], int), "total_atendimentos should be int"
        assert isinstance(kpis["conversao_pct"], (int, float)), "conversao_pct should be numeric"

    def test_seller_context_ranking_structure(self, gerente_headers):
        """Ranking object has position and total_sellers."""
        resp = requests.get(
            f"{BASE_URL}/api/tenants/demo/feedbacks/seller-context",
            headers=gerente_headers,
            params={
                "seller_id": JOAO_SELLER_ID,
                "date_from": "2026-01-01",
                "date_to": "2026-07-31",
            },
        )
        assert resp.status_code == 200
        ranking = resp.json()["ranking"]
        assert "position" in ranking, "Missing ranking.position"
        assert "total_sellers" in ranking, "Missing ranking.total_sellers"

    def test_seller_context_correct_seller_info(self, gerente_headers):
        """Response contains correct seller info."""
        resp = requests.get(
            f"{BASE_URL}/api/tenants/demo/feedbacks/seller-context",
            headers=gerente_headers,
            params={
                "seller_id": JOAO_SELLER_ID,
                "date_from": "2026-01-01",
                "date_to": "2026-07-31",
            },
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["seller_id"] == JOAO_SELLER_ID
        assert data["period_start"] == "2026-01-01"
        assert data["period_end"] == "2026-07-31"
        # Seller name should be João Silva
        assert "João" in data["seller_name"] or "Joao" in data["seller_name"] or "Silva" in data["seller_name"], \
            f"Expected João Silva, got: {data['seller_name']}"

    def test_seller_context_invalid_seller_404(self, gerente_headers):
        """Returns 404 for non-existent seller."""
        resp = requests.get(
            f"{BASE_URL}/api/tenants/demo/feedbacks/seller-context",
            headers=gerente_headers,
            params={
                "seller_id": "00000000-0000-0000-0000-000000000000",
                "date_from": "2026-01-01",
                "date_to": "2026-07-31",
            },
        )
        assert resp.status_code == 404

    def test_seller_context_no_auth_returns_401(self):
        """Unauthenticated request returns 401 or 403."""
        resp = requests.get(
            f"{BASE_URL}/api/tenants/demo/feedbacks/seller-context",
            params={
                "seller_id": JOAO_SELLER_ID,
                "date_from": "2026-01-01",
                "date_to": "2026-07-31",
            },
        )
        assert resp.status_code in [401, 403], f"Expected 401/403, got {resp.status_code}"

    def test_seller_context_admin_can_access(self, admin_headers):
        """Admin can also call seller-context endpoint."""
        resp = requests.get(
            f"{BASE_URL}/api/tenants/demo/feedbacks/seller-context",
            headers=admin_headers,
            params={
                "seller_id": JOAO_SELLER_ID,
                "date_from": "2026-01-01",
                "date_to": "2026-07-31",
            },
        )
        assert resp.status_code == 200


# ─── Feedback creation with period fields ─────────────────────────────────────

class TestFeedbackWithPeriod:
    """Tests for creating feedback with period_start and period_end."""

    created_feedback_id = None

    def test_create_feedback_with_period(self, gerente_headers):
        """Create feedback with period_start and period_end, verify saved correctly."""
        payload = {
            "seller_id": JOAO_SELLER_ID,
            "type": "CONSTRUCTIVE",
            "title": "TEST_ Feedback com período de referência",
            "content": "Este é um feedback de teste com período de referência.",
            "period_start": "2026-01-01",
            "period_end": "2026-01-31",
        }
        resp = requests.post(
            f"{BASE_URL}/api/tenants/demo/feedbacks",
            headers=gerente_headers,
            json=payload,
        )
        assert resp.status_code == 200, f"Expected 200, got {resp.status_code}: {resp.text}"
        data = resp.json()
        assert "id" in data, "Missing id in response"
        assert data["period_start"] == "2026-01-01", f"period_start mismatch: {data.get('period_start')}"
        assert data["period_end"] == "2026-01-31", f"period_end mismatch: {data.get('period_end')}"
        # Store for later tests
        TestFeedbackWithPeriod.created_feedback_id = data["id"]

    def test_get_feedback_shows_period(self, gerente_headers):
        """GET feedback returns period_start and period_end fields."""
        fid = TestFeedbackWithPeriod.created_feedback_id
        if not fid:
            pytest.skip("No feedback created in previous test")

        resp = requests.get(
            f"{BASE_URL}/api/tenants/demo/feedbacks/{fid}",
            headers=gerente_headers,
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data.get("period_start") == "2026-01-01", f"Persisted period_start wrong: {data.get('period_start')}"
        assert data.get("period_end") == "2026-01-31", f"Persisted period_end wrong: {data.get('period_end')}"

    def test_create_feedback_without_period(self, gerente_headers):
        """Create feedback without period fields — still works (period_start/end are optional at API level)."""
        payload = {
            "seller_id": JOAO_SELLER_ID,
            "type": "POSITIVE",
            "title": "TEST_ Feedback sem período",
            "content": "Feedback sem período de referência.",
        }
        resp = requests.post(
            f"{BASE_URL}/api/tenants/demo/feedbacks",
            headers=gerente_headers,
            json=payload,
        )
        assert resp.status_code == 200, f"Expected 200, got {resp.status_code}: {resp.text}"
        data = resp.json()
        assert "id" in data

    def test_seller_context_not_matched_by_feedback_id_route(self, gerente_headers):
        """
        Critical: /seller-context must NOT be matched as a /{feedback_id} route.
        This tests that the route ordering is correct.
        """
        resp = requests.get(
            f"{BASE_URL}/api/tenants/demo/feedbacks/seller-context",
            headers=gerente_headers,
            params={
                "seller_id": JOAO_SELLER_ID,
                "date_from": "2026-01-01",
                "date_to": "2026-07-31",
            },
        )
        # If routing is wrong, it would try to find a feedback with id="seller-context" → 404
        # If routing is correct, it returns the seller-context endpoint → 200
        assert resp.status_code == 200, \
            f"Route ordering bug! /seller-context matched as /{'{feedback_id}'} route. Status: {resp.status_code}"


# ─── Known feedback with period (from context note) ───────────────────────────

class TestExistingFeedbackWithPeriod:
    """Test the known feedback ID that has period_start and period_end."""

    KNOWN_FEEDBACK_ID = "34d1961f-092d-49f7-8eed-8ced44b1eea4"

    def test_known_feedback_has_period(self, gerente_headers):
        """The pre-seeded feedback with id 34d1961f... should have period data."""
        resp = requests.get(
            f"{BASE_URL}/api/tenants/demo/feedbacks/{self.KNOWN_FEEDBACK_ID}",
            headers=gerente_headers,
        )
        if resp.status_code == 404:
            pytest.skip("Pre-seeded feedback not found, may not exist in this environment")
        assert resp.status_code == 200
        data = resp.json()
        assert data.get("period_start") is not None, "Expected period_start to be set"
        assert data.get("period_end") is not None, "Expected period_end to be set"

    def test_known_feedback_period_values(self, gerente_headers):
        """Verify known feedback period matches expected values."""
        resp = requests.get(
            f"{BASE_URL}/api/tenants/demo/feedbacks/{self.KNOWN_FEEDBACK_ID}",
            headers=gerente_headers,
        )
        if resp.status_code == 404:
            pytest.skip("Pre-seeded feedback not found")
        assert resp.status_code == 200
        data = resp.json()
        assert data.get("period_start") == "2026-01-01", f"Expected 2026-01-01, got {data.get('period_start')}"
        assert data.get("period_end") == "2026-07-31", f"Expected 2026-07-31, got {data.get('period_end')}"
