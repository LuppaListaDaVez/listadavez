"""Tests for GET /teams/rankings endpoint"""
import pytest
import requests
import os

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")

@pytest.fixture(scope="module")
def session():
    s = requests.Session()
    r = s.post(f"{BASE_URL}/api/tenants/demo/auth/login", json={"email": "admin@demo.com", "password": "Admin@123456"})
    assert r.status_code == 200, f"Login failed: {r.text}"
    token = r.json()["access_token"]
    s.headers.update({"Authorization": f"Bearer {token}"})
    return s

def test_rankings_month(session):
    r = session.get(f"{BASE_URL}/api/tenants/demo/teams/rankings?period=month")
    assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text}"
    data = r.json()
    assert isinstance(data, list)
    print(f"Rankings month: {data}")
    if data:
        item = data[0]
        assert "rank" in item
        assert "team_name" in item
        assert "sales" in item
        assert "revenue_cents" in item

def test_rankings_all(session):
    r = session.get(f"{BASE_URL}/api/tenants/demo/teams/rankings?period=all")
    assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text}"
    data = r.json()
    assert isinstance(data, list)
    print(f"Rankings all: {data}")
    manha = [x for x in data if "Manh" in x.get("team_name", "")]
    if manha:
        print(f"Equipe Manhã sales: {manha[0]['sales']}")
        assert manha[0]["sales"] >= 2, f"Equipe Manhã should have >= 2 sales, got {manha[0]['sales']}"

def test_rankings_week(session):
    r = session.get(f"{BASE_URL}/api/tenants/demo/teams/rankings?period=week")
    assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text}"
    data = r.json()
    assert isinstance(data, list)
    print(f"Rankings week: {data}")

def test_rankings_no_conflict_with_team_id(session):
    r = session.get(f"{BASE_URL}/api/tenants/demo/teams/rankings")
    assert r.status_code == 200, f"Rankings route conflicts: {r.text}"
    assert "Equipe não encontrada" not in r.text

def test_rankings_default_no_period(session):
    r = session.get(f"{BASE_URL}/api/tenants/demo/teams/rankings")
    assert r.status_code == 200
