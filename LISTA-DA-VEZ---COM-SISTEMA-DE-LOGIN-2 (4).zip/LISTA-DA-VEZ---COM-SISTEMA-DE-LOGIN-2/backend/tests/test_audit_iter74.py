"""
Audit iteration 74 - post-migration bug fix verification.
Covers:
  - Bug 1: concurrent product creation with duplicate SKU (one 201, rest 409)
  - Bug 2: concurrent seller creation with duplicate email (one 201, rest 409)
  - Bug 3: POST /api/super-admin/tenants/{id}/resend-invite (Motor find_one sort=)
  - Bug 4: invite/token datetime comparison (create tenant, resend invite,
           forgot-password request)
  - Multi-tenant isolation (tenant B token can't touch tenant A resources)
  - Queue seller_lock: 6 concurrent "enter queue" -> 1 success + rest 409
Uses cached tokens to avoid rate-limit.
"""
import os
import time
import uuid
import asyncio
import pytest
import requests
import httpx

def _load_backend_url():
    v = os.environ.get("REACT_APP_BACKEND_URL")
    if v:
        return v.rstrip("/")
    try:
        with open("/app/frontend/.env") as f:
            for line in f:
                if line.startswith("REACT_APP_BACKEND_URL="):
                    return line.split("=", 1)[1].strip().rstrip("/")
    except FileNotFoundError:
        pass
    raise RuntimeError("REACT_APP_BACKEND_URL not set")

BASE_URL = _load_backend_url()
TIMEOUT = 90

SUPER_ADMIN = {"email": "admin@listadavez.com", "password": "Admin@123456"}
TENANT_A = {"slug": "demo", "email": "admin@demo.com", "password": "Admin@123456"}
TENANT_B = {"slug": "demo-b", "email": "admin@demo-b.com", "password": "Admin@123456"}


def _login_with_retry(url, payload, name, attempts=4):
    last = None
    for i in range(attempts):
        try:
            r = requests.post(url, json=payload, timeout=TIMEOUT)
            if r.status_code == 200:
                return r
            last = r
            print(f"[login-retry] {name} attempt {i+1}: {r.status_code}")
        except requests.RequestException as e:
            print(f"[login-retry] {name} attempt {i+1}: exception {e}")
        time.sleep(6)
    return last


# ------------ session-scoped fixtures (token caching) ------------
@pytest.fixture(scope="session")
def super_admin_token():
    r = _login_with_retry(f"{BASE_URL}/api/auth/login", SUPER_ADMIN, "super-admin")
    assert r is not None and r.status_code == 200, f"super admin login failed: {getattr(r,'status_code',None)}"
    return r.json()["access_token"]


@pytest.fixture(scope="session")
def tenant_a_token():
    r = _login_with_retry(
        f"{BASE_URL}/api/tenants/{TENANT_A['slug']}/auth/login",
        {"email": TENANT_A["email"], "password": TENANT_A["password"]},
        "tenant-a",
    )
    assert r is not None and r.status_code == 200, f"tenant A login failed: {getattr(r,'status_code',None)}"
    return r.json()["access_token"]


@pytest.fixture(scope="session")
def tenant_b_token():
    r = _login_with_retry(
        f"{BASE_URL}/api/tenants/{TENANT_B['slug']}/auth/login",
        {"email": TENANT_B["email"], "password": TENANT_B["password"]},
        "tenant-b",
    )
    if r is None or r.status_code != 200:
        pytest.skip(f"tenant B (demo-b) login not available: {getattr(r,'status_code',None)}")
    return r.json()["access_token"]


@pytest.fixture(scope="session")
def joao_token():
    r = _login_with_retry(
        f"{BASE_URL}/api/tenants/{TENANT_A['slug']}/auth/login",
        {"email": "joao@demo.com", "password": "Admin@123456"},
        "joao",
    )
    assert r is not None and r.status_code == 200, f"seller login failed: {getattr(r,'status_code',None)}"
    return r.json()["access_token"]


# ---------- Bug 1: concurrent product creation ----------
class TestBug1ProductSKUConcurrency:
    async def _create_products(self, token, sku):
        url = f"{BASE_URL}/api/tenants/{TENANT_A['slug']}/products"
        headers = {"Authorization": f"Bearer {token}"}
        payload = {"name": f"AUDIT_TEST product {sku}", "sku": sku, "price_cents": 1000}
        async with httpx.AsyncClient(timeout=TIMEOUT) as client:
            tasks = [client.post(url, json=payload, headers=headers) for _ in range(5)]
            return await asyncio.gather(*tasks)

    def test_concurrent_duplicate_sku(self, tenant_a_token):
        sku = f"AUDIT_TEST_SKU_{uuid.uuid4().hex[:8]}"
        results = asyncio.run(self._create_products(tenant_a_token, sku))
        statuses = sorted([r.status_code for r in results])
        print(f"[bug1] statuses={statuses}")
        successes = [s for s in statuses if s in (200, 201)]
        conflicts = [s for s in statuses if s == 409]
        assert len(successes) == 1, f"expected exactly 1 success, got {statuses} bodies={[r.text[:120] for r in results]}"
        assert len(conflicts) == len(statuses) - 1, f"remaining must be 409, got {statuses}"

        # verify persistence: only one product with that sku
        r = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_A['slug']}/products",
            headers={"Authorization": f"Bearer {tenant_a_token}"},
            timeout=TIMEOUT,
        )
        assert r.status_code == 200
        matching = [p for p in r.json() if p.get("sku") == sku]
        assert len(matching) == 1, f"expected 1 persisted product, found {len(matching)}"


# ---------- Bug 2: concurrent seller creation ----------
class TestBug2SellerEmailConcurrency:
    async def _create_sellers(self, token, email, store_id):
        url = f"{BASE_URL}/api/tenants/{TENANT_A['slug']}/sellers"
        headers = {"Authorization": f"Bearer {token}"}
        payload = {
            "name": "AUDIT_TEST Seller",
            "email": email,
            "password": "Admin@123456",
            "store_id": store_id,
        }
        async with httpx.AsyncClient(timeout=TIMEOUT) as client:
            tasks = [client.post(url, json=payload, headers=headers) for _ in range(5)]
            return await asyncio.gather(*tasks)

    def test_concurrent_duplicate_email(self, tenant_a_token):
        # fetch a store id first
        r = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_A['slug']}/stores",
            headers={"Authorization": f"Bearer {tenant_a_token}"},
            timeout=TIMEOUT,
        )
        assert r.status_code == 200, f"stores list failed: {r.status_code}"
        stores = r.json()
        assert stores, "no stores in tenant demo"
        store_id = stores[0]["id"]

        email = f"audit_test_{uuid.uuid4().hex[:8]}@demo.com"
        results = asyncio.run(self._create_sellers(tenant_a_token, email, store_id))
        statuses = sorted([r.status_code for r in results])
        print(f"[bug2] statuses={statuses} bodies={[r.text[:150] for r in results[:2]]}")
        successes = [s for s in statuses if s in (200, 201)]
        conflicts = [s for s in statuses if s == 409]
        assert 500 not in statuses, f"500 leaked: {[r.text[:200] for r in results if r.status_code == 500]}"
        assert len(successes) == 1, f"expected 1 success, got {statuses}"
        assert len(conflicts) >= len(statuses) - 1 - 0, f"expected 409s, got {statuses}"


# ---------- Bug 3 + 4: super-admin tenant invites + datetime ----------
class TestBug3And4TenantInvite:
    def test_create_tenant_and_resend_invite(self, super_admin_token):
        headers = {"Authorization": f"Bearer {super_admin_token}"}
        slug = f"audittest{uuid.uuid4().hex[:6]}"
        # valid CNPJ (rotate from known-valid list; use first, may still be in-use so
        # we'll try alternates on 409)
        cnpjs = ["29979036000140", "45997418000153", "63025530000160", "72398092000110"]
        created = None
        for cnpj in cnpjs:
            payload = {
                "name": f"AUDIT_TEST Tenant {slug}",
                "slug": slug,
                "cnpj": cnpj,
                "admin_email": f"admin+{slug}@example.com",
                "admin_name": "AUDIT_TEST Admin",
            }
            r = requests.post(
                f"{BASE_URL}/api/super-admin/tenants", json=payload, headers=headers, timeout=TIMEOUT
            )
            if r.status_code in (200, 201):
                created = r
                break
            if r.status_code == 409:
                slug = f"audittest{uuid.uuid4().hex[:6]}"
                continue
            pytest.fail(f"create tenant failed: {r.status_code} {r.text}")
        assert created is not None, "could not create tenant (all cnpjs conflicted)"
        tenant = created.json()
        tenant_id = tenant.get("id") or tenant.get("tenant", {}).get("id")
        assert tenant_id, f"no tenant id in response: {tenant}"

        # Bug 3: resend invite (was 500 due to Motor find_one(sort=))
        r2 = requests.post(
            f"{BASE_URL}/api/super-admin/tenants/{tenant_id}/resend-invite",
            headers=headers,
            timeout=TIMEOUT,
        )
        assert r2.status_code == 200, f"resend-invite failed: {r2.status_code} {r2.text}"

        # cleanup: try to delete the tenant (best-effort)
        try:
            requests.delete(
                f"{BASE_URL}/api/super-admin/tenants/{tenant_id}",
                headers=headers,
                timeout=TIMEOUT,
            )
        except Exception:
            pass

    def test_forgot_password_datetime(self):
        # Bug 4: forgot password creates token w/ expires_at datetime.
        # Endpoint must NOT return 500.
        r = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_A['slug']}/auth/password-reset/request",
            json={"email": TENANT_A["email"]},
            timeout=TIMEOUT,
        )
        # generally 200 or 202 to avoid enumeration
        assert r.status_code in (200, 202, 204), f"forgot-password failed: {r.status_code} {r.text}"


# ---------- Multi-tenant isolation ----------
class TestIsolation:
    def test_tenant_b_cannot_read_tenant_a_products(self, tenant_a_token, tenant_b_token):
        # get a product from tenant A
        r = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_A['slug']}/products",
            headers={"Authorization": f"Bearer {tenant_a_token}"},
            timeout=TIMEOUT,
        )
        assert r.status_code == 200
        products = r.json()
        if not products:
            pytest.skip("no products in tenant A")
        pid = products[0]["id"]

        # tenant B token trying to access tenant A endpoint
        r2 = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_A['slug']}/products",
            headers={"Authorization": f"Bearer {tenant_b_token}"},
            timeout=TIMEOUT,
        )
        assert r2.status_code in (401, 403, 404), (
            f"tenant B could access tenant A: {r2.status_code} {r2.text[:200]}"
        )

        # tenant B token on its own slug shouldn't leak A's product id
        r3 = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_B['slug']}/products/{pid}",
            headers={"Authorization": f"Bearer {tenant_b_token}"},
            timeout=TIMEOUT,
        )
        assert r3.status_code in (401, 403, 404), (
            f"tenant B accessed tenant A product by id: {r3.status_code}"
        )


# ---------- Queue seller_lock concurrency ----------
class TestQueueLock:
    async def _enter_queue(self, token, store_id, seller_id):
        url = f"{BASE_URL}/api/tenants/{TENANT_A['slug']}/stores/{store_id}/queue/join"
        headers = {"Authorization": f"Bearer {token}"}
        payload = {"seller_id": seller_id}
        async with httpx.AsyncClient(timeout=TIMEOUT) as client:
            tasks = [client.post(url, headers=headers, json=payload) for _ in range(6)]
            return await asyncio.gather(*tasks, return_exceptions=True)

    def test_concurrent_queue_enter_single_success(self, joao_token, tenant_a_token):
        # Get joao's seller_id + store_id via /auth/me on joao token
        me = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_A['slug']}/auth/me",
            headers={"Authorization": f"Bearer {joao_token}"},
            timeout=TIMEOUT,
        )
        if me.status_code != 200:
            # fallback to global /api/auth/me
            me = requests.get(
                f"{BASE_URL}/api/auth/me",
                headers={"Authorization": f"Bearer {joao_token}"},
                timeout=TIMEOUT,
            )
        assert me.status_code == 200, f"me: {me.status_code} {me.text[:200]}"
        me_data = me.json()
        seller_id = (me_data.get("seller") or {}).get("id") or me_data.get("seller_id")
        store_id = (me_data.get("seller") or {}).get("store_id") or me_data.get("store_id")
        # fallback: pull from sellers list matching user_id
        if not seller_id or not store_id:
            user_id = (me_data.get("user") or {}).get("id") or me_data.get("id")
            r = requests.get(
                f"{BASE_URL}/api/tenants/{TENANT_A['slug']}/sellers",
                headers={"Authorization": f"Bearer {tenant_a_token}"},
                timeout=TIMEOUT,
            )
            assert r.status_code == 200
            sellers = r.json()
            s = next((s for s in sellers if s.get("user_id") == user_id), None)
            if not s:
                print(f"[queue-lock] sellers sample keys={list(sellers[0].keys()) if sellers else None}")
                print(f"[queue-lock] me keys={list(me_data.keys())} user_id={user_id}")
                pytest.skip(f"couldn't map joao (user_id={user_id}) to a seller record")
            seller_id = s["id"]
            store_id = s.get("store_id")
        assert seller_id and store_id, f"missing seller_id/store_id: seller_id={seller_id} store_id={store_id}"

        # best-effort leave first (any store, ignore errors)
        try:
            requests.post(
                f"{BASE_URL}/api/tenants/{TENANT_A['slug']}/stores/{store_id}/queue/leave",
                headers={"Authorization": f"Bearer {joao_token}"},
                json={"seller_id": seller_id},
                timeout=TIMEOUT,
            )
        except Exception:
            pass
        time.sleep(0.5)

        results = asyncio.run(self._enter_queue(joao_token, store_id, seller_id))
        statuses = []
        for r in results:
            if isinstance(r, Exception):
                statuses.append(f"exc:{type(r).__name__}")
            else:
                statuses.append(r.status_code)
        print(f"[queue-lock] statuses={statuses}")
        code_counts = {}
        for s in statuses:
            code_counts[s] = code_counts.get(s, 0) + 1
        successes = code_counts.get(200, 0) + code_counts.get(201, 0)
        conflicts = code_counts.get(409, 0)
        # After the fix: exactly 1 success (or the seller was already in queue and 0 success + all 409s from state)
        assert successes <= 1, f"multiple successes: {statuses}"
        assert 500 not in statuses, f"500 leaked: {statuses}"
        assert successes + conflicts == len(statuses), f"unexpected codes: {statuses}"
