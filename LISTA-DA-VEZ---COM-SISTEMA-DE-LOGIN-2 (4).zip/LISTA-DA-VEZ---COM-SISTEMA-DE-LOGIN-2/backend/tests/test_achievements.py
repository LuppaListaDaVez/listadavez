"""test_achievements.py — Backend tests for Gamification module (achievements, awards, rankings)"""
import pytest
import requests
import os

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")

ADMIN_CREDS = {"email": "admin@demo.com", "password": "Admin@123456", "tenant_slug": "demo"}
SELLER_CREDS = {"email": "joao@demo.com", "password": "Admin@123456", "tenant_slug": "demo"}


@pytest.fixture(scope="module")
def admin_token():
    r = requests.post(f"{BASE_URL}/api/tenants/demo/auth/login", json=ADMIN_CREDS)
    assert r.status_code == 200, f"Admin login failed: {r.text}"
    return r.json()["access_token"]


@pytest.fixture(scope="module")
def seller_token():
    r = requests.post(f"{BASE_URL}/api/tenants/demo/auth/login", json=SELLER_CREDS)
    assert r.status_code == 200, f"Seller login failed: {r.text}"
    return r.json()["access_token"]


@pytest.fixture(scope="module")
def admin_headers(admin_token):
    return {"Authorization": f"Bearer {admin_token}"}


@pytest.fixture(scope="module")
def seller_headers(seller_token):
    return {"Authorization": f"Bearer {seller_token}"}


# ── CRUD de conquistas ─────────────────────────────────────────────────────────

class TestAchievementsCRUD:
    """CRUD tests for achievements"""

    created_id = None

    def test_list_achievements(self, admin_headers):
        r = requests.get(f"{BASE_URL}/api/tenants/demo/achievements", headers=admin_headers)
        assert r.status_code == 200
        assert isinstance(r.json(), list)
        print(f"[OK] list achievements: {len(r.json())} items")

    def test_create_achievement(self, admin_headers):
        payload = {
            "name": "TEST_Primeira Venda",
            "description": "Conquista de teste",
            "points": 100,
            "rule_metric": "SALES_COUNT",
            "rule_operator": "GTE",
            "rule_target_value": 1,
            "category": "SALES",
            "scope": "INDIVIDUAL",
            "period_type": "ALL_TIME",
            "visibility": "PUBLIC",
            "recurrence": "ONCE",
            "approval_mode": "AUTOMATIC",
        }
        r = requests.post(f"{BASE_URL}/api/tenants/demo/achievements", headers=admin_headers, json=payload)
        assert r.status_code == 201, f"Create failed: {r.text}"
        data = r.json()
        assert data["name"] == "TEST_Primeira Venda"
        assert data["points"] == 100
        assert data["status"] == "DRAFT"
        assert data["rule"] is not None
        TestAchievementsCRUD.created_id = data["id"]
        print(f"[OK] create achievement id={data['id']}")

    def test_get_achievement(self, admin_headers):
        ach_id = TestAchievementsCRUD.created_id
        if not ach_id:
            pytest.skip("No achievement created")
        r = requests.get(f"{BASE_URL}/api/tenants/demo/achievements/{ach_id}", headers=admin_headers)
        assert r.status_code == 200
        assert r.json()["id"] == ach_id

    def test_activate_achievement(self, admin_headers):
        ach_id = TestAchievementsCRUD.created_id
        if not ach_id:
            pytest.skip("No achievement created")
        r = requests.patch(
            f"{BASE_URL}/api/tenants/demo/achievements/{ach_id}/status",
            headers=admin_headers,
            json={"status": "ACTIVE"},
        )
        assert r.status_code == 200, f"Activate failed: {r.text}"
        assert r.json()["status"] == "ACTIVE"
        print("[OK] activate achievement")

    def test_verify_active_status(self, admin_headers):
        ach_id = TestAchievementsCRUD.created_id
        if not ach_id:
            pytest.skip("No achievement created")
        r = requests.get(f"{BASE_URL}/api/tenants/demo/achievements/{ach_id}", headers=admin_headers)
        assert r.status_code == 200
        assert r.json()["status"] == "ACTIVE"


# ── Awards ────────────────────────────────────────────────────────────────────

class TestAchievementAwards:
    """Awards: grant and list"""

    def test_grant_achievement_manual(self, admin_headers):
        ach_id = TestAchievementsCRUD.created_id
        if not ach_id:
            pytest.skip("No achievement created")
        # Get a seller profile
        sellers_r = requests.get(f"{BASE_URL}/api/tenants/demo/sellers", headers=admin_headers)
        assert sellers_r.status_code == 200
        sellers = sellers_r.json()
        assert len(sellers) > 0, "No sellers found"
        seller_id = sellers[0]["id"]

        r = requests.post(
            f"{BASE_URL}/api/tenants/demo/achievements/{ach_id}/grant",
            headers=admin_headers,
            json={"seller_id": seller_id, "reason": "Test manual grant"},
        )
        # Either 201 (success) or 409 (already granted)
        assert r.status_code in (201, 409), f"Grant failed: {r.text}"
        print(f"[OK] grant achievement: {r.status_code}")

    def test_list_my_awards_seller(self, seller_headers):
        r = requests.get(f"{BASE_URL}/api/tenants/demo/achievement-awards/my", headers=seller_headers)
        assert r.status_code == 200
        assert isinstance(r.json(), list)
        print(f"[OK] my awards: {len(r.json())} items")

    def test_my_progress_seller(self, seller_headers):
        r = requests.get(f"{BASE_URL}/api/tenants/demo/achievement-awards/my-progress", headers=seller_headers)
        assert r.status_code == 200
        assert isinstance(r.json(), list)
        print(f"[OK] my-progress: {len(r.json())} items")


# ── Rankings ──────────────────────────────────────────────────────────────────

class TestAchievementRankings:
    """Rankings by period"""

    def test_ranking_month(self, admin_headers):
        r = requests.get(f"{BASE_URL}/api/tenants/demo/achievement-rankings?period=month", headers=admin_headers)
        assert r.status_code == 200
        assert isinstance(r.json(), list)
        print(f"[OK] ranking month: {len(r.json())} entries")

    def test_ranking_week(self, admin_headers):
        r = requests.get(f"{BASE_URL}/api/tenants/demo/achievement-rankings?period=week", headers=admin_headers)
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_ranking_all(self, admin_headers):
        r = requests.get(f"{BASE_URL}/api/tenants/demo/achievement-rankings?period=all", headers=admin_headers)
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_ranking_seller_can_access(self, seller_headers):
        r = requests.get(f"{BASE_URL}/api/tenants/demo/achievement-rankings?period=month", headers=seller_headers)
        assert r.status_code == 200


# ── Goals Fix2 + Fix3 ─────────────────────────────────────────────────────────

class TestGoalsFixes:
    """Fix2: goals_service $or not overwritten. Fix3: SELLER IDOR protection"""

    def test_fix2_goals_with_store_and_seller(self, admin_headers):
        """Fix2: no 500 error when store_id and seller_id passed together"""
        r = requests.get(
            f"{BASE_URL}/api/tenants/demo/goals?store_id=some_store&seller_id=some_seller",
            headers=admin_headers,
        )
        # Should not be 500
        assert r.status_code in (200, 403, 404), f"Unexpected: {r.status_code} {r.text}"
        print(f"[OK] Fix2 goals store+seller: {r.status_code}")

    def test_fix3_seller_cannot_use_other_seller_id(self, seller_headers, admin_headers):
        """Fix3: SELLER cannot spoof seller_id to see other seller's goals"""
        # Get another seller's id
        sellers_r = requests.get(f"{BASE_URL}/api/tenants/demo/sellers", headers=admin_headers)
        sellers = sellers_r.json()
        if len(sellers) < 2:
            pytest.skip("Need at least 2 sellers for IDOR test")

        # Joao's own goals
        my_r = requests.get(f"{BASE_URL}/api/tenants/demo/goals", headers=seller_headers)
        assert my_r.status_code == 200
        my_goals = my_r.json()

        # Try to get another seller's goals
        other_seller = sellers[1]["id"]  # Different seller id
        other_r = requests.get(
            f"{BASE_URL}/api/tenants/demo/goals?seller_id={other_seller}",
            headers=seller_headers,
        )
        assert other_r.status_code == 200
        other_goals = other_r.json()
        # Should return same as own goals (IDOR protection)
        assert len(other_goals) == len(my_goals), "IDOR: seller can see other seller's goals!"
        print("[OK] Fix3 IDOR protection works")


# ── Approvals ─────────────────────────────────────────────────────────────────

class TestAchievementRequests:
    """Approvals tab"""

    def test_list_requests_empty(self, admin_headers):
        r = requests.get(f"{BASE_URL}/api/tenants/demo/achievement-requests", headers=admin_headers)
        assert r.status_code == 200
        assert isinstance(r.json(), list)
        print(f"[OK] requests: {len(r.json())} pending")
