"""Etapa 5 — Commercial registration tests.

Covers: products CRUD, sales list/detail, detailed finish_attendance, money
validation, backward compatibility with Etapa 3 simple sale, metrics auth.
"""
import os
import time
import uuid
import requests
import pytest

BASE = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")
API = f"{BASE}/api"
DEMO = "demo"

ADMIN_EMAIL = "admin@demo.com"
ADMIN_PWD = "Admin@123456"
SUPER_EMAIL = "admin@listadavez.com"
SUPER_PWD = "Admin@123456"


def _login(email, password):
    r = requests.post(f"{API}/auth/login", json={"email": email, "password": password}, timeout=15)
    assert r.status_code == 200, f"login failed {r.status_code} {r.text}"
    return r.json()["access_token"]


@pytest.fixture(scope="module")
def admin_token():
    return _login(ADMIN_EMAIL, ADMIN_PWD)


@pytest.fixture(scope="module")
def super_token():
    return _login(SUPER_EMAIL, SUPER_PWD)


@pytest.fixture(scope="module")
def admin_h(admin_token):
    return {"Authorization": f"Bearer {admin_token}"}


@pytest.fixture(scope="module")
def ctx(admin_h):
    r = requests.get(f"{API}/tenants/{DEMO}/context", headers=admin_h, timeout=15)
    assert r.status_code == 200, r.text
    data = r.json()
    stores = data.get("stores") or []
    centro = next((s for s in stores if s.get("code") == "CENTRO"), stores[0])
    return {"tenant": data["tenant"], "store_id": centro["id"]}


# ===================== Products CRUD =====================
class TestProducts:
    def test_list_seeded_products(self, admin_h):
        r = requests.get(f"{API}/tenants/{DEMO}/products", headers=admin_h, timeout=15)
        assert r.status_code == 200, r.text
        items = r.json()
        skus = {p["sku"] for p in items if p.get("sku")}
        assert {"TENIS-001", "CAMISETA-001", "BOLSA-001"}.issubset(skus)

    def test_create_update_toggle(self, admin_h):
        sku = f"TEST-{uuid.uuid4().hex[:8].upper()}"
        payload = {"sku": sku, "name": "TEST Produto", "price_cents": 12345, "category": "Teste"}
        r = requests.post(f"{API}/tenants/{DEMO}/products", json=payload, headers=admin_h, timeout=15)
        assert r.status_code == 201, r.text
        prod = r.json()
        assert prod["price_cents"] == 12345
        pid = prod["id"]

        # GET verifies persistence
        g = requests.get(f"{API}/tenants/{DEMO}/products/{pid}", headers=admin_h, timeout=15)
        assert g.status_code == 200
        assert g.json()["sku"] == sku

        # Update
        upd = requests.put(f"{API}/tenants/{DEMO}/products/{pid}",
                           json={"name": "TEST Atualizado", "price_cents": 22000},
                           headers=admin_h, timeout=15)
        assert upd.status_code == 200, upd.text
        assert upd.json()["price_cents"] == 22000
        assert upd.json()["name"] == "TEST Atualizado"

        # Toggle status
        st = requests.patch(f"{API}/tenants/{DEMO}/products/{pid}/status",
                            json={"active": False}, headers=admin_h, timeout=15)
        assert st.status_code == 200
        g2 = requests.get(f"{API}/tenants/{DEMO}/products/{pid}", headers=admin_h, timeout=15)
        assert g2.json()["active"] is False

    def test_duplicate_sku_returns_409(self, admin_h):
        r = requests.post(f"{API}/tenants/{DEMO}/products",
                          json={"sku": "TENIS-001", "name": "dup", "price_cents": 100},
                          headers=admin_h, timeout=15)
        assert r.status_code == 409, r.text

    def test_negative_price_returns_400(self, admin_h):
        r = requests.post(f"{API}/tenants/{DEMO}/products",
                          json={"sku": f"NEG-{uuid.uuid4().hex[:6]}", "name": "neg", "price_cents": -1},
                          headers=admin_h, timeout=15)
        assert r.status_code in (400, 422), r.text


# ===================== Helpers for attendance =====================
def _state(admin_h, store_id):
    r = requests.get(f"{API}/tenants/{DEMO}/stores/{store_id}/queue",
                     headers=admin_h, timeout=15)
    assert r.status_code == 200, r.text
    return r.json()


def _cancel_att(admin_h, att_id, reason="cleanup"):
    return requests.post(f"{API}/tenants/{DEMO}/attendances/{att_id}/cancel",
                         json={"reason": reason}, headers=admin_h, timeout=15)


def _ensure_seller_first(admin_h, store_id):
    """Return a (seller_id, attendance_id) by starting an attendance with the
    first WAITING seller in queue. Resets state if needed."""
    st = _state(admin_h, store_id)
    # If any seller is currently SERVING (active attendance), cancel it first.
    for a in list(st.get("active_attendances", [])):
        _cancel_att(admin_h, a["id"], "reset for tests")
    st = _state(admin_h, store_id)
    entries = st.get("entries", [])
    assert entries, "Need at least 1 seller WAITING in queue (seeded joao/maria)."
    seller_id = entries[0]["seller_id"]
    r = requests.post(f"{API}/tenants/{DEMO}/stores/{store_id}/queue/start-attendance",
                      json={"seller_id": seller_id, "source": "WALK_IN"},
                      headers=admin_h, timeout=15)
    assert r.status_code == 200, r.text
    return seller_id, r.json()["attendance"]["id"]


# ===================== Detailed finish_attendance =====================
class TestDetailedSale:
    def test_detailed_sale_creates_sale_and_items(self, admin_h, ctx):
        store_id = ctx["store_id"]
        # pick a product
        products = requests.get(f"{API}/tenants/{DEMO}/products?active=true",
                                headers=admin_h, timeout=15).json()
        prod = next(p for p in products if p["sku"] == "TENIS-001")

        seller_id, att_id = _ensure_seller_first(admin_h, store_id)

        sale = {
            "items": [
                {"product_id": prod["id"], "name": prod["name"], "quantity": 2,
                 "unit_price_cents": prod["price_cents"], "discount_cents": 0},
                {"name": "Item Manual", "quantity": 1, "unit_price_cents": 5000, "discount_cents": 0},
            ],
            "discount_amount_cents": 1000,
            "payment_methods": [
                {"method": "PIX", "amount_cents": prod["price_cents"] * 2 + 5000 - 1000},
            ],
        }
        gross = prod["price_cents"] * 2 + 5000
        net = gross - 1000

        r = requests.post(f"{API}/tenants/{DEMO}/stores/{store_id}/queue/finish-attendance",
                          json={"attendance_id": att_id, "result": "SALE", "sale": sale},
                          headers=admin_h, timeout=20)
        assert r.status_code == 200, r.text
        body = r.json()
        assert body["attendance"]["sale_amount_cents"] == net
        assert body["sale"] is not None
        assert body["sale"]["gross_amount_cents"] == gross
        assert body["sale"]["discount_amount_cents"] == 1000
        assert body["sale"]["net_amount_cents"] == net
        sale_id = body["sale"]["id"]

        # Sales list contains it
        lst = requests.get(f"{API}/tenants/{DEMO}/sales", headers=admin_h, timeout=15)
        assert lst.status_code == 200
        ids = [s["id"] for s in lst.json()]
        assert sale_id in ids
        match = next(s for s in lst.json() if s["id"] == sale_id)
        assert match.get("seller_name")
        assert match.get("store_name")

        # Detail with items
        d = requests.get(f"{API}/tenants/{DEMO}/sales/{sale_id}", headers=admin_h, timeout=15)
        assert d.status_code == 200
        dbody = d.json()
        assert isinstance(dbody.get("items"), list)
        assert len(dbody["items"]) == 2

    def test_payment_methods_mismatch_returns_400(self, admin_h, ctx):
        store_id = ctx["store_id"]
        seller_id, att_id = _ensure_seller_first(admin_h, store_id)
        sale = {
            "items": [{"name": "X", "quantity": 1, "unit_price_cents": 10000, "discount_cents": 0}],
            "payment_methods": [{"method": "CASH", "amount_cents": 5000}],  # mismatch
        }
        r = requests.post(f"{API}/tenants/{DEMO}/stores/{store_id}/queue/finish-attendance",
                          json={"attendance_id": att_id, "result": "SALE", "sale": sale},
                          headers=admin_h, timeout=20)
        assert r.status_code == 400, r.text
        # cleanup: cancel the still-IN_PROGRESS attendance
        _cancel_att(admin_h, att_id)

    def test_quantity_zero_rejected(self, admin_h, ctx):
        store_id = ctx["store_id"]
        seller_id, att_id = _ensure_seller_first(admin_h, store_id)
        sale = {"items": [{"name": "X", "quantity": 0, "unit_price_cents": 100, "discount_cents": 0}]}
        r = requests.post(f"{API}/tenants/{DEMO}/stores/{store_id}/queue/finish-attendance",
                          json={"attendance_id": att_id, "result": "SALE", "sale": sale},
                          headers=admin_h, timeout=20)
        assert r.status_code == 400
        _cancel_att(admin_h, att_id)

    def test_discount_greater_than_gross_rejected(self, admin_h, ctx):
        store_id = ctx["store_id"]
        seller_id, att_id = _ensure_seller_first(admin_h, store_id)
        sale = {
            "items": [{"name": "X", "quantity": 1, "unit_price_cents": 1000, "discount_cents": 0}],
            "discount_amount_cents": 5000,
        }
        r = requests.post(f"{API}/tenants/{DEMO}/stores/{store_id}/queue/finish-attendance",
                          json={"attendance_id": att_id, "result": "SALE", "sale": sale},
                          headers=admin_h, timeout=20)
        assert r.status_code == 400
        _cancel_att(admin_h, att_id)


# ===================== Backward compatibility =====================
class TestBackwardCompat:
    def test_simple_sale_amount_cents_still_works(self, admin_h, ctx):
        store_id = ctx["store_id"]
        seller_id, att_id = _ensure_seller_first(admin_h, store_id)
        r = requests.post(f"{API}/tenants/{DEMO}/stores/{store_id}/queue/finish-attendance",
                          json={"attendance_id": att_id, "result": "SALE",
                                "sale_amount_cents": 7777},
                          headers=admin_h, timeout=20)
        assert r.status_code == 200, r.text
        body = r.json()
        assert body["attendance"]["sale_amount_cents"] == 7777
        assert body.get("sale") in (None, {}) or body["sale"] is None

    def test_no_sale_requires_loss_reason(self, admin_h, ctx):
        store_id = ctx["store_id"]
        seller_id, att_id = _ensure_seller_first(admin_h, store_id)
        r = requests.post(f"{API}/tenants/{DEMO}/stores/{store_id}/queue/finish-attendance",
                          json={"attendance_id": att_id, "result": "NO_SALE"},
                          headers=admin_h, timeout=15)
        assert r.status_code == 400
        # Now succeed using a real loss reason
        lr = requests.get(f"{API}/tenants/{DEMO}/loss-reasons", headers=admin_h, timeout=15).json()
        assert lr, "Need seeded loss reasons"
        lr_id = lr[0]["id"]
        r2 = requests.post(f"{API}/tenants/{DEMO}/stores/{store_id}/queue/finish-attendance",
                           json={"attendance_id": att_id, "result": "NO_SALE",
                                 "loss_reason_id": lr_id},
                           headers=admin_h, timeout=15)
        assert r2.status_code == 200, r2.text

    def test_invalid_requires_notes(self, admin_h, ctx):
        store_id = ctx["store_id"]
        seller_id, att_id = _ensure_seller_first(admin_h, store_id)
        r = requests.post(f"{API}/tenants/{DEMO}/stores/{store_id}/queue/finish-attendance",
                          json={"attendance_id": att_id, "result": "INVALID"},
                          headers=admin_h, timeout=15)
        assert r.status_code == 400
        r2 = requests.post(f"{API}/tenants/{DEMO}/stores/{store_id}/queue/finish-attendance",
                           json={"attendance_id": att_id, "result": "INVALID",
                                 "notes": "atendimento de teste invalido"},
                           headers=admin_h, timeout=15)
        assert r2.status_code == 200, r2.text


# ===================== Metrics protection =====================
class TestMetrics:
    def test_metrics_no_auth_returns_401(self):
        r = requests.get(f"{API}/metrics", timeout=10)
        assert r.status_code == 401, r.text

    def test_metrics_tenant_admin_returns_403(self, admin_h):
        r = requests.get(f"{API}/metrics", headers=admin_h, timeout=10)
        assert r.status_code == 403, r.text

    def test_metrics_super_admin_returns_200(self, super_token):
        r = requests.get(f"{API}/metrics",
                         headers={"Authorization": f"Bearer {super_token}"}, timeout=10)
        assert r.status_code == 200, r.text
        body = r.json()
        assert "active_websocket_connections" in body
