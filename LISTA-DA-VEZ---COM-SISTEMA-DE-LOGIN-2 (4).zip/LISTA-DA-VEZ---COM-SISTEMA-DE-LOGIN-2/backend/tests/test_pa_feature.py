"""Test PA (Produtos por Atendimento) feature endpoints."""
import pytest
import requests
import os

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")

# Auth headers
def get_admin_token():
    r = requests.post(f"{BASE_URL}/api/tenants/demo/auth/login", json={
        "email": "admin@demo.com", "password": "Admin@123456"
    })
    if r.status_code == 200:
        return r.json().get("access_token") or r.json().get("token")
    return None

@pytest.fixture(scope="module")
def admin_headers():
    token = get_admin_token()
    if not token:
        pytest.skip("Could not authenticate admin")
    return {"Authorization": f"Bearer {token}"}


class TestDashboardPA:
    """Dashboard summary should include pa and total_produtos_vendidos."""

    def test_dashboard_summary_has_pa_field(self, admin_headers):
        r = requests.get(f"{BASE_URL}/api/tenants/demo/dashboard/summary", headers=admin_headers)
        assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text}"
        data = r.json()
        assert "kpis" in data
        kpis = data["kpis"]
        assert "pa" in kpis, f"'pa' not in kpis: {list(kpis.keys())}"
        assert "total_produtos_vendidos" in kpis, f"'total_produtos_vendidos' not in kpis: {list(kpis.keys())}"

    def test_dashboard_pa_is_not_nan(self, admin_headers):
        r = requests.get(f"{BASE_URL}/api/tenants/demo/dashboard/summary", headers=admin_headers)
        assert r.status_code == 200
        pa_val = r.json()["kpis"]["pa"]
        assert pa_val is not None
        assert isinstance(pa_val, (int, float))
        # PA must be 0.0 or positive, never negative
        assert pa_val >= 0.0


class TestMyPerformancePA:
    """my-performance endpoint should include pa and total_produtos_vendidos."""

    def test_my_performance_with_seller(self):
        r = requests.post(f"{BASE_URL}/api/tenants/demo/auth/login", json={
            "email": "admin@demo.com", "password": "Admin@123456"
        })
        token = r.json().get("access_token") or r.json().get("token")
        headers = {"Authorization": f"Bearer {token}"}

        # Get sellers list to find one with a user
        sellers_r = requests.get(f"{BASE_URL}/api/tenants/demo/sellers", headers=headers)
        if sellers_r.status_code != 200 or not sellers_r.json():
            pytest.skip("No sellers found")

        sellers = sellers_r.json()
        # Try to find a seller user
        seller_user = sellers[0] if sellers else None
        if not seller_user:
            pytest.skip("No seller profiles found")

        # Try login as first seller's email (using seed default password)
        user_r = requests.get(f"{BASE_URL}/api/tenants/demo/users", headers=headers)
        if user_r.status_code != 200:
            pytest.skip("Cannot fetch users")

        # Find the user linked to this seller
        seller_user_id = seller_user.get("user_id")
        all_users = user_r.json()
        target_user = next((u for u in all_users if u["id"] == seller_user_id), None)
        if not target_user:
            pytest.skip("Could not find user for seller")

        seller_email = target_user.get("email")
        seller_login = requests.post(f"{BASE_URL}/api/auth/login", json={
            "email": seller_email, "password": "Admin@123456"
        })
        if seller_login.status_code != 200:
            pytest.skip(f"Could not login as seller: {seller_email}")

        seller_token = seller_login.json().get("access_token") or seller_login.json().get("token")
        seller_headers = {"Authorization": f"Bearer {seller_token}"}

        r = requests.get(f"{BASE_URL}/api/tenants/demo/my-performance", headers=seller_headers)
        assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text}"
        data = r.json()
        kpis = data.get("kpis", {})
        assert "pa" in kpis, f"'pa' missing from kpis: {list(kpis.keys())}"
        assert "total_produtos_vendidos" in kpis, f"'total_produtos_vendidos' missing from kpis"
        assert kpis["pa"] >= 0.0


class TestReportPA:
    """Report /pa endpoint tests."""

    def test_report_pa_returns_200(self, admin_headers):
        r = requests.get(f"{BASE_URL}/api/tenants/demo/reports/pa", headers=admin_headers)
        assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text}"

    def test_report_pa_has_total_and_by_seller(self, admin_headers):
        r = requests.get(f"{BASE_URL}/api/tenants/demo/reports/pa", headers=admin_headers)
        assert r.status_code == 200
        data = r.json()
        assert "total" in data, f"'total' missing: {list(data.keys())}"
        assert "by_seller" in data, f"'by_seller' missing: {list(data.keys())}"
        assert isinstance(data["by_seller"], list)

    def test_report_pa_total_has_required_fields(self, admin_headers):
        r = requests.get(f"{BASE_URL}/api/tenants/demo/reports/pa", headers=admin_headers)
        assert r.status_code == 200
        total = r.json()["total"]
        required = ["pa", "total_atendimentos", "atendimentos_com_venda", "total_produtos", "conversao_pct", "total_vendido_cents"]
        for field in required:
            assert field in total, f"Field '{field}' missing from total: {list(total.keys())}"

    def test_report_pa_pa_is_zero_not_nan(self, admin_headers):
        """PA must be 0.0 when no sales with product_quantity, never NaN."""
        r = requests.get(f"{BASE_URL}/api/tenants/demo/reports/pa", headers=admin_headers)
        assert r.status_code == 200
        total = r.json()["total"]
        pa = total["pa"]
        assert pa is not None
        assert isinstance(pa, (int, float))
        assert pa >= 0.0

    def test_report_pa_with_date_filters(self, admin_headers):
        r = requests.get(
            f"{BASE_URL}/api/tenants/demo/reports/pa?date_start=2024-01-01&date_end=2024-12-31",
            headers=admin_headers
        )
        assert r.status_code == 200, f"Date filter caused error: {r.status_code}: {r.text}"

    def test_report_pa_by_seller_fields(self, admin_headers):
        """If by_seller has data, check required fields exist on each row."""
        r = requests.get(f"{BASE_URL}/api/tenants/demo/reports/pa", headers=admin_headers)
        assert r.status_code == 200
        by_seller = r.json()["by_seller"]
        if by_seller:
            row = by_seller[0]
            expected = ["seller_id", "seller_name", "pa", "total_atendimentos", "atendimentos_com_venda", "total_produtos"]
            for field in expected:
                assert field in row, f"Field '{field}' missing from by_seller row: {list(row.keys())}"

    def test_report_pa_no_500_with_store_filter(self, admin_headers):
        """Try with a fake store_id - should return 403 or 200 (not 500)."""
        r = requests.get(
            f"{BASE_URL}/api/tenants/demo/reports/pa?store_id=nonexistent",
            headers=admin_headers
        )
        assert r.status_code in [200, 403, 404], f"Unexpected error: {r.status_code}: {r.text}"
