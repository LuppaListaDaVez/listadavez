"""Tests for product_quantity field in finish-attendance and quick-attendance endpoints"""
import pytest
import requests
import os

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', '').rstrip('/')
TENANT_SLUG = "demo"

@pytest.fixture(scope="module")
def auth_token():
    r = requests.post(f"{BASE_URL}/api/tenants/demo/auth/login", json={"email": "admin@demo.com", "password": "Admin@123456"})
    assert r.status_code == 200, f"Login failed: {r.text}"
    data = r.json()
    return data.get("access_token") or data.get("token")

@pytest.fixture(scope="module")
def store_id(auth_token):
    r = requests.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores", headers={"Authorization": f"Bearer {auth_token}"})
    assert r.status_code == 200
    stores = r.json()
    assert len(stores) > 0, "No stores found"
    return stores[0]["id"]

@pytest.fixture(scope="module")
def seller_id(auth_token, store_id):
    r = requests.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store_id}/sellers", headers={"Authorization": f"Bearer {auth_token}"})
    assert r.status_code == 200
    sellers = r.json()
    assert len(sellers) > 0
    return sellers[0]["id"]

class TestFinishAttendanceWithProductQuantity:
    """Test finish-attendance with product_quantity field"""

    def test_quick_attendance_sale_with_product_quantity(self, auth_token, store_id, seller_id):
        """Quick attendance SALE includes product_quantity persisted"""
        payload = {
            "seller_id": seller_id,
            "result": "SALE",
            "customer_name": "TEST_Cliente Qty",
            "sale_amount_cents": 10000,
            "product_quantity": 5,
            "notes": "test product_quantity"
        }
        r = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store_id}/queue/quick-attendance",
            json=payload,
            headers={"Authorization": f"Bearer {auth_token}"}
        )
        assert r.status_code == 200, f"Quick attendance failed: {r.text}"
        data = r.json()
        print(f"Quick attendance SALE response: {data}")

    def test_quick_attendance_no_sale(self, auth_token, store_id, seller_id):
        """Quick attendance NO_SALE without product_quantity"""
        payload = {
            "seller_id": seller_id,
            "result": "NO_SALE",
            "customer_name": "TEST_Cliente NoSale",
        }
        r = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store_id}/queue/quick-attendance",
            json=payload,
            headers={"Authorization": f"Bearer {auth_token}"}
        )
        # May fail if loss_reason required - that's ok
        print(f"NO_SALE response: {r.status_code} {r.text[:200]}")
        assert r.status_code in [200, 422], f"Unexpected status: {r.text}"

    def test_models_accept_product_quantity_field(self, auth_token, store_id):
        """Verify models accept product_quantity via quick attendance"""
        payload = {
            "seller_id": "invalid_id",
            "result": "SALE",
            "product_quantity": 3,
            "sale_amount_cents": 5000
        }
        r = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store_id}/queue/quick-attendance",
            json=payload,
            headers={"Authorization": f"Bearer {auth_token}"}
        )
        # Should not get 422 (validation error) for product_quantity field
        assert r.status_code != 422, f"product_quantity field rejected by model: {r.text}"
        print(f"Model accepts product_quantity: status={r.status_code}")
