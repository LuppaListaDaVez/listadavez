"""P2-B feature tests: API clients, use cases, graceful shutdown, metrics, docs"""
import pytest
import requests
import os
import subprocess

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")


@pytest.fixture(scope="module")
def superadmin_token():
    r = requests.post(f"{BASE_URL}/api/auth/login", json={"email": "admin@listadavez.com", "password": "Admin@123456"})
    assert r.status_code == 200
    return r.json()["access_token"]


@pytest.fixture(scope="module")
def admin_token():
    r = requests.post(f"{BASE_URL}/api/v1/tenants/demo/auth/login", json={"email": "admin@demo.com", "password": "Admin@123456"})
    assert r.status_code == 200
    return r.json()["access_token"]


class TestAPIVersion:
    """API version and root endpoints"""

    def test_health_ready_returns_redis_connected(self):
        r = requests.get(f"{BASE_URL}/api/v1/health/ready")
        assert r.status_code == 200
        data = r.json()
        assert data.get("redis") == "connected"
        assert data.get("db") == "connected"
        print(f"PASS: health/ready = {data}")

    def test_root_api_version(self):
        # /api/ may return version field
        r = requests.get(f"{BASE_URL}/api/")
        # Could be 200 or 404 — just check if present
        if r.status_code == 200:
            data = r.json()
            version = data.get("version", "N/A")
            print(f"PASS: /api/ version = {version}")
        else:
            print(f"INFO: /api/ returned {r.status_code} — checking /api/health/")
            r2 = requests.get(f"{BASE_URL}/api/health/")
            assert r2.status_code == 200
            print(f"PASS: /api/health/ = {r2.json()}")


class TestV1Routes:
    """API v1 routing"""

    def test_v1_stores(self, admin_token):
        r = requests.get(f"{BASE_URL}/api/v1/tenants/demo/stores", headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, list)
        assert len(data) > 0
        print(f"PASS: /api/v1/tenants/demo/stores returns {len(data)} stores")


class TestPrometheusMetrics:
    """Prometheus metrics endpoint"""

    def test_prometheus_unauthorized(self):
        r = requests.get(f"{BASE_URL}/api/metrics/prometheus")
        assert r.status_code in [401, 403]
        print(f"PASS: prometheus unauthenticated = {r.status_code}")

    def test_prometheus_with_superadmin(self, superadmin_token):
        r = requests.get(f"{BASE_URL}/api/metrics/prometheus", headers={"Authorization": f"Bearer {superadmin_token}"})
        assert r.status_code == 200
        assert "# HELP" in r.text or "# TYPE" in r.text
        print(f"PASS: prometheus text format confirmed (chars: {len(r.text)})")


class TestFrontendAPIClients:
    """Check frontend API client files exist"""

    def test_api_files_exist(self):
        base = "/app/frontend/src/api"
        for fname in ["queue.js", "sales.js", "notifications.js", "reports.js", "auth.js", "dashboard.js", "index.js"]:
            path = f"{base}/{fname}"
            assert os.path.exists(path), f"Missing: {path}"
        print("PASS: All 7 API client files exist")

    def test_reports_api_uses_reportsApi(self):
        with open("/app/frontend/src/hooks/useAsyncExport.js") as f:
            content = f.read()
        assert "reportsApi" in content
        assert "from \"@/api/reports\"" in content or "from '@/api/reports'" in content
        print("PASS: useAsyncExport.js uses reportsApi from @/api/reports")


class TestDocs:
    """Documentation files"""

    def test_docs_exist(self):
        for fname in ["sharding-strategy.md", "autoscaling.md", "governance-guide.md"]:
            path = f"/app/docs/{fname}"
            assert os.path.exists(path), f"Missing: {path}"
            assert os.path.getsize(path) > 0, f"Empty: {path}"
        print("PASS: All 3 docs exist")


class TestGracefulShutdown:
    """Graceful shutdown verification"""

    def test_shutdown_complete_in_logs(self):
        result = subprocess.run(
            ["grep", "-c", "SHUTDOWN_COMPLETE", "/var/log/supervisor/backend.out.log"],
            capture_output=True, text=True
        )
        count = int(result.stdout.strip()) if result.returncode == 0 else 0
        assert count > 0, "SHUTDOWN_COMPLETE not found in backend logs"
        print(f"PASS: SHUTDOWN_COMPLETE found {count} times in logs")

    def test_close_all_in_realtime(self):
        with open("/app/backend/realtime.py") as f:
            content = f.read()
        assert "close_all" in content
        print("PASS: close_all() present in realtime.py")

    def test_shutdown_complete_in_server(self):
        with open("/app/backend/server.py") as f:
            content = f.read()
        assert "SHUTDOWN_COMPLETE" in content
        print("PASS: SHUTDOWN_COMPLETE log present in server.py")


class TestNewUseCasesImportable:
    """New use cases P2-B"""

    def test_goals_use_case_importable(self):
        """Verify CreateGoalUseCase imports properly (permissions ok)"""
        import sys
        sys.path.insert(0, "/app/backend")
        # Goals use case should import P_GOALS_CREATE which exists
        try:
            from application.goals import CreateGoalUseCase
            print("PASS: CreateGoalUseCase importable")
        except ImportError as e:
            pytest.fail(f"CreateGoalUseCase ImportError: {e}")

    def test_notifications_use_case_permission_missing(self):
        """CreateNotificationUseCase has P_NOTIFICATIONS_SEND missing from permissions.py — known issue"""
        import sys
        sys.path.insert(0, "/app/backend")
        try:
            from application.notifications import CreateNotificationUseCase
            print("PASS: CreateNotificationUseCase importable")
        except ImportError as e:
            pytest.fail(f"ImportError: {e}")

    def test_rankings_use_case_permission_missing(self):
        """GenerateRankingUseCase imports P_RANKINGS_VIEW which doesn't exist — known issue"""
        import sys
        sys.path.insert(0, "/app/backend")
        try:
            from application.rankings import GenerateRankingUseCase
            print("PASS: GenerateRankingUseCase importable")
        except ImportError as e:
            pytest.fail(f"ImportError: {e}")


class TestP0Regression:
    """P0/P1 regression checks"""

    def test_login_demo_admin(self):
        r = requests.post(f"{BASE_URL}/api/v1/tenants/demo/auth/login", json={"email": "admin@demo.com", "password": "Admin@123456"})
        assert r.status_code == 200
        assert "access_token" in r.json()
        print("PASS: demo admin login")

    def test_queue_state(self, admin_token):
        r = requests.get(f"{BASE_URL}/api/v1/tenants/demo/queue/state", headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code in [200, 404]
        print(f"PASS: queue state = {r.status_code}")
