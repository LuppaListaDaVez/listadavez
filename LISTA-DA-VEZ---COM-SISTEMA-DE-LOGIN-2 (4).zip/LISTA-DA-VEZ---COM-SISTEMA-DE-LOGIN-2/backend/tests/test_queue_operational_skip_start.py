"""Queue start-attendance rules with operational skip behavior.

Covers:
- SELLER can start from position 2 when all earlier sellers are em_atividade_operacional
- SELLER remains blocked when an earlier seller is not operational
- SELLER in em_atividade_operacional cannot start own attendance
"""
import os
import pytest
import requests


BASE_URL = os.environ.get("REACT_APP_BACKEND_URL")
TENANT_SLUG = "demo"


def _assert_env():
    assert BASE_URL, "REACT_APP_BACKEND_URL is required"


def _h(token):
    return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}


def _login(email: str, password: str, tenant_slug: str | None = None) -> str:
    _assert_env()
    payload = {"email": email, "password": password}
    url = f"{BASE_URL.rstrip('/')}/api/auth/login"
    if tenant_slug:
        url = f"{BASE_URL.rstrip('/')}/api/tenants/{tenant_slug}/auth/login"
    r = requests.post(url, json=payload, timeout=20)
    assert r.status_code == 200, f"login failed for {email}: {r.status_code} {r.text}"
    data = r.json()
    token = data.get("access_token")
    assert isinstance(token, str) and len(token) > 20
    return token


def _get_store_id(admin_token: str) -> str:
    r = requests.get(f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT_SLUG}/stores", headers=_h(admin_token), timeout=20)
    assert r.status_code == 200, r.text
    stores = r.json()
    assert isinstance(stores, list) and len(stores) > 0
    store = next((s for s in stores if s.get("code") == "CENTRO"), stores[0])
    assert store.get("id")
    return store["id"]


def _get_sellers_by_email(admin_token: str, store_id: str) -> dict:
    r = requests.get(
        f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT_SLUG}/sellers?store_id={store_id}",
        headers=_h(admin_token),
        timeout=20,
    )
    assert r.status_code == 200, r.text
    items = r.json()
    out = {}
    for s in items:
        email = ((s.get("user") or {}).get("email") or s.get("email") or "").lower()
        if email:
            out[email] = s
    return out


def _queue_state(admin_token: str, store_id: str) -> dict:
    r = requests.get(
        f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT_SLUG}/stores/{store_id}/queue",
        headers=_h(admin_token),
        timeout=20,
    )
    assert r.status_code == 200, r.text
    data = r.json()
    assert "queue" in data and "entries" in data
    return data


def _ensure_entry_not_operational(admin_token: str, store_id: str, seller_id: str, queue_id: str):
    st = _queue_state(admin_token, store_id)
    entry = next((e for e in st.get("entries", []) if e.get("seller_id") == seller_id), None)
    if entry and entry.get("em_atividade_operacional"):
        requests.post(
            f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT_SLUG}/stores/{store_id}/queue/retornar-operacao",
            headers=_h(admin_token),
            json={"seller_id": seller_id, "queue_id": queue_id},
            timeout=20,
        )


def _best_effort_cleanup(admin_token: str, store_id: str, seller_ids: list[str]):
    # Clear waiting entries from default queue to keep tests deterministic
    st = requests.get(
        f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT_SLUG}/stores/{store_id}/queue",
        headers=_h(admin_token),
        timeout=20,
    )
    if st.status_code == 200:
        data = st.json()
        for e in data.get("entries") or []:
            sid = e.get("seller_id") if isinstance(e, dict) else None
            if sid:
                requests.post(
                    f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT_SLUG}/stores/{store_id}/queue/leave",
                    headers=_h(admin_token),
                    json={"seller_id": sid, "queue_id": data.get("queue", {}).get("id")},
                    timeout=20,
                )

    # Cancel any IN_PROGRESS attendance for targeted sellers
    atts = requests.get(
        f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT_SLUG}/attendances?status=IN_PROGRESS",
        headers=_h(admin_token),
        timeout=20,
    )
    if atts.status_code == 200:
        payload = atts.json()
        if isinstance(payload, dict):
            items = payload.get("items") or payload.get("data") or []
        elif isinstance(payload, list):
            items = payload
        else:
            items = []
        for a in items:
            if not isinstance(a, dict):
                continue
            if a.get("seller_id") in seller_ids:
                requests.post(
                    f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT_SLUG}/attendances/{a['id']}/cancel",
                    headers=_h(admin_token),
                    json={"reason": "TEST_cleanup"},
                    timeout=20,
                )

    # Remove from operational flag when applicable
    for sid in seller_ids:
        requests.post(
            f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT_SLUG}/stores/{store_id}/queue/retornar-operacao",
            headers=_h(admin_token),
            json={"seller_id": sid},
            timeout=20,
        )

    # Remove from queue if waiting
    for sid in seller_ids:
        requests.post(
            f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT_SLUG}/stores/{store_id}/queue/leave",
            headers=_h(admin_token),
            json={"seller_id": sid},
            timeout=20,
        )

    # Force AVAILABLE
    for sid in seller_ids:
        requests.post(
            f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT_SLUG}/stores/{store_id}/queue/return",
            headers=_h(admin_token),
            json={"seller_id": sid, "join_queue": False},
            timeout=20,
        )


@pytest.fixture(scope="session")
def admin_token():
    return _login("admin@demo.com", "Admin@123456", TENANT_SLUG)


@pytest.fixture(scope="session")
def joao_token():
    return _login("joao@demo.com", "Admin@123456", TENANT_SLUG)


@pytest.fixture(scope="session")
def carlos_token():
    return _login("carlos@demo.com", "Admin@123456", TENANT_SLUG)


@pytest.fixture(scope="session")
def test_ctx(admin_token):
    store_id = _get_store_id(admin_token)
    sellers = _get_sellers_by_email(admin_token, store_id)
    assert "joao@demo.com" in sellers, "missing joao@demo.com"
    assert "carlos@demo.com" in sellers, "missing carlos@demo.com"
    return {
        "store_id": store_id,
        "joao_id": sellers["joao@demo.com"]["id"],
        "carlos_id": sellers["carlos@demo.com"]["id"],
    }


@pytest.fixture(autouse=True)
def reset_state(admin_token, test_ctx):
    seller_ids = [test_ctx["joao_id"], test_ctx["carlos_id"]]
    _best_effort_cleanup(admin_token, test_ctx["store_id"], seller_ids)
    yield
    _best_effort_cleanup(admin_token, test_ctx["store_id"], seller_ids)


class TestQueueOperationalSkipStart:
    def test_seller_can_start_when_previous_is_operational(self, admin_token, carlos_token, test_ctx):
        store_id = test_ctx["store_id"]
        joao_id = test_ctx["joao_id"]
        carlos_id = test_ctx["carlos_id"]

        # Join João then Carlos
        r1 = requests.post(
            f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT_SLUG}/stores/{store_id}/queue/join",
            headers=_h(admin_token),
            json={"seller_id": joao_id},
            timeout=20,
        )
        assert r1.status_code == 200, r1.text
        r2 = requests.post(
            f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT_SLUG}/stores/{store_id}/queue/join",
            headers=_h(admin_token),
            json={"seller_id": carlos_id},
            timeout=20,
        )
        assert r2.status_code == 200, r2.text

        st = _queue_state(admin_token, store_id)
        queue_id = st["queue"]["id"]
        entries = st["entries"]
        joao_entry = next(e for e in entries if e["seller_id"] == joao_id)
        carlos_entry = next(e for e in entries if e["seller_id"] == carlos_id)
        assert joao_entry["position"] == 1
        assert carlos_entry["position"] == 2

        # João goes to operational activity while still in queue
        rop = requests.post(
            f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT_SLUG}/stores/{store_id}/queue/sair-da-fila",
            headers=_h(admin_token),
            json={"seller_id": joao_id, "queue_id": queue_id, "motivo": "ATIVIDADE_OPERACIONAL"},
            timeout=20,
        )
        assert rop.status_code == 200, rop.text
        rop_data = rop.json()
        joao_entry = next(e for e in rop_data["entries"] if e["seller_id"] == joao_id)
        assert joao_entry["em_atividade_operacional"] is True

        # Carlos (SELLER) starts own attendance from position 2
        rs = requests.post(
            f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT_SLUG}/stores/{store_id}/queue/start-attendance",
            headers=_h(carlos_token),
            json={"seller_id": carlos_id, "queue_id": queue_id},
            timeout=20,
        )
        assert rs.status_code == 200, rs.text
        data = rs.json()
        assert data["attendance"]["seller_id"] == carlos_id
        assert data["attendance"]["status"] == "IN_PROGRESS"
        assert any(s["seller_id"] == carlos_id for s in data["state"].get("serving_sellers", []))

    def test_seller_blocked_when_previous_not_operational(self, admin_token, carlos_token, test_ctx):
        store_id = test_ctx["store_id"]
        joao_id = test_ctx["joao_id"]
        carlos_id = test_ctx["carlos_id"]

        r1 = requests.post(
            f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT_SLUG}/stores/{store_id}/queue/join",
            headers=_h(admin_token),
            json={"seller_id": joao_id},
            timeout=20,
        )
        assert r1.status_code == 200, r1.text
        r2 = requests.post(
            f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT_SLUG}/stores/{store_id}/queue/join",
            headers=_h(admin_token),
            json={"seller_id": carlos_id},
            timeout=20,
        )
        assert r2.status_code == 200, r2.text

        st = _queue_state(admin_token, store_id)
        queue_id = st["queue"]["id"]
        _ensure_entry_not_operational(admin_token, store_id, joao_id, queue_id)
        st = _queue_state(admin_token, store_id)
        joao_entry = next(e for e in st["entries"] if e["seller_id"] == joao_id)
        carlos_entry = next(e for e in st["entries"] if e["seller_id"] == carlos_id)
        assert joao_entry["position"] == 1
        assert carlos_entry["position"] == 2
        assert joao_entry.get("em_atividade_operacional") is False

        rs = requests.post(
            f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT_SLUG}/stores/{store_id}/queue/start-attendance",
            headers=_h(carlos_token),
            json={"seller_id": carlos_id, "queue_id": queue_id},
            timeout=20,
        )
        assert rs.status_code == 409
        err = rs.json()
        detail = err.get("detail") if isinstance(err, dict) else None
        if isinstance(detail, dict):
            assert detail.get("error") == "SELLER_NOT_FIRST_IN_QUEUE"

    def test_operational_seller_cannot_start_self(self, admin_token, joao_token, test_ctx):
        store_id = test_ctx["store_id"]
        joao_id = test_ctx["joao_id"]

        r1 = requests.post(
            f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT_SLUG}/stores/{store_id}/queue/join",
            headers=_h(admin_token),
            json={"seller_id": joao_id},
            timeout=20,
        )
        assert r1.status_code == 200, r1.text

        st = _queue_state(admin_token, store_id)
        queue_id = st["queue"]["id"]

        rop = requests.post(
            f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT_SLUG}/stores/{store_id}/queue/sair-da-fila",
            headers=_h(admin_token),
            json={"seller_id": joao_id, "queue_id": queue_id, "motivo": "ATIVIDADE_OPERACIONAL"},
            timeout=20,
        )
        assert rop.status_code == 200, rop.text

        rs = requests.post(
            f"{BASE_URL.rstrip('/')}/api/tenants/{TENANT_SLUG}/stores/{store_id}/queue/start-attendance",
            headers=_h(joao_token),
            json={"seller_id": joao_id, "queue_id": queue_id},
            timeout=20,
        )
        assert rs.status_code == 409
        err = rs.json()
        detail = err.get("detail") if isinstance(err, dict) else None
        if isinstance(detail, dict):
            assert detail.get("error") == "EM_ATIVIDADE_OPERACIONAL"
