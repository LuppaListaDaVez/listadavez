"""Tests for queue finish-attendance and auto-create products (iteration 21)."""
import pytest
import requests
import os
import time

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")
TENANT = "demo"
STORE_ID = "a42b1816-430f-490a-ab8f-10e111ad5990"


@pytest.fixture(scope="module")
def token():
    r = requests.post(f"{BASE_URL}/api/tenants/{TENANT}/auth/login",
                      json={"email": "admin@demo.com", "password": "Admin@123456"})
    assert r.status_code == 200, f"Login failed: {r.text}"
    return r.json()["access_token"]


@pytest.fixture(scope="module")
def headers(token):
    return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}


@pytest.fixture(scope="module")
def seller_id(headers):
    """Get or find an available/queued seller_id from state."""
    r = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/stores/{STORE_ID}/queue", headers=headers)
    assert r.status_code == 200
    state = r.json()
    # Try available sellers first
    for s in (state.get("available_sellers") or []):
        return s["seller_id"]
    for e in (state.get("entries") or []):
        return e["seller_id"]
    pytest.skip("No sellers found in queue state")


def start_attendance(headers, seller_id, queue_id):
    """Helper: join queue and start attendance, return attendance_id."""
    # Join queue
    r = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT}/stores/{STORE_ID}/queue/join",
        json={"queue_id": queue_id, "seller_id": seller_id},
        headers=headers,
    )
    # Ignore error if already in queue
    # Start attendance
    r2 = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT}/stores/{STORE_ID}/queue/start-attendance",
        json={"queue_id": queue_id, "seller_id": seller_id},
        headers=headers,
    )
    if r2.status_code not in (200, 201):
        return None
    return r2.json().get("id")


@pytest.fixture(scope="module")
def queue_id(headers):
    r = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/stores/{STORE_ID}/queue", headers=headers)
    assert r.status_code == 200
    return r.json().get("queue", {}).get("id")


# --- Test 1: POST /products creates product ---
def test_create_product(headers):
    unique_name = f"TEST_Produto_{int(time.time())}"
    r = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT}/products",
        json={"name": unique_name, "price_cents": 9990},
        headers=headers,
    )
    assert r.status_code == 201, f"Expected 201, got {r.status_code}: {r.text}"
    data = r.json()
    assert data["name"] == unique_name
    assert data["price_cents"] == 9990
    assert "id" in data
    # Verify GET
    r2 = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/products/{data['id']}", headers=headers)
    assert r2.status_code == 200
    assert r2.json()["name"] == unique_name


# --- Test 2: Finish attendance with simple sale_amount_cents ---
def test_finish_attendance_simple_sale(headers, seller_id, queue_id):
    att_id = start_attendance(headers, seller_id, queue_id)
    if not att_id:
        pytest.skip("Could not start attendance")
    r = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT}/stores/{STORE_ID}/queue/finish-attendance",
        json={"attendance_id": att_id, "result": "SALE", "sale_amount_cents": 15000},
        headers={**headers, "Idempotency-Key": f"test-simple-{att_id}"},
    )
    assert r.status_code in (200, 201), f"Expected 200/201, got {r.status_code}: {r.text}"
    data = r.json()
    assert data.get("result") == "SALE" or "id" in data


# --- Test 3: Finish attendance without sale_amount or items returns error ---
def test_finish_attendance_no_amount_no_items(headers, seller_id, queue_id):
    att_id = start_attendance(headers, seller_id, queue_id)
    if not att_id:
        pytest.skip("Could not start attendance")
    r = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT}/stores/{STORE_ID}/queue/finish-attendance",
        json={"attendance_id": att_id, "result": "SALE"},
        headers={**headers, "Idempotency-Key": f"test-noamount-{att_id}"},
    )
    # Should succeed at backend level with null sale_amount - frontend validates
    # Backend itself doesn't enforce sale_amount for SALE result
    # Just verify we get a response
    assert r.status_code in (200, 201, 400, 422), f"Unexpected status: {r.status_code}: {r.text}"


# --- Test 4: Finish attendance with detailed sale (items) ---
def test_finish_attendance_with_items(headers, seller_id, queue_id):
    att_id = start_attendance(headers, seller_id, queue_id)
    if not att_id:
        pytest.skip("Could not start attendance")
    sale = {
        "items": [{"product_id": None, "name": "TEST_ItemManual", "quantity": 1, "unit_price_cents": 5000, "discount_cents": 0}],
        "discount_amount_cents": 0,
        "payment_methods": [],
        "notes": None,
    }
    r = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT}/stores/{STORE_ID}/queue/finish-attendance",
        json={"attendance_id": att_id, "result": "SALE", "sale": sale},
        headers={**headers, "Idempotency-Key": f"test-items-{att_id}"},
    )
    assert r.status_code in (200, 201), f"Expected 200/201, got {r.status_code}: {r.text}"


# --- Test 5: List products after tests ---
def test_list_products(headers):
    r = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/products", headers=headers)
    assert r.status_code == 200
    data = r.json()
    assert isinstance(data, list)
    print(f"Products count: {len(data)}")
