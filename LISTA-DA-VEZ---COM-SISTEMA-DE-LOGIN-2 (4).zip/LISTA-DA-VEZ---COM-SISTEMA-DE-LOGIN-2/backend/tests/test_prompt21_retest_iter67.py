"""Reteste Prompt 21: múltiplos atendimentos + relatório de oportunidades."""
import os
import uuid
from datetime import datetime

import pytest
import requests
from dotenv import load_dotenv
from pymongo import MongoClient


load_dotenv("/app/backend/.env")
load_dotenv("/app/frontend/.env")

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL")
TENANT = "demo"


def _base_url() -> str:
    if not BASE_URL:
        pytest.skip("REACT_APP_BACKEND_URL não definido")
    return BASE_URL.rstrip("/")


def _api(path: str) -> str:
    return f"{_base_url()}/api{path}"


def _today() -> str:
    return datetime.utcnow().strftime("%Y-%m-%d")


def _db():
    client = MongoClient(os.environ["MONGO_URL"])
    return client, client[os.environ["DB_NAME"]]


@pytest.fixture(scope="module")
def auth_headers():
    response = requests.post(
        _api(f"/tenants/{TENANT}/auth/login"),
        json={"email": "admin@demo.com", "password": "Admin@123456"},
        timeout=30,
    )
    assert response.status_code == 200, response.text
    return {"Authorization": f"Bearer {response.json()['access_token']}"}


def _ctx(db):
    tenant = db.tenants.find_one({"slug": TENANT}, {"_id": 0})
    assert tenant, "Tenant demo não encontrado"
    store = db.stores.find_one({"tenant_id": tenant["id"]}, {"_id": 0})
    assert store, "Store demo não encontrada"
    queue = db.queues.find_one(
        {"tenant_id": tenant["id"], "store_id": store["id"], "is_default": True},
        {"_id": 0},
    )
    assert queue, "Fila padrão não encontrada"
    return tenant, store, queue


def _seller_by_email(db, tenant_id: str, email: str):
    user = db.users.find_one({"email": email}, {"_id": 0})
    assert user, f"Usuário {email} não encontrado"
    seller = db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": user["id"]}, {"_id": 0})
    assert seller, f"Seller profile de {email} não encontrado"
    return seller


def _first_loss_combo(db, tenant_id: str):
    grupo = db.grupos_motivos_perda.find_one({"empresa_id": tenant_id, "ativo": True}, {"_id": 0})
    if not grupo:
        return None
    sub = db.subgrupos_motivos_perda.find_one(
        {"empresa_id": tenant_id, "grupo_motivo_perda_id": grupo["identificador"], "ativo": True},
        {"_id": 0},
    )
    if not sub:
        return None
    motivo = db.motivos_perda.find_one(
        {"empresa_id": tenant_id, "subgrupo_motivo_perda_id": sub["identificador"], "ativo": True},
        {"_id": 0},
    )
    if not motivo:
        return None
    return {
        "grupo_motivo_perda_id": grupo["identificador"],
        "subgrupo_motivo_perda_id": sub["identificador"],
        "motivo_perda_id": motivo["identificador"],
        "descricao_complementar": "Reteste Prompt 21",
    }


def _cleanup_seller_state(db, tenant_id: str, queue_id: str, seller_id: str):
    db.attendances.update_many(
        {"tenant_id": tenant_id, "seller_id": seller_id, "status": "IN_PROGRESS"},
        {"$set": {"status": "CANCELLED", "notes": "Cleanup reteste Prompt 21"}},
    )
    db.queue_entries.delete_many({"tenant_id": tenant_id, "queue_id": queue_id, "seller_id": seller_id})
    db.seller_profiles.update_one(
        {"tenant_id": tenant_id, "id": seller_id},
        {"$set": {"current_status": "AVAILABLE", "em_atividade_operacional": False, "jornada_encerrada": False, "motivo_saida": None}},
    )


def _start_attendance(headers: dict, store_id: str, queue_id: str, seller_id: str) -> dict:
    requests.post(
        _api(f"/tenants/{TENANT}/stores/{store_id}/queue/join"),
        headers=headers,
        json={"queue_id": queue_id, "seller_id": seller_id},
        timeout=30,
    )
    start = requests.post(
        _api(f"/tenants/{TENANT}/stores/{store_id}/queue/start-attendance"),
        headers=headers,
        json={"queue_id": queue_id, "seller_id": seller_id, "customer_name": "Cliente reteste múltiplos"},
        timeout=40,
    )
    assert start.status_code == 200, start.text
    return start.json()["attendance"]


# Report options validation
def test_opportunity_flow_options_include_multiple(auth_headers):
    response = requests.get(
        _api(f"/tenants/{TENANT}/reports/opportunity-flow/options"),
        headers=auth_headers,
        timeout=40,
    )
    assert response.status_code == 200, response.text
    options = response.json().get("attendance_types") or []
    found = [opt for opt in options if opt.get("id") == "MULTIPLE"]
    assert len(found) == 1
    assert found[0].get("name") == "Múltiplos atendimentos"


# MULTIPLE report must count attendance rows, not batch only
def test_opportunity_flow_multiple_counts_individual_attendances(auth_headers):
    client, db = _db()
    try:
        tenant, store, queue = _ctx(db)
        seller = _seller_by_email(db, tenant["id"], "carlos@demo.com")
        _cleanup_seller_state(db, tenant["id"], queue["id"], seller["id"])
        loss_combo = _first_loss_combo(db, tenant["id"])
        if not loss_combo:
            pytest.skip("Sem hierarquia ativa de motivo de perda")

        params = {
            "date_start": _today(),
            "date_end": _today(),
            "store_id": store["id"],
            "seller_id": seller["id"],
            "attendance_type": "MULTIPLE",
        }
        before = requests.get(_api(f"/tenants/{TENANT}/reports/opportunity-flow"), headers=auth_headers, params=params, timeout=60)
        assert before.status_code == 200, before.text
        before_opp = int(before.json().get("totals", {}).get("opportunities", 0))

        first = _start_attendance(auth_headers, store["id"], queue["id"], seller["id"])
        payload = {
            "attendance_id": first["id"],
            "mode": "AGGREGATED",
            "total_customers": 3,
            "successes": 2,
            "no_sales": 1,
            "total_amount_cents": 30000,
            "total_product_quantity": 6,
            **loss_combo,
        }
        done = requests.post(
            _api(f"/tenants/{TENANT}/stores/{store['id']}/queue/finish-multiple-attendances"),
            headers={**auth_headers, "Idempotency-Key": f"multi-flow-{uuid.uuid4()}"},
            json=payload,
            timeout=70,
        )
        assert done.status_code == 200, done.text

        after = requests.get(_api(f"/tenants/{TENANT}/reports/opportunity-flow"), headers=auth_headers, params=params, timeout=60)
        assert after.status_code == 200, after.text
        after_opp = int(after.json().get("totals", {}).get("opportunities", 0))
        assert after_opp - before_opp == 3
    finally:
        client.close()


# Required scenario + idempotency + queue movement once
def test_multiple_required_scenario_and_idempotency(auth_headers):
    client, db = _db()
    try:
        tenant, store, queue = _ctx(db)
        seller = _seller_by_email(db, tenant["id"], "joao@demo.com")
        _cleanup_seller_state(db, tenant["id"], queue["id"], seller["id"])
        loss_combo = _first_loss_combo(db, tenant["id"])
        if not loss_combo:
            pytest.skip("Sem hierarquia ativa de motivo de perda")

        report_params = {
            "date_start": _today(),
            "date_end": _today(),
            "store_id": store["id"],
            "seller_id": seller["id"],
            "attendance_type": "MULTIPLE",
        }
        report_before = requests.get(_api(f"/tenants/{TENANT}/reports/opportunity-flow"), headers=auth_headers, params=report_params, timeout=60)
        assert report_before.status_code == 200, report_before.text
        before_opp = int(report_before.json().get("totals", {}).get("opportunities", 0))
        before_sales = int(report_before.json().get("totals", {}).get("sales", 0))
        before_revenue = int(report_before.json().get("totals", {}).get("revenue", 0))

        first = _start_attendance(auth_headers, store["id"], queue["id"], seller["id"])
        idem_key = f"multi-required-{uuid.uuid4()}"
        payload = {
            "attendance_id": first["id"],
            "mode": "AGGREGATED",
            "total_customers": 5,
            "successes": 3,
            "no_sales": 2,
            "total_amount_cents": 60000,
            "total_product_quantity": 9,
            "notes": "Cenário obrigatório 5/3/2",
            **loss_combo,
        }
        first_call = requests.post(
            _api(f"/tenants/{TENANT}/stores/{store['id']}/queue/finish-multiple-attendances"),
            headers={**auth_headers, "Idempotency-Key": idem_key},
            json=payload,
            timeout=80,
        )
        assert first_call.status_code == 200, first_call.text
        body = first_call.json()
        batch_id = body["batch"]["id"]

        replay = requests.post(
            _api(f"/tenants/{TENANT}/stores/{store['id']}/queue/finish-multiple-attendances"),
            headers={**auth_headers, "Idempotency-Key": idem_key},
            json=payload,
            timeout=80,
        )
        assert replay.status_code == 200, replay.text
        assert replay.json()["batch"]["id"] == batch_id

        attendances = list(db.attendances.find({"tenant_id": tenant["id"], "multiple_batch_id": batch_id}, {"_id": 0}))
        sales = list(db.sales.find({"tenant_id": tenant["id"], "multiple_batch_id": batch_id}, {"_id": 0}))
        idem_records = list(
            db.idempotency_keys.find(
                {
                    "tenant_id": tenant["id"],
                    "endpoint": "/queue/finish-multiple-attendances",
                    "idempotency_key": idem_key,
                },
                {"_id": 0},
            )
        )

        assert len(attendances) == 5
        assert sum(1 for a in attendances if a.get("result") == "SALE") == 3
        assert sum(1 for a in attendances if a.get("result") == "NO_SALE") == 2
        assert len(sales) == 3
        assert sum(int(s.get("net_amount_cents") or 0) for s in sales) == 60000
        assert sum(int(s.get("item_count") or 0) for s in sales) == 9
        assert round(sum(int(s.get("item_count") or 0) for s in sales) / len(attendances), 1) == 1.8
        assert [a["id"] for a in attendances if a.get("multiple_sequence") == 1] == [first["id"]]
        assert len(idem_records) == 1

        waiting_rows = list(
            db.queue_entries.find(
                {
                    "tenant_id": tenant["id"],
                    "queue_id": queue["id"],
                    "seller_id": seller["id"],
                    "status": "WAITING",
                },
                {"_id": 0},
            )
        )
        assert len(waiting_rows) == 1

        report_after = requests.get(_api(f"/tenants/{TENANT}/reports/opportunity-flow"), headers=auth_headers, params=report_params, timeout=60)
        assert report_after.status_code == 200, report_after.text
        totals = report_after.json().get("totals", {})
        assert int(totals.get("opportunities", 0)) - before_opp == 5
        assert int(totals.get("sales", 0)) - before_sales == 3
        assert int(totals.get("revenue", 0)) - before_revenue == 60000
        assert pytest.approx(float(totals.get("conversion_rate", 0)), rel=0, abs=0.01) == 60.0
    finally:
        client.close()