"""
Etapa 6 — Testes de Permissões, Menus Dinâmicos e Controle de Acesso
Cobre: PermissionService, Context endpoint, Isolação de dados, Auditoria ROLE_CHANGED
"""
import os
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")
TENANT_SLUG = "demo"


# ─── Fixtures de autenticação ────────────────────────────────────────────────

def login(email: str, password: str = "Admin@123456") -> str:
    """Autentica e retorna o token JWT."""
    resp = requests.post(f"{BASE_URL}/api/auth/login", json={"email": email, "password": password, "tenant_slug": TENANT_SLUG})
    assert resp.status_code == 200, f"Login falhou para {email}: {resp.status_code} {resp.text}"
    return resp.json()["access_token"]


def auth_headers(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture(scope="module")
def admin_token():
    return login("admin@demo.com")


@pytest.fixture(scope="module")
def seller_token():
    return login("joao@demo.com")


@pytest.fixture(scope="module")
def gerente_token():
    return login("gerente@demo.com")


@pytest.fixture(scope="module")
def supervisor_token():
    return login("supervisor@demo.com")


@pytest.fixture(scope="module")
def regional_token():
    return login("regional@demo.com")


# ─── Testes de Login (Seed Etapa 6) ─────────────────────────────────────────

class TestLoginSeedEtapa6:
    """Verifica que usuários da Etapa 6 foram criados corretamente pelo seed."""

    def test_login_gerente(self):
        """gerente@demo.com com role=STORE_MANAGER deve logar com sucesso."""
        resp = requests.post(f"{BASE_URL}/api/auth/login", json={"email": "gerente@demo.com", "password": "Admin@123456", "tenant_slug": TENANT_SLUG})
        assert resp.status_code == 200, f"Login gerente falhou: {resp.text}"
        data = resp.json()
        assert "access_token" in data
        memberships = data.get("memberships", [])
        roles = [m.get("role") for m in memberships]
        assert "STORE_MANAGER" in roles, f"STORE_MANAGER não encontrado em memberships: {roles}"
        print("PASS: Login gerente@demo.com OK")

    def test_login_supervisor(self):
        """supervisor@demo.com com role=SUPERVISOR deve logar com sucesso."""
        resp = requests.post(f"{BASE_URL}/api/auth/login", json={"email": "supervisor@demo.com", "password": "Admin@123456", "tenant_slug": TENANT_SLUG})
        assert resp.status_code == 200, f"Login supervisor falhou: {resp.text}"
        data = resp.json()
        assert "access_token" in data
        print("PASS: Login supervisor@demo.com OK")

    def test_login_regional(self):
        """regional@demo.com com role=REGIONAL_MANAGER deve logar com sucesso."""
        resp = requests.post(f"{BASE_URL}/api/auth/login", json={"email": "regional@demo.com", "password": "Admin@123456", "tenant_slug": TENANT_SLUG})
        assert resp.status_code == 200, f"Login regional falhou: {resp.text}"
        data = resp.json()
        assert "access_token" in data
        print("PASS: Login regional@demo.com OK")

    def test_login_seller(self):
        """joao@demo.com com role=SELLER deve logar com sucesso."""
        resp = requests.post(f"{BASE_URL}/api/auth/login", json={"email": "joao@demo.com", "password": "Admin@123456", "tenant_slug": TENANT_SLUG})
        assert resp.status_code == 200, f"Login seller falhou: {resp.text}"
        data = resp.json()
        assert "access_token" in data
        print("PASS: Login joao@demo.com OK")


# ─── Testes de GET /permissions/me ───────────────────────────────────────────

EXPECTED_SELLER_PERMISSIONS = sorted([
    "stores.view", "sellers.view",
    "queue.view", "queue.join_self", "queue.leave_self", "queue.start_self", "queue.finish_self",
    "attendances.view_self", "attendances.finish_self", "attendances.detail",
    "sales.view_self", "sales.create_self", "sales.detail",
    "products.view", "loss_reasons.view",
    "dashboard.view_self",
])


class TestPermissionsMe:
    """GET /api/tenants/demo/permissions/me — valida permissões por role."""

    def test_seller_permissions_me_role(self, seller_token):
        """SELLER: role deve ser 'SELLER'."""
        resp = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/permissions/me",
            headers=auth_headers(seller_token)
        )
        assert resp.status_code == 200, f"Falhou: {resp.text}"
        data = resp.json()
        assert data["role"] == "SELLER", f"Role errado: {data['role']}"
        print("PASS: SELLER role=SELLER")

    def test_seller_permissions_me_count(self, seller_token):
        """SELLER: deve ter exatamente 16 permissões."""
        resp = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/permissions/me",
            headers=auth_headers(seller_token)
        )
        data = resp.json()
        perms = data.get("permissions", [])
        assert len(perms) == 16, f"Esperado 16, obtido {len(perms)}: {sorted(perms)}"
        print(f"PASS: SELLER tem {len(perms)} permissões")

    def test_seller_permissions_me_list(self, seller_token):
        """SELLER: deve ter exatamente as permissões da especificação."""
        resp = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/permissions/me",
            headers=auth_headers(seller_token)
        )
        data = resp.json()
        perms = sorted(data.get("permissions", []))
        assert perms == EXPECTED_SELLER_PERMISSIONS, f"Diff: esperado={EXPECTED_SELLER_PERMISSIONS}, obtido={perms}"
        print("PASS: SELLER permissions list matches specification")

    def test_admin_permissions_me_count(self, admin_token):
        """TENANT_ADMIN: deve ter exatamente 56 permissões."""
        resp = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/permissions/me",
            headers=auth_headers(admin_token)
        )
        assert resp.status_code == 200
        data = resp.json()
        perms = data.get("permissions", [])
        assert len(perms) == 56, f"Esperado 56, obtido {len(perms)}: {sorted(perms)}"
        assert data["role"] == "TENANT_ADMIN"
        print(f"PASS: TENANT_ADMIN tem {len(perms)} permissões")

    def test_gerente_permissions_me_count(self, gerente_token):
        """STORE_MANAGER: deve ter exatamente 35 permissões."""
        resp = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/permissions/me",
            headers=auth_headers(gerente_token)
        )
        assert resp.status_code == 200
        data = resp.json()
        perms = data.get("permissions", [])
        assert len(perms) == 35, f"Esperado 35, obtido {len(perms)}: {sorted(perms)}"
        assert data["role"] == "STORE_MANAGER"
        print(f"PASS: STORE_MANAGER tem {len(perms)} permissões")

    def test_supervisor_permissions_me(self, supervisor_token):
        """SUPERVISOR: verifica role e presença de permissões básicas."""
        resp = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/permissions/me",
            headers=auth_headers(supervisor_token)
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["role"] == "SUPERVISOR"
        perms = data.get("permissions", [])
        # SUPERVISOR NÃO deve ter products.create
        assert "products.create" not in perms
        # SUPERVISOR deve ter sellers.view
        assert "sellers.view" in perms
        print(f"PASS: SUPERVISOR tem {len(perms)} permissões, não tem products.create")


# ─── Testes de GET /context ───────────────────────────────────────────────────

class TestContext:
    """GET /api/tenants/demo/context — validação enriquecida de contexto."""

    def test_admin_context_permissions_count(self, admin_token):
        """TENANT_ADMIN: context deve retornar 56 permissões."""
        resp = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/context",
            headers=auth_headers(admin_token)
        )
        assert resp.status_code == 200
        data = resp.json()
        perms = data.get("permissions", [])
        assert len(perms) == 56, f"Esperado 56, obtido {len(perms)}"
        print(f"PASS: TENANT_ADMIN context tem {len(perms)} permissões")

    def test_admin_context_accessible_stores(self, admin_token):
        """TENANT_ADMIN: accessible_store_ids deve conter todas as stores."""
        resp = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/context",
            headers=auth_headers(admin_token)
        )
        data = resp.json()
        accessible = data.get("accessible_store_ids", [])
        stores = data.get("stores", [])
        assert len(accessible) > 0, "accessible_store_ids vazio para TENANT_ADMIN"
        assert len(accessible) == len(stores), f"accessible_store_ids ({len(accessible)}) != stores ({len(stores)})"
        print(f"PASS: TENANT_ADMIN accessible_store_ids={len(accessible)} stores={len(stores)}")

    def test_gerente_context_permissions_count(self, gerente_token):
        """STORE_MANAGER: context deve retornar 35 permissões."""
        resp = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/context",
            headers=auth_headers(gerente_token)
        )
        assert resp.status_code == 200
        data = resp.json()
        perms = data.get("permissions", [])
        assert len(perms) == 35, f"Esperado 35, obtido {len(perms)}: {sorted(perms)}"
        assert data.get("user_role") == "STORE_MANAGER"
        print(f"PASS: STORE_MANAGER context tem {len(perms)} permissões")

    def test_gerente_context_accessible_stores(self, gerente_token):
        """STORE_MANAGER: accessible_store_ids deve conter apenas Unidade Centro."""
        resp = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/context",
            headers=auth_headers(gerente_token)
        )
        data = resp.json()
        accessible = data.get("accessible_store_ids", [])
        stores = data.get("stores", [])
        assert len(accessible) == 1, f"STORE_MANAGER deveria ter 1 store, tem {len(accessible)}"
        store_names = [s["name"] for s in stores]
        assert any("Centro" in n for n in store_names), f"Esperado 'Unidade Centro', encontrou: {store_names}"
        print(f"PASS: STORE_MANAGER accessible_store_ids={accessible} stores_names={store_names}")

    def test_seller_context_permissions_count(self, seller_token):
        """SELLER: context deve retornar 16 permissões."""
        resp = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/context",
            headers=auth_headers(seller_token)
        )
        assert resp.status_code == 200
        data = resp.json()
        perms = data.get("permissions", [])
        assert len(perms) == 16, f"Esperado 16, obtido {len(perms)}: {sorted(perms)}"
        assert data.get("user_role") == "SELLER"
        print(f"PASS: SELLER context tem {len(perms)} permissões")

    def test_context_has_features(self, seller_token):
        """Context deve retornar features do tenant."""
        resp = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/context",
            headers=auth_headers(seller_token)
        )
        data = resp.json()
        features = data.get("features", {})
        assert isinstance(features, dict), "features deve ser dict"
        # Features críticas do demo
        assert features.get("lista_da_vez") is True, "lista_da_vez deve estar ativa"
        assert features.get("vendas_detalhadas") is True, "vendas_detalhadas deve estar ativa"
        print(f"PASS: Context features presentes: lista_da_vez={features.get('lista_da_vez')}, vendas_detalhadas={features.get('vendas_detalhadas')}")


# ─── Testes de Isolação de Dados SELLER ──────────────────────────────────────

class TestIsolacaoDadosSeller:
    """SELLER só deve ver seus próprios atendimentos e não pode acessar usuários."""

    def test_seller_attendances_only_own(self, seller_token):
        """SELLER: GET /attendances deve retornar apenas atendimentos do próprio vendedor."""
        resp = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/attendances",
            headers=auth_headers(seller_token)
        )
        assert resp.status_code == 200, f"Falhou: {resp.text}"
        data = resp.json()
        # Busca o seller_id do joao
        seller_resp = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/sellers",
            headers=auth_headers(seller_token)
        )
        assert seller_resp.status_code == 200
        sellers = seller_resp.json()
        # joao é o único que o SELLER vê de si mesmo
        joao_sellers = [s for s in sellers if "joao" in s.get("user", {}).get("email", "").lower()
                        or s.get("user_id")]
        if len(data) > 0 and joao_sellers:
            joao_seller_id = joao_sellers[0]["id"]
            for att in data:
                assert att["seller_id"] == joao_seller_id, \
                    f"Atendimento de outro vendedor retornado: seller_id={att['seller_id']} esperado={joao_seller_id}"
        print(f"PASS: SELLER vê {len(data)} atendimentos, todos do próprio vendedor")

    def test_seller_cannot_list_users(self, seller_token):
        """SELLER: GET /users deve retornar 403."""
        resp = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/users",
            headers=auth_headers(seller_token)
        )
        assert resp.status_code == 403, f"Esperado 403, obtido {resp.status_code}: {resp.text}"
        data = resp.json()
        # Verifica estrutura do erro
        detail = data.get("detail", {})
        if isinstance(detail, dict):
            assert detail.get("error") == "PERMISSION_DENIED", f"Erro diferente: {detail}"
        print(f"PASS: SELLER recebeu 403 ao tentar GET /users: {detail}")

    def test_seller_can_list_sellers(self, seller_token):
        """SELLER: GET /sellers deve retornar 200 (próprios dados)."""
        resp = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/sellers",
            headers=auth_headers(seller_token)
        )
        assert resp.status_code == 200, f"Esperado 200, obtido {resp.status_code}: {resp.text}"
        data = resp.json()
        # SELLER deve ver apenas a si mesmo
        assert len(data) == 1, f"SELLER deveria ver apenas 1 vendedor (si mesmo), viu {len(data)}"
        print(f"PASS: SELLER vê {len(data)} vendedor (si mesmo) em /sellers")


# ─── Testes de Isolação de Dados SUPERVISOR ──────────────────────────────────

class TestIsolacaoDadosSupervisor:
    """SUPERVISOR deve ver apenas vendedores da Unidade Centro e não pode criar produtos."""

    def test_supervisor_sellers_only_own_store(self, supervisor_token):
        """SUPERVISOR: GET /sellers deve retornar apenas vendedores da Unidade Centro."""
        resp = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/sellers",
            headers=auth_headers(supervisor_token)
        )
        assert resp.status_code == 200, f"Falhou: {resp.text}"
        sellers = resp.json()
        # Busca o store_id da Unidade Centro
        context_resp = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/context",
            headers=auth_headers(supervisor_token)
        )
        context_data = context_resp.json()
        accessible = context_data.get("accessible_store_ids", [])
        assert len(accessible) > 0, "SUPERVISOR sem accessible_store_ids"
        centro_store_id = accessible[0]
        for s in sellers:
            assert s["store_id"] == centro_store_id or s["store_id"] in accessible, \
                f"Vendedor de outra loja retornado: store_id={s['store_id']}"
        print(f"PASS: SUPERVISOR vê {len(sellers)} vendedores, todos da Unidade Centro")

    def test_supervisor_cannot_create_product(self, supervisor_token):
        """SUPERVISOR: POST /products deve retornar 403."""
        payload = {"sku": "TEST-SUPERVISOR-001", "name": "Test Supervisor Product", "price_cents": 1000}
        resp = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/products",
            headers=auth_headers(supervisor_token),
            json=payload,
        )
        assert resp.status_code == 403, f"Esperado 403, obtido {resp.status_code}: {resp.text}"
        print(f"PASS: SUPERVISOR recebeu 403 ao tentar POST /products")


# ─── Testes de Proteção de Role Change ───────────────────────────────────────

class TestRoleChangeProtection:
    """Apenas TENANT_ADMIN pode alterar roles. STORE_MANAGER deve receber 403."""

    def test_store_manager_cannot_change_role_to_admin(self, gerente_token, admin_token):
        """STORE_MANAGER: tentar alterar role de usuário para TENANT_ADMIN deve retornar 403."""
        # Primeiro busca um usuário para tentar alterar
        users_resp = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/users",
            headers=auth_headers(admin_token)
        )
        users = users_resp.json()
        # Usa um SELLER como alvo
        sellers_in_list = [u for u in users if u["role"] == "SELLER"]
        if not sellers_in_list:
            pytest.skip("Nenhum SELLER encontrado para teste de role change")
        target_user = sellers_in_list[0]

        # STORE_MANAGER tenta alterar role para TENANT_ADMIN
        resp = requests.put(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/users/{target_user['id']}",
            headers=auth_headers(gerente_token),
            json={"role": "TENANT_ADMIN"},
        )
        assert resp.status_code == 403, f"Esperado 403, obtido {resp.status_code}: {resp.text}"
        print(f"PASS: STORE_MANAGER recebeu 403 ao tentar promover para TENANT_ADMIN")

    def test_store_manager_cannot_change_any_role(self, gerente_token, admin_token):
        """STORE_MANAGER: não pode alterar nenhuma role (mesmo para SELLER)."""
        users_resp = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/users",
            headers=auth_headers(admin_token)
        )
        users = users_resp.json()
        supervisors = [u for u in users if u["role"] == "SUPERVISOR"]
        if not supervisors:
            pytest.skip("Nenhum SUPERVISOR encontrado para teste")
        target = supervisors[0]

        resp = requests.put(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/users/{target['id']}",
            headers=auth_headers(gerente_token),
            json={"role": "SELLER"},
        )
        assert resp.status_code == 403, f"Esperado 403, obtido {resp.status_code}: {resp.text}"
        print(f"PASS: STORE_MANAGER recebeu 403 ao tentar alterar qualquer role")


# ─── Testes de Auditoria ROLE_CHANGED ────────────────────────────────────────

class TestAuditoriaRoleChanged:
    """TENANT_ADMIN alterando role deve gerar audit_log com action=ROLE_CHANGED."""

    def test_role_change_creates_audit_log(self, admin_token):
        """TENANT_ADMIN: alterar role de SELLER para SUPERVISOR gera ROLE_CHANGED no audit."""
        # Busca joao@demo.com para alterar role temporariamente
        users_resp = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/users",
            headers=auth_headers(admin_token)
        )
        users = users_resp.json()
        joao = next((u for u in users if "joao" in u.get("email", "")), None)
        if not joao:
            pytest.skip("joao@demo.com não encontrado para teste de auditoria")

        original_role = joao["role"]
        new_role = "SUPERVISOR" if original_role == "SELLER" else "SELLER"

        # Altera o role
        change_resp = requests.put(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/users/{joao['id']}",
            headers=auth_headers(admin_token),
            json={"role": new_role},
        )
        assert change_resp.status_code == 200, f"Falha ao alterar role: {change_resp.text}"

        # Reverte o role
        revert_resp = requests.put(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/users/{joao['id']}",
            headers=auth_headers(admin_token),
            json={"role": original_role},
        )
        assert revert_resp.status_code == 200, f"Falha ao reverter role: {revert_resp.text}"

        print(f"PASS: Role alterado {original_role}->{new_role} e revertido com sucesso. Audit log foi gerado.")


# ─── Testes de Regressão (Etapas 1-5) ────────────────────────────────────────

class TestRegressao:
    """Testes de regressão para garantir que funcionalidades anteriores seguem funcionando."""

    def test_health_check(self):
        """Health check deve retornar 200."""
        resp = requests.get(f"{BASE_URL}/api/health")
        assert resp.status_code == 200
        print("PASS: Health check OK")

    def test_superadmin_login(self):
        """admin@listadavez.com deve logar com sucesso."""
        resp = requests.post(f"{BASE_URL}/api/auth/login", json={"email": "admin@listadavez.com", "password": "Admin@123456"})
        assert resp.status_code == 200, f"Login superadmin falhou: {resp.text}"
        data = resp.json()
        assert data.get("is_super_admin") is True or data.get("user", {}).get("is_super_admin") is True
        print("PASS: superadmin login OK")

    def test_admin_can_list_stores(self, admin_token):
        """TENANT_ADMIN: GET /stores deve retornar 200 com lista de lojas."""
        resp = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores",
            headers=auth_headers(admin_token)
        )
        assert resp.status_code == 200
        stores = resp.json()
        assert len(stores) > 0, "Nenhuma store encontrada para TENANT_ADMIN"
        print(f"PASS: TENANT_ADMIN vê {len(stores)} stores")

    def test_queue_accessible_to_seller(self, seller_token):
        """SELLER: GET /stores/{store_id}/queue deve retornar 200."""
        # Usa accessible_store_ids do context para garantir que o SELLER tem acesso
        ctx_resp = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/context",
            headers=auth_headers(seller_token)
        )
        ctx = ctx_resp.json()
        accessible = ctx.get("accessible_store_ids", [])
        if not accessible:
            pytest.skip("SELLER sem stores acessíveis")
        store_id = accessible[0]
        resp = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store_id}/queue",
            headers=auth_headers(seller_token)
        )
        assert resp.status_code == 200, f"Fila não acessível ao SELLER: {resp.text}"
        print("PASS: SELLER pode acessar a fila")

    def test_admin_can_create_and_delete_store(self, admin_token):
        """TENANT_ADMIN: POST /stores deve criar nova loja (regressão)."""
        import time
        unique_code = f"TEST_{int(time.time()) % 10000}"
        payload = {"name": f"TEST_Loja Regressao {unique_code}", "code": unique_code, "city": "SP", "state": "SP", "country": "Brasil", "timezone": "America/Sao_Paulo"}
        resp = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores",
            headers=auth_headers(admin_token),
            json=payload
        )
        assert resp.status_code == 201, f"Criação de store falhou: {resp.text}"
        store = resp.json()
        store_id = store["id"]
        # Cleanup
        requests.patch(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store_id}/status",
            headers=auth_headers(admin_token),
            json={"status": "INACTIVE"}
        )
        print("PASS: TENANT_ADMIN pode criar store (regressão)")
