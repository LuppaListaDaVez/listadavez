"""Etapa 3 — Backend regression tests (Lista da Vez).

Cobre:
- Auth (super admin + tenant admin + sellers)
- GET queue state, queues
- join/leave, mark-away/return
- start/finish attendance (SALE/NO_SALE/INVALID validations)
- reorder permission
- attendance cancel
- feature flag gating
"""
import os
import pytest
import requests

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "https://queue-mgmt-3.preview.emergentagent.com").rstrip("/")
TENANT_SLUG = "demo"
STORE_CODE = "CENTRO"


def _login(email, password, tenant_slug=None):
    payload = {"email": email, "password": password}
    if tenant_slug:
        payload["tenant_slug"] = tenant_slug
    r = requests.post(f"{BASE_URL}/api/auth/login", json=payload, timeout=15)
    assert r.status_code == 200, f"login {email} failed: {r.status_code} {r.text}"
    return r.json()["access_token"]


def _h(token):
    return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}


# ---- session-scoped fixtures ----
@pytest.fixture(scope="session")
def super_token():
    return _login("admin@listadavez.com", "Admin@123456")


@pytest.fixture(scope="session")
def admin_token():
    return _login("admin@demo.com", "Admin@123456", TENANT_SLUG)


@pytest.fixture(scope="session")
def joao_token():
    return _login("joao@demo.com", "Admin@123456", TENANT_SLUG)


@pytest.fixture(scope="session")
def maria_token():
    return _login("maria@demo.com", "Admin@123456", TENANT_SLUG)


@pytest.fixture(scope="session")
def store(admin_token):
    r = requests.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores", headers=_h(admin_token), timeout=15)
    assert r.status_code == 200, r.text
    stores = r.json()
    centro = next((s for s in stores if s.get("code") == STORE_CODE), stores[0])
    return centro


@pytest.fixture(scope="session")
def sellers(admin_token, store):
    r = requests.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/sellers?store_id={store['id']}",
                     headers=_h(admin_token), timeout=15)
    assert r.status_code == 200, r.text
    data = r.json()
    by_email = {((s.get("user") or {}).get("email") or s.get("email") or "").lower(): s for s in data}
    return {
        "all": data,
        "joao": by_email.get("joao@demo.com"),
        "maria": by_email.get("maria@demo.com"),
    }


def _reset_seller_to_available(admin_token, store_id, seller_id):
    """Tenta levar o seller para AVAILABLE via /queue/return (idempotente)."""
    requests.post(
        f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store_id}/queue/return",
        headers=_h(admin_token),
        json={"seller_id": seller_id, "join_queue": False},
        timeout=15,
    )


@pytest.fixture(autouse=True)
def _restore_state(admin_token, store, sellers):
    """Antes de cada teste: garante João e Maria fora da fila e AVAILABLE."""
    for key in ("joao", "maria"):
        s = sellers.get(key)
        if not s:
            continue
        # Cancelar atendimento em aberto se existir
        atts = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/attendances?status=IN_PROGRESS",
            headers=_h(admin_token),
            timeout=15,
        ).json()
        for a in atts or []:
            if a.get("seller_id") == s["id"]:
                requests.post(
                    f"{BASE_URL}/api/tenants/{TENANT_SLUG}/attendances/{a['id']}/cancel",
                    headers=_h(admin_token),
                    json={"reason": "reset suite"},
                    timeout=15,
                )
        # leave queue (best effort) e return AVAILABLE
        requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store['id']}/queue/leave",
            headers=_h(admin_token),
            json={"seller_id": s["id"]},
            timeout=15,
        )
        _reset_seller_to_available(admin_token, store["id"], s["id"])
    yield


# ---- Tests ----
class TestAuthAndHealth:
    def test_health(self):
        r = requests.get(f"{BASE_URL}/api/health", timeout=10)
        assert r.status_code == 200

    def test_super_login(self, super_token):
        assert isinstance(super_token, str) and len(super_token) > 20

    def test_tenant_admin_me(self, admin_token):
        r = requests.get(f"{BASE_URL}/api/auth/me", headers=_h(admin_token), timeout=10)
        assert r.status_code == 200
        body = r.json()
        # accept various shapes
        email = (body.get("user") or body).get("email") if isinstance(body, dict) else None
        assert (body.get("email") or email) == "admin@demo.com"


class TestQueueState:
    def test_get_queue_state(self, admin_token, store):
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store['id']}/queue",
                         headers=_h(admin_token), timeout=15)
        assert r.status_code == 200, r.text
        data = r.json()
        for k in ("queue", "entries", "available_sellers", "serving_sellers",
                  "away_sellers", "active_attendances", "recent_events", "queues"):
            assert k in data, f"missing key {k}"
        assert data["queue"]["name"]  # default queue exists

    def test_list_queues(self, admin_token, store):
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store['id']}/queues",
                         headers=_h(admin_token), timeout=15)
        assert r.status_code == 200
        assert any(q.get("is_default") for q in r.json())


class TestJoinLeave:
    def test_join_then_leave(self, admin_token, store, sellers):
        joao = sellers["joao"]
        assert joao, "joao seed missing"
        r = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store['id']}/queue/join",
            headers=_h(admin_token), json={"seller_id": joao["id"]}, timeout=15,
        )
        assert r.status_code == 200, r.text
        state = r.json()
        assert any(e["seller_id"] == joao["id"] for e in state["entries"])
        # duplicate join -> 409
        r2 = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store['id']}/queue/join",
            headers=_h(admin_token), json={"seller_id": joao["id"]}, timeout=15,
        )
        assert r2.status_code == 409
        # leave
        r3 = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store['id']}/queue/leave",
            headers=_h(admin_token), json={"seller_id": joao["id"]}, timeout=15,
        )
        assert r3.status_code == 200
        assert not any(e["seller_id"] == joao["id"] for e in r3.json()["entries"])

    def test_join_requires_available(self, admin_token, store, sellers):
        joao = sellers["joao"]
        # Put in BREAK then try join -> 409
        r = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store['id']}/queue/mark-away",
            headers=_h(admin_token), json={"seller_id": joao["id"], "new_status": "BREAK"}, timeout=15,
        )
        assert r.status_code == 200, r.text
        r2 = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store['id']}/queue/join",
            headers=_h(admin_token), json={"seller_id": joao["id"]}, timeout=15,
        )
        assert r2.status_code == 409


class TestAttendanceFlow:
    def test_fifo_start_and_finish_sale(self, admin_token, store, sellers):
        joao = sellers["joao"]
        maria = sellers["maria"]
        # Both join
        for s in (joao, maria):
            r = requests.post(
                f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store['id']}/queue/join",
                headers=_h(admin_token), json={"seller_id": s["id"]}, timeout=15,
            )
            assert r.status_code == 200, r.text
        # State: first at position 1
        st = requests.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store['id']}/queue",
                          headers=_h(admin_token), timeout=15).json()
        assert len(st["entries"]) >= 2
        first_seller_id = st["entries"][0]["seller_id"]
        # Start attendance for first
        rs = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store['id']}/queue/start-attendance",
            headers=_h(admin_token), json={"seller_id": first_seller_id}, timeout=15,
        )
        assert rs.status_code == 200, rs.text
        body = rs.json()
        att_id = body["attendance"]["id"]
        # Seller removed from queue & SERVING
        state = body["state"]
        assert not any(e["seller_id"] == first_seller_id for e in state["entries"])
        assert any(s["seller_id"] == first_seller_id for s in state["serving_sellers"])
        # Duplicate start in_progress -> 409 cannot start again (no entry)
        # Validation: SALE without amount -> 400
        rbad = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store['id']}/queue/finish-attendance",
            headers=_h(admin_token),
            json={"attendance_id": att_id, "result": "SALE"},
            timeout=15,
        )
        assert rbad.status_code == 400
        # Finish SALE with amount
        rf = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store['id']}/queue/finish-attendance",
            headers=_h(admin_token),
            json={"attendance_id": att_id, "result": "SALE", "sale_amount_cents": 12345},
            timeout=15,
        )
        assert rf.status_code == 200, rf.text
        fb = rf.json()
        assert fb["attendance"]["status"] == "FINISHED"
        assert fb["attendance"]["result"] == "SALE"
        assert fb["attendance"]["sale_amount_cents"] == 12345
        # Returned to end of queue
        assert any(e["seller_id"] == first_seller_id for e in fb["state"]["entries"])

    def test_no_sale_requires_loss_reason(self, admin_token, store, sellers):
        joao = sellers["joao"]
        requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store['id']}/queue/join",
            headers=_h(admin_token), json={"seller_id": joao["id"]}, timeout=15,
        )
        rs = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store['id']}/queue/start-attendance",
            headers=_h(admin_token), json={"seller_id": joao["id"]}, timeout=15,
        )
        assert rs.status_code == 200, rs.text
        att_id = rs.json()["attendance"]["id"]
        rbad = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store['id']}/queue/finish-attendance",
            headers=_h(admin_token),
            json={"attendance_id": att_id, "result": "NO_SALE"},
            timeout=15,
        )
        assert rbad.status_code == 400
        # cancel to cleanup
        requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/attendances/{att_id}/cancel",
            headers=_h(admin_token), json={"reason": "cleanup"}, timeout=15,
        )

    def test_invalid_requires_notes(self, admin_token, store, sellers):
        joao = sellers["joao"]
        requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store['id']}/queue/join",
            headers=_h(admin_token), json={"seller_id": joao["id"]}, timeout=15,
        )
        rs = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store['id']}/queue/start-attendance",
            headers=_h(admin_token), json={"seller_id": joao["id"]}, timeout=15,
        )
        att_id = rs.json()["attendance"]["id"]
        rbad = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store['id']}/queue/finish-attendance",
            headers=_h(admin_token),
            json={"attendance_id": att_id, "result": "INVALID"},
            timeout=15,
        )
        assert rbad.status_code == 400
        requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/attendances/{att_id}/cancel",
            headers=_h(admin_token), json={"reason": "cleanup"}, timeout=15,
        )

    def test_seller_not_first_blocked(self, admin_token, joao_token, maria_token, store, sellers):
        joao = sellers["joao"]; maria = sellers["maria"]
        # Both join
        for s in (joao, maria):
            requests.post(
                f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store['id']}/queue/join",
                headers=_h(admin_token), json={"seller_id": s["id"]}, timeout=15,
            )
        st = requests.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store['id']}/queue",
                          headers=_h(admin_token), timeout=15).json()
        first = st["entries"][0]["seller_id"]
        second_id = st["entries"][1]["seller_id"]
        # The seller_id #2 — pick correct token
        second_token = joao_token if second_id == joao["id"] else maria_token
        rbad = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store['id']}/queue/start-attendance",
            headers=_h(second_token), json={"seller_id": second_id}, timeout=15,
        )
        assert rbad.status_code == 409
        body = rbad.json()
        # error code present
        detail = body.get("detail")
        assert detail and (isinstance(detail, dict) and detail.get("error") == "SELLER_NOT_FIRST_IN_QUEUE")
        _ = first  # silence


class TestReorderPermission:
    def test_seller_cannot_reorder(self, joao_token, store, sellers):
        joao = sellers["joao"]
        r = requests.patch(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store['id']}/queue/reorder",
            headers=_h(joao_token), json={"ordered_seller_ids": [joao["id"]]}, timeout=15,
        )
        assert r.status_code == 403

    def test_reorder_bad_list(self, admin_token, store, sellers):
        joao = sellers["joao"]; maria = sellers["maria"]
        for s in (joao, maria):
            requests.post(
                f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store['id']}/queue/join",
                headers=_h(admin_token), json={"seller_id": s["id"]}, timeout=15,
            )
        r = requests.patch(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store['id']}/queue/reorder",
            headers=_h(admin_token), json={"ordered_seller_ids": [joao["id"]]}, timeout=15,
        )
        assert r.status_code == 400

    def test_reorder_success(self, admin_token, store, sellers):
        joao = sellers["joao"]; maria = sellers["maria"]
        for s in (joao, maria):
            requests.post(
                f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store['id']}/queue/join",
                headers=_h(admin_token), json={"seller_id": s["id"]}, timeout=15,
            )
        new_order = [maria["id"], joao["id"]]
        r = requests.patch(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store['id']}/queue/reorder",
            headers=_h(admin_token), json={"ordered_seller_ids": new_order}, timeout=15,
        )
        assert r.status_code == 200, r.text
        entries = r.json()["entries"]
        assert [e["seller_id"] for e in entries] == new_order


class TestAttendancesList:
    def test_list_attendances(self, admin_token):
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/attendances",
                         headers=_h(admin_token), timeout=15)
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_cancel_requires_manager(self, joao_token, admin_token, store, sellers):
        joao = sellers["joao"]
        requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store['id']}/queue/join",
            headers=_h(admin_token), json={"seller_id": joao["id"]}, timeout=15,
        )
        rs = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store['id']}/queue/start-attendance",
            headers=_h(admin_token), json={"seller_id": joao["id"]}, timeout=15,
        )
        att_id = rs.json()["attendance"]["id"]
        rbad = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/attendances/{att_id}/cancel",
            headers=_h(joao_token), json={"reason": "x"}, timeout=15,
        )
        assert rbad.status_code == 403
        rok = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/attendances/{att_id}/cancel",
            headers=_h(admin_token), json={"reason": "supervisor pediu"}, timeout=15,
        )
        assert rok.status_code == 200, rok.text
        assert rok.json()["attendance"]["status"] == "CANCELLED"


class TestFeatureFlag:
    def test_feature_flag_disabled_blocks_queue(self, super_token, admin_token, store):
        # find tenant id
        r = requests.get(f"{BASE_URL}/api/super-admin/tenants", headers=_h(super_token), timeout=15)
        assert r.status_code == 200
        tenant = next(t for t in r.json() if t.get("slug") == TENANT_SLUG)
        # Disable feature
        rp = requests.patch(
            f"{BASE_URL}/api/super-admin/tenants/{tenant['id']}/features",
            headers=_h(super_token),
            json={"features": [{"feature_key": "lista_da_vez", "enabled": False}]},
            timeout=15,
        )
        assert rp.status_code in (200, 204), rp.text
        try:
            rq = requests.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores/{store['id']}/queue",
                              headers=_h(admin_token), timeout=15)
            assert rq.status_code == 403
        finally:
            # restore
            requests.patch(
                f"{BASE_URL}/api/super-admin/tenants/{tenant['id']}/features",
                headers=_h(super_token),
                json={"features": [{"feature_key": "lista_da_vez", "enabled": True}]},
                timeout=15,
            )


class TestMultiTenantIsolation:
    def test_cross_tenant_blocked(self, admin_token):
        r = requests.get(f"{BASE_URL}/api/tenants/non-existent/stores",
                         headers=_h(admin_token), timeout=15)
        assert r.status_code in (403, 404)
