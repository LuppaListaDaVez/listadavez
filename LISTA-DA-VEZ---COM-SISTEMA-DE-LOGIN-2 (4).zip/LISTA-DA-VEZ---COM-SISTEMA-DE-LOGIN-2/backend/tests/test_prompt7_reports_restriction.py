"""
Prompt 7 — Reports Module Access Restriction Tests
Tests that:
- SELLER cannot access any report endpoints (403)
- GERENTE (STORE_MANAGER) can access report endpoints (200)
- ADMIN (TENANT_ADMIN) can access report endpoints (200)
- Seller's other features (Queue, My Performance, Goals, Feedbacks, Gamification) still work
"""
import pytest
import requests
import os

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")
SLUG = "demo"

ADMIN_CREDS = {"email": "admin@demo.com", "password": "Admin@123456"}
GERENTE_CREDS = {"email": "gerente@demo.com", "password": "Admin@123456"}
SELLER_CREDS = {"email": "joao@demo.com", "password": "Admin@123456"}


def login(creds, slug=SLUG):
    r = requests.post(f"{BASE_URL}/api/tenants/{slug}/auth/login", json=creds)
    assert r.status_code == 200, f"Login failed for {creds['email']}: {r.text}"
    return r.json()["access_token"]


def auth(token):
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture(scope="module")
def admin_token():
    return login(ADMIN_CREDS)


@pytest.fixture(scope="module")
def gerente_token():
    return login(GERENTE_CREDS)


@pytest.fixture(scope="module")
def seller_token():
    return login(SELLER_CREDS)


# ─── REQ 6: SELLER is blocked on ALL report endpoints (must return 403) ──────

class TestSellerBlockedFromReports:
    """Seller (SELLER role) must get 403 on all /reports/* endpoints."""

    def test_seller_blocked_attendances(self, seller_token):
        """GET /reports/attendances with seller token must return 403."""
        r = requests.get(
            f"{BASE_URL}/api/tenants/{SLUG}/reports/attendances",
            headers=auth(seller_token)
        )
        assert r.status_code == 403, (
            f"Expected 403 for seller on reports/attendances, got {r.status_code}: {r.text}"
        )

    def test_seller_blocked_conversion(self, seller_token):
        """GET /reports/conversion with seller token must return 403."""
        r = requests.get(
            f"{BASE_URL}/api/tenants/{SLUG}/reports/conversion",
            headers=auth(seller_token)
        )
        assert r.status_code == 403, (
            f"Expected 403 for seller on reports/conversion, got {r.status_code}: {r.text}"
        )

    def test_seller_blocked_loss_reasons(self, seller_token):
        """GET /reports/loss-reasons with seller token must return 403."""
        r = requests.get(
            f"{BASE_URL}/api/tenants/{SLUG}/reports/loss-reasons",
            headers=auth(seller_token)
        )
        assert r.status_code == 403, (
            f"Expected 403 for seller on reports/loss-reasons, got {r.status_code}: {r.text}"
        )

    def test_seller_blocked_seller_performance(self, seller_token):
        """GET /reports/seller-performance with seller token must return 403."""
        r = requests.get(
            f"{BASE_URL}/api/tenants/{SLUG}/reports/seller-performance",
            headers=auth(seller_token)
        )
        assert r.status_code == 403, (
            f"Expected 403 for seller on reports/seller-performance, got {r.status_code}: {r.text}"
        )

    def test_seller_blocked_products_report(self, seller_token):
        """GET /reports/products with seller token must return 403."""
        r = requests.get(
            f"{BASE_URL}/api/tenants/{SLUG}/reports/products",
            headers=auth(seller_token)
        )
        assert r.status_code == 403, (
            f"Expected 403 for seller on reports/products, got {r.status_code}: {r.text}"
        )

    def test_seller_error_message_contains_permission_info(self, seller_token):
        """403 response should have meaningful error message."""
        r = requests.get(
            f"{BASE_URL}/api/tenants/{SLUG}/reports/attendances",
            headers=auth(seller_token)
        )
        assert r.status_code == 403
        data = r.json()
        assert "detail" in data
        detail = data["detail"].lower()
        assert "permiss" in detail or "acesso" in detail, (
            f"Expected permission-related message, got: {data['detail']}"
        )


# ─── REQ 7: GERENTE is allowed on report endpoints (must return 200) ─────────

class TestGerenteAllowedOnReports:
    """Gerente (STORE_MANAGER role) must get 200 on all report endpoints."""

    def test_gerente_allowed_attendances(self, gerente_token):
        """GET /reports/attendances with gerente token must return 200."""
        r = requests.get(
            f"{BASE_URL}/api/tenants/{SLUG}/reports/attendances",
            headers=auth(gerente_token)
        )
        assert r.status_code == 200, (
            f"Expected 200 for gerente on reports/attendances, got {r.status_code}: {r.text}"
        )

    def test_gerente_allowed_conversion(self, gerente_token):
        """GET /reports/conversion with gerente token must return 200."""
        r = requests.get(
            f"{BASE_URL}/api/tenants/{SLUG}/reports/conversion",
            headers=auth(gerente_token)
        )
        assert r.status_code == 200, (
            f"Expected 200 for gerente on reports/conversion, got {r.status_code}: {r.text}"
        )

    def test_gerente_allowed_seller_performance(self, gerente_token):
        """GET /reports/seller-performance with gerente token must return 200."""
        r = requests.get(
            f"{BASE_URL}/api/tenants/{SLUG}/reports/seller-performance",
            headers=auth(gerente_token)
        )
        assert r.status_code == 200, (
            f"Expected 200 for gerente on reports/seller-performance, got {r.status_code}: {r.text}"
        )


# ─── REQ 5: ADMIN is allowed on report endpoints (must return 200) ────────────

class TestAdminAllowedOnReports:
    """Admin (TENANT_ADMIN role) must get 200 on all report endpoints."""

    def test_admin_allowed_attendances(self, admin_token):
        """GET /reports/attendances with admin token must return 200."""
        r = requests.get(
            f"{BASE_URL}/api/tenants/{SLUG}/reports/attendances",
            headers=auth(admin_token)
        )
        assert r.status_code == 200, (
            f"Expected 200 for admin on reports/attendances, got {r.status_code}: {r.text}"
        )

    def test_admin_allowed_conversion(self, admin_token):
        """GET /reports/conversion with admin token must return 200."""
        r = requests.get(
            f"{BASE_URL}/api/tenants/{SLUG}/reports/conversion",
            headers=auth(admin_token)
        )
        assert r.status_code == 200, (
            f"Expected 200 for admin on reports/conversion, got {r.status_code}: {r.text}"
        )

    def test_admin_allowed_loss_reasons(self, admin_token):
        """GET /reports/loss-reasons with admin token must return 200."""
        r = requests.get(
            f"{BASE_URL}/api/tenants/{SLUG}/reports/loss-reasons",
            headers=auth(admin_token)
        )
        assert r.status_code == 200, (
            f"Expected 200 for admin on reports/loss-reasons, got {r.status_code}: {r.text}"
        )


# ─── REQ 8: No Regression — Seller can still access other features ────────────

class TestSellerOtherFeaturesNoRegression:
    """Seller must still be able to access Queue, My Performance, Goals, Feedbacks, Gamification."""

    def test_seller_can_access_queue(self, seller_token):
        """Queue requires a store_id; check seller's accessible stores and use one."""
        # Get seller's store
        r_stores = requests.get(
            f"{BASE_URL}/api/tenants/{SLUG}/stores",
            headers=auth(seller_token)
        )
        assert r_stores.status_code == 200, f"Seller cannot access stores: {r_stores.text}"
        stores = r_stores.json()
        assert len(stores) > 0, "Seller has no stores"
        store_id = stores[0]["id"]

        r = requests.get(
            f"{BASE_URL}/api/tenants/{SLUG}/stores/{store_id}/queue",
            headers=auth(seller_token)
        )
        # 200 is expected
        assert r.status_code == 200, (
            f"Seller should access queue, got {r.status_code}: {r.text}"
        )

    def test_seller_can_access_attendances(self, seller_token):
        """Seller can view their own attendances."""
        r = requests.get(
            f"{BASE_URL}/api/tenants/{SLUG}/attendances",
            headers=auth(seller_token)
        )
        assert r.status_code == 200, (
            f"Seller should access attendances (own), got {r.status_code}: {r.text}"
        )

    def test_seller_can_access_goals(self, seller_token):
        """Seller can view their goals."""
        r = requests.get(
            f"{BASE_URL}/api/tenants/{SLUG}/goals",
            headers=auth(seller_token)
        )
        assert r.status_code == 200, (
            f"Seller should access goals, got {r.status_code}: {r.text}"
        )

    def test_seller_can_access_feedbacks(self, seller_token):
        """Seller can view their feedbacks."""
        r = requests.get(
            f"{BASE_URL}/api/tenants/{SLUG}/feedbacks",
            headers=auth(seller_token)
        )
        assert r.status_code == 200, (
            f"Seller should access feedbacks, got {r.status_code}: {r.text}"
        )

    def test_seller_can_access_gamification(self, seller_token):
        """Seller can view gamification / conquistas."""
        r = requests.get(
            f"{BASE_URL}/api/tenants/{SLUG}/gamification/achievements/me",
            headers=auth(seller_token)
        )
        # Accept 200 or fallback to checking context endpoint
        assert r.status_code in (200, 404), (
            f"Seller gamification got unexpected status {r.status_code}: {r.text}"
        )

    def test_seller_can_access_my_performance(self, seller_token):
        """Seller can access my performance endpoint."""
        r = requests.get(
            f"{BASE_URL}/api/tenants/{SLUG}/performance/me",
            headers=auth(seller_token)
        )
        assert r.status_code in (200, 404), (
            f"Seller my-performance got unexpected status {r.status_code}: {r.text}"
        )

    def test_seller_context_has_no_reports_permissions(self, seller_token):
        """Context endpoint must not include any reports.view_* permissions for seller."""
        r = requests.get(
            f"{BASE_URL}/api/tenants/{SLUG}/context",
            headers=auth(seller_token)
        )
        assert r.status_code == 200, f"Context call failed: {r.text}"
        data = r.json()
        permissions = data.get("permissions", [])
        report_perms = [p for p in permissions if p.startswith("reports.")]
        assert len(report_perms) == 0, (
            f"Seller should have 0 reports.* permissions, but found: {report_perms}"
        )
