"""
Tests for Prompt 5: Tenant creation, invite flows, AcceptInvite, InviteUser, Preview
"""
import pytest
import requests
import os
import uuid

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")

SUPER_ADMIN_EMAIL = "admin@listadavez.com"
SUPER_ADMIN_PASS = "Admin@123456"
TENANT_ADMIN_EMAIL = "admin@demo.com"
TENANT_ADMIN_PASS = "Admin@123456"
TENANT_SLUG = "demo"


@pytest.fixture(scope="module")
def super_admin_token():
    resp = requests.post(f"{BASE_URL}/api/auth/login", json={
        "email": SUPER_ADMIN_EMAIL,
        "password": SUPER_ADMIN_PASS,
    })
    assert resp.status_code == 200, f"Super admin login failed: {resp.text}"
    return resp.json()["access_token"]


@pytest.fixture(scope="module")
def tenant_admin_token():
    resp = requests.post(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/auth/login", json={
        "email": TENANT_ADMIN_EMAIL,
        "password": TENANT_ADMIN_PASS,
    })
    assert resp.status_code == 200, f"Tenant admin login failed: {resp.text}"
    return resp.json()["access_token"]


@pytest.fixture(scope="module")
def super_admin_client(super_admin_token):
    s = requests.Session()
    s.headers.update({"Authorization": f"Bearer {super_admin_token}", "Content-Type": "application/json"})
    return s


@pytest.fixture(scope="module")
def tenant_admin_client(tenant_admin_token):
    s = requests.Session()
    s.headers.update({"Authorization": f"Bearer {tenant_admin_token}", "Content-Type": "application/json"})
    return s


# ─── Super Admin: Create Tenant ───────────────────────────────────────────────

class TestCreateTenant:
    """POST /api/super-admin/tenants — create tenant with invite flow"""

    def test_create_tenant_valid(self, super_admin_client):
        unique = uuid.uuid4().hex[:6]
        payload = {
            "name": f"TEST Empresa {unique}",
            "slug": f"test-empresa-{unique}",
            "admin_email": f"admin-{unique}@test-empresa.com",
            "admin_name": "Test Admin",
            "cnpj": "11222333000181",
        }
        resp = super_admin_client.post(f"{BASE_URL}/api/super-admin/tenants", json=payload)
        if resp.status_code == 409:
            pytest.skip("CNPJ already registered; skipping (expected on reruns)")
        assert resp.status_code in [200, 201], f"Expected 2xx, got {resp.status_code}: {resp.text}"
        data = resp.json()
        assert "id" in data or "tenant" in data or "slug" in data or "name" in data, f"Unexpected response: {data}"

    def test_create_tenant_missing_admin_email(self, super_admin_client):
        payload = {
            "name": "Missing Email Corp",
            "slug": "missing-email-corp",
        }
        resp = super_admin_client.post(f"{BASE_URL}/api/super-admin/tenants", json=payload)
        assert resp.status_code in [400, 422], f"Expected 400/422, got {resp.status_code}"

    def test_create_tenant_duplicate_slug(self, super_admin_client):
        # "demo" already exists
        payload = {
            "name": "Demo Duplicate",
            "slug": "demo",
            "admin_email": "admin@demo-dup.com",
        }
        resp = super_admin_client.post(f"{BASE_URL}/api/super-admin/tenants", json=payload)
        assert resp.status_code in [400, 409, 422], f"Expected error for duplicate slug, got {resp.status_code}: {resp.text}"


# ─── TenantsList: Resend Invite ───────────────────────────────────────────────

class TestResendInvite:
    """POST /api/super-admin/tenants/{id}/resend-invite"""

    def test_resend_invite_pending_tenant(self, super_admin_client):
        # First create a tenant to get one in PENDING_ACTIVATION state
        unique = uuid.uuid4().hex[:6]
        import random
        cnpjs = ["29979036000140", "45997418000153", "63025530000160", "72398092000110"]
        cnpj = random.choice(cnpjs)
        create_resp = super_admin_client.post(f"{BASE_URL}/api/super-admin/tenants", json={
            "name": f"TEST Resend {unique}",
            "slug": f"test-resend-{unique}",
            "admin_email": f"admin-resend-{unique}@test.com",
            "cnpj": cnpj,
        })
        if create_resp.status_code == 409:
            pytest.skip("Test CNPJ already used, skipping resend test")
        if create_resp.status_code == 422:
            pytest.skip("Test CNPJ invalid, skipping resend test")
        assert create_resp.status_code in [200, 201], f"Create failed: {create_resp.text}"
        created = create_resp.json()
        tenant_id = created.get("id") or created.get("tenant", {}).get("id")
        assert tenant_id, "No tenant ID in response"

        # Now resend invite
        resp = super_admin_client.post(f"{BASE_URL}/api/super-admin/tenants/{tenant_id}/resend-invite")
        assert resp.status_code in [200, 201], f"Resend failed: {resp.status_code}: {resp.text}"

    def test_resend_invite_nonexistent_tenant(self, super_admin_client):
        resp = super_admin_client.post(f"{BASE_URL}/api/super-admin/tenants/nonexistent-id-999/resend-invite")
        assert resp.status_code == 404, f"Expected 404, got {resp.status_code}"


# ─── AcceptInvite: POST /api/invites/{token}/accept ──────────────────────────

class TestAcceptInvite:
    """POST /api/invites/{token}/accept"""

    def test_accept_invalid_token(self):
        resp = requests.post(f"{BASE_URL}/api/invites/INVALID_TOKEN_XYZ_999/accept", json={
            "token": "INVALID_TOKEN_XYZ_999",
            "name": "Test User",
            "password": "TestPass@123",
        })
        assert resp.status_code in [400, 404], f"Expected 400/404 for invalid token, got {resp.status_code}: {resp.text}"

    def test_accept_missing_password(self):
        resp = requests.post(f"{BASE_URL}/api/invites/sometoken/accept", json={
            "token": "sometoken",
            "name": "Test User",
        })
        assert resp.status_code in [400, 422], f"Expected error for missing password, got {resp.status_code}"


# ─── InviteUser: POST /api/tenants/{slug}/users/invite ────────────────────────

class TestInviteUser:
    """POST /api/tenants/{slug}/users/invite"""

    def test_invite_user_seller(self, tenant_admin_client):
        # Get stores first
        stores_resp = tenant_admin_client.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores")
        assert stores_resp.status_code == 200
        stores = stores_resp.json()
        store_id = stores[0]["id"] if stores else None

        unique = uuid.uuid4().hex[:6]
        payload = {
            "email": f"invite-seller-{unique}@test.com",
            "role": "SELLER",
            "store_ids": [store_id] if store_id else [],
            "all_stores": False,
        }
        resp = tenant_admin_client.post(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/users/invite", json=payload)
        assert resp.status_code in [200, 201], f"Invite seller failed: {resp.status_code}: {resp.text}"
        data = resp.json()
        assert "invite_sent_to" in data or "message" in data, f"Unexpected response: {data}"

    def test_invite_user_tenant_admin(self, tenant_admin_client):
        unique = uuid.uuid4().hex[:6]
        payload = {
            "email": f"invite-admin-{unique}@test.com",
            "role": "TENANT_ADMIN",
            "store_ids": [],
            "all_stores": False,
        }
        resp = tenant_admin_client.post(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/users/invite", json=payload)
        assert resp.status_code in [200, 201], f"Invite tenant admin failed: {resp.status_code}: {resp.text}"

    def test_invite_user_regional_manager_all_stores(self, tenant_admin_client):
        unique = uuid.uuid4().hex[:6]
        payload = {
            "email": f"invite-rm-{unique}@test.com",
            "role": "REGIONAL_MANAGER",
            "store_ids": [],
            "all_stores": True,
        }
        resp = tenant_admin_client.post(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/users/invite", json=payload)
        assert resp.status_code in [200, 201], f"Invite RM all stores failed: {resp.status_code}: {resp.text}"


# ─── Pending Invites List: GET /api/tenants/{slug}/users/invites ──────────────

class TestPendingInvitesList:
    """GET /api/tenants/{slug}/users/invites"""

    def test_list_pending_invites(self, tenant_admin_client):
        resp = tenant_admin_client.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/users/invites")
        assert resp.status_code == 200, f"Failed: {resp.status_code}: {resp.text}"
        data = resp.json()
        assert "invites" in data, f"Missing 'invites' key: {data}"
        assert isinstance(data["invites"], list)


# ─── Preview Email: GET /api/tenants/{slug}/users/invite/{invite_id}/preview ──

class TestPreviewEmail:
    """GET /api/tenants/{slug}/users/invite/{invite_id}/preview"""

    def test_preview_valid_invite(self, tenant_admin_client):
        # Create an invite first
        unique = uuid.uuid4().hex[:6]
        stores_resp = tenant_admin_client.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/stores")
        stores = stores_resp.json() if stores_resp.status_code == 200 else []
        store_id = stores[0]["id"] if stores else None

        create_resp = tenant_admin_client.post(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/users/invite", json={
            "email": f"preview-{unique}@test.com",
            "role": "SELLER",
            "store_ids": [store_id] if store_id else [],
            "all_stores": False,
        })
        assert create_resp.status_code in [200, 201], f"Invite creation failed: {create_resp.text}"
        invite_data = create_resp.json()

        # Get invites list to find the invite_id
        invites_resp = tenant_admin_client.get(f"{BASE_URL}/api/tenants/{TENANT_SLUG}/users/invites")
        assert invites_resp.status_code == 200
        invites = invites_resp.json().get("invites", [])

        # Find our invite
        our_invite = next((i for i in invites if i.get("email") == f"preview-{unique}@test.com"), None)
        if not our_invite:
            pytest.skip("Could not find created invite in list")

        invite_id = our_invite["id"]
        preview_resp = tenant_admin_client.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/users/invite/{invite_id}/preview"
        )
        assert preview_resp.status_code == 200, f"Preview failed: {preview_resp.status_code}: {preview_resp.text}"
        assert "text/html" in preview_resp.headers.get("content-type", ""), "Expected HTML response"
        assert len(preview_resp.text) > 100, "HTML content too short"

    def test_preview_invalid_invite_id(self, tenant_admin_client):
        resp = tenant_admin_client.get(
            f"{BASE_URL}/api/tenants/{TENANT_SLUG}/users/invite/nonexistent-id-999/preview"
        )
        assert resp.status_code == 404, f"Expected 404, got {resp.status_code}"
