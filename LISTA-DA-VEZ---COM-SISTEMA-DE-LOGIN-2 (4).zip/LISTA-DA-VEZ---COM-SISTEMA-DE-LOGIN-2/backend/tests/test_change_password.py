"""Tests for change-password endpoint POST /tenants/{slug}/auth/change-password"""
import pytest
import requests
import os

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")

ADMIN_EMAIL = "admin@demo.com"
ADMIN_PASSWORD = "Admin@123456"
TENANT = "demo"


def get_token(email=ADMIN_EMAIL, password=ADMIN_PASSWORD):
    r = requests.post(f"{BASE_URL}/api/tenants/{TENANT}/auth/login",
                      json={"email": email, "password": password})
    assert r.status_code == 200, f"Login failed: {r.text}"
    return r.json().get("access_token") or r.json().get("token")


def auth_headers(token):
    return {"Authorization": f"Bearer {token}"}


class TestChangePassword:
    """change-password endpoint tests"""

    def test_change_password_correct(self):
        """Correct current password → 200 with expected message"""
        token = get_token()
        r = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT}/auth/change-password",
            json={"current_password": ADMIN_PASSWORD, "new_password": "Admin@123456"},
            headers=auth_headers(token),
        )
        assert r.status_code == 200, f"Expected 200: {r.text}"
        data = r.json()
        assert data.get("message") == "Senha alterada com sucesso."

    def test_change_password_wrong_current(self):
        """Wrong current password → 400"""
        token = get_token()
        r = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT}/auth/change-password",
            json={"current_password": "WrongPassword@1", "new_password": "NewPass@123"},
            headers=auth_headers(token),
        )
        assert r.status_code == 400, f"Expected 400: {r.text}"
        assert "Senha atual incorreta" in r.json().get("detail", "")

    def test_change_password_short_new(self):
        """New password < 8 chars → 422"""
        token = get_token()
        r = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT}/auth/change-password",
            json={"current_password": ADMIN_PASSWORD, "new_password": "short"},
            headers=auth_headers(token),
        )
        assert r.status_code == 422, f"Expected 422: {r.text}"

    def test_change_password_no_auth(self):
        """No auth → 401"""
        r = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT}/auth/change-password",
            json={"current_password": ADMIN_PASSWORD, "new_password": "Admin@123456"},
        )
        assert r.status_code in (401, 403), f"Expected 401/403: {r.text}"
