"""P1 Export Jobs & Health Regression Tests"""
import os
import time
import pytest
import requests

BASE_URL = os.environ.get(
    "BACKEND_URL",
    os.environ.get("REACT_APP_BACKEND_URL", "http://localhost:8001"),
).rstrip("/")
TENANT = "demo"
EMAIL = "admin@demo.com"
PASSWORD = "Admin@123456"


@pytest.fixture(scope="module")
def token():
    r = requests.post(f"{BASE_URL}/api/tenants/{TENANT}/auth/login",
                      json={"email": EMAIL, "password": PASSWORD})
    assert r.status_code == 200, f"Login failed: {r.text}"
    return r.json()["access_token"]


@pytest.fixture(scope="module")
def auth(token):
    return {"Authorization": f"Bearer {token}"}


# ── Health ────────────────────────────────────────────────────────────────────

def test_health():
    r = requests.get(f"{BASE_URL}/api/health")
    assert r.status_code == 200


# ── Create export job (attendances) ──────────────────────────────────────────

def test_create_export_job_attendances(auth):
    r = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT}/reports/export/async",
        json={"report_type": "attendances"},
        headers=auth,
    )
    assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text}"
    data = r.json()
    assert data["status"] == "QUEUED"
    assert "id" in data
    # Store for next test
    test_create_export_job_attendances.job_id = data["id"]


def test_export_job_attendances_becomes_done(auth):
    job_id = getattr(test_create_export_job_attendances, "job_id", None)
    if not job_id:
        pytest.skip("No job_id from previous test")

    for _ in range(15):
        r = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT}/reports/export/jobs/{job_id}",
            headers=auth,
        )
        assert r.status_code == 200
        data = r.json()
        if data["status"] == "DONE":
            assert data.get("row_count") is not None
            assert data.get("filename") is not None
            test_export_job_attendances_becomes_done.job_id_done = job_id
            return
        time.sleep(1)
    pytest.fail(f"Job did not become DONE in 15s. Last status: {data['status']}")


def test_download_export_job_csv(auth):
    job_id = getattr(test_export_job_attendances_becomes_done, "job_id_done", None)
    if not job_id:
        pytest.skip("No DONE job available")
    r = requests.get(
        f"{BASE_URL}/api/tenants/{TENANT}/reports/export/jobs/{job_id}/download",
        headers=auth,
    )
    assert r.status_code == 200, f"Download failed: {r.status_code} {r.text}"
    ct = r.headers.get("Content-Type", "")
    assert "text/csv" in ct, f"Expected text/csv, got: {ct}"


# ── List jobs ─────────────────────────────────────────────────────────────────

def test_list_export_jobs(auth):
    r = requests.get(
        f"{BASE_URL}/api/tenants/{TENANT}/reports/export/jobs",
        headers=auth,
    )
    assert r.status_code == 200
    data = r.json()
    assert isinstance(data, list)


# ── Invalid report_type → 400 ─────────────────────────────────────────────────

def test_create_export_job_invalid_type(auth):
    r = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT}/reports/export/async",
        json={"report_type": "invalid_type_xyz"},
        headers=auth,
    )
    assert r.status_code == 400, f"Expected 400, got {r.status_code}: {r.text}"


# ── Conversion report ─────────────────────────────────────────────────────────

def test_create_export_job_conversion(auth):
    r = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT}/reports/export/async",
        json={"report_type": "conversion"},
        headers=auth,
    )
    assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text}"
    data = r.json()
    assert data["status"] == "QUEUED"
    test_create_export_job_conversion.job_id = data["id"]


def test_export_job_conversion_becomes_done(auth):
    job_id = getattr(test_create_export_job_conversion, "job_id", None)
    if not job_id:
        pytest.skip("No conversion job_id")

    for _ in range(15):
        r = requests.get(
            f"{BASE_URL}/api/tenants/{TENANT}/reports/export/jobs/{job_id}",
            headers=auth,
        )
        assert r.status_code == 200
        data = r.json()
        if data["status"] == "DONE":
            assert data.get("row_count") is not None
            return
        time.sleep(1)
    pytest.fail(f"Conversion job did not become DONE in 15s. Last: {data['status']}")
