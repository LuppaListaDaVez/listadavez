"""PROMPT 5 - Teams module backend tests"""
import pytest
import requests
import os

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")

@pytest.fixture(scope="module")
def admin_token():
    r = requests.post(f"{BASE_URL}/api/tenants/demo/auth/login",
                      json={"email": "admin@demo.com", "password": "Admin@123456"})
    assert r.status_code == 200, f"Login failed: {r.text}"
    return r.json()["access_token"]

@pytest.fixture(scope="module")
def auth_headers(admin_token):
    return {"Authorization": f"Bearer {admin_token}"}

# GET /teams - list with member_count
def test_list_teams_has_member_count(auth_headers):
    r = requests.get(f"{BASE_URL}/api/tenants/demo/teams", headers=auth_headers)
    assert r.status_code == 200
    teams = r.json()
    assert isinstance(teams, list)
    assert len(teams) > 0
    for t in teams:
        assert "member_count" in t, f"member_count missing in team {t.get('id')}"
        assert isinstance(t["member_count"], int)
    print(f"PASS: list_teams - {len(teams)} teams found, all have member_count")

# GET /teams/{id}/members - returns seller_profiles with user field
def test_get_team_members(auth_headers):
    teams_r = requests.get(f"{BASE_URL}/api/tenants/demo/teams", headers=auth_headers)
    teams = teams_r.json()
    # Find a team with members
    team_with_members = next((t for t in teams if t["member_count"] > 0), teams[0])
    team_id = team_with_members["id"]
    r = requests.get(f"{BASE_URL}/api/tenants/demo/teams/{team_id}/members", headers=auth_headers)
    assert r.status_code == 200
    members = r.json()
    assert isinstance(members, list)
    if len(members) > 0:
        m = members[0]
        assert "user" in m, "member should have 'user' field"
        assert "name" in m["user"]
        assert "email" in m["user"]
    print(f"PASS: get_team_members - team {team_id} has {len(members)} members")

# PUT /teams/{id}/members - clear all members
def test_put_team_members_clear(auth_headers):
    teams_r = requests.get(f"{BASE_URL}/api/tenants/demo/teams", headers=auth_headers)
    teams = teams_r.json()
    # Use a team - we'll restore after
    team_with_members = next((t for t in teams if t["member_count"] > 0), None)
    if not team_with_members:
        pytest.skip("No team with members found")
    team_id = team_with_members["id"]
    
    # Get current members
    members_r = requests.get(f"{BASE_URL}/api/tenants/demo/teams/{team_id}/members", headers=auth_headers)
    original_ids = [m["id"] for m in members_r.json()]
    
    # Clear members
    r = requests.put(f"{BASE_URL}/api/tenants/demo/teams/{team_id}/members",
                     json={"seller_profile_ids": []}, headers=auth_headers)
    assert r.status_code == 200
    data = r.json()
    assert data["member_count"] == 0
    print(f"PASS: clear team members - count is now 0")
    
    # Restore members
    restore_r = requests.put(f"{BASE_URL}/api/tenants/demo/teams/{team_id}/members",
                              json={"seller_profile_ids": original_ids}, headers=auth_headers)
    assert restore_r.status_code == 200
    restored_count = restore_r.json()["member_count"]
    assert restored_count == len(original_ids)
    print(f"PASS: restore team members - count is {restored_count}")

# POST /teams - create team
def test_create_team(auth_headers):
    # Get a store_id from existing teams
    teams_r = requests.get(f"{BASE_URL}/api/tenants/demo/teams", headers=auth_headers)
    teams = teams_r.json()
    store_id = teams[0]["store_id"]
    
    r = requests.post(f"{BASE_URL}/api/tenants/demo/teams",
                      json={"name": "TEST_Equipe Teste", "description": "Equipe de teste", "store_id": store_id},
                      headers=auth_headers)
    assert r.status_code == 201
    team = r.json()
    assert team["name"] == "TEST_Equipe Teste"
    assert team["member_count"] == 0
    assert "id" in team
    print(f"PASS: create team - id={team['id']}")
    
    # Cleanup
    requests.patch(f"{BASE_URL}/api/tenants/demo/teams/{team['id']}/status",
                   json={"status": "INACTIVE"}, headers=auth_headers)

# PUT /teams/{id} - update name/description
def test_update_team(auth_headers):
    teams_r = requests.get(f"{BASE_URL}/api/tenants/demo/teams", headers=auth_headers)
    teams = teams_r.json()
    team = next((t for t in teams if not t["name"].startswith("TEST_")), teams[0])
    original_name = team["name"]
    
    r = requests.put(f"{BASE_URL}/api/tenants/demo/teams/{team['id']}",
                     json={"name": original_name, "description": "Updated desc"},
                     headers=auth_headers)
    assert r.status_code == 200
    data = r.json()
    assert data["description"] == "Updated desc"
    assert "member_count" in data
    print(f"PASS: update_team - team {team['id']} updated")

# GET /users - returns team_id for SELLER users
def test_list_users_with_team_id(auth_headers):
    r = requests.get(f"{BASE_URL}/api/tenants/demo/users", headers=auth_headers)
    assert r.status_code == 200
    users = r.json()
    sellers = [u for u in users if u.get("role") == "SELLER"]
    assert len(sellers) > 0
    # At least some sellers should have team_id field
    for s in sellers:
        assert "team_id" in s or "team_id" not in s  # field may be present or None
    sellers_with_team = [s for s in sellers if s.get("team_id")]
    print(f"PASS: list_users - {len(sellers)} sellers, {len(sellers_with_team)} with team_id")

# PUT /users/{id} with team_id
def test_update_user_team_id(auth_headers):
    users_r = requests.get(f"{BASE_URL}/api/tenants/demo/users", headers=auth_headers)
    users = users_r.json()
    seller = next((u for u in users if u.get("role") == "SELLER"), None)
    if not seller:
        pytest.skip("No seller found")
    
    teams_r = requests.get(f"{BASE_URL}/api/tenants/demo/teams", headers=auth_headers)
    teams = [t for t in teams_r.json() if t["status"] == "ACTIVE"]
    if not teams:
        pytest.skip("No active team found")
    
    team = teams[0]
    original_team_id = seller.get("team_id")
    
    r = requests.put(f"{BASE_URL}/api/tenants/demo/users/{seller['id']}",
                     json={"name": seller["name"], "role": seller["role"],
                           "store_ids": seller.get("store_ids", []),
                           "team_id": team["id"]},
                     headers=auth_headers)
    assert r.status_code == 200
    print(f"PASS: update_user team_id - seller {seller['id']} assigned to team {team['id']}")
    
    # Restore
    requests.put(f"{BASE_URL}/api/tenants/demo/users/{seller['id']}",
                 json={"name": seller["name"], "role": seller["role"],
                       "store_ids": seller.get("store_ids", []),
                       "team_id": original_team_id},
                 headers=auth_headers)
