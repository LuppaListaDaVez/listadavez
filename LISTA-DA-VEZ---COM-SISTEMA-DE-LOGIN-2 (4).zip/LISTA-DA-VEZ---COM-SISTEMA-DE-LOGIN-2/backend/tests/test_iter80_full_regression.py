"""
iter80 full regression – broad health check across Luppa functionalities.
Covers: authentication (SA, tenant admin, seller), products dup-SKU, sellers dup-email,
sales/attendances/teams/goals/reports listing, super-admin (tenants/plans dup-name),
push-subscriptions idempotency.
"""
import os
import uuid
import requests
import pytest

BASE = os.environ.get("REACT_APP_BACKEND_URL", "https://queue-mgmt-3.preview.emergentagent.com").rstrip("/")
API = f"{BASE}/api"
TENANT = "demo"
TIMEOUT = 90

# shared session for keep-alive
_session = requests.Session()
requests_post = _session.post
requests_get = _session.get
requests_put = _session.put
requests_delete = _session.delete

SA_EMAIL = "admin@listadavez.com"
SA_PASS = "MP!pass@2143"
TA_EMAIL = "admin@demo.com"
TA_PASS = "Admin@123456"
SELLER_EMAIL = "joao@demo.com"
SELLER_PASS = "Admin@123456"


# ─── AUTH FIXTURES ────────────────────────────────────────────────────────────
@pytest.fixture(scope="module")
def sa_token():
    last = None
    for _ in range(3):
        try:
            r = requests_post(f"{API}/auth/login",
                              json={"email": SA_EMAIL, "password": SA_PASS}, timeout=90)
            last = r
            if r.status_code == 200:
                return r.json()["access_token"]
        except Exception as e:
            last = e
    pytest.fail(f"SA login failed after retries: {last}")


@pytest.fixture(scope="module")
def ta_token():
    r = requests_post(f"{API}/tenants/{TENANT}/auth/login",
                      json={"email": TA_EMAIL, "password": TA_PASS}, timeout=90)
    assert r.status_code == 200, f"TA login failed: {r.status_code} {r.text}"
    return r.json()["access_token"]


@pytest.fixture(scope="module")
def seller_token():
    r = requests_post(f"{API}/tenants/{TENANT}/auth/login",
                      json={"email": SELLER_EMAIL, "password": SELLER_PASS}, timeout=90)
    assert r.status_code == 200, f"Seller login failed: {r.status_code} {r.text}"
    return r.json()["access_token"]


def _h(token):
    return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}


# ─── AUTHENTICATION ───────────────────────────────────────────────────────────
class TestAuth:
    def test_super_admin_login(self, sa_token):
        assert sa_token
        r = requests_get(f"{API}/auth/me", headers=_h(sa_token), timeout=90)
        assert r.status_code == 200
        data = r.json()
        user = data.get("user", data)
        assert user.get("email") == SA_EMAIL

    def test_tenant_admin_login(self, ta_token):
        assert ta_token
        r = requests_get(f"{API}/auth/me", headers=_h(ta_token), timeout=90)
        assert r.status_code == 200
        user = r.json().get("user", {})
        assert user.get("email") == TA_EMAIL

    def test_seller_login(self, seller_token):
        assert seller_token

    def test_invalid_password_rejected(self):
        r = requests_post(f"{API}/tenants/{TENANT}/auth/login",
                          json={"email": TA_EMAIL, "password": "wrong-pass"}, timeout=90)
        assert r.status_code in (401, 403, 429)


# ─── PRODUCTS: SKU DEDUP ──────────────────────────────────────────────────────
class TestProducts:
    def test_create_product_with_unique_sku(self, ta_token):
        sku = f"TEST-{uuid.uuid4().hex[:8].upper()}"
        payload = {"name": f"TEST_prod_{sku}", "sku": sku, "price_cents": 1000}
        r = requests_post(f"{API}/tenants/{TENANT}/products",
                          headers=_h(ta_token), json=payload, timeout=90)
        assert r.status_code in (200, 201), f"{r.status_code} {r.text}"
        assert r.json().get("sku") == sku

    def test_duplicate_sku_returns_409(self, ta_token):
        sku = f"TEST-{uuid.uuid4().hex[:8].upper()}"
        payload = {"name": f"TEST_dup_{sku}", "sku": sku, "price_cents": 500}
        r1 = requests_post(f"{API}/tenants/{TENANT}/products",
                           headers=_h(ta_token), json=payload, timeout=90)
        assert r1.status_code in (200, 201)
        r2 = requests_post(f"{API}/tenants/{TENANT}/products",
                           headers=_h(ta_token), json=payload, timeout=90)
        assert r2.status_code == 409, f"Expected 409, got {r2.status_code}: {r2.text}"

    def test_create_product_without_sku_allowed(self, ta_token):
        p1 = {"name": f"TEST_nosku_{uuid.uuid4().hex[:6]}", "price_cents": 100}
        p2 = {"name": f"TEST_nosku_{uuid.uuid4().hex[:6]}", "price_cents": 200}
        r1 = requests_post(f"{API}/tenants/{TENANT}/products",
                           headers=_h(ta_token), json=p1, timeout=90)
        r2 = requests_post(f"{API}/tenants/{TENANT}/products",
                           headers=_h(ta_token), json=p2, timeout=90)
        assert r1.status_code in (200, 201), f"{r1.status_code} {r1.text}"
        assert r2.status_code in (200, 201), f"{r2.status_code} {r2.text}"


# ─── SELLERS: EMAIL DEDUP ─────────────────────────────────────────────────────
class TestSellers:
    def test_create_seller_and_duplicate_email_409(self, ta_token):
        # need a store_id — fetch from existing sellers or stores
        s = requests_get(f"{API}/tenants/{TENANT}/sellers",
                        headers=_h(ta_token), timeout=90)
        assert s.status_code == 200
        sellers = s.json() if isinstance(s.json(), list) else s.json().get("sellers", [])
        assert sellers, "No seed sellers found to derive store_id"
        store_id = sellers[0].get("store_id")
        assert store_id, "seller row missing store_id"

        email = f"test_{uuid.uuid4().hex[:8]}@demo.com"
        payload = {"name": "TEST Seller", "email": email,
                   "password": "Admin@123456", "store_id": store_id}
        r1 = requests_post(f"{API}/tenants/{TENANT}/sellers",
                           headers=_h(ta_token), json=payload, timeout=90)
        assert r1.status_code in (200, 201), f"Create failed: {r1.status_code} {r1.text}"
        r2 = requests_post(f"{API}/tenants/{TENANT}/sellers",
                           headers=_h(ta_token), json=payload, timeout=90)
        assert r2.status_code == 409, f"Expected 409, got {r2.status_code}: {r2.text}"

    def test_list_sellers(self, ta_token):
        r = requests_get(f"{API}/tenants/{TENANT}/sellers",
                         headers=_h(ta_token), timeout=90)
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, (list, dict))


# ─── SALES / ATTENDANCES / TEAMS / GOALS / REPORTS ────────────────────────────
class TestListings:
    def test_list_sales(self, ta_token):
        r = requests_get(f"{API}/tenants/{TENANT}/sales",
                         headers=_h(ta_token), timeout=90)
        assert r.status_code == 200, f"{r.status_code} {r.text[:200]}"

    def test_list_attendances(self, ta_token):
        r = requests_get(f"{API}/tenants/{TENANT}/attendances",
                         headers=_h(ta_token), timeout=90)
        assert r.status_code == 200, f"{r.status_code} {r.text[:200]}"

    def test_list_teams(self, ta_token):
        r = requests_get(f"{API}/tenants/{TENANT}/teams",
                         headers=_h(ta_token), timeout=90)
        assert r.status_code == 200

    def test_list_goals(self, ta_token):
        r = requests_get(f"{API}/tenants/{TENANT}/goals",
                         headers=_h(ta_token), timeout=90)
        assert r.status_code == 200

    def test_reports_attendances(self, ta_token):
        r = requests_get(f"{API}/tenants/{TENANT}/reports/attendances",
                         headers=_h(ta_token), timeout=90)
        assert r.status_code in (200, 202), f"{r.status_code} {r.text[:200]}"

    def test_reports_seller_performance(self, ta_token):
        # try common paths
        for path in ["/reports/seller-performance", "/reports/sellers",
                     "/reports/performance", "/reports/sales"]:
            r = requests_get(f"{API}/tenants/{TENANT}{path}",
                             headers=_h(ta_token), timeout=90)
            if r.status_code == 200:
                return
        pytest.fail(f"No performance/sales report endpoint returned 200 (last: {r.status_code})")


# ─── SUPER ADMIN: TENANTS + PLAN DUP-NAME ─────────────────────────────────────
class TestSuperAdmin:
    def test_list_tenants(self, sa_token):
        r = requests_get(f"{API}/super-admin/tenants",
                         headers=_h(sa_token), timeout=90)
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, (list, dict))

    def test_list_plans(self, sa_token):
        r = requests_get(f"{API}/super-admin/plans",
                         headers=_h(sa_token), timeout=90)
        assert r.status_code == 200

    def test_create_plan_and_duplicate_name_409(self, sa_token):
        name = f"TEST_plan_{uuid.uuid4().hex[:8]}"
        payload = {"name": name, "monthly_price": 10.0, "annual_price": 100.0,
                   "description": "test", "features": []}
        r1 = requests_post(f"{API}/super-admin/plans",
                           headers=_h(sa_token), json=payload, timeout=90)
        # some builds may require different fields; accept 200/201 or note 422
        if r1.status_code in (422,):
            pytest.skip(f"Plan create schema mismatch: {r1.text[:200]}")
        assert r1.status_code in (200, 201), f"{r1.status_code} {r1.text[:200]}"
        r2 = requests_post(f"{API}/super-admin/plans",
                           headers=_h(sa_token), json=payload, timeout=90)
        assert r2.status_code == 409, f"Expected 409 for dup plan name, got {r2.status_code}: {r2.text[:200]}"


# ─── PUSH SUBSCRIPTIONS IDEMPOTENCY ───────────────────────────────────────────
class TestPushSubscriptions:
    def test_register_push_idempotent(self, ta_token):
        endpoint_url = f"https://fake.push/endpoint/{uuid.uuid4().hex}"
        payload = {"endpoint": endpoint_url,
                   "keys": {"p256dh": "k1", "auth": "k2"},
                   "device_label": "TEST",
                   "browser": "chrome",
                   "platform": "web"}
        r1 = requests_post(f"{API}/tenants/{TENANT}/push-subscriptions",
                           headers=_h(ta_token), json=payload, timeout=90)
        # feature may be disabled -> 402/403; accept and skip
        if r1.status_code in (402, 403):
            pytest.skip(f"push_notifications feature not enabled: {r1.status_code}")
        assert r1.status_code in (200, 201), f"{r1.status_code} {r1.text[:200]}"
        id1 = r1.json().get("id")
        r2 = requests_post(f"{API}/tenants/{TENANT}/push-subscriptions",
                           headers=_h(ta_token), json=payload, timeout=90)
        assert r2.status_code in (200, 201)
        id2 = r2.json().get("id")
        assert id1 == id2, f"Push subscription duplicated: {id1} != {id2}"
