"""routes_gamification.py — My Performance (mantido) + endpoints legados removidos.

LEGADO REMOVIDO:
  - /gamification/my-badges    → use /achievement-awards/my
  - /gamification/my-points    → use /achievement-rankings
  - /gamification/evaluate     → use /achievements/{id}/evaluate
  - /gamification/sellers/{id}/badges  → use /achievement-awards (admin)
"""
from typing import Optional
from datetime import date, timedelta

from fastapi import APIRouter, Depends, HTTPException

from db import db
from security import resolve_tenant_context
from permissions import P_PERFORMANCE_VIEW_SELF, P_PERFORMANCE_VIEW_STORE
import gamification_service
import ranking_service
import goals_service

router = APIRouter(prefix="/tenants/{tenant_slug}", tags=["gamification"])


def _has_perm(role: str, *perms: str) -> bool:
    from permissions import ROLE_PERMISSIONS
    return any(p in ROLE_PERMISSIONS.get(role, []) for p in perms)


def _period_range(period: str) -> tuple[str, str]:
    today = date.today()
    if period == "today":
        return today.isoformat(), today.isoformat()
    if period == "week":
        start = today - timedelta(days=today.weekday())
        return start.isoformat(), today.isoformat()
    if period == "month":
        start = date(today.year, today.month, 1)
        return start.isoformat(), today.isoformat()
    return date(today.year, today.month, 1).isoformat(), today.isoformat()


# ─── My Performance ──────────────────────────────────────────────────────────
@router.get("/my-performance")
async def my_performance(
    period: str = "month",
    date_start: Optional[str] = None,
    date_end: Optional[str] = None,
    ctx: dict = Depends(resolve_tenant_context),
):
    role = ctx["membership"]["role"]
    if not _has_perm(role, P_PERFORMANCE_VIEW_SELF, P_PERFORMANCE_VIEW_STORE, "performance.view_tenant"):
        raise HTTPException(403, "Sem permissão para visualizar desempenho.")

    tenant_id = ctx["tenant"]["id"]
    user_id = ctx["user"]["id"]

    profile = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": user_id})
    if not profile:
        raise HTTPException(404, "Perfil de vendedor não encontrado para este usuário.")

    seller_id = profile["id"]
    store_id = profile.get("store_id")

    ps, pe = _period_range(period)
    if date_start:
        ps = date_start
    if date_end:
        pe = date_end

    # KPIs
    att_q: dict = {
        "tenant_id": tenant_id, "seller_id": seller_id, "status": "FINISHED",
        "finished_at": {"$gte": ps, "$lte": pe + "T23:59:59.999999+00:00"},
    }
    atts = await db.attendances.find(att_q).to_list(2000)
    valid = [a for a in atts if a.get("result") != "INVALID"]
    sales = [a for a in valid if a.get("result") == "SALE"]
    total_cents = sum(a.get("sale_amount_cents") or 0 for a in sales)
    avg_ticket = round(total_cents / len(sales)) if sales else 0
    conversion = round(len(sales) / len(valid) * 100) if valid else 0
    total_produtos = sum(a.get("product_quantity") or 0 for a in sales)
    pa = round(total_produtos / len(sales), 2) if sales else 0.0

    # Metas: fonte central única, com progresso/status recalculados e escopos aplicáveis
    my_goals = await goals_service.list_applicable_goals_for_seller(
        tenant_id,
        profile,
        filters={},
        limit=50,
    )

    ranking_position = None
    from features import is_enabled
    if await is_enabled(tenant_id, "rankings") and store_id:
        ranking = await ranking_service.get_ranking(
            tenant_id=tenant_id,
            criteria="REVENUE",
            store_ids=[store_id],
            period_start=ps,
            period_end=pe,
        )
        for item in ranking.get("items", []):
            if item["seller_id"] == seller_id:
                ranking_position = item["position"]
                break

    # Badges legados (sistema estático — mantidos por retrocompatibilidade com seed)
    badges = []
    if await is_enabled(tenant_id, "gamificacao"):
        badges = await gamification_service.list_seller_badges(tenant_id, seller_id, limit=20)

    profile.pop("_id", None)
    seller_user = await db.users.find_one({"id": user_id})
    return {
        "seller": {
            "id": seller_id,
            "name": (seller_user or {}).get("name", "—"),
            "store_id": store_id,
            "current_status": profile.get("current_status", "OFFLINE"),
        },
        "period": {"type": period, "start": ps, "end": pe},
        "kpis": {
            "sales_total_cents": total_cents,
            "sales_count": len(sales),
            "attendances_finished": len(valid),
            "conversion_rate": conversion,
            "average_ticket_cents": avg_ticket,
            "total_produtos_vendidos": total_produtos,
            "pa": pa,
        },
        "goals": my_goals,
        "ranking_position": ranking_position,
        "badges": badges,
    }


# ─── Histórico Semanal ───────────────────────────────────────────────────────
@router.get("/my-performance/weekly-history")
async def my_performance_weekly_history(
    weeks: int = 8,
    ctx: dict = Depends(resolve_tenant_context),
):
    """Retorna os últimos `weeks` semanas de desempenho do vendedor logado."""
    role = ctx["membership"]["role"]
    if not _has_perm(role, P_PERFORMANCE_VIEW_SELF, P_PERFORMANCE_VIEW_STORE, "performance.view_tenant"):
        raise HTTPException(403, "Sem permissão.")

    tenant_id = ctx["tenant"]["id"]
    user_id = ctx["user"]["id"]

    profile = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": user_id})
    if not profile:
        raise HTTPException(404, "Perfil de vendedor não encontrado.")

    seller_id = profile["id"]
    today = date.today()

    # Calcular início: segunda-feira da semana mais antiga
    # today.weekday() → 0=segunda ... 6=domingo
    current_monday = today - timedelta(days=today.weekday())
    first_monday = current_monday - timedelta(weeks=weeks - 1)

    # Buscar atendimentos finalizados nas últimas `weeks` semanas
    since_str = first_monday.isoformat()
    atts = await db.attendances.find({
        "tenant_id": tenant_id,
        "seller_id": seller_id,
        "status": "FINISHED",
        "finished_at": {"$gte": since_str},
    }).to_list(10000)

    # Agrupar por semana (chave = YYYY-Www)
    from collections import defaultdict
    import re

    weekly: dict[str, dict] = defaultdict(lambda: {
        "sales_count": 0, "revenue_cents": 0, "attendances": 0
    })

    for att in atts:
        finished_at = att.get("finished_at", "")
        if not finished_at:
            continue
        # Extrair data (pode ser "2025-07-01" ou "2025-07-01T10:30:00...")
        date_part = finished_at[:10]
        try:
            att_date = date.fromisoformat(date_part)
        except ValueError:
            continue
        week_monday = att_date - timedelta(days=att_date.weekday())
        week_key = week_monday.isoformat()  # "2025-06-30"

        if att.get("result") != "INVALID":
            weekly[week_key]["attendances"] += 1
        if att.get("result") == "SALE":
            weekly[week_key]["sales_count"] += 1
            weekly[week_key]["revenue_cents"] += att.get("sale_amount_cents") or 0

    # Construir série com todas as semanas (mesmo as sem dados)
    result = []
    for i in range(weeks):
        monday = first_monday + timedelta(weeks=i)
        key = monday.isoformat()
        sunday = monday + timedelta(days=6)
        data = weekly.get(key, {"sales_count": 0, "revenue_cents": 0, "attendances": 0})
        # Label curto: "01/07"
        label = monday.strftime("%d/%m")
        result.append({
            "week_start": key,
            "label": label,
            "is_current": monday == current_monday,
            **data,
        })

    return {"weeks": result, "seller_id": seller_id}
