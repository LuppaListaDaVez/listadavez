"""StoreRepository — acesso seguro à coleção de lojas."""
from typing import Any, Dict, List, Optional, Tuple
from db import db
from .base import BaseRepository, PaginationParams


class StoreRepository(BaseRepository):
    def __init__(self):
        super().__init__(db.stores)

    async def find_by_id_for_tenant(
        self,
        tenant_id: str,
        store_id: str,
        projection: Optional[Dict] = None,
    ) -> Optional[Dict]:
        return await self._find_one(
            {"tenant_id": tenant_id, "id": store_id},
            projection,
        )

    async def find_by_slug_for_tenant(self, tenant_id: str, slug: str) -> Optional[Dict]:
        return await self._find_one({"tenant_id": tenant_id, "slug": slug})

    async def find_many_for_tenant(
        self,
        tenant_id: str,
        filters: Optional[Dict] = None,
        pagination: Optional[PaginationParams] = None,
        sort: Optional[List] = None,
        projection: Optional[Dict] = None,
    ) -> Tuple[List[Dict], int]:
        query = {"tenant_id": tenant_id, **(filters or {})}
        items = await self._find_many(
            query, pagination,
            sort or [("name", 1)],
            projection,
        )
        total = await self._count(query)
        return items, total

    async def create_for_tenant(self, tenant_id: str, data: Dict[str, Any]) -> Dict:
        doc = {"tenant_id": tenant_id, **data}
        return await self._insert_one(doc)

    async def update_for_tenant(
        self, tenant_id: str, store_id: str, data: Dict[str, Any]
    ) -> Optional[Dict]:
        return await self._update_one(
            {"tenant_id": tenant_id, "id": store_id},
            {"$set": data},
        )

    async def count_active_for_tenant(self, tenant_id: str) -> int:
        return await self._count({"tenant_id": tenant_id, "status": "ACTIVE"})


# Singleton
store_repo = StoreRepository()
