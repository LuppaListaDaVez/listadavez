"""QueueRepository — acesso seguro a filas e entradas de fila."""
from typing import Any, Dict, List, Optional, Tuple
from pymongo import ReturnDocument
from db import db
from .base import BaseRepository, PaginationParams


class QueueRepository(BaseRepository):
    def __init__(self):
        super().__init__(db.queues)

    # ── Queues ────────────────────────────────────────────────────────────────

    async def find_default_queue(self, tenant_id: str, store_id: str) -> Optional[Dict]:
        return await self._find_one(
            {"tenant_id": tenant_id, "store_id": store_id, "is_default": True}
        )

    async def find_by_id_for_tenant(
        self, tenant_id: str, queue_id: str, projection: Optional[Dict] = None
    ) -> Optional[Dict]:
        return await self._find_one(
            {"tenant_id": tenant_id, "id": queue_id}, projection
        )

    async def find_active_queues_for_store(
        self, tenant_id: str, store_id: str
    ) -> List[Dict]:
        return await self._find_many(
            {"tenant_id": tenant_id, "store_id": store_id, "status": "ACTIVE"}
        )

    async def upsert_default_queue(self, tenant_id: str, store_id: str, data: Dict) -> Dict:
        from models import new_id, utcnow_iso
        existing = await self.find_default_queue(tenant_id, store_id)
        if existing:
            return existing
        return await self._insert_one(data)

    # ── Queue Entries ─────────────────────────────────────────────────────────

    async def find_entry_for_seller(
        self, tenant_id: str, queue_id: str, seller_id: str
    ) -> Optional[Dict]:
        return await db.queue_entries.find_one(
            {"tenant_id": tenant_id, "queue_id": queue_id,
             "seller_id": seller_id, "status": "WAITING"},
            {"_id": 0},
        )

    async def find_entries_for_queue(
        self, tenant_id: str, queue_id: str
    ) -> List[Dict]:
        cursor = db.queue_entries.find(
            {"tenant_id": tenant_id, "queue_id": queue_id, "status": "WAITING"},
            {"_id": 0},
        ).sort("position", 1)
        return await cursor.to_list(500)

    async def create_entry(self, entry: Dict[str, Any]) -> Dict:
        await db.queue_entries.insert_one({**entry})
        return entry

    async def remove_entry_atomic(
        self, tenant_id: str, queue_id: str, seller_id: str
    ) -> Optional[Dict]:
        """Remove entrada da fila atomicamente. Retorna o documento removido."""
        return await db.queue_entries.find_one_and_delete(
            {"tenant_id": tenant_id, "queue_id": queue_id,
             "seller_id": seller_id, "status": "WAITING"},
            projection={"_id": 0},
        )

    async def update_entry_atomic(
        self,
        tenant_id: str,
        entry_id: str,
        match: Dict,
        update: Dict,
    ) -> Optional[Dict]:
        """Update atômico com condição de match — safe for concurrent ops."""
        query = {"tenant_id": tenant_id, "id": entry_id, **match}
        return await db.queue_entries.find_one_and_update(
            query,
            update,
            return_document=ReturnDocument.AFTER,
            projection={"_id": 0},
        )

    async def count_waiting_entries(self, tenant_id: str, queue_id: str) -> int:
        return await db.queue_entries.count_documents(
            {"tenant_id": tenant_id, "queue_id": queue_id, "status": "WAITING"}
        )

    # ── Queue Events ──────────────────────────────────────────────────────────

    async def create_event(self, event: Dict[str, Any]) -> None:
        await db.queue_events.insert_one({**event})


# Singleton
queue_repo = QueueRepository()
