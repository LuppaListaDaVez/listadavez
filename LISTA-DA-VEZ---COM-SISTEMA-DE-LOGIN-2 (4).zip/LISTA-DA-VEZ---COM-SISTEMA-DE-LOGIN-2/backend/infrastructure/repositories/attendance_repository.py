"""AttendanceRepository — acesso seguro a atendimentos."""
from typing import Any, Dict, List, Optional, Tuple
from pymongo import ReturnDocument
from db import db
from .base import BaseRepository, PaginationParams


class AttendanceRepository(BaseRepository):
    def __init__(self):
        super().__init__(db.attendances)

    async def find_by_id_for_tenant(
        self, tenant_id: str, att_id: str, projection: Optional[Dict] = None
    ) -> Optional[Dict]:
        return await self._find_one(
            {"tenant_id": tenant_id, "id": att_id}, projection
        )

    async def find_in_progress_for_seller(
        self, tenant_id: str, seller_id: str
    ) -> Optional[Dict]:
        return await self._find_one(
            {"tenant_id": tenant_id, "seller_id": seller_id, "status": "IN_PROGRESS"}
        )

    async def find_many_for_tenant(
        self,
        tenant_id: str,
        filters: Optional[Dict] = None,
        pagination: Optional[PaginationParams] = None,
    ) -> Tuple[List[Dict], int]:
        query = {"tenant_id": tenant_id, **(filters or {})}
        items = await self._find_many(
            query, pagination, sort=[("created_at", -1)]
        )
        total = await self._count(query)
        return items, total

    async def find_many_for_store(
        self,
        tenant_id: str,
        store_id: str,
        filters: Optional[Dict] = None,
        pagination: Optional[PaginationParams] = None,
    ) -> Tuple[List[Dict], int]:
        base = {"tenant_id": tenant_id, "store_id": store_id}
        query = {**base, **(filters or {})}
        items = await self._find_many(query, pagination, sort=[("created_at", -1)])
        total = await self._count(query)
        return items, total

    async def create(self, data: Dict[str, Any]) -> Dict:
        return await self._insert_one(data)

    async def finish_atomic(
        self,
        tenant_id: str,
        att_id: str,
        update_data: Dict[str, Any],
    ) -> Optional[Dict]:
        """Finaliza atendimento atomicamente: só atualiza se status=IN_PROGRESS."""
        return await self._col.find_one_and_update(
            {"tenant_id": tenant_id, "id": att_id, "status": "IN_PROGRESS"},
            {"$set": update_data},
            return_document=ReturnDocument.AFTER,
            projection={"_id": 0},
        )

    async def cancel_atomic(
        self,
        tenant_id: str,
        att_id: str,
        update_data: Dict[str, Any],
    ) -> Optional[Dict]:
        """Cancela atendimento atomicamente: só atualiza se status=IN_PROGRESS."""
        return await self._col.find_one_and_update(
            {"tenant_id": tenant_id, "id": att_id, "status": "IN_PROGRESS"},
            {"$set": update_data},
            return_document=ReturnDocument.AFTER,
            projection={"_id": 0},
        )

    async def count_for_tenant(self, tenant_id: str, filters: Optional[Dict] = None) -> int:
        query = {"tenant_id": tenant_id, **(filters or {})}
        return await self._count(query)


# Singleton
attendance_repo = AttendanceRepository()
