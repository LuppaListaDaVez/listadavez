"""UserRepository — acesso seguro a usuários (global e tenant-scoped)."""
from typing import Any, Dict, List, Optional, Tuple
from db import db
from .base import BaseRepository, PaginationParams


class UserRepository(BaseRepository):
    """Repositório de usuários.

    Nota: User é uma entidade global (coleção 'users') mas memberships
    são tenant-scoped (coleção 'tenant_memberships').
    """

    def __init__(self):
        super().__init__(db.users)
        self._memberships = db.tenant_memberships

    # ── Users (global) ────────────────────────────────────────────────────────

    async def find_by_email(self, email: str) -> Optional[Dict]:
        return await self._find_one({"normalized_email": email.lower().strip()})

    async def find_by_id(self, user_id: str) -> Optional[Dict]:
        return await self._find_one({"id": user_id})

    async def update_token_version(self, user_id: str, version: int, updated_at: str) -> None:
        await self._col.update_one(
            {"id": user_id},
            {"$set": {"token_version": version, "updated_at": updated_at}},
        )

    # ── Memberships (tenant-scoped) ───────────────────────────────────────────

    async def find_membership(self, tenant_id: str, user_id: str) -> Optional[Dict]:
        return await db.tenant_memberships.find_one(
            {"tenant_id": tenant_id, "user_id": user_id},
            {"_id": 0},
        )

    async def find_members_for_tenant(
        self,
        tenant_id: str,
        filters: Optional[Dict] = None,
        pagination: Optional[PaginationParams] = None,
    ) -> Tuple[List[Dict], int]:
        """Lista memberships do tenant com dados do usuário. Retorna (items, total)."""
        query = {"tenant_id": tenant_id, **(filters or {})}
        cursor = db.tenant_memberships.find(query, {"_id": 0})
        cursor = cursor.sort("created_at", -1)
        if pagination:
            cursor = cursor.skip(pagination.skip).limit(pagination.page_size)
        members = await cursor.to_list(pagination.page_size if pagination else 200)
        total = await db.tenant_memberships.count_documents(query)
        return members, total

    async def find_member_by_id_for_tenant(self, tenant_id: str, user_id: str) -> Optional[Dict]:
        return await db.tenant_memberships.find_one(
            {"tenant_id": tenant_id, "user_id": user_id},
            {"_id": 0},
        )

    async def create_membership(self, data: Dict[str, Any]) -> Dict:
        await db.tenant_memberships.insert_one({**data})
        return data

    async def update_membership(
        self, tenant_id: str, user_id: str, data: Dict[str, Any]
    ) -> Optional[Dict]:
        from pymongo import ReturnDocument
        return await db.tenant_memberships.find_one_and_update(
            {"tenant_id": tenant_id, "user_id": user_id},
            {"$set": data},
            return_document=ReturnDocument.AFTER,
            projection={"_id": 0},
        )


# Singleton
user_repo = UserRepository()
