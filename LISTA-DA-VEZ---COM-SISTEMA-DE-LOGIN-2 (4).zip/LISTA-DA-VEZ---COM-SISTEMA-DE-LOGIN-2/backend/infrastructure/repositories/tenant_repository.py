"""TenantRepository — acesso seguro à coleção de tenants."""
from typing import Any, Dict, List, Optional, Tuple
from db import db
from .base import BaseRepository, PaginationParams


class TenantRepository(BaseRepository):
    def __init__(self):
        super().__init__(db.tenants)

    async def find_by_slug(self, slug: str) -> Optional[Dict]:
        return await self._find_one({"slug": slug})

    async def find_by_id(self, tenant_id: str) -> Optional[Dict]:
        return await self._find_one({"id": tenant_id})

    async def find_many(
        self,
        filters: Optional[Dict] = None,
        pagination: Optional[PaginationParams] = None,
    ) -> Tuple[List[Dict], int]:
        query = filters or {}
        items = await self._find_many(query, pagination, sort=[("created_at", -1)])
        total = await self._count(query)
        return items, total

    async def create(self, data: Dict[str, Any]) -> Dict:
        return await self._insert_one(data)

    async def update(self, tenant_id: str, data: Dict[str, Any]) -> Optional[Dict]:
        return await self._update_one(
            {"id": tenant_id},
            {"$set": {**data}},
        )

    async def update_status(self, tenant_id: str, status: str, updated_at: str) -> Optional[Dict]:
        return await self._update_one(
            {"id": tenant_id},
            {"$set": {"status": status, "updated_at": updated_at}},
        )


# Singleton
tenant_repo = TenantRepository()
