"""BaseRepository — abstração segura para acesso ao MongoDB.

Regras:
- Todo método tenant-scoped exige tenant_id explícito.
- find_by_id sem tenant_id só é permitido para entidades globais (User por email, Tenant por slug).
- Sempre aplicar projection para evitar vazar campos sensíveis.
- Paginação obrigatória em listagens.
"""
from typing import Any, Dict, List, Optional, Tuple
from motor.motor_asyncio import AsyncIOMotorCollection


class PaginationParams:
    def __init__(self, page: int = 1, page_size: int = 20):
        self.page = max(1, page)
        self.page_size = min(max(1, page_size), 200)
        self.skip = (self.page - 1) * self.page_size


class BaseRepository:
    """Repository base com helpers para queries tenant-scoped seguras."""

    def __init__(self, collection: AsyncIOMotorCollection):
        self._col = collection

    async def _find_one(
        self,
        query: Dict[str, Any],
        projection: Optional[Dict] = None,
    ) -> Optional[Dict]:
        doc = await self._col.find_one(query, projection or {"_id": 0})
        return doc

    async def _find_many(
        self,
        query: Dict[str, Any],
        pagination: Optional[PaginationParams] = None,
        sort: Optional[List[Tuple[str, int]]] = None,
        projection: Optional[Dict] = None,
    ) -> List[Dict]:
        cursor = self._col.find(query, projection or {"_id": 0})
        if sort:
            cursor = cursor.sort(sort)
        if pagination:
            cursor = cursor.skip(pagination.skip).limit(pagination.page_size)
        return await cursor.to_list(length=pagination.page_size if pagination else 500)

    async def _count(self, query: Dict[str, Any]) -> int:
        return await self._col.count_documents(query)

    async def _insert_one(self, doc: Dict[str, Any]) -> Dict[str, Any]:
        await self._col.insert_one({**doc})
        return doc

    async def _update_one(
        self,
        query: Dict[str, Any],
        update: Dict[str, Any],
        return_document: bool = True,
    ) -> Optional[Dict]:
        from pymongo import ReturnDocument
        doc = await self._col.find_one_and_update(
            query,
            update,
            return_document=ReturnDocument.AFTER if return_document else ReturnDocument.BEFORE,
            projection={"_id": 0},
        )
        return doc

    async def find_by_id_for_tenant(
        self,
        tenant_id: str,
        entity_id: str,
        projection: Optional[Dict] = None,
    ) -> Optional[Dict]:
        """Busca segura por ID dentro de um tenant. Nunca vaza dados cross-tenant."""
        return await self._find_one(
            {"tenant_id": tenant_id, "id": entity_id},
            projection,
        )

    async def find_many_for_tenant(
        self,
        tenant_id: str,
        filters: Optional[Dict] = None,
        pagination: Optional[PaginationParams] = None,
        sort: Optional[List[Tuple[str, int]]] = None,
        projection: Optional[Dict] = None,
    ) -> Tuple[List[Dict], int]:
        """Listagem paginada tenant-scoped. Retorna (items, total)."""
        query = {"tenant_id": tenant_id, **(filters or {})}
        items = await self._find_many(query, pagination, sort, projection)
        total = await self._count(query)
        return items, total
