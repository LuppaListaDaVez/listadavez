"""SalesRepository — acesso seguro a vendas e itens."""
from typing import Any, Dict, List, Optional, Tuple
from pymongo import ReturnDocument
from db import db
from .base import BaseRepository, PaginationParams


class SalesRepository(BaseRepository):
    def __init__(self):
        super().__init__(db.sales)

    async def find_by_id_for_tenant(
        self, tenant_id: str, sale_id: str, projection: Optional[Dict] = None
    ) -> Optional[Dict]:
        return await self._find_one(
            {"tenant_id": tenant_id, "id": sale_id}, projection
        )

    async def find_many_for_tenant(
        self,
        tenant_id: str,
        filters: Optional[Dict] = None,
        pagination: Optional[PaginationParams] = None,
    ) -> Tuple[List[Dict], int]:
        query = {"tenant_id": tenant_id, **(filters or {})}
        items = await self._find_many(
            query, pagination, sort=[("created_at", -1)]
        )
        total = await self._count(query)
        return items, total

    async def find_many_for_seller(
        self,
        tenant_id: str,
        seller_id: str,
        filters: Optional[Dict] = None,
        pagination: Optional[PaginationParams] = None,
    ) -> Tuple[List[Dict], int]:
        base = {"tenant_id": tenant_id, "seller_id": seller_id}
        query = {**base, **(filters or {})}
        items = await self._find_many(query, pagination, sort=[("created_at", -1)])
        total = await self._count(query)
        return items, total

    async def find_many_for_store(
        self,
        tenant_id: str,
        store_id: str,
        filters: Optional[Dict] = None,
        pagination: Optional[PaginationParams] = None,
    ) -> Tuple[List[Dict], int]:
        base = {"tenant_id": tenant_id, "store_id": store_id}
        query = {**base, **(filters or {})}
        items = await self._find_many(query, pagination, sort=[("created_at", -1)])
        total = await self._count(query)
        return items, total

    async def create_for_tenant(self, tenant_id: str, data: Dict[str, Any]) -> Dict:
        doc = {"tenant_id": tenant_id, **data}
        return await self._insert_one(doc)

    async def cancel_for_tenant(
        self,
        tenant_id: str,
        sale_id: str,
        cancelled_by: str,
        cancelled_at: str,
        reason: Optional[str] = None,
    ) -> Optional[Dict]:
        return await self._col.find_one_and_update(
            {"tenant_id": tenant_id, "id": sale_id, "status": {"$ne": "CANCELLED"}},
            {"$set": {
                "status": "CANCELLED",
                "cancelled_by": cancelled_by,
                "cancelled_at": cancelled_at,
                "cancel_reason": reason,
            }},
            return_document=ReturnDocument.AFTER,
            projection={"_id": 0},
        )

    async def find_items_for_sale(self, tenant_id: str, sale_id: str) -> List[Dict]:
        cursor = db.sale_items.find(
            {"tenant_id": tenant_id, "sale_id": sale_id},
            {"_id": 0},
        )
        return await cursor.to_list(200)

    async def create_items(self, items: List[Dict]) -> None:
        if items:
            await db.sale_items.insert_many([{**i} for i in items])

    async def sum_amount_for_store(
        self, tenant_id: str, store_id: str, date_from: str, date_to: str
    ) -> int:
        """Soma total de vendas em centavos para uma loja em um período."""
        pipeline = [
            {"$match": {
                "tenant_id": tenant_id,
                "store_id": store_id,
                "status": {"$ne": "CANCELLED"},
                "created_at": {"$gte": date_from, "$lte": date_to},
            }},
            {"$group": {"_id": None, "total": {"$sum": "$net_amount_cents"}}},
        ]
        result = await db.sales.aggregate(pipeline).to_list(1)
        return result[0]["total"] if result else 0


# Singleton
sales_repo = SalesRepository()
