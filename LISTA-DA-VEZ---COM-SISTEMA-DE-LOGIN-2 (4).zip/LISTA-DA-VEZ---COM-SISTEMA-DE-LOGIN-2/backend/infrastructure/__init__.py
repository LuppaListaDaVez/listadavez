"""Infrastructure layer — MongoDB repositories, Redis, external adapters."""
