"""Helpers para verificar feature flags em endpoints."""
from fastapi import HTTPException
from features import is_enabled


async def require_feature(tenant_id: str, feature_key: str):
    if not await is_enabled(tenant_id, feature_key):
        raise HTTPException(
            status_code=403,
            detail={
                "error": "FEATURE_DISABLED",
                "message": "Esta funcionalidade não está disponível no plano atual.",
            },
        )
