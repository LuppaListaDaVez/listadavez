"""Google OAuth via Emergent Auth — rotas de callback para Super Admin e Tenant.

Fluxo:
  1. Frontend redireciona para https://auth.emergentagent.com/?redirect=...
  2. Google autentica → Emergent redireciona de volta com #session_id=...
  3. Frontend lê session_id e chama estes endpoints
  4. Backend troca session_id por dados do usuário e emite JWT local
"""
import logging
import os
from typing import Optional

import httpx
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from db import db
from models import new_id, utcnow_iso
from routes_auth import _issue_tokens_with_session, _build_memberships
from routes_tenant_auth import _issue_tenant_tokens
from session_service import create_session
from security_event_service import log_security_event, SecurityEventType
from audit import log_audit
from rate_limit_service import get_client_ip

logger = logging.getLogger(__name__)

EMERGENT_AUTH_URL = "https://demobackend.emergentagent.com/auth/v1/env/oauth/session-data"

router = APIRouter(tags=["google-auth"])


class GoogleCallbackPayload(BaseModel):
    session_id: str
    tenant_slug: Optional[str] = None


async def _exchange_session_id(session_id: str) -> dict:
    """Troca session_id por dados do usuário via Emergent Auth."""
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(
                EMERGENT_AUTH_URL,
                headers={"X-Session-ID": session_id},
            )
            if resp.status_code != 200:
                logger.warning("Emergent Auth retornou %s para session_id=%s", resp.status_code, session_id[:8])
                raise HTTPException(status_code=401, detail="Sessão Google inválida ou expirada.")
            return resp.json()
    except httpx.RequestError as exc:
        logger.error("Erro ao contatar Emergent Auth: %s", exc)
        raise HTTPException(status_code=503, detail="Serviço de autenticação indisponível.")


# ── Super Admin Google Login ─────────────────────────────────────────────────
@router.post("/auth/google/callback")
async def super_admin_google_callback(payload: GoogleCallbackPayload, request: Request):
    """Troca session_id Google por JWT de Super Admin.

    Regra: apenas o e-mail configurado em SUPER_ADMIN_EMAIL tem acesso.
    """
    ip = get_client_ip(request)
    user_agent = request.headers.get("user-agent")

    google_data = await _exchange_session_id(payload.session_id)
    email = google_data.get("email", "").lower().strip()
    name = google_data.get("name", "")
    picture = google_data.get("picture", "")

    if not email:
        raise HTTPException(status_code=401, detail="E-mail não fornecido pelo Google.")

    # Verificar se é o Super Admin
    super_admin_email = os.environ.get("SUPER_ADMIN_EMAIL", "").lower().strip()
    if email != super_admin_email:
        await log_security_event(
            event_type=SecurityEventType.SUPER_ADMIN_LOGIN_FAILED,
            ip=ip, user_agent=user_agent,
            metadata={"reason": "google_email_not_super_admin", "email_hint": email[:3] + "***"},
            request=request,
        )
        raise HTTPException(
            status_code=403,
            detail={"error": "NOT_AUTHORIZED", "message": "Esta conta Google não tem acesso de Super Admin."},
        )

    # Buscar usuário no banco
    user = await db.users.find_one({"email": email})
    if not user or user.get("status") != "ACTIVE" or not user.get("is_super_admin"):
        raise HTTPException(status_code=403, detail="Conta de Super Admin não encontrada.")

    # Atualizar avatar se disponível
    if picture:
        await db.users.update_one(
            {"id": user["id"]},
            {"$set": {"avatar_url": picture, "last_login_at": utcnow_iso(), "updated_at": utcnow_iso()}},
        )

    session = await create_session(
        user_id=user["id"],
        auth_context="SUPER_ADMIN",
        ip=ip,
        user_agent=user_agent,
    )

    access_token, refresh_token = await _issue_tokens_with_session(
        user=user,
        auth_context="SUPER_ADMIN",
        session_id=session["id"],
        ip=ip,
        user_agent=user_agent,
    )

    await log_security_event(
        event_type=SecurityEventType.SUPER_ADMIN_LOGIN_SUCCESS,
        user_id=user["id"], session_id=session["id"],
        ip=ip, user_agent=user_agent, request=request,
    )
    await log_audit(
        action="LOGIN_GOOGLE", entity="user", entity_id=user["id"],
        user_id=user["id"], request=request,
    )

    memberships = await _build_memberships(user["id"])

    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer",
        "auth_context": "SUPER_ADMIN",
        "session_id": session["id"],
        "user": {
            "id": user["id"],
            "name": user.get("name") or name,
            "email": user["email"],
            "avatar_url": picture or user.get("avatar_url"),
            "is_super_admin": True,
        },
        "memberships": memberships,
    }


# ── Tenant Google Login ──────────────────────────────────────────────────────
@router.post("/tenants/{tenant_slug}/auth/google/callback")
async def tenant_google_callback(
    tenant_slug: str,
    payload: GoogleCallbackPayload,
    request: Request,
):
    """Troca session_id Google por JWT de Tenant.

    Regra: o e-mail deve já existir como membro ativo do tenant (convite obrigatório).
    """
    ip = get_client_ip(request)
    user_agent = request.headers.get("user-agent")

    google_data = await _exchange_session_id(payload.session_id)
    email = google_data.get("email", "").lower().strip()
    picture = google_data.get("picture", "")

    if not email:
        raise HTTPException(status_code=401, detail="E-mail não fornecido pelo Google.")

    # Resolver tenant
    tenant = await db.tenants.find_one({"slug": tenant_slug})
    if not tenant:
        raise HTTPException(status_code=404, detail="Empresa não encontrada.")
    if tenant.get("status") not in ("ACTIVE", "TRIAL"):
        raise HTTPException(status_code=403, detail="Empresa não está ativa.")

    # Verificar usuário
    user = await db.users.find_one({"email": email})
    if not user or user.get("status") != "ACTIVE":
        await log_security_event(
            event_type=SecurityEventType.LOGIN_FAILED,
            tenant_id=tenant["id"], tenant_slug=tenant_slug,
            ip=ip, user_agent=user_agent,
            metadata={"reason": "google_user_not_found", "email_hint": email[:3] + "***"},
            request=request,
        )
        raise HTTPException(
            status_code=403,
            detail={
                "error": "NOT_INVITED",
                "message": "Esta conta Google não tem acesso a esta empresa. Solicite um convite ao administrador.",
            },
        )

    # Verificar membership ativa
    membership = await db.tenant_memberships.find_one(
        {"tenant_id": tenant["id"], "user_id": user["id"], "status": "ACTIVE"}
    )
    if not membership:
        await log_security_event(
            event_type=SecurityEventType.LOGIN_FAILED,
            tenant_id=tenant["id"], tenant_slug=tenant_slug,
            user_id=user["id"], ip=ip, user_agent=user_agent,
            metadata={"reason": "google_no_membership"},
            request=request,
        )
        raise HTTPException(
            status_code=403,
            detail={
                "error": "NOT_INVITED",
                "message": "Esta conta Google não tem acesso a esta empresa. Solicite um convite ao administrador.",
            },
        )

    membership.pop("_id", None)

    # Atualizar avatar se disponível
    if picture:
        await db.users.update_one(
            {"id": user["id"]},
            {"$set": {"avatar_url": picture, "last_login_at": utcnow_iso(), "updated_at": utcnow_iso()}},
        )

    access_token, refresh_raw, session = await _issue_tenant_tokens(
        user=user,
        tenant=tenant,
        membership=membership,
        ip=ip,
        user_agent=user_agent,
    )

    await log_security_event(
        event_type=SecurityEventType.LOGIN_SUCCESS,
        tenant_id=tenant["id"], tenant_slug=tenant_slug,
        user_id=user["id"], session_id=session["id"],
        ip=ip, user_agent=user_agent, request=request,
    )
    await log_audit(
        action="TENANT_LOGIN_GOOGLE", entity="user", entity_id=user["id"],
        tenant_id=tenant["id"], user_id=user["id"], request=request,
    )

    return {
        "access_token": access_token,
        "refresh_token": refresh_raw,
        "token_type": "bearer",
        "auth_context": "TENANT",
        "tenant_slug": tenant["slug"],
        "tenant_id": tenant["id"],
        "session_id": session["id"],
        "user": {
            "id": user["id"],
            "name": user["name"],
            "email": user["email"],
            "avatar_url": picture or user.get("avatar_url"),
            "is_super_admin": False,
        },
        "membership": {
            "role": membership["role"],
            "store_ids": membership.get("store_ids", []),
        },
    }
