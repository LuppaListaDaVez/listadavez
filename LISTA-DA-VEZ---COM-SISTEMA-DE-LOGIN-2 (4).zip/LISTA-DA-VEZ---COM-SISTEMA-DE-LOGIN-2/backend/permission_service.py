"""Lista da Vez — PermissionService (Etapa 6).

Centraliza validação de permissões, acesso a stores e filtros de dados.
"""
from fastapi import HTTPException

from db import db
from permissions import ROLE_PERMISSIONS


def has_permission(role: str, permission_key: str) -> bool:
    """Verifica se o role tem a permissão especificada."""
    return permission_key in ROLE_PERMISSIONS.get(role, [])


def require_permission(role: str, permission_key: str):
    """Lança HTTPException 403 se o role não tiver a permissão."""
    if not has_permission(role, permission_key):
        raise HTTPException(
            status_code=403,
            detail={
                "error": "PERMISSION_DENIED",
                "message": "Permissão insuficiente para esta ação.",
            },
        )


def can_access_store(membership: dict, store_id: str) -> bool:
    """Verifica se o membership permite acesso à loja especificada."""
    role = membership.get("role", "")
    if role == "TENANT_ADMIN":
        return True
    if role == "REGIONAL_MANAGER":
        store_ids = membership.get("store_ids") or []
        # Regional manager com store_ids vazio tem acesso a todas as lojas
        return not store_ids or store_id in store_ids
    return store_id in (membership.get("store_ids") or [])


def require_store_access(membership: dict, store_id: str):
    """Lança HTTPException 403 se o usuário não tiver acesso à loja."""
    if not can_access_store(membership, store_id):
        raise HTTPException(
            status_code=403,
            detail={
                "error": "STORE_ACCESS_DENIED",
                "message": "Você não tem acesso a esta unidade.",
            },
        )


async def get_accessible_store_ids(membership: dict, tenant_id: str) -> list[str]:
    """Retorna a lista de store_ids acessíveis para o membership."""
    role = membership.get("role", "")
    if role == "TENANT_ADMIN":
        stores = await db.stores.find({"tenant_id": tenant_id}).to_list(500)
        return [s["id"] for s in stores]
    if role == "REGIONAL_MANAGER":
        store_ids = membership.get("store_ids") or []
        if not store_ids:
            stores = await db.stores.find({"tenant_id": tenant_id}).to_list(500)
            return [s["id"] for s in stores]
        return list(store_ids)
    if role in ("STORE_MANAGER", "SUPERVISOR"):
        return list(membership.get("store_ids") or [])
    if role == "SELLER":
        user_id = membership.get("user_id")
        if user_id:
            profile = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": user_id})
            if profile:
                return [profile["store_id"]]
        return list(membership.get("store_ids") or [])
    return []


def build_store_filter(membership: dict, requested_store_id: str | None = None) -> dict:
    """Constrói filtro de store_id para queries MongoDB baseado no membership."""
    role = membership.get("role", "")
    if role == "TENANT_ADMIN":
        if requested_store_id:
            return {"store_id": requested_store_id}
        return {}
    if role == "REGIONAL_MANAGER":
        store_ids = membership.get("store_ids") or []
        if not store_ids:
            if requested_store_id:
                return {"store_id": requested_store_id}
            return {}
        if requested_store_id:
            if requested_store_id in store_ids:
                return {"store_id": requested_store_id}
            raise HTTPException(
                status_code=403,
                detail={"error": "STORE_ACCESS_DENIED", "message": "Você não tem acesso a esta unidade."},
            )
        return {"store_id": {"$in": store_ids}}
    if role in ("STORE_MANAGER", "SUPERVISOR"):
        store_ids = membership.get("store_ids") or []
        if requested_store_id:
            if requested_store_id in store_ids:
                return {"store_id": requested_store_id}
            raise HTTPException(
                status_code=403,
                detail={"error": "STORE_ACCESS_DENIED", "message": "Você não tem acesso a esta unidade."},
            )
        return {"store_id": {"$in": store_ids}} if store_ids else {"store_id": "__no_access__"}
    # SELLER e outros — filtro vazio; a lógica específica fica no endpoint
    return {}
