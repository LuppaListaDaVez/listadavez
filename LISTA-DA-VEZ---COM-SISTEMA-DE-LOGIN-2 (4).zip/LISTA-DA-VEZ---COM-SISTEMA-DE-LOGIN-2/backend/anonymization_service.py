"""AnonymizationService — Anonimização segura preservando integridade (Etapa 14)."""
from db import db
from models import new_id, utcnow_iso
from audit import log_audit
from data_protection_service import ANON_NAME, ANON_CUSTOMER_NAME, anon_email


async def _check_legal_hold(tenant_id: str, entity_id: str) -> bool:
    hold = await db.legal_holds.find_one({
        "tenant_id": tenant_id, "status": "ACTIVE", "entity_id": entity_id
    })
    return hold is not None


async def anonymize_user(tenant_id: str, target_user_id: str, created_by: str,
                         request_id: str = None, request=None) -> dict:
    """Anonimiza dados pessoais de um usuário. Preserva IDs e valores agregados."""
    if await _check_legal_hold(tenant_id, target_user_id):
        raise ValueError("Dados do usuário estão sob legal hold ativo.")
    
    now = utcnow_iso()
    job = {
        "id": new_id(), "tenant_id": tenant_id, "request_id": request_id,
        "target_type": "USER", "target_user_id": target_user_id,
        "target_customer_ref": None, "status": "RUNNING",
        "fields_anonymized": [], "records_affected": 0,
        "started_at": now, "finished_at": None,
        "error_code": None, "error_message": None,
        "created_by": created_by, "created_at": now,
    }
    await db.anonymization_jobs.insert_one(job)
    job_id = job["id"]
    
    try:
        affected = 0
        fields_done = []
        
        # Anonimizar feedbacks do author
        fb_result = await db.feedbacks.update_many(
            {"tenant_id": tenant_id, "author_id": target_user_id},
            {"$set": {"author_name": ANON_NAME}}
        )
        if fb_result.modified_count:
            affected += fb_result.modified_count
            fields_done.append("feedbacks.author_name")
        
        # Anonimizar notificações pessoais
        await db.notifications.delete_many(
            {"tenant_id": tenant_id, "user_id": target_user_id}
        )
        fields_done.append("notifications_deleted")
        
        # Anonimizar seller_profile se existir
        sp = await db.seller_profiles.find_one(
            {"tenant_id": tenant_id, "user_id": target_user_id}
        )
        if sp:
            await db.seller_profiles.update_one(
                {"id": sp["id"]},
                {"$set": {"notes": None, "phone": None}}
            )
            affected += 1
            fields_done.append("seller_profile.phone_notes")
        
        # Atualizar job
        await db.anonymization_jobs.update_one({"id": job_id}, {"$set": {
            "status": "COMPLETED", "finished_at": utcnow_iso(),
            "fields_anonymized": fields_done, "records_affected": affected,
        }})
        await log_audit(action="DATA_SUBJECT_ANONYMIZATION_COMPLETED", entity="user",
                        entity_id=target_user_id, tenant_id=tenant_id,
                        user_id=created_by, request=request)
        job.update({"status": "COMPLETED", "fields_anonymized": fields_done, "records_affected": affected})
    except Exception as e:
        await db.anonymization_jobs.update_one({"id": job_id}, {"$set": {
            "status": "FAILED", "finished_at": utcnow_iso(), "error_message": str(e)[:200],
        }})
        raise
    
    job.pop("_id", None)
    return job


async def anonymize_customer(tenant_id: str, customer_ref: str, created_by: str,
                              request_id: str = None, request=None) -> dict:
    """Anonimiza dados de cliente em atendimentos e visitas. Preserva métricas."""
    now = utcnow_iso()
    job = {
        "id": new_id(), "tenant_id": tenant_id, "request_id": request_id,
        "target_type": "CUSTOMER", "target_user_id": None,
        "target_customer_ref": customer_ref, "status": "RUNNING",
        "fields_anonymized": [], "records_affected": 0,
        "started_at": now, "finished_at": None,
        "error_code": None, "error_message": None,
        "created_by": created_by, "created_at": now,
    }
    await db.anonymization_jobs.insert_one(job)
    job_id = job["id"]
    
    anon_fields = {
        "customer_name": ANON_CUSTOMER_NAME,
        "customer_phone": None,
        "customer_email": None,
        "customer_note": None,
    }
    
    try:
        affected = 0
        fields_done = []
        
        # Anonimizar em atendimentos
        att = await db.attendances.update_many(
            {"tenant_id": tenant_id, "customer_ref": customer_ref},
            {"$set": anon_fields}
        )
        if att.modified_count:
            affected += att.modified_count
            fields_done.append("attendances.customer_fields")
        
        # Anonimizar em visitas de cliente
        cv = await db.customer_visits.update_many(
            {"tenant_id": tenant_id, "customer_ref": customer_ref},
            {"$set": {"customer_name": ANON_CUSTOMER_NAME, "customer_phone": None}}
        )
        if cv.modified_count:
            affected += cv.modified_count
            fields_done.append("customer_visits.customer_fields")
        
        await db.anonymization_jobs.update_one({"id": job_id}, {"$set": {
            "status": "COMPLETED", "finished_at": utcnow_iso(),
            "fields_anonymized": fields_done, "records_affected": affected,
        }})
        await log_audit(action="DATA_SUBJECT_ANONYMIZATION_COMPLETED", entity="customer",
                        entity_id=customer_ref, tenant_id=tenant_id,
                        user_id=created_by, request=request)
        job.update({"status": "COMPLETED", "fields_anonymized": fields_done, "records_affected": affected})
    except Exception as e:
        await db.anonymization_jobs.update_one({"id": job_id}, {"$set": {
            "status": "FAILED", "finished_at": utcnow_iso(), "error_message": str(e)[:200],
        }})
        raise
    
    job.pop("_id", None)
    return job


async def list_jobs(tenant_id: str, limit: int = 20) -> list:
    cursor = db.anonymization_jobs.find({"tenant_id": tenant_id}, {"_id": 0}).sort("created_at", -1).limit(limit)
    return await cursor.to_list(length=limit)
