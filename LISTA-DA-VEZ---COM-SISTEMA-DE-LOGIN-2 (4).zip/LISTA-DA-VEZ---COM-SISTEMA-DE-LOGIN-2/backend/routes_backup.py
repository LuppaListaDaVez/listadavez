"""Endpoints de Backup e Restore — Etapa 14."""
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from typing import Optional
from security import resolve_tenant_context
from feature_guard import require_feature
from permissions import (
    ROLE_PERMISSIONS,
    P_BACKUP_VIEW, P_BACKUP_CREATE, P_BACKUP_DOWNLOAD,
    P_BACKUP_DELETE, P_BACKUP_RESTORE_PREVIEW, P_BACKUP_RESTORE_EXECUTE,
    P_BACKUP_LOGS_VIEW,
)
import backup_service as bk_svc
import restore_service as rs_svc

router = APIRouter(prefix="/tenants/{tenant_slug}", tags=["backup"])


def _has(role, *perms):
    return any(p in ROLE_PERMISSIONS.get(role, []) for p in perms)


# ─── Backups ──────────────────────────────────────────────────────────────────

@router.get("/backups")
async def list_backups(ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "backup_restore")
    if not _has(ctx["membership"]["role"], P_BACKUP_VIEW):
        raise HTTPException(403, "Sem permissão.")
    return await bk_svc.list_snapshots(ctx["tenant"]["id"])


@router.post("/backups")
async def create_backup(
    body: dict,
    request: Request,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "backup_restore")
    if not _has(ctx["membership"]["role"], P_BACKUP_CREATE):
        raise HTTPException(403, "Sem permissão.")
    backup_type = body.get("backup_type", "TENANT_FULL")
    try:
        return await bk_svc.create_backup(
            ctx["tenant"]["id"], backup_type, ctx["user"]["id"], request
        )
    except Exception as e:
        raise HTTPException(500, f"Erro ao criar backup: {str(e)[:200]}")


@router.get("/backups/{backup_id}")
async def get_backup(backup_id: str, ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "backup_restore")
    if not _has(ctx["membership"]["role"], P_BACKUP_VIEW):
        raise HTTPException(403, "Sem permissão.")
    doc = await bk_svc.get_snapshot(ctx["tenant"]["id"], backup_id)
    if not doc:
        raise HTTPException(404, "Backup não encontrado.")
    return doc


@router.get("/backups/{backup_id}/download")
async def download_backup(
    backup_id: str,
    request: Request,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "backup_restore")
    if not _has(ctx["membership"]["role"], P_BACKUP_DOWNLOAD):
        raise HTTPException(403, "Sem permissão.")
    result = await bk_svc.download_snapshot(
        ctx["tenant"]["id"], backup_id, ctx["user"]["id"], request
    )
    if not result:
        raise HTTPException(404, "Backup não disponível ou expirado.")
    return result


@router.delete("/backups/{backup_id}")
async def delete_backup(
    backup_id: str,
    request: Request,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "backup_restore")
    if not _has(ctx["membership"]["role"], P_BACKUP_DELETE):
        raise HTTPException(403, "Sem permissão.")
    ok = await bk_svc.delete_snapshot(
        ctx["tenant"]["id"], backup_id, ctx["user"]["id"], request
    )
    if not ok:
        raise HTTPException(404, "Backup não encontrado.")
    return {"message": "Backup excluído com sucesso."}


@router.get("/backup-jobs")
async def list_backup_jobs(ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "backup_restore")
    if not _has(ctx["membership"]["role"], P_BACKUP_LOGS_VIEW):
        raise HTTPException(403, "Sem permissão.")
    return await bk_svc.list_jobs(ctx["tenant"]["id"])


# ─── Restore ──────────────────────────────────────────────────────────────────

class RestorePreviewPayload(BaseModel):
    snapshot_id: str
    mode: str = "RESTORE_CONFIG_ONLY"


class RestoreExecutePayload(BaseModel):
    snapshot_id: str
    restore_job_id: Optional[str] = None
    mode: str = "RESTORE_CONFIG_ONLY"
    confirmation: str
    reason: str = ""


@router.post("/restore/preview")
async def restore_preview(
    payload: RestorePreviewPayload,
    request: Request,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "backup_restore")
    if not _has(ctx["membership"]["role"], P_BACKUP_RESTORE_PREVIEW):
        raise HTTPException(403, "Sem permissão.")
    try:
        return await rs_svc.create_preview(
            ctx["tenant"]["id"], payload.snapshot_id, payload.mode,
            ctx["user"]["id"], request
        )
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.post("/restore/execute")
async def restore_execute(
    payload: RestoreExecutePayload,
    request: Request,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "backup_restore")
    if not _has(ctx["membership"]["role"], P_BACKUP_RESTORE_EXECUTE):
        raise HTTPException(403, "Sem permissão. Apenas Tenant Admin pode executar restore.")
    try:
        return await rs_svc.execute_restore(
            ctx["tenant"]["id"], payload.restore_job_id, payload.snapshot_id,
            payload.mode, payload.confirmation, payload.reason,
            ctx["user"]["id"], request
        )
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.get("/restore-jobs")
async def list_restore_jobs(ctx: dict = Depends(resolve_tenant_context)):
    await require_feature(ctx["tenant"]["id"], "backup_restore")
    if not _has(ctx["membership"]["role"], P_BACKUP_RESTORE_PREVIEW, P_BACKUP_RESTORE_EXECUTE):
        raise HTTPException(403, "Sem permissão.")
    return await rs_svc.list_jobs(ctx["tenant"]["id"])


@router.get("/restore-jobs/{restore_job_id}")
async def get_restore_job(
    restore_job_id: str,
    ctx: dict = Depends(resolve_tenant_context),
):
    await require_feature(ctx["tenant"]["id"], "backup_restore")
    doc = await rs_svc.get_job(ctx["tenant"]["id"], restore_job_id)
    if not doc:
        raise HTTPException(404, "Job de restore não encontrado.")
    return doc
