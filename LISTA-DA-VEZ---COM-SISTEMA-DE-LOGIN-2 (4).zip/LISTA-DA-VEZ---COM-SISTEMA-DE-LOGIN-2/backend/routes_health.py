"""Health check endpoints — P0/P1.5 / P2 (Prometheus metrics)."""
import logging
import os
import time

from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse, PlainTextResponse

from db import client, db
from realtime import event_bus
from security import require_super_admin
from observability import metrics

logger = logging.getLogger("lista-da-vez.health")
router = APIRouter(prefix="/health", tags=["health"])
health_router = router  # alias para importação no v1
metrics_router = APIRouter(prefix="/metrics", tags=["metrics"])


@router.get("")
async def health():
    return {"status": "ok", "service": "lista-da-vez-api", "version": "1.0.0-p2"}


@router.get("/live")
async def health_live():
    """Liveness probe — retorna ok se o processo está vivo."""
    return {"status": "ok"}


@router.get("/ready")
async def health_ready():
    """Readiness probe — verifica banco e Redis (se configurado).
    Retorna 503 se qualquer dependência obrigatória estiver indisponível."""
    result: dict = {"status": "ok"}

    # Verifica MongoDB (obrigatório)
    try:
        await client.admin.command("ping")
        result["db"] = "connected"
    except Exception:
        return JSONResponse(
            status_code=503,
            content={"status": "degraded", "db": "unreachable"},
        )

    # Verifica Redis (se configurado)
    redis_url = os.environ.get("REDIS_URL")
    if redis_url:
        try:
            import redis.asyncio as _aioredis  # type: ignore
            _r = _aioredis.from_url(redis_url, socket_connect_timeout=2)
            await _r.ping()
            await _r.aclose()
            result["redis"] = "connected"
        except ImportError:
            result["redis"] = "library_not_installed"
        except Exception as exc:
            result["redis"] = "unreachable"
            result["redis_error"] = str(exc)[:100]
            result["status"] = "degraded"
            return JSONResponse(status_code=503, content=result)
    else:
        result["redis"] = "not_configured"

    # Verifica export_jobs dispatcher (indica workers saudáveis)
    try:
        pending = await db.export_jobs.count_documents({"status": "QUEUED"})
        result["export_dispatcher"] = "ok"
        result["export_jobs_queued"] = pending
    except Exception:
        result["export_dispatcher"] = "unknown"

    return result


@router.get("/db")
async def health_db():
    try:
        await client.admin.command("ping")
        await db.tenants.estimated_document_count()
        return {"status": "ok", "db": "postgresql"}
    except Exception:
        return JSONResponse(
            status_code=503,
            content={"status": "error", "db": "unreachable"},
        )


@metrics_router.get("", dependencies=[Depends(require_super_admin)])
async def metrics_json():
    """Métricas operacionais em formato JSON (legado)."""
    snap = metrics.snapshot()
    snap["websocket"] = {
        "active_connections": event_bus.get_active_connections_count(),
        "by_store": event_bus.get_active_connections_by_store(),
        "mode": event_bus.mode,
        "events_published": event_bus.events_published_count,
        "events_failed": event_bus.events_failed_count,
    }
    return snap


@metrics_router.get("/prometheus", dependencies=[Depends(require_super_admin)])
async def metrics_prometheus():
    """Métricas no formato Prometheus text (para scrapers como Grafana Agent, Prometheus).

    Exposição das métricas obrigatórias do SLA:
    - http_requests_total
    - http_request_duration_ms (p50, p95, p99)
    - http_5xx_total / http_4xx_total
    - auth_login_failed_total
    - rate_limit_exceeded_total
    - idempotency_conflict_total
    - sales_created_total
    - attendance_started_total / attendance_finished_total
    - websocket_connections_active
    - outbox_pending_total / outbox_failed_total
    - export_jobs_failed_total
    """
    snap = metrics.snapshot()
    ws_connections = event_bus.get_active_connections_count()

    # Outbox stats
    try:
        outbox_pending = await db.event_outbox.count_documents({"status": "PENDING"})
        outbox_dead = await db.event_outbox.count_documents({"status": "DEAD_LETTER"})
    except Exception:
        outbox_pending = outbox_dead = -1

    # Export jobs
    try:
        export_failed = await db.export_jobs.count_documents({"status": "FAILED"})
        export_queued = await db.export_jobs.count_documents({"status": "QUEUED"})
    except Exception:
        export_failed = export_queued = -1

    lats = snap.get("latency_ms", {})
    errs = snap.get("errors", {})
    biz = snap.get("business", {})
    reqs = snap.get("requests", {})

    lines = [
        "# HELP http_requests_total Total HTTP requests processed",
        "# TYPE http_requests_total counter",
        f'http_requests_total {reqs.get("total", 0)}',
        "",
        "# HELP http_request_duration_p50_ms HTTP request latency P50 (ms)",
        "# TYPE http_request_duration_p50_ms gauge",
        f'http_request_duration_p50_ms {lats.get("p50", 0)}',
        "",
        "# HELP http_request_duration_p95_ms HTTP request latency P95 (ms)",
        "# TYPE http_request_duration_p95_ms gauge",
        f'http_request_duration_p95_ms {lats.get("p95", 0)}',
        "",
        "# HELP http_request_duration_p99_ms HTTP request latency P99 (ms)",
        "# TYPE http_request_duration_p99_ms gauge",
        f'http_request_duration_p99_ms {lats.get("p99", 0)}',
        "",
        "# HELP http_5xx_total Total HTTP 5xx errors",
        "# TYPE http_5xx_total counter",
        f'http_5xx_total {errs.get("5xx", 0)}',
        "",
        "# HELP http_4xx_total Total HTTP 4xx responses",
        "# TYPE http_4xx_total counter",
        f'http_4xx_total {errs.get("4xx", 0)}',
        "",
        "# HELP auth_login_failed_total Total failed login attempts",
        "# TYPE auth_login_failed_total counter",
        f'auth_login_failed_total {errs.get("login_failures", 0)}',
        "",
        "# HELP rate_limit_exceeded_total Total requests blocked by rate limiter",
        "# TYPE rate_limit_exceeded_total counter",
        f'rate_limit_exceeded_total {errs.get("rate_limit_hits", 0)}',
        "",
        "# HELP idempotency_conflict_total Total idempotency key conflicts",
        "# TYPE idempotency_conflict_total counter",
        f'idempotency_conflict_total {errs.get("idempotency_conflicts", 0)}',
        "",
        "# HELP sales_created_total Total sales created",
        "# TYPE sales_created_total counter",
        f'sales_created_total {biz.get("sales_created", 0)}',
        "",
        "# HELP attendance_started_total Total attendances started",
        "# TYPE attendance_started_total counter",
        f'attendance_started_total {biz.get("attendances_started", 0)}',
        "",
        "# HELP attendance_finished_total Total attendances finished",
        "# TYPE attendance_finished_total counter",
        f'attendance_finished_total {biz.get("attendances_finished", 0)}',
        "",
        "# HELP websocket_connections_active Current active WebSocket connections",
        "# TYPE websocket_connections_active gauge",
        f"websocket_connections_active {ws_connections}",
        "",
        "# HELP outbox_pending_total Current pending outbox events",
        "# TYPE outbox_pending_total gauge",
        f"outbox_pending_total {outbox_pending}",
        "",
        "# HELP outbox_failed_total Total dead-letter outbox events",
        "# TYPE outbox_failed_total counter",
        f"outbox_failed_total {outbox_dead}",
        "",
        "# HELP export_jobs_failed_total Total failed export jobs",
        "# TYPE export_jobs_failed_total counter",
        f"export_jobs_failed_total {export_failed}",
        "",
        "# HELP export_jobs_queued Current queued export jobs",
        "# TYPE export_jobs_queued gauge",
        f"export_jobs_queued {export_queued}",
        "",
        "# HELP app_uptime_seconds Application uptime in seconds",
        "# TYPE app_uptime_seconds counter",
        f'app_uptime_seconds {snap.get("uptime_seconds", 0)}',
        "",
        "# HELP http_rps Current requests per second",
        "# TYPE http_rps gauge",
        f'http_rps {reqs.get("rps", 0)}',
        "",
    ]
    return PlainTextResponse(
        content="\n".join(lines),
        media_type="text/plain; version=0.0.4; charset=utf-8",
    )


