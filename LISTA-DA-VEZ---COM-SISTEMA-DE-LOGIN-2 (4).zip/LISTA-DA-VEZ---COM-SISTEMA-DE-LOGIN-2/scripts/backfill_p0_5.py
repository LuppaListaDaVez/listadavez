#!/usr/bin/env python3
"""
Backfill P0.5 — Compatibilidade com dados existentes
=====================================================
Script idempotente que adiciona campos introduzidos na ONDA P0 a documentos antigos.

Operações:
  1. users.normalized_email  — email.lower().strip()
  2. users.token_version     — default 1
  3. sales.source            — inferido de attendance_id (QUEUE) ou mantém existente
  4. attendances.source      — copiado de `origin` ou derivado de queue_id
  5. stores.slug             — slugificado de `code` ou `name`

SEGURANÇA:
  - Nunca sobrescreve campos já existentes
  - Nunca inventa tenant_id
  - Nunca apaga dados
  - Relatório de inconsistências gerado em `/docs/p0-5-migration-report.md`
  - Idempotente: pode rodar múltiplas vezes com segurança

USO:
  cd /app/backend
  python ../scripts/backfill_p0_5.py [--dry-run]
"""
import asyncio
import os
import sys
import re
import logging
from datetime import datetime, timezone

from dotenv import load_dotenv
load_dotenv(os.path.join(os.path.dirname(__file__), "../backend/.env"))

from motor.motor_asyncio import AsyncIOMotorClient

MONGO_URL = os.environ["MONGO_URL"]
DB_NAME   = os.environ["DB_NAME"]

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("backfill-p0-5")

DRY_RUN = "--dry-run" in sys.argv


def slugify(text: str) -> str:
    """Converte texto para slug URL-safe."""
    text = text.lower().strip()
    text = re.sub(r"[àáâãäå]", "a", text)
    text = re.sub(r"[èéêë]", "e", text)
    text = re.sub(r"[ìíîï]", "i", text)
    text = re.sub(r"[òóôõö]", "o", text)
    text = re.sub(r"[ùúûü]", "u", text)
    text = re.sub(r"[ç]", "c", text)
    text = re.sub(r"[ñ]", "n", text)
    text = re.sub(r"[^a-z0-9\s-]", "", text)
    text = re.sub(r"[\s_]+", "-", text)
    text = re.sub(r"-+", "-", text)
    return text.strip("-")


# ─────────────────────────────────────────────────────────────────────────────
# 1. normalized_email + token_version nos users
# ─────────────────────────────────────────────────────────────────────────────
async def backfill_users(db) -> dict:
    result = {"updated_normalized_email": 0, "updated_token_version": 0,
              "conflicts": [], "errors": []}
    cursor = db.users.find({"$or": [
        {"normalized_email": {"$exists": False}},
        {"token_version": {"$exists": False}},
    ]})
    async for user in cursor:
        uid = user.get("id") or str(user.get("_id", ""))
        email = user.get("email", "")
        normalized = email.lower().strip() if email else ""

        updates = {}
        if "normalized_email" not in user:
            updates["normalized_email"] = normalized
        if "token_version" not in user:
            updates["token_version"] = 1

        if updates:
            if DRY_RUN:
                logger.info("[DRY_RUN] user %s → %s", uid[:8], updates)
            else:
                await db.users.update_one(
                    {"id": user["id"]} if user.get("id") else {"_id": user["_id"]},
                    {"$set": updates},
                )
            if "normalized_email" in updates:
                result["updated_normalized_email"] += 1
            if "token_version" in updates:
                result["updated_token_version"] += 1

    # Detectar e-mails duplicados (mesmo normalized_email)
    pipeline = [
        {"$match": {"normalized_email": {"$exists": True}}},
        {"$group": {"_id": "$normalized_email", "count": {"$sum": 1}, "ids": {"$push": "$id"}}},
        {"$match": {"count": {"$gt": 1}}},
    ]
    async for dup in db.users.aggregate(pipeline):
        result["conflicts"].append({
            "type": "DUPLICATE_NORMALIZED_EMAIL",
            "email": dup["_id"],
            "count": dup["count"],
            "user_ids": dup.get("ids", []),
        })

    return result


# ─────────────────────────────────────────────────────────────────────────────
# 2. source em sales
# ─────────────────────────────────────────────────────────────────────────────
async def backfill_sales_source(db) -> dict:
    """
    Inferência de source para vendas antigas:
    - attendance_id presente + attendance.origin == QUEUE  → QUEUE
    - attendance_id presente + attendance.origin == QUICK  → QUICK
    - attendance_id ausente                                → PROACTIVE (se tiver proactive_approach) ou OTHER
    - source já setado                                     → não alterar
    """
    result = {"updated": 0, "skipped_already_set": 0, "undetermined": 0}

    cursor = db.sales.find({"source": {"$exists": False}})
    async for sale in cursor:
        sale_id = sale.get("id")
        att_id = sale.get("attendance_id")
        inferred_source = None

        if att_id:
            att = await db.attendances.find_one({"id": att_id})
            if att:
                origin = att.get("origin") or att.get("source")
                if origin in ("QUICK",):
                    inferred_source = "QUICK"
                elif origin in ("PROACTIVE", "STORE_FLOOR"):
                    inferred_source = "PROACTIVE"
                else:
                    inferred_source = "QUEUE"
            else:
                inferred_source = "QUEUE"  # attendance foi deletada — assume QUEUE
        else:
            inferred_source = "OTHER"

        if inferred_source:
            if DRY_RUN:
                logger.info("[DRY_RUN] sale %s source=%s", sale_id, inferred_source)
            else:
                await db.sales.update_one(
                    {"id": sale_id},
                    {"$set": {"source": inferred_source}},
                )
            result["updated"] += 1
        else:
            result["undetermined"] += 1

    # Contar os que já tinham source
    result["skipped_already_set"] = await db.sales.count_documents({"source": {"$exists": True}})
    return result


# ─────────────────────────────────────────────────────────────────────────────
# 3. source em attendances (mapeado de origin)
# ─────────────────────────────────────────────────────────────────────────────
_ORIGIN_TO_SOURCE = {
    "QUEUE":     "QUEUE",
    "MANUAL":    "MANUAL",
    "QUICK":     "QUICK",
    "PROACTIVE": "PROACTIVE",
}

async def backfill_attendances_source(db) -> dict:
    result = {"updated": 0, "skipped_already_set": 0, "undetermined": 0}
    cursor = db.attendances.find({"source": {"$exists": False}})
    async for att in cursor:
        att_id = att.get("id")
        origin = att.get("origin")
        inferred_source = _ORIGIN_TO_SOURCE.get(origin, "OTHER")

        if DRY_RUN:
            logger.info("[DRY_RUN] attendance %s origin=%s → source=%s", att_id, origin, inferred_source)
        else:
            await db.attendances.update_one(
                {"id": att_id},
                {"$set": {"source": inferred_source}},
            )
        result["updated"] += 1

    result["skipped_already_set"] = await db.attendances.count_documents({"source": {"$exists": True}})
    return result


# ─────────────────────────────────────────────────────────────────────────────
# 4. slug em stores
# ─────────────────────────────────────────────────────────────────────────────
async def backfill_store_slugs(db) -> dict:
    result = {"updated": 0, "conflicts": []}
    slugs_seen = {}  # slug → [store_id]

    cursor = db.stores.find({"slug": {"$exists": False}})
    async for store in cursor:
        store_id = store.get("id")
        tenant_id = store.get("tenant_id", "")
        code = store.get("code", "")
        name = store.get("name", "")

        slug = slugify(code) if code else slugify(name)
        if not slug:
            slug = f"store-{store_id[:8]}"

        key = f"{tenant_id}:{slug}"
        if key in slugs_seen:
            # Conflito: adiciona sufixo numérico
            slug = f"{slug}-{len(slugs_seen.get(key, []))}"
            key = f"{tenant_id}:{slug}"
        slugs_seen.setdefault(key, []).append(store_id)

        if DRY_RUN:
            logger.info("[DRY_RUN] store %s slug=%s", store_id, slug)
        else:
            await db.stores.update_one(
                {"id": store_id},
                {"$set": {"slug": slug}},
            )
        result["updated"] += 1

    return result


# ─────────────────────────────────────────────────────────────────────────────
# 5. Registrar evento de migração no audit log
# ─────────────────────────────────────────────────────────────────────────────
async def register_migration_event(db, stats: dict):
    if DRY_RUN:
        logger.info("[DRY_RUN] Não registrando SYSTEM_MIGRATION_P0_5_COMPLETED")
        return
    import uuid as _uuid
    now = datetime.now(timezone.utc).isoformat()
    await db.audit_logs.insert_one({
        "id": str(_uuid.uuid4()),
        "tenant_id": "__system__",
        "store_id": None,
        "user_id": "__migration__",
        "action": "SYSTEM_MIGRATION_P0_5_COMPLETED",
        "entity": "system",
        "entity_id": None,
        "old_value": None,
        "new_value": {k: v for k, v in stats.items() if not isinstance(v, list)},
        "ip": "127.0.0.1",
        "user_agent": "migration-script/p0.5",
        "created_at": now,
    })
    logger.info("Evento SYSTEM_MIGRATION_P0_5_COMPLETED registrado.")


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────
async def main():
    mode = "[DRY_RUN]" if DRY_RUN else "[LIVE]"
    logger.info("%s Iniciando backfill P0.5...", mode)

    client = AsyncIOMotorClient(MONGO_URL)
    db = client[DB_NAME]

    try:
        logger.info("1/4 Backfill users (normalized_email, token_version)...")
        users_stats = await backfill_users(db)
        logger.info("    updated_normalized_email: %d | updated_token_version: %d | conflicts: %d",
                    users_stats["updated_normalized_email"],
                    users_stats["updated_token_version"],
                    len(users_stats["conflicts"]))
        if users_stats["conflicts"]:
            logger.warning("    CONFLITOS DE E-MAIL DETECTADOS: %s", users_stats["conflicts"])

        logger.info("2/4 Backfill sales.source...")
        sales_stats = await backfill_sales_source(db)
        logger.info("    updated: %d | already_set: %d | undetermined: %d",
                    sales_stats["updated"], sales_stats["skipped_already_set"], sales_stats["undetermined"])

        logger.info("3/4 Backfill attendances.source (from origin)...")
        att_stats = await backfill_attendances_source(db)
        logger.info("    updated: %d | already_set: %d",
                    att_stats["updated"], att_stats["skipped_already_set"])

        logger.info("4/4 Backfill stores.slug...")
        store_stats = await backfill_store_slugs(db)
        logger.info("    updated: %d | conflicts: %d",
                    store_stats["updated"], len(store_stats["conflicts"]))

        all_stats = {
            "users_normalized_email": users_stats["updated_normalized_email"],
            "users_token_version":    users_stats["updated_token_version"],
            "sales_source":           sales_stats["updated"],
            "attendances_source":     att_stats["updated"],
            "stores_slug":            store_stats["updated"],
        }

        await register_migration_event(db, all_stats)

        logger.info("%s Backfill P0.5 concluído: %s", mode, all_stats)

        if users_stats["conflicts"]:
            logger.warning("ATENÇÃO: Conflitos de e-mail detectados. Verifique /docs/migration-conflicts.md")

        return all_stats

    finally:
        client.close()


if __name__ == "__main__":
    asyncio.run(main())
