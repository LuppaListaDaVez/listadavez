#!/usr/bin/env python3
"""
Ensure Indexes P0.5 — Verificação e criação segura de índices
=============================================================
Verifica se há duplicatas ANTES de criar unique indexes.
Cria índices faltantes de forma idempotente sem travar o banco.

USO:
  cd /app/backend
  python ../scripts/ensure_indexes.py [--report-only]
"""
import asyncio
import os
import sys
import logging

from dotenv import load_dotenv
load_dotenv(os.path.join(os.path.dirname(__file__), "../backend/.env"))

from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import ASCENDING, DESCENDING

MONGO_URL = os.environ["MONGO_URL"]
DB_NAME   = os.environ["DB_NAME"]

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("ensure-indexes")

REPORT_ONLY = "--report-only" in sys.argv

# Índices não-unique que podem ser criados com segurança (sem duplicidade check)
SAFE_INDEXES = [
    # users
    ("users", [("email", ASCENDING)], {"unique": False}),
    # tenant_memberships
    ("tenant_memberships", [("tenant_id", ASCENDING), ("user_id", ASCENDING)], {}),
    ("tenant_memberships", [("tenant_id", ASCENDING), ("role", ASCENDING)], {}),
    ("tenant_memberships", [("tenant_id", ASCENDING), ("status", ASCENDING)], {}),
    ("tenant_memberships", [("user_id", ASCENDING)], {}),
    # stores
    ("stores", [("tenant_id", ASCENDING)], {}),
    ("stores", [("tenant_id", ASCENDING), ("code", ASCENDING)], {}),
    ("stores", [("tenant_id", ASCENDING), ("status", ASCENDING)], {}),
    ("stores", [("tenant_id", ASCENDING), ("slug", ASCENDING)], {"sparse": True}),
    # queues
    ("queues", [("tenant_id", ASCENDING), ("store_id", ASCENDING)], {}),
    # queue_entries
    ("queue_entries", [("tenant_id", ASCENDING), ("queue_id", ASCENDING), ("status", ASCENDING)], {}),
    ("queue_entries", [("tenant_id", ASCENDING), ("seller_id", ASCENDING), ("status", ASCENDING)], {}),
    # attendances
    ("attendances", [("tenant_id", ASCENDING), ("store_id", ASCENDING), ("created_at", DESCENDING)], {}),
    ("attendances", [("tenant_id", ASCENDING), ("seller_id", ASCENDING), ("created_at", DESCENDING)], {}),
    ("attendances", [("tenant_id", ASCENDING), ("status", ASCENDING)], {}),
    ("attendances", [("tenant_id", ASCENDING), ("source", ASCENDING)], {"sparse": True}),
    ("attendances", [("tenant_id", ASCENDING), ("origin", ASCENDING)], {"sparse": True}),
    # sales
    ("sales", [("tenant_id", ASCENDING), ("store_id", ASCENDING), ("created_at", DESCENDING)], {}),
    ("sales", [("tenant_id", ASCENDING), ("seller_id", ASCENDING), ("created_at", DESCENDING)], {}),
    ("sales", [("tenant_id", ASCENDING), ("attendance_id", ASCENDING)], {}),
    ("sales", [("tenant_id", ASCENDING), ("source", ASCENDING)], {"sparse": True}),
    ("sales", [("tenant_id", ASCENDING), ("status", ASCENDING)], {}),
    # sale_items
    ("sale_items", [("tenant_id", ASCENDING), ("sale_id", ASCENDING)], {}),
    # seller_profiles
    ("seller_profiles", [("tenant_id", ASCENDING), ("store_id", ASCENDING)], {}),
    ("seller_profiles", [("tenant_id", ASCENDING), ("user_id", ASCENDING)], {}),
    # notifications
    ("notifications", [("tenant_id", ASCENDING), ("user_id", ASCENDING)], {}),
    ("notifications", [("tenant_id", ASCENDING), ("user_id", ASCENDING), ("is_read", ASCENDING)], {}),
    ("notifications", [("tenant_id", ASCENDING), ("user_id", ASCENDING), ("created_at", DESCENDING)], {}),
    ("notifications", [("tenant_id", ASCENDING), ("type", ASCENDING)], {"sparse": True}),
    ("notifications", [("tenant_id", ASCENDING), ("event_type", ASCENDING)], {"sparse": True}),  # legado
    # goals
    ("goals", [("tenant_id", ASCENDING), ("store_id", ASCENDING)], {}),
    ("goals", [("tenant_id", ASCENDING), ("seller_id", ASCENDING)], {}),
    ("goals", [("tenant_id", ASCENDING), ("period", ASCENDING)], {}),
    ("goals", [("tenant_id", ASCENDING), ("status", ASCENDING)], {}),
    # rankings
    ("rankings", [("tenant_id", ASCENDING), ("store_id", ASCENDING)], {}),
    ("rankings", [("tenant_id", ASCENDING), ("period", ASCENDING)], {}),
    # feedbacks
    ("feedbacks", [("tenant_id", ASCENDING), ("seller_id", ASCENDING)], {}),
    ("feedbacks", [("tenant_id", ASCENDING), ("store_id", ASCENDING)], {}),
    ("feedbacks", [("tenant_id", ASCENDING), ("created_at", DESCENDING)], {}),
    # audit_logs
    ("audit_logs", [("tenant_id", ASCENDING), ("entity", ASCENDING), ("created_at", DESCENDING)], {}),
    ("audit_logs", [("tenant_id", ASCENDING), ("action", ASCENDING), ("created_at", DESCENDING)], {}),
    ("audit_logs", [("tenant_id", ASCENDING), ("user_id", ASCENDING), ("created_at", DESCENDING)], {}),
    # security_events
    ("security_events", [("tenant_id", ASCENDING), ("event_type", ASCENDING)], {}),
    ("security_events", [("tenant_id", ASCENDING), ("created_at", DESCENDING)], {}),
    # idempotency_keys
    ("idempotency_keys", [("scoped_key", ASCENDING)], {"unique": True}),
    ("idempotency_keys", [("expires_at", ASCENDING)], {"expireAfterSeconds": 0}),
    # auth_sessions
    ("auth_sessions", [("user_id", ASCENDING)], {}),
    ("auth_sessions", [("tenant_id", ASCENDING), ("user_id", ASCENDING)], {}),
    # refresh_tokens
    ("refresh_tokens", [("user_id", ASCENDING)], {}),
    ("refresh_tokens", [("expires_at", ASCENDING)], {"expireAfterSeconds": 0}),
]

# Índices que exigem verificação de duplicatas antes de criar como unique
CONDITIONAL_UNIQUE_INDEXES = [
    {
        "collection": "users",
        "key": [("normalized_email", ASCENDING)],
        "name": "normalized_email_unique",
        "description": "unique normalized_email em users",
        "check_field": "normalized_email",
    },
]


async def check_duplicates(db, coll_name: str, field: str) -> list:
    """Retorna lista de valores duplicados para o campo informado."""
    pipeline = [
        {"$match": {field: {"$exists": True, "$ne": None}}},
        {"$group": {"_id": f"${field}", "count": {"$sum": 1}, "ids": {"$push": "$id"}}},
        {"$match": {"count": {"$gt": 1}}},
        {"$limit": 50},
    ]
    return await db[coll_name].aggregate(pipeline).to_list(50)


async def ensure_indexes(db):
    report = {
        "created": [],
        "already_exist": [],
        "skipped_duplicates": [],
        "errors": [],
    }

    for (coll_name, keys, kwargs) in SAFE_INDEXES:
        try:
            existing = await db[coll_name].index_information()
            key_str = "_".join(f"{k}_{v}" for k, v in keys)
            already = any(key_str in name for name in existing.keys())
            if already:
                report["already_exist"].append(f"{coll_name}.{key_str}")
                continue

            if REPORT_ONLY:
                logger.info("[REPORT_ONLY] Criaria: %s %s", coll_name, key_str)
                report["created"].append(f"[PENDING] {coll_name}.{key_str}")
                continue

            await db[coll_name].create_index(keys, **kwargs)
            report["created"].append(f"{coll_name}.{key_str}")
            logger.info("Índice criado: %s %s", coll_name, key_str)
        except Exception as e:
            report["errors"].append(f"{coll_name}: {e}")
            logger.error("Erro criando índice %s: %s", coll_name, e)

    # Índices unique condicionais
    for idx in CONDITIONAL_UNIQUE_INDEXES:
        coll_name = idx["collection"]
        field = idx["check_field"]

        dups = await check_duplicates(db, coll_name, field)
        if dups:
            logger.warning(
                "SKIP unique index %s.%s — %d duplicatas encontradas: %s",
                coll_name, field, len(dups), [d["_id"] for d in dups]
            )
            report["skipped_duplicates"].append({
                "collection": coll_name,
                "field": field,
                "reason": f"{len(dups)} duplicatas encontradas",
                "examples": [d["_id"] for d in dups[:5]],
            })
        else:
            if not REPORT_ONLY:
                try:
                    await db[coll_name].create_index(idx["key"], unique=True, sparse=True)
                    report["created"].append(f"[UNIQUE] {coll_name}.{field}")
                    logger.info("Índice unique criado: %s.%s", coll_name, field)
                except Exception as e:
                    report["errors"].append(f"{coll_name} unique {field}: {e}")
                    logger.error("Erro criando unique index: %s", e)
            else:
                report["created"].append(f"[PENDING UNIQUE] {coll_name}.{field}")

    return report


async def main():
    mode = "[REPORT_ONLY]" if REPORT_ONLY else "[LIVE]"
    logger.info("%s Verificando índices...", mode)

    client = AsyncIOMotorClient(MONGO_URL)
    db = client[DB_NAME]

    try:
        report = await ensure_indexes(db)
        logger.info("Criados: %d | Já existiam: %d | Pulados (dup): %d | Erros: %d",
                    len(report["created"]),
                    len(report["already_exist"]),
                    len(report["skipped_duplicates"]),
                    len(report["errors"]))
        if report["errors"]:
            logger.error("Erros: %s", report["errors"])
        if report["skipped_duplicates"]:
            logger.warning("Índices unique pulados por duplicatas: %s", report["skipped_duplicates"])
        return report
    finally:
        client.close()


if __name__ == "__main__":
    asyncio.run(main())
