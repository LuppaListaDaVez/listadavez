#!/usr/bin/env python3
"""
Migration Runner P0.5
=====================
Orchestrador principal: executa backfills + index verification no startup.
Idempotente e seguro para rodar em produção.

Pode ser chamado de:
  1. server.py startup (automático)
  2. python scripts/run_migrations.py (manual)
"""
import asyncio
import logging
import os
import sys

from dotenv import load_dotenv

_root = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(_root, "../backend/.env"))

from motor.motor_asyncio import AsyncIOMotorClient

# Adiciona /app/scripts ao path para importar os módulos
sys.path.insert(0, _root)

MONGO_URL = os.environ["MONGO_URL"]
DB_NAME   = os.environ["DB_NAME"]

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("migration-runner")


async def run_all(db):
    """Executa todas as migrações P0.5 em ordem segura."""
    logger.info("=== Iniciando migrações P0.5 ===")
    results = {}

    # 1. Backfill campos ausentes
    try:
        from backfill_p0_5 import (
            backfill_users,
            backfill_sales_source,
            backfill_attendances_source,
            backfill_store_slugs,
            register_migration_event,
        )
        u = await backfill_users(db)
        s = await backfill_sales_source(db)
        a = await backfill_attendances_source(db)
        st = await backfill_store_slugs(db)
        results["backfill"] = {"users": u, "sales": s, "attendances": a, "stores": st}
        stats = {
            "users_normalized_email": u["updated_normalized_email"],
            "users_token_version":    u["updated_token_version"],
            "sales_source":           s["updated"],
            "attendances_source":     a["updated"],
            "stores_slug":            st["updated"],
        }
        if any(v > 0 for v in stats.values()):
            await register_migration_event(db, stats)
            logger.info("Backfill P0.5: %s", stats)
    except Exception as e:
        logger.error("Erro no backfill P0.5: %s", e, exc_info=True)
        results["backfill_error"] = str(e)

    logger.info("=== Migrações P0.5 concluídas ===")
    return results


async def main():
    client = AsyncIOMotorClient(MONGO_URL)
    db = client[DB_NAME]
    try:
        r = await run_all(db)
        logger.info("Resultado final: %s", r)
    finally:
        client.close()


if __name__ == "__main__":
    asyncio.run(main())
