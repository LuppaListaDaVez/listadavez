"""Script de Teste de Carga — Lista da Vez SaaS
P1-Validação: Simulação de 100 empresas com múltiplas lojas e vendedores.

Uso:
    pip install locust
    locust -f scripts/load_test_locust.py --host=https://SEU_BACKEND_URL \
           --users=100 --spawn-rate=10 --run-time=5m --headless

Relatório:
    locust --headless ... --html=load_test_report.html --csv=load_test_metrics

Cenários simulados:
    - LoginUser (20%): logins de admin e vendedor
    - DashboardUser (30%): acesso ao dashboard por admins
    - QueueUser (30%): operações de fila (join, leave, start, finish)
    - ReportUser (15%): geração de relatórios e exports async
    - NotificationUser (5%): leitura de notificações
"""
import json
import random
import string
import time
from locust import HttpUser, task, between, events

# ── Tenant demo para testes de carga ─────────────────────────────────────────
# Em produção real, criar tenants específicos para carga: tenant_load_001...100
TENANT_SLUG = "demo"
ADMIN_EMAIL = "admin@demo.com"
ADMIN_PASSWORD = "Admin@123456"

# Targets de performance (SLA P1)
SLA_DASHBOARD_MS = 500    # P95 do dashboard < 500ms
SLA_QUEUE_MS = 300        # P95 de operações de fila < 300ms
SLA_EXPORT_CREATE_MS = 200  # Criar export job < 200ms


class BaseListaDaVezUser(HttpUser):
    """Base class com login e token management."""
    abstract = True
    wait_time = between(1, 3)
    token = None
    store_id = None
    seller_id = None

    def on_start(self):
        """Login e obter store/seller para as operações."""
        self._login()

    def _login(self):
        with self.client.post(
            f"/api/tenants/{TENANT_SLUG}/auth/login",
            json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD},
            catch_response=True,
            name="[AUTH] Login",
        ) as r:
            if r.status_code == 200:
                self.token = r.json().get("access_token")
                r.success()
            else:
                r.failure(f"Login falhou: {r.status_code}")
                return

        # Obter primeira loja
        with self.client.get(
            f"/api/tenants/{TENANT_SLUG}/stores",
            headers=self._headers(),
            catch_response=True,
            name="[SETUP] Get stores",
        ) as r:
            if r.status_code == 200 and r.json():
                self.store_id = r.json()[0]["id"]
                r.success()

    def _headers(self):
        return {"Authorization": f"Bearer {self.token}"} if self.token else {}

    def _get_queue_state(self):
        if not self.store_id:
            return None
        r = self.client.get(
            f"/api/tenants/{TENANT_SLUG}/stores/{self.store_id}/queue",
            headers=self._headers(),
            name="[QUEUE] Get state",
        )
        return r.json() if r.status_code == 200 else None


class DashboardUser(BaseListaDaVezUser):
    """Simula admin acessando o dashboard — 30% do tráfego."""
    weight = 30

    @task(5)
    def view_dashboard(self):
        """Acesso ao dashboard com summary."""
        with self.client.get(
            f"/api/tenants/{TENANT_SLUG}/dashboard/summary",
            headers=self._headers(),
            catch_response=True,
            name="[DASHBOARD] Summary",
        ) as r:
            if r.status_code == 200:
                elapsed = r.elapsed.total_seconds() * 1000
                if elapsed > SLA_DASHBOARD_MS * 2:
                    r.failure(f"Dashboard lento: {elapsed:.0f}ms")
                else:
                    r.success()
            else:
                r.failure(f"Dashboard erro: {r.status_code}")

    @task(3)
    def view_health(self):
        """Health check — simula load balancer probe."""
        with self.client.get(
            "/api/health/ready",
            catch_response=True,
            name="[HEALTH] Ready probe",
        ) as r:
            if r.status_code == 200:
                r.success()
            else:
                r.failure(f"Health degraded: {r.status_code}")

    @task(2)
    def view_attendances(self):
        """Lista de atendimentos com paginação."""
        self.client.get(
            f"/api/tenants/{TENANT_SLUG}/attendances?page=1&page_size=20",
            headers=self._headers(),
            name="[ATTENDANCES] List",
        )

    @task(1)
    def view_sellers(self):
        """Lista de vendedores."""
        self.client.get(
            f"/api/tenants/{TENANT_SLUG}/sellers",
            headers=self._headers(),
            name="[SELLERS] List",
        )


class QueueUser(BaseListaDaVezUser):
    """Simula operações de fila — 30% do tráfego."""
    weight = 30

    @task(4)
    def poll_queue_state(self):
        """Polling da fila (substituto de WebSocket em clientes sem WS)."""
        self._get_queue_state()

    @task(2)
    def queue_join_leave_cycle(self):
        """Ciclo completo: join → leave de um vendedor disponível."""
        if not self.store_id:
            return
        state = self._get_queue_state()
        if not state:
            return
        available = state.get("available_sellers", [])
        if not available:
            return
        seller_id = available[0]["seller_id"]

        # Join
        with self.client.post(
            f"/api/tenants/{TENANT_SLUG}/stores/{self.store_id}/queue/join",
            json={"seller_id": seller_id},
            headers=self._headers(),
            catch_response=True,
            name="[QUEUE] Join",
        ) as r:
            if r.status_code not in (200, 201, 409):
                r.failure(f"Join inesperado: {r.status_code}")
            else:
                r.success()

        time.sleep(0.5)

        # Leave
        self.client.post(
            f"/api/tenants/{TENANT_SLUG}/stores/{self.store_id}/queue/leave",
            json={"seller_id": seller_id},
            headers=self._headers(),
            name="[QUEUE] Leave",
        )

    @task(1)
    def full_attendance_cycle(self):
        """Ciclo completo: join → start → finish (INVALID para não poluir relatórios)."""
        if not self.store_id:
            return
        state = self._get_queue_state()
        if not state:
            return
        available = state.get("available_sellers", [])
        if not available:
            return
        seller_id = available[0]["seller_id"]

        # Join
        r = self.client.post(
            f"/api/tenants/{TENANT_SLUG}/stores/{self.store_id}/queue/join",
            json={"seller_id": seller_id},
            headers=self._headers(),
            name="[QUEUE] Join (full cycle)",
        )
        if r.status_code not in (200, 201):
            return

        # Start attendance
        r = self.client.post(
            f"/api/tenants/{TENANT_SLUG}/stores/{self.store_id}/queue/start-attendance",
            json={"seller_id": seller_id},
            headers=self._headers(),
            name="[QUEUE] Start attendance",
        )
        if r.status_code != 200:
            return
        att_id = r.json().get("attendance", {}).get("id")
        if not att_id:
            return

        # Simula duração do atendimento
        time.sleep(random.uniform(0.5, 2.0))

        # Finish (INVALID para não poluir dados)
        idem_key = f"load-test-{att_id}-{int(time.time())}"
        self.client.post(
            f"/api/tenants/{TENANT_SLUG}/stores/{self.store_id}/queue/finish-attendance",
            json={
                "attendance_id": att_id,
                "result": "INVALID",
                "notes": "Load test - ignorar",
            },
            headers={**self._headers(), "Idempotency-Key": idem_key},
            name="[QUEUE] Finish attendance",
        )


class ReportUser(BaseListaDaVezUser):
    """Simula usuários gerando relatórios — 15% do tráfego."""
    weight = 15

    @task(3)
    def create_async_export(self):
        """Cria job de export assíncrono (não deve bloquear API)."""
        report_types = ["attendances", "conversion", "loss-reasons", "seller-performance"]
        rtype = random.choice(report_types)

        with self.client.post(
            f"/api/tenants/{TENANT_SLUG}/reports/export/async",
            json={"report_type": rtype},
            headers=self._headers(),
            catch_response=True,
            name="[EXPORT] Create async job",
        ) as r:
            if r.status_code == 200:
                elapsed = r.elapsed.total_seconds() * 1000
                if elapsed > SLA_EXPORT_CREATE_MS * 3:
                    r.failure(f"Export create lento: {elapsed:.0f}ms (esperado < {SLA_EXPORT_CREATE_MS*3}ms)")
                else:
                    r.success()
            elif r.status_code == 403:
                r.success()  # Feature desabilitada é comportamento esperado
            else:
                r.failure(f"Export create erro: {r.status_code}")

    @task(2)
    def list_export_jobs(self):
        """Lista jobs de export do usuário."""
        self.client.get(
            f"/api/tenants/{TENANT_SLUG}/reports/export/jobs",
            headers=self._headers(),
            name="[EXPORT] List jobs",
        )

    @task(1)
    def view_reports_page(self):
        """Acessa metadados de relatórios disponíveis."""
        self.client.get(
            f"/api/tenants/{TENANT_SLUG}/stores",
            headers=self._headers(),
            name="[REPORTS] Get stores",
        )


class NotificationUser(BaseListaDaVezUser):
    """Simula leitura de notificações — 5% do tráfego."""
    weight = 5

    @task(3)
    def get_notifications(self):
        """Lista notificações não lidas."""
        self.client.get(
            f"/api/tenants/{TENANT_SLUG}/notifications?unread=true&page_size=20",
            headers=self._headers(),
            name="[NOTIF] Unread list",
        )

    @task(1)
    def get_rankings(self):
        """Rankings — consulta pesada com múltiplos aggregation stages."""
        self.client.get(
            f"/api/tenants/{TENANT_SLUG}/rankings",
            headers=self._headers(),
            name="[RANKINGS] Get",
        )


class LoginUser(BaseListaDaVezUser):
    """Simula novos logins — 20% do tráfego."""
    weight = 20
    token = None  # Inicia sem token (precisa fazer login)

    def on_start(self):
        pass  # Não fazer login automático, simula o fluxo

    @task(1)
    def login_flow(self):
        """Simula fluxo de login completo."""
        with self.client.post(
            f"/api/tenants/{TENANT_SLUG}/auth/login",
            json={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD},
            catch_response=True,
            name="[AUTH] Login flow",
        ) as r:
            if r.status_code == 200:
                self.token = r.json().get("access_token")
                r.success()
            elif r.status_code == 429:
                r.failure("Rate limit atingido no login")
            else:
                r.failure(f"Login falhou: {r.status_code}")


# ── Event handlers para relatório ─────────────────────────────────────────────

@events.quitting.add_listener
def on_locust_quit(environment, **kw):
    """Sumário de resultados ao finalizar."""
    stats = environment.stats
    print("\n" + "="*60)
    print("RELATÓRIO DE CARGA — Lista da Vez P1-Validação")
    print("="*60)
    print(f"Total de requests: {stats.total.num_requests}")
    print(f"Falhas: {stats.total.num_failures}")
    print(f"Taxa de erro: {stats.total.fail_ratio*100:.1f}%")
    print(f"RPS médio: {stats.total.current_rps:.1f}")
    print(f"P50 latência: {stats.total.get_response_time_percentile(0.5):.0f}ms")
    print(f"P95 latência: {stats.total.get_response_time_percentile(0.95):.0f}ms")
    print(f"P99 latência: {stats.total.get_response_time_percentile(0.99):.0f}ms")
    print("="*60)

    # SLA check
    p95 = stats.total.get_response_time_percentile(0.95)
    fail_ratio = stats.total.fail_ratio
    if p95 > 2000:
        print(f"⚠️  SLA VIOLADO: P95={p95:.0f}ms > 2000ms")
    if fail_ratio > 0.05:
        print(f"⚠️  SLA VIOLADO: taxa de erro {fail_ratio*100:.1f}% > 5%")
    if p95 <= 2000 and fail_ratio <= 0.05:
        print("✅ SLA OK para 100 empresas")
    print("="*60)
