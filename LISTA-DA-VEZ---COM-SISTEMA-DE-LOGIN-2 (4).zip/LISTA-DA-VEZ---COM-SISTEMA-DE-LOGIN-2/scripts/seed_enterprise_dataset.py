"""Dataset Enterprise — P2.5
Seed idempotente de 20 tenants simulados para comprovar escala enterprise.

Uso:
    cd /app && python scripts/seed_enterprise_dataset.py [--drop-enterprise]

Flags:
    --drop-enterprise  Remove apenas os tenants enterprise_XXX antes de re-seedar
                       (NÃO remove demo/demo-b)

Gera:
    /app/fixtures/enterprise_creds.json  — credenciais de todos os tenants criados
"""
import argparse
import asyncio
import json
import os
import random
import sys
import uuid
from datetime import datetime, timezone, timedelta

from motor.motor_asyncio import AsyncIOMotorClient

# ── Configuração ──────────────────────────────────────────────────────────────
MONGO_URL = os.environ.get("MONGO_URL", "mongodb://localhost:27017").strip("\"'")
DB_NAME = os.environ.get("DB_NAME", "test_database").strip("\"'")

NUM_TENANTS = 20
STORES_PER_TENANT = 3
SELLERS_PER_STORE = 6
ATTENDANCES_PER_STORE = 80   # histórico por loja
SALES_PER_STORE = 25          # vendas por loja
GOALS_PER_TENANT = 3

FIXTURE_DIR = "/app/fixtures"
FIXTURE_FILE = f"{FIXTURE_DIR}/enterprise_creds.json"

CITIES = [
    ("São Paulo", "SP"), ("Rio de Janeiro", "RJ"), ("Belo Horizonte", "MG"),
    ("Curitiba", "PR"), ("Porto Alegre", "RS"), ("Salvador", "BA"),
    ("Fortaleza", "CE"), ("Recife", "PE"), ("Manaus", "AM"), ("Brasília", "DF"),
    ("Goiânia", "GO"), ("Florianópolis", "SC"), ("Natal", "RN"), ("Maceió", "AL"),
    ("Belém", "PA"), ("Teresina", "PI"), ("Campo Grande", "MS"), ("Campinas", "SP"),
    ("São Luís", "MA"), ("João Pessoa", "PB"),
]

RETAIL_NAMES = [
    "Alpha Varejo", "Beta Comércio", "Gamma Lojas", "Delta Store", "Epsilon Shops",
    "Zeta Retail", "Eta Fashion", "Theta Commerce", "Iota Vendas", "Kappa Lojas",
    "Lambda Store", "Mu Vendas", "Nu Retail", "Xi Fashion", "Omicron Stores",
    "Pi Commerce", "Rho Lojas", "Sigma Retail", "Tau Vendas", "Upsilon Store",
]

FIRST_NAMES = [
    "Ana", "Bruno", "Carlos", "Daniela", "Eduardo", "Fernanda", "Gabriel",
    "Helena", "Igor", "Juliana", "Klaus", "Letícia", "Marcos", "Natália",
    "Otávio", "Patricia", "Renato", "Sabrina", "Thiago", "Vanessa",
    "Wagner", "Ximena", "Yuri", "Zara", "André", "Beatriz", "Cláudio",
    "Diana", "Elias", "Fabiana",
]

LAST_NAMES = [
    "Silva", "Santos", "Oliveira", "Souza", "Lima", "Pereira", "Costa",
    "Ferreira", "Rodrigues", "Almeida", "Nascimento", "Carvalho", "Araújo",
    "Gomes", "Martins", "Ribeiro", "Barbosa", "Cardoso", "Pinto", "Mendes",
]

LOSS_REASONS = [
    "Preço alto", "Produto indisponível", "Sem estoque", "Só pesquisando",
    "Comprou no concorrente", "Faltou tamanho", "Faltou cor",
    "Cliente sem crédito", "Atendimento demorado",
]

STORE_NAMES = ["Centro", "Norte Shopping", "Sul Plaza", "Leste Mall", "Oeste Store"]
STORE_CODES = ["CTR", "NSH", "SPL", "LST", "OES"]

PAYMENT_METHODS = ["CREDIT_CARD", "DEBIT_CARD", "PIX", "CASH", "BOLETO"]
SALE_SOURCES = ["QUEUE", "PROACTIVE", "MANUAL", "QUEUE", "QUEUE"]  # QUEUE mais frequente

DEFAULT_PASSWORD = "Enterprise@2026"
ENTERPRISE_PASSWORD_HASH = None  # Will be set at runtime


# ── Helpers ───────────────────────────────────────────────────────────────────

def new_id() -> str:
    return str(uuid.uuid4())


def utcnow_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def dt_ago(days=0, hours=0) -> str:
    return (datetime.now(timezone.utc) - timedelta(days=days, hours=hours)).isoformat()


def rand_name() -> str:
    return f"{random.choice(FIRST_NAMES)} {random.choice(LAST_NAMES)}"


def hash_pw(password: str) -> str:
    import bcrypt
    salt = bcrypt.gensalt()
    return bcrypt.hashpw(password.encode("utf-8"), salt).decode("utf-8")


# ── Seed Functions ────────────────────────────────────────────────────────────

async def get_enterprise_plan(db) -> dict:
    plan = await db.plans.find_one({"name": "Enterprise"})
    if not plan:
        raise RuntimeError("Plano Enterprise não encontrado. Rode o seed principal primeiro.")
    return plan


async def get_features(db) -> list:
    features = await db.features.find({}).to_list(100)
    return [f["key"] for f in features]


async def seed_tenant(db, idx: int, plan_id: str, feature_keys: list, pw_hash: str) -> dict:
    """Cria (ou retorna existente) um tenant enterprise com todas as sub-entidades."""
    num = str(idx).zfill(3)
    slug = f"enterprise_{num}"
    now = utcnow_iso()
    city, state = CITIES[(idx - 1) % len(CITIES)]
    tenant_name = RETAIL_NAMES[(idx - 1) % len(RETAIL_NAMES)]

    # ── Tenant ──
    existing_tenant = await db.tenants.find_one({"slug": slug})
    if existing_tenant:
        existing_tenant.pop("_id", None)
        tenant = existing_tenant
    else:
        tenant = {
            "id": new_id(), "name": tenant_name, "slug": slug,
            "cnpj": f"{random.randint(10,99)}.{random.randint(100,999)}.{random.randint(100,999)}/0001-{random.randint(10,99)}",
            "email": f"contato@{slug.replace('_', '-')}.com",
            "phone": f"(11) 9{random.randint(1000,9999)}-{random.randint(1000,9999)}",
            "status": "ACTIVE", "plan_id": plan_id,
            "logo_url": None, "primary_color": f"#{random.randint(100000,999999)}",
            "created_at": dt_ago(days=random.randint(30, 365)),
            "updated_at": now,
        }
        await db.tenants.insert_one(tenant)
    tenant_id = tenant["id"]

    # ── Tenant Settings ──
    if not await db.tenant_settings.find_one({"tenant_id": tenant_id}):
        await db.tenant_settings.insert_one({
            "id": new_id(), "tenant_id": tenant_id,
            "general_settings": {}, "created_at": now, "updated_at": now,
        })

    # ── Features ──
    for key in feature_keys:
        existing_feat = await db.tenant_features.find_one({"tenant_id": tenant_id, "feature_key": key})
        if not existing_feat:
            await db.tenant_features.insert_one({
                "id": new_id(), "tenant_id": tenant_id, "feature_key": key,
                "enabled": True, "updated_by": "enterprise_seed",
                "created_at": now, "updated_at": now,
            })

    # ── Admin User ──
    admin_email = f"admin@{slug.replace('_', '-')}.com"
    admin = await db.users.find_one({"email": admin_email})
    if not admin:
        admin = {
            "id": new_id(), "name": f"Administrador {tenant_name}",
            "email": admin_email, "phone": None,
            "password_hash": pw_hash,
            "normalized_email": admin_email.lower(),
            "avatar_url": None, "is_super_admin": False,
            "status": "ACTIVE", "token_version": 1,
            "last_login_at": None, "created_at": now, "updated_at": now,
        }
        await db.users.insert_one(admin)

    if not await db.tenant_memberships.find_one({"tenant_id": tenant_id, "user_id": admin["id"]}):
        await db.tenant_memberships.insert_one({
            "id": new_id(), "tenant_id": tenant_id, "user_id": admin["id"],
            "role": "TENANT_ADMIN", "store_ids": [], "status": "ACTIVE",
            "created_at": now, "updated_at": now,
        })

    # ── Stores + Sellers + Data ──
    stores_created = []
    all_sellers = []
    creds = {"admin": {"email": admin_email, "password": DEFAULT_PASSWORD}, "sellers": []}

    for s_idx in range(1, STORES_PER_TENANT + 1):
        store_name = f"{STORE_NAMES[(s_idx - 1) % len(STORE_NAMES)]} — {tenant_name}"
        store_code = f"{STORE_CODES[(s_idx - 1) % len(STORE_CODES)]}-{num}"

        existing_store = await db.stores.find_one({"tenant_id": tenant_id, "code": store_code})
        if existing_store:
            existing_store.pop("_id", None)
            store = existing_store
        else:
            store = {
                "id": new_id(), "tenant_id": tenant_id,
                "name": store_name, "code": store_code,
                "address": f"Rua das Flores, {random.randint(1, 999)}",
                "city": city, "state": state, "country": "Brasil",
                "timezone": "America/Sao_Paulo", "phone": None,
                "status": "ACTIVE",
                "created_at": dt_ago(days=random.randint(10, 300)),
                "updated_at": now,
            }
            await db.stores.insert_one(store)
        stores_created.append(store)
        store_id = store["id"]

        # Store settings
        if not await db.store_settings.find_one({"tenant_id": tenant_id, "store_id": store_id}):
            await db.store_settings.insert_one({
                "id": new_id(), "tenant_id": tenant_id, "store_id": store_id,
                "queue_settings": {"auto_return": True, "break_time_minutes": 15},
                "realtime_settings": {}, "notification_settings": {},
                "created_at": now, "updated_at": now,
            })

        # Loss reasons
        for lr_name in LOSS_REASONS:
            if not await db.loss_reasons.find_one({"tenant_id": tenant_id, "name": lr_name, "store_id": None}):
                await db.loss_reasons.insert_one({
                    "id": new_id(), "tenant_id": tenant_id, "store_id": None,
                    "name": lr_name, "description": None, "active": True,
                    "created_at": now, "updated_at": now,
                })

        # ── Sellers ──
        store_sellers = []
        for sel_idx in range(1, SELLERS_PER_STORE + 1):
            sel_name = rand_name()
            sel_email = f"vendedor{sel_idx}@{slug.replace('_', '-')}-{s_idx}.com"

            sel_user = await db.users.find_one({"email": sel_email})
            if not sel_user:
                sel_user = {
                    "id": new_id(), "name": sel_name,
                    "email": sel_email, "phone": None,
                    "password_hash": pw_hash,
                    "normalized_email": sel_email.lower(),
                    "avatar_url": None, "is_super_admin": False,
                    "status": "ACTIVE", "token_version": 1,
                    "last_login_at": None, "created_at": now, "updated_at": now,
                }
                await db.users.insert_one(sel_user)

            if not await db.tenant_memberships.find_one({"tenant_id": tenant_id, "user_id": sel_user["id"]}):
                await db.tenant_memberships.insert_one({
                    "id": new_id(), "tenant_id": tenant_id, "user_id": sel_user["id"],
                    "role": "SELLER", "store_ids": [store_id], "status": "ACTIVE",
                    "created_at": now, "updated_at": now,
                })

            existing_profile = await db.seller_profiles.find_one({"tenant_id": tenant_id, "user_id": sel_user["id"]})
            if existing_profile:
                existing_profile.pop("_id", None)
                seller = existing_profile
            else:
                statuses = ["AVAILABLE", "AVAILABLE", "AVAILABLE", "OFFLINE", "BREAK"]
                seller = {
                    "id": new_id(), "tenant_id": tenant_id,
                    "user_id": sel_user["id"], "store_id": store_id,
                    "team_id": None,
                    "employee_code": f"V{num}{s_idx}{sel_idx:02d}",
                    "hire_date": dt_ago(days=random.randint(30, 730))[:10],
                    "status": "ACTIVE",
                    "current_status": random.choice(statuses),
                    "avatar_url": None,
                    "created_at": now, "updated_at": now,
                }
                await db.seller_profiles.insert_one(seller)

            store_sellers.append(seller)
            all_sellers.append(seller)
            creds["sellers"].append({"email": sel_email, "password": DEFAULT_PASSWORD, "store": store_code})

        # ── Queue ──
        existing_queue = await db.queues.find_one({"tenant_id": tenant_id, "store_id": store_id, "is_default": True})
        if existing_queue:
            existing_queue.pop("_id", None)
            queue = existing_queue
        else:
            queue = {
                "id": new_id(), "tenant_id": tenant_id, "store_id": store_id,
                "name": "Fila Principal", "type": "GENERAL", "is_default": True,
                "status": "ACTIVE", "settings": {},
                "created_at": now, "updated_at": now,
            }
            await db.queues.insert_one(queue)
        queue_id = queue["id"]

        # ── Attendances históricas ──
        existing_atts = await db.attendances.count_documents({"tenant_id": tenant_id, "store_id": store_id})
        if existing_atts < ATTENDANCES_PER_STORE:
            atts_to_create = ATTENDANCES_PER_STORE - existing_atts
            results = ["SALE", "SALE", "NO_SALE", "FOLLOW_UP", "INVALID"]
            for a_idx in range(atts_to_create):
                seller = random.choice(store_sellers)
                days_ago = random.randint(0, 90)
                hours_ago = random.randint(0, 23)
                started = dt_ago(days=days_ago, hours=hours_ago)
                finished = (datetime.fromisoformat(started) + timedelta(minutes=random.randint(5, 60))).isoformat()
                result = random.choice(results)

                att = {
                    "id": new_id(), "tenant_id": tenant_id, "store_id": store_id,
                    "seller_id": seller["id"], "queue_id": queue_id,
                    "queue_entry_id": None,
                    "status": "FINISHED", "result": result,
                    "source": random.choice(["WALK_IN", "WALK_IN", "MANUAL", "RETURNING_CUSTOMER"]),
                    "customer_name": rand_name() if random.random() > 0.3 else None,
                    "customer_phone": None, "notes": None,
                    "sale_id": None, "loss_reason_id": None,
                    "started_at": started, "finished_at": finished,
                    "duration_minutes": random.randint(5, 60),
                    "created_at": started, "updated_at": finished,
                }
                await db.attendances.insert_one(att)

        # ── Sales históricas ──
        existing_sales = await db.sales.count_documents({"tenant_id": tenant_id, "store_id": store_id})
        if existing_sales < SALES_PER_STORE:
            sales_to_create = SALES_PER_STORE - existing_sales
            for _ in range(sales_to_create):
                seller = random.choice(store_sellers)
                days_ago = random.randint(0, 90)
                amount = random.randint(5000, 200000)  # R$ 50 to R$ 2000
                sale_date = dt_ago(days=days_ago)
                method = random.choice(PAYMENT_METHODS)

                await db.sales.insert_one({
                    "id": new_id(), "tenant_id": tenant_id, "store_id": store_id,
                    "seller_id": seller["id"], "attendance_id": None,
                    "proactive_approach_id": None,
                    "source": random.choice(SALE_SOURCES),
                    "status": "COMPLETED",
                    "gross_amount_cents": amount,
                    "discount_amount_cents": random.randint(0, int(amount * 0.1)),
                    "net_amount_cents": amount,
                    "payment_methods": [{"method": method, "amount_cents": amount}],
                    "notes": None,
                    "created_at": sale_date, "updated_at": sale_date,
                })

    # ── Goals por tenant ──
    existing_goals = await db.goals.count_documents({"tenant_id": tenant_id})
    if existing_goals < GOALS_PER_TENANT and stores_created:
        first_store = stores_created[0]
        from datetime import date
        today = date.today()
        month_start = date(today.year, today.month, 1).isoformat()
        month_end = date(today.year, today.month, 28).isoformat()

        goals_to_seed = [
            {"title": f"Meta Mensal {tenant_name}", "type": "REVENUE", "scope": "STORE",
             "store_id": first_store["id"], "seller_id": None, "target_value": random.randint(500000, 5000000)},
            {"title": f"Conversão {tenant_name}", "type": "CONVERSION", "scope": "STORE",
             "store_id": first_store["id"], "seller_id": None, "target_value": random.randint(4000, 8000)},
            {"title": f"Atendimentos {tenant_name}", "type": "ATTENDANCE_COUNT", "scope": "STORE",
             "store_id": first_store["id"], "seller_id": None, "target_value": random.randint(100, 500)},
        ]

        for g in goals_to_seed:
            if not await db.goals.find_one({"tenant_id": tenant_id, "title": g["title"]}):
                await db.goals.insert_one({
                    "id": new_id(), "tenant_id": tenant_id,
                    "store_id": g["store_id"], "team_id": None, "seller_id": g["seller_id"],
                    "created_by": admin["id"], "title": g["title"], "description": None,
                    "type": g["type"], "scope": g["scope"], "period": "MONTHLY",
                    "target_value": g["target_value"], "current_value": 0,
                    "progress_percent": 0, "status": "ACTIVE",
                    "period_start": month_start, "period_end": month_end,
                    "created_at": now, "updated_at": now,
                    "completed_at": None, "cancelled_at": None,
                })

    tenant.pop("_id", None)
    return {"tenant": tenant, "creds": creds, "stores": [s["id"] for s in stores_created]}


async def drop_enterprise_tenants(db):
    """Remove apenas tenants enterprise_XXX (idempotente para re-seed)."""
    tenants = await db.tenants.find({"slug": {"$regex": "^enterprise_"}}).to_list(100)
    if not tenants:
        print("Nenhum tenant enterprise encontrado para remover.")
        return

    tenant_ids = [t["id"] for t in tenants]
    collections = [
        "stores", "tenant_memberships", "tenant_features", "tenant_settings",
        "seller_profiles", "queues", "queue_entries", "attendances", "sales",
        "goals", "notifications", "feedbacks", "loss_reasons", "store_settings",
        "alert_events", "automation_rules",
    ]
    for col in collections:
        result = await db[col].delete_many({"tenant_id": {"$in": tenant_ids}})
        if result.deleted_count:
            print(f"  Removidos {result.deleted_count} docs de '{col}'")

    # Remove usuários enterprise (emails que terminam com enterprise-XXX domínios)
    for t in tenants:
        slug_domain = t["slug"].replace("_", "-")
        await db.users.delete_many({"email": {"$regex": f"@{slug_domain}"}})

    await db.tenants.delete_many({"slug": {"$regex": "^enterprise_"}})
    print(f"Removidos {len(tenants)} tenants enterprise.")


async def main(drop_first: bool = False):
    print("=" * 60)
    print("Lista da Vez — Seed Enterprise Dataset (P2.5)")
    print(f"  MongoDB: {MONGO_URL}")
    print(f"  Database: {DB_NAME}")
    print(f"  Tenants: {NUM_TENANTS} x {STORES_PER_TENANT} lojas x {SELLERS_PER_STORE} vendedores")
    print("=" * 60)

    client = AsyncIOMotorClient(MONGO_URL)
    db = client[DB_NAME]

    if drop_first:
        print("\n[DROP] Removendo tenants enterprise existentes...")
        await drop_enterprise_tenants(db)

    # Verificar dados essenciais
    plan = await get_enterprise_plan(db)
    feature_keys = await get_features(db)
    print(f"\n[INFO] Plano Enterprise: {plan['id']}")
    print(f"[INFO] Features disponíveis: {len(feature_keys)}")

    # Hash único para todos os usuários enterprise
    print("\n[HASH] Gerando hash de senha Enterprise@2026...")
    pw_hash = hash_pw(DEFAULT_PASSWORD)

    # Seed dos 20 tenants
    all_results = []
    print(f"\n[SEED] Criando {NUM_TENANTS} tenants enterprise...")
    for idx in range(1, NUM_TENANTS + 1):
        print(f"  [{idx:02d}/{NUM_TENANTS}] enterprise_{str(idx).zfill(3)}...", end=" ", flush=True)
        result = await seed_tenant(db, idx, plan["id"], feature_keys, pw_hash)
        all_results.append(result)
        tenant_name = result["tenant"]["name"]
        n_stores = len(result["stores"])
        print(f"OK — {tenant_name} ({n_stores} lojas)")

    # Salvar fixtures
    os.makedirs(FIXTURE_DIR, exist_ok=True)
    fixtures = []
    for r in all_results:
        slug = r["tenant"]["slug"]
        fixtures.append({
            "slug": slug,
            "tenant_name": r["tenant"]["name"],
            "tenant_id": r["tenant"]["id"],
            "store_ids": r["stores"],
            "admin": r["creds"]["admin"],
            "sellers_sample": r["creds"]["sellers"][:3],  # top 3 para brevidade
        })

    with open(FIXTURE_FILE, "w", encoding="utf-8") as f:
        json.dump(fixtures, f, indent=2, ensure_ascii=False)

    # Estatísticas finais
    print("\n" + "=" * 60)
    total_stores = await db.stores.count_documents({"slug": {"$regex": "^enterprise_"}} if False else
                                                    {"tenant_id": {"$in": [r["tenant"]["id"] for r in all_results]}})
    total_sellers = await db.seller_profiles.count_documents(
        {"tenant_id": {"$in": [r["tenant"]["id"] for r in all_results]}}
    )
    total_atts = await db.attendances.count_documents(
        {"tenant_id": {"$in": [r["tenant"]["id"] for r in all_results]}}
    )
    total_sales = await db.sales.count_documents(
        {"tenant_id": {"$in": [r["tenant"]["id"] for r in all_results]}}
    )
    total_goals = await db.goals.count_documents(
        {"tenant_id": {"$in": [r["tenant"]["id"] for r in all_results]}}
    )

    print(f"SEED ENTERPRISE CONCLUIDO:")
    print(f"  Tenants criados/atualizados : {NUM_TENANTS}")
    print(f"  Lojas totais                : {total_stores}")
    print(f"  Vendedores totais           : {total_sellers}")
    print(f"  Atendimentos históricos     : {total_atts}")
    print(f"  Vendas históricas           : {total_sales}")
    print(f"  Metas criadas               : {total_goals}")
    print(f"  Credenciais salvas em       : {FIXTURE_FILE}")
    print("=" * 60)

    client.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Seed Enterprise Dataset — Lista da Vez P2.5")
    parser.add_argument("--drop-enterprise", action="store_true",
                        help="Remove tenants enterprise antes de re-seedar")
    args = parser.parse_args()

    # Proteção de produção
    env = os.environ.get("ENVIRONMENT", "development").lower()
    if env == "production":
        print("ERRO: seed_enterprise_dataset.py NÃO pode ser executado em ENVIRONMENT=production.")
        print("Use ENVIRONMENT=staging ou ENVIRONMENT=development.")
        sys.exit(1)

    asyncio.run(main(drop_first=args.drop_enterprise))
