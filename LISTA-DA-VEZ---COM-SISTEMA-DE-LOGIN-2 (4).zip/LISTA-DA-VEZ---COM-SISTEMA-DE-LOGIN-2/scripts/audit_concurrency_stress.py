"""Auditoria — bateria de testes de concorrência 10x (fila, atendimento,
produtos, vendedores, convites, planos, push). Roda fora de /app/backend
para não disparar hot-reload do uvicorn durante iteração.

Uso: python3 /app/scripts/audit_concurrency_stress.py
"""
import asyncio
import os
import uuid

import asyncpg
import httpx

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL") or open("/app/frontend/.env").read().split(
    "REACT_APP_BACKEND_URL=")[1].splitlines()[0].strip()
BASE_URL = BASE_URL.rstrip("/")
DB_URL = None
for line in open("/app/backend/.env"):
    if line.startswith("DATABASE_URL="):
        DB_URL = line.split("=", 1)[1].strip().replace("postgresql+asyncpg://", "postgresql://")
TENANT = "demo"
N = 10

RESULTS = {}


def report(name, ok, detail):
    RESULTS[name] = {"ok": ok, "detail": detail}
    print(f"\n{'PASS' if ok else 'FAIL'} — {name}\n  {detail}")


async def main():
    conn = await asyncpg.connect(DB_URL)
    async with httpx.AsyncClient(timeout=60) as client:
        r = await client.post(f"{BASE_URL}/api/tenants/{TENANT}/auth/login",
                               json={"email": "admin@demo.com", "password": "Admin@123456"})
        r.raise_for_status()
        admin_token = r.json()["access_token"]
        admin_hdrs = {"Authorization": f"Bearer {admin_token}"}

        r = await client.post(f"{BASE_URL}/api/tenants/{TENANT}/auth/login",
                               json={"email": "joao@demo.com", "password": "Admin@123456"})
        r.raise_for_status()
        joao_token = r.json()["access_token"]
        joao_hdrs = {"Authorization": f"Bearer {joao_token}"}

        stores = (await client.get(f"{BASE_URL}/api/tenants/{TENANT}/stores", headers=admin_hdrs)).json()
        store_id = stores[0]["id"]

        sellers = (await client.get(f"{BASE_URL}/api/tenants/{TENANT}/sellers", headers=admin_hdrs)).json()
        joao_user_id = await conn.fetchval("SELECT id FROM doc_users WHERE doc->>'email' = 'joao@demo.com'")
        joao = next(s for s in sellers if s.get("user_id") == joao_user_id)
        joao_seller_id = joao["id"]
        joao_store_id = joao["store_id"]

        # ── 1. Produto — SKU duplicado (10x) ──────────────────────────────
        sku = f"AUDIT_TEST-SKU-{uuid.uuid4().hex[:8]}"
        payload = {"sku": sku, "name": "AUDIT_TEST Produto SKU", "price_cents": 1000}
        results = await asyncio.gather(*[
            client.post(f"{BASE_URL}/api/tenants/{TENANT}/products", headers=admin_hdrs, json=payload)
            for _ in range(N)
        ], return_exceptions=True)
        statuses = [x.status_code if not isinstance(x, Exception) else str(x) for x in results]
        db_count = await conn.fetchval("SELECT count(*) FROM doc_products WHERE doc->>'sku' = $1", sku)
        report("1. Produto SKU duplicado (10x)", statuses.count(201) == 1 and db_count == 1,
               f"statuses={statuses} db_count={db_count}")
        await conn.execute("DELETE FROM doc_products WHERE doc->>'sku' = $1", sku)

        # ── 2. Produto — SKU NULL (10x, deve permitir todos) ──────────────
        run_id = uuid.uuid4().hex[:8]
        results = await asyncio.gather(*[
            client.post(f"{BASE_URL}/api/tenants/{TENANT}/products", headers=admin_hdrs, json={
                "name": f"AUDIT_TEST Produto SemSKU {run_id}-{i}", "price_cents": 500,
            })
            for i in range(N)
        ], return_exceptions=True)
        statuses = [x.status_code if not isinstance(x, Exception) else str(x) for x in results]
        db_count = await conn.fetchval(
            "SELECT count(*) FROM doc_products WHERE doc->>'name' LIKE $1 AND doc->>'sku' IS NULL",
            f"AUDIT_TEST Produto SemSKU {run_id}%")
        report("2. Produto SKU NULL (10x, todos devem passar)", statuses.count(201) == N and db_count == N,
               f"statuses={statuses} db_count={db_count} (esperado {N})")
        await conn.execute("DELETE FROM doc_products WHERE doc->>'name' LIKE $1", f"AUDIT_TEST Produto SemSKU {run_id}%")

        # ── 3. Vendedor — e-mail duplicado (10x) ──────────────────────────
        email = f"audit_test_conc_{uuid.uuid4().hex[:8]}@demo.com"
        results = await asyncio.gather(*[
            client.post(f"{BASE_URL}/api/tenants/{TENANT}/sellers", headers=admin_hdrs, json={
                "name": "AUDIT_TEST Vendedor Conc", "email": email, "password": "Admin@123456",
                "store_id": store_id, "employee_code": f"AUDIT-{run_id}-{i}",
            })
            for i in range(N)
        ], return_exceptions=True)
        statuses = [x.status_code if not isinstance(x, Exception) else str(x) for x in results]
        users_count = await conn.fetchval("SELECT count(*) FROM doc_users WHERE doc->>'email' = $1", email)
        profiles_count = await conn.fetchval(
            "SELECT count(*) FROM doc_seller_profiles sp JOIN doc_users u ON u.id = sp.doc->>'user_id' WHERE u.doc->>'email' = $1",
            email)
        report("3. Vendedor e-mail duplicado (10x)",
               statuses.count(201) == 1 and users_count == 1 and profiles_count == 1,
               f"statuses={statuses} users={users_count} seller_profiles={profiles_count}")
        await conn.execute("DELETE FROM doc_seller_profiles WHERE doc->>'user_id' IN (SELECT id FROM doc_users WHERE doc->>'email' = $1)", email)
        await conn.execute("DELETE FROM doc_tenant_memberships WHERE doc->>'user_id' IN (SELECT id FROM doc_users WHERE doc->>'email' = $1)", email)
        await conn.execute("DELETE FROM doc_users WHERE doc->>'email' = $1", email)

        # ── 4. Plano — nome duplicado (10x, nova proteção) ────────────────
        plan_name = f"AUDIT_TEST Plano {uuid.uuid4().hex[:8]}"
        results = await asyncio.gather(*[
            client.post(f"{BASE_URL}/api/super-admin/plans", headers=admin_hdrs,
                        json={"name": plan_name, "description": "teste"})
            for _ in range(N)
        ], return_exceptions=True)
        statuses = [x.status_code if not isinstance(x, Exception) else str(x) for x in results]
        # plans exigem super admin — se 403 para todos, refazer com super admin
        if all(s == 403 for s in statuses if isinstance(s, int)):
            r = await client.post(f"{BASE_URL}/api/auth/login",
                                   json={"email": "admin@listadavez.com", "password": "Admin@123456"})
            sa_hdrs = {"Authorization": f"Bearer {r.json()['access_token']}"}
            results = await asyncio.gather(*[
                client.post(f"{BASE_URL}/api/super-admin/plans", headers=sa_hdrs,
                            json={"name": plan_name, "description": "teste"})
                for _ in range(N)
            ], return_exceptions=True)
            statuses = [x.status_code if not isinstance(x, Exception) else str(x) for x in results]
        db_count = await conn.fetchval("SELECT count(*) FROM doc_plans WHERE doc->>'name' = $1", plan_name)
        report("4. Plano nome duplicado (10x)", statuses.count(201) == 1 and db_count == 1,
               f"statuses={statuses} db_count={db_count}")
        await conn.execute("DELETE FROM doc_plans WHERE doc->>'name' = $1", plan_name)

        # ── 5. Push subscription — mesmo endpoint (10x, nova proteção) ────
        endpoint = f"https://audit-test-push.example.com/{uuid.uuid4().hex[:8]}"
        results = await asyncio.gather(*[
            client.post(f"{BASE_URL}/api/tenants/{TENANT}/push-subscriptions", headers=joao_hdrs,
                        json={"endpoint": endpoint})
            for _ in range(N)
        ], return_exceptions=True)
        statuses = [x.status_code if not isinstance(x, Exception) else str(x) for x in results]
        db_count = await conn.fetchval("SELECT count(*) FROM doc_push_subscriptions WHERE doc->>'endpoint' = $1", endpoint)
        report("5. Push subscription mesmo endpoint (10x)",
               all(isinstance(s, int) and s < 500 for s in statuses) and db_count == 1,
               f"statuses={statuses} db_count={db_count}")
        await conn.execute("DELETE FROM doc_push_subscriptions WHERE doc->>'endpoint' = $1", endpoint)

        # ── 6. Fila — join concorrente do mesmo vendedor (10x) ────────────
        await client.post(f"{BASE_URL}/api/tenants/{TENANT}/stores/{joao_store_id}/queue/leave",
                           headers=joao_hdrs, json={"seller_id": joao_seller_id})
        await client.patch(f"{BASE_URL}/api/tenants/{TENANT}/sellers/{joao_seller_id}/status",
                            headers=joao_hdrs, json={"new_status": "AVAILABLE"})
        results = await asyncio.gather(*[
            client.post(f"{BASE_URL}/api/tenants/{TENANT}/stores/{joao_store_id}/queue/join",
                        headers=joao_hdrs, json={"seller_id": joao_seller_id})
            for _ in range(N)
        ], return_exceptions=True)
        statuses = [x.status_code if not isinstance(x, Exception) else str(x) for x in results]
        entries_count = await conn.fetchval(
            "SELECT count(*) FROM doc_queue_entries WHERE doc->>'seller_id' = $1 AND doc->>'status' = 'WAITING'",
            joao_seller_id)
        report("6. Fila join concorrente mesmo vendedor (10x)",
               statuses.count(201) + statuses.count(200) <= 1 and entries_count <= 1,
               f"statuses={statuses} waiting_entries={entries_count}")

        # ── 7. Iniciar atendimento concorrente do mesmo vendedor (10x) ────
        results = await asyncio.gather(*[
            client.post(f"{BASE_URL}/api/tenants/{TENANT}/stores/{joao_store_id}/queue/start-attendance",
                        headers=admin_hdrs, json={"seller_id": joao_seller_id})
            for _ in range(N)
        ], return_exceptions=True)
        statuses = [x.status_code if not isinstance(x, Exception) else str(x) for x in results]
        successes = [x for x in results if not isinstance(x, Exception) and x.status_code in (200, 201)]
        att_ids = {x.json().get("attendance", {}).get("id") for x in successes}
        in_progress_count = await conn.fetchval(
            "SELECT count(*) FROM doc_attendances WHERE doc->>'seller_id' = $1 AND doc->>'status' = 'IN_PROGRESS'",
            joao_seller_id)
        report("7. Start-attendance concorrente mesmo vendedor (10x)",
               len(successes) == 1 and in_progress_count == 1,
               f"statuses={statuses} successes={len(successes)} att_ids={att_ids} in_progress_db={in_progress_count}")

        att_id = next(iter(att_ids)) if att_ids else None
        if not att_id:
            r = await client.get(f"{BASE_URL}/api/tenants/{TENANT}/sellers/{joao_seller_id}", headers=admin_hdrs)

        # ── 8. Finalizar atendimento concorrente (10x, mesmo attendance_id) ─
        if att_id:
            results = await asyncio.gather(*[
                client.post(f"{BASE_URL}/api/tenants/{TENANT}/stores/{joao_store_id}/queue/finish-attendance",
                            headers=admin_hdrs, json={"attendance_id": att_id, "result": "SALE", "sale_amount_cents": 4200})
                for _ in range(N)
            ], return_exceptions=True)
            statuses = [x.status_code if not isinstance(x, Exception) else str(x) for x in results]
            successes = [x for x in results if not isinstance(x, Exception) and x.status_code in (200, 201)]
            sales_count = await conn.fetchval(
                "SELECT count(*) FROM doc_sales WHERE doc->>'attendance_id' = $1", att_id)
            report("8. Finish-attendance concorrente mesmo attendance_id (10x)",
                   len(successes) >= 1 and sales_count == 1,
                   f"statuses={statuses} successes={len(successes)} sales_created={sales_count}")
            await conn.execute("DELETE FROM doc_sales WHERE doc->>'attendance_id' = $1", att_id)
            await conn.execute("DELETE FROM doc_attendances WHERE id = $1", att_id)
        else:
            report("8. Finish-attendance concorrente mesmo attendance_id (10x)", False, "sem attendance_id do passo 7")

        # limpar fila/estado do joao ao final
        await conn.execute(
            "DELETE FROM doc_queue_entries WHERE doc->>'seller_id' = $1 AND doc->>'status' = 'WAITING'",
            joao_seller_id)
        await client.patch(f"{BASE_URL}/api/tenants/{TENANT}/sellers/{joao_seller_id}/status",
                            headers=admin_hdrs, json={"new_status": "OFFLINE"})

        # ── 9. Reenvio de convite concorrente (10x, mesmo tenant) ─────────
        r = await client.post(f"{BASE_URL}/api/auth/login",
                               json={"email": "admin@listadavez.com", "password": "Admin@123456"})
        sa_hdrs = {"Authorization": f"Bearer {r.json()['access_token']}"}
        tenants = (await client.get(f"{BASE_URL}/api/super-admin/tenants", headers=sa_hdrs)).json()
        if isinstance(tenants, dict):
            tenants = tenants.get("items", [])
        demo_tenant = next((t for t in tenants if t.get("slug") == TENANT), None)
        if demo_tenant:
            before = await conn.fetchval(
                "SELECT count(*) FROM doc_invite_tokens WHERE doc->>'tenant_id' = $1 AND doc->>'revoked_at' IS NULL AND doc->>'used_at' IS NULL",
                demo_tenant["id"])
            results = await asyncio.gather(*[
                client.post(f"{BASE_URL}/api/super-admin/tenants/{demo_tenant['id']}/resend-invite", headers=sa_hdrs)
                for _ in range(N)
            ], return_exceptions=True)
            statuses = [x.status_code if not isinstance(x, Exception) else str(x) for x in results]
            after = await conn.fetchval(
                "SELECT count(*) FROM doc_invite_tokens WHERE doc->>'tenant_id' = $1 AND doc->>'revoked_at' IS NULL AND doc->>'used_at' IS NULL",
                demo_tenant["id"])
            report("9. Resend-invite concorrente (10x) — informativo",
                   500 not in [s for s in statuses if isinstance(s, int)],
                   f"statuses={statuses} active_tokens_before={before} active_tokens_after={after} "
                   f"(nota: sem lock; corrida pode deixar mais de 1 token ativo — achado de baixa prioridade)")
        else:
            report("9. Resend-invite concorrente (10x)", False, f"tenant demo não encontrado via super-admin (tenants={tenants[:3] if isinstance(tenants, list) else tenants})")

    await conn.close()

    print("\n\n==== RESUMO ====")
    for name, r in RESULTS.items():
        print(f"{'PASS' if r['ok'] else 'FAIL'} - {name}")


if __name__ == "__main__":
    asyncio.run(main())
