import os
import requests


BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")
TENANT = "demo"
ADMIN_EMAIL = "admin@demo.com"
ADMIN_PASS = "Admin@123456"
TARGET_EMAILS = {"joao@demo.com", "carlos@demo.com"}


def _h(token: str):
    return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}


def main():
    if not BASE_URL:
        print("skip cleanup: REACT_APP_BACKEND_URL missing")
        return

    login = requests.post(
        f"{BASE_URL}/api/tenants/{TENANT}/auth/login",
        json={"email": ADMIN_EMAIL, "password": ADMIN_PASS},
        timeout=20,
    )
    if login.status_code != 200:
        print(f"skip cleanup: login failed {login.status_code} {login.text[:200]}")
        return
    token = login.json().get("access_token")
    if not token:
        print("skip cleanup: no access token")
        return

    stores = requests.get(f"{BASE_URL}/api/tenants/{TENANT}/stores", headers=_h(token), timeout=20)
    if stores.status_code != 200 or not stores.json():
        print(f"skip cleanup: stores unavailable {stores.status_code}")
        return
    store_id = stores.json()[0]["id"]

    sellers_resp = requests.get(
        f"{BASE_URL}/api/tenants/{TENANT}/sellers?store_id={store_id}",
        headers=_h(token),
        timeout=20,
    )
    if sellers_resp.status_code != 200:
        print(f"skip cleanup: sellers unavailable {sellers_resp.status_code}")
        return

    seller_ids = []
    for s in sellers_resp.json():
        email = ((s.get("user") or {}).get("email") or s.get("email") or "").lower()
        if email in TARGET_EMAILS:
            seller_ids.append(s["id"])

    queue_state = requests.get(
        f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/queue",
        headers=_h(token),
        timeout=20,
    )
    queue_id = None
    active = []
    if queue_state.status_code == 200:
        payload = queue_state.json()
        queue_id = (payload.get("queue") or {}).get("id")
        active = payload.get("active_attendances") or []

    for att in active:
        if att.get("seller_id") in seller_ids:
            requests.post(
                f"{BASE_URL}/api/tenants/{TENANT}/attendances/{att['id']}/cancel",
                headers=_h(token),
                json={"reason": "cleanup_iter63"},
                timeout=20,
            )

    for sid in seller_ids:
        requests.post(
            f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/queue/retornar-operacao",
            headers=_h(token),
            json={"seller_id": sid},
            timeout=20,
        )
        requests.post(
            f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/queue/nova-jornada",
            headers=_h(token),
            json={"seller_id": sid},
            timeout=20,
        )
        requests.post(
            f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/queue/leave",
            headers=_h(token),
            json={"seller_id": sid, "queue_id": queue_id},
            timeout=20,
        )
        requests.post(
            f"{BASE_URL}/api/tenants/{TENANT}/stores/{store_id}/queue/return",
            headers=_h(token),
            json={"seller_id": sid, "join_queue": False, "queue_id": queue_id, "reason": "cleanup_iter63"},
            timeout=20,
        )

    print(f"cleanup done for sellers: {seller_ids}")


if __name__ == "__main__":
    main()
