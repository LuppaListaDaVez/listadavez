"""Script de Verificação de Índices MongoDB — P3
Verifica que todos os índices críticos existem nas coleções.

Uso:
    cd /app && python scripts/verify_indexes.py [--create-missing]

Flags:
    --create-missing   Cria índices ausentes (background=True)
"""
import asyncio
import argparse
import os
import sys

from motor.motor_asyncio import AsyncIOMotorClient

MONGO_URL = os.environ.get("MONGO_URL", "mongodb://localhost:27017").strip("\"'")
DB_NAME   = os.environ.get("DB_NAME", "test_database").strip("\"'")

# ── Índices críticos por coleção ─────────────────────────────────────────────
# Formato: (coleção, [(campo, direção), ...], unique, nome)
REQUIRED_INDEXES = [
    # tenants
    ("tenants",          [("slug", 1)],                                        True,  "idx_tenants_slug"),
    ("tenants",          [("status", 1)],                                      False, "idx_tenants_status"),
    # users
    ("users",            [("normalized_email", 1)],                            True,  "idx_users_email"),
    ("users",            [("is_super_admin", 1)],                              False, "idx_users_superadmin"),
    # tenant_memberships
    ("tenant_memberships", [("tenant_id", 1), ("user_id", 1)],                True,  "idx_memberships_tenant_user"),
    ("tenant_memberships", [("tenant_id", 1), ("role", 1)],                   False, "idx_memberships_tenant_role"),
    # stores
    ("stores",           [("tenant_id", 1), ("id", 1)],                       False, "idx_stores_tenant_id"),
    ("stores",           [("tenant_id", 1), ("code", 1)],                     False, "idx_stores_tenant_code"),
    ("stores",           [("tenant_id", 1), ("status", 1)],                   False, "idx_stores_tenant_status"),
    # seller_profiles
    ("seller_profiles",  [("tenant_id", 1), ("user_id", 1)],                  False, "idx_sellers_tenant_user"),
    ("seller_profiles",  [("tenant_id", 1), ("store_id", 1), ("current_status", 1)], False, "idx_sellers_store_status"),
    # queues
    ("queues",           [("tenant_id", 1), ("store_id", 1), ("is_default", 1)], False, "idx_queues_default"),
    ("queues",           [("tenant_id", 1), ("store_id", 1), ("status", 1)],  False, "idx_queues_active"),
    # queue_entries
    ("queue_entries",    [("tenant_id", 1), ("queue_id", 1), ("status", 1), ("position", 1)], False, "idx_qentries_queue_status"),
    ("queue_entries",    [("tenant_id", 1), ("seller_id", 1), ("status", 1)], False, "idx_qentries_seller"),
    # attendances
    ("attendances",      [("tenant_id", 1), ("store_id", 1), ("status", 1), ("created_at", -1)], False, "idx_att_store_status"),
    ("attendances",      [("tenant_id", 1), ("seller_id", 1), ("status", 1)], False, "idx_att_seller_status"),
    ("attendances",      [("tenant_id", 1), ("created_at", -1)],              False, "idx_att_tenant_date"),
    # sales
    ("sales",            [("tenant_id", 1), ("store_id", 1), ("created_at", -1)], False, "idx_sales_store_date"),
    ("sales",            [("tenant_id", 1), ("seller_id", 1), ("created_at", -1)], False, "idx_sales_seller_date"),
    ("sales",            [("tenant_id", 1), ("status", 1)],                   False, "idx_sales_status"),
    # goals
    ("goals",            [("tenant_id", 1), ("status", 1), ("period_end", 1)], False, "idx_goals_active"),
    ("goals",            [("tenant_id", 1), ("store_id", 1), ("type", 1)],    False, "idx_goals_store_type"),
    # notifications
    ("notifications",    [("tenant_id", 1), ("user_id", 1), ("is_read", 1), ("created_at", -1)], False, "idx_notif_user_unread"),
    ("notifications",    [("tenant_id", 1), ("created_at", -1)],              False, "idx_notif_date"),
    # export_jobs
    ("export_jobs",      [("tenant_id", 1), ("requested_by", 1), ("created_at", -1)], False, "idx_exports_user"),
    ("export_jobs",      [("tenant_id", 1), ("status", 1)],                   False, "idx_exports_status"),
    # idempotency_keys
    ("idempotency_keys", [("tenant_id", 1), ("key", 1)],                      True,  "idx_idem_tenant_key"),
    ("idempotency_keys", [("created_at", 1)],                                 False, "idx_idem_ttl"),
    # security_events
    ("security_events",  [("tenant_id", 1), ("created_at", -1)],              False, "idx_sec_events_date"),
    ("security_events",  [("event_type", 1), ("created_at", -1)],             False, "idx_sec_events_type"),
    # audit_logs
    ("audit_logs",       [("tenant_id", 1), ("created_at", -1)],              False, "idx_audit_tenant"),
    ("audit_logs",       [("entity", 1), ("entity_id", 1)],                   False, "idx_audit_entity"),
    # feedbacks
    ("feedbacks",        [("tenant_id", 1), ("seller_id", 1), ("created_at", -1)], False, "idx_feedbacks_seller"),
    # loss_reasons
    ("loss_reasons",     [("tenant_id", 1), ("active", 1)],                   False, "idx_lossreasons_tenant"),
]


async def verify_indexes(create_missing: bool = False):
    client = AsyncIOMotorClient(MONGO_URL)
    db = client[DB_NAME]

    print("=" * 60)
    print(f"Lista da Vez — Verificação de Índices MongoDB (P3)")
    print(f"  Database: {DB_NAME}")
    print(f"  Modo: {'CRIAR AUSENTES' if create_missing else 'APENAS VERIFICAR'}")
    print("=" * 60)

    missing = []
    present = []
    errors = []

    for col_name, fields, unique, idx_name in REQUIRED_INDEXES:
        try:
            col = db[col_name]
            existing_indexes = await col.index_information()
            existing_keys = [
                tuple((k, v) for k, v in info["key"])
                for info in existing_indexes.values()
            ]
            required_key = tuple((k, v) for k, v in fields)

            if required_key in existing_keys:
                present.append((col_name, idx_name))
            else:
                missing.append((col_name, fields, unique, idx_name))
        except Exception as e:
            errors.append((col_name, idx_name, str(e)))

    print(f"\n✅ Índices presentes : {len(present)}")
    print(f"❌ Índices ausentes  : {len(missing)}")
    if errors:
        print(f"⚠️  Erros verificação: {len(errors)}")

    if missing:
        print("\nÍndices AUSENTES:")
        for col_name, fields, unique, idx_name in missing:
            print(f"  [{col_name}] {idx_name} — campos: {fields}")

        if create_missing:
            print("\nCriando índices ausentes (background=True)...")
            created = 0
            for col_name, fields, unique, idx_name in missing:
                try:
                    col = db[col_name]
                    await col.create_index(fields, background=True, unique=unique, name=idx_name)
                    print(f"  ✅ Criado: [{col_name}] {idx_name}")
                    created += 1
                except Exception as e:
                    print(f"  ⚠️  Erro ao criar [{col_name}] {idx_name}: {e}")
            print(f"\nÍndices criados: {created}/{len(missing)}")
        else:
            print("\nUse --create-missing para criar os índices ausentes.")
    else:
        print("\nTodos os índices críticos estão presentes!")

    if errors:
        print("\nErros durante verificação:")
        for col_name, idx_name, err in errors:
            print(f"  [{col_name}] {idx_name}: {err}")

    client.close()

    # Exit code 1 se há índices ausentes (permite uso em CI)
    if missing and not create_missing:
        sys.exit(1)
    sys.exit(0)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Verificar/criar índices MongoDB críticos")
    parser.add_argument("--create-missing", action="store_true",
                        help="Criar índices ausentes com background=True")
    args = parser.parse_args()
    asyncio.run(verify_indexes(create_missing=args.create_missing))
