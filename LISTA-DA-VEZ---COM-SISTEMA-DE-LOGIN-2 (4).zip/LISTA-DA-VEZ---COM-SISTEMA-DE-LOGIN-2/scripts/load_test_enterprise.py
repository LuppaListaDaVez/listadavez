"""Script de Carga Enterprise — Lista da Vez P2.5
Simula tráfego de 500 empresas com múltiplas lojas e vendedores.
Evolução do load_test_locust.py com foco em escala enterprise.

Uso:
    pip install locust
    locust -f scripts/load_test_enterprise.py --host=https://SEU_BACKEND_URL \
           --users=500 --spawn-rate=25 --run-time=10m --headless

    # Relatório completo:
    locust -f scripts/load_test_enterprise.py --host=https://SEU_BACKEND_URL \
           --users=500 --spawn-rate=25 --run-time=10m --headless \
           --html=docs/load-test-enterprise-report.html \
           --csv=docs/load-test-enterprise-metrics

Cenários simulados:
    - AdminDashboardUser (25%): admins de tenant consultando dashboard
    - QueueOperationUser (30%): operações completas de fila (join/start/finish)
    - SellerStatusUser (20%): vendedores alternando status (break/available)
    - ReportHeavyUser (10%): relatórios, exportações assíncronas pesadas
    - MetricsMonitorUser (5%): monitoramento de métricas (super admin)
    - BurstTrafficUser (10%): simulação de picos de tráfego
"""
import json
import os
import random
import time
import uuid
from locust import HttpUser, task, between, events, constant_pacing

# ── SLA Targets — P2.5 Enterprise (500 empresas) ─────────────────────────────
SLA_P95_DASHBOARD_MS = 500
SLA_P95_QUEUE_MS = 300
SLA_P95_LOGIN_MS = 400
SLA_P95_REPORT_CREATE_MS = 200
SLA_MAX_ERROR_RATE = 0.02   # 2%
SLA_MIN_RPS = 50             # Throughput mínimo

# ── Tenants para teste ────────────────────────────────────────────────────────
# Usa tenants reais: demo + enterprise seedados pelo seed_enterprise_dataset.py
BASE_TENANT = "demo"
ADMIN_EMAIL = "admin@demo.com"
ADMIN_PASSWORD = "Admin@123456"

# Tenants enterprise (se seedados)
ENTERPRISE_TENANTS = [f"enterprise_{str(i).zfill(3)}" for i in range(1, 21)]
ENTERPRISE_ADMIN_TEMPLATE = "admin@enterprise-{num}.com"
ENTERPRISE_PASSWORD = "Enterprise@2026"

# Credenciais de fallback (sempre disponíveis)
FALLBACK_TENANTS = [
    {"slug": "demo", "email": "admin@demo.com", "password": "Admin@123456"},
    {"slug": "demo-b", "email": "admin@demo-b.com", "password": "Admin@123456"},
]


def load_enterprise_fixtures():
    """Carrega fixtures do seed enterprise se disponíveis."""
    fixture_path = "/app/fixtures/enterprise_creds.json"
    if os.path.exists(fixture_path):
        try:
            with open(fixture_path) as f:
                data = json.load(f)
            return [
                {"slug": d["slug"], "email": d["admin"]["email"],
                 "password": d["admin"]["password"]}
                for d in data if d.get("admin")
            ]
        except Exception:
            pass
    return []


ENTERPRISE_FIXTURES = load_enterprise_fixtures()
ALL_TENANTS = (ENTERPRISE_FIXTURES or FALLBACK_TENANTS) + FALLBACK_TENANTS


# ── Base User ─────────────────────────────────────────────────────────────────

class BaseEnterpriseUser(HttpUser):
    """Base com login automático e gestão de token."""
    abstract = True
    token = None
    store_id = None
    seller_id = None
    tenant_info = None

    def on_start(self):
        self.tenant_info = random.choice(ALL_TENANTS)
        self._login()

    def _login(self):
        if not self.tenant_info:
            return
        slug = self.tenant_info["slug"]
        with self.client.post(
            f"/api/tenants/{slug}/auth/login",
            json={
                "email": self.tenant_info["email"],
                "password": self.tenant_info["password"],
            },
            catch_response=True,
            name="[AUTH] Login",
        ) as r:
            if r.status_code == 200:
                self.token = r.json().get("access_token")
                r.success()
            elif r.status_code == 429:
                r.failure("Rate limit no login")
                # Tentar com fallback
                self.tenant_info = random.choice(FALLBACK_TENANTS)
            else:
                r.failure(f"Login falhou: {r.status_code} — {slug}")
                self.tenant_info = random.choice(FALLBACK_TENANTS)
                return

        if not self.token:
            return

        # Obter primeira loja
        with self.client.get(
            f"/api/tenants/{slug}/stores",
            headers=self._headers(),
            catch_response=True,
            name="[SETUP] Get stores",
        ) as r:
            if r.status_code == 200 and r.json():
                self.store_id = r.json()[0]["id"]
                r.success()
            elif r.status_code in (401, 403):
                # Token inválido para tenant — usar fallback
                self.tenant_info = random.choice(FALLBACK_TENANTS)
                self._login()
            else:
                r.success()  # Loja pode estar vazia

    def _headers(self):
        return {"Authorization": f"Bearer {self.token}"} if self.token else {}

    def _slug(self):
        return self.tenant_info["slug"] if self.tenant_info else BASE_TENANT

    def _get_queue_state(self):
        if not self.store_id:
            return None
        r = self.client.get(
            f"/api/tenants/{self._slug()}/stores/{self.store_id}/queue",
            headers=self._headers(),
            name="[QUEUE] Get state",
        )
        return r.json() if r.status_code == 200 else None


# ── Cenário 1: Admin Dashboard (25%) ─────────────────────────────────────────

class AdminDashboardUser(BaseEnterpriseUser):
    """Simula admin acessando dashboard e relatórios — 25% do tráfego."""
    weight = 25
    wait_time = between(1, 4)

    @task(5)
    def view_dashboard(self):
        """Dashboard summary — P95 target < 500ms."""
        with self.client.get(
            f"/api/tenants/{self._slug()}/dashboard/summary",
            headers=self._headers(),
            catch_response=True,
            name="[DASHBOARD] Summary",
        ) as r:
            if r.status_code == 200:
                elapsed_ms = r.elapsed.total_seconds() * 1000
                if elapsed_ms > SLA_P95_DASHBOARD_MS * 2:
                    r.failure(f"Dashboard P95 violado: {elapsed_ms:.0f}ms > {SLA_P95_DASHBOARD_MS*2}ms")
                else:
                    r.success()
            elif r.status_code in (401, 403):
                self._login()
                r.success()
            else:
                r.failure(f"Dashboard erro: {r.status_code}")

    @task(3)
    def view_stores(self):
        """Lista de lojas."""
        self.client.get(
            f"/api/tenants/{self._slug()}/stores",
            headers=self._headers(),
            name="[STORES] List",
        )

    @task(2)
    def view_sellers_list(self):
        """Lista de vendedores."""
        self.client.get(
            f"/api/tenants/{self._slug()}/sellers",
            headers=self._headers(),
            name="[SELLERS] List",
        )

    @task(2)
    def view_goals(self):
        """Metas ativas."""
        self.client.get(
            f"/api/tenants/{self._slug()}/goals",
            headers=self._headers(),
            name="[GOALS] List",
        )

    @task(1)
    def view_rankings(self):
        """Rankings — consulta com aggregation pipeline pesado."""
        self.client.get(
            f"/api/tenants/{self._slug()}/rankings",
            headers=self._headers(),
            name="[RANKINGS] Get",
        )

    @task(1)
    def view_notifications(self):
        """Notificações não lidas."""
        self.client.get(
            f"/api/tenants/{self._slug()}/notifications?unread=true&page_size=20",
            headers=self._headers(),
            name="[NOTIF] Unread",
        )


# ── Cenário 2: Queue Operations (30%) ────────────────────────────────────────

class QueueOperationUser(BaseEnterpriseUser):
    """Simula fluxo completo de fila — 30% do tráfego."""
    weight = 30
    wait_time = between(0.5, 2)

    @task(5)
    def poll_queue_state(self):
        """Polling contínuo do estado da fila."""
        if not self.store_id:
            return
        with self.client.get(
            f"/api/tenants/{self._slug()}/stores/{self.store_id}/queue",
            headers=self._headers(),
            catch_response=True,
            name="[QUEUE] Poll state",
        ) as r:
            if r.status_code == 200:
                elapsed_ms = r.elapsed.total_seconds() * 1000
                if elapsed_ms > SLA_P95_QUEUE_MS * 3:
                    r.failure(f"Queue poll lento: {elapsed_ms:.0f}ms")
                else:
                    r.success()
            else:
                r.success()  # Store pode não ter fila configurada

    @task(3)
    def queue_join_leave_cycle(self):
        """Ciclo join → leave."""
        if not self.store_id:
            return
        state = self._get_queue_state()
        if not state:
            return

        available = state.get("available_sellers", [])
        if not available:
            return

        seller_id = available[0]["seller_id"]

        # Join
        with self.client.post(
            f"/api/tenants/{self._slug()}/stores/{self.store_id}/queue/join",
            json={"seller_id": seller_id},
            headers=self._headers(),
            catch_response=True,
            name="[QUEUE] Join",
        ) as r:
            if r.status_code not in (200, 201, 409):
                r.failure(f"Join inesperado: {r.status_code}")
            else:
                r.success()

        time.sleep(random.uniform(0.2, 1.0))

        # Leave
        self.client.post(
            f"/api/tenants/{self._slug()}/stores/{self.store_id}/queue/leave",
            json={"seller_id": seller_id},
            headers=self._headers(),
            name="[QUEUE] Leave",
        )

    @task(1)
    def full_attendance_cycle(self):
        """Ciclo completo: join → start → finish (INVALID para não poluir dados reais)."""
        if not self.store_id:
            return
        state = self._get_queue_state()
        if not state:
            return

        available = state.get("available_sellers", [])
        if not available:
            return

        seller_id = available[0]["seller_id"]

        # Join
        r = self.client.post(
            f"/api/tenants/{self._slug()}/stores/{self.store_id}/queue/join",
            json={"seller_id": seller_id},
            headers=self._headers(),
            name="[QUEUE] Join (full)",
        )
        if r.status_code not in (200, 201):
            return

        # Start attendance
        r = self.client.post(
            f"/api/tenants/{self._slug()}/stores/{self.store_id}/queue/start-attendance",
            json={"seller_id": seller_id},
            headers=self._headers(),
            name="[QUEUE] Start attendance",
        )
        if r.status_code != 200:
            return

        att_id = r.json().get("attendance", {}).get("id") or r.json().get("id")
        if not att_id:
            return

        time.sleep(random.uniform(0.5, 2.0))

        # Finish
        idem_key = f"load-enterprise-{att_id}-{int(time.time())}"
        self.client.post(
            f"/api/tenants/{self._slug()}/stores/{self.store_id}/queue/finish-attendance",
            json={
                "attendance_id": att_id,
                "result": "INVALID",
                "notes": "Enterprise load test — ignorar",
            },
            headers={**self._headers(), "Idempotency-Key": idem_key},
            name="[QUEUE] Finish attendance",
        )


# ── Cenário 3: Seller Status (20%) ───────────────────────────────────────────

class SellerStatusUser(BaseEnterpriseUser):
    """Simula vendedores alternando status e consultando fila — 20% do tráfego."""
    weight = 20
    wait_time = between(2, 6)

    @task(4)
    def check_own_status(self):
        """Vendedor consulta seu próprio status na fila."""
        if not self.store_id:
            return
        self._get_queue_state()

    @task(2)
    def mark_break(self):
        """Vendedor entra em pausa."""
        if not self.store_id:
            return
        state = self._get_queue_state()
        if not state:
            return

        available = state.get("available_sellers", [])
        if not available:
            return

        seller_id = available[0]["seller_id"]
        self.client.post(
            f"/api/tenants/{self._slug()}/stores/{self.store_id}/queue/mark-away",
            json={"seller_id": seller_id, "new_status": "BREAK", "reason": "Load test"},
            headers=self._headers(),
            name="[SELLER] Mark break",
        )

    @task(1)
    def view_attendances_history(self):
        """Consulta histórico de atendimentos."""
        self.client.get(
            f"/api/tenants/{self._slug()}/attendances?page=1&page_size=20",
            headers=self._headers(),
            name="[ATTENDANCES] History",
        )


# ── Cenário 4: Heavy Reports (10%) ───────────────────────────────────────────

class ReportHeavyUser(BaseEnterpriseUser):
    """Simula geração de relatórios pesados — 10% do tráfego."""
    weight = 10
    wait_time = between(3, 10)

    @task(3)
    def create_async_export(self):
        """Cria job de export assíncrono."""
        types = ["attendances", "conversion", "loss-reasons", "seller-performance"]
        rtype = random.choice(types)

        with self.client.post(
            f"/api/tenants/{self._slug()}/reports/export/async",
            json={"report_type": rtype},
            headers=self._headers(),
            catch_response=True,
            name="[EXPORT] Create async job",
        ) as r:
            if r.status_code in (200, 201):
                elapsed_ms = r.elapsed.total_seconds() * 1000
                if elapsed_ms > SLA_P95_REPORT_CREATE_MS * 5:
                    r.failure(f"Export create lento: {elapsed_ms:.0f}ms")
                else:
                    r.success()
            elif r.status_code == 403:
                r.success()  # Feature desabilitada — aceitável
            else:
                r.failure(f"Export error: {r.status_code}")

    @task(2)
    def list_export_jobs(self):
        """Lista jobs de export."""
        self.client.get(
            f"/api/tenants/{self._slug()}/reports/export/jobs",
            headers=self._headers(),
            name="[EXPORT] List jobs",
        )

    @task(2)
    def view_sales_report(self):
        """Consulta relatório de vendas paginado."""
        self.client.get(
            f"/api/tenants/{self._slug()}/attendances?page=1&page_size=50",
            headers=self._headers(),
            name="[REPORT] Attendances paginated",
        )

    @task(1)
    def view_feedbacks(self):
        """Consulta feedbacks — relatório de coaching."""
        self.client.get(
            f"/api/tenants/{self._slug()}/feedbacks?page_size=20",
            headers=self._headers(),
            name="[REPORT] Feedbacks",
        )


# ── Cenário 5: Metrics Monitor (5%) ──────────────────────────────────────────

class MetricsMonitorUser(BaseEnterpriseUser):
    """Simula monitoramento de métricas por super admin — 5% do tráfego."""
    weight = 5
    wait_time = between(5, 15)

    def on_start(self):
        """Super admin usa endpoint diferente de login."""
        with self.client.post(
            "/api/auth/login",
            json={"email": "superadmin@sistema.com", "password": "Admin@123456"},
            catch_response=True,
            name="[AUTH] Super admin login",
        ) as r:
            if r.status_code == 200:
                self.token = r.json().get("access_token")
                r.success()
            else:
                r.failure(f"Super admin login falhou: {r.status_code}")

    @task(3)
    def get_json_metrics(self):
        """Consulta métricas JSON."""
        with self.client.get(
            "/api/metrics",
            headers=self._headers(),
            catch_response=True,
            name="[METRICS] JSON",
        ) as r:
            if r.status_code == 200:
                r.success()
            elif r.status_code in (401, 403):
                self.on_start()  # Re-login
                r.success()
            else:
                r.failure(f"Metrics error: {r.status_code}")

    @task(2)
    def get_prometheus_metrics(self):
        """Consulta métricas Prometheus."""
        self.client.get(
            "/api/metrics/prometheus",
            headers=self._headers(),
            name="[METRICS] Prometheus",
        )

    @task(1)
    def health_check(self):
        """Health check como load balancer probe."""
        with self.client.get(
            "/api/health/ready",
            catch_response=True,
            name="[HEALTH] Ready probe",
        ) as r:
            if r.status_code == 200:
                r.success()
            else:
                r.failure(f"Health degraded: {r.status_code}")


# ── Cenário 6: Burst Traffic (10%) ────────────────────────────────────────────

class BurstTrafficUser(BaseEnterpriseUser):
    """Simula picos de tráfego (muitos logins simultâneos) — 10% do tráfego."""
    weight = 10
    wait_time = constant_pacing(0.5)  # Requests mais rápidos

    @task(3)
    def rapid_login(self):
        """Simula logins rápidos (pico de acesso no início do dia)."""
        tenant = random.choice(ALL_TENANTS[:5])  # Top 5 tenants
        with self.client.post(
            f"/api/tenants/{tenant['slug']}/auth/login",
            json={"email": tenant["email"], "password": tenant["password"]},
            catch_response=True,
            name="[BURST] Rapid login",
        ) as r:
            if r.status_code == 200:
                self.token = r.json().get("access_token")
                r.success()
            elif r.status_code == 429:
                r.success()  # Rate limit esperado em burst — aceitável
            else:
                r.failure(f"Burst login erro: {r.status_code}")

    @task(2)
    def rapid_health_check(self):
        """Health check em alta frequência."""
        self.client.get("/api/health/ready", name="[BURST] Health")

    @task(1)
    def rapid_queue_read(self):
        """Leitura rápida da fila (acesso mobile/PWA)."""
        if not self.store_id:
            return
        self.client.get(
            f"/api/tenants/{self._slug()}/stores/{self.store_id}/queue",
            headers=self._headers(),
            name="[BURST] Queue read",
        )


# ── Event Handlers — Relatório Automático ─────────────────────────────────────

@events.quitting.add_listener
def on_locust_quit(environment, **kw):
    """Gera sumário de resultados e verifica SLA."""
    stats = environment.stats
    total = stats.total

    print("\n" + "=" * 70)
    print("RELATÓRIO ENTERPRISE LOAD TEST — Lista da Vez P2.5")
    print("=" * 70)
    print(f"Usuários simulados: {environment.runner.target_user_count if environment.runner else 'N/A'}")
    print(f"Total de requests : {total.num_requests}")
    print(f"Falhas            : {total.num_failures}")
    print(f"Taxa de erro      : {total.fail_ratio * 100:.2f}%")
    print(f"RPS médio         : {total.current_rps:.1f}")
    print(f"RPS máximo        : {total.max_rps:.1f}")
    print()

    p50 = total.get_response_time_percentile(0.50) or 0
    p95 = total.get_response_time_percentile(0.95) or 0
    p99 = total.get_response_time_percentile(0.99) or 0

    print(f"Latência P50      : {p50:.0f}ms")
    print(f"Latência P95      : {p95:.0f}ms")
    print(f"Latência P99      : {p99:.0f}ms")
    print()

    # Top 5 endpoints mais lentos
    print("Top 5 endpoints mais lentos (P95):")
    entries = sorted(
        [e for e in stats.entries.values() if e.num_requests > 0],
        key=lambda e: e.get_response_time_percentile(0.95) or 0,
        reverse=True,
    )[:5]
    for e in entries:
        ep95 = e.get_response_time_percentile(0.95) or 0
        print(f"  {e.name[:50]:50s} P95={ep95:.0f}ms  ({e.num_requests} req, {e.fail_ratio*100:.1f}% fail)")

    print("\n" + "─" * 70)
    print("VERIFICAÇÃO DE SLA:")

    sla_ok = True

    if p95 > SLA_P95_DASHBOARD_MS * 2:
        print(f"  FALHA P95 geral: {p95:.0f}ms > {SLA_P95_DASHBOARD_MS*2}ms")
        sla_ok = False
    else:
        print(f"  OK P95: {p95:.0f}ms <= {SLA_P95_DASHBOARD_MS*2}ms")

    if total.fail_ratio > SLA_MAX_ERROR_RATE:
        print(f"  FALHA taxa de erro: {total.fail_ratio*100:.2f}% > {SLA_MAX_ERROR_RATE*100}%")
        sla_ok = False
    else:
        print(f"  OK taxa de erro: {total.fail_ratio*100:.2f}% <= {SLA_MAX_ERROR_RATE*100}%")

    if total.current_rps < SLA_MIN_RPS and total.num_requests > 100:
        print(f"  WARN throughput: {total.current_rps:.1f} RPS < {SLA_MIN_RPS} RPS esperado")
    else:
        print(f"  OK throughput: {total.current_rps:.1f} RPS")

    print()
    if sla_ok:
        print("RESULTADO FINAL: SLA Enterprise APROVADO para 500 empresas")
    else:
        print("RESULTADO FINAL: SLA Enterprise FALHOU — revisar antes do P3")
    print("=" * 70)

    # Salvar relatório em JSON
    report = {
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime()),
        "total_requests": total.num_requests,
        "total_failures": total.num_failures,
        "fail_ratio": total.fail_ratio,
        "avg_rps": total.current_rps,
        "max_rps": total.max_rps,
        "p50_ms": p50,
        "p95_ms": p95,
        "p99_ms": p99,
        "sla_approved": sla_ok,
    }
    os.makedirs("/app/docs", exist_ok=True)
    with open("/app/docs/load-test-enterprise-latest.json", "w") as f:
        json.dump(report, f, indent=2)


@events.init.add_listener
def on_locust_init(environment, **kw):
    """Exibe configuração no início."""
    print("\n" + "=" * 70)
    print("Lista da Vez — Enterprise Load Test P2.5 iniciando...")
    fixture_count = len(ENTERPRISE_FIXTURES)
    print(f"Tenants disponíveis: {len(ALL_TENANTS)} ({fixture_count} enterprise + {len(FALLBACK_TENANTS)} fallback)")
    print("Cenários: Admin(25%) + Queue(30%) + Seller(20%) + Reports(10%) + Metrics(5%) + Burst(10%)")
    print("=" * 70)
