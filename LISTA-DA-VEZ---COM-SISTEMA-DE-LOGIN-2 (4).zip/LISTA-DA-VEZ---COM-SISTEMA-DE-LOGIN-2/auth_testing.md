# Auth Testing Playbook

## Escopo desta alteração
- A autenticação existente JWT/Bearer e Google OAuth não foi reimplementada.
- O seed de apresentação apenas cria/atualiza usuários demo de forma idempotente usando `security.hash_password` já existente.

## Credenciais demo esperadas
- `/demo/login`
- `admin@demo.com / Admin@123456` — TENANT_ADMIN
- `gerente@demo.com / Admin@123456` — STORE_MANAGER
- `joao@demo.com / Admin@123456` — SELLER

## Teste rápido via API
```bash
curl -X POST "$REACT_APP_BACKEND_URL/api/tenants/demo/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@demo.com","password":"Admin@123456"}'
```

## Verificações
- Login retorna `access_token` e `refresh_token`.
- Usuários demo têm `password_hash` bcrypt.
- Memberships do tenant `demo` ficam ativas e com roles corretas.
- O seed é idempotente: rodar novamente não duplica usuários, lojas, vendedores, atendimentos ou vendas de apresentação.