/**
 * api/notifications.js — Operações de notificações.
 */
import api from "../lib/api";

export const notificationsApi = {
    /** Listar notificações não lidas do usuário. */
    listUnread: (tenantSlug, params) =>
        api
            .get(`/tenants/${tenantSlug}/notifications/unread`, { params })
            .then((r) => r.data),

    /** Listar todas as notificações. */
    list: (tenantSlug, params) =>
        api
            .get(`/tenants/${tenantSlug}/notifications`, { params })
            .then((r) => r.data),

    /** Marcar notificação como lida. */
    markRead: (tenantSlug, notificationId) =>
        api
            .post(`/tenants/${tenantSlug}/notifications/${notificationId}/read`)
            .then((r) => r.data),

    /** Marcar todas como lidas. */
    markAllRead: (tenantSlug) =>
        api
            .post(`/tenants/${tenantSlug}/notifications/mark-all-read`)
            .then((r) => r.data),

    /** Preferências de notificação do usuário. */
    getPreferences: (tenantSlug) =>
        api
            .get(`/tenants/${tenantSlug}/notification-preferences`)
            .then((r) => r.data),

    /** Atualizar preferências. */
    updatePreferences: (tenantSlug, payload) =>
        api
            .put(`/tenants/${tenantSlug}/notification-preferences`, payload)
            .then((r) => r.data),
};
