/**
 * api/auth.js — Operações de autenticação tenant-scoped.
 */
import api from "../lib/api";

export const authApi = {
    /** Login tenant. */
    login: (tenantSlug, email, password) =>
        api
            .post(`/tenants/${tenantSlug}/auth/login`, { email, password })
            .then((r) => r.data),

    /** Logout (revoga token). */
    logout: (tenantSlug) =>
        api
            .post(`/tenants/${tenantSlug}/auth/logout`)
            .then((r) => r.data)
            .catch(() => null), // logout sempre limpa local mesmo se falhar

    /** Refresh de token. */
    refresh: (refreshToken) =>
        api
            .post(`/auth/refresh`, { refresh_token: refreshToken })
            .then((r) => r.data),

    /** Solicitar reset de senha. */
    requestPasswordReset: (tenantSlug, email) =>
        api
            .post(`/tenants/${tenantSlug}/auth/password-reset/request`, { email })
            .then((r) => r.data),

    /** Confirmar reset de senha com token. */
    confirmPasswordReset: (tenantSlug, token, newPassword) =>
        api
            .post(`/tenants/${tenantSlug}/auth/password-reset/confirm`, {
                token,
                new_password: newPassword,
            })
            .then((r) => r.data),

    /** Alterar senha do usuário logado. */
    changePassword: (tenantSlug, currentPassword, newPassword) =>
        api
            .post(`/tenants/${tenantSlug}/auth/change-password`, {
                current_password: currentPassword,
                new_password: newPassword,
            })
            .then((r) => r.data),

    /** Perfil do usuário logado. */
    getProfile: (tenantSlug) =>
        api.get(`/tenants/${tenantSlug}/auth/me`).then((r) => r.data),
};
