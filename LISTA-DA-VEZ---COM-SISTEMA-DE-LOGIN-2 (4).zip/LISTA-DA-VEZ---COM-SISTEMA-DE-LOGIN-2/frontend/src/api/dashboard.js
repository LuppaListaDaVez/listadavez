/**
 * api/dashboard.js — Operações do dashboard e resumo operacional.
 */
import api from "../lib/api";

export const dashboardApi = {
    /** Resumo do dashboard do tenant. */
    getSummary: (tenantSlug) =>
        api
            .get(`/tenants/${tenantSlug}/dashboard/summary`)
            .then((r) => r.data),

    /** Metas ativas. */
    getActiveGoals: (tenantSlug, params) =>
        api
            .get(`/tenants/${tenantSlug}/goals`, { params: { status: "ACTIVE", ...params } })
            .then((r) => r.data),

    /** Rankings por critério. */
    getRankings: (tenantSlug, criteria = "REVENUE", params) =>
        api
            .get(`/tenants/${tenantSlug}/rankings`, {
                params: { criteria, ...params },
            })
            .then((r) => r.data),

    /** Sellers da loja. */
    getSellers: (tenantSlug, storeId) =>
        api
            .get(`/tenants/${tenantSlug}/sellers`, {
                params: storeId ? { store_id: storeId } : undefined,
            })
            .then((r) => r.data),

    /** Usuários do tenant. */
    getUsers: (tenantSlug) =>
        api.get(`/tenants/${tenantSlug}/users`).then((r) => r.data),

    /** Times/equipes. */
    getTeams: (tenantSlug) =>
        api.get(`/tenants/${tenantSlug}/teams`).then((r) => r.data),

    /** Observabilidade/health admin. */
    getObservability: () =>
        api.get(`/admin/observability`).then((r) => r.data),
};
