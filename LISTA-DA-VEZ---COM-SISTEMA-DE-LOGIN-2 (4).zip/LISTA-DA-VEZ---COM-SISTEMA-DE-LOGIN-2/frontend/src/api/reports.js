/**
 * api/reports.js — Relatórios e exportações assíncronas.
 */
import api from "../lib/api";

export const reportsApi = {
    /** Criar job de exportação assíncrona. */
    createExportJob: (tenantSlug, reportType, filters) =>
        api
            .post(`/tenants/${tenantSlug}/reports/export/async`, {
                report_type: reportType,
                filters: filters || {},
            })
            .then((r) => r.data),

    /** Consultar status de um job de exportação. */
    getExportJob: (tenantSlug, jobId) =>
        api
            .get(`/tenants/${tenantSlug}/reports/export/jobs/${jobId}`)
            .then((r) => r.data),

    /** URL de download do resultado. */
    getExportDownloadUrl: (tenantSlug, jobId) =>
        `${api.defaults.baseURL}/tenants/${tenantSlug}/reports/export/jobs/${jobId}/download`,

    /** Listar jobs de exportação do tenant. */
    listExportJobs: (tenantSlug, params) =>
        api
            .get(`/tenants/${tenantSlug}/reports/export/jobs`, { params })
            .then((r) => r.data),

    /** Relatório de conversão. */
    getConversionReport: (tenantSlug, storeId, params) =>
        api
            .get(`/tenants/${tenantSlug}/stores/${storeId}/reports/conversion`, { params })
            .then((r) => r.data),

    /** Relatório de atendimentos. */
    getAttendanceReport: (tenantSlug, storeId, params) =>
        api
            .get(`/tenants/${tenantSlug}/stores/${storeId}/reports/attendances`, { params })
            .then((r) => r.data),

    /** Rankings. */
    getRankings: (tenantSlug, params) =>
        api
            .get(`/tenants/${tenantSlug}/rankings`, { params })
            .then((r) => r.data),
};
