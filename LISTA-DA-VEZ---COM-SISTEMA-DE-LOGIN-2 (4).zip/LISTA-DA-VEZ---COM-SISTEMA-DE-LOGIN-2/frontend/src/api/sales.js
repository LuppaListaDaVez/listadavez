/**
 * api/sales.js — Operações de vendas.
 */
import api from "../lib/api";

export const salesApi = {
    /** Listar vendas de uma loja com paginação e filtros. */
    list: (tenantSlug, storeId, params) =>
        api
            .get(`/tenants/${tenantSlug}/stores/${storeId}/sales`, { params })
            .then((r) => r.data),

    /** Criar venda manual. */
    create: (tenantSlug, storeId, payload) =>
        api
            .post(`/tenants/${tenantSlug}/stores/${storeId}/sales`, payload)
            .then((r) => r.data),

    /** Detalhe de uma venda. */
    get: (tenantSlug, saleId) =>
        api
            .get(`/tenants/${tenantSlug}/sales/${saleId}`)
            .then((r) => r.data),

    /** Cancelar venda. */
    cancel: (tenantSlug, saleId, reason) =>
        api
            .post(`/tenants/${tenantSlug}/sales/${saleId}/cancel`, { reason })
            .then((r) => r.data),

    /** Listar motivos de perda. */
    listLossReasons: (tenantSlug, params) =>
        api
            .get(`/tenants/${tenantSlug}/loss-reasons`, { params })
            .then((r) => r.data),

    /** Criar motivo de perda. */
    createLossReason: (tenantSlug, payload) =>
        api
            .post(`/tenants/${tenantSlug}/loss-reasons`, payload)
            .then((r) => r.data),

    /** Listar produtos. */
    listProducts: (tenantSlug, params) =>
        api
            .get(`/tenants/${tenantSlug}/products`, { params })
            .then((r) => r.data),
};
