/**
 * api/index.js — Re-exporta a instância axios base e helpers.
 *
 * Domínios disponíveis:
 *   import { queueApi } from "@/api/queue";
 *   import { salesApi } from "@/api/sales";
 *   import { notificationsApi } from "@/api/notifications";
 *   import { reportsApi } from "@/api/reports";
 *   import { authApi } from "@/api/auth";
 *   import { dashboardApi } from "@/api/dashboard";
 */
export { default as api, extractError, API_BASE } from "../lib/api";
export { queueApi } from "./queue";
export { salesApi } from "./sales";
export { notificationsApi } from "./notifications";
export { reportsApi } from "./reports";
export { authApi } from "./auth";
export { dashboardApi } from "./dashboard";
