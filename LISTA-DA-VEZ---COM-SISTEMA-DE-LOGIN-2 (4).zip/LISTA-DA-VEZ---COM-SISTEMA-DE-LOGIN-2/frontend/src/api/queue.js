/**
 * api/queue.js — Operações de fila (Lista da Vez).
 *
 * Todas as funções recebem { tenantSlug, storeId } como base
 * e retornam dados já desembrulhados do envelope Axios.
 */
import api from "../lib/api";

const base = (tenantSlug, storeId) =>
    `/tenants/${tenantSlug}/stores/${storeId}`;

export const queueApi = {
    /** Estado completo da fila de uma loja. */
    getState: (tenantSlug, storeId, queueId) =>
        api
            .get(`${base(tenantSlug, storeId)}/queue`, {
                params: queueId ? { queue_id: queueId } : undefined,
            })
            .then((r) => r.data),

    /** Lista de filas de uma loja. */
    listQueues: (tenantSlug, storeId) =>
        api.get(`${base(tenantSlug, storeId)}/queues`).then((r) => r.data),

    /** Criar fila customizada. */
    createQueue: (tenantSlug, storeId, payload) =>
        api.post(`${base(tenantSlug, storeId)}/queues`, payload).then((r) => r.data),

    /** Vendedor entra na fila. */
    join: (tenantSlug, storeId, sellerId, queueId) =>
        api
            .post(`${base(tenantSlug, storeId)}/queue/join`, {
                seller_id: sellerId,
                queue_id: queueId,
            })
            .then((r) => r.data),

    /** Vendedor sai da fila. */
    leave: (tenantSlug, storeId, sellerId, queueId) =>
        api
            .post(`${base(tenantSlug, storeId)}/queue/leave`, {
                seller_id: sellerId,
                queue_id: queueId,
            })
            .then((r) => r.data),

    /** Iniciar atendimento. */
    startAttendance: (tenantSlug, storeId, sellerId, queueId) =>
        api
            .post(`${base(tenantSlug, storeId)}/queue/start-attendance`, {
                seller_id: sellerId,
                queue_id: queueId,
            })
            .then((r) => r.data),

    /** Finalizar atendimento. */
    finishAttendance: (tenantSlug, storeId, payload, idempotencyKey) =>
        api
            .post(`${base(tenantSlug, storeId)}/queue/finish-attendance`, payload, {
                headers: idempotencyKey
                    ? { "Idempotency-Key": idempotencyKey }
                    : undefined,
            })
            .then((r) => r.data),

    /** Cancelar atendimento. */
    cancelAttendance: (tenantSlug, attendanceId, reason) =>
        api
            .post(`/tenants/${tenantSlug}/attendances/${attendanceId}/cancel`, {
                reason,
            })
            .then((r) => r.data),

    /** Atendimento rápido (sem fila). */
    quickAttendance: (tenantSlug, storeId, payload) =>
        api
            .post(`${base(tenantSlug, storeId)}/queue/quick-attendance`, payload)
            .then((r) => r.data),

    /** Marcar vendedor como ausente/pausa. */
    markAway: (tenantSlug, storeId, sellerId, newStatus, reason) =>
        api
            .post(`${base(tenantSlug, storeId)}/queue/mark-away`, {
                seller_id: sellerId,
                new_status: newStatus,
                reason,
            })
            .then((r) => r.data),

    /** Retornar vendedor a AVAILABLE. */
    returnSeller: (tenantSlug, storeId, sellerId, joinQueue, queueId, reason) =>
        api
            .post(`${base(tenantSlug, storeId)}/queue/return`, {
                seller_id: sellerId,
                join_queue: joinQueue,
                queue_id: queueId,
                reason,
            })
            .then((r) => r.data),

    /** Reordenar fila. */
    reorder: (tenantSlug, storeId, queueId, orderedSellerIds) =>
        api
            .patch(`${base(tenantSlug, storeId)}/queue/reorder`, {
                queue_id: queueId,
                ordered_seller_ids: orderedSellerIds,
            })
            .then((r) => r.data),

    /** Settings da fila/loja. */
    getSettings: (tenantSlug, storeId) =>
        api
            .get(`${base(tenantSlug, storeId)}/settings`)
            .then((r) => r.data),

    /** Listar atendimentos da loja com paginação. */
    listAttendances: (tenantSlug, storeId, params) =>
        api
            .get(`${base(tenantSlug, storeId)}/attendances`, { params })
            .then((r) => r.data),
};
