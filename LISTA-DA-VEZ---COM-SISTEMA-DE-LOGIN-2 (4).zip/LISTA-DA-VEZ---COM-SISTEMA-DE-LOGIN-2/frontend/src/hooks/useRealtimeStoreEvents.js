import { useCallback, useEffect, useRef, useState } from "react";

const BACKOFF_MS = [1000, 2000, 5000, 10000];
const PING_INTERVAL_MS = 30_000; // heartbeat para manter WS vivo em proxies

/**
 * Conecta ao WebSocket da loja e, em caso de falha, cai para polling.
 * onRefresh é chamado quando chega um evento relevante ou a cada tick de polling.
 * P1-Validação: polling pausado quando aba está oculta (Page Visibility API).
 */
export function useRealtimeStoreEvents({ tenantSlug, storeId, enabled, onRefresh }) {
    const [connectionStatus, setConnectionStatus] = useState("CONNECTING");
    const [lastEventAt, setLastEventAt] = useState(null);
    const [error, setError] = useState(null);

    const wsRef = useRef(null);
    const pollRef = useRef(null);
    const pingRef = useRef(null);
    const reconnectRef = useRef(null);
    const attemptRef = useRef(0);
    const closedRef = useRef(false);
    const onRefreshRef = useRef(onRefresh);
    onRefreshRef.current = onRefresh;

    const stopPolling = useCallback(() => {
        if (pollRef.current) { clearInterval(pollRef.current); pollRef.current = null; }
    }, []);

    const stopPing = useCallback(() => {
        if (pingRef.current) { clearInterval(pingRef.current); pingRef.current = null; }
    }, []);

    const startPing = useCallback((ws) => {
        if (pingRef.current) return;
        pingRef.current = setInterval(() => {
            if (ws && ws.readyState === WebSocket.OPEN) {
                ws.send("ping");
            }
        }, PING_INTERVAL_MS);
    }, []);

    const startPolling = useCallback(() => {
        if (pollRef.current) return;
        // Não iniciar se aba estiver oculta
        if (document.hidden) return;
        pollRef.current = setInterval(() => {
            // Pular tick se aba estiver oculta
            if (!document.hidden) onRefreshRef.current && onRefreshRef.current();
        }, 5000);
    }, []);

    const connect = useCallback(() => {
        if (!storeId) return;
        if (!enabled) {
            setConnectionStatus("DISABLED_BY_PLAN");
            startPolling();
            return;
        }
        const backend = process.env.REACT_APP_BACKEND_URL || "";
        const wsBase = backend.replace(/^http/, "ws"); // https->wss, http->ws
        const token = localStorage.getItem("access_token");
        if (!token) { setConnectionStatus("ERROR"); startPolling(); return; }
        setConnectionStatus("CONNECTING");
        let ws;
        try {
            ws = new WebSocket(`${wsBase}/api/ws/tenants/${tenantSlug}/stores/${storeId}?token=${token}`);
        } catch (e) {
            setError(e); setConnectionStatus("POLLING"); startPolling(); return;
        }
        wsRef.current = ws;

        ws.onopen = () => {
            attemptRef.current = 0;
            setError(null);
            setConnectionStatus("CONNECTED");
            stopPolling();
            startPing(ws);
        };
        ws.onmessage = (ev) => {
            try {
                const data = JSON.parse(ev.data);
                if (data.event_type === "connection.ready" || data.event_type === "pong") return;
                setLastEventAt(new Date());
                if (onRefreshRef.current) onRefreshRef.current();
            } catch { /* ignore malformed */ }
        };
        ws.onerror = () => { /* tratado no onclose */ };
        ws.onclose = (e) => {
            wsRef.current = null;
            stopPing();
            if (closedRef.current) return;
            if (e && e.code === 4403) {
                setConnectionStatus("DISABLED_BY_PLAN");
                startPolling();
                return;
            }
            setConnectionStatus("POLLING");
            startPolling();
            const delay = BACKOFF_MS[Math.min(attemptRef.current, BACKOFF_MS.length - 1)];
            attemptRef.current += 1;
            reconnectRef.current = setTimeout(() => { if (!closedRef.current) connect(); }, delay);
        };
    }, [storeId, enabled, tenantSlug, startPolling, stopPolling, startPing, stopPing]);

    // Page Visibility API: pausar polling e reconexão quando aba fica oculta
    useEffect(() => {
        const handleVisibilityChange = () => {
            if (document.hidden) {
                // Aba oculta: parar polling e reconnect timers
                stopPolling();
                if (reconnectRef.current) { clearTimeout(reconnectRef.current); reconnectRef.current = null; }
            } else {
                // Aba visível: reconectar ou retomar polling
                if (!wsRef.current || wsRef.current.readyState === WebSocket.CLOSED) {
                    attemptRef.current = 0;
                    connect();
                } else if (!pollRef.current) {
                    startPolling();
                }
                // Refresh imediato ao retornar para a aba
                onRefreshRef.current && onRefreshRef.current();
            }
        };
        document.addEventListener("visibilitychange", handleVisibilityChange);
        return () => document.removeEventListener("visibilitychange", handleVisibilityChange);
    }, [connect, startPolling, stopPolling]);

    useEffect(() => {
        closedRef.current = false;
        attemptRef.current = 0;
        connect();
        return () => {
            closedRef.current = true;
            stopPolling();
            stopPing();
            if (reconnectRef.current) clearTimeout(reconnectRef.current);
            if (wsRef.current) { try { wsRef.current.close(); } catch { /* noop */ } wsRef.current = null; }
        };
    }, [connect, stopPolling, stopPing]);

    const reconnect = useCallback(() => {
        attemptRef.current = 0;
        if (wsRef.current) { try { wsRef.current.close(); } catch { /* noop */ } }
        connect();
    }, [connect]);

    return {
        connectionStatus,
        isRealtimeActive: connectionStatus === "CONNECTED",
        isPolling: connectionStatus === "POLLING" || connectionStatus === "DISABLED_BY_PLAN",
        lastEventAt,
        error,
        reconnect,
    };
}

