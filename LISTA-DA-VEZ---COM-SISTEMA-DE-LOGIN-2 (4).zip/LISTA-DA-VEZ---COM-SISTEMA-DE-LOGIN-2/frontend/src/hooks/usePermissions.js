import { useTenant } from "@/context/TenantContext";

/**
 * usePermissions — hook central de permissões da Etapa 6.
 *
 * Lê permissões, features e stores acessíveis diretamente do TenantContext
 * (que é populado pelo endpoint GET /api/tenants/{slug}/context).
 */
export function usePermissions() {
    const { context } = useTenant();

    const role = context?.user_role || null;
    const permissions = context?.permissions || [];
    const features = context?.features || {};
    const accessibleStores = context?.accessible_store_ids || [];
    const stores = context?.stores || [];

    /** Verifica se o usuário tem pelo menos uma das permissões informadas. */
    const hasPermission = (...keys) => keys.some((k) => permissions.includes(k));

    /** Verifica se o usuário tem TODAS as permissões informadas. */
    const hasAllPermissions = (...keys) => keys.every((k) => permissions.includes(k));

    /** Verifica se uma feature está ativa. */
    const hasFeature = (key) => !!features[key];

    /** Verifica se o usuário tem acesso a uma store específica. */
    const canAccessStore = (storeId) => {
        if (role === "TENANT_ADMIN") return true;
        return accessibleStores.includes(storeId);
    };

    /**
     * Verifica se um item de menu deve ser exibido.
     * @param {string[]} requiredPermissions - Basta ter ao menos uma.
     * @param {string[]} requiredFeatures - Todas devem estar ativas.
     */
    const canSeeMenuItem = (requiredPermissions = [], requiredFeatures = []) => {
        const permOk = requiredPermissions.length === 0 || hasPermission(...requiredPermissions);
        const featOk = requiredFeatures.every((f) => hasFeature(f));
        return permOk && featOk;
    };

    /** Alias semântico — verifica se pode executar uma ação. */
    const canPerformAction = (permissionKey, opts = {}) => {
        if (!hasPermission(permissionKey)) return false;
        if (opts.storeId && !canAccessStore(opts.storeId)) return false;
        if (opts.feature && !hasFeature(opts.feature)) return false;
        return true;
    };

    return {
        role,
        permissions,
        features,
        accessibleStores,
        stores,
        hasPermission,
        hasAllPermissions,
        hasFeature,
        canAccessStore,
        canSeeMenuItem,
        canPerformAction,
    };
}
