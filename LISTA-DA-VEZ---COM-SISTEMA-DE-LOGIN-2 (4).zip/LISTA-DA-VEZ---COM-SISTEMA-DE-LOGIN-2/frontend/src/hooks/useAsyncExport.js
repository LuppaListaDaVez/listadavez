import { useState, useRef, useCallback } from "react";
import { reportsApi } from "@/api/reports";
import { toast } from "sonner";

const POLL_INTERVAL_MS = 2000;
const MAX_POLLS = 120; // 4 minutos máximo

/**
 * Hook para exportação assíncrona de relatórios CSV.
 *
 * @param {string} tenantSlug
 * @param {string} reportType - "attendances" | "conversion" | "loss-reasons" | ...
 * @param {object} filters - { date_start, date_end, store_id, seller_id, result }
 *
 * Retorna:
 *   exportState: "idle" | "creating" | "queued" | "processing" | "done" | "failed"
 *   startExport: () => void
 *   downloadUrl: string | null
 *   jobId: string | null
 */
export function useAsyncExport({ tenantSlug, reportType, filters = {} }) {
    const [exportState, setExportState] = useState("idle");
    const [jobId, setJobId] = useState(null);
    const [filename, setFilename] = useState(null);
    const pollRef = useRef(null);
    const pollCountRef = useRef(0);

    const stopPolling = useCallback(() => {
        if (pollRef.current) {
            clearInterval(pollRef.current);
            pollRef.current = null;
        }
        pollCountRef.current = 0;
    }, []);

    const startPolling = useCallback((id) => {
        stopPolling();
        pollCountRef.current = 0;

        pollRef.current = setInterval(async () => {
            pollCountRef.current += 1;
            if (pollCountRef.current > MAX_POLLS) {
                stopPolling();
                setExportState("failed");
                toast.error("Exportação demorou muito. Tente novamente.");
                return;
            }
            try {
                const job = await reportsApi.getExportJob(tenantSlug, id);
                if (job.status === "DONE") {
                    stopPolling();
                    setFilename(job.filename);
                    setExportState("done");
                    toast.success(`CSV pronto! Clique em "Baixar" para fazer o download.`);
                } else if (job.status === "FAILED") {
                    stopPolling();
                    setExportState("failed");
                    toast.error(`Exportação falhou: ${job.error || "erro desconhecido"}`);
                } else {
                    setExportState(job.status === "PROCESSING" ? "processing" : "queued");
                }
            } catch {
                // erro pontual de rede, continua tentando
            }
        }, POLL_INTERVAL_MS);
    }, [tenantSlug, stopPolling]);

    const startExport = useCallback(async () => {
        if (exportState === "creating" || exportState === "queued" || exportState === "processing") return;

        setExportState("creating");
        try {
            const job = await reportsApi.createExportJob(tenantSlug, reportType, {
                date_start: filters.date_start || null,
                date_end: filters.date_end || null,
                store_id: filters.store_id || null,
                seller_id: filters.seller_id || null,
                result: filters.result || null,
            });
            setJobId(job.id);
            setExportState("queued");
            toast.info("Exportação iniciada! Aguarde a geração do arquivo...");
            startPolling(job.id);
        } catch (err) {
            setExportState("failed");
            const msg = err?.response?.data?.detail || "Erro ao iniciar exportação.";
            toast.error(msg);
        }
    }, [tenantSlug, reportType, filters, exportState, startPolling]);

    const downloadFile = useCallback(async () => {
        if (!jobId) return;
        try {
            const base = process.env.REACT_APP_BACKEND_URL;
            const token = localStorage.getItem("access_token");
            const res = await fetch(
                `${base}/api/tenants/${tenantSlug}/reports/export/jobs/${jobId}/download`,
                { headers: { Authorization: `Bearer ${token}` } }
            );
            if (!res.ok) { toast.error("Erro ao baixar arquivo."); return; }
            const blob = await res.blob();
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = filename || `export_${Date.now()}.csv`;
            a.click();
            URL.revokeObjectURL(url);
        } catch {
            toast.error("Erro ao baixar arquivo.");
        }
    }, [jobId, tenantSlug, filename]);

    const reset = useCallback(() => {
        stopPolling();
        setExportState("idle");
        setJobId(null);
        setFilename(null);
    }, [stopPolling]);

    return {
        exportState,
        jobId,
        filename,
        startExport,
        downloadFile,
        reset,
        isExporting: ["creating", "queued", "processing"].includes(exportState),
    };
}
