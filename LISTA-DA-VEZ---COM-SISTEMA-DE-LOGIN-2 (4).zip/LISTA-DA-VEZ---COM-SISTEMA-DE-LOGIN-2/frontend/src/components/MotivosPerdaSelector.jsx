import React, { useCallback, useEffect, useMemo, useState } from "react";
import api from "@/lib/api";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Label } from "@/components/ui/label";
import {
    Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { AlertTriangle } from "lucide-react";

const VAZIO = "__vazio__";

export function useMotivosPerdaOpcoes(tenantSlug, enabled = true) {
    const [estrutura, setEstrutura] = useState({ hierarquia_ativa: false, grupos: [] });
    const [loading, setLoading] = useState(false);

    const carregar = useCallback(async () => {
        if (!tenantSlug || !enabled) return;
        setLoading(true);
        try {
            const { data } = await api.get(`/tenants/${tenantSlug}/motivos-perda/opcoes`);
            setEstrutura(data || { hierarquia_ativa: false, grupos: [] });
        } catch {
            setEstrutura({ hierarquia_ativa: false, grupos: [] });
        } finally {
            setLoading(false);
        }
    }, [tenantSlug, enabled]);

    useEffect(() => { carregar(); }, [carregar]);
    return { estrutura, loading, carregar };
}

export function encontrarMotivoPerda(estrutura, value = {}) {
    const grupo = (estrutura?.grupos || []).find((g) => g.identificador === value.grupo_motivo_perda_id);
    const subgrupo = (grupo?.subgrupos || []).find((s) => s.identificador === value.subgrupo_motivo_perda_id);
    const motivo = (subgrupo?.motivos || []).find((m) => m.identificador === value.motivo_perda_id);
    return { grupo, subgrupo, motivo };
}

export function MotivosPerdaSelector({ estrutura, value, onChange, prefix = "motivo-perda" }) {
    const atual = useMemo(() => value || {}, [value]);
    const { grupo, subgrupo, motivo } = useMemo(() => encontrarMotivoPerda(estrutura, atual), [estrutura, atual]);
    const subgrupos = grupo?.subgrupos || [];
    const motivos = subgrupo?.motivos || [];
    const limite = motivo?.limite_descricao_complementar || 300;
    const descricao = atual.descricao_complementar || "";

    const alterarGrupo = (id) => onChange({
        grupo_motivo_perda_id: id === VAZIO ? "" : id,
        subgrupo_motivo_perda_id: "",
        motivo_perda_id: "",
        descricao_complementar: "",
    });

    const alterarSubgrupo = (id) => onChange({
        ...atual,
        subgrupo_motivo_perda_id: id === VAZIO ? "" : id,
        motivo_perda_id: "",
        descricao_complementar: "",
    });

    const alterarMotivo = (id) => onChange({
        ...atual,
        motivo_perda_id: id === VAZIO ? "" : id,
        descricao_complementar: "",
    });

    if (!estrutura?.hierarquia_ativa) {
        return (
            <Alert data-testid={`${prefix}-sem-configuracao-alerta`}>
                <AlertTriangle size={14} />
                <AlertDescription>
                    Cadastre ao menos um grupo, um subgrupo e um motivo ativo para utilizar a classificação de perdas.
                </AlertDescription>
            </Alert>
        );
    }

    return (
        <div className="space-y-3" data-testid={`${prefix}-selector`}>
            <div className="space-y-1.5">
                <Label>Grupo</Label>
                <Select value={atual.grupo_motivo_perda_id || VAZIO} onValueChange={alterarGrupo}>
                    <SelectTrigger data-testid={`${prefix}-grupo-select`}>
                        <SelectValue placeholder="Selecione o grupo" />
                    </SelectTrigger>
                    <SelectContent className="max-h-72">
                        <SelectItem value={VAZIO} data-testid={`${prefix}-grupo-opcao-vazia`}>Selecione o grupo</SelectItem>
                        {(estrutura.grupos || []).map((g) => (
                            <SelectItem key={g.identificador} value={g.identificador} data-testid={`${prefix}-grupo-opcao-${g.identificador}`}>{g.nome}</SelectItem>
                        ))}
                    </SelectContent>
                </Select>
            </div>

            <div className="space-y-1.5">
                <Label>Subgrupo</Label>
                <Select value={atual.subgrupo_motivo_perda_id || VAZIO} onValueChange={alterarSubgrupo} disabled={!grupo}>
                    <SelectTrigger data-testid={`${prefix}-subgrupo-select`}>
                        <SelectValue placeholder="Selecione o subgrupo" />
                    </SelectTrigger>
                    <SelectContent className="max-h-72">
                        <SelectItem value={VAZIO} data-testid={`${prefix}-subgrupo-opcao-vazia`}>Selecione o subgrupo</SelectItem>
                        {subgrupos.map((s) => (
                            <SelectItem key={s.identificador} value={s.identificador} data-testid={`${prefix}-subgrupo-opcao-${s.identificador}`}>{s.nome}</SelectItem>
                        ))}
                    </SelectContent>
                </Select>
            </div>

            <div className="space-y-1.5">
                <Label>Motivo</Label>
                <Select value={atual.motivo_perda_id || VAZIO} onValueChange={alterarMotivo} disabled={!subgrupo}>
                    <SelectTrigger data-testid={`${prefix}-motivo-select`}>
                        <SelectValue placeholder="Selecione o motivo" />
                    </SelectTrigger>
                    <SelectContent className="max-h-72">
                        <SelectItem value={VAZIO} data-testid={`${prefix}-motivo-opcao-vazia`}>Selecione o motivo</SelectItem>
                        {motivos.map((m) => (
                            <SelectItem key={m.identificador} value={m.identificador} data-testid={`${prefix}-motivo-opcao-${m.identificador}`}>{m.nome}</SelectItem>
                        ))}
                    </SelectContent>
                </Select>
            </div>

            {motivo?.exige_descricao_complementar && (
                <div className="space-y-1.5">
                    <div className="flex items-center justify-between gap-3">
                        <Label>Descrição complementar</Label>
                        <span className="text-xs text-muted-foreground tabular-nums" data-testid={`${prefix}-descricao-contador`}>
                            {descricao.trim().length}/{limite}
                        </span>
                    </div>
                    <Textarea
                        value={descricao}
                        maxLength={limite}
                        onChange={(e) => onChange({ ...atual, descricao_complementar: e.target.value })}
                        placeholder="Descreva o contexto da perda"
                        data-testid={`${prefix}-descricao-input`}
                    />
                </div>
            )}
        </div>
    );
}