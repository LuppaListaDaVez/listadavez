/**
 * RealtimeToastManager — mostra toasts para eventos motivacionais em tempo real.
 * Notificações pessoais já são tratadas no NotificationContext.
 * Aqui: apenas motivation.event_created (eventos públicos).
 */
import { useEffect, useRef } from "react";
import { toast } from "sonner";
import { useRealtimeTenant } from "@/context/RealtimeTenantContext";
import { usePermissions } from "@/hooks/usePermissions";

const EVENT_LABELS = {
    GOAL_DAILY_ACHIEVED:  "🏆 Meta diária batida!",
    GOAL_WEEKLY_ACHIEVED: "🏆 Meta semanal batida!",
    GOAL_MONTHLY_ACHIEVED:"🏆 Meta mensal batida!",
    GOAL_EXCEEDED:        "🚀 Meta superada!",
    BADGE_EARNED:         "🎖️ Nova conquista!",
    AWARD:                "🥇 Premiação!",
    RECOGNITION:          "⭐ Reconhecimento!",
    RANKING_TOP_1:        "🥇 Novo 1° lugar!",
    RANKING_TOP_3:        "🥈 Top 3!",
    RANKING_TOP_10:       "🎯 Top 10!",
    RANKING_POSITION_UP:  "📈 Subiu no ranking!",
    PERSONAL_RECORD:      "🔥 Recorde pessoal!",
    COMPANY_RECORD:       "🔥 Recorde da empresa!",
    CAMPAIGN_STARTED:     "🎯 Nova campanha!",
    CAMPAIGN_UPDATED:     "📢 Campanha atualizada!",
    CAMPAIGN_ENDED:       "🏁 Campanha encerrada!",
    PROACTIVE_SALE_CREATED: "⚡ Venda proativa!",
    FIRST_PROACTIVE_SALE: "⚡ Primeira venda proativa!",
    TEAM_GOAL_ACHIEVED:   "👥 Meta de equipe!",
    CONVERSION_HIGHLIGHT: "📊 Destaque em conversão!",
    ADMIN_ANNOUNCEMENT:   "📢 Aviso da administração",
    GENERAL_ANNOUNCEMENT: "📣 Comunicado geral",
    SCHEDULED_MESSAGE:    "💬 Mensagem motivacional",
};

export function RealtimeToastManager() {
    const { subscribe } = useRealtimeTenant();
    const { hasFeature } = usePermissions();
    const seenRef = useRef(new Set());

    const enabled = hasFeature("motivacao_publica");

    useEffect(() => {
        if (!enabled) return;

        const unsub = subscribe("motivation.event_created", (event) => {
            const p = event.payload;
            if (!p?.id) return;
            if (seenRef.current.has(p.id)) return;
            seenRef.current.add(p.id);

            const label = EVENT_LABELS[p.event_type] || "Destaque!";
            toast(p.title || label, {
                description: p.message || "",
                duration: 7000,
                position: "top-right",
            });
        });

        return unsub;
    }, [subscribe, enabled]);

    return null;
}
