/**
 * GoalCelebrationBanner — Banner de "Meta Atingida!" com confetti
 * Aparece na QueuePage quando o vendedor bate a meta via WebSocket.
 * Persiste via sessionStorage durante o dia (sem confetti no reload).
 */
import { useEffect, useRef, useState } from "react";
import { Trophy, X } from "lucide-react";
import { useRealtimeTenant } from "@/context/RealtimeTenantContext";
import { useAuth } from "@/context/AuthContext";

const SESSION_KEY_PREFIX = "goal_achieved_";

function getTodayKey(userId) {
    const today = new Date().toISOString().slice(0, 10);
    return `${SESSION_KEY_PREFIX}${userId}_${today}`;
}

export function GoalCelebrationBanner() {
    const { user } = useAuth();
    const { subscribe } = useRealtimeTenant();
    const [celebration, setCelebration] = useState(null); // { sales_count, goal_target, goal_name } | null
    const [dismissed, setDismissed] = useState(false);
    const firedRef = useRef(false);

    // Restore from sessionStorage on mount (banner only, no confetti)
    useEffect(() => {
        if (!user?.id) return;
        try {
            const stored = sessionStorage.getItem(getTodayKey(user.id));
            if (stored) {
                const data = JSON.parse(stored);
                if (!data.dismissed) setCelebration(data);
            }
        } catch { /* ignore */ }
    }, [user?.id]);

    // Subscribe to real-time GOAL_ACHIEVED event
    useEffect(() => {
        const unsub = subscribe("GOAL_ACHIEVED", async (event) => {
            const p = event.payload || {};
            if (firedRef.current) return;
            firedRef.current = true;

            const data = {
                sales_count: p.sales_count,
                goal_target: p.goal_target,
                goal_name: p.goal_name || "Meta diária",
                dismissed: false,
            };

            setCelebration(data);
            setDismissed(false);

            // Save to sessionStorage
            if (user?.id) {
                try { sessionStorage.setItem(getTodayKey(user.id), JSON.stringify(data)); } catch { /* ignore */ }
            }

            // Fire confetti
            try {
                const confetti = (await import("canvas-confetti")).default;
                const style = getComputedStyle(document.documentElement);
                const primary = `hsl(${style.getPropertyValue("--primary").trim()})`;
                const chart3  = `hsl(${style.getPropertyValue("--chart-3").trim()})`;
                const chart1  = `hsl(${style.getPropertyValue("--chart-1").trim()})`;
                confetti({ particleCount: 130, spread: 90, origin: { y: 0.35 }, colors: [primary, chart3, chart1], scalar: 1.2 });
                setTimeout(() => {
                    confetti({ particleCount: 60, spread: 50, origin: { x: 0.1, y: 0.5 }, colors: [chart3, primary] });
                    confetti({ particleCount: 60, spread: 50, origin: { x: 0.9, y: 0.5 }, colors: [chart1, primary] });
                }, 350);
            } catch { /* confetti is non-critical */ }
        });
        return unsub;
    }, [subscribe, user?.id]);

    const handleDismiss = () => {
        setDismissed(true);
        if (user?.id && celebration) {
            try { sessionStorage.setItem(getTodayKey(user.id), JSON.stringify({ ...celebration, dismissed: true })); } catch { /* ignore */ }
        }
    };

    if (!celebration || dismissed) return null;

    return (
        <div
            data-testid="goal-celebration-banner"
            className="relative flex items-center gap-3 px-5 py-3.5 mb-5 rounded-xl border border-primary/40 bg-primary/8 animate-in fade-in-0 slide-in-from-top-3 duration-500"
        >
            {/* Glow */}
            <div className="absolute inset-0 rounded-xl pointer-events-none bg-primary/5" />

            <div className="flex-shrink-0 w-9 h-9 rounded-full bg-primary/15 flex items-center justify-center">
                <Trophy size={18} className="text-primary" strokeWidth={2} />
            </div>

            <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-primary leading-tight">
                    Meta atingida! Parabéns!
                </p>
                <p className="text-xs text-foreground/70 mt-0.5">
                    {celebration.sales_count} {celebration.sales_count === 1 ? "venda" : "vendas"} hoje
                    {celebration.goal_name && ` · ${celebration.goal_name}`}
                </p>
            </div>

            <button
                onClick={handleDismiss}
                className="flex-shrink-0 p-1.5 rounded-md hover:bg-primary/15 transition-colors duration-150 text-primary/60 hover:text-primary"
                aria-label="Fechar celebração"
                data-testid="goal-celebration-dismiss"
            >
                <X size={14} />
            </button>
        </div>
    );
}
