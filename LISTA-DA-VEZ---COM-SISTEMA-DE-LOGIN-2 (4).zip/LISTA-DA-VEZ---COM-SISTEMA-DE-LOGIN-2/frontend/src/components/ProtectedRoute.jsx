import React from "react";
import { Navigate, useLocation, useParams } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { useTenant } from "@/context/TenantContext";
import { usePermissions } from "@/hooks/usePermissions";
import AccessDenied from "@/components/AccessDenied";

export function RequireAuth({ children, redirectTo }) {
    const { user, loading } = useAuth();
    const location = useLocation();
    if (loading) {
        return (
            <div className="flex h-screen items-center justify-center bg-background">
                <p className="text-sm text-muted-foreground">Carregando…</p>
            </div>
        );
    }
    if (!user) {
        return <Navigate to={redirectTo} replace state={{ from: location }} />;
    }
    return children;
}

export function RequireSuperAdmin({ children }) {
    const { user, loading } = useAuth();
    if (loading) {
        return (
            <div className="flex h-screen items-center justify-center bg-background">
                <p className="text-sm text-muted-foreground">Carregando…</p>
            </div>
        );
    }
    if (!user) return <Navigate to="/super-admin/login" replace />;
    if (!user.is_super_admin) return <Navigate to="/" replace />;
    return children;
}

export function RequireTenantAuth({ children }) {
    const { tenantSlug } = useParams();
    return <RequireAuth redirectTo={`/${tenantSlug}/login`}>{children}</RequireAuth>;
}

/**
 * ProtectedTenantRoute — protege rotas por permissão e/ou feature flag.
 *
 * @param {string[]} permissions - basta ter ao menos UMA.
 * @param {string[]} features - TODAS devem estar ativas.
 * @param {React.ReactNode} children
 */
export function ProtectedTenantRoute({ permissions = [], features = [], children }) {
    const { context, loading } = useTenant();
    const { hasPermission, hasFeature } = usePermissions();

    if (loading) {
        return (
            <div className="flex items-center justify-center min-h-[60vh]">
                <p className="text-sm text-muted-foreground">Verificando acesso…</p>
            </div>
        );
    }

    // Context ainda não carregado (edge case no first render)
    if (!context) return null;

    // Verifica features obrigatórias
    if (features.length > 0 && !features.every((f) => hasFeature(f))) {
        return <AccessDenied message="Esta funcionalidade não está disponível no seu plano." />;
    }

    // Verifica permissões (basta ter ao menos uma)
    if (permissions.length > 0 && !permissions.some((p) => hasPermission(p))) {
        return <AccessDenied />;
    }

    return children;
}
