import React from "react";
import { Button } from "@/components/ui/button";
import { Download, Loader2, CheckCircle, AlertCircle, XCircle } from "lucide-react";
import { useAsyncExport } from "@/hooks/useAsyncExport";

const STATE_CONFIG = {
    idle:       { label: "Exportar CSV",   icon: Download,     variant: "outline",    disabled: false },
    creating:   { label: "Iniciando...",   icon: Loader2,      variant: "outline",    disabled: true,  spin: true },
    queued:     { label: "Na fila...",     icon: Loader2,      variant: "outline",    disabled: true,  spin: true },
    processing: { label: "Gerando CSV...", icon: Loader2,      variant: "outline",    disabled: true,  spin: true },
    done:       { label: "Baixar CSV",     icon: CheckCircle,  variant: "default",    disabled: false },
    failed:     { label: "Tentar novamente", icon: XCircle,   variant: "destructive", disabled: false },
};

/**
 * Botão de exportação assíncrona de CSV.
 *
 * Props:
 *   tenantSlug, reportType, filters, size (padrão "sm")
 */
export function AsyncExportButton({ tenantSlug, reportType, filters, size = "sm", "data-testid": testId }) {
    const { exportState, startExport, downloadFile, reset } = useAsyncExport({
        tenantSlug,
        reportType,
        filters,
    });

    const cfg = STATE_CONFIG[exportState] || STATE_CONFIG.idle;
    const Icon = cfg.icon;

    const handleClick = () => {
        if (exportState === "done") {
            downloadFile();
            // Reset after download so user can export again
            setTimeout(reset, 1500);
        } else if (exportState === "failed") {
            reset();
        } else {
            startExport();
        }
    };

    return (
        <Button
            variant={cfg.variant}
            size={size}
            onClick={handleClick}
            disabled={cfg.disabled}
            data-testid={testId || "btn-async-export-csv"}
            className="min-w-[130px] justify-center"
        >
            <Icon
                size={13}
                strokeWidth={1.5}
                className={`mr-1.5 shrink-0 ${cfg.spin ? "animate-spin" : ""}`}
            />
            {cfg.label}
        </Button>
    );
}
