import React from "react";
import { useTenant } from "@/context/TenantContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import { SlidersHorizontal, X } from "lucide-react";

const RESULT_OPTIONS = [
    { value: "SALE", label: "Sucesso" },
    { value: "NO_SALE", label: "Não sucesso" },
    { value: "FOLLOW_UP", label: "Retornará" },
    { value: "INVALID", label: "Inválido" },
];

/**
 * ReportFilters — barra de filtros reutilizável para relatórios.
 *
 * Props:
 *  filters: { date_start, date_end, store_id, seller_id, result }
 *  onChange(filters): callback ao mudar qualquer filtro
 *  showResult: boolean (exibir filtro de resultado)
 *  showSeller: boolean (exibir filtro de vendedor — requer sellers[])
 *  sellers: array de { id, name } para popular o select
 */
export function ReportFilters({
    filters = {},
    onChange,
    showResult = false,
    showSeller = false,
    sellers = [],
}) {
    const { context } = useTenant();
    const stores = context?.stores || [];

    const set = (key, value) => onChange({ ...filters, [key]: value || undefined });

    const clear = () =>
        onChange({ date_start: undefined, date_end: undefined, store_id: undefined, seller_id: undefined, result: undefined });

    const hasAny = Object.values(filters).some(Boolean);

    return (
        <div className="bg-card border border-border/60 rounded-md p-4 mb-6">
            <div className="flex items-center gap-2 mb-3">
                <SlidersHorizontal size={14} className="text-muted-foreground" strokeWidth={1.5} />
                <span className="text-xs uppercase tracking-[0.12em] text-muted-foreground font-medium">Filtros</span>
                {hasAny && (
                    <button
                        onClick={clear}
                        className="ml-auto flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors"
                        data-testid="filters-clear"
                    >
                        <X size={12} /> Limpar
                    </button>
                )}
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3 items-end">
                <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">Data início</Label>
                    <Input
                        type="date"
                        value={filters.date_start || ""}
                        onChange={(e) => set("date_start", e.target.value)}
                        className="text-sm h-8"
                        data-testid="filter-date-start"
                    />
                </div>
                <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">Data fim</Label>
                    <Input
                        type="date"
                        value={filters.date_end || ""}
                        onChange={(e) => set("date_end", e.target.value)}
                        className="text-sm h-8"
                        data-testid="filter-date-end"
                    />
                </div>
                {stores.length > 1 && (
                    <div className="space-y-1">
                        <Label className="text-xs text-muted-foreground">Unidade</Label>
                        <Select value={filters.store_id || "__all__"} onValueChange={(v) => set("store_id", v === "__all__" ? "" : v)}>
                            <SelectTrigger className="h-8 text-sm" data-testid="filter-store">
                                <SelectValue placeholder="Todas" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="__all__">Todas as unidades</SelectItem>
                                {stores.map((s) => (
                                    <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>
                )}
                {showSeller && sellers.length > 0 && (
                    <div className="space-y-1">
                        <Label className="text-xs text-muted-foreground">Vendedor</Label>
                        <Select value={filters.seller_id || "__all__"} onValueChange={(v) => set("seller_id", v === "__all__" ? "" : v)}>
                            <SelectTrigger className="h-8 text-sm" data-testid="filter-seller">
                                <SelectValue placeholder="Todos" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="__all__">Todos os vendedores</SelectItem>
                                {sellers.map((s) => (
                                    <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>
                )}
                {showResult && (
                    <div className="space-y-1">
                        <Label className="text-xs text-muted-foreground">Resultado</Label>
                        <Select value={filters.result || "__all__"} onValueChange={(v) => set("result", v === "__all__" ? "" : v)}>
                            <SelectTrigger className="h-8 text-sm" data-testid="filter-result">
                                <SelectValue placeholder="Todos" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="__all__">Todos</SelectItem>
                                {RESULT_OPTIONS.map((o) => (
                                    <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>
                )}
            </div>
        </div>
    );
}
