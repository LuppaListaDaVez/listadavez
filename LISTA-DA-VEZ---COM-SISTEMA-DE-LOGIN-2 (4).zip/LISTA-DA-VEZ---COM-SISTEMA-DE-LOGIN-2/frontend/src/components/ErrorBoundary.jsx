import React from "react";

/**
 * ErrorBoundary global — captura crashes de componentes React
 * e exibe UI de fallback amigável em vez de tela branca.
 * P3 — TD-015
 */
export class ErrorBoundary extends React.Component {
    constructor(props) {
        super(props);
        this.state = { hasError: false, error: null };
    }

    static getDerivedStateFromError(error) {
        return { hasError: true, error };
    }

    componentDidCatch(error, info) {
        // Log mínimo sem expor dados sensíveis ao console de produção
        if (process.env.NODE_ENV === "development") {
            console.error("[ErrorBoundary]", error, info.componentStack);
        }
    }

    render() {
        if (this.state.hasError) {
            return (
                <div
                    style={{
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center",
                        justifyContent: "center",
                        minHeight: "100vh",
                        padding: "2rem",
                        fontFamily: "system-ui, sans-serif",
                        background: "hsl(var(--background))",
                        color: "hsl(var(--foreground))",
                        textAlign: "center",
                    }}
                >
                    <div style={{ fontSize: "3rem", marginBottom: "1rem" }}>⚠</div>
                    <h1 style={{ fontSize: "1.5rem", fontWeight: 700, marginBottom: "0.5rem" }}>
                        Algo deu errado
                    </h1>
                    <p style={{ color: "hsl(var(--muted-foreground))", marginBottom: "2rem", maxWidth: "400px" }}>
                        Ocorreu um erro inesperado. Tente recarregar a página. Se o problema persistir,
                        entre em contato com o suporte.
                    </p>
                    <button
                        onClick={() => window.location.reload()}
                        style={{
                            padding: "0.75rem 2rem",
                            borderRadius: "0.5rem",
                            background: "hsl(var(--primary))",
                            color: "hsl(var(--primary-foreground))",
                            border: "none",
                            cursor: "pointer",
                            fontSize: "1rem",
                            fontWeight: 600,
                        }}
                    >
                        Recarregar página
                    </button>
                </div>
            );
        }
        return this.props.children;
    }
}
