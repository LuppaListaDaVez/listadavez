import React, { useState, useEffect } from "react";
import { NavLink, Outlet, useNavigate, useParams, Navigate, Link } from "react-router-dom";
import {
    LayoutDashboard, Store, Users, Settings, LogOut, UserCheck,
    UsersRound, XCircle, ListOrdered, ClipboardList, Package, ShoppingCart,
    BarChart2, Target, Trophy, Star, Activity, MessageSquare, Bell, Zap,
    AlertTriangle, Cpu, Sparkles, Shield, User, Menu, X, ChevronDown, Sun, Moon,
} from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { useTenant } from "@/context/TenantContext";
import { usePermissions } from "@/hooks/usePermissions";
import { NotificationProvider } from "@/context/NotificationContext";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { NotificationBell } from "@/components/NotificationBell";
import { RealtimeToastManager } from "@/components/RealtimeToastManager";
import { RealtimeTenantProvider } from "@/context/RealtimeTenantContext";
import ImpersonationBanner from "@/components/ImpersonationBanner";
import {
    DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel,
    DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";

// ─── Logo component ─────────────────────────────────────────────────────────────
function LuppaLogo({ height = 26, mode = "dark" }) {
    // mode: "dark" = logo verde sobre fundo claro | "light" = logo branca sobre fundo escuro
    const style = mode === "light"
        ? { filter: "brightness(0) invert(1)", height }
        : { mixBlendMode: "darken", height };
    return (
        <img
            src="/luppa-logo.webp"
            alt="Luppa"
            style={style}
            draggable="false"
        />
    );
}

// ─── Grupos de menu ────────────────────────────────────────────────────────────
const MENU_ITEMS = [
    { to: "dashboard",             label: "Painel",              icon: LayoutDashboard, testId: "nav-t-dashboard",        permissions: ["dashboard.view_store","dashboard.view_tenant"], features: [] },
    { to: "queue",                 label: "Lista da Vez",         icon: ListOrdered,     testId: "nav-t-queue",            permissions: ["queue.view"], features: ["lista_da_vez"] },
    { to: "attendances",           label: "Atendimentos",        icon: ClipboardList,   testId: "nav-t-attendances",      permissions: ["attendances.view_self","attendances.view_store","attendances.view_tenant"], features: ["lista_da_vez"] },
    { to: "sales",                 label: "Vendas",              icon: ShoppingCart,    testId: "nav-t-sales",            permissions: ["sales.view_self","sales.view_store","sales.view_tenant"], features: ["vendas_detalhadas"] },
    { to: "products",              label: "Produtos",            icon: Package,         testId: "nav-t-products",         permissions: ["products.view"], features: ["produtos"] },
    { to: "goals",                 label: "Metas",               icon: Target,          testId: "nav-t-goals",            permissions: ["goals.view_self","goals.view_store","goals.view_tenant"], features: ["metas"] },
    { to: "rankings",              label: "Rankings",            icon: Trophy,          testId: "nav-t-rankings",         permissions: ["rankings.view_self","rankings.view_store","rankings.view_tenant"], features: ["rankings"] },
    { to: "my-performance",        label: "Meu Painel",          icon: Activity,        testId: "nav-t-myperformance",    permissions: ["performance.view_self","performance.view_store"] },
    { to: "gamification",          label: "Conquistas",          icon: Star,            testId: "nav-t-gamification",     permissions: ["gamification.view_self","gamification.view_store","gamification.view_tenant"], features: ["gamificacao"] },
    { to: "feedbacks",             label: "Feedbacks",           icon: MessageSquare,   testId: "nav-t-feedbacks",        permissions: ["feedbacks.view_self","feedbacks.view_store","feedbacks.view_tenant"], features: ["feedbacks"] },
    { to: "reports",               label: "Relatórios",          icon: BarChart2,       testId: "nav-t-reports",          permissions: ["reports.view_self","reports.view_store","reports.view_tenant"], features: ["relatorios_basicos"] },
    { to: "reports/proactivity",   label: "Rel. Proatividade",   icon: Zap,             testId: "nav-t-proactivity-report", permissions: ["proactivity.reports_view"], features: ["abordagem_proativa"] },
    { to: "stores",                label: "Unidades",            icon: Store,           testId: "nav-t-stores",           permissions: ["stores.create"], features: [] },
    { to: "users",                 label: "Usuários",            icon: Users,           testId: "nav-t-users",            permissions: ["users.view"], features: [] },
    { to: "teams",                 label: "Equipes",             icon: UsersRound,      testId: "nav-t-teams",            permissions: ["teams.view"], features: ["multi_equipes"] },
    { to: "sellers",               label: "Vendedores",          icon: UserCheck,       testId: "nav-t-sellers",          permissions: ["sellers.view"], features: [] },
    { to: "loss-reasons",          label: "Motivos de perda",    icon: XCircle,         testId: "nav-t-loss",             permissions: ["loss_reasons.view"], features: ["motivos_nao_venda"] },
    { to: "proactivity",           label: "Abordagem Proativa",  icon: Zap,             testId: "nav-t-proactivity",      permissions: ["proactivity.view_store","proactivity.view_tenant","proactivity.create_any"], features: ["abordagem_proativa"] },
    { to: "my-proactivity",        label: "Minhas abordagens",   icon: Activity,        testId: "nav-t-my-proactivity",   permissions: ["proactivity.view_self"], features: ["abordagem_proativa"] },
    { to: "motivation-feed",       label: "Feed Motivacional",   icon: Sparkles,        testId: "nav-t-motivation-feed",  permissions: ["motivation_events.view"], features: ["motivacao_publica"] },
    { to: "alerts",                label: "Alertas",             icon: AlertTriangle,   testId: "nav-t-alerts",           permissions: ["alerts.view_self","alerts.view_store","alerts.view_tenant"], features: ["alertas_inteligentes"] },
    { to: "automation-rules",      label: "Automações",          icon: Cpu,             testId: "nav-t-automation",       permissions: ["automation.view"], features: ["automacoes"] },
    { to: "notifications/preferences", label: "Notificações",   icon: Bell,            testId: "nav-t-notif-prefs",      permissions: ["notifications.preferences_update_self","notifications.preferences_update_any"], features: ["preferencias_notificacao"] },
    { to: "backups",               label: "Backups",             icon: Sparkles,        testId: "nav-t-backups",          permissions: ["backup.view"], features: ["backup_restore"] },
    { to: "settings",              label: "Configurações",        icon: Settings,        testId: "nav-t-settings",         permissions: ["tenant.settings.view","tenant.settings.update"], features: [] },
];

const PRIMARY_ITEMS = ["dashboard","queue","attendances","sales"];
const SECONDARY_GROUPS = [
    { label: "Desempenho",    items: ["my-performance","goals","rankings","gamification","feedbacks"] },
    { label: "Relatórios",   items: ["reports","reports/proactivity"] },
    { label: "Equipes",      items: ["users","sellers","teams","stores"] },
    { label: "Operações",    items: ["proactivity","my-proactivity","motivation-feed","products","alerts","automation-rules"] },
    { label: "Configurar",   items: ["settings","loss-reasons","notifications/preferences","backups"] },
];

const ROLE_LABELS = {
    TENANT_ADMIN: "Administrador", REGIONAL_MANAGER: "Ger. Regional",
    STORE_MANAGER: "Gerente de Loja", SUPERVISOR: "Supervisor",
    SELLER: "Vendedor", SUPER_ADMIN: "Super Admin",
};

// ─── Theme Toggle ───────────────────────────────────────────────────────────
function ThemeToggle() {
    const [dark, setDark] = useState(() => document.documentElement.classList.contains("dark"));
    const toggle = () => {
        const next = !dark;
        setDark(next);
        document.documentElement.classList.toggle("dark", next);
        try { localStorage.setItem("luppa.theme", next ? "dark" : "light"); } catch (e) {}
    };
    return (
        <button
            onClick={toggle}
            aria-label={dark ? "Ativar modo claro" : "Ativar modo escuro"}
            className="h-8 w-8 flex items-center justify-center rounded-[6px] text-[#3A3A38] hover:bg-[#E0E0DC] transition-colors duration-150">
            {dark ? <Sun size={15} strokeWidth={2} /> : <Moon size={15} strokeWidth={2} />}
        </button>
    );
}

export default function TenantLayout() {
    const { tenantSlug } = useParams();
    const { user, logout } = useAuth();
    const { context, loading, error } = useTenant();
    const { canSeeMenuItem } = usePermissions();
    const nav = useNavigate();
    const [mobileOpen, setMobileOpen] = useState(false);

    useEffect(() => { setMobileOpen(false); }, []);

    if (loading) {
        return (
            <div className="flex h-screen items-center justify-center" style={{ background: "var(--luppa-bg)" }}>
                <div className="flex flex-col items-center gap-4">
                    <LuppaLogo height={32} mode="dark" />
                    <div className="h-0.5 w-20 bg-[#006A4F]/20 rounded-full overflow-hidden">
                        <div className="h-full bg-[#006A4F] rounded-full animate-[shimmer_1.2s_ease-in-out_infinite] w-1/2" />
                    </div>
                </div>
            </div>
        );
    }

    if (error === "not_found") return <NotFoundTenant />;
    if (error === "forbidden") return <NoAccessTenant slug={tenantSlug} />;
    if (error === "unauthorized") return <Navigate to={`/${tenantSlug}/login`} replace />;
    if (error === "session_mismatch") return <Navigate to={`/${tenantSlug}/login?reason=session_mismatch`} replace />;
    if (!context) return null;

    const itemByTo = Object.fromEntries(MENU_ITEMS.map(i => [i.to, i]));
    const visibleItems = MENU_ITEMS.filter(item => canSeeMenuItem(item.permissions, item.features));
    const visibleToSet = new Set(visibleItems.map(i => i.to));
    const primaryVisible = PRIMARY_ITEMS.map(to => itemByTo[to]).filter(i => i && visibleToSet.has(i.to));

    const handleLogout = async () => { await logout(); nav(`/${tenantSlug}/login`); };
    const closeMobile = () => setMobileOpen(false);

    return (
        <RealtimeTenantProvider>
            <NotificationProvider>
                <div className="min-h-screen flex flex-col" style={{ background: "var(--luppa-bg)" }}>
                    <ImpersonationBanner />

                    {/* ── Header ── */}
                    <header
                        className="sticky top-0 z-40 w-full border-b"
                        style={{
                            background: "#EBEBEA",
                            borderColor: "#D8D8D4",
                            paddingTop: "env(safe-area-inset-top, 0px)",
                        }}
                    >
                        <div className="max-w-[1800px] mx-auto px-4 md:px-6 lg:px-10 h-14 flex items-center gap-3">

                            {/* Logo */}
                            <Link
                                to={`/${tenantSlug}/dashboard`}
                                className="flex items-center flex-shrink-0 mr-3"
                                aria-label="Luppa"
                            >
                                <LuppaLogo height={24} mode="dark" />
                            </Link>

                            {/* Nav desktop */}
                            <nav className="hidden md:flex items-center gap-0.5 flex-1 overflow-x-auto scrollbar-none" data-testid="topbar-nav">
                                {primaryVisible.map(item => (
                                    <NavLink
                                        key={item.to}
                                        to={`/${tenantSlug}/${item.to}`}
                                        data-testid={item.testId}
                                        className={({ isActive }) => cn(
                                            "flex items-center gap-1.5 px-3 py-1.5 rounded-[6px] text-[13px] whitespace-nowrap transition-all duration-150",
                                            isActive
                                                ? "bg-[#006A4F] text-white font-medium"
                                                : "text-[#3A3A38] hover:bg-[#DEDEDA] hover:text-[#111110]"
                                        )}
                                    >
                                        <item.icon size={13} strokeWidth={2} className="flex-shrink-0" />
                                        {item.label}
                                    </NavLink>
                                ))}

                                {SECONDARY_GROUPS.map(group => {
                                    const groupVisible = group.items
                                        .map(to => itemByTo[to])
                                        .filter(i => i && visibleToSet.has(i.to));
                                    if (!groupVisible.length) return null;
                                    return (
                                        <DropdownMenu key={group.label}>
                                            <DropdownMenuTrigger asChild>
                                                <button className="flex items-center gap-1 px-3 py-1.5 rounded-[6px] text-[13px] text-[#3A3A38] hover:bg-[#DEDEDA] hover:text-[#111110] transition-all duration-150 whitespace-nowrap">
                                                    {group.label}
                                                    <ChevronDown size={11} strokeWidth={2} className="opacity-50" />
                                                </button>
                                            </DropdownMenuTrigger>
                                            <DropdownMenuContent align="start" className="min-w-[180px]">
                                                {groupVisible.map(item => (
                                                    <DropdownMenuItem key={item.to} asChild>
                                                        <NavLink
                                                            to={`/${tenantSlug}/${item.to}`}
                                                            data-testid={item.testId}
                                                            className={({ isActive }) => cn(
                                                                "flex items-center gap-2.5 w-full text-[13px]",
                                                                isActive && "text-luppa-green font-medium"
                                                            )}
                                                        >
                                                            <item.icon size={13} strokeWidth={1.75} />
                                                            {item.label}
                                                        </NavLink>
                                                    </DropdownMenuItem>
                                                ))}
                                            </DropdownMenuContent>
                                        </DropdownMenu>
                                    );
                                })}
                            </nav>

                            {/* Ações direita */}
                            <div className="flex items-center gap-1 ml-auto flex-shrink-0">
                                <ThemeToggle />
                                <NotificationBell />

                                <DropdownMenu>
                                    <DropdownMenuTrigger asChild>
                                        <button
                                            className="flex items-center gap-2 px-2 py-1.5 rounded-[6px] hover:bg-[#DEDEDA] transition-colors duration-150"
                                            data-testid="user-menu-trigger"
                                        >
                                            <div className="h-6 w-6 rounded-full bg-[#006A4F]/15 text-[#006A4F] flex items-center justify-center text-[10px] font-semibold flex-shrink-0">
                                                {(user?.name || "U").charAt(0).toUpperCase()}
                                            </div>
                                            <span className="text-[13px] font-medium text-[#111110] hidden sm:block max-w-[90px] truncate">
                                                {(user?.name || "").split(" ")[0]}
                                            </span>
                                            <ChevronDown size={11} className="opacity-40 flex-shrink-0" />
                                        </button>
                                    </DropdownMenuTrigger>
                                    <DropdownMenuContent align="end" className="w-52">
                                        <DropdownMenuLabel className="font-normal">
                                            <div className="flex flex-col">
                                                <p className="text-sm font-medium leading-none">{user?.name}</p>
                                                <p className="text-xs text-muted-foreground mt-0.5 truncate">{user?.email}</p>
                                                <Badge variant="muted" className="mt-1.5 w-fit text-[10px]" data-testid="user-role-badge">
                                                    {ROLE_LABELS[context.user_role] || context.user_role}
                                                </Badge>
                                            </div>
                                        </DropdownMenuLabel>
                                        <DropdownMenuSeparator />
                                        <DropdownMenuItem asChild>
                                            <NavLink to={`/${tenantSlug}/profile`} data-testid="nav-t-profile" className="flex items-center gap-2 w-full">
                                                <User size={13} /> Meu Perfil
                                            </NavLink>
                                        </DropdownMenuItem>
                                        <DropdownMenuSeparator />
                                        <DropdownMenuItem
                                            className="cursor-pointer text-luppa-error focus:bg-luppa-error/8 focus:text-luppa-error"
                                            onClick={handleLogout}
                                            data-testid="nav-t-logout"
                                        >
                                            <LogOut size={13} /> Sair
                                        </DropdownMenuItem>
                                    </DropdownMenuContent>
                                </DropdownMenu>

                                <button
                                    className="md:hidden h-8 w-8 flex items-center justify-center rounded-[6px] hover:bg-[#DEDEDA] transition-colors text-[#3A3A38]"
                                    onClick={() => setMobileOpen(true)}
                                    data-testid="sidebar-toggle"
                                    aria-label="Abrir menu"
                                >
                                    <Menu size={17} />
                                </button>
                            </div>
                        </div>
                    </header>

                    {/* ── Mobile drawer ── */}
                    {mobileOpen && (
                        <div className="fixed inset-0 z-50 md:hidden" role="dialog" aria-modal="true">
                            <div className="absolute inset-0 bg-black/50" onClick={closeMobile} />
                            <div className="absolute inset-y-0 left-0 w-72 flex flex-col shadow-2xl" style={{ background: "#1C1C1E", borderRight: "1px solid rgba(255,255,255,0.08)" }}>
                                <div className="flex items-center justify-between px-5 py-4" style={{ borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
                                    <LuppaLogo height={22} mode="light" />
                                    <button
                                        onClick={closeMobile}
                                        className="h-7 w-7 flex items-center justify-center rounded-[6px] text-white/60 hover:text-white hover:bg-white/10 transition-colors"
                                        aria-label="Fechar menu"
                                    >
                                        <X size={15} />
                                    </button>
                                </div>
                                <nav className="flex-1 px-3 py-3 space-y-0.5 overflow-y-auto" data-testid="sidebar-nav">
                                    {visibleItems.map((item) => (
                                        <NavLink
                                            key={item.to}
                                            to={`/${tenantSlug}/${item.to}`}
                                            data-testid={item.testId}
                                            onClick={closeMobile}
                                            className={({ isActive }) => cn(
                                                "flex items-center gap-2.5 px-3 py-2.5 rounded-[8px] text-[13px] transition-all duration-150",
                                                isActive
                                                    ? "bg-[#006A4F] text-white font-medium"
                                                    : "text-white/60 hover:bg-white/8 hover:text-white"
                                            )}
                                        >
                                            <item.icon size={15} strokeWidth={1.75} className="flex-shrink-0" />
                                            {item.label}
                                        </NavLink>
                                    ))}
                                </nav>
                                <div className="px-3 py-3" style={{ borderTop: "1px solid rgba(255,255,255,0.08)" }}>
                                    <NavLink to={`/${tenantSlug}/profile`} onClick={closeMobile} data-testid="nav-t-profile">
                                        <div className="flex items-center gap-2.5 px-3 py-2 rounded-[8px] text-[13px] text-white/60 hover:bg-white/8 hover:text-white cursor-pointer transition-colors">
                                            <User size={13} strokeWidth={1.75} /> Meu Perfil
                                        </div>
                                    </NavLink>
                                    <button
                                        onClick={handleLogout}
                                        className="w-full flex items-center gap-2.5 px-3 py-2 rounded-[8px] text-[13px] text-luppa-error/70 hover:bg-luppa-error/20 transition-colors mt-0.5"
                                        data-testid="nav-t-logout"
                                    >
                                        <LogOut size={13} strokeWidth={1.75} /> Sair
                                    </button>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* ── Content (dark) ── */}
                    <main className="flex-1 min-w-0">
                        <div className="page-container py-6 sm:py-8">
                            <RealtimeToastManager />
                            <Outlet />
                        </div>
                    </main>
                </div>
            </NotificationProvider>
        </RealtimeTenantProvider>
    );
}

function NotFoundTenant() {
    return (
        <div className="flex h-screen items-center justify-center" style={{ background: "var(--luppa-bg)" }}>
            <div className="max-w-md text-center space-y-4 px-6">
                <p className="micro-label text-luppa-gray">Erro 404</p>
                <h1 className="text-4xl font-semibold tracking-[-0.03em]">Empresa não encontrada.</h1>
                <p className="text-sm text-muted-foreground">Verifique o endereço da URL e tente novamente.</p>
            </div>
        </div>
    );
}

function NoAccessTenant({ slug }) {
    const { logout } = useAuth();
    const nav = useNavigate();
    const handle = async () => { await logout(); nav(`/${slug}/login`); };
    return (
        <div className="flex h-screen items-center justify-center" style={{ background: "var(--luppa-bg)" }}>
            <div className="max-w-md text-center space-y-4 px-6">
                <p className="micro-label text-luppa-gray">Acesso negado</p>
                <h1 className="text-4xl font-semibold tracking-[-0.03em]">Você não tem acesso a esta empresa.</h1>
                <p className="text-sm text-muted-foreground">Faça login com uma conta autorizada.</p>
                <Button onClick={handle} data-testid="no-access-logout-button">Trocar de conta</Button>
            </div>
        </div>
    );
}
