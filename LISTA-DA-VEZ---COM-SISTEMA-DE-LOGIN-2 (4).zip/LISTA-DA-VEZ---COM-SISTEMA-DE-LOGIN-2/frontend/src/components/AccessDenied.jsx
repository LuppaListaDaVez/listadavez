import React from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ShieldX } from "lucide-react";

/**
 * AccessDenied — tela exibida quando o usuário não tem permissão para acessar
 * uma área ou executar uma ação.
 */
export default function AccessDenied({ message, showDetails = false }) {
    const { tenantSlug } = useParams();
    const nav = useNavigate();

    return (
        <div className="flex flex-col items-center justify-center min-h-[60vh] px-6 text-center" data-testid="access-denied-page">
            <div className="w-16 h-16 rounded-full bg-luppa-error/10 flex items-center justify-center mb-6">
                <ShieldX size={32} className="text-luppa-error" strokeWidth={1.5} />
            </div>
            <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground mb-2">Acesso negado</p>
            <h2 className="text-2xl font-semibold mb-3">
                Você não tem permissão para acessar esta área.
            </h2>
            <p className="text-sm text-muted-foreground max-w-sm mb-6">
                {message || "Caso precise de acesso, solicite ao administrador da empresa."}
            </p>
            <Button
                onClick={() => nav(`/${tenantSlug}/dashboard`)}
                data-testid="access-denied-back-btn"
            >
                Voltar ao dashboard
            </Button>
        </div>
    );
}
