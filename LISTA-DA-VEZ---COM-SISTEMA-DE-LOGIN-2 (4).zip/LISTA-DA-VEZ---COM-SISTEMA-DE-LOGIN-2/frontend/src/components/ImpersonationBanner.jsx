/**
 * ImpersonationBanner — Banner de aviso quando o Super Admin está impersonando um tenant.
 *
 * Armazena o estado em sessionStorage para não persistir entre abas/sessões:
 *   - impersonation_active: "true"
 *   - impersonation_tenant_name: "Nome da empresa"
 *   - sa_access_token: token original do Super Admin
 *   - sa_refresh_token: refresh token original
 *   - sa_user: JSON do usuário Super Admin
 */
import React from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Shield, ArrowLeft } from "lucide-react";

export function useImpersonation() {
    const isActive = sessionStorage.getItem("impersonation_active") === "true";
    const tenantName = sessionStorage.getItem("impersonation_tenant_name") || "";
    return { isActive, tenantName };
}

/**
 * Inicia a impersonação: guarda os tokens do SA e aplica os tokens do tenant.
 */
export function startImpersonation({ data, currentTokens }) {
    // Salvar estado atual do SA
    sessionStorage.setItem("impersonation_active", "true");
    sessionStorage.setItem("impersonation_tenant_name", data.tenant_name);
    sessionStorage.setItem("sa_access_token", currentTokens.access_token);
    sessionStorage.setItem("sa_refresh_token", currentTokens.refresh_token || "");
    sessionStorage.setItem("sa_user", currentTokens.user || "");

    // Aplicar tokens do tenant impersonado
    localStorage.setItem("access_token", data.access_token);
    localStorage.setItem("refresh_token", data.refresh_token);
    localStorage.setItem("auth_tenant_slug", data.tenant_slug);
    localStorage.setItem("user", JSON.stringify(data.user));
}

/**
 * Encerra a impersonação e restaura os tokens do SA.
 */
export function stopImpersonation() {
    const saToken   = sessionStorage.getItem("sa_access_token");
    const saRefresh = sessionStorage.getItem("sa_refresh_token");
    const saUser    = sessionStorage.getItem("sa_user");

    // Restaurar tokens do SA
    if (saToken) localStorage.setItem("access_token", saToken);
    if (saRefresh) localStorage.setItem("refresh_token", saRefresh);
    if (saUser) localStorage.setItem("user", saUser);
    localStorage.removeItem("auth_tenant_slug");

    // Limpar estado de impersonação
    sessionStorage.removeItem("impersonation_active");
    sessionStorage.removeItem("impersonation_tenant_name");
    sessionStorage.removeItem("sa_access_token");
    sessionStorage.removeItem("sa_refresh_token");
    sessionStorage.removeItem("sa_user");
}

export default function ImpersonationBanner() {
    const navigate = useNavigate();
    const { isActive, tenantName } = useImpersonation();

    if (!isActive) return null;

    const handleExit = () => {
        stopImpersonation();
        // Forçar reload para AuthContext re-ler os tokens do SA
        window.location.href = "/super-admin/dashboard";
    };

    return (
        <div
            className="w-full bg-amber-500 text-amber-950 px-4 py-2 flex items-center justify-between gap-4 text-sm font-medium z-50 shrink-0"
            data-testid="impersonation-banner"
            role="alert"
        >
            <div className="flex items-center gap-2 min-w-0">
                <Shield size={15} className="shrink-0" />
                <span className="truncate">
                    Você está acessando como <strong>{tenantName}</strong> — modo Super Admin
                </span>
            </div>
            <Button
                size="sm"
                variant="ghost"
                className="shrink-0 h-7 px-3 text-amber-950 hover:bg-amber-400/40 hover:text-amber-950 gap-1.5"
                onClick={handleExit}
                data-testid="exit-impersonation-button"
            >
                <ArrowLeft size={13} />
                Sair da empresa
            </Button>
        </div>
    );
}
