import { Bell } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useTenant } from "@/context/TenantContext";
import { useNotifications } from "@/context/NotificationContext";
import { usePermissions } from "@/hooks/usePermissions";

export function NotificationBell() {
    const { context } = useTenant();
    const { hasFeature } = usePermissions();
    const nav = useNavigate();
    const { unreadCount } = useNotifications();

    const tenantSlug = context?.tenant?.slug;
    const enabled = hasFeature("notificacoes");

    if (!enabled) return null;

    return (
        <button
            onClick={() => nav(`/${tenantSlug}/notifications`)}
            className="relative p-2 rounded-sm hover:bg-muted transition-colors"
            data-testid="notification-bell"
            title="Notificações"
        >
            <Bell size={18} strokeWidth={1.5} className="text-foreground/70" />
            {unreadCount > 0 && (
                <span
                    className="absolute -top-0.5 -right-0.5 h-[18px] min-w-[18px] px-1 bg-luppa-error text-white text-[9px] font-bold rounded-full flex items-center justify-center leading-none"
                    data-testid="notification-unread-badge"
                >
                    {unreadCount > 99 ? "99+" : unreadCount}
                </span>
            )}
        </button>
    );
}
