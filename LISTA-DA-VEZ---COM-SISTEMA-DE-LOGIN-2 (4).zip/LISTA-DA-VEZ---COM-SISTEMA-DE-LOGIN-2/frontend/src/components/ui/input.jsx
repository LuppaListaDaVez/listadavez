import * as React from "react"

import { cn } from "@/lib/utils"

const Input = React.forwardRef(({ className, type, ...props }, ref) => {
  return (
    <input
      type={type}
      className={cn(
        "flex h-10 w-full rounded-[6px] border border-luppa-border bg-luppa-white px-3 py-2",
        "text-base text-foreground placeholder:text-muted-foreground/55",
        "shadow-xs transition-[border-color,box-shadow] duration-150",
        "file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground",
        "focus-visible:outline-none focus-visible:border-luppa-green",
        "focus-visible:ring-0 focus-visible:shadow-[0_0_0_4px_rgba(0,106,79,0.10)]",
        "disabled:cursor-not-allowed disabled:opacity-50 disabled:bg-muted/30",
        // dark mode
        "dark:bg-luppa-input dark:border-white/10 dark:text-foreground dark:placeholder:text-white/35",
        "dark:focus-visible:border-luppa-green dark:focus-visible:shadow-[0_0_0_4px_rgba(0,106,79,0.18)]",
        // iOS — min-font-size 16px para evitar zoom automático
        "sm:text-sm",
        className
      )}
      style={{ fontSize: 'max(16px, 0.875rem)', ...props.style }}
      ref={ref}
      {...props} />
  );
})
Input.displayName = "Input"

export { Input }
