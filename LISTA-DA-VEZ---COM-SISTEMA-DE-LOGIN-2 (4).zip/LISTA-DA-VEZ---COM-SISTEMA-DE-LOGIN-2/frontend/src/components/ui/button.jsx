import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva } from "class-variance-authority";

import { cn } from "@/lib/utils"

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium transition-all duration-200 focus-visible:outline-none disabled:pointer-events-none disabled:opacity-50 active:scale-[0.98] [&_svg]:pointer-events-none [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default:
          "rounded-[6px] bg-luppa-green text-white shadow-xs hover:bg-luppa-green/90 active:bg-luppa-green/95",
        destructive:
          "rounded-[6px] bg-luppa-error text-white shadow-xs hover:bg-luppa-error/90",
        outline:
          "rounded-[6px] border border-luppa-border bg-luppa-white text-foreground shadow-xs hover:bg-luppa-surface hover:text-foreground dark:border-white/10 dark:bg-transparent dark:hover:bg-white/5",
        secondary:
          "rounded-[6px] bg-secondary text-secondary-foreground shadow-xs hover:bg-secondary/80",
        ghost:
          "rounded-[6px] hover:bg-luppa-list text-muted-foreground hover:text-foreground dark:hover:bg-white/5",
        link:
          "text-primary underline-offset-4 hover:underline p-0 h-auto",
        green:
          "rounded-[6px] bg-luppa-green text-white shadow-xs hover:bg-luppa-green/90",
        purple:
          "rounded-[6px] bg-luppa-purple text-white shadow-xs hover:bg-luppa-purple/90",
      },
      size: {
        default: "h-9 px-4 py-2 text-sm",
        sm:      "h-8 px-3 py-1.5 text-xs",
        lg:      "h-11 px-6 py-2.5 text-base",
        xl:      "h-12 px-8 py-3 text-base",
        icon:    "h-9 w-9 p-0 rounded-[6px]",
        "icon-sm": "h-7 w-7 p-0 rounded-[6px]",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

const Button = React.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
  const Comp = asChild ? Slot : "button"
  return (
    <Comp
      className={cn(buttonVariants({ variant, size, className }))}
      ref={ref}
      {...props} />
  );
})
Button.displayName = "Button"

export { Button, buttonVariants }
