import * as React from "react"
import { cva } from "class-variance-authority";

import { cn } from "@/lib/utils"

const badgeVariants = cva(
  "inline-flex items-center rounded-[4px] px-2 py-0.5 text-[11px] font-medium leading-tight transition-colors focus:outline-none",
  {
    variants: {
      variant: {
        default:
          "bg-primary text-primary-foreground border border-transparent",
        secondary:
          "bg-muted text-muted-foreground border border-transparent",
        destructive:
          "bg-luppa-error/10 text-luppa-error border border-luppa-error/20",
        outline:
          "bg-transparent text-foreground border border-border",
        success:
          "bg-luppa-chip-active-bg text-luppa-chip-active-text border border-transparent",
        warning:
          "bg-amber-50 text-luppa-warning border border-amber-200 dark:bg-amber-900/20 dark:text-amber-400 dark:border-amber-800/30",
        purple:
          "bg-luppa-lilac text-luppa-purple border border-transparent dark:bg-luppa-purple/20 dark:text-luppa-lilac",
        blue:
          "bg-luppa-purple/10 text-luppa-purple border border-luppa-purple/25 dark:bg-luppa-purple/20 dark:text-luppa-purple/70 dark:border-luppa-purple/30",
        orange:
          "bg-luppa-warning/10 text-luppa-warning border border-luppa-warning/25 dark:bg-luppa-warning/20 dark:text-luppa-warning/70 dark:border-luppa-warning/30",
        muted:
          "bg-muted text-muted-foreground border border-transparent",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  }
)

function Badge({
  className,
  variant,
  ...props
}) {
  return (<div className={cn(badgeVariants({ variant }), className)} {...props} />);
}

export { Badge, badgeVariants }
