import React, { useState } from "react";
import { NavLink, Outlet, useNavigate, Link } from "react-router-dom";
import {
    LayoutDashboard, Building2, CreditCard, LogOut, ShieldCheck,
    Activity, Users, Settings, Mail, Menu, X, ChevronDown, Sun, Moon,
} from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import {
    DropdownMenu, DropdownMenuContent, DropdownMenuItem,
    DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";

function LuppaLogo({ height = 24, mode = "dark" }) {
    const style = mode === "light"
        ? { filter: "brightness(0) invert(1)", height }
        : { mixBlendMode: "darken", height };
    return <img src="/luppa-logo.webp" alt="Luppa" style={style} draggable="false" />;
}

function ThemeToggle() {
    const [dark, setDark] = useState(() => document.documentElement.classList.contains("dark"));
    const toggle = () => {
        const next = !dark;
        setDark(next);
        document.documentElement.classList.toggle("dark", next);
        try { localStorage.setItem("luppa.theme", next ? "dark" : "light"); } catch (e) {}
    };
    return (
        <button
            onClick={toggle}
            aria-label={dark ? "Ativar modo claro" : "Ativar modo escuro"}
            className="h-8 w-8 flex items-center justify-center rounded-[6px] text-[#3A3A38] hover:bg-[#E0E0DC] transition-colors duration-150">
            {dark ? <Sun size={15} strokeWidth={2} /> : <Moon size={15} strokeWidth={2} />}
        </button>
    );
}

const MENU_ITEMS = [
    { to: "/super-admin/dashboard", label: "Painel",   icon: LayoutDashboard, testId: "sa-nav-dashboard" },
    { to: "/super-admin/tenants",   label: "Empresas",  icon: Building2,       testId: "sa-nav-tenants" },
    { to: "/super-admin/plans",     label: "Planos",    icon: CreditCard,      testId: "sa-nav-plans" },
    { to: "/super-admin/features",  label: "Features",  icon: Settings,        testId: "sa-nav-features" },
    { to: "/super-admin/settings/email", label: "E-mail", icon: Mail,          testId: "sa-nav-email-settings" },
];

const SECURITY_ITEMS = [
    { to: "/super-admin/security",          label: "Visão Geral", icon: ShieldCheck, testId: "sa-nav-security" },
    { to: "/super-admin/security/events",   label: "Eventos",     icon: Activity,    testId: "sa-nav-sec-events" },
    { to: "/super-admin/security/sessions", label: "Sessões",     icon: Users,       testId: "sa-nav-sec-sessions" },
    { to: "/super-admin/security/mfa",      label: "MFA",         icon: ShieldCheck, testId: "sa-nav-sec-mfa" },
];

export default function SuperAdminLayout() {
    const { user, logout } = useAuth();
    const nav = useNavigate();
    const [mobileOpen, setMobileOpen] = useState(false);

    const handleLogout = async () => { await logout(); nav("/super-admin/login"); };
    const closeMobile = () => setMobileOpen(false);

    return (
        <div className="min-h-screen flex flex-col" style={{ background: "var(--luppa-bg)" }}>

            {/* ── Header ── */}
            <header
                className="sticky top-0 z-40 w-full border-b"
                style={{ background: "#EBEBEA", borderColor: "#D8D8D4" }}
            >
                <div className="max-w-[1800px] mx-auto px-4 md:px-6 lg:px-10 h-14 flex items-center gap-3">
                    <Link to="/super-admin/dashboard" className="flex items-center gap-2.5 flex-shrink-0 mr-3">
                        <LuppaLogo height={24} mode="dark" />
                        <span className="hidden sm:flex h-5 items-center text-[10px] font-semibold uppercase tracking-[0.1em] text-white bg-[#006A4F] px-2 rounded-[4px]">
                            Super Admin
                        </span>
                    </Link>

                    <nav className="hidden md:flex items-center gap-0.5 flex-1">
                        {MENU_ITEMS.map(item => (
                            <NavLink
                                key={item.to}
                                to={item.to}
                                data-testid={item.testId}
                                className={({ isActive }) => cn(
                                    "flex items-center gap-1.5 px-3 py-1.5 rounded-[6px] text-[13px] whitespace-nowrap transition-all duration-150",
                                    isActive
                                        ? "bg-[#006A4F] text-white font-medium"
                                        : "text-[#3A3A38] hover:bg-[#DEDEDA] hover:text-[#111110]"
                                )}
                            >
                                <item.icon size={13} strokeWidth={2} className="flex-shrink-0" />
                                {item.label}
                            </NavLink>
                        ))}

                        <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                                <button className="flex items-center gap-1 px-3 py-1.5 rounded-[6px] text-[13px] text-[#3A3A38] hover:bg-[#DEDEDA] hover:text-[#111110] transition-all duration-150 whitespace-nowrap">
                                    <ShieldCheck size={13} strokeWidth={2} />
                                    Segurança
                                    <ChevronDown size={11} strokeWidth={2} className="opacity-50" />
                                </button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="start" className="min-w-[180px]">
                                {SECURITY_ITEMS.map(item => (
                                    <DropdownMenuItem key={item.to} asChild>
                                        <NavLink to={item.to} data-testid={item.testId} className={({ isActive }) => cn("flex items-center gap-2 w-full text-[13px]", isActive && "text-luppa-green font-medium")}>
                                            <item.icon size={13} />{item.label}
                                        </NavLink>
                                    </DropdownMenuItem>
                                ))}
                            </DropdownMenuContent>
                        </DropdownMenu>
                    </nav>

                    <div className="flex items-center gap-1 ml-auto flex-shrink-0">
                        <ThemeToggle />

                        <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                                <button className="flex items-center gap-2 px-2 py-1.5 rounded-[6px] hover:bg-[#DEDEDA] transition-colors duration-150">
                                    <div className="h-6 w-6 rounded-full bg-[#006A4F]/15 text-[#006A4F] flex items-center justify-center text-[10px] font-semibold">
                                        {(user?.name || "A").charAt(0).toUpperCase()}
                                    </div>
                                    <span className="text-[13px] font-medium text-[#111110] hidden sm:block">
                                        {(user?.name || "").split(" ")[0]}
                                    </span>
                                    <ChevronDown size={11} className="opacity-40" />
                                </button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="w-48">
                                <DropdownMenuLabel className="font-normal">
                                    <p className="text-sm font-medium">{user?.name}</p>
                                    <p className="text-xs text-muted-foreground mt-0.5 truncate">{user?.email}</p>
                                </DropdownMenuLabel>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem
                                    className="cursor-pointer text-luppa-error focus:bg-luppa-error/8 focus:text-luppa-error"
                                    onClick={handleLogout}
                                    data-testid="sa-logout-btn"
                                >
                                    <LogOut size={13} /> Sair
                                </DropdownMenuItem>
                            </DropdownMenuContent>
                        </DropdownMenu>

                        <button
                            className="md:hidden h-8 w-8 flex items-center justify-center rounded-[6px] hover:bg-[#DEDEDA] transition-colors text-[#3A3A38]"
                            onClick={() => setMobileOpen(true)}
                            data-testid="sa-sidebar-toggle"
                        >
                            <Menu size={17} />
                        </button>
                    </div>
                </div>
            </header>

            {/* ── Mobile drawer ── */}
            {mobileOpen && (
                <div className="fixed inset-0 z-50 md:hidden">
                    <div className="absolute inset-0 bg-black/50" onClick={closeMobile} />
                    <div className="absolute inset-y-0 left-0 w-64 flex flex-col shadow-2xl" style={{ background: "#1C1C1E", borderRight: "1px solid rgba(255,255,255,0.08)" }}>
                        <div className="flex items-center justify-between px-5 py-4" style={{ borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
                            <LuppaLogo height={22} mode="light" />
                            <button onClick={closeMobile} className="h-7 w-7 flex items-center justify-center rounded-[6px] text-white/60 hover:text-white hover:bg-white/10">
                                <X size={15} />
                            </button>
                        </div>
                        <nav className="flex-1 px-3 py-3 space-y-0.5 overflow-y-auto">
                            {[...MENU_ITEMS, ...SECURITY_ITEMS].map(item => (
                                <NavLink
                                    key={item.to}
                                    to={item.to}
                                    data-testid={item.testId}
                                    onClick={closeMobile}
                                    className={({ isActive }) => cn(
                                        "flex items-center gap-2.5 px-3 py-2.5 rounded-[8px] text-[13px] transition-all duration-150",
                                        isActive ? "bg-[#006A4F] text-white font-medium" : "text-white/60 hover:bg-white/8 hover:text-white"
                                    )}
                                >
                                    <item.icon size={14} strokeWidth={1.75} />
                                    {item.label}
                                </NavLink>
                            ))}
                        </nav>
                        <div className="p-3" style={{ borderTop: "1px solid rgba(255,255,255,0.08)" }}>
                            <button onClick={handleLogout} className="w-full flex items-center gap-2 px-3 py-2 rounded-[8px] text-[13px] text-luppa-error/70 hover:bg-luppa-error/20 transition-colors" data-testid="sa-logout-btn">
                                <LogOut size={13} /> Sair
                            </button>
                        </div>
                    </div>
                </div>
            )}

            <main className="flex-1 min-w-0">
                <div className="page-container py-6 sm:py-8">
                    <Outlet />
                </div>
            </main>
        </div>
    );
}
