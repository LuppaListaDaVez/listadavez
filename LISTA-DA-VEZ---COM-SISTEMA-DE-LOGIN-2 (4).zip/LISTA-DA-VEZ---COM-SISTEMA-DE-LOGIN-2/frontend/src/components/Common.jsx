import React, { useState } from "react";
import { Inbox } from "lucide-react";

export function PageLoader() {
    return (
        <div className="flex items-center justify-center min-h-[60vh]" aria-label="Carregando página" role="status">
            <div className="flex flex-col items-center gap-3">
                <div className="w-6 h-6 border-2 border-luppa-green/20 border-t-luppa-green rounded-full animate-spin" />
                <p className="text-xs text-muted-foreground tracking-wide">Carregando…</p>
            </div>
        </div>
    );
}

export function PageHeader({ eyebrow, title, description, children }) {
    return (
        <div className="flex items-start justify-between mb-8 gap-4 flex-wrap">
            <div className="space-y-1.5 min-w-0">
                {eyebrow && (
                    <p className="micro-label">{eyebrow}</p>
                )}
                <h1 className="text-2xl sm:text-3xl font-semibold tracking-[-0.02em] leading-tight">{title}</h1>
                {description && (
                    <p className="text-sm text-muted-foreground max-w-2xl leading-relaxed">{description}</p>
                )}
            </div>
            {children && <div className="flex gap-2 items-center flex-wrap max-w-full w-full sm:w-auto sm:flex-shrink-0">{children}</div>}
        </div>
    );
}

export function EmptyState({ icon: Icon = Inbox, title, description, action }) {
    return (
        <div
            className="flex flex-col items-center justify-center py-16 px-6 text-center"
            role="status"
            aria-live="polite"
        >
            <div className="h-10 w-10 rounded-[12px] bg-muted flex items-center justify-center mb-4">
                <Icon size={20} strokeWidth={1.5} className="text-muted-foreground" />
            </div>
            <h3 className="text-base font-semibold mb-1">{title}</h3>
            {description && (
                <p className="text-sm text-muted-foreground max-w-xs leading-relaxed">{description}</p>
            )}
            {action && <div className="mt-5">{action}</div>}
        </div>
    );
}

/**
 * MetricCard — Card de métrica responsivo e reutilizável.
 * Usa container queries (cqi) para escalar o valor automaticamente.
 *
 * Props: label, value, accent, loading, testId, icon, trend
 * accent: "green" | "purple" | "amber" | "blue" | "red" | undefined
 */
export function MetricCard({ label, value, accent, loading = false, testId, icon: Icon, trend, className = "" }) {
    const accentColors = {
        green:  "text-luppa-green",
        purple: "text-luppa-purple",
        amber:  "text-luppa-warning",
        blue:   "text-luppa-purple",
        red:    "text-luppa-error",
    };
    const colorCls = accentColors[accent] || "text-foreground";

    return (
        <div className={`metric-card-wrap rounded-[16px] border border-border/60 bg-card shadow-sm p-4 sm:p-5 ${className}`}>
            {/* Header: label + ícone */}
            <div className="flex items-center justify-between gap-1 mb-2 min-w-0">
                <p className="metric-label text-[10px] font-semibold uppercase tracking-[0.1em] text-muted-foreground">
                    {label}
                </p>
                {Icon && <Icon size={13} className={`${colorCls} opacity-50 flex-shrink-0`} />}
            </div>

            {/* Valor principal */}
            {loading ? (
                <div className="h-7 w-20 bg-muted animate-pulse rounded" aria-busy="true" />
            ) : (
                <span
                    className={`metric-num font-mono font-semibold tracking-[-0.02em] ${colorCls}`}
                    data-testid={testId}
                    aria-label={String(value)}
                >
                    {value ?? "—"}
                </span>
            )}

            {/* Tendência (opcional) */}
            {trend != null && !loading && (
                <p className={`text-[10px] font-semibold mt-1 ${trend > 0 ? "text-luppa-green" : trend < 0 ? "text-luppa-error" : "text-muted-foreground"}`}>
                    {trend > 0 ? "+" : ""}{trend}%
                </p>
            )}
        </div>
    );
}

/**
 * Usar em qualquer lugar em que o nome do vendedor/usuário é exibido.
 *
 * Props:
 *   name       {string}  Nome completo
 *   src        {string}  URL da foto (opcional)
 *   size       {number}  Diâmetro em px (default 28)
 *   className  {string}  Classes extras
 *   showName   {boolean} Se true, renderiza foto + nome lado a lado
 *   role       {string}  Texto secundário (cargo, unidade)
 */
export function SellerAvatar({ name = "", src, size = 28, className = "", showName = false, role: roleProp }) {
    const [imgError, setImgError] = useState(false);
    const initials = (name || "?")
        .split(" ")
        .filter(Boolean)
        .slice(0, 2)
        .map((n) => n[0].toUpperCase())
        .join("");

    const avatarStyle = {
        width: size,
        height: size,
        minWidth: size,
        borderRadius: "50%",
        fontSize: Math.max(9, Math.round(size * 0.38)),
    };

    const avatar =
        src && !imgError ? (
            <img
                src={src}
                alt={name}
                style={{ ...avatarStyle, objectFit: "cover" }}
                className={`border border-border/60 bg-muted ${className}`}
                onError={() => setImgError(true)}
                data-testid="seller-avatar-img"
            />
        ) : (
            <div
                style={avatarStyle}
                className={`bg-primary/10 text-primary flex items-center justify-center font-semibold border border-border/40 select-none ${className}`}
                data-testid="seller-avatar-initials"
            >
                {initials}
            </div>
        );

    if (!showName) return avatar;

    return (
        <div className="flex items-center gap-2 min-w-0">
            {avatar}
            <div className="min-w-0">
                <p className="text-sm font-medium leading-tight truncate">{name || "—"}</p>
                {roleProp && <p className="text-xs text-muted-foreground truncate">{roleProp}</p>}
            </div>
        </div>
    );
}
