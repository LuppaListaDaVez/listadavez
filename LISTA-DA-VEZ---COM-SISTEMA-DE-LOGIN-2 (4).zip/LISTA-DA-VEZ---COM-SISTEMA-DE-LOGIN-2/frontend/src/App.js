import React, { lazy, Suspense } from "react";
import { BrowserRouter, Routes, Route, Navigate, useLocation } from "react-router-dom";
import { Toaster } from "sonner";

import { AuthProvider } from "@/context/AuthContext";
import { TenantProvider } from "@/context/TenantContext";
import { RequireSuperAdmin, RequireTenantAuth, ProtectedTenantRoute } from "@/components/ProtectedRoute";
import { PageLoader } from "@/components/Common";
import { ErrorBoundary } from "@/components/ErrorBoundary";

// ── Infra (sync — necessário para o shell de autenticação) ─────────────────
const SuperAdminLayout = lazy(() => import("@/components/SuperAdminLayout"));
const TenantLayout     = lazy(() => import("@/components/TenantLayout"));

// ── Super Admin pages ──────────────────────────────────────────────────────
const HomePage           = lazy(() => import("@/pages/HomePage"));
const SuperAdminLogin    = lazy(() => import("@/pages/superadmin/SuperAdminLogin"));
const SuperAdminDashboard = lazy(() => import("@/pages/superadmin/SuperAdminDashboard"));
const TenantsList        = lazy(() => import("@/pages/superadmin/TenantsList"));
const TenantNew          = lazy(() => import("@/pages/superadmin/TenantNew"));
const TenantFeatures     = lazy(() => import("@/pages/superadmin/TenantFeatures"));
const FeaturesList       = lazy(() => import("@/pages/superadmin/FeaturesList"));
const PlansList          = lazy(() => import("@/pages/superadmin/PlansList"));
const SecurityPage       = lazy(() => import("@/pages/superadmin/SecurityPage"));
const SecurityEventsPage = lazy(() => import("@/pages/superadmin/SecurityEventsPage"));
const SessionsPage       = lazy(() => import("@/pages/superadmin/SessionsPage"));
const MFASetupPage       = lazy(() => import("@/pages/superadmin/MFASetupPage"));

// ── Tenant pages ───────────────────────────────────────────────────────────
const TenantLogin        = lazy(() => import("@/pages/tenant/TenantLogin"));
const TenantDashboard    = lazy(() => import("@/pages/tenant/TenantDashboard"));
const StoresList         = lazy(() => import("@/pages/tenant/StoresList"));
const StoreNew           = lazy(() => import("@/pages/tenant/StoreNew"));
const UsersList          = lazy(() => import("@/pages/tenant/UsersList"));
const UserNew            = lazy(() => import("@/pages/tenant/UserNew"));
const Settings           = lazy(() => import("@/pages/tenant/Settings"));
const SellersList        = lazy(() => import("@/pages/tenant/SellersList"));
const TeamsList          = lazy(() => import("@/pages/tenant/TeamsList"));
const LossReasonsList    = lazy(() => import("@/pages/tenant/LossReasonsList"));
const StoreSettings      = lazy(() => import("@/pages/tenant/StoreSettings"));
const QueuePage          = lazy(() => import("@/pages/tenant/QueuePage"));
const AttendancesList    = lazy(() => import("@/pages/tenant/AttendancesList"));
const ProductsList       = lazy(() => import("@/pages/tenant/ProductsList"));
const SalesList          = lazy(() => import("@/pages/tenant/SalesList"));
const ReportsPage        = lazy(() => import("@/pages/tenant/ReportsPage"));
const GoalsList          = lazy(() => import("@/pages/tenant/GoalsList"));
const GoalNew            = lazy(() => import("@/pages/tenant/GoalNew"));
const GoalDetail         = lazy(() => import("@/pages/tenant/GoalDetail"));
const RankingsPage       = lazy(() => import("@/pages/tenant/RankingsPage"));
const MyPerformancePage  = lazy(() => import("@/pages/tenant/MyPerformancePage"));
const GamificationPage   = lazy(() => import("@/pages/tenant/GamificationPage"));
const FeedbacksList      = lazy(() => import("@/pages/tenant/FeedbacksList"));
const FeedbackNew        = lazy(() => import("@/pages/tenant/FeedbackNew"));
const FeedbackDetail     = lazy(() => import("@/pages/tenant/FeedbackDetail"));
const NotificationsPage  = lazy(() => import("@/pages/tenant/NotificationsPage"));
const ProactivityPage    = lazy(() => import("@/pages/tenant/ProactivityPage"));
const ProactivityNew     = lazy(() => import("@/pages/tenant/ProactivityNew"));
const ProactivityDetail  = lazy(() => import("@/pages/tenant/ProactivityDetail"));
const MyProactivityPage  = lazy(() => import("@/pages/tenant/MyProactivityPage"));
const AlertsPage         = lazy(() => import("@/pages/tenant/AlertsPage"));
const AutomationRulesPage = lazy(() => import("@/pages/tenant/AutomationRulesPage"));
const MotivationFeedPage = lazy(() => import("@/pages/tenant/MotivationFeedPage"));
const NotificationPreferencesPage = lazy(() => import("@/pages/tenant/NotificationPreferencesPage"));

// ── Tenant report pages ────────────────────────────────────────────────────
const AttendancesReport      = lazy(() => import("@/pages/tenant/reports/AttendancesReport"));
const ConversionReport       = lazy(() => import("@/pages/tenant/reports/ConversionReport"));
const LossReasonsReport      = lazy(() => import("@/pages/tenant/reports/LossReasonsReport"));
const SellerPerformanceReport = lazy(() => import("@/pages/tenant/reports/SellerPerformanceReport"));
const ProductsReport         = lazy(() => import("@/pages/tenant/reports/ProductsReport"));
const ProactivityReport      = lazy(() => import("@/pages/tenant/reports/ProactivityReport"));
const PAReport                = lazy(() => import("@/pages/tenant/reports/PAReport"));
const OpportunityFlowReport   = lazy(() => import("@/pages/tenant/reports/OpportunityFlowReport"));
const PreferenceAttendancesReport = lazy(() => import("@/pages/tenant/reports/PreferenceAttendancesReport"));

// ── Etapa 14 — LGPD, Privacidade, Retenção, Backup ───────────────────────
const PrivacyOverviewPage        = lazy(() => import("@/pages/tenant/PrivacyOverviewPage"));
const PrivacyRequestsPage        = lazy(() => import("@/pages/tenant/PrivacyRequestsPage"));
const PrivacyRequestDetailPage   = lazy(() => import("@/pages/tenant/PrivacyRequestDetailPage"));
const ConsentsPage               = lazy(() => import("@/pages/tenant/ConsentsPage"));
const DataMapPage                = lazy(() => import("@/pages/tenant/DataMapPage"));
const RetentionPage              = lazy(() => import("@/pages/tenant/RetentionPage"));
const BackupsPage                = lazy(() => import("@/pages/tenant/BackupsPage"));
const DataProtectionSettingsPage = lazy(() => import("@/pages/tenant/DataProtectionSettingsPage"));

const SmtpSettingsPage = lazy(() => import("@/pages/superadmin/SmtpSettingsPage"));

// ── Google OAuth Callback ─────────────────────────────────────────────────
const GoogleAuthCallback = lazy(() => import("@/pages/GoogleAuthCallback"));

// ── Prompt 5 — Convites ───────────────────────────────────────────────────
const AcceptInvitePage    = lazy(() => import("@/pages/AcceptInvitePage"));
const InviteUserPage      = lazy(() => import("@/pages/tenant/InviteUserPage"));
const ProfilePage         = lazy(() => import("@/pages/tenant/ProfilePage"));
const ForgotPasswordPage  = lazy(() => import("@/pages/tenant/ForgotPasswordPage"));
const ResetPasswordPage   = lazy(() => import("@/pages/ResetPasswordPage"));

const RESERVED = new Set(["super-admin", "api", "auth", "static", "favicon.ico"]);

function TenantGuard({ children }) {
    return (
        <TenantProvider>
            <RequireTenantAuth>{children}</RequireTenantAuth>
        </TenantProvider>
    );
}

function TenantLoginRouteGuard({ children }) {
    return <TenantProvider>{children}</TenantProvider>;
}

function Guard({ permissions, features, children }) {
    return (
        <ProtectedTenantRoute permissions={permissions} features={features}>
            {children}
        </ProtectedTenantRoute>
    );
}

export default function App() {
    return (
        <ErrorBoundary>
        <BrowserRouter>
            <AuthProvider>
                <Toaster position="top-right" richColors />
                <Suspense fallback={<PageLoader />}>
                    <AppRouter />
                </Suspense>
            </AuthProvider>
        </BrowserRouter>
        </ErrorBoundary>
    );
}

/**
 * REMINDER: DO NOT HARDCODE THE URL, OR ADD ANY FALLBACKS OR REDIRECT URLS, THIS BREAKS THE AUTH
 * Detecta #session_id= na URL de forma síncrona (antes do primeiro render)
 * para evitar race conditions com o AuthProvider.
 */
function AppRouter() {
    const location = useLocation();

    // Se há session_id no hash → renderizar callback imediatamente
    if (location.hash?.includes("session_id=")) {
        return (
            <Suspense fallback={<PageLoader />}>
                <GoogleAuthCallback />
            </Suspense>
        );
    }

    return (
        <Routes>
                        <Route path="/" element={<HomePage />} />

                        {/* Super Admin */}
                        <Route path="/super-admin/login" element={<SuperAdminLogin />} />
                        <Route
                            path="/super-admin"
                            element={
                                <RequireSuperAdmin>
                                    <SuperAdminLayout />
                                </RequireSuperAdmin>
                            }
                        >
                            <Route index element={<Navigate to="/super-admin/dashboard" replace />} />
                            <Route path="dashboard" element={<SuperAdminDashboard />} />
                            <Route path="settings/email" element={<SmtpSettingsPage />} />
                            <Route path="tenants" element={<TenantsList />} />
                            <Route path="tenants/new" element={<TenantNew />} />
                            <Route path="tenants/:tenantId/features" element={<TenantFeatures />} />
                            <Route path="plans" element={<PlansList />} />
                            <Route path="features" element={<FeaturesList />} />
                            <Route path="security" element={<SecurityPage />} />
                            <Route path="security/events" element={<SecurityEventsPage />} />
                            <Route path="security/sessions" element={<SessionsPage />} />
                            <Route path="security/mfa" element={<MFASetupPage />} />
                        </Route>

                        {/* Prompt 5: Ativação de conta via convite (rota pública) */}
                        <Route path="/ativar-conta" element={<AcceptInvitePage />} />
                        <Route path="/redefinir-senha" element={<ResetPasswordPage />} />

                        {/* Google OAuth callbacks (públicas) */}
                        <Route path="/super-admin/auth/callback" element={<GoogleAuthCallback />} />
                        <Route path="/:tenantSlug/auth/callback" element={<GoogleAuthCallback />} />

                        {/* Tenant-scoped */}
                        <Route
                            path="/:tenantSlug/login"
                            element={
                                <TenantSlugFilter>
                                    <TenantLoginRouteGuard>
                                        <TenantLogin />
                                    </TenantLoginRouteGuard>
                                </TenantSlugFilter>
                            }
                        />
                        <Route
                            path="/:tenantSlug/forgot-password"
                            element={
                                <TenantSlugFilter>
                                    <ForgotPasswordPage />
                                </TenantSlugFilter>
                            }
                        />
                        <Route
                            path="/:tenantSlug"
                            element={
                                <TenantSlugFilter>
                                    <TenantGuard>
                                        <TenantLayout />
                                    </TenantGuard>
                                </TenantSlugFilter>
                            }
                        >
                            <Route index element={<Navigate to="dashboard" replace />} />
                            <Route path="dashboard" element={
                                <Guard permissions={["dashboard.view_store", "dashboard.view_tenant"]}>
                                    <TenantDashboard />
                                </Guard>
                            } />
                            <Route path="stores" element={<Guard permissions={["stores.create"]}><StoresList /></Guard>} />
                            <Route path="stores/new" element={<Guard permissions={["stores.create"]}><StoreNew /></Guard>} />
                            <Route path="users" element={<Guard permissions={["users.view"]}><UsersList /></Guard>} />
                            <Route path="users/invite" element={<Guard permissions={["users.create"]}><InviteUserPage /></Guard>} />
                            <Route path="users/new" element={<Guard permissions={["users.create"]}><UserNew /></Guard>} />
                            <Route path="settings" element={<Guard permissions={["tenant.settings.view", "tenant.settings.update"]}><Settings /></Guard>} />
                            <Route path="profile" element={<ProfilePage />} />
                            <Route path="sellers" element={<Guard permissions={["sellers.view"]}><SellersList /></Guard>} />
                            <Route path="teams" element={<Guard permissions={["teams.view"]} features={["multi_equipes"]}><TeamsList /></Guard>} />
                            <Route path="queue" element={<Guard permissions={["queue.view"]} features={["lista_da_vez"]}><QueuePage /></Guard>} />
                            <Route path="queue/:storeId" element={<Guard permissions={["queue.view"]} features={["lista_da_vez"]}><QueuePage /></Guard>} />
                            <Route path="attendances" element={<Guard permissions={["attendances.view_self", "attendances.view_store", "attendances.view_tenant"]} features={["lista_da_vez"]}><AttendancesList /></Guard>} />
                            <Route path="products" element={<Guard permissions={["products.view"]} features={["produtos"]}><ProductsList /></Guard>} />
                            <Route path="sales" element={<Guard permissions={["sales.view_self", "sales.view_store", "sales.view_tenant"]} features={["vendas_detalhadas"]}><SalesList /></Guard>} />
                            <Route path="loss-reasons" element={<Guard permissions={["loss_reasons.view"]} features={["motivos_nao_venda"]}><LossReasonsList /></Guard>} />
                            <Route path="reports" element={<Guard permissions={["reports.view_self", "reports.view_store", "reports.view_tenant"]} features={["relatorios_basicos"]}><ReportsPage /></Guard>} />
                            <Route path="reports/attendances" element={<Guard permissions={["reports.view_self", "reports.view_store", "reports.view_tenant"]} features={["relatorios_basicos"]}><AttendancesReport /></Guard>} />
                            <Route path="reports/conversion" element={<Guard permissions={["reports.view_self", "reports.view_store", "reports.view_tenant"]} features={["relatorios_basicos"]}><ConversionReport /></Guard>} />
                            <Route path="reports/loss-reasons" element={<Guard permissions={["reports.view_self", "reports.view_store", "reports.view_tenant"]} features={["relatorios_basicos"]}><LossReasonsReport /></Guard>} />
                            <Route path="reports/seller-performance" element={<Guard permissions={["reports.view_self", "reports.view_store", "reports.view_tenant"]} features={["relatorios_basicos"]}><SellerPerformanceReport /></Guard>} />
                            <Route path="reports/products" element={<Guard permissions={["reports.view_self", "reports.view_store", "reports.view_tenant"]} features={["relatorios_basicos"]}><ProductsReport /></Guard>} />
                            <Route path="reports/pa" element={<Guard permissions={["reports.view_self", "reports.view_store", "reports.view_tenant"]} features={["relatorios_basicos"]}><PAReport /></Guard>} />
                            <Route path="reports/opportunity-flow" element={<Guard permissions={["reports.view_self", "reports.view_store", "reports.view_tenant"]} features={["relatorios_basicos"]}><OpportunityFlowReport /></Guard>} />
                            <Route path="reports/preference-attendances" element={<Guard permissions={["reports.view_self", "reports.view_store", "reports.view_tenant"]} features={["relatorios_basicos"]}><PreferenceAttendancesReport /></Guard>} />
                            <Route path="goals" element={<Guard permissions={["goals.view_self", "goals.view_store", "goals.view_tenant"]} features={["metas"]}><GoalsList /></Guard>} />
                            <Route path="goals/new" element={<Guard permissions={["goals.create"]} features={["metas"]}><GoalNew /></Guard>} />
                            <Route path="goals/:goalId" element={<Guard permissions={["goals.view_self", "goals.view_store", "goals.view_tenant"]} features={["metas"]}><GoalDetail /></Guard>} />
                            <Route path="goals/:goalId/edit" element={<Guard permissions={["goals.update"]} features={["metas"]}><GoalNew /></Guard>} />
                            <Route path="rankings" element={<Guard permissions={["rankings.view_self", "rankings.view_store", "rankings.view_tenant"]} features={["rankings"]}><RankingsPage /></Guard>} />
                            <Route path="my-performance" element={<Guard permissions={["performance.view_self", "performance.view_store"]}><MyPerformancePage /></Guard>} />
                            <Route path="gamification" element={<Guard permissions={["gamification.view_self", "gamification.view_store", "gamification.view_tenant"]} features={["gamificacao"]}><GamificationPage /></Guard>} />
                            <Route path="feedbacks" element={<Guard permissions={["feedbacks.view_self", "feedbacks.view_store", "feedbacks.view_tenant"]} features={["feedbacks"]}><FeedbacksList /></Guard>} />
                            <Route path="feedbacks/new" element={<Guard permissions={["feedbacks.create"]} features={["feedbacks"]}><FeedbackNew /></Guard>} />
                            <Route path="feedbacks/:feedbackId" element={<Guard permissions={["feedbacks.view_self", "feedbacks.view_store", "feedbacks.view_tenant"]} features={["feedbacks"]}><FeedbackDetail /></Guard>} />
                            <Route path="notifications" element={<Guard permissions={["notifications.view_self"]} features={["notificacoes"]}><NotificationsPage /></Guard>} />
                            <Route path="proactivity" element={<Guard permissions={["proactivity.view_self","proactivity.view_store","proactivity.view_tenant"]} features={["abordagem_proativa"]}><ProactivityPage /></Guard>} />
                            <Route path="proactivity/new" element={<Guard permissions={["proactivity.create_self","proactivity.create_any"]} features={["abordagem_proativa"]}><ProactivityNew /></Guard>} />
                            <Route path="proactivity/:approachId" element={<Guard permissions={["proactivity.view_self","proactivity.view_store","proactivity.view_tenant"]} features={["abordagem_proativa"]}><ProactivityDetail /></Guard>} />
                            <Route path="my-proactivity" element={<Guard permissions={["proactivity.view_self"]} features={["abordagem_proativa"]}><MyProactivityPage /></Guard>} />
                            <Route path="reports/proactivity" element={<Guard permissions={["proactivity.reports_view","proactivity.view_self"]} features={["abordagem_proativa"]}><ProactivityReport /></Guard>} />
                            {/* Etapa 12 */}
                            <Route path="alerts" element={<Guard permissions={["alerts.view_self","alerts.view_store","alerts.view_tenant"]} features={["alertas_inteligentes"]}><AlertsPage /></Guard>} />
                            <Route path="automation-rules" element={<Guard permissions={["automation.view"]} features={["automacoes"]}><AutomationRulesPage /></Guard>} />
                            <Route path="motivation-feed" element={<Guard permissions={["motivation_events.view"]} features={["motivacao_publica"]}><MotivationFeedPage /></Guard>} />
                            <Route path="notifications/preferences" element={<Guard permissions={["notifications.preferences_update_self","notifications.preferences_update_any"]} features={["preferencias_notificacao"]}><NotificationPreferencesPage /></Guard>} />
                            {/* Etapa 14 — LGPD */}
                            <Route path="privacy" element={<Guard permissions={["privacy.requests.view","privacy.requests.create"]} features={["lgpd"]}><PrivacyOverviewPage /></Guard>} />
                            <Route path="privacy/requests" element={<Guard permissions={["privacy.requests.view","privacy.requests.create"]} features={["lgpd"]}><PrivacyRequestsPage /></Guard>} />
                            <Route path="privacy/requests/:requestId" element={<Guard permissions={["privacy.requests.view","privacy.requests.create"]} features={["lgpd"]}><PrivacyRequestDetailPage /></Guard>} />
                            <Route path="privacy/consents" element={<Guard permissions={["privacy.consents.view","privacy.consents.manage"]} features={["lgpd"]}><ConsentsPage /></Guard>} />
                            <Route path="privacy/data-map" element={<Guard permissions={["privacy.data_map.view"]} features={["lgpd"]}><DataMapPage /></Guard>} />
                            <Route path="settings/data-protection" element={<Guard permissions={["privacy.settings.view","privacy.settings.update"]} features={["lgpd"]}><DataProtectionSettingsPage /></Guard>} />
                            <Route path="settings/retention" element={<Guard permissions={["retention.policies.view"]} features={["retencao_dados"]}><RetentionPage /></Guard>} />
                            <Route path="backups" element={<Guard permissions={["backup.view"]} features={["backup_restore"]}><BackupsPage /></Guard>} />
                            <Route path="settings/store/:storeId" element={<Guard permissions={["tenant.settings.view", "tenant.settings.update"]}><StoreSettings /></Guard>} />
                            <Route path="store-settings" element={<Guard permissions={["tenant.settings.view", "tenant.settings.update"]}><StoreSettings /></Guard>} />
                        </Route>

                        <Route path="*" element={<Navigate to="/" replace />} />
                    </Routes>
    );
}

function TenantSlugFilter({ children }) {
    const seg = window.location.pathname.split("/").filter(Boolean)[0];
    if (seg && RESERVED.has(seg)) return <Navigate to="/" replace />;
    return children;
}
