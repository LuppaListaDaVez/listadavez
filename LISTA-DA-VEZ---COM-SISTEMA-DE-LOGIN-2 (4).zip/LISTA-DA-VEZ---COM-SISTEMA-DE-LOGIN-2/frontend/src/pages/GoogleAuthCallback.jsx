import React, { useEffect, useRef } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import api from "@/lib/api";
import { PageLoader } from "@/components/Common";

/**
 * Componente de callback Google OAuth.
 * Lê #session_id= da URL, chama o backend para trocar por JWT,
 * armazena os tokens e redireciona para o dashboard correto.
 *
 * REMINDER: DO NOT HARDCODE THE URL, OR ADD ANY FALLBACKS OR REDIRECT URLS, THIS BREAKS THE AUTH
 */
export default function GoogleAuthCallback() {
    const navigate = useNavigate();
    const location = useLocation();
    const { loginWithTokens } = useAuth();
    const hasProcessed = useRef(false);

    useEffect(() => {
        // Usar useRef para evitar dupla execução em StrictMode
        if (hasProcessed.current) return;
        hasProcessed.current = true;

        const processCallback = async () => {
            // Extrair session_id do hash da URL (#session_id=...)
            const hash = location.hash || window.location.hash;
            const match = hash.match(/session_id=([^&]+)/);
            if (!match) {
                navigate("/", { replace: true });
                return;
            }

            const sessionId = match[1];

            // Determinar contexto: super-admin ou tenant
            // Pathname será /super-admin/auth/callback ou /:slug/auth/callback
            const pathname = location.pathname;
            const isSuperAdmin = pathname.startsWith("/super-admin/auth/callback");
            const tenantSlugMatch = pathname.match(/^\/([^/]+)\/auth\/callback/);
            const tenantSlug = !isSuperAdmin && tenantSlugMatch ? tenantSlugMatch[1] : null;

            try {
                let data;
                if (isSuperAdmin) {
                    const resp = await api.post("/auth/google/callback", { session_id: sessionId });
                    data = resp.data;
                } else if (tenantSlug) {
                    const resp = await api.post(`/tenants/${tenantSlug}/auth/google/callback`, {
                        session_id: sessionId,
                    });
                    data = resp.data;
                } else {
                    navigate("/", { replace: true });
                    return;
                }

                // Armazenar tokens (mesmo padrão do login com senha)
                localStorage.setItem("access_token", data.access_token);
                localStorage.setItem("refresh_token", data.refresh_token);
                localStorage.setItem("user", JSON.stringify(data.user));

                if (data.auth_context === "SUPER_ADMIN") {
                    localStorage.removeItem("auth_tenant_slug");
                    navigate("/super-admin/dashboard", { replace: true });
                } else {
                    localStorage.setItem("auth_tenant_slug", data.tenant_slug);
                    loginWithTokens(data, data.tenant_slug);
                    navigate(`/${data.tenant_slug}/dashboard`, { replace: true });
                }
            } catch (err) {
                const message =
                    err?.response?.data?.detail?.message ||
                    err?.response?.data?.detail ||
                    "Erro ao autenticar com Google.";

                // Redirecionar de volta ao login com mensagem de erro
                if (isSuperAdmin) {
                    navigate(`/super-admin/login?google_error=${encodeURIComponent(message)}`, { replace: true });
                } else if (tenantSlug) {
                    navigate(`/${tenantSlug}/login?google_error=${encodeURIComponent(message)}`, { replace: true });
                } else {
                    navigate("/", { replace: true });
                }
            }
        };

        processCallback();
    }, []); // eslint-disable-line react-hooks/exhaustive-deps

    return <PageLoader />;
}
