import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ShieldCheck, Activity, Users, AlertTriangle, RefreshCw, Unlock } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import api from "@/lib/api";
import { toast } from "sonner";

export default function SecurityPage() {
    const [metrics, setMetrics] = useState(null);
    const [loading, setLoading] = useState(true);
    const [unlockEmail, setUnlockEmail] = useState("");
    const [unlockSlug, setUnlockSlug] = useState("");
    const [unlocking, setUnlocking] = useState(false);

    const handleUnlock = async (e) => {
        e.preventDefault();
        if (!unlockEmail.trim()) { toast.error("Informe o e-mail."); return; }
        setUnlocking(true);
        try {
            const { data } = await api.post("/super-admin/system/unlock-user", {
                email: unlockEmail.trim(),
                tenant_slug: unlockSlug.trim(),
            });
            toast.success(data.message);
            setUnlockEmail("");
            setUnlockSlug("");
        } catch (err) {
            toast.error(err?.response?.data?.detail || "Erro ao desbloquear.");
        } finally {
            setUnlocking(false);
        }
    };

    const load = async () => {
        setLoading(true);
        try {
            const { data } = await api.get("/admin/system/metrics");
            setMetrics(data);
        } catch {
            setMetrics(null);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        load();
    }, []);

    const stats = [
        {
            label: "Tenants Ativos",
            value: metrics?.tenants?.active ?? "—",
            icon: ShieldCheck,
            sub: `de ${metrics?.tenants?.total ?? "—"} total`,
        },
        {
            label: "Usuários Ativos",
            value: metrics?.users?.active ?? "—",
            icon: Users,
            sub: `de ${metrics?.users?.total ?? "—"} total`,
        },
        {
            label: "Sessões Ativas",
            value: metrics?.sessions?.active ?? "—",
            icon: Activity,
            sub: `de ${metrics?.sessions?.total ?? "—"} total`,
        },
        {
            label: "Mismatch (24h)",
            value: metrics?.last_24h?.tenant_session_mismatch ?? "—",
            icon: AlertTriangle,
            sub: "TENANT_SESSION_MISMATCH",
            alert: (metrics?.last_24h?.tenant_session_mismatch ?? 0) > 0,
        },
    ];

    return (
        <div className="space-y-6">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-semibold" data-testid="security-page-title">Painel de Segurança</h1>
                    <p className="text-sm text-muted-foreground mt-1">
                        Visão geral — apenas Super Admin
                    </p>
                </div>
                <Button variant="outline" size="sm" onClick={load} disabled={loading} data-testid="security-refresh-btn">
                    <RefreshCw size={14} className={`mr-2 ${loading ? "animate-spin" : ""}`} />
                    Atualizar
                </Button>
            </div>

            {/* Métricas */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {stats.map((s) => (
                    <Card key={s.label} className={s.alert ? "border-destructive/50" : ""}>
                        <CardHeader className="flex flex-row items-center justify-between pb-2 pt-4 px-4">
                            <CardTitle className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                                {s.label}
                            </CardTitle>
                            <s.icon size={16} className={s.alert ? "text-destructive" : "text-muted-foreground"} />
                        </CardHeader>
                        <CardContent className="px-4 pb-4">
                            <p className={`text-2xl font-bold ${s.alert ? "text-destructive" : ""}`}>{s.value}</p>
                            <p className="text-xs text-muted-foreground mt-1">{s.sub}</p>
                        </CardContent>
                    </Card>
                ))}
            </div>

            {/* Stats 24h */}
            <Card>
                <CardHeader className="pb-2">
                    <CardTitle className="text-sm">Últimas 24 horas</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        {[
                            { label: "Logins com sucesso", value: metrics?.last_24h?.logins_success ?? "—", color: "text-luppa-green" },
                            { label: "Logins falhos", value: metrics?.last_24h?.logins_failed ?? "—", color: "text-luppa-warning" },
                            { label: "Rate limit atingido", value: metrics?.last_24h?.rate_limit_exceeded ?? "—", color: "text-luppa-warning" },
                            { label: "Cross-tenant blocks", value: metrics?.last_24h?.tenant_session_mismatch ?? "—", color: "text-luppa-error" },
                        ].map((s) => (
                            <div key={s.label} className="text-center p-3 rounded-md bg-muted/50">
                                <p className={`text-xl font-bold ${s.color}`}>{s.value}</p>
                                <p className="text-xs text-muted-foreground mt-1">{s.label}</p>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>

            {/* Desbloquear conta */}
            <Card>
                <CardHeader className="pb-3">
                    <CardTitle className="text-sm flex items-center gap-2">
                        <Unlock size={15} className="text-muted-foreground" />
                        Desbloquear Conta
                    </CardTitle>
                    <p className="text-xs text-muted-foreground">
                        Remove o bloqueio por tentativas de login excessivas sem precisar reiniciar o servidor.
                    </p>
                </CardHeader>
                <CardContent>
                    <form onSubmit={handleUnlock} className="flex flex-col sm:flex-row gap-3 items-end">
                        <div className="flex-1 space-y-1">
                            <Label className="text-xs" htmlFor="unlock-email">E-mail do usuário *</Label>
                            <Input
                                id="unlock-email"
                                data-testid="unlock-email-input"
                                type="email"
                                placeholder="usuario@empresa.com"
                                value={unlockEmail}
                                onChange={(e) => setUnlockEmail(e.target.value)}
                            />
                        </div>
                        <div className="w-full sm:w-52 space-y-1">
                            <Label className="text-xs" htmlFor="unlock-slug">Tenant slug (opcional)</Label>
                            <Input
                                id="unlock-slug"
                                data-testid="unlock-slug-input"
                                placeholder="ex: mpconsulting"
                                value={unlockSlug}
                                onChange={(e) => setUnlockSlug(e.target.value)}
                            />
                        </div>
                        <Button
                            type="submit"
                            size="sm"
                            disabled={unlocking || !unlockEmail.trim()}
                            data-testid="unlock-user-btn"
                            className="gap-2"
                        >
                            <Unlock size={14} />
                            {unlocking ? "Desbloqueando…" : "Desbloquear"}
                        </Button>
                    </form>
                </CardContent>
            </Card>

            {/* Links para subpáginas */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {[
                    { to: "/super-admin/security/events", label: "Eventos de Segurança", desc: "Logs de login, mismatch, rate limit…", testId: "nav-security-events" },
                    { to: "/super-admin/security/sessions", label: "Sessões Ativas", desc: "Visualizar e revogar sessões de usuários.", testId: "nav-security-sessions" },
                    { to: "/super-admin/security/mfa", label: "Configuração MFA", desc: "Gerenciar MFA do Super Admin (TOTP).", testId: "nav-security-mfa" },
                ].map((l) => (
                    <Card key={l.to} className="hover:shadow-md transition-shadow cursor-pointer">
                        <Link to={l.to} data-testid={l.testId}>
                            <CardContent className="p-5">
                                <p className="font-medium text-sm">{l.label}</p>
                                <p className="text-xs text-muted-foreground mt-1">{l.desc}</p>
                            </CardContent>
                        </Link>
                    </Card>
                ))}
            </div>
        </div>
    );
}
