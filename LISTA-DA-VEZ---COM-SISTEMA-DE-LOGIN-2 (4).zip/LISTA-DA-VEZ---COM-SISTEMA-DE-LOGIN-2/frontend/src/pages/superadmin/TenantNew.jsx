/**
 * TenantNew — Cadastro de empresa pelo Super Admin.
 *
 * Atualizado (Prompt 5):
 *  - Campo admin_password REMOVIDO (fluxo via convite por e-mail).
 *  - CNPJ com máscara 00.000.000/0000-00 e validação client-side do dígito verificador.
 *  - Após sucesso exibe banner: "Convite enviado para {email}".
 */
import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api, { extractError } from "@/lib/api";
import { PageHeader } from "@/components/Common";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
    Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CheckCircle, AlertTriangle, Mail } from "lucide-react";

// ─── CNPJ helpers ─────────────────────────────────────────────────────────────

function maskCNPJ(v) {
    const d = v.replace(/\D/g, "").slice(0, 14);
    return d
        .replace(/^(\d{2})(\d)/, "$1.$2")
        .replace(/^(\d{2})\.(\d{3})(\d)/, "$1.$2.$3")
        .replace(/\.(\d{3})(\d)/, ".$1/$2")
        .replace(/(\d{4})(\d)/, "$1-$2");
}

function validateCNPJ(cnpj) {
    const n = cnpj.replace(/\D/g, "");
    if (n.length !== 14) return false;
    if (/^(\d)\1+$/.test(n)) return false;

    let s = 0, w = 5;
    for (let i = 0; i < 12; i++) {
        s += parseInt(n[i]) * w;
        w = w === 2 ? 9 : w - 1;
    }
    const d1 = s % 11 < 2 ? 0 : 11 - (s % 11);
    if (d1 !== parseInt(n[12])) return false;

    s = 0; w = 6;
    for (let i = 0; i < 13; i++) {
        s += parseInt(n[i]) * w;
        w = w === 2 ? 9 : w - 1;
    }
    const d2 = s % 11 < 2 ? 0 : 11 - (s % 11);
    return d2 === parseInt(n[13]);
}

// ─── Component ────────────────────────────────────────────────────────────────

export default function TenantNew() {
    const nav = useNavigate();
    const [plans, setPlans] = useState([]);
    const [form, setForm] = useState({
        name: "",
        slug: "",
        email: "",
        phone: "",
        cnpj: "",
        plan_id: "",
        admin_name: "",
        admin_email: "",
    });
    const [cnpjRaw, setCnpjRaw] = useState("");
    const [cnpjError, setCnpjError] = useState(null);
    const [err, setErr] = useState(null);
    const [loading, setLoading] = useState(false);
    const [success, setSuccess] = useState(null); // { adminEmail, tenantName }

    useEffect(() => {
        api.get("/super-admin/plans").then(({ data }) => setPlans(data));
    }, []);

    const setF = (k, v) => setForm((p) => ({ ...p, [k]: v }));

    const handleCnpj = (raw) => {
        const masked = maskCNPJ(raw);
        setCnpjRaw(masked);
        const digits = masked.replace(/\D/g, "");
        setF("cnpj", digits); // enviar apenas dígitos ao backend
        if (digits.length === 14 && !validateCNPJ(masked)) {
            setCnpjError("CNPJ inválido. Verifique os dígitos informados.");
        } else {
            setCnpjError(null);
        }
    };

    const submit = async (e) => {
        e.preventDefault();
        // Validação CNPJ obrigatória antes de enviar
        if (form.cnpj && !validateCNPJ(cnpjRaw)) {
            setCnpjError("CNPJ inválido.");
            return;
        }
        if (!form.admin_email) {
            setErr("E-mail do responsável é obrigatório.");
            return;
        }
        setErr(null);
        setLoading(true);
        try {
            const payload = { ...form };
            Object.keys(payload).forEach((k) => {
                if (payload[k] === "") delete payload[k];
            });
            await api.post("/super-admin/tenants", payload);
            setSuccess({ adminEmail: form.admin_email, tenantName: form.name });
        } catch (e) {
            setErr(extractError(e, "Erro ao criar empresa"));
            setLoading(false);
        }
    };

    if (success) {
        return (
            <div>
                <PageHeader eyebrow="Cadastros" title="Empresa cadastrada" />
                <Card className="border border-border shadow-sm max-w-xl">
                    <CardContent className="p-8 flex flex-col items-center gap-5 text-center">
                        <div className="w-14 h-14 rounded-full bg-luppa-green/10 border border-emerald-200 flex items-center justify-center">
                            <Mail size={26} className="text-luppa-green" strokeWidth={1.5} />
                        </div>
                        <div className="space-y-1">
                            <h2 className="font-semibold text-lg">Convite enviado!</h2>
                            <p className="text-muted-foreground text-sm max-w-sm">
                                A empresa <strong>{success.tenantName}</strong> foi cadastrada.
                                Um convite foi enviado para{" "}
                                <strong className="font-mono">{success.adminEmail}</strong>.
                            </p>
                            <p className="text-muted-foreground text-sm mt-2">
                                A empresa será ativada quando o responsável definir sua senha.
                            </p>
                        </div>
                        <div className="flex gap-2 pt-2">
                            <Link to="/super-admin/tenants">
                                <Button variant="outline">Ver empresas</Button>
                            </Link>
                            <Button
                                data-testid="create-another-tenant-btn"
                                onClick={() => {
                                    setSuccess(null);
                                    setForm({ name: "", slug: "", email: "", phone: "", cnpj: "", plan_id: "", admin_name: "", admin_email: "" });
                                    setCnpjRaw("");
                                }}
                            >
                                Cadastrar outra empresa
                            </Button>
                        </div>
                    </CardContent>
                </Card>
            </div>
        );
    }

    return (
        <div>
            <PageHeader
                eyebrow="Cadastros"
                title="Nova empresa"
                description="Cadastre a empresa e envie um convite ao responsável para ativar a conta."
            />
            <Card className="border border-border shadow-sm max-w-3xl">
                <CardContent className="p-6">
                    <form onSubmit={submit} className="grid grid-cols-1 md:grid-cols-2 gap-5">
                        {err && (
                            <div className="md:col-span-2">
                                <Alert variant="destructive">
                                    <AlertTriangle size={15} className="mr-1 inline" />
                                    <AlertDescription data-testid="new-tenant-error">{err}</AlertDescription>
                                </Alert>
                            </div>
                        )}

                        <Field label="Razão Social *">
                            <Input
                                value={form.name}
                                onChange={(e) => setF("name", e.target.value)}
                                placeholder="Nome da empresa"
                                required
                                data-testid="tenant-name-input"
                            />
                        </Field>

                        <Field label="Slug (URL) *">
                            <Input
                                value={form.slug}
                                onChange={(e) => setF("slug", e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ""))}
                                pattern="[a-z0-9-]+"
                                placeholder="ex: minha-empresa"
                                required
                                data-testid="tenant-slug-input"
                            />
                            <p className="text-xs text-muted-foreground">Apenas letras minúsculas, números e hífen.</p>
                        </Field>

                        <Field label="CNPJ">
                            <Input
                                value={cnpjRaw}
                                onChange={(e) => handleCnpj(e.target.value)}
                                placeholder="00.000.000/0000-00"
                                inputMode="numeric"
                                data-testid="tenant-cnpj-input"
                            />
                            {cnpjError && (
                                <p className="text-xs text-luppa-error flex items-center gap-1">
                                    <AlertTriangle size={11} /> {cnpjError}
                                </p>
                            )}
                            {form.cnpj.length === 14 && !cnpjError && (
                                <p className="text-xs text-luppa-green flex items-center gap-1">
                                    <CheckCircle size={11} /> CNPJ válido
                                </p>
                            )}
                        </Field>

                        <Field label="Telefone">
                            <Input
                                value={form.phone}
                                onChange={(e) => setF("phone", e.target.value)}
                                placeholder="(11) 9 9999-9999"
                                data-testid="tenant-phone-input"
                            />
                        </Field>

                        <Field label="E-mail da empresa">
                            <Input
                                type="email"
                                value={form.email}
                                onChange={(e) => setF("email", e.target.value)}
                                placeholder="contato@empresa.com.br"
                                data-testid="tenant-email-input"
                            />
                        </Field>

                        <Field label="Plano">
                            <Select value={form.plan_id} onValueChange={(v) => setF("plan_id", v)}>
                                <SelectTrigger data-testid="tenant-plan-select">
                                    <SelectValue placeholder="Selecione…" />
                                </SelectTrigger>
                                <SelectContent>
                                    {plans.map((p) => (
                                        <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </Field>

                        {/* Responsável (sem senha) */}
                        <div className="md:col-span-2 mt-2 pt-4 border-t border-border">
                            <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground mb-3">
                                Responsável pela ativação
                            </p>
                            <p className="text-xs text-muted-foreground mb-4">
                                O responsável receberá um convite por e-mail para definir a senha e ativar a empresa.
                            </p>
                        </div>

                        <Field label="Nome do responsável">
                            <Input
                                value={form.admin_name}
                                onChange={(e) => setF("admin_name", e.target.value)}
                                placeholder="Nome completo"
                                data-testid="admin-name-input"
                            />
                        </Field>

                        <Field label="E-mail do responsável *">
                            <Input
                                type="email"
                                value={form.admin_email}
                                onChange={(e) => setF("admin_email", e.target.value)}
                                placeholder="responsavel@empresa.com.br"
                                required
                                data-testid="admin-email-input"
                            />
                        </Field>

                        <div className="md:col-span-2 flex justify-end gap-2 pt-4">
                            <Button
                                type="button"
                                variant="outline"
                                onClick={() => nav("/super-admin/tenants")}
                            >
                                Cancelar
                            </Button>
                            <Button
                                type="submit"
                                disabled={loading || !!cnpjError}
                                data-testid="create-tenant-submit"
                            >
                                {loading ? "Cadastrando…" : "Cadastrar e enviar convite"}
                            </Button>
                        </div>
                    </form>
                </CardContent>
            </Card>
        </div>
    );
}

function Field({ label, children }) {
    return (
        <div className="space-y-1.5">
            <Label>{label}</Label>
            {children}
        </div>
    );
}
