import React, { useEffect, useState } from "react";
import api, { extractError } from "@/lib/api";
import { PageHeader } from "@/components/Common";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
    DialogFooter,
} from "@/components/ui/dialog";
import { Plus } from "lucide-react";
import { toast } from "sonner";

export default function FeaturesList() {
    const [features, setFeatures] = useState([]);
    const [open, setOpen] = useState(false);
    const [form, setForm] = useState({ key: "", name: "", description: "" });
    const [saving, setSaving] = useState(false);

    const load = async () => {
        const { data } = await api.get("/super-admin/features");
        setFeatures(data);
    };
    useEffect(() => {
        load();
    }, []);

    const submit = async (e) => {
        e.preventDefault();
        if (saving) return;
        setSaving(true);
        try {
            await api.post("/super-admin/features", form);
            toast.success("Funcionalidade criada.");
            setForm({ key: "", name: "", description: "" });
            setOpen(false);
            load();
        } catch (e) {
            toast.error(extractError(e, "Erro ao criar funcionalidade"));
        } finally {
            setSaving(false);
        }
    };

    return (
        <div>
            <PageHeader eyebrow="Catálogo" title="Funcionalidades" description="Catálogo global de funcionalidades.">
                <Dialog open={open} onOpenChange={setOpen}>
                    <DialogTrigger asChild>
                        <Button data-testid="new-feature-button" className="gap-2">
                            <Plus size={16} strokeWidth={1.5} /> Nova funcionalidade
                        </Button>
                    </DialogTrigger>
                    <DialogContent>
                        <DialogHeader>
                            <DialogTitle>Nova funcionalidade</DialogTitle>
                        </DialogHeader>
                        <form onSubmit={submit} className="space-y-4">
                            <div className="space-y-2">
                                <Label>Chave</Label>
                                <Input value={form.key} onChange={(e) => setForm({ ...form, key: e.target.value })} required data-testid="feature-key-input" />
                            </div>
                            <div className="space-y-2">
                                <Label>Nome</Label>
                                <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required data-testid="feature-name-input" />
                            </div>
                            <div className="space-y-2">
                                <Label>Descrição</Label>
                                <Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} data-testid="feature-desc-input" />
                            </div>
                            <DialogFooter>
                                <Button type="submit" disabled={saving} data-testid="feature-submit">{saving ? "Criando…" : "Criar"}</Button>
                            </DialogFooter>
                        </form>
                    </DialogContent>
                </Dialog>
            </PageHeader>
            <Card className="border border-border shadow-sm">
                <CardContent className="p-0 divide-y divide-border">
                    {features.map((f) => (
                        <div key={f.id} className="p-5" data-testid={`feature-list-${f.key}`}>
                            <div className="flex items-center gap-3">
                                <p className="font-mono text-xs px-2 py-1 bg-muted rounded-sm">{f.key}</p>
                                <p className="font-medium">{f.name}</p>
                            </div>
                            <p className="text-xs text-muted-foreground mt-2">{f.description}</p>
                        </div>
                    ))}
                </CardContent>
            </Card>
        </div>
    );
}
