import React, { useEffect, useState } from "react";
import { RefreshCw, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import api from "@/lib/api";
import { toast } from "sonner";
import { fmtDateTime, fmtDate } from "@/lib/i18n";

export default function SessionsPage() {
    const [sessions, setSessions] = useState([]);
    const [loading, setLoading] = useState(true);
    const [revoking, setRevoking] = useState(null);

    const load = async () => {
        setLoading(true);
        try {
            const { data } = await api.get("/admin/security/sessions?active_only=true&limit=200");
            setSessions(data);
        } catch {
            setSessions([]);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        load();
    }, []);

    const revoke = async (sessionId) => {
        if (!window.confirm("Revogar esta sessão?")) return;
        setRevoking(sessionId);
        try {
            await api.post(`/admin/security/sessions/${sessionId}/revoke`);
            toast.success("Sessão revogada.");
            await load();
        } catch {
            toast.error("Falha ao revogar sessão.");
        } finally {
            setRevoking(null);
        }
    };

    return (
        <div className="space-y-5">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-semibold" data-testid="sessions-page-title">Sessões Ativas</h1>
                    <p className="text-sm text-muted-foreground mt-1">{sessions.length} sessões ativas</p>
                </div>
                <Button variant="outline" size="sm" onClick={load} disabled={loading} data-testid="sessions-refresh-btn">
                    <RefreshCw size={14} className={loading ? "animate-spin" : ""} />
                </Button>
            </div>

            <div className="rounded-md border overflow-hidden">
                <div className="overflow-x-auto">
                <table className="w-full text-xs min-w-[640px]">
                    <thead className="bg-muted/50">
                        <tr>
                            <th className="px-3 py-2 text-left font-medium text-muted-foreground">Contexto</th>
                            <th className="px-3 py-2 text-left font-medium text-muted-foreground">Tenant</th>
                            <th className="px-3 py-2 text-left font-medium text-muted-foreground">Role</th>
                            <th className="px-3 py-2 text-left font-medium text-muted-foreground">IP</th>
                            <th className="px-3 py-2 text-left font-medium text-muted-foreground">Criada em</th>
                            <th className="px-3 py-2 text-left font-medium text-muted-foreground">Expira em</th>
                            <th className="px-3 py-2"></th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                        {sessions.length === 0 && (
                            <tr>
                                <td colSpan={7} className="px-3 py-6 text-center text-muted-foreground">
                                    {loading ? "Carregando…" : "Nenhuma sessão ativa."}
                                </td>
                            </tr>
                        )}
                        {sessions.map((s) => (
                            <tr key={s.id} className="hover:bg-muted/30" data-testid={`session-row-${s.id}`}>
                                <td className="px-3 py-2">
                                    <Badge variant={s.auth_context === "SUPER_ADMIN" ? "default" : "secondary"}>
                                        {s.auth_context}
                                    </Badge>
                                </td>
                                <td className="px-3 py-2 text-muted-foreground">{s.tenant_slug || "—"}</td>
                                <td className="px-3 py-2 text-muted-foreground">{s.role || "—"}</td>
                                <td className="px-3 py-2 font-mono text-muted-foreground">{s.ip || "—"}</td>
                                <td className="px-3 py-2 text-muted-foreground">
                                    {s.created_at ? fmtDateTime(s.created_at) : "—"}
                                </td>
                                <td className="px-3 py-2 text-muted-foreground">
                                    {s.expires_at ? fmtDate(s.expires_at) : "—"}
                                </td>
                                <td className="px-3 py-2">
                                    <Button
                                        variant="ghost"
                                        size="sm"
                                        className="h-6 px-2 text-destructive hover:text-destructive"
                                        onClick={() => revoke(s.id)}
                                        disabled={revoking === s.id}
                                        data-testid={`revoke-session-btn-${s.id}`}
                                    >
                                        <XCircle size={14} className="mr-1" />
                                        {revoking === s.id ? "…" : "Revogar"}
                                    </Button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    );
}
