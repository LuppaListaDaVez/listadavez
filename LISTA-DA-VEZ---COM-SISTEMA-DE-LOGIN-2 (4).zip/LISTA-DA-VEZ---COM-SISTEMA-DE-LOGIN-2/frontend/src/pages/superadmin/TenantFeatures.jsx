import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import api from "@/lib/api";
import { PageHeader } from "@/components/Common";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";

export default function TenantFeatures() {
    const { tenantId } = useParams();
    const [features, setFeatures] = useState([]);
    const [tenant, setTenant] = useState(null);
    const [saving, setSaving] = useState(false);

    const load = async () => {
        const [t, f] = await Promise.all([
            api.get(`/super-admin/tenants/${tenantId}`),
            api.get(`/super-admin/tenants/${tenantId}/features`),
        ]);
        setTenant(t.data);
        setFeatures(f.data);
    };

    useEffect(() => {
        load();
    }, [tenantId]);

    const toggle = (key, enabled) => {
        setFeatures((prev) =>
            prev.map((f) => (f.feature_key === key ? { ...f, enabled } : f)),
        );
    };

    const allEnabled = features.length > 0 && features.every((f) => f.enabled);
    const toggleAll = () => {
        const next = !allEnabled;
        setFeatures((prev) => prev.map((f) => ({ ...f, enabled: next })));
    };

    const save = async () => {
        setSaving(true);
        try {
            const payload = {
                features: features.map((f) => ({ feature_key: f.feature_key, enabled: f.enabled })),
            };
            const { data } = await api.patch(`/super-admin/tenants/${tenantId}/features`, payload);
            setFeatures(data);
            toast.success("Funcionalidades atualizadas.");
        } catch {
            toast.error("Erro ao salvar.");
        } finally {
            setSaving(false);
        }
    };

    if (!tenant) return <p className="text-sm text-muted-foreground">Carregando…</p>;

    return (
        <div>
            <PageHeader
                eyebrow={`Empresa /${tenant.slug}`}
                title={`Funcionalidades de ${tenant.name}`}
                description="Ative ou desative módulos específicos para esta empresa."
            >
                <Link to="/super-admin/tenants">
                    <Button variant="outline">Voltar</Button>
                </Link>
                <Button onClick={save} disabled={saving} data-testid="save-features-button">
                    {saving ? "Salvando…" : "Salvar alterações"}
                </Button>
            </PageHeader>
            <Card className="border border-border shadow-sm">
                <CardContent className="p-0 divide-y divide-border">
                    {/* Linha "Selecionar todos" */}
                    <div className="flex items-center justify-between px-5 py-3 bg-muted/40">
                        <p className="text-sm font-medium text-muted-foreground">
                            {allEnabled ? "Desativar todas" : "Ativar todas"}
                        </p>
                        <Switch
                            checked={allEnabled}
                            onCheckedChange={toggleAll}
                            data-testid="feature-toggle-all"
                        />
                    </div>
                    {features.map((f) => (
                        <div
                            key={f.feature_key}
                            className="flex items-center justify-between p-5"
                            data-testid={`feature-row-${f.feature_key}`}
                        >
                            <div>
                                <p className="font-medium text-sm">{f.name}</p>
                                <p className="text-xs text-muted-foreground mt-1">
                                    {f.description || f.feature_key}
                                </p>
                            </div>
                            <Switch
                                checked={f.enabled}
                                onCheckedChange={(v) => toggle(f.feature_key, v)}
                                data-testid={`feature-toggle-${f.feature_key}`}
                            />
                        </div>
                    ))}
                </CardContent>
            </Card>
        </div>
    );
}
