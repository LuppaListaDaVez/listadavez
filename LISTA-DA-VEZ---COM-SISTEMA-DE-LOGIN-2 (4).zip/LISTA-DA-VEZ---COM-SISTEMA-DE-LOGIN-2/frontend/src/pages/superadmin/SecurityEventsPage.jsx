import React, { useEffect, useState } from "react";
import { RefreshCw, Filter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import api from "@/lib/api";
import { SEVERITY_PT, fmtDateTime } from "@/lib/i18n";

const SEVERITY_COLORS = {
    INFO: "secondary",
    WARNING: "outline",
    CRITICAL: "destructive",
};

const EVENT_TYPE_PT = {
    LOGIN_FAILED:                  "Login — tentativa inválida",
    LOGIN_SUCCESS:                 "Login — acesso bem-sucedido",
    TENANT_SESSION_MISMATCH:       "Sessão — empresa incompatível",
    RATE_LIMIT_EXCEEDED:           "Taxa de requisições excedida",
    REFRESH_TOKEN_REUSE_DETECTED:  "Token reutilizado (suspeito)",
    LOGOUT:                        "Saída do sistema",
};

export default function SecurityEventsPage() {
    const [events, setEvents] = useState([]);
    const [loading, setLoading] = useState(true);
    const [severity, setSeverity] = useState("all");
    const [eventType, setEventType] = useState("all");

    const load = async () => {
        setLoading(true);
        try {
            const params = new URLSearchParams({ limit: 200 });
            if (severity !== "all") params.set("severity", severity);
            if (eventType !== "all") params.set("event_type", eventType);
            const { data } = await api.get(`/admin/security/events?${params}`);
            setEvents(data);
        } catch {
            setEvents([]);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        load();
    }, [severity, eventType]);

    return (
        <div className="space-y-5">
            <div className="flex items-center justify-between flex-wrap gap-3">
                <div>
                    <h1 className="text-2xl font-semibold" data-testid="security-events-title">Eventos de Segurança</h1>
                    <p className="text-sm text-muted-foreground mt-1">{events.length} registros</p>
                </div>
                <div className="flex items-center gap-2">
                    <Select value={severity} onValueChange={setSeverity}>
                        <SelectTrigger className="w-36 h-8 text-xs" data-testid="filter-severity">
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">Severidade</SelectItem>
                            <SelectItem value="INFO">Informação</SelectItem>
                            <SelectItem value="WARNING">Aviso</SelectItem>
                            <SelectItem value="CRITICAL">Crítico</SelectItem>
                        </SelectContent>
                    </Select>
                    <Select value={eventType} onValueChange={setEventType}>
                        <SelectTrigger className="w-52 h-8 text-xs" data-testid="filter-event-type">
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all">Todos os tipos</SelectItem>
                            <SelectItem value="LOGIN_FAILED">Login — tentativa inválida</SelectItem>
                            <SelectItem value="LOGIN_SUCCESS">Login — acesso bem-sucedido</SelectItem>
                            <SelectItem value="TENANT_SESSION_MISMATCH">Sessão — empresa incompatível</SelectItem>
                            <SelectItem value="RATE_LIMIT_EXCEEDED">Taxa de requisições excedida</SelectItem>
                            <SelectItem value="REFRESH_TOKEN_REUSE_DETECTED">Token reutilizado (suspeito)</SelectItem>
                            <SelectItem value="LOGOUT">Saída do sistema</SelectItem>
                        </SelectContent>
                    </Select>
                    <Button variant="outline" size="sm" onClick={load} disabled={loading} data-testid="events-refresh-btn">
                        <RefreshCw size={14} className={loading ? "animate-spin" : ""} />
                    </Button>
                </div>
            </div>

            <div className="rounded-md border overflow-hidden">
                <div className="overflow-x-auto">
                <table className="w-full text-xs min-w-[560px]">
                    <thead className="bg-muted/50">
                        <tr>
                            <th className="px-3 py-2 text-left font-medium text-muted-foreground">Tipo</th>
                            <th className="px-3 py-2 text-left font-medium text-muted-foreground">Severidade</th>
                            <th className="px-3 py-2 text-left font-medium text-muted-foreground">Tenant</th>
                            <th className="px-3 py-2 text-left font-medium text-muted-foreground">IP</th>
                            <th className="px-3 py-2 text-left font-medium text-muted-foreground">Data</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                        {events.length === 0 && (
                            <tr>
                                <td colSpan={5} className="px-3 py-6 text-center text-muted-foreground">
                                    {loading ? "Carregando…" : "Nenhum evento encontrado."}
                                </td>
                            </tr>
                        )}
                        {events.map((ev) => (
                            <tr key={ev.id} className="hover:bg-muted/30" data-testid={`security-event-row-${ev.id}`}>
                                <td className="px-3 py-2 font-mono">{EVENT_TYPE_PT[ev.event_type] || ev.event_type}</td>
                                <td className="px-3 py-2">
                                    <Badge variant={SEVERITY_COLORS[ev.severity] || "secondary"}>
                                        {SEVERITY_PT[ev.severity] || ev.severity}
                                    </Badge>
                                </td>
                                <td className="px-3 py-2 text-muted-foreground">{ev.tenant_slug || "—"}</td>
                                <td className="px-3 py-2 text-muted-foreground font-mono">{ev.ip || "—"}</td>
                                <td className="px-3 py-2 text-muted-foreground">
                                    {ev.created_at ? fmtDateTime(ev.created_at) : "—"}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    );
}
