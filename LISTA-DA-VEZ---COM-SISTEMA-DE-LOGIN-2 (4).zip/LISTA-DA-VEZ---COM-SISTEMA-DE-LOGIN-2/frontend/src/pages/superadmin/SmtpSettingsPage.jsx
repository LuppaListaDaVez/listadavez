/**
 * SmtpSettingsPage — Configuração de e-mail SMTP pelo Super Admin.
 *
 * Rota: /super-admin/settings/email
 *
 * Funcionalidades:
 *  - Mostra status atual (configurado via banco ou env vars)
 *  - Formulário com todos os campos SMTP
 *  - Botões de preenchimento rápido por provedor (Gmail, Outlook, M365, Zoho, etc.)
 *  - Salvar configuração no banco de dados
 *  - Remover configuração do banco (volta para env vars)
 *  - Enviar e-mail de teste sem salvar primeiro
 */
import React, { useEffect, useState } from "react";
import api, { extractError } from "@/lib/api";
import { PageHeader } from "@/components/Common";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import {
    CheckCircle, AlertTriangle, Eye, EyeOff, Mail, Send, Trash2,
    RefreshCw, Zap,
} from "lucide-react";

// ─── Provedores populares com preenchimento rápido ────────────────────────────
const PROVIDERS = [
    { label: "Gmail",        host: "smtp.gmail.com",          port: 587, secure: false },
    { label: "Outlook",      host: "smtp-mail.outlook.com",   port: 587, secure: false },
    { label: "Microsoft 365",host: "smtp.office365.com",      port: 587, secure: false },
    { label: "Zoho",         host: "smtp.zoho.com",           port: 587, secure: false },
    { label: "Hostinger",    host: "smtp.hostinger.com",      port: 587, secure: false },
    { label: "Locaweb",      host: "email-ssl.com.br",        port: 587, secure: false },
];

const EMPTY_FORM = {
    smtp_host:   "",
    smtp_port:   587,
    smtp_secure: false,
    smtp_user:   "",
    smtp_pass:   "",
    smtp_from:   "",
};

export default function SmtpSettingsPage() {
    const [form, setForm]           = useState(EMPTY_FORM);
    const [showPass, setShowPass]   = useState(false);
    const [source, setSource]       = useState(null); // "database" | "environment" | null
    const [loading, setLoading]     = useState(true);
    const [saving, setSaving]       = useState(false);
    const [testEmail, setTestEmail] = useState("");
    const [testing, setTesting]     = useState(false);
    const [testResult, setTestResult] = useState(null); // { success, message }

    const setF = (k, v) => setForm((p) => ({ ...p, [k]: v }));

    const load = async () => {
        setLoading(true);
        try {
            const { data } = await api.get("/super-admin/system/smtp-config");
            setSource(data.source);
            setForm({
                smtp_host:   data.smtp_host   || "",
                smtp_port:   data.smtp_port   || 587,
                smtp_secure: data.smtp_secure || false,
                smtp_user:   data.smtp_user   || "",
                smtp_pass:   data.smtp_pass   || "", // "****" se configurada
                smtp_from:   data.smtp_from   || "",
            });
        } catch {
            toast.error("Erro ao carregar configuração.");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => { load(); }, []);

    const isConfigured = !!(form.smtp_host && form.smtp_user && form.smtp_pass);

    const quickFill = (p) => {
        setF("smtp_host", p.host);
        setF("smtp_port", p.port);
        setF("smtp_secure", p.secure);
        setTestResult(null);
    };

    const save = async () => {
        if (!form.smtp_host) { toast.error("Informe o servidor SMTP."); return; }
        if (!form.smtp_user) { toast.error("Informe o usuário SMTP."); return; }
        if (!form.smtp_from) { toast.error("Informe o endereço de envio."); return; }
        if (!form.smtp_pass || form.smtp_pass === "****") {
            // Senha não alterada — OK se já havia uma salva
            if (source !== "database") {
                toast.error("Informe a senha SMTP para salvar."); return;
            }
        }
        setSaving(true);
        try {
            await api.put("/super-admin/system/smtp-config", form);
            toast.success("Configuração SMTP salva no banco de dados.");
            setTestResult(null);
            load();
        } catch (e) {
            toast.error(extractError(e, "Erro ao salvar configuração."));
        } finally {
            setSaving(false);
        }
    };

    const remove = async () => {
        if (!window.confirm("Remover configuração do banco? O sistema voltará a usar as variáveis de ambiente.")) return;
        try {
            await api.delete("/super-admin/system/smtp-config");
            toast.success("Configuração removida.");
            setSource("environment");
            setTestResult(null);
            load();
        } catch (e) {
            toast.error(extractError(e, "Erro ao remover configuração."));
        }
    };

    const sendTest = async () => {
        if (!testEmail) { toast.error("Informe o e-mail de destino para o teste."); return; }
        if (!form.smtp_host) { toast.error("Configure o servidor SMTP antes de testar."); return; }
        setTesting(true);
        setTestResult(null);
        try {
            const { data } = await api.post("/super-admin/system/smtp-config/test", {
                config: form,
                test_email: testEmail,
            });

            // Detectar erro de credenciais e mostrar instrução específica
            if (!data.success && (data.message?.includes("535") || data.message?.toLowerCase().includes("badcred") || data.message?.toLowerCase().includes("username and password"))) {
                setTestResult({
                    success: false,
                    message: `Credenciais incorretas (535 BadCredentials). Para Gmail/Outlook, você precisa usar uma Senha de App — não a senha normal da conta. Clique no link abaixo para gerar uma.`,
                    isBadCreds: true,
                });
                toast.error("Credenciais SMTP inválidas.");
            } else {
                setTestResult(data);
                if (data.success) {
                    toast.success(`E-mail de teste enviado para ${testEmail}!`);
                } else {
                    toast.error("Falha ao enviar e-mail de teste.");
                }
            }
        } catch (e) {
            setTestResult({ success: false, message: extractError(e, "Erro ao testar.") });
        } finally {
            setTesting(false);
        }
    };

    if (loading) {
        return (
            <div>
                <PageHeader eyebrow="Configurações" title="E-mail (SMTP)" />
                <p className="text-sm text-muted-foreground">Carregando…</p>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <PageHeader
                eyebrow="Configurações"
                title="E-mail (SMTP)"
                description="Configure o serviço de envio de e-mails transacionais — convites, ativações e notificações."
            />

            {/* Status card */}
            <Card className="border border-border shadow-sm max-w-2xl">
                <CardContent className="p-5 flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                        {isConfigured ? (
                            <CheckCircle size={20} className="text-luppa-green shrink-0" />
                        ) : (
                            <AlertTriangle size={20} className="text-amber-500 shrink-0" />
                        )}
                        <div>
                            <p className="text-sm font-medium">
                                {isConfigured ? "SMTP configurado" : "SMTP não configurado"}
                            </p>
                            <p className="text-xs text-muted-foreground">
                                {isConfigured
                                    ? `${form.smtp_host} — enviando como ${form.smtp_from || form.smtp_user}`
                                    : "Os convites são apenas registrados em log, não enviados por e-mail."}
                            </p>
                        </div>
                    </div>
                    <div className="flex items-center gap-2">
                        <Badge variant={source === "database" ? "default" : "secondary"} className="text-xs">
                            {source === "database" ? "Banco" : "Env vars"}
                        </Badge>
                        {source === "database" && (
                            <Button
                                size="sm"
                                variant="ghost"
                                className="text-luppa-error hover:text-luppa-error gap-1.5 text-xs"
                                onClick={remove}
                                data-testid="remove-smtp-config-btn"
                            >
                                <Trash2 size={13} /> Remover
                            </Button>
                        )}
                    </div>
                </CardContent>
            </Card>

            {/* Formulário de configuração */}
            <Card className="border border-border shadow-sm max-w-2xl">
                <CardHeader className="px-6 py-4 border-b border-border">
                    <CardTitle className="text-sm font-semibold">Configuração SMTP</CardTitle>
                </CardHeader>
                <CardContent className="p-6 space-y-5">
                    {/* Quick-fill */}
                    <div className="space-y-2">
                        <Label className="text-xs text-muted-foreground uppercase tracking-wide">
                            Preencher automaticamente para
                        </Label>
                        <div className="flex flex-wrap gap-2">
                            {PROVIDERS.map((p) => (
                                <Button
                                    key={p.label}
                                    size="sm"
                                    variant="outline"
                                    className="gap-1.5 text-xs h-7"
                                    onClick={() => quickFill(p)}
                                    data-testid={`quickfill-${p.label.toLowerCase().replace(/\s/g, "-")}`}
                                >
                                    <Zap size={11} /> {p.label}
                                </Button>
                            ))}
                        </div>
                    </div>

                    <hr className="border-border" />

                    {/* Campos SMTP */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-1.5">
                            <Label htmlFor="smtp-host">
                                Servidor SMTP (SMTP_HOST) <span className="text-luppa-error">*</span>
                            </Label>
                            <Input
                                id="smtp-host"
                                placeholder="smtp.gmail.com"
                                value={form.smtp_host}
                                onChange={(e) => setF("smtp_host", e.target.value)}
                                data-testid="smtp-host-input"
                            />
                        </div>

                        <div className="space-y-1.5">
                            <Label htmlFor="smtp-port">Porta (SMTP_PORT)</Label>
                            <Input
                                id="smtp-port"
                                type="number"
                                placeholder="587"
                                value={form.smtp_port}
                                onChange={(e) => setF("smtp_port", parseInt(e.target.value) || 587)}
                                data-testid="smtp-port-input"
                            />
                        </div>

                        <div className="space-y-1.5">
                            <Label htmlFor="smtp-user">
                                Usuário (SMTP_USER) <span className="text-luppa-error">*</span>
                            </Label>
                            <Input
                                id="smtp-user"
                                type="email"
                                placeholder="seu@email.com"
                                value={form.smtp_user}
                                onChange={(e) => setF("smtp_user", e.target.value)}
                                data-testid="smtp-user-input"
                            />
                        </div>

                        <div className="space-y-1.5">
                            <Label htmlFor="smtp-pass">
                                Senha (SMTP_PASS) <span className="text-luppa-error">*</span>
                            </Label>
                            <div className="relative">
                                <Input
                                    id="smtp-pass"
                                    type={showPass ? "text" : "password"}
                                    placeholder={source === "database" ? "••••••••  (não alterada)" : "Senha ou App Password"}
                                    value={form.smtp_pass}
                                    onChange={(e) => setF("smtp_pass", e.target.value)}
                                    className="pr-10"
                                    data-testid="smtp-pass-input"
                                />
                                <button
                                    type="button"
                                    onClick={() => setShowPass((p) => !p)}
                                    className="absolute inset-y-0 right-3 flex items-center text-muted-foreground hover:text-foreground"
                                    aria-label={showPass ? "Ocultar" : "Mostrar"}
                                    tabIndex={-1}
                                >
                                    {showPass ? <EyeOff size={15} /> : <Eye size={15} />}
                                </button>
                            </div>
                            {/* Instrução clara sobre App Password */}
                            <div className="rounded-md bg-amber-50 border border-amber-200 p-3 space-y-1">
                                <p className="text-xs font-semibold text-amber-800">
                                    Gmail e Outlook exigem Senha de App — a senha normal NAO funciona via SMTP.
                                </p>
                                <p className="text-xs text-amber-700">
                                    <strong>Gmail:</strong>{" "}
                                    <a
                                        href="https://myaccount.google.com/apppasswords"
                                        target="_blank"
                                        rel="noreferrer"
                                        className="underline font-semibold"
                                    >
                                        myaccount.google.com/apppasswords
                                    </a>{" "}
                                    → gere uma senha para "Outro (nome personalizado)" → copie aqui.
                                </p>
                                <p className="text-xs text-amber-700">
                                    <strong>Outlook / M365:</strong> Configurações de Conta → Segurança →
                                    Verificação em duas etapas → Criar senha de aplicativo.
                                </p>
                            </div>
                        </div>

                        <div className="space-y-1.5 md:col-span-2">
                            <Label htmlFor="smtp-from">
                                Endereço de envio (SMTP_FROM) <span className="text-luppa-error">*</span>
                            </Label>
                            <Input
                                id="smtp-from"
                                type="email"
                                placeholder="noreply@suaempresa.com"
                                value={form.smtp_from}
                                onChange={(e) => setF("smtp_from", e.target.value)}
                                data-testid="smtp-from-input"
                            />
                        </div>

                        <div className="flex items-center gap-3 md:col-span-2 rounded-md border border-border px-3 py-2.5 bg-muted/30">
                            <Switch
                                id="smtp-secure"
                                checked={form.smtp_secure}
                                onCheckedChange={(v) => {
                                    setF("smtp_secure", v);
                                    setF("smtp_port", v ? 465 : 587);
                                }}
                                data-testid="smtp-secure-toggle"
                            />
                            <div>
                                <label htmlFor="smtp-secure" className="text-sm cursor-pointer font-medium select-none">
                                    SSL/TLS direto (SMTP_SECURE)
                                </label>
                                <p className="text-xs text-muted-foreground">
                                    {form.smtp_secure
                                        ? "Porta 465 — conexão SSL/TLS desde o início (menos comum)"
                                        : "Porta 587 — STARTTLS (padrão Gmail, Outlook, Zoho e maioria dos provedores)"}
                                </p>
                            </div>
                        </div>
                    </div>

                    <div className="flex justify-end gap-2 pt-2">
                        <Button
                            variant="outline"
                            onClick={load}
                            className="gap-1.5"
                            data-testid="reload-smtp-config-btn"
                        >
                            <RefreshCw size={14} /> Cancelar
                        </Button>
                        <Button
                            onClick={save}
                            disabled={saving}
                            data-testid="save-smtp-config-btn"
                            className="gap-1.5"
                        >
                            {saving ? "Salvando…" : "Salvar configuração"}
                        </Button>
                    </div>
                </CardContent>
            </Card>

            {/* Teste de envio */}
            <Card className="border border-border shadow-sm max-w-2xl">
                <CardHeader className="px-6 py-4 border-b border-border">
                    <CardTitle className="text-sm font-semibold flex items-center gap-2">
                        <Send size={14} /> Enviar e-mail de teste
                    </CardTitle>
                </CardHeader>
                <CardContent className="p-6 space-y-4">
                    <p className="text-sm text-muted-foreground">
                        Envia um e-mail de teste usando a configuração <strong>atual do formulário</strong>{" "}
                        (não é necessário salvar antes).
                    </p>

                    {testResult && (
                        <Alert
                            variant={testResult.success ? "default" : "destructive"}
                            className={testResult.success ? "border-emerald-200 bg-luppa-green/10" : ""}
                            data-testid={testResult.success ? "test-email-success" : "test-email-error"}
                        >
                            {testResult.success
                                ? <CheckCircle size={15} className="mr-2 inline text-luppa-green" />
                                : <AlertTriangle size={15} className="mr-2 inline" />}
                            <AlertDescription className="text-sm space-y-1">
                                <p>{testResult.message}</p>
                                {testResult.isBadCreds && (
                                    <p>
                                        <a
                                            href="https://myaccount.google.com/apppasswords"
                                            target="_blank"
                                            rel="noreferrer"
                                            className="underline font-semibold"
                                        >
                                            Gerar Senha de App do Gmail →
                                        </a>
                                    </p>
                                )}
                            </AlertDescription>
                        </Alert>
                    )}

                    <div className="flex gap-2">
                        <Input
                            type="email"
                            placeholder="seu@email.com"
                            value={testEmail}
                            onChange={(e) => setTestEmail(e.target.value)}
                            className="flex-1"
                            data-testid="test-email-input"
                        />
                        <Button
                            onClick={sendTest}
                            disabled={testing || !testEmail || !form.smtp_host}
                            className="gap-1.5 whitespace-nowrap"
                            data-testid="send-test-email-btn"
                        >
                            <Mail size={14} />
                            {testing ? "Enviando…" : "Testar envio"}
                        </Button>
                    </div>

                    {!form.smtp_host && (
                        <p className="text-xs text-amber-600">
                            Configure o servidor SMTP antes de enviar o teste.
                        </p>
                    )}
                </CardContent>
            </Card>

            {/* Referência de variáveis de ambiente */}
            <Card className="border border-border shadow-sm max-w-2xl bg-muted/30">
                <CardContent className="p-5">
                    <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-3">
                        Variáveis de ambiente equivalentes (no servidor)
                    </p>
                    <pre className="text-xs font-mono leading-relaxed text-foreground whitespace-pre-wrap">
{`EMAIL_PROVIDER=smtp
SMTP_HOST=${form.smtp_host || "smtp.exemplo.com"}
SMTP_PORT=${form.smtp_port}
SMTP_SECURE=${form.smtp_secure}
SMTP_USER=${form.smtp_user || "usuario@exemplo.com"}
SMTP_PASS=<sua_senha>
SMTP_FROM=${form.smtp_from || "noreply@exemplo.com"}`}
                    </pre>
                    <p className="text-xs text-muted-foreground mt-2">
                        A configuração salva no banco tem prioridade sobre as variáveis de ambiente.
                    </p>
                </CardContent>
            </Card>
        </div>
    );
}
