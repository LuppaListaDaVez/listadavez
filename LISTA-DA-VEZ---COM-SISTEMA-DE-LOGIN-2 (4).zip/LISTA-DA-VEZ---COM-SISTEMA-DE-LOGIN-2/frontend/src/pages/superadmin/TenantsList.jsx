/**
 * TenantsList — Listagem de empresas para o Super Admin.
 *
 * Atualizado (Delete + Link de ativação):
 *  - Botão "Excluir empresa" no dropdown (com diálogo de confirmação).
 *  - "Reenviar convite" retorna o link → modal de cópia para o admin compartilhar manualmente.
 *  - Badge PENDING_ACTIVATION com aviso de e-mail.
 */
import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api, { extractError } from "@/lib/api";
import { PageHeader, EmptyState } from "@/components/Common";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
    Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
    DropdownMenu, DropdownMenuContent, DropdownMenuItem,
    DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
    Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from "@/components/ui/dialog";
import {
    AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
    AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { MoreHorizontal, Plus, Send, Trash2, Copy, Check, ExternalLink, Users, Cpu, LogIn } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { startImpersonation } from "@/components/ImpersonationBanner";

const STATUS_VARIANT = {
    ACTIVE:              "default",
    TRIAL:               "secondary",
    SUSPENDED:           "outline",
    CANCELLED:           "destructive",
    PENDING_ACTIVATION:  "secondary",
};

const STATUS_LABEL = {
    ACTIVE:             "Ativo",
    TRIAL:              "Período de Teste",
    SUSPENDED:          "Suspenso",
    CANCELLED:          "Cancelado",
    PENDING_ACTIVATION: "Aguardando ativação",
};

const ROLE_LABEL = {
    TENANT_ADMIN:     "Admin",
    MANAGER:          "Gerente",
    STORE_MANAGER:    "Gerente de Loja",
    REGIONAL_MANAGER: "Gerente Regional",
    SUPERVISOR:       "Supervisor",
    SELLER:           "Vendedor",
    SUPPORT:          "Suporte",
    VIEWER:           "Visualizador",
};

export default function TenantsList() {
    const navigate = useNavigate();
    const [tenants, setTenants]         = useState([]);
    const [loading, setLoading]         = useState(true);
    const [resending, setResending]     = useState(null);
    const [deleting, setDeleting]       = useState(null);
    const [deleteTarget, setDeleteTarget] = useState(null);
    const [inviteModal, setInviteModal] = useState(null);
    const [copied, setCopied]           = useState(false);
    const [impersonating, setImpersonating] = useState(null);

    // Estado do modal de usuários
    const [usersModal, setUsersModal]   = useState(null);   // { tenantId, tenantName }
    const [tenantUsers, setTenantUsers] = useState([]);
    const [loadingUsers, setLoadingUsers] = useState(false);
    const [saDeleteTarget, setSaDeleteTarget] = useState(null); // { user, tenantId }
    const [saDeleting, setSaDeleting] = useState(false);

    // Estado do modal de Automações
    const [automacaoModal, setAutomacaoModal]   = useState(null);   // { tenantId, tenantName }
    const [automacaoEnabled, setAutomacaoEnabled] = useState(false);
    const [loadingAutomacao, setLoadingAutomacao] = useState(false);
    const [savingAutomacao, setSavingAutomacao]   = useState(false);

    const load = async () => {
        setLoading(true);
        const { data } = await api.get("/super-admin/tenants");
        setTenants(data);
        setLoading(false);
    };

    useEffect(() => { load(); }, []);

    const setStatus = async (id, status) => {
        try {
            await api.patch(`/super-admin/tenants/${id}/status`, { status });
            toast.success("Status atualizado.");
            load();
        } catch (e) {
            toast.error(extractError(e, "Erro ao atualizar status"));
        }
    };

    const resendInvite = async (id, name) => {
        setResending(id);
        try {
            const { data } = await api.post(`/super-admin/tenants/${id}/resend-invite`);
            // Mostrar modal com o link de ativação (fallback caso e-mail não chegue)
            setInviteModal({
                email: data.invite_sent_to,
                link: data.invite_link,
                tenantName: name,
            });
            toast.success(`Convite gerado para "${name}".`);
        } catch (e) {
            toast.error(extractError(e, "Erro ao reenviar convite"));
        } finally {
            setResending(null);
        }
    };

    const confirmDelete = async () => {
        if (!deleteTarget) return;
        setDeleting(deleteTarget.id);
        try {
            await api.delete(`/super-admin/tenants/${deleteTarget.id}`);
            toast.success(`Empresa "${deleteTarget.name}" excluída.`);
            setDeleteTarget(null);
            load();
        } catch (e) {
            toast.error(extractError(e, "Erro ao excluir empresa"));
        } finally {
            setDeleting(null);
        }
    };

    const copyLink = () => {
        if (!inviteModal?.link) return;
        try {
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(inviteModal.link).then(() => {
                    setCopied(true);
                    setTimeout(() => setCopied(false), 2000);
                }).catch(() => copyLinkFallback());
            } else {
                copyLinkFallback();
            }
        } catch {
            copyLinkFallback();
        }
    };

    const copyLinkFallback = () => {
        const el = document.createElement('textarea');
        el.value = inviteModal.link;
        el.style.position = 'fixed';
        el.style.opacity = '0';
        document.body.appendChild(el);
        el.focus();
        el.select();
        try {
            document.execCommand('copy');
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        } catch {
            // silently fail
        } finally {
            document.body.removeChild(el);
        }
    };

    const openUsersModal = async (tenantId, tenantName) => {
        setUsersModal({ tenantId, tenantName });
        setTenantUsers([]);
        setLoadingUsers(true);
        try {
            const { data } = await api.get(`/super-admin/tenants/${tenantId}/users`);
            setTenantUsers(data);
        } catch (e) {
            toast.error(extractError(e, "Erro ao carregar usuários"));
            setUsersModal(null);
        } finally {
            setLoadingUsers(false);
        }
    };

    const handleSaDeleteUser = async () => {
        if (!saDeleteTarget) return;
        setSaDeleting(true);
        try {
            await api.delete(`/super-admin/tenants/${saDeleteTarget.tenantId}/users/${saDeleteTarget.user.id}`);
            toast.success(`Usuário "${saDeleteTarget.user.name}" excluído com sucesso.`);
            setSaDeleteTarget(null);
            // Recarrega lista de usuários do modal
            if (usersModal) {
                const { data } = await api.get(`/super-admin/tenants/${usersModal.tenantId}/users`);
                setTenantUsers(data);
            }
        } catch (e) {
            toast.error(extractError(e, "Erro ao excluir usuário"));
        } finally {
            setSaDeleting(false);
        }
    };

    const openAutomacaoModal = async (tenantId, tenantName) => {
        setAutomacaoModal({ tenantId, tenantName });
        setLoadingAutomacao(true);
        try {
            const { data } = await api.get(`/super-admin/tenants/${tenantId}/features`);
            const feat = data.find((f) => f.feature_key === "automacoes");
            setAutomacaoEnabled(feat?.enabled ?? false);
        } catch (e) {
            toast.error(extractError(e, "Erro ao carregar features"));
            setAutomacaoModal(null);
        } finally {
            setLoadingAutomacao(false);
        }
    };

    const saveAutomacao = async () => {
        if (!automacaoModal) return;
        setSavingAutomacao(true);
        try {
            await api.patch(`/super-admin/tenants/${automacaoModal.tenantId}/features`, {
                features: [{ feature_key: "automacoes", enabled: automacaoEnabled }],
            });
            toast.success(`Automações ${automacaoEnabled ? "ativadas" : "desativadas"} para "${automacaoModal.tenantName}".`);
            setAutomacaoModal(null);
        } catch (e) {
            toast.error(extractError(e, "Erro ao salvar"));
        } finally {
            setSavingAutomacao(false);
        }
    };

    const impersonate = async (tenantId, tenantName, tenantSlug) => {
        setImpersonating(tenantId);
        try {
            const { data } = await api.post(`/super-admin/tenants/${tenantId}/impersonate`);
            const currentTokens = {
                access_token:  localStorage.getItem("access_token"),
                refresh_token: localStorage.getItem("refresh_token"),
                user:          localStorage.getItem("user"),
            };
            startImpersonation({ data, currentTokens });
            toast.success(`Acessando "${tenantName}" como Super Admin…`);
            // Redireciona para o dashboard do tenant
            navigate(`/${tenantSlug}/dashboard`);
        } catch (e) {
            toast.error(extractError(e, "Erro ao acessar empresa"));
            setImpersonating(null);
        }
    };

    return (
        <div>
            <PageHeader
                eyebrow="Cadastros"
                title="Empresas"
                description="Empresas contratantes (tenants) da plataforma."
            >
                <Link to="/super-admin/tenants/new">
                    <Button data-testid="new-tenant-button" className="gap-2">
                        <Plus size={16} strokeWidth={1.5} /> Nova empresa
                    </Button>
                </Link>
            </PageHeader>

            {loading ? (
                <p className="text-sm text-muted-foreground">Carregando…</p>
            ) : tenants.length === 0 ? (
                <EmptyState
                    title="Nenhuma empresa cadastrada"
                    description="Cadastre o primeiro tenant para começar."
                    action={
                        <Link to="/super-admin/tenants/new">
                            <Button data-testid="empty-new-tenant-button">Nova empresa</Button>
                        </Link>
                    }
                />
            ) : (
                <Card className="border border-border shadow-sm">
                    <CardContent className="p-0">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Nome</TableHead>
                                    <TableHead>Slug</TableHead>
                                    <TableHead>Status</TableHead>
                                    <TableHead className="w-40 text-right">Ações</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {tenants.map((t) => (
                                    <TableRow key={t.id} data-testid={`tenant-row-${t.slug}`}>
                                        <TableCell className="font-medium">{t.name}</TableCell>
                                        <TableCell className="font-mono text-xs">/{t.slug}</TableCell>
                                        <TableCell>
                                            <Badge variant={STATUS_VARIANT[t.status] || "secondary"}>
                                                {STATUS_LABEL[t.status] || t.status}
                                            </Badge>
                                        </TableCell>
                                        <TableCell className="text-right">
                                            <div className="flex justify-end items-center gap-1">
                                                {/* Botão de Impersonação */}
                                                {(t.status === "ACTIVE" || t.status === "TRIAL") && (
                                                    <Button
                                                        size="sm"
                                                        variant="outline"
                                                        className="gap-1.5 text-xs h-7 px-2 border-amber-400 text-amber-700 hover:bg-amber-50 hover:text-amber-800"
                                                        disabled={impersonating === t.id}
                                                        onClick={() => impersonate(t.id, t.name, t.slug)}
                                                        data-testid={`impersonate-btn-${t.slug}`}
                                                        title="Entrar como esta empresa"
                                                    >
                                                        <LogIn size={12} />
                                                        {impersonating === t.id ? "Acessando…" : "Entrar como"}
                                                    </Button>
                                                )}

                                                {/* Reenviar convite + ver link */}
                                                {t.status === "PENDING_ACTIVATION" && (
                                                    <Button
                                                        size="sm"
                                                        variant="outline"
                                                        className="gap-1.5 text-xs h-7 px-2"
                                                        disabled={resending === t.id}
                                                        onClick={() => resendInvite(t.id, t.name)}
                                                        data-testid={`resend-invite-${t.slug}`}
                                                    >
                                                        <Send size={12} />
                                                        {resending === t.id ? "Gerando…" : "Reenviar / Ver link"}
                                                    </Button>
                                                )}

                                                <DropdownMenu>
                                                    <DropdownMenuTrigger asChild>
                                                        <Button
                                                            variant="ghost"
                                                            size="icon"
                                                            data-testid={`tenant-actions-${t.slug}`}
                                                        >
                                                            <MoreHorizontal size={16} />
                                                        </Button>
                                                    </DropdownMenuTrigger>
                                                    <DropdownMenuContent align="end">
                                                        <DropdownMenuItem
                                                            className="gap-2"
                                                            onClick={() => openUsersModal(t.id, t.name)}
                                                            data-testid={`view-users-${t.slug}`}
                                                        >
                                                            <Users size={13} />
                                                            Ver usuários
                                                        </DropdownMenuItem>
                                                        <DropdownMenuItem
                                                            className="gap-2"
                                                            onClick={() => openAutomacaoModal(t.id, t.name)}
                                                            data-testid={`automacao-toggle-${t.slug}`}
                                                        >
                                                            <Cpu size={13} />
                                                            Automações
                                                        </DropdownMenuItem>
                                                        {(t.status === "ACTIVE" || t.status === "TRIAL") && (
                                                            <>
                                                                <DropdownMenuSeparator />
                                                                <DropdownMenuItem
                                                                    className="gap-2 text-amber-700 focus:text-amber-700 focus:bg-amber-50"
                                                                    onClick={() => impersonate(t.id, t.name, t.slug)}
                                                                    disabled={impersonating === t.id}
                                                                    data-testid={`impersonate-dropdown-${t.slug}`}
                                                                >
                                                                    <LogIn size={13} />
                                                                    Entrar como esta empresa
                                                                </DropdownMenuItem>
                                                            </>
                                                        )}
                                                        <DropdownMenuSeparator />
                                                        <DropdownMenuItem asChild>
                                                            <Link to={`/super-admin/tenants/${t.id}/features`}>
                                                                Features
                                                            </Link>
                                                        </DropdownMenuItem>

                                                        {t.status === "PENDING_ACTIVATION" && (
                                                            <DropdownMenuItem
                                                                onClick={() => resendInvite(t.id, t.name)}
                                                                disabled={resending === t.id}
                                                                className="gap-2"
                                                            >
                                                                <Send size={13} />
                                                                Reenviar / Ver link
                                                            </DropdownMenuItem>
                                                        )}

                                                        {t.status !== "ACTIVE" && (
                                                            <DropdownMenuItem onClick={() => setStatus(t.id, "ACTIVE")}>
                                                                Ativar
                                                            </DropdownMenuItem>
                                                        )}
                                                        {t.status !== "SUSPENDED" && (
                                                            <DropdownMenuItem onClick={() => setStatus(t.id, "SUSPENDED")}>
                                                                Suspender
                                                            </DropdownMenuItem>
                                                        )}

                                                        <DropdownMenuSeparator />
                                                        <DropdownMenuItem
                                                            className="gap-2 text-destructive focus:text-destructive focus:bg-destructive/8"
                                                            onClick={() => setDeleteTarget({ id: t.id, name: t.name })}
                                                            data-testid={`delete-tenant-${t.slug}`}
                                                        >
                                                            <Trash2 size={13} />
                                                            Excluir empresa
                                                        </DropdownMenuItem>
                                                    </DropdownMenuContent>
                                                </DropdownMenu>
                                            </div>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>
            )}

            {/* Diálogo de confirmação de exclusão */}
            <AlertDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
                <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>Excluir empresa permanentemente?</AlertDialogTitle>
                        <AlertDialogDescription>
                            A empresa <strong>{deleteTarget?.name}</strong> e todos os seus dados
                            (usuários vinculados, filiais, convites, perfis de vendedor) serão{" "}
                            <strong>excluídos permanentemente</strong>.
                            Esta ação não pode ser desfeita.
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel data-testid="cancel-delete-tenant">Cancelar</AlertDialogCancel>
                        <AlertDialogAction
                            onClick={confirmDelete}
                            disabled={!!deleting}
                            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                            data-testid="confirm-delete-tenant"
                        >
                            {deleting ? "Excluindo…" : "Excluir permanentemente"}
                        </AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>

            {/* Modal do link de ativação */}
            <Dialog open={!!inviteModal} onOpenChange={(o) => { if (!o) { setInviteModal(null); setCopied(false); } }}>
                <DialogContent className="max-w-lg" data-testid="invite-link-modal">
                    <DialogHeader>
                        <DialogTitle className="flex items-center gap-2">
                            <Send size={16} className="text-luppa-purple" />
                            Link de ativação gerado
                        </DialogTitle>
                        <DialogDescription>
                            {inviteModal?.link
                                ? <>
                                    Convite enviado para <strong>{inviteModal?.email}</strong>.
                                    Caso o e-mail não chegue, compartilhe o link abaixo diretamente.
                                  </>
                                : `Convite reenviado para ${inviteModal?.email}.`
                            }
                        </DialogDescription>
                    </DialogHeader>

                    {inviteModal?.link && (
                        <div className="space-y-3 pt-2">
                            <div className="flex gap-2">
                                <Input
                                    readOnly
                                    value={inviteModal.link}
                                    className="font-mono text-xs"
                                    data-testid="invite-link-input"
                                    onFocus={(e) => e.target.select()}
                                />
                                <Button
                                    variant="outline"
                                    size="icon"
                                    onClick={copyLink}
                                    title="Copiar link"
                                    data-testid="copy-invite-link-btn"
                                >
                                    {copied ? <Check size={15} className="text-luppa-green" /> : <Copy size={15} />}
                                </Button>
                                <a
                                    href={inviteModal.link}
                                    target="_blank"
                                    rel="noreferrer"
                                    title="Abrir link"
                                >
                                    <Button variant="outline" size="icon">
                                        <ExternalLink size={15} />
                                    </Button>
                                </a>
                            </div>
                            <p className="text-xs text-muted-foreground">
                                O link expira em 72 horas. Se o e-mail não chegou, verifique as{" "}
                                <Link
                                    to="/super-admin/settings/email"
                                    className="underline text-luppa-purple"
                                    onClick={() => setInviteModal(null)}
                                >
                                    configurações de SMTP
                                </Link>
                                .
                            </p>
                        </div>
                    )}
                </DialogContent>
            </Dialog>
            {/* Modal de Automações */}
            <Dialog open={!!automacaoModal} onOpenChange={(o) => { if (!o) setAutomacaoModal(null); }}>
                <DialogContent className="max-w-md" data-testid="automacao-modal">
                    <DialogHeader>
                        <DialogTitle className="flex items-center gap-2">
                            <Cpu size={17} className="text-primary" />
                            Automações — {automacaoModal?.tenantName}
                        </DialogTitle>
                        <DialogDescription>
                            Ative ou desative o módulo de Automações para esta empresa.
                            Quando desativado, o menu "Automações" ficará oculto para os usuários.
                        </DialogDescription>
                    </DialogHeader>

                    {loadingAutomacao ? (
                        <p className="text-sm text-muted-foreground py-4 text-center">Carregando…</p>
                    ) : (
                        <div className="py-4 space-y-5">
                            <div className="flex items-center justify-between gap-4 rounded-lg border border-border p-4">
                                <div>
                                    <Label className="text-sm font-medium">Módulo de Automações</Label>
                                    <p className="text-xs text-muted-foreground mt-0.5">
                                        Permite criar regras de automação baseadas em gatilhos (metas, vendas, rankings, etc.)
                                    </p>
                                </div>
                                <Switch
                                    checked={automacaoEnabled}
                                    onCheckedChange={setAutomacaoEnabled}
                                    data-testid="automacao-switch"
                                />
                            </div>
                            <div className="flex justify-end gap-2">
                                <Button variant="outline" onClick={() => setAutomacaoModal(null)}>
                                    Cancelar
                                </Button>
                                <Button
                                    onClick={saveAutomacao}
                                    disabled={savingAutomacao}
                                    data-testid="automacao-save-button"
                                >
                                    {savingAutomacao ? "Salvando…" : "Salvar"}
                                </Button>
                            </div>
                        </div>
                    )}
                </DialogContent>
            </Dialog>

            {/* Modal de usuários da empresa */}
            <Dialog open={!!usersModal} onOpenChange={(o) => { if (!o) { setUsersModal(null); setSaDeleteTarget(null); } }}>
                <DialogContent className="max-w-xl" data-testid="tenant-users-modal">
                    <DialogHeader>
                        <DialogTitle className="flex items-center gap-2">
                            <Users size={17} className="text-primary" />
                            Usuários — {usersModal?.tenantName}
                        </DialogTitle>
                        <DialogDescription>
                            Usuários vinculados a esta empresa. Senhas nunca são exibidas por segurança.
                        </DialogDescription>
                    </DialogHeader>

                    {loadingUsers ? (
                        <p className="text-sm text-muted-foreground py-4 text-center">Carregando usuários…</p>
                    ) : tenantUsers.length === 0 ? (
                        <div className="py-8 text-center border border-dashed border-border rounded-md" data-testid="no-users-message">
                            <Users size={28} className="mx-auto text-muted-foreground/40 mb-2" />
                            <p className="text-sm text-muted-foreground font-medium">Esta empresa ainda não possui usuários cadastrados.</p>
                        </div>
                    ) : (
                        <div className="mt-2 border border-border/60 rounded-md overflow-hidden" data-testid="tenant-users-table">
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Nome</TableHead>
                                        <TableHead>E-mail</TableHead>
                                        <TableHead>Cargo</TableHead>
                                        <TableHead className="w-10"></TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {tenantUsers.map((u) => (
                                        <TableRow key={u.id} data-testid={`user-row-${u.id}`}>
                                            <TableCell className="font-medium text-sm">{u.name || "—"}</TableCell>
                                            <TableCell className="text-sm font-mono">{u.email}</TableCell>
                                            <TableCell>
                                                <Badge variant="secondary" className="text-xs">
                                                    {ROLE_LABEL[u.role] || u.role}
                                                </Badge>
                                            </TableCell>
                                            <TableCell>
                                                <Button
                                                    size="sm" variant="ghost"
                                                    title="Excluir usuário desta empresa"
                                                    onClick={() => setSaDeleteTarget({ user: u, tenantId: usersModal?.tenantId })}
                                                    data-testid={`sa-delete-user-${u.id}`}
                                                >
                                                    <Trash2 size={14} className="text-luppa-error" />
                                                </Button>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                            <div className="px-4 py-2.5 border-t border-border/50 bg-muted/20">
                                <p className="text-xs text-muted-foreground">
                                    {tenantUsers.length} usuário{tenantUsers.length !== 1 ? "s" : ""} cadastrado{tenantUsers.length !== 1 ? "s" : ""}
                                </p>
                            </div>
                        </div>
                    )}
                </DialogContent>
            </Dialog>

            {/* Confirmação de exclusão (Super Admin) */}
            <AlertDialog open={!!saDeleteTarget} onOpenChange={(o) => { if (!o) setSaDeleteTarget(null); }}>
                <AlertDialogContent data-testid="sa-delete-user-dialog">
                    <AlertDialogHeader>
                        <AlertDialogTitle>Excluir usuário?</AlertDialogTitle>
                        <AlertDialogDescription>
                            <strong>{saDeleteTarget?.user?.name}</strong> ({saDeleteTarget?.user?.email}) perderá acesso permanente a esta empresa.
                            Dados históricos serão preservados.
                            <br /><br />Esta ação não pode ser desfeita pela interface.
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel disabled={saDeleting}>Cancelar</AlertDialogCancel>
                        <AlertDialogAction
                            onClick={handleSaDeleteUser}
                            disabled={saDeleting}
                            className="bg-luppa-error hover:bg-luppa-error text-white"
                            data-testid="sa-confirm-delete-user-button"
                        >
                            {saDeleting ? "Excluindo…" : "Sim, excluir"}
                        </AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </div>
    );
}
