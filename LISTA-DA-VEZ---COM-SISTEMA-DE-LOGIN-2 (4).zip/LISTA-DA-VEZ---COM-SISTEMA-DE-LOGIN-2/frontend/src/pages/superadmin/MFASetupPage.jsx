import React, { useEffect, useState } from "react";
import { ShieldCheck, QrCode } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import api from "@/lib/api";
import { toast } from "sonner";
import { fmtDateTime } from "@/lib/i18n";

export default function MFASetupPage() {
    const [status, setStatus] = useState(null);
    const [setupData, setSetupData] = useState(null);
    const [code, setCode] = useState("");
    const [loading, setLoading] = useState(false);
    const [loadingStatus, setLoadingStatus] = useState(true);

    const loadStatus = async () => {
        setLoadingStatus(true);
        try {
            const { data } = await api.get("/admin/security/mfa");
            const myConfig = data?.[0];
            setStatus(myConfig || null);
        } catch {
            setStatus(null);
        } finally {
            setLoadingStatus(false);
        }
    };

    useEffect(() => {
        loadStatus();
    }, []);

    const startSetup = async () => {
        setLoading(true);
        try {
            const { data } = await api.post("/admin/security/mfa/setup");
            setSetupData(data);
        } catch {
            toast.error("Falha ao iniciar setup MFA.");
        } finally {
            setLoading(false);
        }
    };

    const confirmSetup = async () => {
        if (!code || code.length < 6) {
            toast.error("Digite o código de 6 dígitos.");
            return;
        }
        setLoading(true);
        try {
            await api.post("/admin/security/mfa/confirm", { code });
            toast.success("MFA ativado com sucesso!");
            setSetupData(null);
            setCode("");
            await loadStatus();
        } catch {
            toast.error("Código inválido. Tente novamente.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="max-w-lg space-y-6">
            <div>
                <h1 className="text-2xl font-semibold" data-testid="mfa-page-title">MFA — Autenticação de Dois Fatores</h1>
                <p className="text-sm text-muted-foreground mt-1">
                    Configure o TOTP para aumentar a segurança do Super Admin.
                </p>
            </div>

            <Card>
                <CardHeader className="pb-3">
                    <CardTitle className="text-sm flex items-center gap-2">
                        <ShieldCheck size={16} />
                        Status Atual
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    {loadingStatus ? (
                        <p className="text-sm text-muted-foreground">Carregando…</p>
                    ) : (
                        <div className="flex items-center gap-3">
                            <Badge variant={status?.enabled ? "default" : "secondary"} data-testid="mfa-status-badge">
                                {status?.enabled ? "Ativado" : "Não configurado"}
                            </Badge>
                            {status?.last_used_at && (
                                <span className="text-xs text-muted-foreground">
                                    Último uso: {fmtDateTime(status.last_used_at)}
                                </span>
                            )}
                        </div>
                    )}
                </CardContent>
            </Card>

            {!setupData && (
                <Button onClick={startSetup} disabled={loading} data-testid="start-mfa-setup-btn">
                    <QrCode size={14} className="mr-2" />
                    {status?.enabled ? "Reconfigurar MFA" : "Configurar MFA (TOTP)"}
                </Button>
            )}

            {setupData && (
                <Card>
                    <CardHeader className="pb-3">
                        <CardTitle className="text-sm">Configure seu Autenticador</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <p className="text-sm text-muted-foreground">
                            1. Abra seu app autenticador (Google Authenticator, Authy, etc.)
                        </p>
                        <p className="text-sm text-muted-foreground">
                            2. Escaneie o QR Code ou adicione o segredo manualmente:
                        </p>
                        <div className="p-3 bg-muted rounded font-mono text-sm break-all" data-testid="totp-secret">
                            {setupData.secret}
                        </div>
                        {setupData.recovery_codes && (
                            <Alert>
                                <AlertDescription>
                                    <strong>Recovery codes (salve agora — visível apenas uma vez):</strong>
                                    <div className="mt-2 grid grid-cols-2 gap-1">
                                        {setupData.recovery_codes.map((c) => (
                                            <code key={c} className="text-xs font-mono">{c}</code>
                                        ))}
                                    </div>
                                </AlertDescription>
                            </Alert>
                        )}
                        <div className="space-y-2">
                            <Label htmlFor="mfa-code">3. Digite o código do app para confirmar</Label>
                            <Input
                                id="mfa-code"
                                placeholder="000000"
                                value={code}
                                onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                                maxLength={6}
                                data-testid="mfa-confirm-code-input"
                            />
                        </div>
                        <div className="flex gap-2">
                            <Button onClick={confirmSetup} disabled={loading || code.length < 6} data-testid="mfa-confirm-btn">
                                Confirmar e Ativar MFA
                            </Button>
                            <Button variant="outline" onClick={() => setSetupData(null)}>Cancelar</Button>
                        </div>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}
