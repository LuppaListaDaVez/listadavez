import React, { useEffect, useState } from "react";
import api from "@/lib/api";
import { PageHeader } from "@/components/Common";
import { Card, CardContent } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertTriangle } from "lucide-react";

export default function SuperAdminDashboard() {
    const [stats, setStats] = useState({ tenants: 0, plans: 0, features: 0, active: 0 });
    const [emailStatus, setEmailStatus] = useState(null);

    useEffect(() => {
        (async () => {
            try {
                const [tn, pl, ft, em] = await Promise.all([
                    api.get("/super-admin/tenants"),
                    api.get("/super-admin/plans"),
                    api.get("/super-admin/features"),
                    api.get("/super-admin/system/email-status"),
                ]);
                setStats({
                    tenants: tn.data.length,
                    plans: pl.data.length,
                    features: ft.data.length,
                    active: tn.data.filter((t) => t.status === "ACTIVE").length,
                });
                setEmailStatus(em.data);
            } catch {
                /* noop */
            }
        })();
    }, []);

    const items = [
        { label: "Empresas", value: stats.tenants, testId: "metric-tenants" },
        { label: "Ativas", value: stats.active, testId: "metric-active" },
        { label: "Planos", value: stats.plans, testId: "metric-plans" },
        { label: "Funcionalidades", value: stats.features, testId: "metric-features" },
    ];

    const showEmailWarning = emailStatus && !emailStatus.configured;

    return (
        <div>
            <PageHeader
                eyebrow="Painel global"
                title="Visão geral da plataforma"
                description="Métricas resumidas das empresas contratantes."
            />

            {/* Banner de aviso: SMTP não configurado */}
            {showEmailWarning && (
                <Alert
                    variant="destructive"
                    className="mb-6 border-amber-300 bg-amber-50 text-amber-900"
                    data-testid="email-not-configured-banner"
                >
                    <AlertTriangle size={15} className="mr-2 inline text-amber-600" />
                    <AlertDescription className="text-sm">
                        <strong>E-mail não configurado</strong> — os convites enviados são apenas
                        registrados no log do servidor, <strong>não chegam na caixa de entrada</strong>
                        {emailStatus.missing_vars?.length > 0 && (
                            <>
                                {". Configure as variáveis no servidor: "}
                                <code className="font-mono text-xs bg-amber-100 px-1 rounded">
                                    {emailStatus.missing_vars.join(", ")}
                                </code>
                            </>
                        )}
                        {". "}
                        <a href="/super-admin/settings/email" className="underline font-semibold">
                            Configurar agora →
                        </a>
                    </AlertDescription>
                </Alert>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {items.map((m) => (
                    <Card key={m.label} className="border border-border shadow-sm">
                        <CardContent className="p-6">
                            <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground">{m.label}</p>
                            <p
                                className="font-sans text-4xl font-bold tracking-tighter mt-3"
                                data-testid={m.testId}
                            >
                                {m.value}
                            </p>
                        </CardContent>
                    </Card>
                ))}
            </div>
        </div>
    );
}
