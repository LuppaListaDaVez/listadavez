import React, { useEffect, useState } from "react";
import api, { extractError } from "@/lib/api";
import { PageHeader } from "@/components/Common";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
    DialogFooter,
} from "@/components/ui/dialog";
import { Plus } from "lucide-react";
import { toast } from "sonner";
import { PLAN_STATUS_PT } from "@/lib/i18n";

export default function PlansList() {
    const [plans, setPlans] = useState([]);
    const [open, setOpen] = useState(false);
    const [form, setForm] = useState({ name: "", description: "" });
    const [saving, setSaving] = useState(false);

    const load = async () => {
        const { data } = await api.get("/super-admin/plans");
        setPlans(data);
    };
    useEffect(() => {
        load();
    }, []);

    const submit = async (e) => {
        e.preventDefault();
        if (saving) return;
        setSaving(true);
        try {
            await api.post("/super-admin/plans", form);
            toast.success("Plano criado.");
            setForm({ name: "", description: "" });
            setOpen(false);
            load();
        } catch (e) {
            toast.error(extractError(e, "Erro ao criar plano"));
        } finally {
            setSaving(false);
        }
    };

    return (
        <div>
            <PageHeader eyebrow="Catálogo" title="Planos" description="Planos comerciais disponíveis.">
                <Dialog open={open} onOpenChange={setOpen}>
                    <DialogTrigger asChild>
                        <Button data-testid="new-plan-button" className="gap-2">
                            <Plus size={16} strokeWidth={1.5} /> Novo plano
                        </Button>
                    </DialogTrigger>
                    <DialogContent>
                        <DialogHeader>
                            <DialogTitle>Novo plano</DialogTitle>
                        </DialogHeader>
                        <form onSubmit={submit} className="space-y-4">
                            <div className="space-y-2">
                                <Label>Nome</Label>
                                <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required data-testid="plan-name-input" />
                            </div>
                            <div className="space-y-2">
                                <Label>Descrição</Label>
                                <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} data-testid="plan-desc-input" />
                            </div>
                            <DialogFooter>
                                <Button type="submit" disabled={saving} data-testid="plan-submit">{saving ? "Criando…" : "Criar"}</Button>
                            </DialogFooter>
                        </form>
                    </DialogContent>
                </Dialog>
            </PageHeader>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {plans.map((p) => (
                    <Card key={p.id} className="border border-border shadow-sm" data-testid={`plan-card-${p.name}`}>
                        <CardContent className="p-6">
                            <div className="flex items-center justify-between">
                                <h3 className="font-sans text-xl font-semibold">{p.name}</h3>
                                <Badge variant="secondary">{PLAN_STATUS_PT[p.status] || p.status}</Badge>
                            </div>
                            <p className="text-sm text-muted-foreground mt-2">{p.description}</p>
                        </CardContent>
                    </Card>
                ))}
            </div>
        </div>
    );
}
