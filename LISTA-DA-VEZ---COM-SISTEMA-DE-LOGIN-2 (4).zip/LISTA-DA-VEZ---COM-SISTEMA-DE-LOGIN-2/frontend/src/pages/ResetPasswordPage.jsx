import React, { useState } from "react";
import { Link, useSearchParams, useNavigate } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CheckCircle, Eye, EyeOff } from "lucide-react";
import api from "@/lib/api";

function StrengthBar({ password }) {
    const score = (() => {
        if (!password) return 0;
        let s = 0;
        if (password.length >= 8) s++;
        if (/[A-Z]/.test(password)) s++;
        if (/[0-9]/.test(password)) s++;
        if (/[^A-Za-z0-9]/.test(password)) s++;
        return s;
    })();
    const labels = ["", "Fraca", "Razoável", "Boa", "Forte"];
    const colors = ["", "bg-luppa-error", "bg-luppa-warning", "bg-luppa-purple", "bg-luppa-green"];
    return (
        <div className="space-y-1 mt-1">
            <div className="flex gap-1">
                {[1, 2, 3, 4].map((i) => (
                    <div
                        key={i}
                        className={`h-1 flex-1 rounded-full transition-all ${i <= score ? colors[score] : "bg-muted"}`}
                    />
                ))}
            </div>
            {password && (
                <p className={`text-xs ${score < 2 ? "text-luppa-error" : score < 4 ? "text-luppa-warning" : "text-luppa-green"}`}>
                    {labels[score]}
                </p>
            )}
        </div>
    );
}

export default function ResetPasswordPage() {
    const [searchParams] = useSearchParams();
    const navigate = useNavigate();
    const token = searchParams.get("token") || "";
    const slug = searchParams.get("slug") || "";

    const [newPassword, setNewPassword] = useState("");
    const [confirm, setConfirm] = useState("");
    const [showNew, setShowNew] = useState(false);
    const [showConfirm, setShowConfirm] = useState(false);
    const [loading, setLoading] = useState(false);
    const [done, setDone] = useState(false);
    const [error, setError] = useState(null);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError(null);

        if (!token || !slug) {
            setError("Link de redefinição inválido. Solicite um novo.");
            return;
        }
        if (newPassword.length < 8) {
            setError("A senha deve ter pelo menos 8 caracteres.");
            return;
        }
        if (newPassword !== confirm) {
            setError("As senhas não coincidem.");
            return;
        }

        setLoading(true);
        try {
            await api.post(`/tenants/${slug}/auth/password-reset/confirm`, {
                token,
                new_password: newPassword,
            });
            setDone(true);
        } catch (err) {
            const detail = err?.response?.data?.detail;
            setError(typeof detail === "string" ? detail : "Ocorreu um erro. Tente novamente.");
        } finally {
            setLoading(false);
        }
    };

    if (!token || !slug) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-background px-4">
                <div className="w-full max-w-sm text-center space-y-3">
                    <h1 className="text-xl font-semibold">Link inválido</h1>
                    <p className="text-sm text-muted-foreground">
                        Este link de redefinição de senha está incompleto ou expirado.
                    </p>
                </div>
            </div>
        );
    }

    if (done) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-background px-4">
                <div className="w-full max-w-sm text-center space-y-4">
                    <CheckCircle className="mx-auto h-12 w-12 text-luppa-green" />
                    <h1 className="font-sans text-2xl font-semibold">Senha redefinida!</h1>
                    <p className="text-sm text-muted-foreground">
                        Sua senha foi atualizada com sucesso. Faça login com a nova senha.
                    </p>
                    <Button
                        className="w-full mt-2"
                        onClick={() => navigate(`/${slug}/login`)}
                        data-testid="reset-password-go-to-login"
                    >
                        Ir para o login
                    </Button>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen flex items-center justify-center bg-background px-4">
            <div className="w-full max-w-sm space-y-6">
                <div>
                    <h1 className="font-sans text-2xl font-semibold">Redefinir senha</h1>
                    <p className="text-sm text-muted-foreground mt-1">
                        Escolha uma nova senha para sua conta.
                    </p>
                </div>

                <Card className="border border-border shadow-sm">
                    <CardContent className="p-6">
                        <form onSubmit={handleSubmit} className="space-y-4">
                            {error && (
                                <Alert variant="destructive">
                                    <AlertDescription data-testid="reset-password-error">{error}</AlertDescription>
                                </Alert>
                            )}
                            <div className="space-y-2">
                                <Label htmlFor="new-password">Nova senha</Label>
                                <div className="relative">
                                    <Input
                                        id="new-password"
                                        type={showNew ? "text" : "password"}
                                        className="pr-10"
                                        placeholder="Mínimo 8 caracteres"
                                        value={newPassword}
                                        onChange={(e) => setNewPassword(e.target.value)}
                                        data-testid="reset-password-new-input"
                                        required
                                    />
                                    <button
                                        type="button"
                                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                                        onClick={() => setShowNew((v) => !v)}
                                        tabIndex={-1}
                                    >
                                        {showNew ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                                    </button>
                                </div>
                                <StrengthBar password={newPassword} />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="confirm-password">Confirmar nova senha</Label>
                                <div className="relative">
                                    <Input
                                        id="confirm-password"
                                        type={showConfirm ? "text" : "password"}
                                        className="pr-10"
                                        placeholder="Repita a nova senha"
                                        value={confirm}
                                        onChange={(e) => setConfirm(e.target.value)}
                                        data-testid="reset-password-confirm-input"
                                        required
                                    />
                                    <button
                                        type="button"
                                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                                        onClick={() => setShowConfirm((v) => !v)}
                                        tabIndex={-1}
                                    >
                                        {showConfirm ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                                    </button>
                                </div>
                                {confirm && newPassword !== confirm && (
                                    <p className="text-xs text-luppa-error">As senhas não coincidem.</p>
                                )}
                            </div>
                            <Button
                                type="submit"
                                className="w-full"
                                disabled={loading || (confirm.length > 0 && newPassword !== confirm)}
                                data-testid="reset-password-submit-button"
                            >
                                {loading ? "Salvando…" : "Salvar nova senha"}
                            </Button>
                        </form>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
