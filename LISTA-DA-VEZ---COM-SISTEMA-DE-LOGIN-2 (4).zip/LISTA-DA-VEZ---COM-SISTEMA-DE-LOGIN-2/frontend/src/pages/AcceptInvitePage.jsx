/**
 * AcceptInvitePage — Página pública de ativação de conta via convite.
 *
 * Rota: /ativar-conta?token=...
 * Pública — não requer autenticação prévia.
 *
 * Fluxo:
 *  1. Lê ?token= da query string.
 *  2. Exibe formulário: nome + senha + confirmar senha.
 *  3. POST /invites/{token}/accept → salva tokens e redireciona.
 *  4. Se existing_user=true → redireciona para /{slug}/login.
 *  5. Se token inválido/expirado → mensagem amigável.
 */
import React, { useState } from "react";
import { useSearchParams, useNavigate, Link } from "react-router-dom";
import api, { extractError } from "@/lib/api";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CheckCircle, AlertTriangle, Eye, EyeOff, ArrowRight } from "lucide-react";

function validatePassword(pwd) {
    return pwd.length >= 8 && /\d/.test(pwd);
}

function StrengthBar({ pwd }) {
    const hasLen = pwd.length >= 8;
    const hasNum = /\d/.test(pwd);
    const hasMix = /[a-zA-Z]/.test(pwd) && /\d/.test(pwd);
    const score = [hasLen, hasNum, hasMix].filter(Boolean).length;
    const colors = ["bg-luppa-error/70", "bg-amber-400", "bg-luppa-green"];
    return (
        <div className="flex gap-1 mt-1" aria-hidden>
            {[0, 1, 2].map((i) => (
                <div
                    key={i}
                    className={`h-1 flex-1 rounded-full transition-colors duration-300 ${i < score ? colors[score - 1] : "bg-muted"}`}
                />
            ))}
        </div>
    );
}

export default function AcceptInvitePage() {
    const [searchParams] = useSearchParams();
    const token = searchParams.get("token") || "";
    const navigate = useNavigate();
    const { loginWithTokens } = useAuth();

    const [form, setForm] = useState({ name: "", password: "", confirm: "" });
    const [showPwd, setShowPwd] = useState(false);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [done, setDone] = useState(null); // { message, tenantSlug, existingUser }

    const setF = (k, v) => setForm((p) => ({ ...p, [k]: v }));

    if (!token) {
        return (
            <PublicShell>
                <div className="text-center space-y-4">
                    <AlertTriangle className="mx-auto text-amber-500" size={40} strokeWidth={1.5} />
                    <h2 className="text-xl font-semibold">Link de convite inválido</h2>
                    <p className="text-muted-foreground text-sm max-w-sm mx-auto">
                        O link que você acessou não contém um token de convite válido.
                        Verifique o e-mail recebido ou entre em contato com o administrador.
                    </p>
                    <a href="mailto:suporte@listadavez.com" className="text-sm text-luppa-purple underline">
                        Falar com o suporte
                    </a>
                </div>
            </PublicShell>
        );
    }

    if (done) {
        if (done.existingUser) {
            return (
                <PublicShell>
                    <div className="text-center space-y-4">
                        <CheckCircle className="mx-auto text-luppa-green" size={40} strokeWidth={1.5} />
                        <h2 className="text-xl font-semibold">Conta vinculada!</h2>
                        <p className="text-muted-foreground text-sm max-w-sm mx-auto">
                            Sua conta já existia e foi vinculada à empresa. Faça login com sua senha atual.
                        </p>
                        <Button
                            data-testid="go-to-login-btn"
                            onClick={() => navigate(`/${done.tenantSlug}/login`)}
                            className="gap-2"
                        >
                            Ir para o login <ArrowRight size={15} />
                        </Button>
                    </div>
                </PublicShell>
            );
        }
        return (
            <PublicShell>
                <div className="text-center space-y-4">
                    <CheckCircle className="mx-auto text-luppa-green" size={40} strokeWidth={1.5} />
                    <h2 className="text-xl font-semibold">Conta ativada!</h2>
                    <p className="text-muted-foreground text-sm max-w-sm mx-auto">
                        {done.message}
                    </p>
                    <Button
                        data-testid="go-to-dashboard-btn"
                        onClick={() => navigate(`/${done.tenantSlug}/dashboard`)}
                        className="gap-2"
                    >
                        Acessar o sistema <ArrowRight size={15} />
                    </Button>
                </div>
            </PublicShell>
        );
    }

    const canSubmit =
        form.name.trim().length >= 2 &&
        validatePassword(form.password) &&
        form.password === form.confirm;

    const submit = async (e) => {
        e.preventDefault();
        if (!canSubmit) return;
        if (form.password !== form.confirm) {
            setError("As senhas não coincidem.");
            return;
        }
        if (!validatePassword(form.password)) {
            setError("Senha deve ter ao menos 8 caracteres e 1 número.");
            return;
        }
        setError(null);
        setLoading(true);
        try {
            const { data } = await api.post(`/invites/${token}/accept`, {
                name: form.name.trim(),
                password: form.password,
            });

            if (data.existing_user) {
                setDone({ message: data.message, tenantSlug: data.tenant_slug, existingUser: true });
                return;
            }

            // Novo usuário — salvar tokens e sessão
            loginWithTokens(data, data.tenant_slug);
            setDone({ message: data.message, tenantSlug: data.tenant_slug, existingUser: false });
        } catch (err) {
            const msg = extractError(err, null);
            // Mostrar mensagem genérica para erros de token (segurança)
            const isTokenErr =
                msg?.toLowerCase().includes("inválid") ||
                msg?.toLowerCase().includes("expirad") ||
                err?.response?.status === 400;

            setError(
                isTokenErr
                    ? "Este link de convite é inválido ou expirou. Solicite um novo convite ao administrador."
                    : (msg || "Ocorreu um erro. Tente novamente.")
            );
        } finally {
            setLoading(false);
        }
    };

    return (
        <PublicShell>
            <div className="space-y-6">
                <div className="text-center space-y-1">
                    <h2 className="text-2xl font-semibold tracking-tight" data-testid="accept-invite-title">
                        Ative sua conta
                    </h2>
                    <p className="text-sm text-muted-foreground">
                        Preencha seus dados para criar sua senha e acessar o sistema.
                    </p>
                </div>

                {error && (
                    <Alert variant="destructive">
                        <AlertTriangle size={15} className="mr-2 inline" />
                        <AlertDescription data-testid="accept-invite-error">{error}</AlertDescription>
                    </Alert>
                )}

                <form onSubmit={submit} className="space-y-4">
                    <div className="space-y-2">
                        <Label htmlFor="name">Nome completo</Label>
                        <Input
                            id="name"
                            placeholder="Como você gostaria de ser chamado"
                            value={form.name}
                            onChange={(e) => setF("name", e.target.value)}
                            required
                            autoFocus
                            data-testid="accept-name-input"
                        />
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="password">Senha</Label>
                        <div className="relative">
                            <Input
                                id="password"
                                type={showPwd ? "text" : "password"}
                                placeholder="Mínimo 8 caracteres e 1 número"
                                value={form.password}
                                onChange={(e) => setF("password", e.target.value)}
                                required
                                data-testid="accept-password-input"
                                className="pr-10"
                            />
                            <button
                                type="button"
                                onClick={() => setShowPwd((p) => !p)}
                                className="absolute inset-y-0 right-3 flex items-center text-muted-foreground hover:text-foreground"
                                tabIndex={-1}
                                aria-label={showPwd ? "Ocultar senha" : "Mostrar senha"}
                            >
                                {showPwd ? <EyeOff size={16} /> : <Eye size={16} />}
                            </button>
                        </div>
                        {form.password.length > 0 && <StrengthBar pwd={form.password} />}
                        {form.password.length > 0 && !validatePassword(form.password) && (
                            <p className="text-xs text-amber-600">
                                A senha precisa ter ao menos 8 caracteres e 1 número.
                            </p>
                        )}
                    </div>

                    <div className="space-y-2">
                        <Label htmlFor="confirm">Confirmar senha</Label>
                        <Input
                            id="confirm"
                            type={showPwd ? "text" : "password"}
                            placeholder="Repita a senha"
                            value={form.confirm}
                            onChange={(e) => setF("confirm", e.target.value)}
                            required
                            data-testid="accept-confirm-input"
                        />
                        {form.confirm.length > 0 && form.password !== form.confirm && (
                            <p className="text-xs text-luppa-error">As senhas não coincidem.</p>
                        )}
                    </div>

                    <Button
                        type="submit"
                        className="w-full gap-2"
                        disabled={loading || !canSubmit}
                        data-testid="accept-submit-btn"
                    >
                        {loading ? "Ativando conta…" : "Ativar minha conta"}
                        {!loading && <ArrowRight size={15} />}
                    </Button>
                </form>

                <p className="text-center text-xs text-muted-foreground">
                    Problemas com o link?{" "}
                    <a href="mailto:suporte@listadavez.com" className="underline hover:text-foreground">
                        Falar com o suporte
                    </a>
                </p>
            </div>
        </PublicShell>
    );
}

function PublicShell({ children }) {
    return (
        <div className="min-h-screen bg-[#f4f5f7] flex items-center justify-center p-4">
            <div className="w-full max-w-md space-y-8">
                {/* Logo / Brand */}
                <div className="text-center">
                    <div className="inline-flex items-center gap-2 font-bold text-xl tracking-tight">
                        <div className="w-8 h-8 bg-[#1a1a2e] rounded-md flex items-center justify-center">
                            <span className="text-white text-xs font-black">LV</span>
                        </div>
                        Lista da Vez
                    </div>
                </div>
                {/* Card */}
                <div className="bg-card rounded-xl shadow-sm border border-border/60 p-8">
                    {children}
                </div>
            </div>
        </div>
    );
}
