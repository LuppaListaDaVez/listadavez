import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import api, { extractError } from "@/lib/api";
import { useTenant } from "@/context/TenantContext";
import { PageHeader } from "@/components/Common";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

export default function StoreSettings() {
    const { tenantSlug, storeId: paramId } = useParams();
    const { context } = useTenant();
    const stores = context?.stores || [];
    const [storeId, setStoreId] = useState(paramId || stores[0]?.id || "");
    const [doc, setDoc] = useState(null);
    const [saving, setSaving] = useState(false);
    const multiFilas = !!context?.features?.multi_filas;

    useEffect(() => { if (!storeId && stores[0]) setStoreId(stores[0].id); }, [stores, storeId]);
    useEffect(() => { if (!storeId) return;
        api.get(`/tenants/${tenantSlug}/stores/${storeId}/settings`).then(({data}) => setDoc(data));
    }, [tenantSlug, storeId]);

    const setQ = (k, v) => setDoc({ ...doc, queue_settings: { ...doc.queue_settings, [k]: v } });
    const setN = (k, v) => setDoc({ ...doc, notification_settings: { ...doc.notification_settings, [k]: v } });
    const setR = (k, v) => setDoc({ ...doc, realtime_settings: { ...doc.realtime_settings, [k]: v } });

    const save = async () => { setSaving(true);
        try { await api.put(`/tenants/${tenantSlug}/stores/${storeId}/settings`, {
                queue_settings: doc.queue_settings, realtime_settings: doc.realtime_settings, notification_settings: doc.notification_settings,
            }); toast.success("Configurações salvas.");
        } catch (e) { toast.error(extractError(e, "Erro")); } finally { setSaving(false); }
    };

    if (!doc) return <p className="text-sm text-muted-foreground">Carregando…</p>;
    return (
        <div>
            <PageHeader eyebrow="Operação" title="Configurações da unidade" description="Parâmetros de fila, tempo real e notificações.">
                <Select value={storeId} onValueChange={setStoreId}>
                    <SelectTrigger className="w-56" data-testid="store-select"><SelectValue/></SelectTrigger>
                    <SelectContent>{stores.map((s)=><SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent>
                </Select>
                <Button onClick={save} disabled={saving} data-testid="settings-save">{saving?"Salvando…":"Salvar"}</Button>
            </PageHeader>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="border border-border shadow-sm"><CardContent className="p-6 space-y-4">
                    <h3 className="font-sans text-lg font-semibold">Fila</h3>
                    <Toggle label="Múltiplas filas (multi_filas necessário)" disabled={!multiFilas} value={doc.queue_settings.allow_multiple_queues} onChange={(v)=>setQ("allow_multiple_queues", v)} tid="q-multi"/>
                    <Toggle label="Vendedor em múltiplas filas" disabled={!multiFilas} value={doc.queue_settings.seller_can_join_multiple_queues} onChange={(v)=>setQ("seller_can_join_multiple_queues", v)} tid="q-seller-multi"/>
                    <Toggle label="Voltar para o fim após atendimento" value={doc.queue_settings.return_to_end_after_attendance} onChange={(v)=>setQ("return_to_end_after_attendance", v)} tid="q-return-end"/>
                    <Toggle label="Motivo de perda obrigatório" value={doc.queue_settings.require_loss_reason} onChange={(v)=>setQ("require_loss_reason", v)} tid="q-loss"/>
                    <Toggle label="Valor da venda obrigatório" value={doc.queue_settings.require_sale_amount} onChange={(v)=>setQ("require_sale_amount", v)} tid="q-amount"/>
                    <Toggle label="Permitir atendimento inválido" value={doc.queue_settings.allow_invalid_attendance} onChange={(v)=>setQ("allow_invalid_attendance", v)} tid="q-invalid"/>
                    <Toggle label="Voltar para o fim ao retornar da pausa" value={doc.queue_settings.return_from_break_to_end} onChange={(v)=>setQ("return_from_break_to_end", v)} tid="q-break-end"/>
                    <Toggle label="Permitir reordenar pelo gerente" value={doc.queue_settings.allow_manager_reorder} onChange={(v)=>setQ("allow_manager_reorder", v)} tid="q-reorder"/>
                    <Toggle label="Atendimento por preferência habilitado" value={doc.queue_settings.preference_enabled !== false} onChange={(v)=>setQ("preference_enabled", v)} tid="q-preference-enabled"/>
                    <div className="space-y-2">
                        <Label>Retorno após atendimento por preferência</Label>
                        <Select value={doc.queue_settings.preference_return_rule || "PREVIOUS_POSITION"} onValueChange={(v)=>setQ("preference_return_rule", v)}>
                            <SelectTrigger data-testid="q-preference-return-rule"><SelectValue /></SelectTrigger>
                            <SelectContent>
                                <SelectItem value="TO_TOP">Voltar ao topo</SelectItem>
                                <SelectItem value="PREVIOUS_POSITION">Voltar à posição anterior</SelectItem>
                                <SelectItem value="TO_END">Ir ao final</SelectItem>
                                <SelectItem value="CONSUME_TURN">Perder a vez</SelectItem>
                            </SelectContent>
                        </Select>
                        <p className="text-xs text-muted-foreground">A regra é copiada no início do atendimento; mudanças futuras não afetam atendimentos em andamento.</p>
                    </div>
                    <div className="space-y-2"><Label>Notificar quando faltar X posições</Label>
                        <Input type="number" value={doc.queue_settings.notify_when_positions_before} onChange={(e)=>setQ("notify_when_positions_before", parseInt(e.target.value||"0"))} data-testid="q-notify-pos"/>
                    </div>
                </CardContent></Card>
                <div className="space-y-6">
                    <Card className="border border-border shadow-sm"><CardContent className="p-6 space-y-4">
                        <h3 className="font-sans text-lg font-semibold">Tempo real</h3>
                        <Toggle label="Habilitado" value={doc.realtime_settings.enabled} onChange={(v)=>setR("enabled", v)} tid="r-enabled"/>
                        <div className="space-y-2"><Label>Polling fallback (segundos)</Label>
                            <Input type="number" value={doc.realtime_settings.fallback_polling_seconds} onChange={(e)=>setR("fallback_polling_seconds", parseInt(e.target.value||"0"))} data-testid="r-poll"/>
                        </div>
                    </CardContent></Card>
                    <Card className="border border-border shadow-sm"><CardContent className="p-6 space-y-4">
                        <h3 className="font-sans text-lg font-semibold">Notificações</h3>
                        <Toggle label="Notificar vendedor da vez" value={doc.notification_settings.notify_seller_turn} onChange={(v)=>setN("notify_seller_turn", v)} tid="n-turn"/>
                        <Toggle label="Notificar posições anteriores" value={doc.notification_settings.notify_positions_before} onChange={(v)=>setN("notify_positions_before", v)} tid="n-pos"/>
                        <Toggle label="Notificar feedback recebido" value={doc.notification_settings.notify_feedback_received} onChange={(v)=>setN("notify_feedback_received", v)} tid="n-feedback"/>
                    </CardContent></Card>
                </div>
            </div>
        </div>
    );
}

function Toggle({ label, value, onChange, disabled, tid }) {
    return (
        <div className="flex items-center justify-between gap-4">
            <Label className={disabled ? "text-muted-foreground" : ""}>{label}</Label>
            <Switch checked={!!value} onCheckedChange={onChange} disabled={disabled} data-testid={tid}/>
        </div>
    );
}
