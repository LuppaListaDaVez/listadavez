import React, { useState, useRef, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import api, { extractError } from "@/lib/api";
import { useTenant } from "@/context/TenantContext";
import { usePermissions } from "@/hooks/usePermissions";
import { ROLE_PT } from "@/lib/i18n";
import { PageHeader } from "@/components/Common";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Camera, X } from "lucide-react";

const MAX_AVATAR_BYTES = 350_000; // ~350 KB base64 antes de encode

const STORE_ID_REQUIRED = new Set(["REGIONAL_MANAGER", "STORE_MANAGER", "SUPERVISOR", "SELLER"]);

const ALL_ROLES = [
    { value: "TENANT_ADMIN", label: "Admin do Tenant" },
    { value: "REGIONAL_MANAGER", label: "Gerente Regional" },
    { value: "STORE_MANAGER", label: "Gerente de Loja" },
    { value: "SUPERVISOR", label: "Supervisor" },
    { value: "SELLER", label: "Vendedor" },
];

export default function UserNew() {
    const { tenantSlug } = useParams();
    const { context } = useTenant();
    const { role: currentRole } = usePermissions();
    const nav = useNavigate();
    const fileRef = useRef(null);

    const availableRoles = currentRole === "TENANT_ADMIN"
        ? ALL_ROLES
        : ALL_ROLES.filter((r) => r.value !== "TENANT_ADMIN");

    const [form, setForm] = useState({
        name: "",
        email: "",
        phone: "",
        password: "",
        role: "SELLER",
        store_ids: [],
        avatar_url: null,
        team_id: "",
    });
    const [avatarPreview, setAvatarPreview] = useState(null);
    const [err, setErr] = useState(null);
    const [loading, setLoading] = useState(false);
    const [teams, setTeams] = useState([]);

    const setF = (k, v) => setForm((p) => ({ ...p, [k]: v }));
    const toggleStore = (id, checked) => {
        setF("store_ids", checked ? [...form.store_ids, id] : form.store_ids.filter((s) => s !== id));
    };

    const handleAvatarChange = (e) => {
        const file = e.target.files[0];
        if (!file) return;
        if (file.size > MAX_AVATAR_BYTES) {
            setErr("Foto muito grande. Máximo 350 KB.");
            return;
        }
        const reader = new FileReader();
        reader.onload = (ev) => {
            const dataUrl = ev.target.result;
            setAvatarPreview(dataUrl);
            setF("avatar_url", dataUrl);
        };
        reader.readAsDataURL(file);
    };

    const removeAvatar = () => {
        setAvatarPreview(null);
        setF("avatar_url", null);
        if (fileRef.current) fileRef.current.value = "";
    };

    const storeRequired = STORE_ID_REQUIRED.has(form.role);

    // Carregar equipes quando role=SELLER e uma unidade estiver selecionada
    useEffect(() => {
        if (form.role === "SELLER" && form.store_ids.length > 0) {
            api.get(`/tenants/${tenantSlug}/teams`)
                .then(({ data }) => setTeams(data.filter((t) => t.store_id === form.store_ids[0] && t.status === "ACTIVE")))
                .catch(() => setTeams([]));
        } else {
            setTeams([]);
            setF("team_id", "");
        }
    }, [form.role, form.store_ids[0]]);

    const submit = async (e) => {
        e.preventDefault();
        setErr(null);
        if (storeRequired && form.store_ids.length === 0) {
            setErr(`Vincule ao menos uma unidade para o papel ${ROLE_PT[form.role] || form.role}.`);
            return;
        }
        setLoading(true);
        try {
            await api.post(`/tenants/${tenantSlug}/users`, {
                name: form.name,
                email: form.email,
                phone: form.phone,
                password: form.password,
                role: form.role,
                store_ids: form.store_ids,
                avatar_url: form.avatar_url,
                team_id: form.team_id || null,
            });
            nav(`/${tenantSlug}/users`);
        } catch (e) {
            setErr(extractError(e, "Erro ao criar usuário"));
            setLoading(false);
        }
    };

    return (
        <div>
            <PageHeader eyebrow="Equipe" title="Novo usuário" description="Adicione um membro à empresa." />
            <Card className="border border-border shadow-sm max-w-3xl">
                <CardContent className="p-6">
                    <form onSubmit={submit} className="grid grid-cols-1 md:grid-cols-2 gap-5">
                        {err && (
                            <div className="md:col-span-2">
                                <Alert variant="destructive">
                                    <AlertDescription data-testid="new-user-error">{err}</AlertDescription>
                                </Alert>
                            </div>
                        )}

                        {/* Avatar */}
                        <div className="md:col-span-2 flex items-center gap-4">
                            <div className="relative">
                                <div className="w-16 h-16 rounded-full bg-muted border-2 border-dashed border-border flex items-center justify-center overflow-hidden">
                                    {avatarPreview
                                        ? <img src={avatarPreview} alt="avatar" className="w-full h-full object-cover" />
                                        : <Camera size={20} className="text-muted-foreground" />
                                    }
                                </div>
                                {avatarPreview && (
                                    <button
                                        type="button"
                                        onClick={removeAvatar}
                                        className="absolute -top-1 -right-1 bg-destructive text-destructive-foreground rounded-full w-5 h-5 flex items-center justify-center"
                                        data-testid="remove-avatar-btn"
                                    >
                                        <X size={10} />
                                    </button>
                                )}
                            </div>
                            <div>
                                <Label className="text-sm font-medium">Foto do usuário</Label>
                                <p className="text-xs text-muted-foreground mb-1">JPG ou PNG, máx. 350 KB</p>
                                <Button
                                    type="button"
                                    variant="outline"
                                    size="sm"
                                    onClick={() => fileRef.current?.click()}
                                    data-testid="upload-avatar-btn"
                                >
                                    {avatarPreview ? "Trocar foto" : "Selecionar foto"}
                                </Button>
                                <input
                                    ref={fileRef}
                                    type="file"
                                    accept="image/jpeg,image/png,image/webp"
                                    className="hidden"
                                    onChange={handleAvatarChange}
                                    data-testid="avatar-file-input"
                                />
                            </div>
                        </div>

                        <Field label="Nome completo">
                            <Input value={form.name} onChange={(e) => setF("name", e.target.value)} required data-testid="user-name-input" />
                        </Field>
                        <Field label="E-mail">
                            <Input type="email" value={form.email} onChange={(e) => setF("email", e.target.value)} required data-testid="user-email-input" />
                        </Field>
                        <Field label="Telefone">
                            <Input value={form.phone} onChange={(e) => setF("phone", e.target.value)} data-testid="user-phone-input" />
                        </Field>
                        <Field label="Senha inicial">
                            <Input type="password" value={form.password} onChange={(e) => setF("password", e.target.value)} required data-testid="user-password-input" />
                        </Field>
                        <Field label="Papel">
                            <Select value={form.role} onValueChange={(v) => setF("role", v)}>
                                <SelectTrigger data-testid="user-role-select"><SelectValue /></SelectTrigger>
                                <SelectContent>
                                    {availableRoles.map((r) => (
                                        <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </Field>

                        {(context?.stores || []).length > 0 && (
                            <div className="md:col-span-2 space-y-2">
                                <Label>
                                    Unidades vinculadas
                                    {storeRequired
                                        ? <span className="text-luppa-error ml-1">*</span>
                                        : <span className="text-xs text-muted-foreground ml-2">(Deixe vazio para acesso total ao tenant)</span>
                                    }
                                </Label>
                                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mt-2">
                                    {(context.stores || []).map((s) => (
                                        <label key={s.id} className="flex items-center gap-2 text-sm cursor-pointer">
                                            <Checkbox
                                                checked={form.store_ids.includes(s.id)}
                                                onCheckedChange={(v) => toggleStore(s.id, !!v)}
                                                data-testid={`user-store-checkbox-${s.code}`}
                                            />
                                            <span>{s.name}</span>
                                        </label>
                                    ))}
                                </div>
                                {storeRequired && form.store_ids.length === 0 && (
                                    <p className="text-xs text-amber-600">Obrigatório para este papel.</p>
                                )}
                            </div>
                        )}

                        {/* Seletor de equipe para SELLER */}
                        {form.role === "SELLER" && form.store_ids.length > 0 && (
                            <div className="md:col-span-2 space-y-2">
                                <Label>
                                    Equipe
                                    <span className="text-xs text-muted-foreground ml-2">(opcional)</span>
                                </Label>
                                {teams.length === 0 ? (
                                    <p className="text-xs text-muted-foreground">Nenhuma equipe ativa nesta unidade.</p>
                                ) : (
                                    <Select value={form.team_id || "__none__"} onValueChange={(v) => setF("team_id", v === "__none__" ? "" : v)}>
                                        <SelectTrigger data-testid="user-team-select">
                                            <SelectValue placeholder="Sem equipe" />
                                        </SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="__none__">Sem equipe</SelectItem>
                                            {teams.map((t) => (
                                                <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                )}
                            </div>
                        )}

                        <div className="md:col-span-2 flex justify-end gap-2 pt-4">
                            <Button type="button" variant="outline" onClick={() => nav(`/${tenantSlug}/users`)}>Cancelar</Button>
                            <Button type="submit" disabled={loading} data-testid="create-user-submit">
                                {loading ? "Criando…" : "Criar usuário"}
                            </Button>
                        </div>
                    </form>
                </CardContent>
            </Card>
        </div>
    );
}

function Field({ label, children }) {
    return (
        <div className="space-y-2">
            <Label>{label}</Label>
            {children}
        </div>
    );
}
