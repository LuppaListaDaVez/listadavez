import React, { useEffect, useState, useCallback } from "react";
import { useParams } from "react-router-dom";
import { Save, Shield, Eye, EyeOff, Check } from "lucide-react";
import api from "@/lib/api";
import { PageHeader } from "@/components/Common";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { usePermissions } from "@/hooks/usePermissions";

function Toggle({ checked, onChange, testId }) {
    return (
        <button type="button" role="switch" aria-checked={checked} onClick={() => onChange(!checked)} data-testid={testId}
            className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors ${checked ? "bg-foreground" : "bg-muted-foreground/30"}`}>
            <span className={`inline-block h-3.5 w-3.5 transform rounded-full bg-background shadow transition-transform ${checked ? "translate-x-5" : "translate-x-1"}`} />
        </button>
    );
}

function SettingRow({ label, description, checked, onChange, testId }) {
    return (
        <div className="flex items-center justify-between py-3 border-b border-border last:border-0">
            <div className="min-w-0 pr-4">
                <p className="text-sm font-medium">{label}</p>
                {description && <p className="text-xs text-muted-foreground mt-0.5">{description}</p>}
            </div>
            <Toggle checked={!!checked} onChange={onChange} testId={testId} />
        </div>
    );
}

export default function DataProtectionSettingsPage() {
    const { tenantSlug } = useParams();
    const { hasPermission } = usePermissions();
    const [settings, setSettings] = useState(null);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [saved, setSaved] = useState(false);
    const canEdit = hasPermission("privacy.settings.update");

    const load = useCallback(async () => {
        setLoading(true);
        try {
            const res = await api.get(`/tenants/${tenantSlug}/settings/data-protection`);
            setSettings(res.data);
        } catch {
            toast.error("Erro ao carregar configurações.");
        } finally {
            setLoading(false);
        }
    }, [tenantSlug]);

    useEffect(() => { load(); }, [load]);

    const handleSave = async () => {
        if (!settings) return;
        setSaving(true);
        try {
            const res = await api.put(`/tenants/${tenantSlug}/settings/data-protection`, settings);
            setSettings(res.data);
            setSaved(true);
            toast.success("Configurações salvas!");
            setTimeout(() => setSaved(false), 3000);
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Erro ao salvar.");
        } finally {
            setSaving(false);
        }
    };

    const set = (key, val) => setSettings(s => ({ ...s, [key]: val }));

    return (
        <div data-testid="data-protection-settings-page">
            <div className="flex items-start justify-between mb-6">
                <PageHeader eyebrow="Privacidade" title="Config. de Proteção de Dados" description="Contato do DPO, mascaramento padrão e políticas de privacidade." />
                {canEdit && (
                    <Button size="sm" onClick={handleSave} disabled={saving || !settings} className="mt-1" data-testid="save-privacy-settings-btn">
                        {saved ? <><Check size={14} className="mr-2" />Salvo</> : saving ? "Salvando..." : <><Save size={14} className="mr-2" />Salvar</>}
                    </Button>
                )}
            </div>

            {loading || !settings ? (
                <div className="space-y-4"><Skeleton className="h-48" /><Skeleton className="h-48" /></div>
            ) : (
                <div className="space-y-5 max-w-2xl">
                    {/* Contato DPO */}
                    <Card className="border border-border shadow-sm">
                        <CardContent className="p-5">
                            <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground mb-1">Responsável de Privacidade (DPO)</p>
                            <p className="text-sm text-muted-foreground mb-4">Contato responsável por solicitações LGPD.</p>
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="text-xs text-muted-foreground mb-1 block">Nome do DPO</label>
                                    <input className="w-full border border-border rounded-sm px-3 py-2 text-sm bg-background" value={settings.dpo_name || ""} onChange={e => set("dpo_name", e.target.value)} disabled={!canEdit} data-testid="dpo-name-input" placeholder="Nome completo" />
                                </div>
                                <div>
                                    <label className="text-xs text-muted-foreground mb-1 block">E-mail do DPO</label>
                                    <input type="email" className="w-full border border-border rounded-sm px-3 py-2 text-sm bg-background" value={settings.dpo_email || ""} onChange={e => set("dpo_email", e.target.value)} disabled={!canEdit} data-testid="dpo-email-input" placeholder="dpo@empresa.com" />
                                </div>
                                <div>
                                    <label className="text-xs text-muted-foreground mb-1 block">Contato de Privacidade</label>
                                    <input className="w-full border border-border rounded-sm px-3 py-2 text-sm bg-background" value={settings.privacy_contact_name || ""} onChange={e => set("privacy_contact_name", e.target.value)} disabled={!canEdit} placeholder="Nome" />
                                </div>
                                <div>
                                    <label className="text-xs text-muted-foreground mb-1 block">E-mail de Privacidade</label>
                                    <input type="email" className="w-full border border-border rounded-sm px-3 py-2 text-sm bg-background" value={settings.privacy_contact_email || ""} onChange={e => set("privacy_contact_email", e.target.value)} disabled={!canEdit} placeholder="privacidade@empresa.com" />
                                </div>
                            </div>
                        </CardContent>
                    </Card>

                    {/* Mascaramento */}
                    <Card className="border border-border shadow-sm">
                        <CardContent className="p-5">
                            <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground mb-1">Mascaramento Padrão</p>
                            <p className="text-sm text-muted-foreground mb-4">Controla quais dados são mascarados por padrão em telas não sensíveis.</p>
                            <SettingRow label="Mascarar telefone de cliente" description="Ex: 11987654321 → 11*****4321" checked={settings.mask_customer_phone_by_default} onChange={v => set("mask_customer_phone_by_default", v)} testId="toggle-mask-phone" />
                            <SettingRow label="Mascarar e-mail de cliente" description="Ex: c@email.com → c*****@email.com" checked={settings.mask_customer_email_by_default} onChange={v => set("mask_customer_email_by_default", v)} testId="toggle-mask-email" />
                        </CardContent>
                    </Card>

                    {/* Visibilidade de dados financeiros */}
                    <Card className="border border-border shadow-sm">
                        <CardContent className="p-5">
                            <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground mb-1">Visibilidade de Dados</p>
                            <p className="text-sm text-muted-foreground mb-4">Controla o que pode ser exibido em eventos públicos e motivacionais.</p>
                            <SettingRow label="Exibir valores de vendas em público" description="Permite exibir totais de vendas em rankings e dashboards." checked={settings.allow_public_sales_amounts} onChange={v => set("allow_public_sales_amounts", v)} testId="toggle-public-sales" />
                            <SettingRow label="Exibir valores financeiros em eventos motivacionais" description="Ex: 'João bateu R$10.000 em vendas!'" checked={settings.allow_motivation_financial_values} onChange={v => set("allow_motivation_financial_values", v)} testId="toggle-motivation-values" />
                        </CardContent>
                    </Card>

                    {/* URLs */}
                    <Card className="border border-border shadow-sm">
                        <CardContent className="p-5">
                            <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground mb-1">Documentos Legais</p>
                            <div className="grid grid-cols-1 gap-4 mt-3">
                                <div>
                                    <label className="text-xs text-muted-foreground mb-1 block">URL da Política de Privacidade</label>
                                    <input type="url" className="w-full border border-border rounded-sm px-3 py-2 text-sm bg-background" value={settings.privacy_policy_url || ""} onChange={e => set("privacy_policy_url", e.target.value)} disabled={!canEdit} data-testid="privacy-policy-url-input" placeholder="https://empresa.com/privacidade" />
                                </div>
                                <div>
                                    <label className="text-xs text-muted-foreground mb-1 block">URL dos Termos de Uso</label>
                                    <input type="url" className="w-full border border-border rounded-sm px-3 py-2 text-sm bg-background" value={settings.terms_url || ""} onChange={e => set("terms_url", e.target.value)} disabled={!canEdit} data-testid="terms-url-input" placeholder="https://empresa.com/termos" />
                                </div>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            )}
        </div>
    );
}
