import React, { useEffect, useRef, useState } from "react";
import { Link, useParams } from "react-router-dom";
import api, { extractError } from "@/lib/api";
import { useTenant } from "@/context/TenantContext";
import { usePermissions } from "@/hooks/usePermissions";
import { useAuth } from "@/context/AuthContext";
import { PageHeader, EmptyState } from "@/components/Common";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
    Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
    Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
    Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
    AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
    AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Plus, Pencil, UserX, UserCheck, Send, Clock, UserPlus, KeyRound, Mail, Camera, X, Trash2 } from "lucide-react";
import { toast } from "sonner";

const MAX_AVATAR_BYTES = 350_000;

const ROLES = [
    { value: "TENANT_ADMIN", label: "Admin do Tenant" },
    { value: "REGIONAL_MANAGER", label: "Gerente Regional" },
    { value: "STORE_MANAGER", label: "Gerente de Loja" },
    { value: "SUPERVISOR", label: "Supervisor" },
    { value: "SELLER", label: "Vendedor" },
];

const ROLE_LABELS = Object.fromEntries(ROLES.map((r) => [r.value, r.label]));

function formatExpiry(expiresAt) {
    if (!expiresAt) return "–";
    const d = new Date(expiresAt);
    const diffMs = d - Date.now();
    const diffH = Math.round(diffMs / 3_600_000);
    if (diffMs < 0) return "Expirado";
    if (diffH < 1) return "< 1 hora";
    if (diffH < 24) return `${diffH}h restantes`;
    return `${Math.round(diffH / 24)}d restantes`;
}

function UserAvatar({ src, name, size = 8 }) {
    const initials = (name || "?").split(" ").slice(0, 2).map((n) => n[0]).join("").toUpperCase();
    if (src) {
        return (
            <img
                src={src}
                alt={name}
                className={`w-${size} h-${size} rounded-full object-cover border border-border`}
            />
        );
    }
    return (
        <div className={`w-${size} h-${size} rounded-full bg-primary/10 text-primary flex items-center justify-center text-xs font-semibold border border-border`}>
            {initials}
        </div>
    );
}

export default function UsersList() {
    const { tenantSlug } = useParams();
    const { context } = useTenant();
    const { hasPermission, role } = usePermissions();
    const { user: currentUser } = useAuth();
    const canCreate = hasPermission("users.create");
    const canEdit = hasPermission("users.update");
    const canChangeStatus = hasPermission("users.status_change");
    const canChangeRole = hasPermission("users.change_role");
    const canDelete = role === "TENANT_ADMIN";
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [editTarget, setEditTarget] = useState(null);
    const [pwdTarget, setPwdTarget] = useState(null);
    const [deleteTarget, setDeleteTarget] = useState(null);
    const [deleting, setDeleting] = useState(false);
    const [invites, setInvites] = useState([]);
    const [resendingInvite, setResendingInvite] = useState(null);
    const [sendingReset, setSendingReset] = useState(null);

    const load = async () => {
        setLoading(true);
        const { data } = await api.get(`/tenants/${tenantSlug}/users`);
        setUsers(data);
        setLoading(false);
    };

    const loadInvites = async () => {
        try {
            const { data } = await api.get(`/tenants/${tenantSlug}/users/invites`);
            setInvites(data.invites || []);
        } catch {
            // sem permissão ou falha silenciosa
        }
    };

    const handleDeleteUser = async () => {
        if (!deleteTarget) return;
        setDeleting(true);
        try {
            await api.delete(`/tenants/${tenantSlug}/users/${deleteTarget.id}`);
            toast.success(`Usuário "${deleteTarget.name}" excluído com sucesso.`);
            setDeleteTarget(null);
            load();
        } catch (e) {
            toast.error(extractError(e, "Erro ao excluir usuário"));
        } finally {
            setDeleting(false);
        }
    };

    useEffect(() => { load(); loadInvites(); }, [tenantSlug]);

    const toggleStatus = async (user) => {
        const newStatus = user.status === "ACTIVE" ? "INACTIVE" : "ACTIVE";
        try {
            await api.patch(`/tenants/${tenantSlug}/users/${user.id}/status`, { status: newStatus });
            toast.success(`Usuário ${newStatus === "ACTIVE" ? "ativado" : "inativado"}.`);
            load();
        } catch (e) { toast.error(extractError(e, "Erro ao atualizar status")); }
    };

    const resendInvite = async (inviteId) => {
        setResendingInvite(inviteId);
        try {
            await api.post(`/tenants/${tenantSlug}/users/invite/${inviteId}/resend`);
            toast.success("Convite reenviado com sucesso.");
            loadInvites();
        } catch (e) {
            toast.error(extractError(e, "Erro ao reenviar convite"));
        } finally {
            setResendingInvite(null);
        }
    };

    const sendPasswordReset = async (user) => {
        setSendingReset(user.id);
        try {
            await api.post(`/tenants/${tenantSlug}/auth/password-reset/request`, { email: user.email });
            toast.success(`Link de redefinição enviado para ${user.email}.`);
        } catch (e) {
            toast.error(extractError(e, "Erro ao enviar link"));
        } finally {
            setSendingReset(null);
        }
    };

    return (
        <div>
            <PageHeader eyebrow="Equipe" title="Usuários" description="Membros da empresa.">
                {canCreate && (
                    <div className="flex gap-2">
                        <Link to={`/${tenantSlug}/users/invite`}>
                            <Button variant="outline" data-testid="invite-user-button" className="gap-2">
                                <UserPlus size={16} strokeWidth={1.5} /> Convidar funcionário
                            </Button>
                        </Link>
                        <Link to={`/${tenantSlug}/users/new`}>
                            <Button data-testid="new-user-button" className="gap-2">
                                <Plus size={16} strokeWidth={1.5} /> Novo usuário
                            </Button>
                        </Link>
                    </div>
                )}
            </PageHeader>

            {loading ? (
                <p className="text-sm text-muted-foreground">Carregando…</p>
            ) : users.length === 0 ? (
                <EmptyState
                    title="Sem usuários cadastrados"
                    description="Adicione um usuário para começar a montar sua equipe."
                    action={
                        <Link to={`/${tenantSlug}/users/new`}>
                            <Button>Novo usuário</Button>
                        </Link>
                    }
                />
            ) : (
                <Card className="border border-border shadow-sm">
                    <CardContent className="p-0">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Usuário</TableHead>
                                    <TableHead>E-mail</TableHead>
                                    <TableHead>Papel</TableHead>
                                    <TableHead>Status</TableHead>
                                    <TableHead className="text-right">Ações</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {users.map((u) => (
                                    <TableRow key={u.id} data-testid={`user-row-${u.email}`}>
                                        <TableCell>
                                            <div className="flex items-center gap-2">
                                                <UserAvatar src={u.avatar_url} name={u.name} />
                                                <span className="font-medium">{u.name}</span>
                                            </div>
                                        </TableCell>
                                        <TableCell className="font-mono text-xs">{u.email}</TableCell>
                                        <TableCell>
                                            <Badge variant="secondary">{ROLE_LABELS[u.role] || u.role}</Badge>
                                        </TableCell>
                                        <TableCell>
                                            <Badge variant={u.status === "ACTIVE" ? "default" : "outline"}>{u.status === "ACTIVE" ? "Ativo" : "Inativo"}</Badge>
                                        </TableCell>
                                        <TableCell className="text-right">
                                            <div className="flex justify-end gap-1">
                                                {canEdit && (
                                                    <Button size="sm" variant="ghost" onClick={() => setEditTarget(u)} data-testid={`edit-user-${u.email}`}>
                                                        <Pencil size={15} />
                                                    </Button>
                                                )}
                                                {canEdit && (
                                                    <Button
                                                        size="sm" variant="ghost"
                                                        title="Alterar senha"
                                                        onClick={() => setPwdTarget(u)}
                                                        data-testid={`set-password-${u.email}`}
                                                    >
                                                        <KeyRound size={15} />
                                                    </Button>
                                                )}
                                                {canEdit && (
                                                    <Button
                                                        size="sm" variant="ghost"
                                                        title="Enviar link de redefinição de senha"
                                                        disabled={sendingReset === u.id}
                                                        onClick={() => sendPasswordReset(u)}
                                                        data-testid={`send-reset-${u.email}`}
                                                    >
                                                        <Mail size={15} />
                                                    </Button>
                                                )}
                                                {canChangeStatus && (
                                                    <AlertDialog>
                                                        <AlertDialogTrigger asChild>
                                                            <Button size="sm" variant="ghost" data-testid={`toggle-user-${u.email}`}>
                                                                {u.status === "ACTIVE"
                                                                    ? <UserX size={15} className="text-luppa-error" />
                                                                    : <UserCheck size={15} className="text-luppa-green" />}
                                                            </Button>
                                                        </AlertDialogTrigger>
                                                        <AlertDialogContent>
                                                            <AlertDialogHeader>
                                                                <AlertDialogTitle>{u.status === "ACTIVE" ? "Inativar usuário?" : "Ativar usuário?"}</AlertDialogTitle>
                                                                <AlertDialogDescription>
                                                                    {u.status === "ACTIVE"
                                                                        ? `${u.name} perderá acesso ao sistema.`
                                                                        : `${u.name} voltará a ter acesso ao sistema.`}
                                                                </AlertDialogDescription>
                                                            </AlertDialogHeader>
                                                            <AlertDialogFooter>
                                                                <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                                                <AlertDialogAction onClick={() => toggleStatus(u)} data-testid={`confirm-toggle-user-${u.email}`}>
                                                                    Confirmar
                                                                </AlertDialogAction>
                                                            </AlertDialogFooter>
                                                        </AlertDialogContent>
                                                    </AlertDialog>
                                                )}
                                                {/* Botão de excluir — apenas TENANT_ADMIN e não pode excluir a si mesmo */}
                                                {canDelete && u.id !== currentUser?.id && (
                                                    <Button
                                                        size="sm" variant="ghost"
                                                        title="Excluir usuário"
                                                        onClick={() => setDeleteTarget(u)}
                                                        data-testid={`delete-user-${u.email}`}
                                                    >
                                                        <Trash2 size={15} className="text-luppa-error" />
                                                    </Button>
                                                )}
                                            </div>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>
            )}

            {editTarget && (
                <EditUserDialog
                    tenantSlug={tenantSlug} user={editTarget} stores={context?.stores || []}
                    canChangeRole={canChangeRole}
                    onClose={() => setEditTarget(null)} onSaved={() => { setEditTarget(null); load(); }}
                />
            )}

            {pwdTarget && (
                <SetPasswordDialog
                    tenantSlug={tenantSlug} user={pwdTarget}
                    onClose={() => setPwdTarget(null)}
                />
            )}

            {/* ── Dialog de confirmação de exclusão ── */}
            <AlertDialog open={!!deleteTarget} onOpenChange={(o) => { if (!o) setDeleteTarget(null); }}>
                <AlertDialogContent data-testid="delete-user-dialog">
                    <AlertDialogHeader>
                        <AlertDialogTitle>Excluir usuário?</AlertDialogTitle>
                        <AlertDialogDescription>
                            <strong>{deleteTarget?.name}</strong> perderá acesso permanente a esta empresa.
                            Vendas, atendimentos e histórico serão preservados.
                            <br /><br />
                            Esta ação não pode ser desfeita pela interface.
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel disabled={deleting}>Cancelar</AlertDialogCancel>
                        <AlertDialogAction
                            onClick={handleDeleteUser}
                            disabled={deleting}
                            className="bg-luppa-error hover:bg-luppa-error text-white"
                            data-testid="confirm-delete-user-button"
                        >
                            {deleting ? "Excluindo…" : "Sim, excluir"}
                        </AlertDialogAction>
                    </AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>

            {/* Convites pendentes */}
            {invites.length > 0 && (
                <div className="mt-8">
                    <Card className="border border-border shadow-sm">
                        <CardHeader className="px-6 py-4 border-b border-border">
                            <CardTitle className="text-sm font-semibold flex items-center gap-2">
                                <Clock size={15} className="text-amber-500" />
                                Convites pendentes ({invites.length})
                            </CardTitle>
                        </CardHeader>
                        <CardContent className="p-0">
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>E-mail</TableHead>
                                        <TableHead>Cargo</TableHead>
                                        <TableHead>Expira em</TableHead>
                                        <TableHead className="text-right">Ações</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {invites.map((inv) => (
                                        <TableRow key={inv.id} data-testid={`invite-row-${inv.email}`}>
                                            <TableCell className="font-mono text-xs">{inv.email}</TableCell>
                                            <TableCell>
                                                <Badge variant="secondary">{ROLE_LABELS[inv.role] || inv.role}</Badge>
                                            </TableCell>
                                            <TableCell className="text-xs text-muted-foreground">
                                                {formatExpiry(inv.expires_at)}
                                            </TableCell>
                                            <TableCell className="text-right">
                                                <Button
                                                    size="sm" variant="ghost" className="gap-1.5 text-xs"
                                                    disabled={resendingInvite === inv.id}
                                                    onClick={() => resendInvite(inv.id)}
                                                    data-testid={`resend-user-invite-${inv.email}`}
                                                >
                                                    <Send size={13} />
                                                    {resendingInvite === inv.id ? "Reenviando…" : "Reenviar"}
                                                </Button>
                                            </TableCell>
                                        </TableRow>
                                    ))}
                                </TableBody>
                            </Table>
                        </CardContent>
                    </Card>
                </div>
            )}
        </div>
    );
}

// ─── Diálogo de Edição ─────────────────────────────────────────────────────
function EditUserDialog({ tenantSlug, user, stores, canChangeRole, onClose, onSaved }) {
    const fileRef = useRef(null);
    const [form, setForm] = useState({
        name: user.name || "",
        email: user.email || "",
        phone: user.phone || "",
        role: user.role || "SELLER",
        store_ids: user.store_ids || [],
        avatar_url: user.avatar_url || null,
        team_id: user.team_id || "",
    });
    const [avatarPreview, setAvatarPreview] = useState(user.avatar_url || null);
    const [saving, setSaving] = useState(false);
    const [teams, setTeams] = useState([]);
    const setF = (k, v) => setForm((p) => ({ ...p, [k]: v }));

    // Carrega equipes da unidade do vendedor
    useEffect(() => {
        const storeId = form.store_ids[0];
        if (form.role === "SELLER" && storeId) {
            api.get(`/tenants/${tenantSlug}/teams`)
                .then(({ data }) => setTeams(data.filter((t) => t.store_id === storeId && t.status === "ACTIVE")))
                .catch(() => setTeams([]));
        } else {
            setTeams([]);
        }
    }, [form.role, form.store_ids[0]]);

    const toggleStore = (id, checked) => {
        setF("store_ids", checked ? [...form.store_ids, id] : form.store_ids.filter((s) => s !== id));
    };

    const handleAvatarChange = (e) => {
        const file = e.target.files[0];
        if (!file) return;
        if (file.size > MAX_AVATAR_BYTES) {
            toast.error("Foto muito grande. Máximo 350 KB.");
            return;
        }
        const reader = new FileReader();
        reader.onload = (ev) => {
            setAvatarPreview(ev.target.result);
            setF("avatar_url", ev.target.result);
        };
        reader.readAsDataURL(file);
    };

    const removeAvatar = () => {
        setAvatarPreview(null);
        setF("avatar_url", "");
        if (fileRef.current) fileRef.current.value = "";
    };

    const submit = async (e) => {
        e.preventDefault();
        setSaving(true);
        try {
            await api.put(`/tenants/${tenantSlug}/users/${user.id}`, {
                ...form,
                team_id: form.team_id || null,
            });
            toast.success("Usuário atualizado.");
            onSaved();
        } catch (err) {
            toast.error(extractError(err, "Erro ao atualizar usuário"));
        } finally { setSaving(false); }
    };

    return (
        <Dialog open onOpenChange={onClose}>
            <DialogContent className="max-w-lg">
                <DialogHeader>
                    <DialogTitle>Editar usuário</DialogTitle>
                    <DialogDescription>Atualize os dados de {user.name}.</DialogDescription>
                </DialogHeader>
                <form onSubmit={submit} className="space-y-4">
                    {/* Avatar */}
                    <div className="flex items-center gap-4">
                        <div className="relative">
                            <div className="w-14 h-14 rounded-full bg-muted border-2 border-dashed border-border flex items-center justify-center overflow-hidden">
                                {avatarPreview
                                    ? <img src={avatarPreview} alt="avatar" className="w-full h-full object-cover" />
                                    : <Camera size={18} className="text-muted-foreground" />
                                }
                            </div>
                            {avatarPreview && (
                                <button
                                    type="button"
                                    onClick={removeAvatar}
                                    className="absolute -top-1 -right-1 bg-destructive text-destructive-foreground rounded-full w-5 h-5 flex items-center justify-center"
                                >
                                    <X size={10} />
                                </button>
                            )}
                        </div>
                        <div>
                            <p className="text-xs text-muted-foreground mb-1">JPG ou PNG, máx. 350 KB</p>
                            <Button type="button" variant="outline" size="sm" onClick={() => fileRef.current?.click()}>
                                {avatarPreview ? "Trocar foto" : "Adicionar foto"}
                            </Button>
                            <input
                                ref={fileRef}
                                type="file"
                                accept="image/jpeg,image/png,image/webp"
                                className="hidden"
                                onChange={handleAvatarChange}
                                data-testid="edit-avatar-file-input"
                            />
                        </div>
                    </div>

                    {/* E-mail (editável) */}
                    <div className="space-y-1">
                        <Label>E-mail</Label>
                        <Input
                            type="email"
                            value={form.email}
                            onChange={(e) => setF("email", e.target.value.toLowerCase().trim())}
                            required
                            data-testid="edit-user-email"
                            placeholder="novo@email.com"
                        />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                            <Label>Nome completo</Label>
                            <Input value={form.name} onChange={(e) => setF("name", e.target.value)} required data-testid="edit-user-name" />
                        </div>
                        <div className="space-y-2">
                            <Label>Telefone</Label>
                            <Input value={form.phone} onChange={(e) => setF("phone", e.target.value)} data-testid="edit-user-phone" />
                        </div>
                        <div className="space-y-2 md:col-span-2">
                            <Label>Papel</Label>
                            {canChangeRole ? (
                                <Select value={form.role} onValueChange={(v) => setF("role", v)}>
                                    <SelectTrigger data-testid="edit-user-role">
                                        <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {ROLES.map((r) => <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>)}
                                    </SelectContent>
                                </Select>
                            ) : (
                                <p className="text-sm text-muted-foreground border rounded-sm px-3 py-2">{ROLE_LABELS[form.role] || form.role}</p>
                            )}
                        </div>
                    </div>
                    {stores.length > 0 && (
                        <div className="space-y-2">
                            <Label>Unidades vinculadas</Label>
                            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                                {stores.map((s) => (
                                    <label key={s.id} className="flex items-center gap-2 text-sm cursor-pointer">
                                        <Checkbox
                                            checked={form.store_ids.includes(s.id)}
                                            onCheckedChange={(v) => toggleStore(s.id, !!v)}
                                            data-testid={`edit-user-store-${s.code}`}
                                        />
                                        <span>{s.name}</span>
                                    </label>
                                ))}
                            </div>
                        </div>
                    )}
                    {/* Seletor de equipe para SELLER */}
                    {form.role === "SELLER" && (
                        <div className="space-y-2">
                            <Label>
                                Equipe
                                <span className="text-xs text-muted-foreground ml-2">(opcional)</span>
                            </Label>
                            {teams.length === 0 ? (
                                <p className="text-xs text-muted-foreground">
                                    {form.store_ids.length === 0
                                        ? "Vincule uma unidade para ver as equipes disponíveis."
                                        : "Nenhuma equipe ativa nesta unidade."}
                                </p>
                            ) : (
                                <Select value={form.team_id || "__none__"} onValueChange={(v) => setF("team_id", v === "__none__" ? "" : v)}>
                                    <SelectTrigger data-testid="edit-user-team-select">
                                        <SelectValue placeholder="Sem equipe" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="__none__">Sem equipe</SelectItem>
                                        {teams.map((t) => (
                                            <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            )}
                        </div>
                    )}
                    <DialogFooter>
                        <Button type="button" variant="outline" onClick={onClose}>Cancelar</Button>
                        <Button type="submit" disabled={saving} data-testid="save-user-submit">
                            {saving ? "Salvando…" : "Salvar alterações"}
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}

// ─── Diálogo de Definir Senha ──────────────────────────────────────────────
function SetPasswordDialog({ tenantSlug, user, onClose }) {
    const [newPassword, setNewPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [saving, setSaving] = useState(false);

    const submit = async (e) => {
        e.preventDefault();
        if (newPassword.length < 8) {
            toast.error("A senha deve ter pelo menos 8 caracteres.");
            return;
        }
        if (newPassword !== confirmPassword) {
            toast.error("As senhas não coincidem.");
            return;
        }
        setSaving(true);
        try {
            await api.post(`/tenants/${tenantSlug}/users/${user.id}/set-password`, {
                new_password: newPassword,
            });
            toast.success(`Senha de ${user.name} alterada com sucesso.`);
            onClose();
        } catch (err) {
            toast.error(extractError(err, "Erro ao alterar senha"));
        } finally { setSaving(false); }
    };

    return (
        <Dialog open onOpenChange={onClose}>
            <DialogContent className="max-w-sm">
                <DialogHeader>
                    <DialogTitle>Alterar senha</DialogTitle>
                    <DialogDescription>Defina uma nova senha para <strong>{user.name}</strong>.</DialogDescription>
                </DialogHeader>
                <form onSubmit={submit} className="space-y-4">
                    <div className="space-y-2">
                        <Label>Nova senha</Label>
                        <Input
                            type="password"
                            value={newPassword}
                            onChange={(e) => setNewPassword(e.target.value)}
                            placeholder="Mínimo 8 caracteres"
                            required
                            data-testid="set-password-new"
                        />
                    </div>
                    <div className="space-y-2">
                        <Label>Confirmar nova senha</Label>
                        <Input
                            type="password"
                            value={confirmPassword}
                            onChange={(e) => setConfirmPassword(e.target.value)}
                            placeholder="Repita a senha"
                            required
                            data-testid="set-password-confirm"
                        />
                    </div>
                    <DialogFooter>
                        <Button type="button" variant="outline" onClick={onClose}>Cancelar</Button>
                        <Button type="submit" disabled={saving} data-testid="set-password-submit">
                            {saving ? "Salvando…" : "Alterar senha"}
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}
