import { useState, useEffect, useCallback } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
    ArrowLeft, ThumbsUp, AlertTriangle, MessageSquare, ClipboardList,
    CheckCircle, Clock, User, Calendar,
} from "lucide-react";
import { toast } from "sonner";
import api, { extractError } from "@/lib/api";
import { usePermissions } from "@/hooks/usePermissions";
import { fmtDate, fmtDateTime } from "@/lib/i18n";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

const TYPE_CONFIG = {
    POSITIVE: { label: "Positivo", icon: ThumbsUp, color: "text-luppa-green", bg: "bg-luppa-green/10 border-emerald-200" },
    CONSTRUCTIVE: { label: "Construtivo", icon: MessageSquare, color: "text-luppa-purple", bg: "bg-luppa-purple/10 border-luppa-purple/25" },
    WARNING: { label: "Aviso", icon: AlertTriangle, color: "text-amber-700", bg: "bg-amber-50 border-amber-200" },
    ACTION_PLAN: { label: "Plano de Ação", icon: ClipboardList, color: "text-luppa-purple", bg: "bg-luppa-purple/10 border-luppa-purple/25" },
};

const AP_STATUS_OPTS = [
    { value: "PENDING", label: "Pendente" },
    { value: "IN_PROGRESS", label: "Em andamento" },
    { value: "COMPLETED", label: "Concluído" },
];

const AP_STATUS_CLASSES = {
    PENDING: "bg-slate-100 text-slate-600",
    IN_PROGRESS: "bg-luppa-purple/15 text-luppa-purple",
    COMPLETED: "bg-luppa-green/15 text-luppa-green",
};

export default function FeedbackDetail() {
    const { tenantSlug, feedbackId } = useParams();
    const nav = useNavigate();
    const { role, hasPermission } = usePermissions();
    const [feedback, setFeedback] = useState(null);
    const [loading, setLoading] = useState(true);
    const [ackLoading, setAckLoading] = useState(false);
    const [apLoading, setApLoading] = useState(false);
    const [newApStatus, setNewApStatus] = useState("");

    const isSeller = role === "SELLER";

    const load = useCallback(async () => {
        try {
            const res = await api.get(`/tenants/${tenantSlug}/feedbacks/${feedbackId}`);
            setFeedback(res.data);
            setNewApStatus(res.data.action_plan?.status || "");
        } catch (e) {
            toast.error(extractError(e));
            nav(-1);
        } finally {
            setLoading(false);
        }
    }, [tenantSlug, feedbackId, nav]);

    useEffect(() => { load(); }, [load]);

    const handleAcknowledge = async () => {
        setAckLoading(true);
        try {
            await api.patch(`/tenants/${tenantSlug}/feedbacks/${feedbackId}/acknowledge`);
            toast.success("Leitura confirmada!");
            load();
        } catch (e) {
            toast.error(extractError(e));
        } finally {
            setAckLoading(false);
        }
    };

    const handleUpdateActionPlan = async () => {
        if (!newApStatus) return;
        setApLoading(true);
        try {
            await api.put(`/tenants/${tenantSlug}/feedbacks/${feedbackId}/action-plan`, { status: newApStatus });
            toast.success("Plano de ação atualizado!");
            load();
        } catch (e) {
            toast.error(extractError(e));
        } finally {
            setApLoading(false);
        }
    };

    if (loading) {
        return <p className="text-sm text-muted-foreground py-10 text-center">Carregando…</p>;
    }
    if (!feedback) return null;

    const cfg = TYPE_CONFIG[feedback.type] || TYPE_CONFIG.CONSTRUCTIVE;
    const Icon = cfg.icon;

    return (
        <div className="max-w-2xl space-y-6">
            {/* Header */}
            <div className="flex items-center gap-3">
                <Button variant="ghost" size="icon" onClick={() => nav(-1)} data-testid="btn-back">
                    <ArrowLeft size={16} />
                </Button>
                <div>
                    <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">Feedbacks</p>
                    <h1 className="text-2xl font-semibold mt-0.5 truncate">{feedback.title}</h1>
                </div>
            </div>

            {/* Card principal */}
            <div className="bg-card border border-border/60 rounded-md p-6 space-y-5" data-testid="feedback-detail-card">
                {/* Tipo badge */}
                <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded border text-sm font-medium ${cfg.bg} ${cfg.color}`}>
                    <Icon size={14} />
                    {cfg.label}
                </div>

                {/* Meta info */}
                <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="flex items-center gap-2 text-muted-foreground">
                        <User size={14} />
                        <span>De: <span className="text-foreground font-medium">{feedback.author_name}</span></span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                        <Calendar size={14} />
                        <span>{fmtDate(feedback.created_at)}</span>
                    </div>
                </div>

                {/* Período de referência */}
                {(feedback.period_start || feedback.period_end) && (
                    <div className="flex items-center gap-2 text-sm px-3 py-2 bg-luppa-purple/10 border border-luppa-purple/20 rounded-sm">
                        <Calendar size={13} className="text-luppa-purple flex-shrink-0" />
                        <span className="text-luppa-purple text-xs">
                            Período de referência:{" "}
                            <span className="font-medium">
                                {feedback.period_start
                                    ? fmtDate(feedback.period_start + "T12:00:00")
                                    : "—"}
                                {" → "}
                                {feedback.period_end
                                    ? fmtDate(feedback.period_end + "T12:00:00")
                                    : "—"}
                            </span>
                        </span>
                    </div>
                )}

                {/* Conteúdo */}
                <div>
                    <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">Conteúdo</p>
                    <p className="text-sm leading-relaxed whitespace-pre-wrap" data-testid="feedback-content">
                        {feedback.content}
                    </p>
                </div>

                {/* Status de confirmação */}
                <div className="flex items-center justify-between pt-2 border-t border-border">
                    <div className="flex items-center gap-2 text-sm">
                        {feedback.is_acknowledged ? (
                            <>
                                <CheckCircle size={14} className="text-luppa-green" />
                                <span className="text-luppa-green font-medium">Confirmado em {fmtDate(feedback.acknowledged_at)}</span>
                            </>
                        ) : (
                            <>
                                <Clock size={14} className="text-amber-500" />
                                <span className="text-amber-600">Aguardando confirmação de leitura</span>
                            </>
                        )}
                    </div>
                    {isSeller && !feedback.is_acknowledged && (
                        <Button
                            size="sm"
                            variant="outline"
                            onClick={handleAcknowledge}
                            disabled={ackLoading}
                            data-testid="btn-acknowledge"
                        >
                            <CheckCircle size={14} className="mr-1.5" />
                            {ackLoading ? "Confirmando…" : "Confirmar leitura"}
                        </Button>
                    )}
                </div>
            </div>

            {/* Plano de Ação */}
            {feedback.action_plan && (
                <div className="bg-luppa-purple/10/40 border border-luppa-purple/25 rounded-sm p-6 space-y-4" data-testid="action-plan-section">
                    <div className="flex items-center justify-between">
                        <p className="text-xs font-semibold uppercase tracking-wide text-luppa-purple">Plano de Ação</p>
                        <span className={`text-xs font-medium px-2 py-0.5 rounded ${AP_STATUS_CLASSES[feedback.action_plan.status] || ""}`} data-testid="ap-status-badge">
                            {AP_STATUS_OPTS.find((o) => o.value === feedback.action_plan.status)?.label || feedback.action_plan.status}
                        </span>
                    </div>

                    <p className="text-sm leading-relaxed" data-testid="ap-description">
                        {feedback.action_plan.description}
                    </p>

                    {feedback.action_plan.due_date && (
                        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                            <Clock size={12} />
                            Prazo: {fmtDate(feedback.action_plan.due_date + "T12:00:00")}
                        </div>
                    )}

                    {/* Vendedor pode atualizar status do plano */}
                    {isSeller && feedback.action_plan.status !== "COMPLETED" && (
                        <div className="flex items-center gap-3 pt-2 border-t border-luppa-purple/25">
                            <Select value={newApStatus} onValueChange={setNewApStatus}>
                                <SelectTrigger className="w-44 h-8 text-xs" data-testid="select-ap-status">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    {AP_STATUS_OPTS.map((o) => (
                                        <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                            <Button
                                size="sm"
                                onClick={handleUpdateActionPlan}
                                disabled={apLoading || newApStatus === feedback.action_plan.status}
                                data-testid="btn-update-ap"
                            >
                                {apLoading ? "Salvando…" : "Atualizar status"}
                            </Button>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
}
