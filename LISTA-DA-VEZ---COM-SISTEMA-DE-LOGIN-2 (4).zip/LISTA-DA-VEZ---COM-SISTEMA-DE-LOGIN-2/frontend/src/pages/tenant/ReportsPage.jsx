import React from "react";
import { Link, useParams } from "react-router-dom";
import { PageHeader } from "@/components/Common";
import { usePermissions } from "@/hooks/usePermissions";
import { Card, CardContent } from "@/components/ui/card";
import { ClipboardList, TrendingDown, BarChart2, Users, Package, Download, ShoppingBag, Clock3, Star } from "lucide-react";

const REPORT_CARDS = [
    {
        to: "reports/attendances",
        label: "Atendimentos",
        description: "Lista completa com filtros por data, loja, vendedor e resultado.",
        icon: ClipboardList,
        feature: "relatorios_basicos",
        perm: "reports.view_store",
        testId: "report-card-attendances",
    },
    {
        to: "reports/conversion",
        label: "Conversão",
        description: "Taxa de conversão por vendedor e por unidade com gráficos comparativos.",
        icon: TrendingDown,
        feature: "relatorios_basicos",
        perm: "reports.view_store",
        testId: "report-card-conversion",
    },
    {
        to: "reports/preference-attendances",
        label: "Atendimentos por Preferência",
        description: "Clientes que procuraram vendedores específicos, regras aplicadas e conversão.",
        icon: Star,
        feature: "relatorios_basicos",
        perm: "reports.view_store",
        testId: "report-card-preference-attendances",
    },
    {
        to: "reports/opportunity-flow",
        label: "Fluxo por Horário",
        description: "Oportunidades, conversão, vendas e receita por horário de início do atendimento.",
        icon: Clock3,
        feature: "relatorios_basicos",
        perm: "reports.view_store",
        testId: "report-card-opportunity-flow",
    },
    {
        to: "reports/loss-reasons",
        label: "Motivos de Perda",
        description: "Ranking dos motivos de não-venda mais frequentes.",
        icon: BarChart2,
        feature: "relatorios_basicos",
        perm: "reports.view_store",
        testId: "report-card-loss-reasons",
    },
    {
        to: "reports/seller-performance",
        label: "Performance de Vendedores",
        description: "KPIs individuais: vendas, conversão, ticket médio e tempo de atendimento.",
        icon: Users,
        feature: "relatorios_basicos",
        perm: "reports.view_store",
        testId: "report-card-seller-perf",
    },
    {
        to: "reports/products",
        label: "Produtos Mais Vendidos",
        description: "Ranking de produtos por quantidade e receita gerada.",
        icon: Package,
        feature: "relatorios_basicos",
        perm: "reports.view_store",
        testId: "report-card-products",
    },
    {
        to: "reports/pa",
        label: "PA — Produtos por Atendimento",
        description: "Média de produtos vendidos por atendimento com venda, por vendedor e empresa.",
        icon: ShoppingBag,
        feature: "relatorios_basicos",
        perm: "reports.view_store",
        testId: "report-card-pa",
    },
];

export default function ReportsPage() {
    const { tenantSlug } = useParams();
    const { hasFeature, hasPermission } = usePermissions();

    const visible = REPORT_CARDS.filter(
        (c) => hasFeature(c.feature) && hasPermission(c.perm, "reports.view_tenant", "reports.view_self")
    );

    return (
        <div data-testid="reports-page">
            <PageHeader
                eyebrow="Relatórios"
                title="Central de Relatórios"
                description="Análise detalhada de atendimentos, vendas e performance da equipe."
            />

            {visible.length === 0 ? (
                <div className="border border-dashed border-border bg-card rounded-md p-16 text-center">
                    <p className="text-sm text-muted-foreground">
                        Nenhum relatório disponível para seu nível de acesso ou features ativas.
                    </p>
                </div>
            ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                    {visible.map((card) => (
                        <Link key={card.to} to={`/${tenantSlug}/${card.to}`} data-testid={card.testId}>
                            <Card className="border border-border shadow-sm hover:shadow-md hover:border-foreground/20 transition-all duration-200 group cursor-pointer h-full">
                                <CardContent className="p-6 flex flex-col gap-4 h-full">
                                    <div className="flex items-center gap-3">
                                        <div className="w-9 h-9 rounded-sm bg-accent flex items-center justify-center group-hover:bg-foreground/5 transition-colors">
                                            <card.icon size={18} strokeWidth={1.5} className="text-foreground/70" />
                                        </div>
                                        <p className="font-semibold text-sm">{card.label}</p>
                                    </div>
                                    <p className="text-sm text-muted-foreground leading-relaxed flex-1">{card.description}</p>
                                    <p className="text-xs text-foreground/40 group-hover:text-foreground/60 transition-colors flex items-center gap-1">
                                        <Download size={11} /> Exportação CSV disponível
                                    </p>
                                </CardContent>
                            </Card>
                        </Link>
                    ))}
                </div>
            )}
        </div>
    );
}
