import React, { useEffect, useState, useCallback } from "react";
import { useParams, Link } from "react-router-dom";
import { Plus, Activity, ShoppingBag, XCircle, ArrowRight, TrendingUp } from "lucide-react";
import api from "@/lib/api";
import { PageHeader } from "@/components/Common";
import { centsToBRL } from "@/lib/money";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { fmtDateTime } from "@/lib/i18n";

const STATUS_LABEL = {
    OPEN: "Aberta", CONVERTED_TO_ATTENDANCE: "Em atendimento",
    CONVERTED_TO_SALE: "Venda realizada", NO_SALE: "Sem venda", CANCELLED: "Cancelada",
};
const STATUS_COLOR = {
    OPEN: "bg-luppa-purple/15 text-luppa-purple", CONVERTED_TO_ATTENDANCE: "bg-luppa-purple/15 text-luppa-purple",
    CONVERTED_TO_SALE: "bg-luppa-green/15 text-emerald-800", NO_SALE: "bg-luppa-error/15 text-luppa-error",
    CANCELLED: "bg-gray-100 text-gray-600",
};


export default function MyProactivityPage() {
    const { tenantSlug } = useParams();
    const [approaches, setApproaches] = useState([]);
    const [summary, setSummary] = useState(null);
    const [loading, setLoading] = useState(true);
    const [statusFilter, setStatusFilter] = useState("");

    const load = useCallback(async () => {
        setLoading(true);
        try {
            const params = new URLSearchParams();
            if (statusFilter) params.set("status", statusFilter);
            const [appsRes, sumRes] = await Promise.all([
                api.get(`/tenants/${tenantSlug}/my-proactive-approaches?${params}`),
                api.get(`/tenants/${tenantSlug}/proactivity/summary`),
            ]);
            setApproaches(appsRes.data);
            setSummary(sumRes.data);
        } catch {
            toast.error("Erro ao carregar suas abordagens");
        } finally {
            setLoading(false);
        }
    }, [tenantSlug, statusFilter]);

    useEffect(() => { load(); }, [load]);

    return (
        <div data-testid="my-proactivity-page">
            <div className="flex items-start justify-between">
                <PageHeader
                    eyebrow="Proatividade"
                    title="Minhas abordagens"
                    description="Acompanhe suas abordagens proativas e desempenho."
                />
                <Link to={`/${tenantSlug}/proactivity/new`} data-testid="new-approach-btn">
                    <Button size="sm" className="mt-1">
                        <Plus size={14} className="mr-2" /> Nova abordagem
                    </Button>
                </Link>
            </div>

            {/* KPI cards */}
            {summary && (
                <div className="metric-grid mb-6">
                    {[
                        { label: "Total", value: summary.total_approaches, testId: "my-total", color: "" },
                        { label: "Abertas", value: summary.open, testId: "my-open", color: "text-luppa-purple" },
                        { label: "Vendas", value: summary.converted_to_sale, testId: "my-sales", color: "text-luppa-green" },
                        { label: "Conversão", value: `${summary.conversion_to_sale_pct || 0}%`, testId: "my-conversion", color: "text-luppa-purple" },
                    ].map((k) => (
                        <div key={k.label} className="metric-card-wrap border border-border/60 rounded-md p-4 bg-card">
                            <p className="metric-label text-xs uppercase tracking-[0.08em] text-muted-foreground mb-1">{k.label}</p>
                            <span className={`metric-num font-semibold ${k.color}`} data-testid={k.testId}>{k.value}</span>
                        </div>
                    ))}
                </div>
            )}

            {/* Receita proativa */}
            {summary && summary.proactive_revenue_cents > 0 && (
                <div className="metric-card-wrap border border-border/60 rounded-md p-4 bg-card mb-6 flex items-center gap-3">
                    <ShoppingBag size={16} className="text-luppa-green flex-shrink-0" />
                    <div className="min-w-0">
                        <p className="metric-label text-xs uppercase tracking-[0.08em] text-muted-foreground">Receita proativa gerada</p>
                        <span className="metric-num font-semibold text-luppa-green" data-testid="my-revenue">
                            {centsToBRL(summary.proactive_revenue_cents)}
                        </span>
                    </div>
                </div>
            )}

            {/* Status filter */}
            <div className="flex gap-2 mb-4 flex-wrap">
                {["", "OPEN", "CONVERTED_TO_SALE", "CONVERTED_TO_ATTENDANCE", "NO_SALE", "CANCELLED"].map(s => (
                    <button
                        key={s}
                        onClick={() => setStatusFilter(s)}
                        data-testid={`filter-${s || "all"}`}
                        className={`text-xs px-3 py-1.5 rounded-full border transition-colors ${
                            statusFilter === s ? "bg-foreground text-background border-foreground" : "border-border text-muted-foreground hover:border-foreground/40"
                        }`}
                    >
                        {s ? STATUS_LABEL[s] : "Todas"}
                    </button>
                ))}
            </div>

            {/* List */}
            {loading ? (
                <div className="space-y-3">{[1, 2, 3].map(i => <Skeleton key={i} className="h-16 w-full" />)}</div>
            ) : approaches.length === 0 ? (
                <Card className="border border-border shadow-sm">
                    <CardContent className="p-10 text-center">
                        <Activity size={28} strokeWidth={1} className="mx-auto mb-3 text-muted-foreground" />
                        <p className="text-sm text-muted-foreground">
                            {statusFilter ? `Sem abordagens com status "${STATUS_LABEL[statusFilter]}".` : "Você ainda não registrou nenhuma abordagem proativa."}
                        </p>
                        <Link to={`/${tenantSlug}/proactivity/new`}>
                            <Button size="sm" className="mt-4" data-testid="empty-new-btn">
                                <Plus size={14} className="mr-2" /> Registrar abordagem
                            </Button>
                        </Link>
                    </CardContent>
                </Card>
            ) : (
                <div className="space-y-2" data-testid="my-approaches-list">
                    {approaches.map(a => (
                        <Link key={a.id} to={`/${tenantSlug}/proactivity/${a.id}`} data-testid={`my-approach-${a.id}`}>
                            <Card className="border border-border shadow-sm hover:shadow-md transition-all cursor-pointer">
                                <CardContent className="p-4 flex items-center justify-between">
                                    <div className="min-w-0">
                                        <p className="text-sm font-medium truncate">{a.customer_name || "Cliente não identificado"}</p>
                                        <p className="text-xs text-muted-foreground mt-0.5">{fmtDateTime(a.started_at)}</p>
                                    </div>
                                    <div className="flex items-center gap-2 flex-shrink-0">
                                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${STATUS_COLOR[a.status] || ""}`}>
                                            {STATUS_LABEL[a.status] || a.status}
                                        </span>
                                        <ArrowRight size={14} className="text-muted-foreground" />
                                    </div>
                                </CardContent>
                            </Card>
                        </Link>
                    ))}
                </div>
            )}
        </div>
    );
}
