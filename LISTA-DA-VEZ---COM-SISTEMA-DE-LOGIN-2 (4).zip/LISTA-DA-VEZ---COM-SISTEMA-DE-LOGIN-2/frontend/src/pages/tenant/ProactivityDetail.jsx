import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
    ArrowLeft, User, Store, Calendar, Tag, MessageSquare,
    ShoppingBag, ClipboardList, XCircle, CheckCircle2, AlertCircle,
} from "lucide-react";
import { useTenant } from "@/context/TenantContext";
import api from "@/lib/api";
import { PageHeader } from "@/components/Common";
import { centsToBRL, brlToCents, centsToInput } from "@/lib/money";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import { fmtDateTime } from "@/lib/i18n";

const STATUS_LABEL = {
    OPEN: "Aberta",
    CONVERTED_TO_ATTENDANCE: "Em atendimento",
    CONVERTED_TO_SALE: "Venda realizada",
    NO_SALE: "Sem venda",
    CANCELLED: "Cancelada",
};

const STATUS_COLOR = {
    OPEN: "bg-luppa-purple/15 text-luppa-purple",
    CONVERTED_TO_ATTENDANCE: "bg-luppa-purple/15 text-luppa-purple",
    CONVERTED_TO_SALE: "bg-luppa-green/15 text-emerald-800",
    NO_SALE: "bg-luppa-error/15 text-luppa-error",
    CANCELLED: "bg-gray-100 text-gray-600",
};

const SOURCE_LABEL = {
    STORE_FLOOR: "Piso da loja", WINDOW: "Vitrine",
    RETURNING_CUSTOMER: "Cliente retornante", REFERRAL: "Indicação",
    PHONE: "Telefone", WHATSAPP: "WhatsApp", INSTAGRAM: "Instagram", OTHER: "Outro",
};

const TYPE_LABEL = {
    ACTIVE_APPROACH: "Abordagem ativa",
    CUSTOMER_REENGAGEMENT: "Reengajamento",
    PRODUCT_INTEREST: "Interesse em produto",
    POST_VISIT_FOLLOWUP: "Seguimento pós-visita",
    OTHER: "Outro",
};


export default function ProactivityDetail() {
    const { tenantSlug, approachId } = useParams();
    const { context } = useTenant();
    const nav = useNavigate();
    const role = context?.user_role;

    const [approach, setApproach] = useState(null);
    const [loading, setLoading] = useState(true);
    const [actionLoading, setActionLoading] = useState(false);

    // Modal state
    const [showNoSaleModal, setShowNoSaleModal] = useState(false);
    const [showSaleModal, setShowSaleModal] = useState(false);
    const [showCancelModal, setShowCancelModal] = useState(false);
    const [lossReasons, setLossReasons] = useState([]);
    const [noSaleForm, setNoSaleForm] = useState({ loss_reason_id: "", notes: "" });
    const [saleForm, setSaleForm] = useState({ gross_amount_brl: "", discount_amount_brl: "0,00", payment_method: "CREDIT_CARD", notes: "" });
    const [cancelReason, setCancelReason] = useState("");

    const isOwn = approach && context?.user?.id;

    const canCancel = approach?.status === "OPEN" && (
        ["TENANT_ADMIN", "STORE_MANAGER", "SUPERVISOR"].includes(role) ||
        (role === "SELLER")
    );
    const canConvertToAtt = approach?.status === "OPEN" && ["TENANT_ADMIN", "STORE_MANAGER", "SUPERVISOR", "SELLER"].includes(role);
    const canConvertToSale = approach?.status === "OPEN" && ["TENANT_ADMIN", "STORE_MANAGER", "SUPERVISOR", "SELLER"].includes(role);
    const canCloseNoSale = approach?.status === "OPEN" && ["TENANT_ADMIN", "STORE_MANAGER", "SUPERVISOR", "SELLER"].includes(role);

    const load = async () => {
        setLoading(true);
        try {
            const res = await api.get(`/tenants/${tenantSlug}/proactive-approaches/${approachId}`);
            setApproach(res.data);
        } catch (e) {
            toast.error("Abordagem não encontrada");
            nav(-1);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => { load(); }, [approachId, tenantSlug]);

    useEffect(() => {
        if (showNoSaleModal) {
            api.get(`/tenants/${tenantSlug}/loss-reasons`).then(r => setLossReasons(r.data || [])).catch(() => {});
        }
    }, [showNoSaleModal, tenantSlug]);

    const doConvertToAttendance = async () => {
        setActionLoading(true);
        try {
            await api.post(`/tenants/${tenantSlug}/proactive-approaches/${approachId}/convert-to-attendance`, {
                customer_name: approach.customer_name,
            });
            toast.success("Convertida em atendimento!");
            await load();
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Erro ao converter");
        } finally {
            setActionLoading(false);
        }
    };

    const doCloseNoSale = async () => {
        setActionLoading(true);
        try {
            await api.post(`/tenants/${tenantSlug}/proactive-approaches/${approachId}/close-no-sale`, {
                loss_reason_id: noSaleForm.loss_reason_id || undefined,
                notes: noSaleForm.notes || undefined,
            });
            toast.success("Encerrada sem venda");
            setShowNoSaleModal(false);
            await load();
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Erro ao encerrar");
        } finally {
            setActionLoading(false);
        }
    };

    const doConvertToSale = async () => {
        const gross = brlToCents(saleForm.gross_amount_brl) ?? 0;
        const discount = brlToCents(saleForm.discount_amount_brl) ?? 0;
        if (gross <= 0) {
            toast.error("Informe o valor da venda.");
            return;
        }
        setActionLoading(true);
        try {
            await api.post(`/tenants/${tenantSlug}/proactive-approaches/${approachId}/convert-to-sale`, {
                gross_amount_cents: gross,
                discount_amount_cents: discount,
                net_amount_cents: gross - discount,
                payment_method: saleForm.payment_method,
                notes: saleForm.notes || undefined,
                items: [],
            });
            toast.success("Venda registrada com sucesso!");
            setShowSaleModal(false);
            await load();
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Erro ao registrar venda");
        } finally {
            setActionLoading(false);
        }
    };

    const doCancel = async () => {
        setActionLoading(true);
        try {
            await api.post(`/tenants/${tenantSlug}/proactive-approaches/${approachId}/cancel`, {
                reason: cancelReason || undefined,
            });
            toast.success("Abordagem cancelada");
            setShowCancelModal(false);
            await load();
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Erro ao cancelar");
        } finally {
            setActionLoading(false);
        }
    };

    if (loading) return <div className="flex items-center justify-center h-40"><p className="text-sm text-muted-foreground">Carregando...</p></div>;
    if (!approach) return null;

    return (
        <div data-testid="proactivity-detail-page">
            <div className="flex items-start justify-between mb-6">
                <div className="flex items-center gap-3">
                    <Button variant="ghost" size="icon" onClick={() => nav(-1)} data-testid="back-btn">
                        <ArrowLeft size={18} />
                    </Button>
                    <div>
                        <p className="text-xs uppercase tracking-[0.15em] text-muted-foreground">Abordagem Proativa</p>
                        <h1 className="font-sans text-2xl font-semibold">
                            {approach.customer_name || "Cliente não identificado"}
                        </h1>
                    </div>
                </div>
                <span className={`text-xs px-3 py-1 rounded-full font-medium mt-1 ${STATUS_COLOR[approach.status] || "bg-gray-100 text-gray-600"}`}>
                    {STATUS_LABEL[approach.status] || approach.status}
                </span>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Main Info */}
                <div className="lg:col-span-2 space-y-4">
                    <Card className="border border-border shadow-sm">
                        <CardContent className="p-6">
                            <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground mb-4">Detalhes</p>
                            <dl className="grid grid-cols-2 gap-3 text-sm">
                                <dt className="text-muted-foreground flex items-center gap-1.5"><User size={13} /> Vendedor</dt>
                                <dd className="font-medium">{approach.seller_name || approach.seller_id}</dd>
                                <dt className="text-muted-foreground flex items-center gap-1.5"><Store size={13} /> Unidade</dt>
                                <dd className="font-medium">{approach.store_name || approach.store_id}</dd>
                                <dt className="text-muted-foreground flex items-center gap-1.5"><Tag size={13} /> Fonte</dt>
                                <dd>{SOURCE_LABEL[approach.source] || approach.source}</dd>
                                <dt className="text-muted-foreground flex items-center gap-1.5"><Tag size={13} /> Tipo</dt>
                                <dd>{TYPE_LABEL[approach.approach_type] || approach.approach_type}</dd>
                                <dt className="text-muted-foreground flex items-center gap-1.5"><Calendar size={13} /> Iniciada em</dt>
                                <dd>{fmtDateTime(approach.started_at)}</dd>
                                {approach.converted_at && (
                                    <>
                                        <dt className="text-muted-foreground flex items-center gap-1.5"><Calendar size={13} /> Convertida em</dt>
                                        <dd>{fmtDateTime(approach.converted_at)}</dd>
                                    </>
                                )}
                                {approach.closed_at && (
                                    <>
                                        <dt className="text-muted-foreground flex items-center gap-1.5"><Calendar size={13} /> Encerrada em</dt>
                                        <dd>{fmtDateTime(approach.closed_at)}</dd>
                                    </>
                                )}
                                {approach.customer_phone && (
                                    <>
                                        <dt className="text-muted-foreground">Telefone</dt>
                                        <dd>{approach.customer_phone}</dd>
                                    </>
                                )}
                                {approach.loss_reason && (
                                    <>
                                        <dt className="text-muted-foreground">Motivo de perda</dt>
                                        <dd className="text-luppa-error font-medium">{approach.loss_reason?.name}</dd>
                                    </>
                                )}
                            </dl>
                            {approach.notes && (
                                <div className="mt-4 pt-4 border-t border-border">
                                    <div className="flex items-center gap-1.5 mb-1">
                                        <MessageSquare size={13} className="text-muted-foreground" />
                                        <p className="text-xs uppercase tracking-[0.08em] text-muted-foreground">Observações</p>
                                    </div>
                                    <p className="text-sm">{approach.notes}</p>
                                </div>
                            )}
                        </CardContent>
                    </Card>

                    {/* Linked records */}
                    {approach.linked_attendance_id && (
                        <Card className="border border-border shadow-sm">
                            <CardContent className="p-5">
                                <div className="flex items-center gap-2">
                                    <ClipboardList size={14} className="text-luppa-purple" />
                                    <p className="text-sm font-medium">Atendimento vinculado</p>
                                </div>
                                <p className="text-xs text-muted-foreground mt-1 font-mono">{approach.linked_attendance_id}</p>
                            </CardContent>
                        </Card>
                    )}
                    {approach.linked_sale_id && (
                        <Card className="border border-border shadow-sm">
                            <CardContent className="p-5">
                                <div className="flex items-center gap-2">
                                    <ShoppingBag size={14} className="text-luppa-green" />
                                    <p className="text-sm font-medium">Venda vinculada</p>
                                </div>
                                <p className="text-xs text-muted-foreground mt-1 font-mono">{approach.linked_sale_id}</p>
                            </CardContent>
                        </Card>
                    )}
                </div>

                {/* Actions */}
                {approach.status === "OPEN" && (
                    <div className="space-y-3">
                        <Card className="border border-border shadow-sm">
                            <CardContent className="p-5">
                                <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground mb-4">Ações disponíveis</p>
                                <div className="space-y-2">
                                    {canConvertToAtt && (
                                        <Button className="w-full justify-start" variant="outline" size="sm" onClick={doConvertToAttendance} disabled={actionLoading} data-testid="action-convert-att">
                                            <ClipboardList size={14} className="mr-2 text-luppa-purple" /> Converter em atendimento
                                        </Button>
                                    )}
                                    {canConvertToSale && (
                                        <Button className="w-full justify-start" variant="outline" size="sm" onClick={() => setShowSaleModal(true)} disabled={actionLoading} data-testid="action-convert-sale">
                                            <ShoppingBag size={14} className="mr-2 text-luppa-green" /> Registrar venda
                                        </Button>
                                    )}
                                    {canCloseNoSale && (
                                        <Button className="w-full justify-start" variant="outline" size="sm" onClick={() => setShowNoSaleModal(true)} disabled={actionLoading} data-testid="action-close-no-sale">
                                            <XCircle size={14} className="mr-2 text-luppa-error" /> Encerrar sem venda
                                        </Button>
                                    )}
                                    {canCancel && (
                                        <Button className="w-full justify-start" variant="outline" size="sm" onClick={() => setShowCancelModal(true)} disabled={actionLoading} data-testid="action-cancel">
                                            <AlertCircle size={14} className="mr-2 text-gray-500" /> Cancelar abordagem
                                        </Button>
                                    )}
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                )}
                {approach.status !== "OPEN" && (
                    <Card className="border border-border shadow-sm h-fit">
                        <CardContent className="p-5 flex items-center gap-3">
                            <CheckCircle2 size={18} className="text-muted-foreground flex-shrink-0" />
                            <div>
                                <p className="text-sm font-medium">Abordagem encerrada</p>
                                <p className="text-xs text-muted-foreground mt-0.5">Status: {STATUS_LABEL[approach.status]}</p>
                            </div>
                        </CardContent>
                    </Card>
                )}
            </div>

            {/* No Sale Modal */}
            {showNoSaleModal && (
                <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4" data-testid="no-sale-modal">
                    <Card className="w-full max-w-md border border-border shadow-xl">
                        <CardContent className="p-6">
                            <h3 className="font-semibold mb-4">Encerrar sem venda</h3>
                            <div className="space-y-3">
                                <div>
                                    <label className="text-sm font-medium mb-1 block">Motivo de perda</label>
                                    <select
                                        className="w-full border border-border rounded-sm px-3 py-2 text-sm bg-background"
                                        value={noSaleForm.loss_reason_id}
                                        onChange={e => setNoSaleForm(f => ({ ...f, loss_reason_id: e.target.value }))}
                                        data-testid="no-sale-loss-reason"
                                    >
                                        <option value="">Sem motivo específico</option>
                                        {lossReasons.map(lr => <option key={lr.id} value={lr.id}>{lr.name}</option>)}
                                    </select>
                                </div>
                                <div>
                                    <label className="text-sm font-medium mb-1 block">Observações</label>
                                    <textarea
                                        className="w-full border border-border rounded-sm px-3 py-2 text-sm resize-none"
                                        rows={2}
                                        value={noSaleForm.notes}
                                        onChange={e => setNoSaleForm(f => ({ ...f, notes: e.target.value }))}
                                        data-testid="no-sale-notes"
                                    />
                                </div>
                            </div>
                            <div className="flex gap-2 mt-4">
                                <Button size="sm" onClick={doCloseNoSale} disabled={actionLoading} data-testid="no-sale-confirm-btn">
                                    {actionLoading ? "Aguarde..." : "Confirmar"}
                                </Button>
                                <Button size="sm" variant="outline" onClick={() => setShowNoSaleModal(false)} data-testid="no-sale-cancel-btn">
                                    Cancelar
                                </Button>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            )}

            {/* Sale Modal */}
            {showSaleModal && (
                <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4" data-testid="sale-modal">
                    <Card className="w-full max-w-md border border-border shadow-xl">
                        <CardContent className="p-6">
                            <h3 className="font-semibold mb-4">Registrar venda proativa</h3>
                            <div className="space-y-3">
                                <div>
                                    <label className="text-sm font-medium mb-1 block">Valor bruto (R$)</label>
                                    <input type="text" inputMode="decimal" className="w-full border border-border rounded-sm px-3 py-2 text-sm"
                                        placeholder="Ex: 199,90"
                                        value={saleForm.gross_amount_brl}
                                        onChange={e => setSaleForm(f => ({ ...f, gross_amount_brl: e.target.value }))}
                                        data-testid="sale-gross-amount" />
                                </div>
                                <div>
                                    <label className="text-sm font-medium mb-1 block">Desconto (R$)</label>
                                    <input type="text" inputMode="decimal" className="w-full border border-border rounded-sm px-3 py-2 text-sm"
                                        placeholder="0,00"
                                        value={saleForm.discount_amount_brl}
                                        onChange={e => setSaleForm(f => ({ ...f, discount_amount_brl: e.target.value }))}
                                        data-testid="sale-discount-amount" />
                                </div>
                                <div>
                                    <label className="text-sm font-medium mb-1 block">Forma de pagamento</label>
                                    <select className="w-full border border-border rounded-sm px-3 py-2 text-sm bg-background"
                                        value={saleForm.payment_method}
                                        onChange={e => setSaleForm(f => ({ ...f, payment_method: e.target.value }))}
                                        data-testid="sale-payment-method">
                                        <option value="CREDIT_CARD">Cartão de crédito</option>
                                        <option value="DEBIT_CARD">Cartão de débito</option>
                                        <option value="CASH">Dinheiro</option>
                                        <option value="PIX">Pix</option>
                                        <option value="OTHER">Outro</option>
                                    </select>
                                </div>
                                <div>
                                    <label className="text-sm font-medium mb-1 block">Observações</label>
                                    <textarea className="w-full border border-border rounded-sm px-3 py-2 text-sm resize-none" rows={2}
                                        value={saleForm.notes}
                                        onChange={e => setSaleForm(f => ({ ...f, notes: e.target.value }))}
                                        data-testid="sale-notes" />
                                </div>
                            </div>
                            <div className="flex gap-2 mt-4">
                                <Button size="sm" onClick={doConvertToSale} disabled={actionLoading} data-testid="sale-confirm-btn">
                                    {actionLoading ? "Aguarde..." : "Confirmar venda"}
                                </Button>
                                <Button size="sm" variant="outline" onClick={() => setShowSaleModal(false)} data-testid="sale-cancel-btn">Cancelar</Button>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            )}

            {/* Cancel Modal */}
            {showCancelModal && (
                <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4" data-testid="cancel-modal">
                    <Card className="w-full max-w-sm border border-border shadow-xl">
                        <CardContent className="p-6">
                            <h3 className="font-semibold mb-3">Cancelar abordagem</h3>
                            <textarea className="w-full border border-border rounded-sm px-3 py-2 text-sm resize-none mb-4" rows={2}
                                placeholder="Motivo do cancelamento (opcional)"
                                value={cancelReason}
                                onChange={e => setCancelReason(e.target.value)}
                                data-testid="cancel-reason" />
                            <div className="flex gap-2">
                                <Button size="sm" variant="destructive" onClick={doCancel} disabled={actionLoading} data-testid="cancel-confirm-btn">
                                    {actionLoading ? "Aguarde..." : "Confirmar cancelamento"}
                                </Button>
                                <Button size="sm" variant="outline" onClick={() => setShowCancelModal(false)} data-testid="cancel-dismiss-btn">Voltar</Button>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            )}
        </div>
    );
}
