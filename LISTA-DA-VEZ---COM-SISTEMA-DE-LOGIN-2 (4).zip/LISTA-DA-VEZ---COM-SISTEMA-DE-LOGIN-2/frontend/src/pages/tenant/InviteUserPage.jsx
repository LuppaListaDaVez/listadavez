/**
 * InviteUserPage — Convidar funcionário via e-mail.
 *
 * Rota: /:tenantSlug/users/invite
 * Acesso: TENANT_ADMIN, REGIONAL_MANAGER
 *
 * Regras de negócio:
 *  - TENANT_ADMIN pode convidar todos os cargos.
 *  - REGIONAL_MANAGER não pode convidar TENANT_ADMIN.
 *  - TENANT_ADMIN → sem filial obrigatória.
 *  - REGIONAL_MANAGER → toggle "Acesso a todas as filiais" (all_stores: true).
 *  - SELLER → apenas 1 filial (seleção única).
 *  - Outros → multi-select de filiais (obrigatório).
 */
import React, { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import api, { extractError } from "@/lib/api";
import { useTenant } from "@/context/TenantContext";
import { usePermissions } from "@/hooks/usePermissions";
import { PageHeader } from "@/components/Common";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
    Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { Mail, CheckCircle } from "lucide-react";

const ALL_ROLES = [
    { value: "TENANT_ADMIN",      label: "Admin da Empresa" },
    { value: "REGIONAL_MANAGER",  label: "Gerente Regional" },
    { value: "STORE_MANAGER",     label: "Gerente de Loja" },
    { value: "SUPERVISOR",        label: "Supervisor" },
    { value: "SELLER",            label: "Vendedor" },
];

const NEEDS_STORES = new Set(["REGIONAL_MANAGER", "STORE_MANAGER", "SUPERVISOR", "SELLER"]);

export default function InviteUserPage() {
    const { tenantSlug } = useParams();
    const { context } = useTenant();
    const { role: currentRole } = usePermissions();
    const nav = useNavigate();

    const availableRoles = currentRole === "TENANT_ADMIN"
        ? ALL_ROLES
        : ALL_ROLES.filter((r) => r.value !== "TENANT_ADMIN");

    const stores = context?.stores || [];

    const [form, setForm] = useState({
        email: "",
        role: "SELLER",
        store_ids: [],
        all_stores: false,
    });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [success, setSuccess] = useState(null);

    const setF = (k, v) => setForm((p) => ({ ...p, [k]: v }));

    const isTenantAdmin = form.role === "TENANT_ADMIN";
    const isRegionalManager = form.role === "REGIONAL_MANAGER";
    const isSeller = form.role === "SELLER";
    const needsStores = NEEDS_STORES.has(form.role);

    const toggleStore = (id) => {
        if (isSeller) {
            // Seller: seleção única
            setF("store_ids", form.store_ids[0] === id ? [] : [id]);
            return;
        }
        setF("store_ids",
            form.store_ids.includes(id)
                ? form.store_ids.filter((s) => s !== id)
                : [...form.store_ids, id]
        );
    };

    const canSubmit = () => {
        if (!form.email.trim()) return false;
        if (isTenantAdmin) return true;
        if (isRegionalManager) return form.all_stores || form.store_ids.length > 0;
        return form.store_ids.length > 0;
    };

    const submit = async (e) => {
        e.preventDefault();
        if (!canSubmit()) return;
        setError(null);
        setLoading(true);
        try {
            const payload = {
                email: form.email.trim().toLowerCase(),
                role: form.role,
                store_ids: isTenantAdmin ? [] : form.store_ids,
                all_stores: isRegionalManager ? form.all_stores : false,
            };
            const { data } = await api.post(`/tenants/${tenantSlug}/users/invite`, payload);
            setSuccess(data.invite_sent_to || form.email.trim());
        } catch (err) {
            setError(extractError(err, "Erro ao enviar convite."));
        } finally {
            setLoading(false);
        }
    };

    if (success) {
        return (
            <div>
                <PageHeader eyebrow="Equipe" title="Convite enviado" />
                <Card className="max-w-lg border border-border shadow-sm">
                    <CardContent className="p-8 flex flex-col items-center gap-4 text-center">
                        <CheckCircle size={40} className="text-luppa-green" strokeWidth={1.5} />
                        <div>
                            <p className="font-semibold">Convite enviado para</p>
                            <p className="text-muted-foreground text-sm mt-1 font-mono">{success}</p>
                        </div>
                        <p className="text-sm text-muted-foreground max-w-xs">
                            O funcionário receberá um e-mail com um link para ativar a conta e definir sua senha.
                            O link expira em 72 horas.
                        </p>
                        <div className="flex gap-2 pt-2">
                            <Button variant="outline" onClick={() => nav(`/${tenantSlug}/users`)}>
                                Ver usuários
                            </Button>
                            <Button
                                data-testid="invite-another-btn"
                                onClick={() => {
                                    setSuccess(null);
                                    setForm({ email: "", role: "SELLER", store_ids: [], all_stores: false });
                                }}
                            >
                                Convidar outro
                            </Button>
                        </div>
                    </CardContent>
                </Card>
            </div>
        );
    }

    return (
        <div>
            <PageHeader
                eyebrow="Equipe"
                title="Convidar funcionário"
                description="O funcionário receberá um e-mail para criar sua senha e ativar a conta."
            />
            <Card className="max-w-2xl border border-border shadow-sm">
                <CardContent className="p-6">
                    <form onSubmit={submit} className="space-y-5">
                        {error && (
                            <Alert variant="destructive">
                                <AlertDescription data-testid="invite-error">{error}</AlertDescription>
                            </Alert>
                        )}

                        {/* E-mail */}
                        <div className="space-y-2">
                            <Label htmlFor="email">
                                E-mail do funcionário <span className="text-luppa-error">*</span>
                            </Label>
                            <div className="relative">
                                <Mail size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                                <Input
                                    id="email"
                                    type="email"
                                    placeholder="funcionario@empresa.com.br"
                                    value={form.email}
                                    onChange={(e) => setF("email", e.target.value)}
                                    required
                                    className="pl-9"
                                    data-testid="invite-email-input"
                                />
                            </div>
                        </div>

                        {/* Cargo */}
                        <div className="space-y-2">
                            <Label>Cargo <span className="text-luppa-error">*</span></Label>
                            <Select
                                value={form.role}
                                onValueChange={(v) => {
                                    setF("role", v);
                                    setF("store_ids", []);
                                    setF("all_stores", false);
                                }}
                            >
                                <SelectTrigger data-testid="invite-role-select">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    {availableRoles.map((r) => (
                                        <SelectItem key={r.value} value={r.value}>
                                            {r.label}
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>

                        {/* Filiais — condicional por cargo */}
                        {!isTenantAdmin && stores.length > 0 && (
                            <div className="space-y-3 pt-1">
                                <Label>
                                    Filial{isSeller ? "" : "is"}
                                    {needsStores && !form.all_stores && (
                                        <span className="text-luppa-error ml-1">*</span>
                                    )}
                                    {isSeller && (
                                        <span className="text-xs text-muted-foreground ml-2">
                                            (selecione 1 filial)
                                        </span>
                                    )}
                                </Label>

                                {/* REGIONAL_MANAGER: toggle "Acesso a todas as filiais" */}
                                {isRegionalManager && (
                                    <div className="flex items-center gap-3 rounded-md border border-border px-3 py-2.5 bg-muted/30">
                                        <Switch
                                            id="all-stores-toggle"
                                            checked={form.all_stores}
                                            onCheckedChange={(v) => {
                                                setF("all_stores", v);
                                                if (v) setF("store_ids", []);
                                            }}
                                            data-testid="all-stores-toggle"
                                        />
                                        <label htmlFor="all-stores-toggle" className="text-sm cursor-pointer select-none">
                                            Acesso a <strong>todas as filiais</strong> do tenant
                                        </label>
                                    </div>
                                )}

                                {/* Lista de filiais (oculta se all_stores ativo) */}
                                {!form.all_stores && (
                                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                                        {stores.map((s) => (
                                            <label
                                                key={s.id}
                                                className={`flex items-center gap-2 text-sm cursor-pointer rounded-md border px-3 py-2 transition-colors ${
                                                    form.store_ids.includes(s.id)
                                                        ? "border-foreground bg-foreground/5 font-medium"
                                                        : "border-border hover:border-foreground/30"
                                                }`}
                                            >
                                                <Checkbox
                                                    checked={form.store_ids.includes(s.id)}
                                                    onCheckedChange={() => toggleStore(s.id)}
                                                    data-testid={`invite-store-${s.code || s.id}`}
                                                />
                                                <span className="truncate">{s.name}</span>
                                            </label>
                                        ))}
                                    </div>
                                )}

                                {/* Validação Seller */}
                                {isSeller && form.store_ids.length === 0 && (
                                    <p className="text-xs text-amber-600">
                                        Selecione a filial onde o vendedor vai atuar.
                                    </p>
                                )}
                                {isSeller && form.store_ids.length > 1 && (
                                    <p className="text-xs text-luppa-error">
                                        Vendedor deve ser vinculado a apenas 1 filial.
                                    </p>
                                )}
                            </div>
                        )}

                        <div className="flex justify-end gap-2 pt-2">
                            <Button
                                type="button"
                                variant="outline"
                                onClick={() => nav(`/${tenantSlug}/users`)}
                            >
                                Cancelar
                            </Button>
                            <Button
                                type="submit"
                                disabled={loading || !canSubmit()}
                                data-testid="invite-submit-btn"
                            >
                                {loading ? "Enviando convite…" : "Enviar convite"}
                            </Button>
                        </div>
                    </form>
                </CardContent>
            </Card>
        </div>
    );
}
