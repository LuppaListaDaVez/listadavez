import React, { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import api, { extractError } from "@/lib/api";
import { PageHeader } from "@/components/Common";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function StoreNew() {
    const { tenantSlug } = useParams();
    const nav = useNavigate();
    const [form, setForm] = useState({
        name: "",
        code: "",
        city: "",
        state: "",
        country: "Brasil",
        timezone: "America/Sao_Paulo",
        address: "",
        phone: "",
    });
    const [err, setErr] = useState(null);
    const [loading, setLoading] = useState(false);

    const setF = (k, v) => setForm((p) => ({ ...p, [k]: v }));

    const submit = async (e) => {
        e.preventDefault();
        setErr(null);
        setLoading(true);
        try {
            await api.post(`/tenants/${tenantSlug}/stores`, form);
            nav(`/${tenantSlug}/stores`);
        } catch (e) {
            setErr(extractError(e, "Erro ao criar unidade"));
            setLoading(false);
        }
    };

    return (
        <div>
            <PageHeader eyebrow="Unidades" title="Nova unidade" description="Cadastre uma nova filial física." />
            <Card className="border border-border shadow-sm max-w-3xl">
                <CardContent className="p-6">
                    <form onSubmit={submit} className="grid grid-cols-1 md:grid-cols-2 gap-5">
                        {err && (
                            <div className="md:col-span-2">
                                <Alert variant="destructive">
                                    <AlertDescription data-testid="new-store-error">{err}</AlertDescription>
                                </Alert>
                            </div>
                        )}
                        <Field label="Nome">
                            <Input value={form.name} onChange={(e) => setF("name", e.target.value)} required data-testid="store-name-input" />
                        </Field>
                        <Field label="Código">
                            <Input value={form.code} onChange={(e) => setF("code", e.target.value.toUpperCase())} required data-testid="store-code-input" />
                        </Field>
                        <Field label="Cidade">
                            <Input value={form.city} onChange={(e) => setF("city", e.target.value)} data-testid="store-city-input" />
                        </Field>
                        <Field label="UF">
                            <Input value={form.state} onChange={(e) => setF("state", e.target.value.toUpperCase())} maxLength={2} data-testid="store-state-input" />
                        </Field>
                        <Field label="País">
                            <Input value={form.country} onChange={(e) => setF("country", e.target.value)} data-testid="store-country-input" />
                        </Field>
                        <Field label="Fuso horário">
                            <Input value={form.timezone} onChange={(e) => setF("timezone", e.target.value)} data-testid="store-tz-input" />
                        </Field>
                        <Field label="Endereço">
                            <Input value={form.address} onChange={(e) => setF("address", e.target.value)} data-testid="store-address-input" />
                        </Field>
                        <Field label="Telefone">
                            <Input value={form.phone} onChange={(e) => setF("phone", e.target.value)} data-testid="store-phone-input" />
                        </Field>
                        <div className="md:col-span-2 flex justify-end gap-2 pt-4">
                            <Button type="button" variant="outline" onClick={() => nav(`/${tenantSlug}/stores`)}>Cancelar</Button>
                            <Button type="submit" disabled={loading} data-testid="create-store-submit">
                                {loading ? "Criando…" : "Criar unidade"}
                            </Button>
                        </div>
                    </form>
                </CardContent>
            </Card>
        </div>
    );
}

function Field({ label, children }) {
    return (
        <div className="space-y-2">
            <Label>{label}</Label>
            {children}
        </div>
    );
}
