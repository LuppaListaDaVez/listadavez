import React, { useCallback, useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import api, { extractError } from "@/lib/api";
import { centsToBRL } from "@/lib/money";
import { PageHeader } from "@/components/Common";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Download, Star, ArrowLeft, RefreshCw } from "lucide-react";
import { toast } from "sonner";

const ALL = "__all__";
const RULES = { TO_TOP: "Topo", PREVIOUS_POSITION: "Posição anterior", TO_END: "Final", CONSUME_TURN: "Perder a vez" };
const RESULTS = { SALE: "Sucesso", NO_SALE: "Não sucesso", FOLLOW_UP: "Cliente retornará", INVALID: "Inválido" };
const today = () => new Date().toISOString().slice(0, 10);
const fmtSec = (s) => !s ? "0m" : `${Math.floor(s / 60)}m`;

function Kpi({ label, value, testId }) {
    return <div className="metric-card-wrap border border-border rounded-md p-4 bg-card" data-testid={testId}><p className="metric-label text-xs uppercase tracking-[0.1em] text-muted-foreground">{label}</p><span className="metric-num font-semibold">{value}</span></div>;
}

export default function PreferenceAttendancesReport() {
    const { tenantSlug } = useParams();
    const [filters, setFilters] = useState({ date_start: today(), date_end: today(), result: "", return_rule: "" });
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(false);
    const params = useMemo(() => { const p = new URLSearchParams(); Object.entries(filters).forEach(([k,v]) => { if (v) p.set(k, v); }); return p; }, [filters]);
    const load = useCallback(async () => { setLoading(true); try { const { data: r } = await api.get(`/tenants/${tenantSlug}/reports/preference-attendances?${params}`); setData(r); } catch(e) { toast.error(extractError(e, "Erro ao carregar relatório")); } finally { setLoading(false); } }, [tenantSlug, params]);
    useEffect(() => { load(); }, [load]);
    const set = (k, v) => setFilters({ ...filters, [k]: v === ALL ? "" : v });
    const exportFile = async (type) => { try { const res = await api.get(`/tenants/${tenantSlug}/reports/preference-attendances/export.${type}?${params}`, { responseType: "blob" }); const url = URL.createObjectURL(new Blob([res.data])); const a = document.createElement("a"); a.href = url; a.download = `atendimentos_por_preferencia.${type}`; a.click(); URL.revokeObjectURL(url); } catch(e) { toast.error(extractError(e, "Erro ao exportar")); } };
    const totals = data?.totals || {};
    const ruleData = Object.entries(data?.by_rule || {}).map(([rule, count]) => ({ rule: RULES[rule] || rule, count }));
    const sellerData = data?.top_sellers || [];
    return (
        <div data-testid="preference-report-page">
            <div className="flex items-center gap-3 mb-6"><Link to={`/${tenantSlug}/reports`} data-testid="preference-report-back"><ArrowLeft size={16}/></Link><PageHeader eyebrow="Relatórios" title="Atendimentos por Preferência" description="Análise dos atendimentos iniciados quando o cliente procura um vendedor específico." /></div>
            <Card className="border border-border shadow-sm mb-5"><CardContent className="p-4 grid grid-cols-2 md:grid-cols-6 gap-3 items-end">
                <div className="space-y-1"><Label>De</Label><Input type="date" value={filters.date_start} onChange={(e)=>set("date_start", e.target.value)} data-testid="pref-date-start"/></div>
                <div className="space-y-1"><Label>Até</Label><Input type="date" value={filters.date_end} onChange={(e)=>set("date_end", e.target.value)} data-testid="pref-date-end"/></div>
                <div className="space-y-1"><Label>Resultado</Label><Select value={filters.result || ALL} onValueChange={(v)=>set("result", v)}><SelectTrigger data-testid="pref-result"><SelectValue /></SelectTrigger><SelectContent><SelectItem value={ALL}>Todos</SelectItem>{Object.entries(RESULTS).map(([k,v])=><SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent></Select></div>
                <div className="space-y-1"><Label>Regra</Label><Select value={filters.return_rule || ALL} onValueChange={(v)=>set("return_rule", v)}><SelectTrigger data-testid="pref-rule"><SelectValue /></SelectTrigger><SelectContent><SelectItem value={ALL}>Todas</SelectItem>{Object.entries(RULES).map(([k,v])=><SelectItem key={k} value={k}>{v}</SelectItem>)}</SelectContent></Select></div>
                <Button onClick={load} disabled={loading} data-testid="pref-refresh"><RefreshCw size={14}/> Atualizar</Button>
                <div className="flex gap-2"><Button variant="outline" onClick={()=>exportFile("csv")} data-testid="pref-export-csv"><Download size={14}/> CSV</Button><Button variant="outline" onClick={()=>exportFile("xlsx")} data-testid="pref-export-xlsx"><Download size={14}/> XLSX</Button></div>
            </CardContent></Card>
            <div className="metric-grid mb-6"><Kpi label="Preferências" value={totals.preference_attendances || 0} testId="pref-kpi-total"/><Kpi label="Finalizados" value={totals.finished || 0} testId="pref-kpi-finished"/><Kpi label="Com venda" value={totals.with_sale || 0} testId="pref-kpi-sale"/><Kpi label="Conversão" value={`${Number(totals.conversion_rate || 0).toFixed(1)}%`} testId="pref-kpi-conversion"/>{data?.can_view_financial && <Kpi label="Receita" value={centsToBRL(totals.revenue || 0)} testId="pref-kpi-revenue"/>}<Kpi label="Tempo médio" value={fmtSec(totals.average_duration_seconds)} testId="pref-kpi-duration"/></div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 mb-6"><Card className="border border-border shadow-sm"><CardContent className="p-5"><h3 className="font-semibold mb-3">Regras aplicadas</h3><ResponsiveContainer width="100%" height={230}><BarChart data={ruleData}><CartesianGrid vertical={false}/><XAxis dataKey="rule" tick={{fontSize:11}}/><YAxis allowDecimals={false}/><Tooltip/><Bar dataKey="count" name="Atendimentos" fill="hsl(var(--chart-1))" radius={[4,4,0,0]}/></BarChart></ResponsiveContainer></CardContent></Card><Card className="border border-border shadow-sm"><CardContent className="p-5"><h3 className="font-semibold mb-3">Vendedores mais procurados</h3><ResponsiveContainer width="100%" height={230}><BarChart data={sellerData}><CartesianGrid vertical={false}/><XAxis dataKey="seller_name" tick={{fontSize:11}}/><YAxis allowDecimals={false}/><Tooltip/><Bar dataKey="count" name="Preferências" fill="hsl(var(--chart-2))" radius={[4,4,0,0]}/></BarChart></ResponsiveContainer></CardContent></Card></div>
            <Card className="border border-border shadow-sm"><CardContent className="p-0 overflow-x-auto"><table className="w-full text-sm" data-testid="preference-report-table"><thead><tr className="border-b bg-muted/40"><th className="px-4 py-3 text-left">Data</th><th className="px-4 py-3 text-left">Cliente</th><th className="px-4 py-3 text-left">Vendedor</th><th className="px-4 py-3 text-left">Pos. anterior</th><th className="px-4 py-3 text-left">Pos. final</th><th className="px-4 py-3 text-left">Regra</th><th className="px-4 py-3 text-left">Resultado</th><th className="px-4 py-3 text-left">Vendas</th>{data?.can_view_financial && <th className="px-4 py-3 text-left">Receita</th>}</tr></thead><tbody>{(data?.items || []).map((r)=><tr key={r.id} className="border-b"><td className="px-4 py-3">{r.started_at ? new Date(r.started_at).toLocaleString("pt-BR") : "—"}</td><td className="px-4 py-3">{r.customer_name || "—"}</td><td className="px-4 py-3">{r.seller_name}</td><td className="px-4 py-3">{r.previous_position || "—"}</td><td className="px-4 py-3">{r.final_position || "—"}</td><td className="px-4 py-3">{RULES[r.return_rule] || r.return_rule}</td><td className="px-4 py-3">{RESULTS[r.result] || r.status}</td><td className="px-4 py-3">{r.sales_count}</td>{data?.can_view_financial && <td className="px-4 py-3">{centsToBRL(r.revenue || 0)}</td>}</tr>)}</tbody></table></CardContent></Card>
        </div>
    );
}