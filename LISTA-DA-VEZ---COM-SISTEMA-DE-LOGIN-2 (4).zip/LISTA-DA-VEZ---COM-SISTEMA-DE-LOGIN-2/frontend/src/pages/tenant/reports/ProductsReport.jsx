import React, { useState, useEffect, useCallback } from "react";
import { useParams, Link } from "react-router-dom";
import api from "@/lib/api";
import { centsToBRL } from "@/lib/money";
import { PageHeader } from "@/components/Common";
import { ReportFilters } from "@/components/ReportFilters";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, RefreshCw } from "lucide-react";
import { toast } from "sonner";
import { AsyncExportButton } from "@/components/AsyncExportButton";

export default function ProductsReport() {
    const { tenantSlug } = useParams();
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [filters, setFilters] = useState({});

    const load = useCallback(async () => {
        setLoading(true);
        try {
            const params = new URLSearchParams();
            if (filters.date_start) params.set("date_start", filters.date_start);
            if (filters.date_end) params.set("date_end", filters.date_end);
            if (filters.store_id) params.set("store_id", filters.store_id);
            const { data: res } = await api.get(`/tenants/${tenantSlug}/reports/products?${params}`);
            setData(res);
        } catch {
            toast.error("Erro ao carregar relatório de produtos.");
        } finally {
            setLoading(false);
        }
    }, [tenantSlug, filters]);

    useEffect(() => { load(); }, [load]);

    const handleExport = async () => { /* substituído pelo AsyncExportButton */ };

    const maxQty = data.length ? Math.max(...data.map((d) => d.quantidade)) : 1;
    const totalQty = data.reduce((s, d) => s + d.quantidade, 0);
    const totalCents = data.reduce((s, d) => s + d.total_cents, 0);

    return (
        <div data-testid="report-products">
            <div className="flex items-center gap-3 mb-6">
                <Link to={`/${tenantSlug}/reports`} className="text-muted-foreground hover:text-foreground transition-colors">
                    <ArrowLeft size={16} strokeWidth={1.5} />
                </Link>
                <PageHeader eyebrow="Relatório" title="Produtos Mais Vendidos" description="Ranking de produtos por volume e receita no período." />
            </div>

            <ReportFilters filters={filters} onChange={setFilters} />

            {/* KPIs */}
            <div className="metric-grid mb-6">
                {[
                    { label: "Produtos distintos", value: data.length, testId: "kpi-products" },
                    { label: "Total de itens", value: totalQty, testId: "kpi-qty" },
                    { label: "Receita total", value: centsToBRL(totalCents), testId: "kpi-revenue" },
                ].map((k) => (
                    <div key={k.label} className="metric-card-wrap border border-border/60 rounded-md p-4 bg-card">
                        <p className="metric-label text-xs uppercase tracking-[0.1em] text-muted-foreground mb-1">{k.label}</p>
                        <span className="metric-num font-semibold" data-testid={k.testId}>{k.value}</span>
                    </div>
                ))}
            </div>

            <div className="flex justify-between items-center mb-3">
                <p className="text-sm text-muted-foreground">{data.length} produto{data.length !== 1 ? "s" : ""}</p>
                <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={load}>
                        <RefreshCw size={13} strokeWidth={1.5} className="mr-1.5" /> Atualizar
                    </Button>
                    <AsyncExportButton
                        tenantSlug={tenantSlug}
                        reportType="products"
                        filters={filters}
                        data-testid="btn-export-csv"
                    />
                </div>
            </div>

            <div className="border border-border/60 rounded-md bg-card overflow-hidden">
                <div className="overflow-x-auto">
                <table className="w-full text-sm" data-testid="table-products">
                    <thead>
                        <tr className="border-b border-border bg-muted/40">
                            {["#", "Produto", "Quantidade", "Receita Total"].map((h) => (
                                <th key={h} className="text-left px-4 py-3 text-xs font-medium uppercase tracking-[0.08em] text-muted-foreground">{h}</th>
                            ))}
                        </tr>
                    </thead>
                    <tbody>
                        {loading ? (
                            Array.from({ length: 5 }).map((_, i) => (
                                <tr key={i} className="border-b border-border">
                                    {[1, 2, 3, 4].map((j) => (
                                        <td key={j} className="px-4 py-3"><Skeleton className="h-4 w-full" /></td>
                                    ))}
                                </tr>
                            ))
                        ) : data.length === 0 ? (
                            <tr>
                                <td colSpan={4} className="text-center py-12 text-muted-foreground">
                                    Nenhum produto vendido no período selecionado.
                                </td>
                            </tr>
                        ) : (
                            data.map((p, i) => (
                                <tr key={p.product_id || i} className="border-b border-border hover:bg-muted/30 transition-colors">
                                    <td className="px-4 py-3 text-muted-foreground font-mono text-xs">{i + 1}</td>
                                    <td className="px-4 py-3 font-medium">{p.name}</td>
                                    <td className="px-4 py-3">
                                        <div className="flex items-center gap-2">
                                            <span className="font-bold">{p.quantidade}</span>
                                            <div className="h-1.5 bg-border rounded-full w-24 hidden sm:block">
                                                <div className="h-1.5 bg-foreground rounded-full" style={{ width: `${(p.quantidade / maxQty) * 100}%` }} />
                                            </div>
                                        </div>
                                    </td>
                                    <td className="px-4 py-3 font-mono">{centsToBRL(p.total_cents)}</td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    );
}
