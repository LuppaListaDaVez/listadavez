import React, { useState, useEffect, useCallback } from "react";
import { useParams, Link } from "react-router-dom";
import api from "@/lib/api";
import { centsToBRL } from "@/lib/money";
import { PageHeader } from "@/components/Common";
import { ReportFilters } from "@/components/ReportFilters";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, RefreshCw, Trophy } from "lucide-react";
import { toast } from "sonner";
import { AsyncExportButton } from "@/components/AsyncExportButton";

function fmtDuration(seconds) {
    if (!seconds) return "—";
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    if (m < 60) return `${m}m ${s}s`;
    const h = Math.floor(m / 60);
    return `${h}h ${m % 60}m`;
}

function RankBadge({ rank }) {
    if (rank === 0) return <span className="text-amber-500 font-bold">1°</span>;
    if (rank === 1) return <span className="text-zinc-400 font-bold">2°</span>;
    if (rank === 2) return <span className="text-amber-700 font-bold">3°</span>;
    return <span className="text-muted-foreground font-mono text-xs">{rank + 1}°</span>;
}

export default function SellerPerformanceReport() {
    const { tenantSlug } = useParams();
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [filters, setFilters] = useState({});

    const load = useCallback(async () => {
        setLoading(true);
        try {
            const params = new URLSearchParams();
            if (filters.date_start) params.set("date_start", filters.date_start);
            if (filters.date_end) params.set("date_end", filters.date_end);
            if (filters.store_id) params.set("store_id", filters.store_id);
            const { data: res } = await api.get(`/tenants/${tenantSlug}/reports/seller-performance?${params}`);
            setData(res);
        } catch {
            toast.error("Erro ao carregar relatório de performance.");
        } finally {
            setLoading(false);
        }
    }, [tenantSlug, filters]);

    useEffect(() => { load(); }, [load]);

    const handleExport = async () => { /* substituído pelo AsyncExportButton */ };

    const maxVendas = data.length ? Math.max(...data.map((d) => d.vendas)) : 1;

    return (
        <div data-testid="report-seller-perf">
            <div className="flex items-center gap-3 mb-6">
                <Link to={`/${tenantSlug}/reports`} className="text-muted-foreground hover:text-foreground transition-colors">
                    <ArrowLeft size={16} strokeWidth={1.5} />
                </Link>
                <PageHeader eyebrow="Relatório" title="Performance de Vendedores" description="KPIs individuais por vendedor no período selecionado." />
            </div>

            <ReportFilters filters={filters} onChange={setFilters} />

            <div className="flex justify-between items-center mb-4">
                <p className="text-sm text-muted-foreground">{data.length} vendedor{data.length !== 1 ? "es" : ""}</p>
                <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={load}>
                        <RefreshCw size={13} strokeWidth={1.5} className="mr-1.5" /> Atualizar
                    </Button>
                    <AsyncExportButton
                        tenantSlug={tenantSlug}
                        reportType="seller-performance"
                        filters={filters}
                        data-testid="btn-export-csv"
                    />
                </div>
            </div>

            <div className="border border-border/60 rounded-md bg-card overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm" data-testid="table-seller-perf">
                        <thead>
                            <tr className="border-b border-border bg-muted/40">
                                {["#", "Vendedor", "Atendimentos", "Vendas", "Conversão", "Total Vendido", "Ticket Médio", "Tempo Médio"].map((h) => (
                                    <th key={h} className="text-left px-4 py-3 text-xs font-medium uppercase tracking-[0.08em] text-muted-foreground whitespace-nowrap">{h}</th>
                                ))}
                            </tr>
                        </thead>
                        <tbody>
                            {loading ? (
                                Array.from({ length: 5 }).map((_, i) => (
                                    <tr key={i} className="border-b border-border">
                                        {Array.from({ length: 8 }).map((_, j) => (
                                            <td key={j} className="px-4 py-3"><Skeleton className="h-4 w-full" /></td>
                                        ))}
                                    </tr>
                                ))
                            ) : data.length === 0 ? (
                                <tr>
                                    <td colSpan={8} className="text-center py-12 text-muted-foreground">
                                        Nenhum dado encontrado com os filtros aplicados.
                                    </td>
                                </tr>
                            ) : (
                                data.map((s, i) => (
                                    <tr key={s.seller_id} className="border-b border-border hover:bg-muted/30 transition-colors">
                                        <td className="px-4 py-3 w-10 text-center"><RankBadge rank={i} /></td>
                                        <td className="px-4 py-3 font-medium whitespace-nowrap">{s.seller_name}</td>
                                        <td className="px-4 py-3">{s.atendimentos}</td>
                                        <td className="px-4 py-3">
                                            <div className="flex items-center gap-2">
                                                <span className="font-bold">{s.vendas}</span>
                                                <div className="h-1 bg-border rounded-full w-16 hidden sm:block">
                                                    <div className="h-1 bg-foreground rounded-full" style={{ width: `${maxVendas ? (s.vendas / maxVendas) * 100 : 0}%` }} />
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-4 py-3">
                                            <span className={`font-bold ${s.conversao_pct >= 50 ? "text-luppa-green" : s.conversao_pct >= 30 ? "text-amber-700" : "text-luppa-error"}`}>
                                                {s.conversao_pct}%
                                            </span>
                                        </td>
                                        <td className="px-4 py-3 font-mono">{centsToBRL(s.total_cents)}</td>
                                        <td className="px-4 py-3 font-mono">{centsToBRL(s.ticket_medio_cents)}</td>
                                        <td className="px-4 py-3 text-muted-foreground">{fmtDuration(s.tempo_medio_segundos)}</td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}
