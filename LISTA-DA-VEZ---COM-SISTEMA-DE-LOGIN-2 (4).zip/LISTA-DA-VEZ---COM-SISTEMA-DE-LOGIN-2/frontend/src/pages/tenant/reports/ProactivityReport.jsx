import React, { useEffect, useState, useCallback } from "react";
import { useParams } from "react-router-dom";
import { RefreshCw, TrendingUp, ShoppingBag, Activity, User } from "lucide-react";
import api from "@/lib/api";
import { PageHeader } from "@/components/Common";
import { centsToBRL } from "@/lib/money";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { useTenant } from "@/context/TenantContext";
import { AsyncExportButton } from "@/components/AsyncExportButton";

export default function ProactivityReport() {
    const { tenantSlug } = useParams();
    const { context } = useTenant();
    const [report, setReport] = useState(null);
    const [loading, setLoading] = useState(true);
    const [stores, setStores] = useState([]);
    const [filters, setFilters] = useState({ store_id: "", date_start: "", date_end: "" });
    const role = context?.user_role;
    const canExport = ["TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER"].includes(role);

    const load = useCallback(async () => {
        setLoading(true);
        try {
            const params = new URLSearchParams();
            Object.entries(filters).forEach(([k, v]) => { if (v) params.set(k, v); });
            const res = await api.get(`/tenants/${tenantSlug}/reports/proactivity?${params}`);
            setReport(res.data);
        } catch {
            toast.error("Erro ao carregar relatório de proatividade");
        } finally {
            setLoading(false);
        }
    }, [tenantSlug, filters]);

    useEffect(() => {
        load();
        api.get(`/tenants/${tenantSlug}/stores`).then(r => setStores(r.data)).catch(() => {});
    }, [load, tenantSlug]);

    const handleExport = async () => { /* substituído pelo AsyncExportButton */ };

    const KPI = ({ label, value, color, testId }) => (
        <div className="metric-card-wrap border border-border/60 rounded-md p-4 bg-card">
            <p className="metric-label text-xs uppercase tracking-[0.1em] text-muted-foreground mb-1">{label}</p>
            <span className={`metric-num font-semibold ${color || ""}`} data-testid={testId}>{value}</span>
        </div>
    );

    return (
        <div data-testid="proactivity-report-page">
            <div className="flex items-start justify-between mb-6">
                <PageHeader
                    eyebrow="Relatórios"
                    title="Relatório de Proatividade"
                    description="KPIs de abordagens proativas, conversão e receita."
                />
                <div className="flex gap-2 mt-1">
                    {canExport && (
                        <AsyncExportButton
                            tenantSlug={tenantSlug}
                            reportType="proactivity"
                            filters={filters}
                            data-testid="proactivity-report-export-btn"
                        />
                    )}
                    <Button variant="outline" size="sm" onClick={load} data-testid="proactivity-report-refresh-btn">
                        <RefreshCw size={14} className="mr-2" /> Atualizar
                    </Button>
                </div>
            </div>

            {/* Filters */}
            <Card className="border border-border shadow-sm mb-6">
                <CardContent className="p-4">
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                        {role !== "SELLER" && (
                            <div>
                                <label className="text-xs text-muted-foreground mb-1 block">Unidade</label>
                                <select className="w-full border border-border rounded-md px-2 py-1.5 text-sm bg-background"
                                    value={filters.store_id} onChange={e => setFilters(f => ({ ...f, store_id: e.target.value }))}
                                    data-testid="report-filter-store">
                                    <option value="">Todas</option>
                                    {stores.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                                </select>
                            </div>
                        )}
                        <div>
                            <label className="text-xs text-muted-foreground mb-1 block">De</label>
                            <input type="date" className="w-full border border-border rounded-sm px-2 py-1.5 text-sm"
                                value={filters.date_start} onChange={e => setFilters(f => ({ ...f, date_start: e.target.value }))}
                                data-testid="report-filter-date-from" />
                        </div>
                        <div>
                            <label className="text-xs text-muted-foreground mb-1 block">Até</label>
                            <input type="date" className="w-full border border-border rounded-sm px-2 py-1.5 text-sm"
                                value={filters.date_end} onChange={e => setFilters(f => ({ ...f, date_end: e.target.value }))}
                                data-testid="report-filter-date-to" />
                        </div>
                    </div>
                    <Button size="sm" className="mt-3" onClick={load} data-testid="report-apply-btn">
                        <RefreshCw size={12} className="mr-1" /> Aplicar filtros
                    </Button>
                </CardContent>
            </Card>

            {loading ? (
                <div className="space-y-4">
                    <div className="metric-grid-sm">
                        {[1,2,3,4,5,6].map(i => <Skeleton key={i} className="h-24 w-full" />)}
                    </div>
                </div>
            ) : !report ? null : (
                <>
                    {/* KPIs principais */}
                    <div className="metric-grid-sm mb-6">
                        <KPI label="Total abordagens" value={report.total_approaches} testId="r-total" />
                        <KPI label="Abertas" value={report.open} color="text-luppa-purple" testId="r-open" />
                        <KPI label="Em atendimento" value={report.converted_to_attendance} color="text-luppa-purple" testId="r-att" />
                        <KPI label="Vendas" value={report.converted_to_sale} color="text-luppa-green" testId="r-sales" />
                        <KPI label="Sem venda" value={report.no_sale} color="text-luppa-error" testId="r-no-sale" />
                        <KPI label="Canceladas" value={report.cancelled} color="text-gray-500" testId="r-cancelled" />
                    </div>

                    {/* Métricas de conversão */}
                    <div className="metric-grid mb-6">
                        <div className="metric-card-wrap border border-border/60 rounded-md p-4 bg-card flex items-center gap-3">
                            <TrendingUp size={16} className="text-luppa-purple flex-shrink-0" />
                            <div className="min-w-0">
                                <p className="metric-label text-xs uppercase tracking-[0.08em] text-muted-foreground">Conv. → Atendimento</p>
                                <span className="metric-num font-semibold text-luppa-purple" data-testid="r-conv-att">{report.conversion_to_attendance_pct}%</span>
                            </div>
                        </div>
                        <div className="metric-card-wrap border border-border/60 rounded-md p-4 bg-card flex items-center gap-3">
                            <TrendingUp size={16} className="text-luppa-green flex-shrink-0" />
                            <div className="min-w-0">
                                <p className="metric-label text-xs uppercase tracking-[0.08em] text-muted-foreground">Conv. → Venda</p>
                                <span className="metric-num font-semibold text-luppa-green" data-testid="r-conv-sale">{report.conversion_to_sale_pct}%</span>
                            </div>
                        </div>
                        <div className="metric-card-wrap border border-border/60 rounded-md p-4 bg-card flex items-center gap-3">
                            <ShoppingBag size={16} className="text-luppa-green flex-shrink-0" />
                            <div className="min-w-0">
                                <p className="metric-label text-xs uppercase tracking-[0.08em] text-muted-foreground">Receita proativa</p>
                                <span className="metric-num font-semibold text-luppa-green" data-testid="r-revenue">{centsToBRL(report.proactive_revenue_cents || 0)}</span>
                            </div>
                        </div>
                    </div>

                    {/* Por vendedor */}
                    {report.by_seller && report.by_seller.length > 0 && (
                        <Card className="border border-border shadow-sm mb-6">
                            <CardContent className="p-5">
                                <div className="flex items-center gap-2 mb-4">
                                    <User size={14} className="text-muted-foreground" />
                                    <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground">Por vendedor</p>
                                </div>
                                <div className="overflow-x-auto">
                                    <table className="w-full text-sm" data-testid="seller-table">
                                        <thead>
                                            <tr className="border-b border-border text-left">
                                                <th className="pb-2 font-medium text-xs text-muted-foreground">Vendedor</th>
                                                <th className="pb-2 font-medium text-xs text-muted-foreground text-right">Abordagens</th>
                                                <th className="pb-2 font-medium text-xs text-muted-foreground text-right">Vendas</th>
                                                <th className="pb-2 font-medium text-xs text-muted-foreground text-right">Conversão</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {report.by_seller.map((s, i) => (
                                                <tr key={s.seller_id} className={i < report.by_seller.length - 1 ? "border-b border-border/50" : ""}>
                                                    <td className="py-2.5 font-medium">{s.seller_name}</td>
                                                    <td className="py-2.5 text-right">{s.total_approaches}</td>
                                                    <td className="py-2.5 text-right text-luppa-green">{s.sales}</td>
                                                    <td className="py-2.5 text-right text-luppa-purple">{s.conversion_pct}%</td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    {/* Motivos de perda */}
                    {report.loss_reasons && report.loss_reasons.length > 0 && (
                        <Card className="border border-border shadow-sm mb-6">
                            <CardContent className="p-5">
                                <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground mb-4">Motivos de perda</p>
                                <div className="space-y-2">
                                    {report.loss_reasons.map(lr => (
                                        <div key={lr.loss_reason_id} className="flex items-center justify-between">
                                            <span className="text-sm">{lr.name}</span>
                                            <span className="text-sm font-mono text-muted-foreground">{lr.count}x</span>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    )}

                    {/* Fontes */}
                    {report.source_breakdown && report.source_breakdown.length > 0 && (
                        <Card className="border border-border shadow-sm">
                            <CardContent className="p-5">
                                <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground mb-4">Fontes de abordagem</p>
                                <div className="flex flex-wrap gap-2">
                                    {report.source_breakdown.map(s => (
                                        <div key={s.source} className="flex items-center gap-2 bg-muted rounded-sm px-3 py-1.5 text-sm">
                                            <span className="font-medium">{s.source}</span>
                                            <span className="text-muted-foreground text-xs">{s.count}x</span>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    )}
                </>
            )}
        </div>
    );
}
