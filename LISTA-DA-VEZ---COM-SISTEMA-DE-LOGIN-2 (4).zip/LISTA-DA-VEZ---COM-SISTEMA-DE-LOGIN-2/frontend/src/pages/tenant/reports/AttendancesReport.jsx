import React, { useState, useEffect, useCallback } from "react";
import { useParams, Link } from "react-router-dom";
import api from "@/lib/api";
import { centsToBRL } from "@/lib/money";
import { PageHeader } from "@/components/Common";
import { ReportFilters } from "@/components/ReportFilters";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, RefreshCw } from "lucide-react";
import { toast } from "sonner";
import { AsyncExportButton } from "@/components/AsyncExportButton";
import { fmtDateTime } from "@/lib/i18n";

const RESULT_LABELS = {
    SALE: { label: "Sucesso", color: "bg-luppa-green/15 text-emerald-800" },
    NO_SALE: { label: "Não sucesso", color: "bg-luppa-error/15 text-luppa-error" },
    FOLLOW_UP: { label: "Retornará", color: "bg-amber-100 text-amber-800" },
    INVALID: { label: "Inválido", color: "bg-gray-100 text-gray-600" },
};


function fmtDuration(start, end) {
    if (!start || !end) return "—";
    const diff = Math.round((new Date(end) - new Date(start)) / 1000);
    if (diff <= 0) return "—";
    const m = Math.floor(diff / 60);
    const s = diff % 60;
    return m > 0 ? `${m}m ${s}s` : `${s}s`;
}

export default function AttendancesReport() {
    const { tenantSlug } = useParams();
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [filters, setFilters] = useState({});

    const load = useCallback(async () => {
        setLoading(true);
        try {
            const params = new URLSearchParams();
            if (filters.date_start) params.set("date_start", filters.date_start);
            if (filters.date_end) params.set("date_end", filters.date_end);
            if (filters.store_id) params.set("store_id", filters.store_id);
            if (filters.seller_id) params.set("seller_id", filters.seller_id);
            if (filters.result) params.set("result", filters.result);
            const { data: res } = await api.get(`/tenants/${tenantSlug}/reports/attendances?${params}`);
            setData(res);
        } catch {
            toast.error("Erro ao carregar relatório de atendimentos.");
        } finally {
            setLoading(false);
        }
    }, [tenantSlug, filters]);

    useEffect(() => { load(); }, [load]);

    const handleExport = async () => {
        // mantido como fallback — substituído pelo AsyncExportButton abaixo
    };

    const sales = data.filter((a) => a.result === "SALE");
    const totalSold = sales.reduce((s, a) => s + (a.sale_amount_cents || 0), 0);
    const conversion = data.length ? Math.round((sales.length / data.length) * 100) : 0;

    return (
        <div data-testid="report-attendances">
            <div className="flex items-center gap-3 mb-6">
                <Link to={`/${tenantSlug}/reports`} className="text-muted-foreground hover:text-foreground transition-colors">
                    <ArrowLeft size={16} strokeWidth={1.5} />
                </Link>
                <PageHeader eyebrow="Relatório" title="Atendimentos" />
            </div>

            <ReportFilters filters={filters} onChange={setFilters} showResult showSeller />

            {/* KPI rápido */}
            <div className="metric-grid mb-6">
                {[
                    { label: "Total", value: data.length, testId: "kpi-total" },
                    { label: "Vendas", value: sales.length, testId: "kpi-sales" },
                    { label: "Conversão", value: `${conversion}%`, testId: "kpi-conv" },
                    { label: "Total vendido", value: centsToBRL(totalSold), testId: "kpi-sold" },
                ].map((k) => (
                    <div key={k.label} className="metric-card-wrap border border-border/60 rounded-md p-4 bg-card">
                        <p className="metric-label text-xs uppercase tracking-[0.1em] text-muted-foreground mb-1">{k.label}</p>
                        <span className="metric-num font-semibold" data-testid={k.testId}>{k.value}</span>
                    </div>
                ))}
            </div>

            <div className="flex justify-between items-center mb-3">
                <p className="text-sm text-muted-foreground">{data.length} registros</p>
                <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={load} data-testid="btn-refresh">
                        <RefreshCw size={13} strokeWidth={1.5} className="mr-1.5" /> Atualizar
                    </Button>
                    <AsyncExportButton
                        tenantSlug={tenantSlug}
                        reportType="attendances"
                        filters={filters}
                        data-testid="btn-export-csv"
                    />
                </div>
            </div>

            <div className="border border-border/60 rounded-md bg-card overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm" data-testid="table-attendances">
                        <thead>
                            <tr className="border-b border-border bg-muted/40">
                                {["Vendedor", "Unidade", "Resultado", "Valor venda", "Motivo perda", "Início", "Duração", "Obs"].map((h) => (
                                    <th key={h} className="text-left px-4 py-3 text-xs font-medium uppercase tracking-[0.08em] text-muted-foreground whitespace-nowrap">{h}</th>
                                ))}
                            </tr>
                        </thead>
                        <tbody>
                            {loading ? (
                                Array.from({ length: 6 }).map((_, i) => (
                                    <tr key={i} className="border-b border-border">
                                        {Array.from({ length: 8 }).map((_, j) => (
                                            <td key={j} className="px-4 py-3"><Skeleton className="h-4 w-full" /></td>
                                        ))}
                                    </tr>
                                ))
                            ) : data.length === 0 ? (
                                <tr>
                                    <td colSpan={8} className="text-center py-12 text-muted-foreground text-sm">
                                        Nenhum atendimento encontrado com os filtros aplicados.
                                    </td>
                                </tr>
                            ) : (
                                data.map((a) => {
                                    const r = RESULT_LABELS[a.result] || { label: a.result, color: "bg-gray-100 text-gray-600" };
                                    return (
                                        <tr key={a.id} className="border-b border-border hover:bg-muted/30 transition-colors">
                                            <td className="px-4 py-3 font-medium whitespace-nowrap">{a.seller_name || "—"}</td>
                                            <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">{a.store_name || "—"}</td>
                                            <td className="px-4 py-3">
                                                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${r.color}`}>{r.label}</span>
                                            </td>
                                            <td className="px-4 py-3 font-mono text-sm">{a.result === "SALE" ? centsToBRL(a.sale_amount_cents) : "—"}</td>
                                            <td className="px-4 py-3 text-muted-foreground max-w-[160px] truncate">{a.loss_reason !== "—" ? a.loss_reason : "—"}</td>
                                            <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">{fmtDateTime(a.created_at)}</td>
                                            <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">{fmtDuration(a.started_at, a.finished_at)}</td>
                                            <td className="px-4 py-3 text-muted-foreground max-w-[120px] truncate">{a.notes || "—"}</td>
                                        </tr>
                                    );
                                })
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}
