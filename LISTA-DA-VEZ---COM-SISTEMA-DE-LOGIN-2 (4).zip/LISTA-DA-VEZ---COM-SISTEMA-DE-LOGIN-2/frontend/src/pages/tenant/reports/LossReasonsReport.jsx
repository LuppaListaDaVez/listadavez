import React, { useState, useEffect, useCallback } from "react";
import { useParams, Link } from "react-router-dom";
import {
    ResponsiveContainer,
    BarChart,
    Bar,
    XAxis,
    YAxis,
    Tooltip,
    CartesianGrid,
    Cell,
} from "recharts";
import api from "@/lib/api";
import { PageHeader } from "@/components/Common";
import { ReportFilters } from "@/components/ReportFilters";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, RefreshCw } from "lucide-react";
import { toast } from "sonner";
import { AsyncExportButton } from "@/components/AsyncExportButton";

const BAR_COLORS = [
    "hsl(var(--chart-1))",
    "hsl(var(--chart-2))",
    "hsl(var(--chart-3))",
    "hsl(var(--chart-4))",
    "hsl(var(--chart-5))",
    "hsl(var(--foreground))",
];

export default function LossReasonsReport() {
    const { tenantSlug } = useParams();
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [filters, setFilters] = useState({});

    const load = useCallback(async () => {
        setLoading(true);
        try {
            const params = new URLSearchParams();
            if (filters.date_start) params.set("date_start", filters.date_start);
            if (filters.date_end) params.set("date_end", filters.date_end);
            if (filters.store_id) params.set("store_id", filters.store_id);
            const { data: res } = await api.get(`/tenants/${tenantSlug}/reports/loss-reasons?${params}`);
            setData(res);
        } catch {
            toast.error("Erro ao carregar relatório de motivos.");
        } finally {
            setLoading(false);
        }
    }, [tenantSlug, filters]);

    useEffect(() => { load(); }, [load]);

    const handleExport = async () => { /* substituído pelo AsyncExportButton */ };

    const items = data?.items || [];
    const total = data?.total_no_sale || 0;
    const chartData = items.slice(0, 8).map((i) => ({ name: i.name, count: i.count, pct: i.pct }));

    return (
        <div data-testid="report-loss-reasons">
            <div className="flex items-center gap-3 mb-6">
                <Link to={`/${tenantSlug}/reports`} className="text-muted-foreground hover:text-foreground transition-colors">
                    <ArrowLeft size={16} strokeWidth={1.5} />
                </Link>
                <PageHeader eyebrow="Relatório" title="Motivos de Perda" description="Ranking dos motivos de não-conversão registrados no período." />
            </div>

            <ReportFilters filters={filters} onChange={setFilters} />

            <div className="flex justify-between items-center mb-4">
                <p className="text-sm text-muted-foreground">{total} não-vendas registradas</p>
                <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={load}>
                        <RefreshCw size={13} strokeWidth={1.5} className="mr-1.5" /> Atualizar
                    </Button>
                    <AsyncExportButton
                        tenantSlug={tenantSlug}
                        reportType="loss-reasons"
                        filters={filters}
                        data-testid="btn-export-csv"
                    />
                </div>
            </div>

            {/* Gráfico */}
            <Card className="border border-border shadow-sm mb-6" data-testid="chart-loss-reasons">
                <CardContent className="p-6">
                    <p className="text-xs uppercase tracking-[0.12em] text-muted-foreground mb-5">Ocorrências por motivo (top 8)</p>
                    {loading ? (
                        <Skeleton className="h-52 w-full" />
                    ) : chartData.length === 0 ? (
                        <p className="text-center text-sm text-muted-foreground py-10">Nenhum motivo registrado no período.</p>
                    ) : (
                        <ResponsiveContainer width="100%" height={220}>
                            <BarChart data={chartData} layout="vertical" margin={{ top: 4, right: 40, bottom: 4, left: 8 }}>
                                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" horizontal={false} />
                                <XAxis type="number" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} />
                                <YAxis type="category" dataKey="name" tick={{ fontSize: 12, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} width={130} />
                                <Tooltip
                                    cursor={{ fill: "hsl(var(--muted))" }}
                                    formatter={(v, _, p) => [`${v} (${p.payload.pct}%)`, "Ocorrências"]}
                                />
                                <Bar dataKey="count" radius={[0, 3, 3, 0]} maxBarSize={24}>
                                    {chartData.map((_, i) => (
                                        <Cell key={i} fill={BAR_COLORS[i % BAR_COLORS.length]} />
                                    ))}
                                </Bar>
                            </BarChart>
                        </ResponsiveContainer>
                    )}
                </CardContent>
            </Card>

            {/* Tabela */}
            <div className="border border-border/60 rounded-md bg-card overflow-hidden">
                <div className="overflow-x-auto">
                <table className="w-full text-sm" data-testid="table-loss-reasons">
                    <thead>
                        <tr className="border-b border-border bg-muted/40">
                            {["#", "Motivo", "Ocorrências", "%"].map((h) => (
                                <th key={h} className="text-left px-4 py-3 text-xs font-medium uppercase tracking-[0.08em] text-muted-foreground">{h}</th>
                            ))}
                        </tr>
                    </thead>
                    <tbody>
                        {loading ? (
                            Array.from({ length: 5 }).map((_, i) => (
                                <tr key={i} className="border-b border-border">
                                    {[1, 2, 3, 4].map((j) => (
                                        <td key={j} className="px-4 py-3"><Skeleton className="h-4 w-full" /></td>
                                    ))}
                                </tr>
                            ))
                        ) : items.length === 0 ? (
                            <tr>
                                <td colSpan={4} className="text-center py-12 text-muted-foreground">Nenhum dado encontrado.</td>
                            </tr>
                        ) : (
                            items.map((item, i) => (
                                <tr key={i} className="border-b border-border hover:bg-muted/30 transition-colors">
                                    <td className="px-4 py-3 text-muted-foreground font-mono text-xs">{i + 1}</td>
                                    <td className="px-4 py-3 font-medium">{item.name}</td>
                                    <td className="px-4 py-3 font-bold">{item.count}</td>
                                    <td className="px-4 py-3">
                                        <div className="flex items-center gap-2">
                                            <div className="flex-1 h-1.5 bg-border rounded-full max-w-[80px]">
                                                <div className="h-1.5 bg-foreground rounded-full" style={{ width: `${item.pct}%` }} />
                                            </div>
                                            <span className="text-sm font-mono">{item.pct}%</span>
                                        </div>
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    );
}
