/**
 * Relatório PA — Produtos por Atendimento
 * PA = total_produtos_vendidos / total_atendimentos_com_venda
 */
import React, { useState, useEffect, useCallback } from "react";
import { useParams } from "react-router-dom";
import api, { extractError } from "@/lib/api";
import { PageHeader } from "@/components/Common";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
    Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { useTenant } from "@/context/TenantContext";
import { centsToBRL } from "@/lib/money";
import { RefreshCw, Package, TrendingUp, Users, ShoppingCart } from "lucide-react";
import { toast } from "sonner";

function fmtDate(d) {
    return d.toISOString().slice(0, 10);
}

function fmtPa(val) {
    if (!val && val !== 0) return "—";
    return Number(val).toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function SummaryCard({ icon: Icon, label, value, accent, testId }) {
    const colors = {
        blue: "text-luppa-purple",
        emerald: "text-luppa-green",
        amber: "text-amber-700",
        indigo: "text-luppa-purple",
    };
    return (
        <div className="metric-card-wrap border border-border/60 rounded-md p-4 bg-card" data-testid={testId}>
            <div className="flex items-center justify-between mb-1 gap-1 min-w-0">
                <p className="metric-label text-xs uppercase tracking-[0.1em] text-muted-foreground">{label}</p>
                <Icon size={13} className={`${colors[accent] || "text-muted-foreground"} opacity-50 flex-shrink-0`} />
            </div>
            <span className={`metric-num font-semibold ${colors[accent] || ""}`}>{value}</span>
        </div>
    );
}

export default function PAReport() {
    const { tenantSlug } = useParams();
    const { context } = useTenant();
    const stores = context?.stores || [];

    const today = fmtDate(new Date());
    const firstOfMonth = fmtDate(new Date(new Date().getFullYear(), new Date().getMonth(), 1));

    const [dateStart, setDateStart] = useState(firstOfMonth);
    const [dateEnd, setDateEnd] = useState(today);
    const [storeId, setStoreId] = useState("");
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(false);

    const fetchData = useCallback(async () => {
        setLoading(true);
        try {
            const params = new URLSearchParams();
            if (dateStart) params.set("date_start", dateStart);
            if (dateEnd) params.set("date_end", dateEnd);
            if (storeId) params.set("store_id", storeId);
            const { data: res } = await api.get(
                `/tenants/${tenantSlug}/reports/pa?${params.toString()}`
            );
            setData(res);
        } catch (e) {
            toast.error(extractError(e, "Erro ao carregar relatório de PA"));
        } finally {
            setLoading(false);
        }
    }, [tenantSlug, dateStart, dateEnd, storeId]);

    useEffect(() => { fetchData(); }, [fetchData]);

    const total = data?.total || {};
    const sellers = data?.by_seller || [];

    return (
        <div data-testid="pa-report-page">
            <PageHeader
                eyebrow="Relatórios"
                title="PA — Produtos por Atendimento"
                description="Média de produtos vendidos por atendimento bem-sucedido."
            />

            {/* Filtros */}
            <div className="flex flex-wrap items-end gap-3 mb-6 p-4 bg-muted/40 rounded-lg border border-border">
                <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">De</Label>
                    <Input
                        type="date"
                        value={dateStart}
                        onChange={(e) => setDateStart(e.target.value)}
                        className="h-8 text-xs w-36"
                        data-testid="pa-date-start"
                    />
                </div>
                <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">Até</Label>
                    <Input
                        type="date"
                        value={dateEnd}
                        onChange={(e) => setDateEnd(e.target.value)}
                        className="h-8 text-xs w-36"
                        data-testid="pa-date-end"
                    />
                </div>
                {stores.length > 1 && (
                    <div className="space-y-1">
                        <Label className="text-xs text-muted-foreground">Unidade</Label>
                        <Select value={storeId || "all"} onValueChange={(v) => setStoreId(v === "all" ? "" : v)}>
                            <SelectTrigger className="h-8 text-xs w-44" data-testid="pa-store-select">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="all">Todas as unidades</SelectItem>
                                {stores.map((s) => (
                                    <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>
                )}
                <Button
                    size="sm"
                    variant="outline"
                    onClick={fetchData}
                    disabled={loading}
                    className="gap-2"
                    data-testid="pa-refresh-btn"
                >
                    <RefreshCw size={13} className={loading ? "animate-spin" : ""} />
                    Atualizar
                </Button>
            </div>

            {/* Cards de resumo geral */}
            <div className="metric-grid mb-6">
                <SummaryCard
                    icon={Package}
                    label="PA da Empresa"
                    value={fmtPa(total.pa)}
                    accent="blue"
                    testId="pa-total-card"
                />
                <SummaryCard
                    icon={ShoppingCart}
                    label="Total de Produtos"
                    value={(total.total_produtos || 0).toLocaleString("pt-BR")}
                    accent="emerald"
                    testId="pa-products-card"
                />
                <SummaryCard
                    icon={Users}
                    label="Atend. com Venda"
                    value={(total.atendimentos_com_venda || 0).toLocaleString("pt-BR")}
                    accent="indigo"
                    testId="pa-sale-att-card"
                />
                <SummaryCard
                    icon={TrendingUp}
                    label="Conversão"
                    value={`${total.conversao_pct || 0}%`}
                    accent="amber"
                    testId="pa-conversion-card"
                />
            </div>

            {/* Tabela de vendedores */}
            {sellers.length === 0 ? (
                <Card className="border border-border shadow-sm">
                    <CardContent className="p-12 text-center">
                        <Package size={32} className="text-muted-foreground/30 mx-auto mb-3" />
                        <p className="text-sm text-muted-foreground">
                            {loading ? "Carregando…" : "Nenhum dado encontrado para o período selecionado."}
                        </p>
                    </CardContent>
                </Card>
            ) : (
                <Card className="border border-border shadow-sm" data-testid="pa-sellers-table">
                    <CardContent className="p-0">
                        <div className="overflow-x-auto">
                            <table className="w-full text-sm">
                                <thead>
                                    <tr className="border-b border-border bg-muted/40">
                                        <th className="text-left px-4 py-3 text-xs uppercase tracking-[0.08em] text-muted-foreground font-semibold">#</th>
                                        <th className="text-left px-4 py-3 text-xs uppercase tracking-[0.08em] text-muted-foreground font-semibold">Vendedor</th>
                                        <th className="text-right px-4 py-3 text-xs uppercase tracking-[0.08em] text-muted-foreground font-semibold">Atend.</th>
                                        <th className="text-right px-4 py-3 text-xs uppercase tracking-[0.08em] text-muted-foreground font-semibold">c/ Venda</th>
                                        <th className="text-right px-4 py-3 text-xs uppercase tracking-[0.08em] text-muted-foreground font-semibold">Produtos</th>
                                        <th className="text-right px-4 py-3 text-xs uppercase tracking-[0.08em] text-muted-foreground font-semibold font-mono">PA</th>
                                        <th className="text-right px-4 py-3 text-xs uppercase tracking-[0.08em] text-muted-foreground font-semibold">Conversão</th>
                                        <th className="text-right px-4 py-3 text-xs uppercase tracking-[0.08em] text-muted-foreground font-semibold">Receita</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {sellers.map((s, i) => (
                                        <tr
                                            key={s.seller_id}
                                            className={`border-b border-border/50 transition-colors hover:bg-muted/30 ${i === 0 ? "bg-luppa-purple/10/40" : ""}`}
                                            data-testid={`pa-row-${s.seller_id}`}
                                        >
                                            <td className="px-4 py-3 text-muted-foreground font-medium">
                                                {i === 0
                                                    ? <span className="text-luppa-purple font-bold">1º</span>
                                                    : `${i + 1}º`}
                                            </td>
                                            <td className="px-4 py-3 font-medium truncate max-w-[160px]">{s.seller_name}</td>
                                            <td className="px-4 py-3 text-right text-muted-foreground">{s.total_atendimentos}</td>
                                            <td className="px-4 py-3 text-right text-muted-foreground">{s.atendimentos_com_venda}</td>
                                            <td className="px-4 py-3 text-right font-medium">{s.total_produtos}</td>
                                            <td className="px-4 py-3 text-right">
                                                <Badge
                                                    variant={s.pa > 0 ? "default" : "secondary"}
                                                    className="font-mono tabular-nums"
                                                    data-testid={`pa-value-${s.seller_id}`}
                                                >
                                                    {fmtPa(s.pa)}
                                                </Badge>
                                            </td>
                                            <td className="px-4 py-3 text-right text-muted-foreground">{s.conversao_pct}%</td>
                                            <td className="px-4 py-3 text-right font-mono text-xs">{centsToBRL(s.total_cents)}</td>
                                        </tr>
                                    ))}
                                </tbody>
                                <tfoot>
                                    <tr className="bg-muted/50 border-t-2 border-border font-semibold">
                                        <td className="px-4 py-3 text-xs text-muted-foreground" colSpan={2}>Total geral</td>
                                        <td className="px-4 py-3 text-right text-xs">{total.total_atendimentos}</td>
                                        <td className="px-4 py-3 text-right text-xs">{total.atendimentos_com_venda}</td>
                                        <td className="px-4 py-3 text-right text-xs">{total.total_produtos}</td>
                                        <td className="px-4 py-3 text-right">
                                            <Badge className="font-mono" data-testid="pa-total-value">{fmtPa(total.pa)}</Badge>
                                        </td>
                                        <td className="px-4 py-3 text-right text-xs">{total.conversao_pct}%</td>
                                        <td className="px-4 py-3 text-right font-mono text-xs">{centsToBRL(total.total_vendido_cents)}</td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </CardContent>
                </Card>
            )}

            {/* Explicação da fórmula */}
            <div className="mt-4 p-4 bg-muted/30 rounded-md border border-border/50">
                <p className="text-xs text-muted-foreground leading-relaxed">
                    <span className="font-semibold text-foreground">Como o PA é calculado:</span>{" "}
                    PA = total de produtos vendidos ÷ total de atendimentos com venda.
                    Atendimentos sem venda não entram no PA, mas são usados no cálculo de conversão.
                    O total geral não é a média dos PAs individuais — é calculado diretamente do total de produtos e atendimentos.
                </p>
            </div>
        </div>
    );
}
