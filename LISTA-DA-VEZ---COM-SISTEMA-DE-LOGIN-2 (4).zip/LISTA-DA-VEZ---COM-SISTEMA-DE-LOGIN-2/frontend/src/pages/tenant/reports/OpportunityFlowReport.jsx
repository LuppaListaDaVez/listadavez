import React, { useCallback, useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import {
    ResponsiveContainer, ComposedChart, CartesianGrid, XAxis, YAxis, Tooltip,
    Legend, Bar, Line, AreaChart, Area,
} from "recharts";
import api, { extractError } from "@/lib/api";
import { PageHeader } from "@/components/Common";
import { centsToBRL } from "@/lib/money";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ArrowLeft, Download, RefreshCw, TrendingUp, Users, ShoppingCart, Target, AlertTriangle } from "lucide-react";
import { toast } from "sonner";

const ALL = "__all__";
const WEEKDAYS = { 1: "Dom", 2: "Seg", 3: "Ter", 4: "Qua", 5: "Qui", 6: "Sex", 7: "Sáb" };

function isoDate(d) { return d.toISOString().slice(0, 10); }
function todayRange() { const d = new Date(); return { date_start: isoDate(d), date_end: isoDate(d), preset: "today" }; }
function pct(v) { return `${Number(v || 0).toLocaleString("pt-BR", { maximumFractionDigits: 1 })}%`; }
function number(v) { return Number(v || 0).toLocaleString("pt-BR"); }

function presetToDates(preset) {
    const now = new Date();
    const start = new Date(now);
    const end = new Date(now);
    if (preset === "yesterday") { start.setDate(start.getDate() - 1); end.setDate(end.getDate() - 1); }
    if (preset === "last7") start.setDate(start.getDate() - 6);
    if (preset === "last30") start.setDate(start.getDate() - 29);
    if (preset === "week") start.setDate(start.getDate() - start.getDay());
    if (preset === "month") start.setDate(1);
    return { date_start: isoDate(start), date_end: isoDate(end), preset };
}

function Kpi({ icon: Icon, label, value, sub, testId }) {
    return (
        <div className="metric-card-wrap border border-border/60 rounded-md p-4 bg-card min-w-0" data-testid={testId}>
            <div className="flex items-center justify-between gap-3 mb-2">
                <p className="metric-label text-xs uppercase tracking-[0.1em] text-muted-foreground truncate">{label}</p>
                <Icon size={15} className="text-luppa-green/70 shrink-0" />
            </div>
            <span className="metric-num font-semibold break-words">{value}</span>
            {sub && <p className="text-xs text-muted-foreground mt-1">{sub}</p>}
        </div>
    );
}

function ChartTooltip({ active, payload, label, financeiro }) {
    if (!active || !payload?.length) return null;
    const d = payload[0]?.payload || {};
    return (
        <div className="bg-card border border-border rounded-md shadow-md p-3 text-sm" data-testid="opportunity-flow-tooltip">
            <p className="font-semibold mb-1">{label}</p>
            <p>Oportunidades: <b>{number(d.opportunities)}</b></p>
            <p>Convertidas: <b>{number(d.converted_opportunities)}</b></p>
            <p>Vendas: <b>{number(d.sales)}</b></p>
            <p>Conversão: <b>{pct(d.conversion_rate)}</b></p>
            {financeiro && <p>Receita: <b>{centsToBRL(d.revenue || 0)}</b></p>}
            {financeiro && <p>Ticket médio: <b>{centsToBRL(d.average_ticket || 0)}</b></p>}
        </div>
    );
}

export default function OpportunityFlowReport() {
    const { tenantSlug } = useParams();
    const [filters, setFilters] = useState(todayRange());
    const [options, setOptions] = useState({ stores: [], teams: [], sellers: [], attendance_types: [] });
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(false);
    const [exporting, setExporting] = useState(null);
    const [metric, setMetric] = useState("opportunities");
    const [legend, setLegend] = useState({ opportunities: true, converted: true, conversion: true });
    const [sort, setSort] = useState({ key: "bucket_start", dir: "asc" });

    const params = useMemo(() => {
        const p = new URLSearchParams();
        ["date_start", "date_end", "store_id", "team_id", "seller_id", "attendance_type"].forEach((k) => { if (filters[k]) p.set(k, filters[k]); });
        return p;
    }, [filters]);

    const loadOptions = useCallback(async () => {
        const p = new URLSearchParams();
        if (filters.store_id) p.set("store_id", filters.store_id);
        if (filters.team_id) p.set("team_id", filters.team_id);
        const { data: res } = await api.get(`/tenants/${tenantSlug}/reports/opportunity-flow/options?${p}`);
        setOptions(res);
    }, [tenantSlug, filters.store_id, filters.team_id]);

    const load = useCallback(async () => {
        setLoading(true);
        try {
            await loadOptions();
            const { data: res } = await api.get(`/tenants/${tenantSlug}/reports/opportunity-flow?${params}`);
            setData(res);
        } catch (e) {
            toast.error(extractError(e, "Erro ao carregar Fluxo de Oportunidades por Horário"));
        } finally { setLoading(false); }
    }, [tenantSlug, params, loadOptions]);

    useEffect(() => { load(); }, [load]);

    const set = (key, value) => {
        const next = { ...filters, [key]: value === ALL ? "" : value };
        if (key === "store_id") { next.team_id = ""; next.seller_id = ""; }
        if (key === "team_id") next.seller_id = "";
        setFilters(next);
    };

    const exportFile = async (type) => {
        setExporting(type);
        try {
            const res = await api.get(`/tenants/${tenantSlug}/reports/opportunity-flow/export.${type}?${params}`, { responseType: "blob" });
            const url = URL.createObjectURL(new Blob([res.data]));
            const a = document.createElement("a");
            a.href = url; a.download = `fluxo_oportunidades_horario.${type}`; a.click(); URL.revokeObjectURL(url);
        } catch (e) { toast.error(extractError(e, "Erro ao exportar relatório")); }
        finally { setExporting(null); }
    };

    const totals = data?.totals || {};
    const financeiro = !!data?.can_view_financial;
    const sortedSeries = useMemo(() => {
        const arr = [...(data?.series || [])];
        arr.sort((a, b) => {
            const av = a[sort.key] ?? 0, bv = b[sort.key] ?? 0;
            const cmp = av > bv ? 1 : av < bv ? -1 : 0;
            return sort.dir === "asc" ? cmp : -cmp;
        });
        return arr;
    }, [data, sort]);

    const maxHeat = Math.max(1, ...(data?.heatmap || []).map((c) => Number(c[metric] || 0)));

    return (
        <div data-testid="opportunity-flow-page">
            <div className="flex items-center gap-3 mb-6">
                <Link to={`/${tenantSlug}/reports`} className="text-muted-foreground hover:text-foreground" data-testid="opportunity-flow-back-link"><ArrowLeft size={16} /></Link>
                <PageHeader eyebrow="Relatórios" title="Fluxo de Oportunidades por Horário" description="Volume, conversão e receita agrupados pelo horário real de início do atendimento." />
            </div>

            <Card className="border border-border shadow-sm mb-6" data-testid="opportunity-flow-filters-card">
                <CardContent className="p-4 space-y-4">
                    <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-8 gap-3 items-end">
                        <div className="space-y-1 col-span-2 md:col-span-1"><Label>Período</Label><Select value={filters.preset || "custom"} onValueChange={(v) => v === "custom" ? setFilters({ ...filters, preset: "custom" }) : setFilters({ ...filters, ...presetToDates(v) })}><SelectTrigger data-testid="opf-preset"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="today">Hoje</SelectItem><SelectItem value="yesterday">Ontem</SelectItem><SelectItem value="last7">Últimos 7 dias</SelectItem><SelectItem value="last30">Últimos 30 dias</SelectItem><SelectItem value="week">Semana atual</SelectItem><SelectItem value="month">Mês atual</SelectItem><SelectItem value="custom">Personalizado</SelectItem></SelectContent></Select></div>
                        <div className="space-y-1"><Label>De</Label><Input type="date" value={filters.date_start || ""} onChange={(e) => setFilters({ ...filters, date_start: e.target.value, preset: "custom" })} data-testid="opf-date-start" /></div>
                        <div className="space-y-1"><Label>Até</Label><Input type="date" value={filters.date_end || ""} onChange={(e) => setFilters({ ...filters, date_end: e.target.value, preset: "custom" })} data-testid="opf-date-end" /></div>
                        <div className="space-y-1"><Label>Unidade</Label><Select value={filters.store_id || ALL} onValueChange={(v) => set("store_id", v)}><SelectTrigger data-testid="opf-store"><SelectValue /></SelectTrigger><SelectContent><SelectItem value={ALL}>Todas</SelectItem>{options.stores.map((o) => <SelectItem key={o.id} value={o.id}>{o.name}</SelectItem>)}</SelectContent></Select></div>
                        <div className="space-y-1"><Label>Equipe</Label><Select value={filters.team_id || ALL} onValueChange={(v) => set("team_id", v)}><SelectTrigger data-testid="opf-team"><SelectValue /></SelectTrigger><SelectContent><SelectItem value={ALL}>Todas</SelectItem>{options.teams.map((o) => <SelectItem key={o.id} value={o.id}>{o.name}</SelectItem>)}</SelectContent></Select></div>
                        <div className="space-y-1"><Label>Vendedor</Label><Select value={filters.seller_id || ALL} onValueChange={(v) => set("seller_id", v)}><SelectTrigger data-testid="opf-seller"><SelectValue /></SelectTrigger><SelectContent><SelectItem value={ALL}>Todos</SelectItem>{options.sellers.map((o) => <SelectItem key={o.id} value={o.id}>{o.name}</SelectItem>)}</SelectContent></Select></div>
                        <div className="space-y-1"><Label>Tipo</Label><Select value={filters.attendance_type || ALL} onValueChange={(v) => set("attendance_type", v)}><SelectTrigger data-testid="opf-type"><SelectValue /></SelectTrigger><SelectContent><SelectItem value={ALL}>Todos</SelectItem>{options.attendance_types.map((o) => <SelectItem key={o.id} value={o.id}>{o.name}</SelectItem>)}</SelectContent></Select></div>
                        <Button onClick={load} disabled={loading} className="gap-2" data-testid="opf-refresh"><RefreshCw size={14} className={loading ? "animate-spin" : ""} />Atualizar</Button>
                    </div>
                </CardContent>
            </Card>

            {!financeiro && data && <Alert className="mb-6" data-testid="opportunity-flow-financial-hidden"><AlertTriangle size={14} /><AlertDescription>Receita oculta: seu perfil não possui permissão financeira para receber valores pela API.</AlertDescription></Alert>}

            <div className="metric-grid mb-6">
                <Kpi icon={Users} label="Oportunidades" value={loading ? "—" : number(totals.opportunities)} testId="opf-kpi-opportunities" />
                <Kpi icon={Target} label="Convertidas" value={loading ? "—" : number(totals.converted_opportunities)} sub={pct(totals.conversion_rate)} testId="opf-kpi-converted" />
                <Kpi icon={ShoppingCart} label="Vendas" value={loading ? "—" : number(totals.sales)} testId="opf-kpi-sales" />
                <Kpi icon={TrendingUp} label="Conversão" value={loading ? "—" : pct(totals.conversion_rate)} sub={data?.comparison?.sem_base_comparativa ? "Sem base comparativa" : `${pct(data?.comparison?.conversion_change_points)} p.p.`} testId="opf-kpi-conversion" />
                {financeiro && <Kpi icon={TrendingUp} label="Receita" value={loading ? "—" : centsToBRL(totals.revenue || 0)} testId="opf-kpi-revenue" />}
                {financeiro && <Kpi icon={ShoppingCart} label="Ticket médio" value={loading ? "—" : centsToBRL(totals.average_ticket || 0)} testId="opf-kpi-ticket" />}
                <Kpi icon={Users} label={`Média por ${data?.period?.granularity === "hour" ? "hora" : data?.period?.granularity === "week" ? "semana" : data?.period?.granularity === "month" ? "mês" : "dia"}`} value={loading ? "—" : Number(totals.average_opportunities || 0).toLocaleString("pt-BR", { maximumFractionDigits: 1 })} testId="opf-kpi-average" />
                <Kpi icon={AlertTriangle} label="Vendas sem atendimento" value={loading ? "—" : number(data?.data_quality?.sales_without_attendance)} testId="opf-kpi-quality" />
            </div>

            <div className="flex flex-wrap gap-2 justify-end mb-4">
                <Button variant="outline" size="sm" onClick={() => exportFile("csv")} disabled={!!exporting} data-testid="opf-export-csv"><Download size={13} /> CSV</Button>
                <Button variant="outline" size="sm" onClick={() => exportFile("xlsx")} disabled={!!exporting} data-testid="opf-export-xlsx"><Download size={13} /> XLSX</Button>
            </div>

            <Tabs defaultValue="evolucao" className="space-y-5">
                <TabsList className="flex flex-wrap h-auto" data-testid="opf-tabs"><TabsTrigger value="evolucao" data-testid="opf-tab-evolution">Evolução</TabsTrigger><TabsTrigger value="mapa" data-testid="opf-tab-heatmap">Mapa de horários</TabsTrigger><TabsTrigger value="tabela" data-testid="opf-tab-table">Tabela analítica</TabsTrigger></TabsList>
                <TabsContent value="evolucao">
                    <Card className="border border-border shadow-sm" data-testid="opf-chart-card"><CardContent className="p-4 md:p-6">
                        <div className="flex flex-wrap gap-2 mb-4"><Button size="sm" variant={legend.opportunities ? "default" : "outline"} onClick={() => setLegend({ ...legend, opportunities: !legend.opportunities })} data-testid="opf-toggle-opportunities">Oportunidades</Button><Button size="sm" variant={legend.converted ? "default" : "outline"} onClick={() => setLegend({ ...legend, converted: !legend.converted })} data-testid="opf-toggle-converted">Convertidas</Button><Button size="sm" variant={legend.conversion ? "default" : "outline"} onClick={() => setLegend({ ...legend, conversion: !legend.conversion })} data-testid="opf-toggle-conversion">Conversão</Button></div>
                        {loading ? <Skeleton className="h-80 w-full" /> : <div className="overflow-x-auto"><div className="min-w-[720px] md:min-w-0"><ResponsiveContainer width="100%" height={340}><ComposedChart data={data?.series || []} margin={{ top: 16, right: 22, left: 0, bottom: 4 }}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" /><XAxis dataKey="label" tick={{ fontSize: 11 }} interval="preserveStartEnd" /><YAxis yAxisId="left" allowDecimals={false} /><YAxis yAxisId="right" orientation="right" domain={[0, 100]} tickFormatter={(v) => `${v}%`} /><Tooltip content={<ChartTooltip financeiro={financeiro} />} /><Legend />{legend.opportunities && <Bar yAxisId="left" dataKey="opportunities" name="Oportunidades" fill="hsl(var(--chart-1))" radius={[4, 4, 0, 0]} />}{legend.converted && <Bar yAxisId="left" dataKey="converted_opportunities" name="Convertidas" fill="hsl(var(--chart-2))" radius={[4, 4, 0, 0]} />}{legend.conversion && <Line yAxisId="right" type="monotone" dataKey="conversion_rate" name="Conversão" stroke="hsl(var(--foreground))" strokeWidth={2.5} dot={{ r: 3 }} />}</ComposedChart></ResponsiveContainer></div></div>}
                        {financeiro && <div className="mt-6" data-testid="opf-revenue-chart"><p className="text-xs uppercase tracking-[0.1em] text-muted-foreground mb-2">Receita por intervalo</p><ResponsiveContainer width="100%" height={160}><AreaChart data={data?.series || []}><XAxis dataKey="label" tick={{ fontSize: 10 }} /><YAxis tickFormatter={(v) => `R$ ${(v / 100).toLocaleString("pt-BR")}`} /><Tooltip formatter={(v) => centsToBRL(v)} /><Area type="monotone" dataKey="revenue" name="Receita" stroke="hsl(var(--chart-4))" fill="hsl(var(--chart-4))" fillOpacity={0.18} /></AreaChart></ResponsiveContainer></div>}
                    </CardContent></Card>
                </TabsContent>
                <TabsContent value="mapa"><Card className="border border-border shadow-sm" data-testid="opf-heatmap-card"><CardContent className="p-4 md:p-6"><div className="flex items-center gap-2 mb-4"><Label>Métrica</Label><Select value={metric} onValueChange={setMetric}><SelectTrigger className="w-56" data-testid="opf-heatmap-metric"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="opportunities">Oportunidades</SelectItem><SelectItem value="converted_opportunities">Convertidas</SelectItem><SelectItem value="sales">Vendas</SelectItem><SelectItem value="conversion_rate">Conversão</SelectItem>{financeiro && <SelectItem value="revenue">Receita</SelectItem>}</SelectContent></Select></div><div className="overflow-x-auto"><div className="grid gap-1 min-w-[900px]" style={{ gridTemplateColumns: "70px repeat(24, 1fr)" }}><div />{Array.from({ length: 24 }).map((_, h) => <div key={h} className="text-[10px] text-center text-muted-foreground">{h}h</div>)}{[2,3,4,5,6,7,1].map((d) => <React.Fragment key={d}><div className="text-xs font-medium py-2">{WEEKDAYS[d]}</div>{Array.from({ length: 24 }).map((_, h) => { const c = (data?.heatmap || []).find((x) => x.weekday === d && x.hour === h) || {}; const value = Number(c[metric] || 0); const intensity = Math.min(1, value / maxHeat); return <div key={`${d}-${h}`} title={`${WEEKDAYS[d]} ${h}h: ${metric === "revenue" ? centsToBRL(value) : metric === "conversion_rate" ? pct(value) : number(value)}`} className="h-8 rounded-[4px] border border-border/50" style={{ background: `rgba(0, 106, 79, ${0.08 + intensity * 0.72})` }} data-testid={`opf-heatmap-${d}-${h}`} />; })}</React.Fragment>)}</div></div></CardContent></Card></TabsContent>
                <TabsContent value="tabela"><Card className="border border-border shadow-sm" data-testid="opf-table-card"><CardContent className="p-0"><div className="overflow-x-auto"><table className="w-full text-sm" data-testid="opf-table"><thead><tr className="border-b bg-muted/40">{["Intervalo", "Oportunidades", "Convertidas", "Vendas", "Conversão", ...(financeiro ? ["Receita", "Ticket médio"] : [])].map((h) => <th key={h} className="px-4 py-3 text-left text-xs uppercase tracking-[0.08em] text-muted-foreground whitespace-nowrap"><button onClick={() => setSort({ key: h === "Intervalo" ? "bucket_start" : h === "Convertidas" ? "converted_opportunities" : h === "Conversão" ? "conversion_rate" : h === "Receita" ? "revenue" : h === "Ticket médio" ? "average_ticket" : h === "Vendas" ? "sales" : "opportunities", dir: sort.dir === "asc" ? "desc" : "asc" })} data-testid={`opf-sort-${h.toLowerCase().replace(/\s+/g, "-")}`}>{h}</button></th>)}</tr></thead><tbody>{loading ? <tr><td colSpan={8} className="p-6"><Skeleton className="h-8 w-full" /></td></tr> : sortedSeries.length === 0 ? <tr><td colSpan={8} className="p-8 text-center text-muted-foreground">Sem dados para o período.</td></tr> : sortedSeries.map((r) => <tr key={r.bucket_start} className="border-b hover:bg-muted/30"><td className="px-4 py-3 font-medium">{r.label}</td><td className="px-4 py-3">{number(r.opportunities)}</td><td className="px-4 py-3">{number(r.converted_opportunities)}</td><td className="px-4 py-3">{number(r.sales)}</td><td className="px-4 py-3 font-semibold">{pct(r.conversion_rate)}</td>{financeiro && <td className="px-4 py-3 font-mono">{centsToBRL(r.revenue || 0)}</td>}{financeiro && <td className="px-4 py-3 font-mono">{centsToBRL(r.average_ticket || 0)}</td>}</tr>)}</tbody></table></div></CardContent></Card></TabsContent>
            </Tabs>
        </div>
    );
}