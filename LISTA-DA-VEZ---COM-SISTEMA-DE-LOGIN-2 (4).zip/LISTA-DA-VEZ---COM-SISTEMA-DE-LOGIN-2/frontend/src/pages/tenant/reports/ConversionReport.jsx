import React, { useState, useEffect, useCallback } from "react";
import { useParams, Link } from "react-router-dom";
import {
    ResponsiveContainer,
    BarChart,
    Bar,
    XAxis,
    YAxis,
    Tooltip,
    CartesianGrid,
    Cell,
    LabelList,
} from "recharts";
import api from "@/lib/api";
import { centsToBRL } from "@/lib/money";
import { PageHeader } from "@/components/Common";
import { ReportFilters } from "@/components/ReportFilters";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, RefreshCw } from "lucide-react";
import { toast } from "sonner";
import { AsyncExportButton } from "@/components/AsyncExportButton";

const COLORS_SELLER = [
    "hsl(var(--chart-1))",
    "hsl(var(--chart-2))",
    "hsl(var(--chart-4))",
    "hsl(var(--chart-3))",
    "hsl(var(--chart-5))",
    "hsl(var(--foreground))",
];
const COLORS_STORE = [
    "hsl(var(--chart-4))",
    "hsl(var(--chart-1))",
    "hsl(var(--chart-3))",
    "hsl(var(--chart-2))",
    "hsl(var(--chart-5))",
];

function CustomTooltipSeller({ active, payload, label }) {
    if (!active || !payload?.length) return null;
    const d = payload[0]?.payload;
    return (
        <div className="bg-card border border-border/60 rounded-md shadow-xs p-3 text-sm">
            <p className="font-semibold mb-1">{label}</p>
            <p className="text-muted-foreground">Atendimentos: <span className="text-foreground font-medium">{d?.atendimentos}</span></p>
            <p className="text-muted-foreground">Vendas: <span className="text-foreground font-medium">{d?.vendas}</span></p>
            <p className="text-muted-foreground">Conversão: <span className="font-bold text-foreground">{d?.conversao_pct}%</span></p>
            <p className="text-muted-foreground">Ticket médio: <span className="text-foreground">{centsToBRL(d?.ticket_medio_cents)}</span></p>
        </div>
    );
}

function CustomTooltipStore({ active, payload, label }) {
    if (!active || !payload?.length) return null;
    const d = payload[0]?.payload;
    return (
        <div className="bg-card border border-border/60 rounded-md shadow-xs p-3 text-sm">
            <p className="font-semibold mb-1">{label}</p>
            <p className="text-muted-foreground">Atendimentos: <span className="text-foreground font-medium">{d?.atendimentos}</span></p>
            <p className="text-muted-foreground">Vendas: <span className="text-foreground font-medium">{d?.vendas}</span></p>
            <p className="text-muted-foreground">Conversão: <span className="font-bold text-foreground">{d?.conversao_pct}%</span></p>
        </div>
    );
}

export default function ConversionReport() {
    const { tenantSlug } = useParams();
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [filters, setFilters] = useState({});

    const load = useCallback(async () => {
        setLoading(true);
        try {
            const params = new URLSearchParams();
            if (filters.date_start) params.set("date_start", filters.date_start);
            if (filters.date_end) params.set("date_end", filters.date_end);
            if (filters.store_id) params.set("store_id", filters.store_id);
            const { data: res } = await api.get(`/tenants/${tenantSlug}/reports/conversion?${params}`);
            setData(res);
        } catch {
            toast.error("Erro ao carregar relatório de conversão.");
        } finally {
            setLoading(false);
        }
    }, [tenantSlug, filters]);

    useEffect(() => { load(); }, [load]);

    const handleExport = async () => { /* substituído pelo AsyncExportButton */ };

    const total = data?.total || {};
    const bySeller = data?.by_seller || [];
    const byStore = data?.by_store || [];

    const sellerChartData = bySeller.map((s) => ({
        ...s,
        name: s.seller_name?.split(" ")[0] || "—",
        fullName: s.seller_name,
    }));

    const storeChartData = byStore.map((s) => ({
        ...s,
        name: s.store_name || "—",
    }));

    return (
        <div data-testid="report-conversion">
            <div className="flex items-center gap-3 mb-6">
                <Link to={`/${tenantSlug}/reports`} className="text-muted-foreground hover:text-foreground transition-colors">
                    <ArrowLeft size={16} strokeWidth={1.5} />
                </Link>
                <PageHeader eyebrow="Relatório" title="Taxa de Conversão" />
            </div>

            <ReportFilters filters={filters} onChange={setFilters} />

            {/* KPIs gerais */}
            <div className="metric-grid mb-8">
                {[
                    { label: "Atendimentos", value: total.atendimentos ?? "—", testId: "kpi-total" },
                    { label: "Vendas", value: total.vendas ?? "—", testId: "kpi-sales" },
                    { label: "Conversão geral", value: total.atendimentos ? `${total.conversao_pct}%` : "—", testId: "kpi-conv" },
                    { label: "Total vendido", value: total.total_vendido_cents != null ? centsToBRL(total.total_vendido_cents) : "—", testId: "kpi-sold" },
                ].map((k) => (
                    <div key={k.label} className="metric-card-wrap border border-border/60 rounded-md p-4 bg-card">
                        <p className="metric-label text-xs uppercase tracking-[0.1em] text-muted-foreground mb-1">{k.label}</p>
                        <span className="metric-num font-semibold" data-testid={k.testId}>{k.value}</span>
                    </div>
                ))}
            </div>

            <div className="flex justify-end mb-4">
                <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={load}>
                        <RefreshCw size={13} strokeWidth={1.5} className="mr-1.5" /> Atualizar
                    </Button>
                    <AsyncExportButton
                        tenantSlug={tenantSlug}
                        reportType="conversion"
                        filters={filters}
                        data-testid="btn-export-csv"
                    />
                </div>
            </div>

            {/* ── Gráfico 1: Conversão por Vendedor ── */}
            <Card className="border border-border shadow-sm mb-6" data-testid="chart-by-seller">
                <CardContent className="p-6">
                    <p className="text-xs uppercase tracking-[0.12em] text-muted-foreground mb-1">Conversão por Vendedor (%)</p>
                    <p className="text-xs text-muted-foreground mb-5">Percentual de atendimentos convertidos em venda por cada vendedor no período.</p>
                    {loading ? (
                        <Skeleton className="h-64 w-full" />
                    ) : sellerChartData.length === 0 ? (
                        <p className="text-center text-sm text-muted-foreground py-12">Sem dados para o período selecionado.</p>
                    ) : (
                        <ResponsiveContainer width="100%" height={280}>
                            <BarChart data={sellerChartData} margin={{ top: 16, right: 16, bottom: 8, left: 0 }}>
                                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                                <XAxis dataKey="name" tick={{ fontSize: 12, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} />
                                <YAxis domain={[0, 100]} unit="%" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} width={36} />
                                <Tooltip content={<CustomTooltipSeller />} cursor={{ fill: "hsl(var(--muted))" }} />
                                <Bar dataKey="conversao_pct" radius={[3, 3, 0, 0]} maxBarSize={52}>
                                    <LabelList dataKey="conversao_pct" position="top" formatter={(v) => `${v}%`} style={{ fontSize: 11, fontWeight: 600 }} />
                                    {sellerChartData.map((_, i) => (
                                        <Cell key={i} fill={COLORS_SELLER[i % COLORS_SELLER.length]} />
                                    ))}
                                </Bar>
                            </BarChart>
                        </ResponsiveContainer>
                    )}
                </CardContent>
            </Card>

            {/* ── Gráfico 2: Conversão por Unidade ── */}
            {byStore.length > 0 && (
                <Card className="border border-border shadow-sm mb-6" data-testid="chart-by-store">
                    <CardContent className="p-6">
                        <p className="text-xs uppercase tracking-[0.12em] text-muted-foreground mb-1">Conversão Geral por Unidade (%)</p>
                        <p className="text-xs text-muted-foreground mb-5">Comparativo de conversão entre unidades no período selecionado.</p>
                        <ResponsiveContainer width="100%" height={220}>
                            <BarChart data={storeChartData} margin={{ top: 16, right: 16, bottom: 8, left: 0 }}>
                                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                                <XAxis dataKey="name" tick={{ fontSize: 12, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} />
                                <YAxis domain={[0, 100]} unit="%" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} width={36} />
                                <Tooltip content={<CustomTooltipStore />} cursor={{ fill: "hsl(var(--muted))" }} />
                                <Bar dataKey="conversao_pct" radius={[3, 3, 0, 0]} maxBarSize={60}>
                                    <LabelList dataKey="conversao_pct" position="top" formatter={(v) => `${v}%`} style={{ fontSize: 11, fontWeight: 600 }} />
                                    {storeChartData.map((_, i) => (
                                        <Cell key={i} fill={COLORS_STORE[i % COLORS_STORE.length]} />
                                    ))}
                                </Bar>
                            </BarChart>
                        </ResponsiveContainer>
                    </CardContent>
                </Card>
            )}

            {/* Tabela de detalhes por vendedor */}
            <Card className="border border-border shadow-sm">
                <CardContent className="p-6">
                    <p className="text-xs uppercase tracking-[0.12em] text-muted-foreground mb-4">Detalhes por Vendedor</p>
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm" data-testid="table-by-seller">
                            <thead>
                                <tr className="border-b border-border">
                                    {["Vendedor", "Atendimentos", "Vendas", "Conversão", "Total Vendido", "Ticket Médio"].map((h) => (
                                        <th key={h} className="text-left pb-3 pr-6 text-xs font-medium uppercase tracking-[0.08em] text-muted-foreground whitespace-nowrap">{h}</th>
                                    ))}
                                </tr>
                            </thead>
                            <tbody>
                                {loading ? (
                                    Array.from({ length: 4 }).map((_, i) => (
                                        <tr key={i} className="border-b border-border">
                                            {Array.from({ length: 6 }).map((_, j) => (
                                                <td key={j} className="py-3 pr-6"><Skeleton className="h-4 w-20" /></td>
                                            ))}
                                        </tr>
                                    ))
                                ) : bySeller.length === 0 ? (
                                    <tr>
                                        <td colSpan={6} className="text-center py-8 text-muted-foreground">Sem dados.</td>
                                    </tr>
                                ) : (
                                    bySeller.map((s, i) => (
                                        <tr key={s.seller_id || i} className="border-b border-border hover:bg-muted/30 transition-colors">
                                            <td className="py-3 pr-6 font-medium">{s.seller_name}</td>
                                            <td className="py-3 pr-6">{s.atendimentos}</td>
                                            <td className="py-3 pr-6">{s.vendas}</td>
                                            <td className="py-3 pr-6 font-bold">{s.conversao_pct}%</td>
                                            <td className="py-3 pr-6 font-mono">{centsToBRL(s.total_cents)}</td>
                                            <td className="py-3 pr-6 font-mono">{centsToBRL(s.ticket_medio_cents)}</td>
                                        </tr>
                                    ))
                                )}
                            </tbody>
                        </table>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}
