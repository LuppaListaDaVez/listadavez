import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import api, { extractError } from "@/lib/api";
import { centsToBRL } from "@/lib/money";
import { PageHeader, EmptyState, SellerAvatar } from "@/components/Common";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "sonner";
import { fmtDateTime } from "@/lib/i18n";

const PAYMENT_LABEL = {
    CASH: "Dinheiro", DEBIT: "Débito", CREDIT: "Crédito", PIX: "PIX",
    TRANSFER: "Transferência", VOUCHER: "Vale", BOLETO: "Boleto",
    STORE_CREDIT: "Crédito loja", OTHER: "Outro",
};

export default function SalesList() {
    const { tenantSlug } = useParams();
    const [items, setItems] = useState([]);
    const [loading, setLoading] = useState(true);
    const [detail, setDetail] = useState(null);

    const load = async () => {
        setLoading(true);
        try {
            const { data } = await api.get(`/tenants/${tenantSlug}/sales`);
            // P0: resposta paginada {items: [...], pagination: {...}}
            setItems(Array.isArray(data) ? data : (data.items || []));
        }
        catch (e) { toast.error(extractError(e, "Erro ao carregar vendas")); setItems([]); }
        setLoading(false);
    };
    useEffect(() => { load(); /* eslint-disable-next-line */ }, [tenantSlug]);

    const openDetail = async (s) => {
        try { const { data } = await api.get(`/tenants/${tenantSlug}/sales/${s.id}`); setDetail(data); }
        catch (e) { toast.error(extractError(e, "Erro ao carregar venda")); }
    };

    return (
        <div data-testid="sales-page">
            <PageHeader eyebrow="Comercial" title="Vendas" description="Registro detalhado de vendas realizadas nos atendimentos." />

            {loading ? <p className="text-sm text-muted-foreground">Carregando…</p> :
             items.length === 0 ? <EmptyState title="Sem vendas" description="As vendas detalhadas aparecerão aqui." /> :
             <Card className="border border-border shadow-sm"><CardContent className="p-0">
                <Table>
                    <TableHeader><TableRow>
                        <TableHead>Vendedor</TableHead>
                        <TableHead>Unidade</TableHead>
                        <TableHead>Itens</TableHead>
                        <TableHead>Bruto</TableHead>
                        <TableHead>Desconto</TableHead>
                        <TableHead>Líquido</TableHead>
                        <TableHead>Data</TableHead>
                    </TableRow></TableHeader>
                    <TableBody>
                        {items.map((s) => (
                            <TableRow key={s.id} className="cursor-pointer" onClick={() => openDetail(s)} data-testid={`sale-row-${s.id}`}>
                                <TableCell className="font-medium">
                                    <SellerAvatar
                                        name={s.seller_name || "—"}
                                        src={s.seller_avatar_url}
                                        size={26}
                                        showName
                                    />
                                </TableCell>
                                <TableCell className="text-sm text-muted-foreground">{s.store_name || "—"}</TableCell>
                                <TableCell>{s.item_count ?? 0}</TableCell>
                                <TableCell className="font-mono text-sm">{centsToBRL(s.gross_amount_cents)}</TableCell>
                                <TableCell className="font-mono text-sm">{centsToBRL(s.discount_amount_cents)}</TableCell>
                                <TableCell className="font-mono text-sm font-semibold" data-testid={`sale-net-${s.id}`}>{centsToBRL(s.net_amount_cents)}</TableCell>
                                <TableCell className="text-xs font-mono text-muted-foreground">{fmtDateTime(s.created_at)}</TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
             </CardContent></Card>}

            <Dialog open={!!detail} onOpenChange={(o) => !o && setDetail(null)}>
                <DialogContent className="max-w-lg">
                    <DialogHeader><DialogTitle>Detalhe da venda</DialogTitle>
                        <DialogDescription>Itens, valores e formas de pagamento da venda.</DialogDescription>
                    </DialogHeader>
                    {detail && (
                        <div className="space-y-4" data-testid="sale-detail">
                            <div className="text-sm grid grid-cols-2 gap-2">
                                <div><span className="text-muted-foreground">Vendedor: </span>{detail.seller_name || "—"}</div>
                                <div><span className="text-muted-foreground">Unidade: </span>{detail.store_name || "—"}</div>
                            </div>
                            <div>
                                <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground mb-2">Itens</p>
                                <div className="space-y-1">
                                    {(detail.items || []).length === 0 ? <p className="text-sm text-muted-foreground">Venda sem itens.</p> :
                                     detail.items.map((it) => (
                                        <div key={it.id} className="flex justify-between text-sm border-b border-border py-1">
                                            <span>{it.quantity}× {it.name}{it.sku ? ` (${it.sku})` : ""}</span>
                                            <span className="font-mono">{centsToBRL(it.line_total_cents)}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                            <div className="text-sm space-y-1">
                                <div className="flex justify-between"><span className="text-muted-foreground">Bruto</span><span className="font-mono">{centsToBRL(detail.gross_amount_cents)}</span></div>
                                <div className="flex justify-between"><span className="text-muted-foreground">Desconto</span><span className="font-mono">{centsToBRL(detail.discount_amount_cents)}</span></div>
                                <div className="flex justify-between font-semibold"><span>Líquido</span><span className="font-mono">{centsToBRL(detail.net_amount_cents)}</span></div>
                            </div>
                            {(detail.payment_methods || []).length > 0 && (
                                <div>
                                    <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground mb-2">Pagamentos</p>
                                    <div className="flex flex-wrap gap-2">
                                        {detail.payment_methods.map((p, i) => (
                                            <Badge key={i} variant="secondary">{PAYMENT_LABEL[p.method] || p.method}: {centsToBRL(p.amount_cents)}</Badge>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                    )}
                </DialogContent>
            </Dialog>
        </div>
    );
}
