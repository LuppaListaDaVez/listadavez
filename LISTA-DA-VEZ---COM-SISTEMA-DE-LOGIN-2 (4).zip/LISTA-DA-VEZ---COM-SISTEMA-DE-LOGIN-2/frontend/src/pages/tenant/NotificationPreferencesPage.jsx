import React, { useEffect, useState, useCallback } from "react";
import { useParams } from "react-router-dom";
import { Bell, Mail, Smartphone, Zap, Moon, Save, Check } from "lucide-react";
import api from "@/lib/api";
import { PageHeader } from "@/components/Common";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { usePermissions } from "@/hooks/usePermissions";

function Toggle({ checked, onChange, testId }) {
    return (
        <button
            type="button"
            role="switch"
            aria-checked={checked}
            onClick={() => onChange(!checked)}
            data-testid={testId}
            className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors focus:outline-none ${
                checked ? "bg-foreground" : "bg-muted-foreground/30"
            }`}
        >
            <span
                className={`inline-block h-3.5 w-3.5 transform rounded-full bg-background shadow transition-transform ${
                    checked ? "translate-x-5" : "translate-x-1"
                }`}
            />
        </button>
    );
}

function PrefRow({ icon: Icon, label, description, checked, onChange, testId }) {
    return (
        <div className="flex items-center justify-between py-3 border-b border-border last:border-0">
            <div className="flex items-center gap-3 min-w-0 pr-4">
                <div className="w-8 h-8 rounded-sm bg-muted flex items-center justify-center flex-shrink-0">
                    <Icon size={15} strokeWidth={1.5} className="text-muted-foreground" />
                </div>
                <div className="min-w-0">
                    <p className="text-sm font-medium">{label}</p>
                    {description && <p className="text-xs text-muted-foreground mt-0.5">{description}</p>}
                </div>
            </div>
            <Toggle checked={!!checked} onChange={onChange} testId={testId} />
        </div>
    );
}

export default function NotificationPreferencesPage() {
    const { tenantSlug } = useParams();
    const { hasFeature } = usePermissions();
    const featureActive = hasFeature("preferencias_notificacao");

    const [prefs, setPrefs] = useState(null);
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [saved, setSaved] = useState(false);

    const load = useCallback(async () => {
        setLoading(true);
        try {
            const res = await api.get(`/tenants/${tenantSlug}/notifications/preferences`);
            setPrefs(res.data);
        } catch {
            toast.error("Erro ao carregar preferências");
        } finally {
            setLoading(false);
        }
    }, [tenantSlug]);

    useEffect(() => { load(); }, [load]);

    const handleSave = async () => {
        if (!prefs) return;
        setSaving(true);
        try {
            const res = await api.put(`/tenants/${tenantSlug}/notifications/preferences`, prefs);
            setPrefs(res.data);
            setSaved(true);
            toast.success("Preferências salvas!");
            setTimeout(() => setSaved(false), 3000);
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Erro ao salvar");
        } finally {
            setSaving(false);
        }
    };

    const set = (key, val) => setPrefs(p => ({ ...p, [key]: val }));

    if (!featureActive) {
        return (
            <div data-testid="notification-prefs-page">
                <PageHeader eyebrow="Notificações" title="Preferências de Notificação" />
                <Card className="border border-border shadow-sm mt-6">
                    <CardContent className="p-10 text-center">
                        <Bell size={32} strokeWidth={1} className="mx-auto mb-3 text-muted-foreground" />
                        <p className="text-sm text-muted-foreground">Esta funcionalidade não está disponível no seu plano atual.</p>
                    </CardContent>
                </Card>
            </div>
        );
    }

    return (
        <div data-testid="notification-prefs-page">
            <div className="flex items-start justify-between mb-6">
                <PageHeader
                    eyebrow="Notificações"
                    title="Preferências de Notificação"
                    description="Controle como e quando você recebe notificações."
                />
                <Button
                    size="sm"
                    onClick={handleSave}
                    disabled={saving || !prefs}
                    className="mt-1"
                    data-testid="save-prefs-btn"
                >
                    {saved ? (
                        <><Check size={14} className="mr-2" /> Salvo</>
                    ) : saving ? (
                        "Salvando..."
                    ) : (
                        <><Save size={14} className="mr-2" /> Salvar</>
                    )}
                </Button>
            </div>

            {loading || !prefs ? (
                <div className="space-y-4">
                    <Skeleton className="h-48 w-full" />
                    <Skeleton className="h-48 w-full" />
                </div>
            ) : (
                <div className="space-y-6 max-w-2xl">
                    {/* Canais */}
                    <Card className="border border-border shadow-sm">
                        <CardContent className="p-5">
                            <p className="text-xs uppercase tracking-[0.12em] text-muted-foreground mb-1">Canais</p>
                            <p className="text-sm text-muted-foreground mb-4">Escolha por onde deseja receber notificações.</p>
                            <PrefRow
                                icon={Bell}
                                label="Notificações no app"
                                description="Alertas e atualizações dentro da plataforma."
                                checked={prefs.in_app_enabled}
                                onChange={v => set("in_app_enabled", v)}
                                testId="pref-toggle-inapp"
                            />
                            <PrefRow
                                icon={Zap}
                                label="Notificações em tempo real"
                                description="Alertas instantâneos via WebSocket quando disponível."
                                checked={prefs.realtime_enabled}
                                onChange={v => set("realtime_enabled", v)}
                                testId="pref-toggle-realtime"
                            />
                            <PrefRow
                                icon={Mail}
                                label="E-mail"
                                description="Resumos e alertas críticos por e-mail."
                                checked={prefs.email_enabled}
                                onChange={v => set("email_enabled", v)}
                                testId="pref-toggle-email"
                            />
                            <PrefRow
                                icon={Smartphone}
                                label="Push / Mobile"
                                description="Notificações push no seu dispositivo móvel."
                                checked={prefs.push_enabled}
                                onChange={v => set("push_enabled", v)}
                                testId="pref-toggle-push"
                            />
                        </CardContent>
                    </Card>

                    {/* Conteúdo */}
                    <Card className="border border-border shadow-sm">
                        <CardContent className="p-5">
                            <p className="text-xs uppercase tracking-[0.12em] text-muted-foreground mb-1">Conteúdo</p>
                            <p className="text-sm text-muted-foreground mb-4">O que você deseja acompanhar.</p>
                            <PrefRow
                                icon={Zap}
                                label="Eventos motivacionais"
                                description="Conquistas, metas batidas e destaques da equipe."
                                checked={prefs.motivation_events_enabled}
                                onChange={v => set("motivation_events_enabled", v)}
                                testId="pref-toggle-motivation"
                            />
                        </CardContent>
                    </Card>

                    {/* Horário silencioso */}
                    <Card className="border border-border shadow-sm">
                        <CardContent className="p-5">
                            <p className="text-xs uppercase tracking-[0.12em] text-muted-foreground mb-1">Horário silencioso</p>
                            <p className="text-sm text-muted-foreground mb-4">Pausar notificações em horários específicos.</p>
                            <PrefRow
                                icon={Moon}
                                label="Ativar horário silencioso"
                                description="Notificações serão pausadas no período configurado."
                                checked={prefs.quiet_hours_enabled}
                                onChange={v => set("quiet_hours_enabled", v)}
                                testId="pref-toggle-quiethours"
                            />
                            {prefs.quiet_hours_enabled && (
                                <div className="mt-4 grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="text-xs text-muted-foreground mb-1.5 block">Início</label>
                                        <input
                                            type="time"
                                            className="w-full border border-border rounded-sm px-3 py-2 text-sm bg-background"
                                            value={prefs.quiet_hours_start || "22:00"}
                                            onChange={e => set("quiet_hours_start", e.target.value)}
                                            data-testid="quiet-hours-start"
                                        />
                                    </div>
                                    <div>
                                        <label className="text-xs text-muted-foreground mb-1.5 block">Fim</label>
                                        <input
                                            type="time"
                                            className="w-full border border-border rounded-sm px-3 py-2 text-sm bg-background"
                                            value={prefs.quiet_hours_end || "08:00"}
                                            onChange={e => set("quiet_hours_end", e.target.value)}
                                            data-testid="quiet-hours-end"
                                        />
                                    </div>
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </div>
            )}
        </div>
    );
}
