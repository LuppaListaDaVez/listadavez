import React, { useEffect, useState, useCallback } from "react";
import { useParams } from "react-router-dom";
import { Play, Eye, RefreshCw, Lock } from "lucide-react";
import api from "@/lib/api";
import { PageHeader } from "@/components/Common";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { usePermissions } from "@/hooks/usePermissions";
import {
    Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";

const ACTION_PT = { KEEP: "Manter", ANONYMIZE: "Anonimizar", DELETE: "Excluir", ARCHIVE: "Arquivar" };
const STATUS_COLORS = { PENDING: "bg-gray-100 text-gray-600", RUNNING: "bg-luppa-purple/15 text-luppa-purple", COMPLETED: "bg-luppa-green/15 text-luppa-green", FAILED: "bg-luppa-error/15 text-luppa-error", CANCELLED: "bg-gray-100 text-gray-600" };
const STATUS_PT = { PENDING: "Pendente", RUNNING: "Rodando", COMPLETED: "Concluído", FAILED: "Falhou", CANCELLED: "Cancelado" };
const CAT_PT = { CUSTOMER_VISITS: "Visitas", ATTENDANCES: "Atendimentos", SALES: "Vendas", SALE_ITEMS: "Itens", FEEDBACKS: "Feedbacks", NOTIFICATIONS: "Notificações", MOTIVATION_EVENTS: "Eventos Motivacionais", AUDIT_LOGS: "Audit Logs", SECURITY_EVENTS: "Segurança", API_REQUEST_LOGS: "Logs API", REPORT_EXPORTS: "Exportações", BACKUPS: "Backups" };

export default function RetentionPage() {
    const { tenantSlug } = useParams();
    const { hasFeature, hasPermission } = usePermissions();
    const [policies, setPolicies] = useState([]);
    const [jobs, setJobs] = useState([]);
    const [loading, setLoading] = useState(true);
    const [preview, setPreview] = useState(null);
    const [previewOpen, setPreviewOpen] = useState(false);
    const [loadingPreview, setLoadingPreview] = useState(false);
    const [runningId, setRunningId] = useState(null);

    const canUpdate = hasPermission("retention.policies.update");
    const canRun = hasPermission("retention.jobs.run");
    const featureActive = hasFeature("retencao_dados");

    const load = useCallback(async () => {
        setLoading(true);
        try {
            const [pRes, jRes] = await Promise.allSettled([
                api.get(`/tenants/${tenantSlug}/retention/policies`),
                api.get(`/tenants/${tenantSlug}/retention/jobs`),
            ]);
            if (pRes.status === "fulfilled") setPolicies(pRes.value.data || []);
            if (jRes.status === "fulfilled") setJobs(jRes.value.data || []);
        } catch {
            toast.error("Erro ao carregar políticas.");
        } finally {
            setLoading(false);
        }
    }, [tenantSlug]);

    useEffect(() => { load(); }, [load]);

    const handlePreview = async (policyId) => {
        setLoadingPreview(true);
        try {
            const res = await api.post(`/tenants/${tenantSlug}/retention/policies/${policyId}/preview`);
            setPreview(res.data);
            setPreviewOpen(true);
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Erro ao gerar preview.");
        } finally {
            setLoadingPreview(false);
        }
    };

    const handleRun = async (policyId) => {
        setRunningId(policyId);
        try {
            const res = await api.post(`/tenants/${tenantSlug}/retention/policies/${policyId}/run`);
            toast.success(`Job concluído! ${res.data.records_affected ?? 0} registros processados.`);
            load();
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Erro ao executar job.");
        } finally {
            setRunningId(null);
        }
    };

    if (!featureActive) return (
        <div><PageHeader eyebrow="Governança" title="Retenção de Dados" />
            <Card className="mt-6 border"><CardContent className="p-10 text-center"><p className="text-sm text-muted-foreground">Módulo indisponível.</p></CardContent></Card>
        </div>
    );

    return (
        <div data-testid="retention-page">
            <PageHeader eyebrow="Governança" title="Retenção de Dados" description="Políticas de ciclo de vida dos dados por categoria." />

            <div className="mt-6 grid lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                    <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground mb-3">Políticas de Retenção</p>
                    <Card className="border border-border shadow-sm">
                        <CardContent className="p-0">
                            {loading ? (
                                <div className="p-5 space-y-3"><Skeleton className="h-14" /><Skeleton className="h-14" /><Skeleton className="h-14" /></div>
                            ) : policies.length === 0 ? (
                                <div className="p-8 text-center"><p className="text-sm text-muted-foreground">Nenhuma política encontrada.</p></div>
                            ) : policies.map(p => (
                                <div key={p.id} data-testid={`policy-${p.data_category}`} className="flex items-center justify-between py-3 px-4 border-b border-border last:border-0">
                                    <div>
                                        <p className="text-sm font-medium">{CAT_PT[p.data_category] || p.data_category}</p>
                                        <p className="text-xs text-muted-foreground">{p.retention_days} dias → {ACTION_PT[p.action_after_retention] || p.action_after_retention}</p>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <button
                                            onClick={() => handlePreview(p.id)}
                                            disabled={loadingPreview}
                                            className="text-xs text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1"
                                            data-testid={`preview-policy-${p.id}`}
                                        >
                                            <Eye size={12} />Preview
                                        </button>
                                        {canRun && (
                                            <button
                                                onClick={() => handleRun(p.id)}
                                                disabled={runningId === p.id}
                                                className="text-xs text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1"
                                                data-testid={`run-policy-${p.id}`}
                                            >
                                                <Play size={12} />{runningId === p.id ? "..." : "Executar"}
                                            </button>
                                        )}
                                    </div>
                                </div>
                            ))}
                        </CardContent>
                    </Card>
                </div>

                <div>
                    <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground mb-3">Últimos Jobs</p>
                    <Card className="border border-border shadow-sm">
                        <CardContent className="p-4">
                            {jobs.length === 0 ? (
                                <p className="text-xs text-muted-foreground text-center py-4">Nenhum job executado.</p>
                            ) : jobs.slice(0, 8).map(j => (
                                <div key={j.id} data-testid={`job-${j.id}`} className="py-2 border-b border-border last:border-0">
                                    <div className="flex justify-between items-center mb-0.5">
                                        <p className="text-xs font-medium">{CAT_PT[j.data_category] || j.data_category}</p>
                                        <span className={`text-xs px-1.5 py-0.5 rounded ${STATUS_COLORS[j.status] || "bg-gray-100"}`}>{STATUS_PT[j.status] || j.status}</span>
                                    </div>
                                    <p className="text-xs text-muted-foreground">{j.records_affected ?? 0} afetados · {j.created_at?.slice(0, 10)}</p>
                                </div>
                            ))}
                        </CardContent>
                    </Card>
                </div>
            </div>

            {/* Preview Modal */}
            <Dialog open={previewOpen} onOpenChange={setPreviewOpen}>
                <DialogContent>
                    <DialogHeader><DialogTitle>Preview da Política de Retenção</DialogTitle></DialogHeader>
                    {preview && (
                        <div className="space-y-3 py-2 text-sm">
                            <div className="grid grid-cols-2 gap-2">
                                <div><p className="text-xs text-muted-foreground">Categoria</p><p>{CAT_PT[preview.data_category] || preview.data_category}</p></div>
                                <div><p className="text-xs text-muted-foreground">Ação</p><p>{ACTION_PT[preview.action] || preview.action}</p></div>
                                <div><p className="text-xs text-muted-foreground">Data de corte</p><p>{preview.cutoff_date?.slice(0, 10)}</p></div>
                                <div><p className="text-xs text-muted-foreground">Registros estimados</p><p className="font-semibold text-luppa-warning">{preview.estimated_records_affected}</p></div>
                            </div>
                            <div className="bg-amber-50 border border-amber-200 rounded p-3">
                                <p className="text-xs text-amber-800">Esta é uma estimativa (dry-run). Nenhum dado foi alterado.</p>
                            </div>
                        </div>
                    )}
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setPreviewOpen(false)}>Fechar</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}
