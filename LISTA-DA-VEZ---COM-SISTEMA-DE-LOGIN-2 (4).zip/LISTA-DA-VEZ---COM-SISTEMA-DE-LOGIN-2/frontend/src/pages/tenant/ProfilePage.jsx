import React, { useState } from "react";
import { useParams } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { useTenant } from "@/context/TenantContext";
import { authApi } from "@/api/auth";
import { PageHeader } from "@/components/Common";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import { Eye, EyeOff, User, Mail, Shield, KeyRound, CheckCircle } from "lucide-react";

const ROLE_LABELS = {
    TENANT_ADMIN: "Administrador",
    REGIONAL_MANAGER: "Gerente Regional",
    STORE_MANAGER: "Gerente de Loja",
    SUPERVISOR: "Supervisor",
    SELLER: "Vendedor",
};

function StrengthBar({ password }) {
    const score = (() => {
        if (!password) return 0;
        let s = 0;
        if (password.length >= 8) s++;
        if (/[A-Z]/.test(password)) s++;
        if (/[0-9]/.test(password)) s++;
        if (/[^A-Za-z0-9]/.test(password)) s++;
        return s;
    })();
    const labels = ["", "Fraca", "Razoável", "Boa", "Forte"];
    const colors = ["", "bg-luppa-error", "bg-luppa-warning", "bg-luppa-purple", "bg-luppa-green"];
    if (!password) return null;
    return (
        <div className="space-y-1 mt-1">
            <div className="flex gap-1">
                {[1, 2, 3, 4].map((i) => (
                    <div key={i} className={`h-1 flex-1 rounded-full transition-all ${i <= score ? colors[score] : "bg-muted"}`} />
                ))}
            </div>
            <p className={`text-xs ${score < 2 ? "text-luppa-error" : score < 4 ? "text-luppa-warning" : "text-luppa-green"}`}>
                {labels[score]}
            </p>
        </div>
    );
}

export default function ProfilePage() {
    const { tenantSlug } = useParams();
    const { user } = useAuth();
    const { context } = useTenant();

    const [currentPwd, setCurrentPwd] = useState("");
    const [newPwd, setNewPwd] = useState("");
    const [confirmPwd, setConfirmPwd] = useState("");
    const [showCurrent, setShowCurrent] = useState(false);
    const [showNew, setShowNew] = useState(false);
    const [showConfirm, setShowConfirm] = useState(false);
    const [loading, setLoading] = useState(false);
    const [done, setDone] = useState(false);

    const mismatch = confirmPwd.length > 0 && newPwd !== confirmPwd;
    const canSubmit = currentPwd.length > 0 && newPwd.length >= 8 && newPwd === confirmPwd && !loading;

    const handleChangePassword = async (e) => {
        e.preventDefault();
        if (!canSubmit) return;
        setLoading(true);
        try {
            await authApi.changePassword(tenantSlug, currentPwd, newPwd);
            toast.success("Senha alterada com sucesso!");
            setCurrentPwd(""); setNewPwd(""); setConfirmPwd("");
            setDone(true);
            setTimeout(() => setDone(false), 4000);
        } catch (err) {
            const detail = err?.response?.data?.detail;
            toast.error(typeof detail === "string" ? detail : "Erro ao alterar a senha. Tente novamente.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="max-w-2xl space-y-8">
            <PageHeader
                eyebrow="Conta"
                title="Meu Perfil"
                description="Informações da sua conta e configurações de segurança."
            />

            {/* ── Informações da conta ── */}
            <Card className="border border-border shadow-sm">
                <CardContent className="p-6 space-y-5">
                    <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground">Informações da conta</p>
                    <div className="space-y-4">
                        <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-accent flex items-center justify-center flex-shrink-0">
                                <User size={15} className="text-foreground/70" />
                            </div>
                            <div className="min-w-0">
                                <p className="text-xs text-muted-foreground">Nome</p>
                                <p className="text-sm font-medium truncate" data-testid="profile-name">
                                    {user?.name || "—"}
                                </p>
                            </div>
                        </div>
                        <Separator />
                        <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-accent flex items-center justify-center flex-shrink-0">
                                <Mail size={15} className="text-foreground/70" />
                            </div>
                            <div className="min-w-0">
                                <p className="text-xs text-muted-foreground">E-mail</p>
                                <p className="text-sm font-medium truncate" data-testid="profile-email">
                                    {user?.email || "—"}
                                </p>
                            </div>
                        </div>
                        <Separator />
                        <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-accent flex items-center justify-center flex-shrink-0">
                                <Shield size={15} className="text-foreground/70" />
                            </div>
                            <div>
                                <p className="text-xs text-muted-foreground">Perfil de acesso</p>
                                <Badge variant="secondary" className="mt-1 text-xs" data-testid="profile-role">
                                    {ROLE_LABELS[context?.user_role] || context?.user_role || "—"}
                                </Badge>
                            </div>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* ── Alterar senha ── */}
            <Card className="border border-border shadow-sm">
                <CardContent className="p-6">
                    <div className="flex items-center gap-2 mb-5">
                        <KeyRound size={15} className="text-muted-foreground" />
                        <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground">Alterar senha</p>
                    </div>

                    {done && (
                        <div className="flex items-center gap-2 text-sm text-luppa-green bg-luppa-green/10 border border-luppa-green/25 rounded-md p-3 mb-5" data-testid="change-password-success">
                            <CheckCircle size={15} />
                            Senha alterada com sucesso!
                        </div>
                    )}

                    <form onSubmit={handleChangePassword} className="space-y-4" data-testid="change-password-form">
                        {/* Senha atual */}
                        <div className="space-y-1.5">
                            <Label htmlFor="current-pwd">Senha atual</Label>
                            <div className="relative">
                                <Input
                                    id="current-pwd"
                                    type={showCurrent ? "text" : "password"}
                                    className="pr-10"
                                    placeholder="Digite sua senha atual"
                                    value={currentPwd}
                                    onChange={(e) => setCurrentPwd(e.target.value)}
                                    data-testid="change-password-current"
                                    autoComplete="current-password"
                                />
                                <button
                                    type="button"
                                    tabIndex={-1}
                                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                                    onClick={() => setShowCurrent((v) => !v)}
                                >
                                    {showCurrent ? <EyeOff size={15} /> : <Eye size={15} />}
                                </button>
                            </div>
                        </div>

                        {/* Nova senha */}
                        <div className="space-y-1.5">
                            <Label htmlFor="new-pwd">Nova senha</Label>
                            <div className="relative">
                                <Input
                                    id="new-pwd"
                                    type={showNew ? "text" : "password"}
                                    className="pr-10"
                                    placeholder="Mínimo 8 caracteres"
                                    value={newPwd}
                                    onChange={(e) => setNewPwd(e.target.value)}
                                    data-testid="change-password-new"
                                    autoComplete="new-password"
                                />
                                <button
                                    type="button"
                                    tabIndex={-1}
                                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                                    onClick={() => setShowNew((v) => !v)}
                                >
                                    {showNew ? <EyeOff size={15} /> : <Eye size={15} />}
                                </button>
                            </div>
                            <StrengthBar password={newPwd} />
                        </div>

                        {/* Confirmar nova senha */}
                        <div className="space-y-1.5">
                            <Label htmlFor="confirm-pwd">Confirmar nova senha</Label>
                            <div className="relative">
                                <Input
                                    id="confirm-pwd"
                                    type={showConfirm ? "text" : "password"}
                                    className="pr-10"
                                    placeholder="Repita a nova senha"
                                    value={confirmPwd}
                                    onChange={(e) => setConfirmPwd(e.target.value)}
                                    data-testid="change-password-confirm"
                                    autoComplete="new-password"
                                />
                                <button
                                    type="button"
                                    tabIndex={-1}
                                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                                    onClick={() => setShowConfirm((v) => !v)}
                                >
                                    {showConfirm ? <EyeOff size={15} /> : <Eye size={15} />}
                                </button>
                            </div>
                            {mismatch && (
                                <p className="text-xs text-luppa-error" data-testid="change-password-mismatch">
                                    As senhas não coincidem.
                                </p>
                            )}
                        </div>

                        <div className="pt-2 flex justify-end">
                            <Button
                                type="submit"
                                disabled={!canSubmit}
                                data-testid="change-password-submit"
                            >
                                {loading ? "Salvando…" : "Alterar senha"}
                            </Button>
                        </div>
                    </form>
                </CardContent>
            </Card>
        </div>
    );
}
