import { useState, useCallback } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Bell, CheckCheck } from "lucide-react";
import { toast } from "sonner";
import { extractError } from "@/lib/api";
import { usePermissions } from "@/hooks/usePermissions";
import { Button } from "@/components/ui/button";
import { useNotifications, NOTIF_TYPE_CONFIG } from "@/context/NotificationContext";
import { fmtDate } from "@/lib/i18n";

function timeAgo(dateStr) {
    const diff = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return "agora mesmo";
    if (mins < 60) return `há ${mins} min`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `há ${hours}h`;
    const days = Math.floor(hours / 24);
    if (days < 7) return `há ${days}d`;
    return fmtDate(dateStr);
}

export default function NotificationsPage() {
    const { tenantSlug } = useParams();
    const nav = useNavigate();
    const { hasFeature } = usePermissions();
    const { notifications, unread_count, loading, markAsRead, markAllRead } = useNotifications();

    const [markingAll, setMarkingAll] = useState(false);
    const [unreadOnly, setUnreadOnly] = useState(false);

    const handleMarkAll = async () => {
        setMarkingAll(true);
        try {
            await markAllRead();
            toast.success("Todas as notificações marcadas como lidas.");
        } catch (e) {
            toast.error(extractError(e));
        } finally {
            setMarkingAll(false);
        }
    };

    const handleNotifClick = useCallback((notif) => {
        if (!notif.is_read) markAsRead(notif.id);
        if (notif.entity_type === "feedback" && notif.entity_id) {
            nav(`/${tenantSlug}/feedbacks/${notif.entity_id}`);
        } else if (notif.entity_type === "goal" && notif.entity_id) {
            nav(`/${tenantSlug}/goals/${notif.entity_id}`);
        }
    }, [markAsRead, nav, tenantSlug]);

    if (!hasFeature("notificacoes")) {
        return (
            <div className="text-center py-20 text-muted-foreground">
                <p className="text-sm">Recurso de Notificações não está ativado neste plano.</p>
            </div>
        );
    }

    const unreadCount = notifications.filter(n => !n.is_read).length;
    const filtered = unreadOnly ? notifications.filter(n => !n.is_read) : notifications;

    return (
        <div className="max-w-2xl space-y-6" data-testid="notifications-page">
            {/* Header */}
            <div className="flex items-start justify-between">
                <div>
                    <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">Central</p>
                    <h1 className="text-2xl font-semibold mt-1 flex items-center gap-2">
                        Notificações
                        {unreadCount > 0 && (
                            <span className="inline-flex items-center justify-center h-5 min-w-5 px-1.5 bg-luppa-error text-white text-[10px] font-bold rounded-full" data-testid="notif-unread-badge">
                                {unreadCount}
                            </span>
                        )}
                    </h1>
                </div>
                <div className="flex items-center gap-2">
                    <button
                        onClick={() => setUnreadOnly(v => !v)}
                        className={`text-xs px-3 py-1.5 rounded border transition-colors ${unreadOnly ? "bg-foreground text-background border-foreground" : "border-border hover:bg-muted"}`}
                        data-testid="toggle-unread-only"
                    >
                        {unreadOnly ? "Mostrar todas" : "Só não lidas"}
                    </button>
                    {unreadCount > 0 && (
                        <Button size="sm" variant="outline" onClick={handleMarkAll} disabled={markingAll} data-testid="btn-mark-all-read">
                            <CheckCheck size={14} className="mr-1.5" />
                            {markingAll ? "Marcando…" : "Marcar todas"}
                        </Button>
                    )}
                </div>
            </div>

            {/* Lista */}
            {loading ? (
                <p className="text-sm text-muted-foreground py-10 text-center">Carregando…</p>
            ) : filtered.length === 0 ? (
                <div className="bg-card border border-border/60 rounded-md p-12 text-center" data-testid="notifications-empty">
                    <Bell size={36} className="mx-auto mb-3 text-muted-foreground/30" />
                    <p className="text-sm text-muted-foreground">
                        {unreadOnly ? "Nenhuma notificação não lida." : "Nenhuma notificação ainda."}
                    </p>
                </div>
            ) : (
                <div className="space-y-1" data-testid="notifications-list">
                    {filtered.map((notif) => {
                        const cfg = NOTIF_TYPE_CONFIG[notif.type] || NOTIF_TYPE_CONFIG.SYSTEM;
                        const Icon = cfg.icon;
                        const isClickable = notif.entity_type && notif.entity_id;
                        return (
                            <div
                                key={notif.id}
                                onClick={() => handleNotifClick(notif)}
                                data-testid={`notif-row-${notif.id}`}
                                className={`flex items-start gap-3 p-4 rounded-sm border transition-all ${
                                    notif.is_read
                                        ? "bg-card border-border opacity-70"
                                        : "bg-card border-l-2 border-l-primary border-border"
                                } ${isClickable ? "cursor-pointer hover:border-foreground/20" : ""}`}
                            >
                                <div className={`mt-0.5 flex-shrink-0 p-2 rounded-sm ${cfg.bg}`}>
                                    <Icon size={14} className={cfg.color} />
                                </div>
                                <div className="flex-1 min-w-0">
                                    <div className="flex items-start justify-between gap-2">
                                        <p className={`text-sm ${notif.is_read ? "font-normal" : "font-semibold"}`} data-testid={`notif-title-${notif.id}`}>
                                            {notif.title}
                                        </p>
                                        <span className="text-[10px] text-muted-foreground flex-shrink-0 mt-0.5">
                                            {timeAgo(notif.created_at)}
                                        </span>
                                    </div>
                                    <p className="text-xs text-muted-foreground mt-0.5 leading-snug">{notif.body}</p>
                                </div>
                                {!notif.is_read && (
                                    <div className="mt-2 flex-shrink-0 h-2 w-2 rounded-full bg-luppa-purple" />
                                )}
                            </div>
                        );
                    })}
                </div>
            )}
        </div>
    );
}
