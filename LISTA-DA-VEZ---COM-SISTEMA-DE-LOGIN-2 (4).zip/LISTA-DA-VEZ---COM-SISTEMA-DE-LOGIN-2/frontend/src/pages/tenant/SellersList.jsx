import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import api, { extractError } from "@/lib/api";
import { SELLER_STATUS_PT, SELLER_STATUS_COLORS, USER_STATUS_PT, translateTechnicalValue } from "@/lib/i18n";
import { useTenant } from "@/context/TenantContext";
import { PageHeader, EmptyState } from "@/components/Common";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
    Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter,
} from "@/components/ui/dialog";
import {
    Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
    Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Plus, RotateCw, History } from "lucide-react";
import { toast } from "sonner";

// STATUS_COLORS importado de @/lib/i18n como SELLER_STATUS_COLORS
const STATUS_COLORS = SELLER_STATUS_COLORS;

const ALL_STATUSES = ["OFFLINE","AVAILABLE","BREAK","LUNCH","MEETING","TRAINING","ABSENT","BLOCKED"];

export default function SellersList() {
    const { tenantSlug } = useParams();
    const { context } = useTenant();
    const [sellers, setSellers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [statusModal, setStatusModal] = useState(null);
    const [logsModal, setLogsModal] = useState(null);

    const load = async () => {
        setLoading(true);
        const { data } = await api.get(`/tenants/${tenantSlug}/sellers`);
        setSellers(data); setLoading(false);
    };
    useEffect(() => { load(); }, [tenantSlug]);

    return (
        <div>
            <PageHeader eyebrow="Equipe" title="Vendedores" description="Perfis comerciais vinculados às unidades.">
                <CreateSellerDialog onCreated={load} stores={context?.stores || []} />
            </PageHeader>
            {loading ? <p className="text-sm text-muted-foreground">Carregando…</p> :
             sellers.length === 0 ? <EmptyState title="Sem vendedores" description="Crie o primeiro vendedor." /> :
             <Card className="border border-border shadow-sm"><CardContent className="p-0">
                <Table><TableHeader><TableRow>
                    <TableHead>Nome</TableHead><TableHead>Código</TableHead>
                    <TableHead>Status operacional</TableHead><TableHead>Status</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                </TableRow></TableHeader><TableBody>
                {sellers.map((s) => (
                    <TableRow key={s.id} data-testid={`seller-row-${s.employee_code}`}>
                        <TableCell><div className="font-medium">{s.user?.name}</div>
                            <div className="text-xs text-muted-foreground">{s.user?.email}</div></TableCell>
                        <TableCell className="font-mono text-xs">{s.employee_code}</TableCell>
                        <TableCell><span className={`px-2 py-1 rounded-sm text-xs font-medium ${STATUS_COLORS[s.current_status] || "bg-muted"}`} data-testid={`seller-opstatus-${s.employee_code}`}>{SELLER_STATUS_PT[s.current_status] || translateTechnicalValue(s.current_status)}</span></TableCell>
                        <TableCell><Badge variant={s.status === "ACTIVE" ? "default" : "outline"}>{USER_STATUS_PT[s.status] || s.status}</Badge></TableCell>
                        <TableCell className="text-right space-x-2">
                            <Button size="sm" variant="outline" onClick={() => setStatusModal(s)} data-testid={`seller-status-btn-${s.employee_code}`}><RotateCw size={14}/></Button>
                            <Button size="sm" variant="ghost" onClick={() => setLogsModal(s)} data-testid={`seller-logs-btn-${s.employee_code}`}><History size={14}/></Button>
                        </TableCell>
                    </TableRow>
                ))}
                </TableBody></Table>
             </CardContent></Card>}
            {statusModal && <StatusModal seller={statusModal} tenantSlug={tenantSlug} onClose={() => setStatusModal(null)} onSaved={load} />}
            {logsModal && <LogsModal seller={logsModal} tenantSlug={tenantSlug} onClose={() => setLogsModal(null)} />}
        </div>
    );
}

function CreateSellerDialog({ onCreated, stores }) {
    const { tenantSlug } = useParams();
    const [open, setOpen] = useState(false);
    const [form, setForm] = useState({ name: "", email: "", password: "", phone: "", store_id: "", employee_code: "", current_status: "OFFLINE" });
    const [saving, setSaving] = useState(false);
    const setF = (k,v) => setForm((p) => ({ ...p, [k]: v }));
    const submit = async (e) => { e.preventDefault();
        if (saving) return;
        setSaving(true);
        try { await api.post(`/tenants/${tenantSlug}/sellers`, form);
            toast.success("Vendedor criado."); setOpen(false); onCreated();
            setForm({ name:"", email:"", password:"", phone:"", store_id:"", employee_code:"", current_status:"OFFLINE" });
        } catch (e) { toast.error(extractError(e, "Erro ao criar")); }
        finally { setSaving(false); }
    };
    return (
        <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button data-testid="new-seller-button" className="gap-2"><Plus size={16}/> Novo vendedor</Button></DialogTrigger>
            <DialogContent className="max-w-lg">
                <DialogHeader><DialogTitle>Novo vendedor</DialogTitle></DialogHeader>
                <form onSubmit={submit} className="grid grid-cols-2 gap-4">
                    <div className="col-span-2 space-y-2"><Label>Nome</Label><Input value={form.name} onChange={(e)=>setF("name",e.target.value)} required data-testid="seller-name-input"/></div>
                    <div className="space-y-2"><Label>E-mail</Label><Input type="email" value={form.email} onChange={(e)=>setF("email",e.target.value)} required data-testid="seller-email-input"/></div>
                    <div className="space-y-2"><Label>Senha</Label><Input type="password" value={form.password} onChange={(e)=>setF("password",e.target.value)} required data-testid="seller-password-input"/></div>
                    <div className="space-y-2"><Label>Código</Label><Input value={form.employee_code} onChange={(e)=>setF("employee_code",e.target.value)} data-testid="seller-code-input"/></div>
                    <div className="space-y-2"><Label>Unidade</Label>
                        <Select value={form.store_id} onValueChange={(v)=>setF("store_id",v)}>
                            <SelectTrigger data-testid="seller-store-select"><SelectValue placeholder="Selecione…"/></SelectTrigger>
                            <SelectContent>{stores.map((s)=><SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent>
                        </Select>
                    </div>
                    <DialogFooter className="col-span-2"><Button type="submit" disabled={saving} data-testid="seller-submit">{saving ? "Criando…" : "Criar"}</Button></DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}

function StatusModal({ seller, tenantSlug, onClose, onSaved }) {
    const [newStatus, setNewStatus] = useState("AVAILABLE");
    const [reason, setReason] = useState("");
    const [saving, setSaving] = useState(false);
    const submit = async (e) => { e.preventDefault();
        if (saving) return;
        setSaving(true);
        try { await api.patch(`/tenants/${tenantSlug}/sellers/${seller.id}/status`, { new_status: newStatus, reason });
            toast.success("Status atualizado."); onSaved(); onClose();
        } catch (e) { toast.error(extractError(e, "Erro")); }
        finally { setSaving(false); }
    };
    return (
        <Dialog open onOpenChange={onClose}>
            <DialogContent>
                <DialogHeader><DialogTitle>Alterar status</DialogTitle></DialogHeader>
                <form onSubmit={submit} className="space-y-4">
                    <p className="text-sm text-muted-foreground">Atual: <span className="font-mono">{SELLER_STATUS_PT[seller.current_status] || translateTechnicalValue(seller.current_status)}</span></p>
                    <div className="space-y-2"><Label>Novo status</Label>
                        <Select value={newStatus} onValueChange={setNewStatus}>
                            <SelectTrigger data-testid="status-select"><SelectValue/></SelectTrigger>
                <SelectContent>{ALL_STATUSES.map((s) => <SelectItem key={s} value={s}>{SELLER_STATUS_PT[s] || translateTechnicalValue(s)}</SelectItem>)}</SelectContent>
                        </Select>
                    </div>
                    <div className="space-y-2"><Label>Motivo</Label><Input value={reason} onChange={(e)=>setReason(e.target.value)} data-testid="status-reason-input"/></div>
                    <DialogFooter><Button type="button" variant="outline" onClick={onClose}>Cancelar</Button><Button type="submit" disabled={saving} data-testid="status-confirm">{saving ? "Salvando…" : "Confirmar"}</Button></DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}

function LogsModal({ seller, tenantSlug, onClose }) {
    const [logs, setLogs] = useState([]);
    useEffect(() => { api.get(`/tenants/${tenantSlug}/sellers/${seller.id}/status-logs`).then(({data}) => setLogs(data)); }, [seller.id, tenantSlug]);
    return (
        <Dialog open onOpenChange={onClose}>
            <DialogContent className="max-w-2xl">
                <DialogHeader><DialogTitle>Histórico de {seller.user?.name}</DialogTitle></DialogHeader>
                <div className="max-h-96 overflow-auto space-y-2">
                    {logs.length === 0 ? <p className="text-sm text-muted-foreground">Sem registros.</p> :
                     logs.map((l) => (
                        <div key={l.id} className="text-xs border border-border rounded-sm p-2 bg-muted/30">
                            <p className="font-mono">{l.created_at}</p>
                            <p>{translateTechnicalValue(l.old_status)} → <span className="font-semibold">{translateTechnicalValue(l.new_status)}</span></p>
                            {l.reason && <p className="text-muted-foreground mt-1">{l.reason}</p>}
                        </div>
                    ))}
                </div>
            </DialogContent>
        </Dialog>
    );
}
