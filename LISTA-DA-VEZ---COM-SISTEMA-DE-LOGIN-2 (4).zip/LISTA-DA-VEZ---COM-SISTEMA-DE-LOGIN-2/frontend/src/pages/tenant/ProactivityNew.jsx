import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeft, Send } from "lucide-react";
import { useTenant } from "@/context/TenantContext";
import api from "@/lib/api";
import { PageHeader } from "@/components/Common";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";

const SOURCES = [
    { value: "STORE_FLOOR", label: "Piso da loja" },
    { value: "WINDOW", label: "Vitrine" },
    { value: "RETURNING_CUSTOMER", label: "Cliente retornante" },
    { value: "REFERRAL", label: "Indicação" },
    { value: "PHONE", label: "Telefone" },
    { value: "WHATSAPP", label: "WhatsApp" },
    { value: "INSTAGRAM", label: "Instagram" },
    { value: "OTHER", label: "Outro" },
];

const APPROACH_TYPES = [
    { value: "ACTIVE_APPROACH", label: "Abordagem ativa" },
    { value: "CUSTOMER_REENGAGEMENT", label: "Reengajamento de cliente" },
    { value: "PRODUCT_INTEREST", label: "Interesse em produto" },
    { value: "POST_VISIT_FOLLOWUP", label: "Seguimento pós-visita" },
    { value: "OTHER", label: "Outro" },
];

export default function ProactivityNew() {
    const { tenantSlug } = useParams();
    const { context } = useTenant();
    const nav = useNavigate();
    const role = context?.user_role;

    const [stores, setStores] = useState([]);
    const [sellers, setSellers] = useState([]);
    const [loading, setLoading] = useState(false);

    const [form, setForm] = useState({
        store_id: "",
        seller_id: "",
        customer_name: "",
        customer_phone: "",
        customer_note: "",
        source: "STORE_FLOOR",
        approach_type: "ACTIVE_APPROACH",
        notes: "",
    });

    useEffect(() => {
        api.get(`/tenants/${tenantSlug}/stores`).then(r => {
            setStores(r.data);
            // Para SELLER: auto-seleciona a única loja (ou primeira disponível)
            // Para outros roles com uma loja: também auto-seleciona
            if (r.data.length === 1 || role === "SELLER") {
                const storeId = r.data[0]?.id;
                if (storeId) setForm(f => ({ ...f, store_id: storeId }));
            }
        }).catch(() => {});
    }, [tenantSlug, role]);

    useEffect(() => {
        if (!form.store_id) { setSellers([]); return; }
        api.get(`/tenants/${tenantSlug}/sellers?store_id=${form.store_id}`).then(r => {
            setSellers(r.data);
            // If SELLER role, auto-fill seller_id
            if (role === "SELLER" && r.data.length > 0) {
                const own = r.data.find(s => s.user_id === context?.user?.id);
                if (own) setForm(f => ({ ...f, seller_id: own.id }));
            }
        }).catch(() => {});
    }, [form.store_id, tenantSlug, role, context]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!form.store_id) { toast.error("Selecione a unidade"); return; }
        setLoading(true);
        try {
            const payload = { ...form };
            if (!payload.seller_id) delete payload.seller_id;
            if (!payload.customer_name) delete payload.customer_name;
            if (!payload.customer_phone) delete payload.customer_phone;
            if (!payload.customer_note) delete payload.customer_note;
            if (!payload.notes) delete payload.notes;
            const res = await api.post(`/tenants/${tenantSlug}/proactive-approaches`, payload);
            toast.success("Abordagem registrada com sucesso!");
            nav(`/${tenantSlug}/proactivity/${res.data.id}`);
        } catch (err) {
            toast.error(err?.response?.data?.detail || "Erro ao registrar abordagem");
        } finally {
            setLoading(false);
        }
    };

    const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

    return (
        <div data-testid="proactivity-new-page">
            <div className="flex items-center gap-3 mb-6">
                <Button variant="ghost" size="icon" onClick={() => nav(-1)} data-testid="back-btn">
                    <ArrowLeft size={18} />
                </Button>
                <PageHeader eyebrow="Abordagem Proativa" title="Nova abordagem" />
            </div>

            <div className="max-w-xl">
                <Card className="border border-border shadow-sm">
                    <CardContent className="p-6">
                        <form onSubmit={handleSubmit} className="space-y-4">
                            {/* Unidade — oculta para SELLER (auto-preenchida) */}
                            {role !== "SELLER" && (
                                <div>
                                    <label className="text-sm font-medium mb-1.5 block">Unidade *</label>
                                    <select
                                        className="w-full border border-border rounded-sm px-3 py-2 text-sm bg-background"
                                        value={form.store_id}
                                        onChange={e => set("store_id", e.target.value)}
                                        required
                                        data-testid="form-store"
                                    >
                                        <option value="">Selecione a unidade</option>
                                        {stores.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                                    </select>
                                </div>
                            )}

                            {/* Vendedor (apenas managers podem selecionar outro) */}
                            {role !== "SELLER" && (
                                <div>
                                    <label className="text-sm font-medium mb-1.5 block">Vendedor</label>
                                    <select
                                        className="w-full border border-border rounded-sm px-3 py-2 text-sm bg-background"
                                        value={form.seller_id}
                                        onChange={e => set("seller_id", e.target.value)}
                                        data-testid="form-seller"
                                    >
                                        <option value="">Selecione o vendedor (opcional)</option>
                                        {sellers.map(s => <option key={s.id} value={s.id}>{s.user?.name || s.name || s.id}</option>)}
                                    </select>
                                </div>
                            )}

                            {/* Fonte */}
                            <div>
                                <label className="text-sm font-medium mb-1.5 block">Fonte da abordagem</label>
                                <select
                                    className="w-full border border-border rounded-sm px-3 py-2 text-sm bg-background"
                                    value={form.source}
                                    onChange={e => set("source", e.target.value)}
                                    data-testid="form-source"
                                >
                                    {SOURCES.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
                                </select>
                            </div>

                            {/* Tipo */}
                            <div>
                                <label className="text-sm font-medium mb-1.5 block">Tipo de abordagem</label>
                                <select
                                    className="w-full border border-border rounded-sm px-3 py-2 text-sm bg-background"
                                    value={form.approach_type}
                                    onChange={e => set("approach_type", e.target.value)}
                                    data-testid="form-approach-type"
                                >
                                    {APPROACH_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
                                </select>
                            </div>

                            {/* Cliente */}
                            <div>
                                <label className="text-sm font-medium mb-1.5 block">Nome do cliente (opcional)</label>
                                <input
                                    type="text"
                                    className="w-full border border-border rounded-sm px-3 py-2 text-sm"
                                    placeholder="Ex: Roberto Carvalho"
                                    value={form.customer_name}
                                    onChange={e => set("customer_name", e.target.value)}
                                    data-testid="form-customer-name"
                                />
                            </div>
                            <div>
                                <label className="text-sm font-medium mb-1.5 block">Telefone (opcional)</label>
                                <input
                                    type="tel"
                                    className="w-full border border-border rounded-sm px-3 py-2 text-sm"
                                    placeholder="(11) 9xxxx-xxxx"
                                    value={form.customer_phone}
                                    onChange={e => set("customer_phone", e.target.value)}
                                    data-testid="form-customer-phone"
                                />
                            </div>

                            {/* Observações */}
                            <div>
                                <label className="text-sm font-medium mb-1.5 block">Observações</label>
                                <textarea
                                    className="w-full border border-border rounded-sm px-3 py-2 text-sm resize-none"
                                    rows={3}
                                    placeholder="Descreva a abordagem..."
                                    value={form.notes}
                                    onChange={e => set("notes", e.target.value)}
                                    data-testid="form-notes"
                                />
                            </div>

                            <div className="flex gap-3 pt-2">
                                <Button type="submit" disabled={loading} data-testid="form-submit-btn">
                                    <Send size={14} className="mr-2" />
                                    {loading ? "Registrando..." : "Registrar abordagem"}
                                </Button>
                                <Button type="button" variant="outline" onClick={() => nav(-1)} data-testid="form-cancel-btn">
                                    Cancelar
                                </Button>
                            </div>
                        </form>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
