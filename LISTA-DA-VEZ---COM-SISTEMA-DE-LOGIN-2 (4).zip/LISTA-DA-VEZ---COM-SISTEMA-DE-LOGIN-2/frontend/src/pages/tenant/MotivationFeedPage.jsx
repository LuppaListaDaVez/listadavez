/**
 * Feed Motivacional — Prompt 11
 * Realtime via RealtimeTenantContext | Admin pode criar avisos públicos
 */
import { useState, useEffect, useCallback, useRef } from "react";
import { useParams } from "react-router-dom";
import {
    Trophy, Star, TrendingUp, Zap, Award, Users, Megaphone,
    Plus, Send, Wifi, WifiOff,
} from "lucide-react";
import { toast } from "sonner";
import api, { extractError } from "@/lib/api";
import { usePermissions } from "@/hooks/usePermissions";
import { useRealtimeTenant } from "@/context/RealtimeTenantContext";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
    Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";

// ─── Config visual por tipo de evento ────────────────────────────────────────

const EVENT_CONFIG = {
    GOAL_DAILY_ACHIEVED:   { icon: Trophy, color: "text-amber-600", bg: "bg-amber-50", border: "border-amber-200", emoji: "🏆" },
    GOAL_WEEKLY_ACHIEVED:  { icon: Trophy, color: "text-amber-700", bg: "bg-amber-100", border: "border-amber-300", emoji: "🏆" },
    GOAL_MONTHLY_ACHIEVED: { icon: Trophy, color: "text-luppa-warning", bg: "bg-luppa-warning/10", border: "border-luppa-warning/25", emoji: "🏆" },
    GOAL_EXCEEDED:         { icon: Trophy, color: "text-luppa-green", bg: "bg-luppa-green/10", border: "border-luppa-green/25", emoji: "🚀" },
    BADGE_EARNED:          { icon: Award, color: "text-luppa-purple", bg: "bg-luppa-purple/10", border: "border-luppa-purple/25", emoji: "🎖️" },
    AWARD:                 { icon: Award, color: "text-luppa-warning", bg: "bg-luppa-warning/10", border: "border-luppa-warning/25", emoji: "🥇" },
    RECOGNITION:           { icon: Star, color: "text-amber-500", bg: "bg-amber-50", border: "border-amber-200", emoji: "⭐" },
    RANKING_TOP_1:         { icon: Star, color: "text-luppa-warning", bg: "bg-luppa-warning/10", border: "border-luppa-warning/30", emoji: "🥇" },
    RANKING_TOP_3:         { icon: Star, color: "text-slate-500", bg: "bg-slate-50", border: "border-slate-200", emoji: "🥈" },
    RANKING_TOP_10:        { icon: Star, color: "text-luppa-warning", bg: "bg-luppa-warning/10", border: "border-luppa-warning/25", emoji: "🎯" },
    RANKING_POSITION_UP:   { icon: TrendingUp, color: "text-luppa-green", bg: "bg-luppa-green/10", border: "border-luppa-green/25", emoji: "📈" },
    PERSONAL_RECORD:       { icon: Zap, color: "text-luppa-warning", bg: "bg-luppa-warning/10", border: "border-luppa-warning/25", emoji: "🔥" },
    COMPANY_RECORD:        { icon: Zap, color: "text-luppa-error", bg: "bg-luppa-error/10", border: "border-luppa-error/25", emoji: "🔥" },
    CAMPAIGN_STARTED:      { icon: Megaphone, color: "text-luppa-purple", bg: "bg-luppa-purple/10", border: "border-luppa-purple/25", emoji: "🎯" },
    CAMPAIGN_UPDATED:      { icon: Megaphone, color: "text-luppa-purple", bg: "bg-luppa-purple/10", border: "border-luppa-purple/25", emoji: "📢" },
    CAMPAIGN_ENDED:        { icon: Megaphone, color: "text-slate-600", bg: "bg-slate-50", border: "border-slate-200", emoji: "🏁" },
    PROACTIVE_SALE_CREATED:{ icon: Zap, color: "text-luppa-purple", bg: "bg-luppa-purple/10", border: "border-luppa-purple/25", emoji: "⚡" },
    FIRST_PROACTIVE_SALE:  { icon: Zap, color: "text-luppa-purple", bg: "bg-luppa-purple/10", border: "border-luppa-purple/25", emoji: "⚡" },
    TEAM_GOAL_ACHIEVED:    { icon: Users, color: "text-luppa-green", bg: "bg-luppa-green/10", border: "border-emerald-200", emoji: "👥" },
    CONVERSION_HIGHLIGHT:  { icon: TrendingUp, color: "text-luppa-green", bg: "bg-luppa-green/10", border: "border-luppa-green/25", emoji: "📊" },
    PROACTIVE_TOP_SELLER_DAY: { icon: Zap, color: "text-violet-600", bg: "bg-violet-50", border: "border-violet-200", emoji: "⚡" },
    ADMIN_ANNOUNCEMENT:    { icon: Megaphone, color: "text-luppa-error", bg: "bg-luppa-error/10", border: "border-luppa-error/25", emoji: "📢" },
    GENERAL_ANNOUNCEMENT:  { icon: Megaphone, color: "text-sky-600", bg: "bg-sky-50", border: "border-sky-200", emoji: "📣" },
    SCHEDULED_MESSAGE:     { icon: Megaphone, color: "text-violet-600", bg: "bg-violet-50", border: "border-violet-200", emoji: "💬" },
};

function getConfig(eventType) {
    return EVENT_CONFIG[eventType] || { icon: Trophy, color: "text-gray-600", bg: "bg-gray-50", border: "border-gray-200", emoji: "⭐" };
}

function fmtDate(iso) {
    if (!iso) return "";
    try {
        const d = new Date(iso);
        const now = new Date();
        const diff = Math.floor((now - d) / 1000);
        if (diff < 60) return "agora mesmo";
        if (diff < 3600) return `há ${Math.floor(diff / 60)} min`;
        if (diff < 86400) return `há ${Math.floor(diff / 3600)}h`;
        return d.toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });
    } catch { return iso; }
}

// ─── EventCard ────────────────────────────────────────────────────────────────

function EventCard({ event, isNew }) {
    const cfg = getConfig(event.event_type);
    const Icon = cfg.icon;
    const photo = event.seller_photo;
    const name = event.seller_name;

    return (
        <Card
            className={`border ${cfg.border} shadow-sm transition-all ${isNew ? "ring-2 ring-offset-1 ring-blue-300 animate-pulse-once" : "hover:shadow-md"}`}
            data-testid={`motivation-event-${event.id}`}
        >
            <CardContent className="p-4">
                <div className="flex items-start gap-3">
                    {/* Ícone ou foto do vendedor */}
                    <div className="relative flex-shrink-0">
                        {photo ? (
                            <img src={photo} alt={name} className="w-10 h-10 rounded-full object-cover" />
                        ) : (
                            <div className={`w-10 h-10 rounded-full ${cfg.bg} flex items-center justify-center`}>
                                <Icon size={18} strokeWidth={1.5} className={cfg.color} />
                            </div>
                        )}
                        <span className="absolute -bottom-0.5 -right-0.5 text-xs leading-none">{cfg.emoji}</span>
                    </div>

                    <div className="min-w-0 flex-1">
                        <p className="font-semibold text-sm text-foreground">{event.title}</p>
                        <p className="text-sm text-muted-foreground mt-0.5 leading-snug">{event.message}</p>
                        <div className="flex items-center gap-2 mt-2">
                            {name && (
                                <span className="text-[10px] font-medium text-muted-foreground bg-muted px-1.5 py-0.5 rounded">{name}</span>
                            )}
                            <span className="text-[10px] text-muted-foreground">{fmtDate(event.created_at)}</span>
                        </div>
                    </div>
                </div>
            </CardContent>
        </Card>
    );
}

// ─── Admin Announcement Form ──────────────────────────────────────────────────

const ANNOUNCE_TYPES = [
    { value: "ADMIN_ANNOUNCEMENT", label: "Aviso da Administração" },
    { value: "GENERAL_ANNOUNCEMENT", label: "Comunicado Geral" },
    { value: "RECOGNITION", label: "Reconhecimento" },
    { value: "AWARD", label: "Premiação" },
    { value: "SCHEDULED_MESSAGE", label: "Mensagem Motivacional" },
];

function AnnounceForm({ tenantSlug, onSuccess }) {
    const [message, setMessage] = useState("");
    const [type, setType] = useState("ADMIN_ANNOUNCEMENT");
    const [saving, setSaving] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!message.trim()) return;
        setSaving(true);
        try {
            await api.post(`/tenants/${tenantSlug}/motivation-events/announce`, {
                message: message.trim(),
                event_type: type,
            });
            toast.success("Aviso publicado no feed!");
            setMessage("");
            onSuccess();
        } catch (err) {
            toast.error(extractError(err));
        } finally {
            setSaving(false);
        }
    };

    return (
        <Card className="border-dashed border-2 border-luppa-error/25 bg-luppa-error/10/30" data-testid="announce-form">
            <CardContent className="p-4">
                <form onSubmit={handleSubmit} className="space-y-3">
                    <p className="text-sm font-semibold text-luppa-error mb-1">Publicar aviso no feed</p>
                    <Select value={type} onValueChange={setType}>
                        <SelectTrigger className="h-8 text-xs" data-testid="announce-type">
                            <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                            {ANNOUNCE_TYPES.map(t => (
                                <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                    <Textarea
                        value={message}
                        onChange={e => setMessage(e.target.value)}
                        placeholder="Escreva seu aviso para toda a equipe…"
                        rows={3}
                        className="text-sm resize-none"
                        data-testid="announce-message"
                        required
                    />
                    <div className="flex justify-end">
                        <Button type="submit" size="sm" disabled={saving || !message.trim()} className="gap-1.5" data-testid="announce-submit">
                            <Send size={13} /> {saving ? "Publicando…" : "Publicar"}
                        </Button>
                    </div>
                </form>
            </CardContent>
        </Card>
    );
}

// ─── Página Principal ─────────────────────────────────────────────────────────

export default function MotivationFeedPage() {
    const { tenantSlug } = useParams();
    const { hasPermission } = usePermissions();
    const { subscribe, isConnected } = useRealtimeTenant();

    const [events, setEvents] = useState([]);
    const [loading, setLoading] = useState(true);
    const [newIds, setNewIds] = useState(new Set());
    const [newCount, setNewCount] = useState(0);
    const seenIdsRef = useRef(new Set());

    const [showAnnounce, setShowAnnounce] = useState(false);

    const canManage = hasPermission("motivation_events.manage");

    const load = useCallback(async () => {
        setLoading(true);
        try {
            const res = await api.get(`/tenants/${tenantSlug}/motivation-events/feed?limit=50`);
            const data = Array.isArray(res.data) ? res.data : [];
            data.forEach(e => seenIdsRef.current.add(e.id));
            setEvents(data);
        } catch {
            toast.error("Erro ao carregar feed motivacional");
        } finally {
            setLoading(false);
        }
    }, [tenantSlug]);

    useEffect(() => { load(); }, [load]);

    // Realtime via WS
    useEffect(() => {
        const unsub = subscribe("motivation.event_created", (event) => {
            const p = event.payload;
            if (!p?.id || seenIdsRef.current.has(p.id)) return;
            seenIdsRef.current.add(p.id);

            const newEvent = {
                id: p.id,
                event_type: p.event_type,
                icon: p.icon,
                title: p.title,
                message: p.message,
                seller_id: p.seller_id,
                seller_name: p.seller_name,
                seller_photo: p.seller_photo,
                created_at: p.created_at,
            };

            setEvents(prev => [newEvent, ...prev]);
            setNewIds(prev => new Set([...prev, p.id]));
            setNewCount(c => c + 1);

            // Remove highlight after 5s
            setTimeout(() => {
                setNewIds(prev => { const s = new Set(prev); s.delete(p.id); return s; });
            }, 5000);
        });
        return unsub;
    }, [subscribe]);

    return (
        <div data-testid="motivation-feed-page">
            {/* Header */}
            <div className="flex items-start justify-between mb-6">
                <div>
                    <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">Engajamento</p>
                    <h1 className="text-2xl font-semibold mt-1 flex items-center gap-2">
                        Feed Motivacional
                        {newCount > 0 && (
                            <span
                                className="inline-flex items-center justify-center h-5 min-w-5 px-1.5 bg-luppa-purple text-white text-[10px] font-bold rounded-full cursor-pointer"
                                onClick={() => setNewCount(0)}
                                data-testid="feed-new-badge"
                            >
                                +{newCount}
                            </span>
                        )}
                    </h1>
                    <p className="text-sm text-muted-foreground mt-1">Conquistas, metas e destaques da equipe.</p>
                </div>
                <div className="flex items-center gap-3 mt-1">
                    {/* Indicador de realtime */}
                    <span
                        className={`flex items-center gap-1 text-xs ${isConnected ? "text-luppa-green" : "text-muted-foreground"}`}
                        title={isConnected ? "Tempo real ativo" : "Reconectando…"}
                        data-testid="feed-realtime-indicator"
                    >
                        {isConnected
                            ? <><Wifi size={12} /> Tempo real</>
                            : <><WifiOff size={12} /> Reconectando…</>
                        }
                    </span>
                    {canManage && (
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setShowAnnounce(v => !v)}
                            className="gap-2"
                            data-testid="btn-announce"
                        >
                            <Megaphone size={14} /> {showAnnounce ? "Cancelar" : "Publicar aviso"}
                        </Button>
                    )}
                </div>
            </div>

            {/* Admin announce form */}
            {canManage && showAnnounce && (
                <div className="mb-5">
                    <AnnounceForm tenantSlug={tenantSlug} onSuccess={() => { load(); setShowAnnounce(false); }} />
                </div>
            )}

            {/* Feed */}
            {loading ? (
                <div className="space-y-3">
                    {[1,2,3,4].map(i => <Skeleton key={i} className="h-20 w-full" />)}
                </div>
            ) : events.length === 0 ? (
                <Card className="border border-border shadow-sm">
                    <CardContent className="p-12 text-center">
                        <Trophy size={36} strokeWidth={1} className="mx-auto mb-4 text-muted-foreground" />
                        <p className="text-sm text-muted-foreground">Nenhum evento motivacional ainda.</p>
                        <p className="text-xs text-muted-foreground mt-1">Quando vendedores baterem metas ou ganharem conquistas, os eventos aparecerão aqui.</p>
                    </CardContent>
                </Card>
            ) : (
                <div className="space-y-3" data-testid="motivation-events-list">
                    {events.map(ev => (
                        <EventCard key={ev.id} event={ev} isNew={newIds.has(ev.id)} />
                    ))}
                </div>
            )}
        </div>
    );
}
