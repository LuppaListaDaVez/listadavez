import React, { useEffect, useState, useCallback } from "react";
import { useParams } from "react-router-dom";
import { Plus, Play, Pause, Trash2, RefreshCw, ChevronRight, Zap } from "lucide-react";
import api from "@/lib/api";
import { PageHeader } from "@/components/Common";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { fmtDateTime } from "@/lib/i18n";

const TRIGGER_LABELS = {
    GOAL_ACHIEVED: "Meta batida",
    GOAL_NEAR_TARGET: "Meta próxima",
    BADGE_EARNED: "Conquista obtida",
    RANKING_CHANGED: "Ranking mudou",
    SALE_CREATED: "Venda criada",
    ATTENDANCE_STALLED: "Atendimento parado",
    PROACTIVE_SALE_CREATED: "Venda proativa",
    MANUAL: "Manual",
    SCHEDULED_DAILY: "Diário",
    SCHEDULED_WEEKLY: "Semanal",
};

const ACTION_LABELS = {
    CREATE_NOTIFICATION: "Criar notificação",
    SEND_EMAIL: "Enviar e-mail",
    SEND_PUSH: "Enviar push",
    CREATE_ALERT: "Criar alerta",
    CREATE_MOTIVATION_EVENT: "Evento motivacional",
};


const AVAILABLE_TRIGGERS = Object.keys(TRIGGER_LABELS);
const AVAILABLE_ACTIONS = [
    { type: "CREATE_NOTIFICATION", label: "Criar notificação", fields: ["title", "message"] },
    { type: "CREATE_ALERT", label: "Criar alerta", fields: ["title", "message", "severity"] },
    { type: "CREATE_MOTIVATION_EVENT", label: "Evento motivacional", fields: ["event_type"] },
    { type: "SEND_EMAIL", label: "Enviar e-mail", fields: [] },
    { type: "SEND_PUSH", label: "Enviar notificação push", fields: [] },
];

export default function AutomationRulesPage() {
    const { tenantSlug } = useParams();
    const [rules, setRules] = useState([]);
    const [loading, setLoading] = useState(true);
    const [showNew, setShowNew] = useState(false);
    const [form, setForm] = useState({ name: "", description: "", trigger_type: "GOAL_ACHIEVED", is_active: true, actions: [] });
    const [saving, setSaving] = useState(false);

    const load = useCallback(async () => {
        setLoading(true);
        try {
            const res = await api.get(`/tenants/${tenantSlug}/automation-rules`);
            setRules(res.data);
        } catch { toast.error("Erro ao carregar automações"); }
        finally { setLoading(false); }
    }, [tenantSlug]);

    useEffect(() => { load(); }, [load]);

    const handleCreate = async (e) => {
        e.preventDefault();
        if (!form.name) { toast.error("Nome obrigatório"); return; }
        setSaving(true);
        try {
            await api.post(`/tenants/${tenantSlug}/automation-rules`, {
                ...form,
                actions: form.actions.length > 0 ? form.actions : [{ type: "CREATE_NOTIFICATION", title: "Automação", message: "Evento automático." }],
            });
            toast.success("Automação criada!");
            setShowNew(false);
            setForm({ name: "", description: "", trigger_type: "GOAL_ACHIEVED", is_active: true, actions: [] });
            await load();
        } catch (e) { toast.error(e?.response?.data?.detail || "Erro ao criar"); }
        finally { setSaving(false); }
    };

    const handleToggle = async (rule) => {
        const endpoint = rule.is_active ? "disable" : "enable";
        try {
            await api.post(`/tenants/${tenantSlug}/automation-rules/${rule.id}/${endpoint}`);
            toast.success(rule.is_active ? "Automação desativada" : "Automação ativada");
            await load();
        } catch (e) { toast.error("Erro ao alterar status"); }
    };

    const handleRun = async (ruleId) => {
        try {
            const res = await api.post(`/tenants/${tenantSlug}/automation-rules/${ruleId}/run`);
            toast.success(`Executada: ${res.data.results?.length || 0} ações`);
        } catch (e) { toast.error(e?.response?.data?.detail || "Erro ao executar"); }
    };

    const handleDelete = async (ruleId) => {
        if (!window.confirm("Excluir esta automação?")) return;
        try {
            await api.delete(`/tenants/${tenantSlug}/automation-rules/${ruleId}`);
            toast.success("Automação excluída");
            await load();
        } catch { toast.error("Erro ao excluir"); }
    };

    return (
        <div data-testid="automation-rules-page">
            <div className="flex items-start justify-between mb-6">
                <PageHeader eyebrow="Automações" title="Regras de Automação" description="Configure ações automáticas baseadas em eventos do sistema." />
                <Button size="sm" onClick={() => setShowNew(v => !v)} className="mt-1" data-testid="new-automation-btn">
                    <Plus size={14} className="mr-2" /> Nova automação
                </Button>
            </div>

            {/* Form de criação */}
            {showNew && (
                <Card className="border border-border shadow-sm mb-6">
                    <CardContent className="p-5">
                        <p className="font-semibold text-sm mb-4">Nova regra de automação</p>
                        <form onSubmit={handleCreate} className="space-y-3">
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                <div>
                                    <label className="text-xs text-muted-foreground mb-1 block">Nome *</label>
                                    <input className="w-full border border-border rounded-sm px-3 py-2 text-sm"
                                        value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                                        placeholder="Ex: Notificar meta batida" required data-testid="auto-name" />
                                </div>
                                <div>
                                    <label className="text-xs text-muted-foreground mb-1 block">Gatilho</label>
                                    <select className="w-full border border-border rounded-sm px-3 py-2 text-sm bg-background"
                                        value={form.trigger_type} onChange={e => setForm(f => ({ ...f, trigger_type: e.target.value }))}
                                        data-testid="auto-trigger">
                                        {AVAILABLE_TRIGGERS.map(t => <option key={t} value={t}>{TRIGGER_LABELS[t]}</option>)}
                                    </select>
                                </div>
                            </div>
                            <div>
                                <label className="text-xs text-muted-foreground mb-1 block">Descrição</label>
                                <textarea className="w-full border border-border rounded-sm px-3 py-2 text-sm resize-none" rows={2}
                                    value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                                    data-testid="auto-description" />
                            </div>
                            <div className="flex gap-3">
                                <Button type="submit" size="sm" disabled={saving} data-testid="auto-submit">
                                    {saving ? "Salvando..." : "Criar automação"}
                                </Button>
                                <Button type="button" variant="outline" size="sm" onClick={() => setShowNew(false)}>Cancelar</Button>
                            </div>
                        </form>
                    </CardContent>
                </Card>
            )}

            {loading ? (
                <div className="space-y-3">{[1,2,3].map(i => <Skeleton key={i} className="h-20 w-full" />)}</div>
            ) : rules.length === 0 ? (
                <Card className="border border-border shadow-sm">
                    <CardContent className="p-10 text-center">
                        <Zap size={32} strokeWidth={1} className="mx-auto mb-3 text-muted-foreground" />
                        <p className="text-sm text-muted-foreground">Nenhuma regra de automação configurada.</p>
                        <Button size="sm" className="mt-4" onClick={() => setShowNew(true)} data-testid="empty-new-btn">
                            <Plus size={14} className="mr-2" /> Criar primeira automação
                        </Button>
                    </CardContent>
                </Card>
            ) : (
                <div className="space-y-3" data-testid="automation-rules-list">
                    {rules.map(rule => (
                        <Card key={rule.id} className={`border shadow-sm transition-all ${rule.is_active ? "border-border" : "border-border/40 opacity-60"}`}
                            data-testid={`automation-rule-${rule.id}`}>
                            <CardContent className="p-4">
                                <div className="flex items-center justify-between gap-4">
                                    <div className="min-w-0 flex-1">
                                        <div className="flex items-center gap-2">
                                            <p className="font-medium text-sm">{rule.name}</p>
                                            <span className={`text-xs px-1.5 py-0.5 rounded-full ${rule.is_active ? "bg-luppa-green/15 text-luppa-green" : "bg-gray-100 text-gray-600"}`}>
                                                {rule.is_active ? "Ativa" : "Inativa"}
                                            </span>
                                        </div>
                                        <p className="text-xs text-muted-foreground mt-0.5">
                                            Gatilho: {TRIGGER_LABELS[rule.trigger_type] || rule.trigger_type} ·{" "}
                                            {(rule.actions || []).length} ação(ões) ·{" "}
                                            Última execução: {fmtDateTime(rule.last_run_at)}
                                        </p>
                                    </div>
                                    <div className="flex items-center gap-2 flex-shrink-0">
                                        <button onClick={() => handleRun(rule.id)} title="Executar agora"
                                            className="text-muted-foreground hover:text-foreground transition-colors"
                                            data-testid={`run-rule-${rule.id}`}>
                                            <Play size={14} />
                                        </button>
                                        <button onClick={() => handleToggle(rule)} title={rule.is_active ? "Desativar" : "Ativar"}
                                            className="text-muted-foreground hover:text-foreground transition-colors"
                                            data-testid={`toggle-rule-${rule.id}`}>
                                            {rule.is_active ? <Pause size={14} /> : <Play size={14} />}
                                        </button>
                                        <button onClick={() => handleDelete(rule.id)} title="Excluir"
                                            className="text-muted-foreground hover:text-luppa-error transition-colors"
                                            data-testid={`delete-rule-${rule.id}`}>
                                            <Trash2 size={14} />
                                        </button>
                                    </div>
                                </div>
                            </CardContent>
                        </Card>
                    ))}
                </div>
            )}
        </div>
    );
}
