import React, { useEffect, useRef, useState, useCallback } from "react";
import { useParams, Link, Navigate } from "react-router-dom";
import {
    ResponsiveContainer, BarChart, Bar, XAxis, YAxis,
    Tooltip, CartesianGrid, ComposedChart, Line, Legend,
} from "recharts";
import { useTenant } from "@/context/TenantContext";
import api from "@/lib/api";
import { PageHeader } from "@/components/Common";
import { centsToBRL } from "@/lib/money";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { TrendingUp, Clock, Users, Target, Trophy, Zap, CalendarDays, UserCheck, RefreshCw, BarChart3, Store } from "lucide-react";
import AccessDenied from "@/components/AccessDenied";
import { GOAL_TYPE_PT, SELLER_STATUS_PT, translateTechnicalValue } from "@/lib/i18n";

// ─── Roles que NÃO têm acesso ao dashboard ────────────────────────────────
const BLOCKED_ROLES = ["SELLER"];
const DASHBOARD_REFRESH_MS = 5 * 60 * 1000;
const DASHBOARD_REFRESH_LABEL = "5 min";

// ─── Cálculo de datas por período ─────────────────────────────────────────
const fmtDate = (d) => {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
};

function getPeriodDates(period, customFrom, customTo) {
    const now = new Date();
    const today = fmtDate(now);

    switch (period) {
        case "today": return { from: today, to: today, label: "Hoje" };
        case "yesterday": {
            const d = new Date(now); d.setDate(d.getDate() - 1);
            const s = fmtDate(d); return { from: s, to: s, label: "Ontem" };
        }
        case "last7": {
            const d = new Date(now); d.setDate(d.getDate() - 6);
            return { from: fmtDate(d), to: today, label: "Últimos 7 dias" };
        }
        case "last30": {
            const d = new Date(now); d.setDate(d.getDate() - 29);
            return { from: fmtDate(d), to: today, label: "Últimos 30 dias" };
        }
        case "this_month": {
            const first = new Date(now.getFullYear(), now.getMonth(), 1);
            return { from: fmtDate(first), to: today, label: "Este mês" };
        }
        case "prev_month": {
            const first = new Date(now.getFullYear(), now.getMonth() - 1, 1);
            const last = new Date(now.getFullYear(), now.getMonth(), 0);
            return { from: fmtDate(first), to: fmtDate(last), label: "Mês anterior" };
        }
        case "custom":
            return { from: customFrom || today, to: customTo || today, label: "Período personalizado" };
        default:
            return { from: today, to: today, label: "Hoje" };
    }
}

const AWAY = ["BREAK", "LUNCH", "MEETING", "TRAINING", "ABSENT", "OFFLINE", "BLOCKED"];

function isToday(iso) {
    if (!iso) return false;
    const d = new Date(iso); const n = new Date();
    return d.getFullYear() === n.getFullYear() && d.getMonth() === n.getMonth() && d.getDate() === n.getDate();
}

function fmtDuration(seconds) {
    if (!seconds) return "—";
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}m ${s}s`;
}

// ─── Componente de métrica — usa sistema responsivo centralizado ──────────
function Metric({ label, value, testId, accent, loading }) {
    const colors = {
        emerald: "text-luppa-green",
        green:   "text-luppa-green",
        purple:  "text-luppa-purple",
        indigo:  "text-luppa-purple",
        amber:   "text-luppa-warning",
        blue:    "text-luppa-purple",
    };
    const colorCls = colors[accent] || "text-foreground";
    const displayValue = value ?? "—";
    const displayLength = String(displayValue).replace(/\s/g, "").length;
    const isCurrency = String(displayValue).includes("R$");
    const valueSizeClass = isCurrency
        ? (displayLength >= 10 ? "dashboard-metric-num-money-lg" : "dashboard-metric-num-money")
        : displayLength >= 8
            ? "dashboard-metric-num-long"
            : "dashboard-metric-num";
    return (
        <div className="metric-card-wrap rounded-[16px] border border-border/60 bg-card shadow-sm p-5 sm:p-6 min-h-[124px] flex flex-col justify-between gap-4" data-testid={`${testId}-card`}>
            <p className="metric-label micro-label dashboard-metric-label">{label}</p>
            {loading ? (
                <div className="h-9 w-24 bg-muted animate-pulse rounded" data-testid={`${testId}-loading`} />
            ) : (
                <span
                    className={`metric-num dashboard-metric-value ${valueSizeClass} font-mono font-semibold ${colorCls}`}
                    style={{ fontVariantNumeric: "tabular-nums" }}
                    data-testid={testId}
                    aria-label={String(displayValue)}
                >
                    {displayValue}
                </span>
            )}
        </div>
    );
}

function StoreSelector({ stores, storeId, setStoreId }) {
    if (!stores?.length) return null;
    return (
        <div className="space-y-1" data-testid="store-selector">
            <Label className="text-xs text-muted-foreground flex items-center gap-1">
                <Store size={12} /> Unidade
            </Label>
            <Select value={storeId || "all"} onValueChange={(v) => setStoreId(v === "all" ? null : v)}>
                <SelectTrigger className="w-52 h-8 text-xs" data-testid="store-select">
                    <SelectValue />
                </SelectTrigger>
                <SelectContent>
                    <SelectItem value="all">Todas as unidades</SelectItem>
                    {stores.map((s) => (
                        <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                    ))}
                </SelectContent>
            </Select>
        </div>
    );
}

// ─── Tooltip do gráfico ────────────────────────────────────────────────────
function TrendTooltip({ active, payload, label }) {
    if (!active || !payload?.length) return null;
    return (
        <div className="bg-card border border-border/60 rounded-md shadow-md p-3 text-xs">
            <p className="font-semibold mb-1">{label}</p>
            {payload.map((p) => (
                <p key={p.dataKey} style={{ color: p.color }}>
                    {p.name}: <span className="font-medium">{p.value}{p.dataKey === "conversao" ? "%" : ""}</span>
                </p>
            ))}
        </div>
    );
}

function fmtNumber(n) {
    return Number(n || 0).toLocaleString("pt-BR");
}

function fmtPct(n) {
    return `${Number(n || 0).toLocaleString("pt-BR", { maximumFractionDigits: 1 })}%`;
}

function OpportunityTooltip({ active, payload, label, financeiro }) {
    if (!active || !payload?.length) return null;
    const d = payload[0]?.payload || {};
    return (
        <div className="bg-card border border-border/60 rounded-md shadow-md p-3 text-xs" data-testid="dashboard-opportunity-tooltip">
            <p className="font-semibold mb-1">{label}</p>
            <p>Oportunidades: <b>{fmtNumber(d.opportunities)}</b></p>
            <p>Convertidas: <b>{fmtNumber(d.converted_opportunities)}</b></p>
            <p>Conversão: <b>{fmtPct(d.conversion_rate)}</b></p>
            {financeiro && <p>Receita: <b>{centsToBRL(d.revenue || 0)}</b></p>}
        </div>
    );
}

function OpportunityFlowWidget({ data, loading, periodLabel, tenantSlug }) {
    const series = data?.series || [];
    const totals = data?.totals || {};
    const financeiro = !!data?.can_view_financial;
    return (
        <Card className="border border-border shadow-sm mt-5" data-testid="dashboard-opportunity-flow-card">
            <CardContent className="p-5 md:p-6">
                <div className="flex flex-wrap items-start justify-between gap-3 mb-5">
                    <div className="min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                            <BarChart3 size={15} strokeWidth={1.5} className="text-muted-foreground" />
                            <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground">Fluxo de oportunidades por horário</p>
                        </div>
                        <p className="text-sm text-muted-foreground">{periodLabel} · oportunidades, convertidas e conversão.</p>
                    </div>
                    <Link to={`/${tenantSlug}/reports/opportunity-flow`} className="text-xs text-muted-foreground hover:text-foreground transition-colors" data-testid="dashboard-opportunity-flow-link">
                        Ver relatório completo →
                    </Link>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5" data-testid="dashboard-opportunity-summary">
                    <div className="rounded-md bg-muted/50 p-3 min-w-0">
                        <p className="micro-label">Oportunidades</p>
                        <p className="font-mono text-xl font-semibold mt-1" data-testid="dashboard-opportunities-total">{loading && !data ? "—" : fmtNumber(totals.opportunities)}</p>
                    </div>
                    <div className="rounded-md bg-muted/50 p-3 min-w-0">
                        <p className="micro-label">Convertidas</p>
                        <p className="font-mono text-xl font-semibold mt-1" data-testid="dashboard-opportunities-converted">{loading && !data ? "—" : fmtNumber(totals.converted_opportunities)}</p>
                    </div>
                    <div className="rounded-md bg-muted/50 p-3 min-w-0">
                        <p className="micro-label">Conversão</p>
                        <p className="font-mono text-xl font-semibold mt-1" data-testid="dashboard-opportunities-conversion">{loading && !data ? "—" : fmtPct(totals.conversion_rate)}</p>
                    </div>
                    {financeiro && (
                        <div className="rounded-md bg-muted/50 p-3 min-w-0">
                            <p className="micro-label">Receita</p>
                            <p className="font-mono text-xl font-semibold mt-1" data-testid="dashboard-opportunities-revenue">{loading && !data ? "—" : centsToBRL(totals.revenue || 0)}</p>
                        </div>
                    )}
                </div>

                {loading && !data ? (
                    <Skeleton className="h-72 w-full" data-testid="dashboard-opportunity-loading" />
                ) : series.length === 0 ? (
                    <div className="h-56 flex items-center justify-center text-sm text-muted-foreground" data-testid="dashboard-opportunity-empty">Sem dados para o período.</div>
                ) : (
                    <div className="overflow-x-auto" data-testid="dashboard-opportunity-chart-wrap">
                        <div className="min-w-[680px] md:min-w-0">
                            <ResponsiveContainer width="100%" height={300}>
                                <ComposedChart data={series} margin={{ top: 12, right: 24, left: 0, bottom: 0 }}>
                                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                                    <XAxis dataKey="label" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} interval="preserveStartEnd" />
                                    <YAxis yAxisId="left" allowDecimals={false} tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} width={34} />
                                    <YAxis yAxisId="right" orientation="right" domain={[0, 100]} tickFormatter={(v) => `${v}%`} tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} width={42} />
                                    <Tooltip content={<OpportunityTooltip financeiro={financeiro} />} cursor={{ fill: "hsl(var(--muted))" }} />
                                    <Legend wrapperStyle={{ fontSize: 12 }} />
                                    <Bar yAxisId="left" dataKey="opportunities" name="Oportunidades" fill="hsl(var(--chart-1))" radius={[4, 4, 0, 0]} maxBarSize={38} />
                                    <Bar yAxisId="left" dataKey="converted_opportunities" name="Convertidas" fill="hsl(var(--chart-2))" radius={[4, 4, 0, 0]} maxBarSize={38} />
                                    <Line yAxisId="right" type="monotone" dataKey="conversion_rate" name="Conversão" stroke="hsl(var(--foreground))" strokeWidth={2.5} dot={{ r: 3 }} />
                                </ComposedChart>
                            </ResponsiveContainer>
                        </div>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}

// ─── Seletor de Período ────────────────────────────────────────────────────
function PeriodSelector({ period, setPeriod, customFrom, setCustomFrom, customTo, setCustomTo }) {
    return (
        <div className="flex flex-wrap items-end gap-3" data-testid="period-selector">
            <div className="space-y-1">
                <Label className="text-xs text-muted-foreground flex items-center gap-1">
                    <CalendarDays size={12} /> Período
                </Label>
                <Select value={period} onValueChange={setPeriod}>
                    <SelectTrigger className="w-44 h-8 text-xs" data-testid="period-select">
                        <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="today">Hoje</SelectItem>
                        <SelectItem value="yesterday">Ontem</SelectItem>
                        <SelectItem value="last7">Últimos 7 dias</SelectItem>
                        <SelectItem value="last30">Últimos 30 dias</SelectItem>
                        <SelectItem value="this_month">Este mês</SelectItem>
                        <SelectItem value="prev_month">Mês anterior</SelectItem>
                        <SelectItem value="custom">Período personalizado</SelectItem>
                    </SelectContent>
                </Select>
            </div>

            {period === "custom" && (
                <>
                    <div className="space-y-1">
                        <Label className="text-xs text-muted-foreground">De</Label>
                        <Input
                            type="date"
                            value={customFrom}
                            onChange={(e) => setCustomFrom(e.target.value)}
                            className="h-8 text-xs w-36"
                            data-testid="period-custom-from"
                        />
                    </div>
                    <div className="space-y-1">
                        <Label className="text-xs text-muted-foreground">Até</Label>
                        <Input
                            type="date"
                            value={customTo}
                            onChange={(e) => setCustomTo(e.target.value)}
                            className="h-8 text-xs w-36"
                            data-testid="period-custom-to"
                        />
                    </div>
                </>
            )}
        </div>
    );
}

// ─── Seletor de Vendedor ───────────────────────────────────────────────────
function SellerSelector({ sellers, sellerId, setSellerId }) {
    if (!sellers.length) return null;
    return (
        <div className="space-y-1" data-testid="seller-selector">
            <Label className="text-xs text-muted-foreground flex items-center gap-1">
                <UserCheck size={12} /> Vendedor
            </Label>
            <Select value={sellerId || "all"} onValueChange={(v) => setSellerId(v === "all" ? null : v)}>
                <SelectTrigger className="w-48 h-8 text-xs" data-testid="seller-select">
                    <SelectValue />
                </SelectTrigger>
                <SelectContent>
                    <SelectItem value="all">Todos os vendedores</SelectItem>
                    {sellers.map((s) => (
                        <SelectItem key={s.id} value={s.id}>
                            {s.user?.name || s.name || s.id}
                        </SelectItem>
                    ))}
                </SelectContent>
            </Select>
        </div>
    );
}

// ─── Dashboard Principal ───────────────────────────────────────────────────
export default function TenantDashboard() {
    const { tenantSlug } = useParams();
    const { context } = useTenant();

    // ── Filtros ──────────────────────────────────────────────────────────────
    const [period, setPeriod] = useState("today");
    const [customFrom, setCustomFrom] = useState(fmtDate(new Date()));
    const [customTo, setCustomTo] = useState(fmtDate(new Date()));
    const [storeId, setStoreId] = useState(null);
    const [sellerId, setSellerId] = useState(null);

    // ── Dados ────────────────────────────────────────────────────────────────
    const [sellers, setSellers] = useState([]);
    const [users, setUsers] = useState([]);
    const [teams, setTeams] = useState([]);
    const [attendances, setAttendances] = useState([]);

    const [summary, setSummary] = useState(null);
    const [summaryLoading, setSummaryLoading] = useState(false);
    const [dashboardRefreshing, setDashboardRefreshing] = useState(false);
    const [lastUpdated, setLastUpdated] = useState(null);
    const [opportunityFlow, setOpportunityFlow] = useState(null);
    const [opportunityLoading, setOpportunityLoading] = useState(false);
    const [activeGoals, setActiveGoals] = useState([]);
    const [topRanking, setTopRanking] = useState([]);

    const timer = useRef(null);
    const summaryLoadedRef = useRef(false);
    const opportunityLoadedRef = useRef(false);

    const hasQueue = !!context?.features?.lista_da_vez;
    const hasDashboards = !!context?.features?.dashboards;
    const hasMetas = !!context?.features?.metas;
    const hasRankings = !!context?.features?.rankings;
    const hasOpportunityFlow = !!context?.features?.relatorios_basicos;

    // ── Fetch legacy (sellers, users, teams, attendances) ────────────────────
    const fetchLegacyData = useCallback(async () => {
        try {
            const reqs = [
                api.get(`/tenants/${tenantSlug}/users`),
                api.get(`/tenants/${tenantSlug}/sellers`),
                context?.features?.multi_equipes
                    ? api.get(`/tenants/${tenantSlug}/teams`)
                    : Promise.resolve({ data: [] }),
                hasQueue
                    ? api.get(`/tenants/${tenantSlug}/attendances?page_size=100`)
                    : Promise.resolve({ data: { items: [] } }),
            ];
            const [u, s, t, a] = await Promise.all(reqs);
            setUsers(u.data);
            setSellers(s.data);
            setTeams(t.data);
            const attData = Array.isArray(a.data) ? a.data : (a.data?.items || []);
            setAttendances(attData);
        } catch { /* keep last */ }
    }, [tenantSlug, context, hasQueue]);

    // ── Fetch summary (enhanced, com filtros) ─────────────────────────────────
    const fetchSummary = useCallback(async () => {
        if (!hasDashboards) return;
        const { from, to } = getPeriodDates(period, customFrom, customTo);
        if (!summaryLoadedRef.current) setSummaryLoading(true);
        try {
            const params = new URLSearchParams({ date_from: from, date_to: to });
            if (storeId) params.set("store_id", storeId);
            if (sellerId) params.set("seller_id", sellerId);
            const { data } = await api.get(`/tenants/${tenantSlug}/dashboard/summary?${params}`);
            setSummary(data);
            summaryLoadedRef.current = true;
        } catch {
            /* fallback to legacy */
        } finally {
            setSummaryLoading(false);
        }
    }, [tenantSlug, hasDashboards, period, customFrom, customTo, storeId, sellerId]);

    const fetchOpportunityFlow = useCallback(async () => {
        if (!hasOpportunityFlow) return;
        const { from, to } = getPeriodDates(period, customFrom, customTo);
        if (!opportunityLoadedRef.current) setOpportunityLoading(true);
        try {
            const params = new URLSearchParams({ date_start: from, date_end: to });
            if (storeId) params.set("store_id", storeId);
            if (sellerId) params.set("seller_id", sellerId);
            const { data } = await api.get(`/tenants/${tenantSlug}/reports/opportunity-flow?${params}`);
            setOpportunityFlow(data);
            opportunityLoadedRef.current = true;
        } catch {
            /* mantém o último gráfico renderizado */
        } finally {
            setOpportunityLoading(false);
        }
    }, [tenantSlug, hasOpportunityFlow, period, customFrom, customTo, storeId, sellerId]);

    const fetchGoals = useCallback(async () => {
        if (!hasMetas) return;
        try {
            const { data } = await api.get(`/tenants/${tenantSlug}/goals?status=ACTIVE`);
            setActiveGoals(data.slice(0, 4));
        } catch { /* silent */ }
    }, [tenantSlug, hasMetas]);

    const fetchRanking = useCallback(async () => {
        if (!hasRankings) return;
        try {
            const { data } = await api.get(`/tenants/${tenantSlug}/rankings?criteria=REVENUE`);
            setTopRanking((data.items || []).slice(0, 5));
        } catch { /* silent */ }
    }, [tenantSlug, hasRankings]);

    const refreshDashboard = useCallback(async () => {
        setDashboardRefreshing(true);
        try {
            await Promise.all([
                fetchLegacyData(),
                fetchSummary(),
                fetchGoals(),
                fetchRanking(),
                fetchOpportunityFlow(),
            ]);
            setLastUpdated(new Date());
        } finally {
            setDashboardRefreshing(false);
        }
    }, [fetchLegacyData, fetchSummary, fetchGoals, fetchRanking, fetchOpportunityFlow]);

    // ── Atualização suave: primeira carga, filtros e auto-refresh de 5 minutos ─
    useEffect(() => {
        fetchLegacyData().then(() => setLastUpdated(new Date()));
        fetchSummary();
        fetchGoals();
        fetchRanking();
        fetchOpportunityFlow();
        if (timer.current) clearInterval(timer.current);
        timer.current = setInterval(() => {
            fetchLegacyData();
            if (hasDashboards) fetchSummary();
            if (hasOpportunityFlow) fetchOpportunityFlow();
            setLastUpdated(new Date());
        }, DASHBOARD_REFRESH_MS);
        return () => timer.current && clearInterval(timer.current);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [tenantSlug, context, hasDashboards, hasOpportunityFlow, period, customFrom, customTo, storeId, sellerId]);

    if (!context) return null;

    // ── Bloquear SELLER (após todos os hooks) ─────────────────────────────────
    const userRole = context?.user_role;
    if (BLOCKED_ROLES.includes(userRole)) {
        return <AccessDenied message="Você não tem permissão para acessar o painel." />;
    }

    const kpis = summary?.kpis;
    const weekTrend = summary?.week_trend || [];
    const sellersByStatus = summary?.sellers_status || {};
    const proactivityKpis = summary?.proactivity_kpis || null;
    const periodInfo = getPeriodDates(period, customFrom, customTo);
    const dashboardSellers = storeId ? sellers.filter((s) => s.store_id === storeId) : sellers;
    const selectedStoreName = storeId ? context.stores?.find((s) => s.id === storeId)?.name : null;
    const count = (st) => dashboardSellers.filter((s) => s.current_status === st).length;
    const awayCount = dashboardSellers.filter((s) => AWAY.includes(s.current_status)).length;

    // Legacy KPIs (quando dashboards feature está OFF)
    const finishedTodayAtts = attendances.filter((a) => a.status === "FINISHED" && isToday(a.finished_at));
    const salesToday = finishedTodayAtts.filter((a) => a.result === "SALE");
    const totalSoldCents = salesToday.reduce((sum, a) => sum + (a.sale_amount_cents || 0), 0);
    const avgTicketCents = salesToday.length ? Math.round(totalSoldCents / salesToday.length) : 0;
    const conversion = finishedTodayAtts.length
        ? Math.round((salesToday.length / finishedTodayAtts.length) * 100)
        : 0;
    const inProgress = attendances.filter((a) => a.status === "IN_PROGRESS").length;
    const finishedToday = attendances.filter((a) => a.status === "FINISHED" && isToday(a.finished_at)).length;

    // Roles que podem ver o filtro de vendedor (não SELLERs)
    const canFilterSeller = !BLOCKED_ROLES.includes(userRole);

    return (
        <div data-testid="tenant-dashboard" className="dashboard-wide-shell animate-fade-in">
            {/* ── Hero verde Luppa ── */}
            <div className="rounded-[20px] bg-luppa-green p-7 sm:p-9 lg:p-10 mb-8 relative overflow-hidden">
                <div className="absolute inset-0 opacity-10 pointer-events-none" style={{
                    backgroundImage: "radial-gradient(circle at 20% 50%, rgba(255,255,255,0.4) 0%, transparent 50%), radial-gradient(circle at 80% 20%, rgba(255,255,255,0.2) 0%, transparent 40%)"
                }} />
                <div className="relative z-10">
                    <p className="text-white/65 text-sm font-semibold uppercase tracking-[0.1em] mb-2">Painel · Luppa</p>
                    <h1 className="text-4xl sm:text-5xl lg:text-6xl font-semibold text-white leading-tight">
                        {context.tenant.name}
                    </h1>
                    <p className="text-white/70 text-base md:text-lg mt-2">
                        Atualização automática a cada {DASHBOARD_REFRESH_LABEL}
                        {lastUpdated && <> · último update {lastUpdated.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}</>}
                    </p>
                </div>
            </div>

            {/* ── Métricas Operacionais ── */}
            <div className="metric-grid-wide">
                <Metric label="Unidades" value={context.stores?.length || 0} testId="metric-stores" />
                <Metric label="Vendedores" value={dashboardSellers.length} testId="metric-sellers" />
                <Metric label="Disponíveis" value={dashboardSellers.filter((s) => s.current_status === "AVAILABLE").length} testId="metric-available" accent="emerald" />
                {hasQueue && <Metric label="Na fila" value={dashboardSellers.filter((s) => s.current_status === "WAITING_IN_QUEUE").length} testId="metric-waiting" accent="purple" />}
                {hasQueue && <Metric label="Em atendimento" value={dashboardSellers.filter((s) => s.current_status === "SERVING").length} testId="metric-serving" accent="indigo" />}
                <Metric label="Fora / pausa" value={awayCount} testId="metric-away" accent="amber" />
                {context.features?.multi_equipes && <Metric label="Equipes" value={teams.length} testId="metric-teams" />}
                {hasQueue && !hasDashboards && (
                    <>
                        <Metric label="Em andamento" value={inProgress} testId="metric-att-progress" accent="indigo" />
                        <Metric label="Finalizados hoje" value={finishedToday} testId="metric-att-today" accent="emerald" />
                    </>
                )}
            </div>

            {/* ── KPIs Comerciais (dashboard aprimorado) ── */}
            {hasDashboards && (
                <div className="mt-8">
                    {/* Barra de filtros */}
                    <div className="flex flex-wrap items-end gap-4 mb-5 p-4 bg-luppa-list rounded-[12px] border border-border/40" data-testid="dashboard-filters-bar">
                        <PeriodSelector
                            period={period}
                            setPeriod={setPeriod}
                            customFrom={customFrom}
                            setCustomFrom={setCustomFrom}
                            customTo={customTo}
                            setCustomTo={setCustomTo}
                        />
                        <StoreSelector stores={context.stores || []} storeId={storeId} setStoreId={(value) => { setStoreId(value); setSellerId(null); }} />
                        {canFilterSeller && (
                            <SellerSelector
                                sellers={dashboardSellers}
                                sellerId={sellerId}
                                setSellerId={setSellerId}
                            />
                        )}
                        <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            className="gap-2"
                            onClick={refreshDashboard}
                            disabled={dashboardRefreshing}
                            data-testid="dashboard-refresh-button"
                        >
                            <RefreshCw size={14} className={dashboardRefreshing ? "animate-spin" : ""} /> Atualizar
                        </Button>
                        <div className="ml-auto" data-testid="dashboard-current-scope">
                            <p className="text-xs text-muted-foreground">
                                Exibindo: <span className="font-medium text-foreground">{periodInfo.label}</span>
                                {selectedStoreName && <> · <span className="font-medium text-foreground">{selectedStoreName}</span></>}
                                {sellerId && sellers.find(s => s.id === sellerId) && (
                                    <> · <span className="font-medium text-foreground">
                                        {sellers.find(s => s.id === sellerId)?.user?.name}
                                    </span></>
                                )}
                            </p>
                        </div>
                    </div>

                    {kpis ? (
                        <>
                            <div className="metric-grid-wide dashboard-kpi-grid">
                                <Metric label="Atendimentos" value={kpis.atendimentos_hoje} testId="metric-att-hoje" loading={summaryLoading} />
                                <Metric label="Em andamento" value={kpis.em_andamento} testId="metric-att-progress" accent="indigo" loading={summaryLoading} />
                                <Metric label="Vendas" value={kpis.vendas_hoje} testId="metric-sales-today" accent="emerald" loading={summaryLoading} />
                                <Metric label="Total vendido" value={centsToBRL(kpis.total_vendido_cents)} testId="metric-total-sold" accent="indigo" loading={summaryLoading} />
                                <Metric label="Ticket médio" value={centsToBRL(kpis.ticket_medio_cents)} testId="metric-avg-ticket" accent="purple" loading={summaryLoading} />
                                <Metric label="Conversão" value={`${kpis.conversao_pct}%`} testId="metric-conversion" accent="amber" loading={summaryLoading} />
                                <Metric
                                    label="PA"
                                    value={kpis.pa != null ? Number(kpis.pa).toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : "0,00"}
                                    testId="metric-pa"
                                    accent="emerald"
                                    loading={summaryLoading}
                                />
                                <Metric
                                    label="Qtd. produtos"
                                    value={kpis.total_produtos_vendidos != null ? kpis.total_produtos_vendidos : 0}
                                    testId="metric-total-products"
                                    accent="indigo"
                                    loading={summaryLoading}
                                />
                            </div>

                            {hasOpportunityFlow && (
                                <OpportunityFlowWidget
                                    data={opportunityFlow}
                                    loading={opportunityLoading}
                                    periodLabel={periodInfo.label}
                                    tenantSlug={tenantSlug}
                                />
                            )}

                            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mt-4">
                                <Card className="border border-border shadow-sm">
                                    <CardContent className="p-5 flex items-start gap-4">
                                        <div className="w-9 h-9 rounded-[8px] bg-accent flex items-center justify-center flex-shrink-0">
                                            <Clock size={16} strokeWidth={1.5} className="text-foreground/70" />
                                        </div>
                                        <div className="min-w-0">
                                            <p className="micro-label">Tempo médio atend.</p>
                                            <div className="font-mono font-semibold text-2xl mt-1 tracking-tight" data-testid="metric-avg-duration">
                                                {summaryLoading ? <Skeleton className="h-8 w-20" /> : fmtDuration(kpis.tempo_medio_segundos)}
                                            </div>
                                        </div>
                                    </CardContent>
                                </Card>

                                <Card className="border border-border shadow-sm col-span-1 lg:col-span-2">
                                    <CardContent className="p-5">
                                        <div className="flex items-center gap-2 mb-3">
                                            <Users size={14} strokeWidth={1.5} className="text-muted-foreground" />
                                            <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground">Vendedores por status</p>
                                        </div>
                                        {summaryLoading ? (
                                            <Skeleton className="h-8 w-full" />
                                        ) : (
                                            <div className="flex flex-wrap gap-2">
                                                {Object.entries(sellersByStatus).map(([st, cnt]) => (
                                                    <Badge key={st} variant="secondary" className="text-xs" data-testid={`seller-status-badge-${st.toLowerCase()}`}>
                                                        {SELLER_STATUS_PT[st] || translateTechnicalValue(st)}: {cnt}
                                                    </Badge>
                                                ))}
                                                {Object.keys(sellersByStatus).length === 0 && (
                                                    <p className="text-sm text-muted-foreground">Sem vendedores ativos.</p>
                                                )}
                                            </div>
                                        )}
                                    </CardContent>
                                </Card>
                            </div>

                            {/* Tendência do período */}
                            {weekTrend.length > 0 && (
                                <Card className="border border-border shadow-sm mt-4">
                                    <CardContent className="p-5">
                                        <div className="flex items-center gap-2 mb-1">
                                            <TrendingUp size={14} strokeWidth={1.5} className="text-muted-foreground" />
                                            <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground">
                                                Tendência — {periodInfo.label}
                                            </p>
                                        </div>
                                        <p className="text-xs text-muted-foreground mb-5">Atendimentos e vendas por dia.</p>
                                        {summaryLoading ? (
                                            <Skeleton className="h-48 w-full" />
                                        ) : (
                                            <ResponsiveContainer width="100%" height={200}>
                                                <BarChart data={weekTrend} margin={{ top: 8, right: 8, bottom: 0, left: -10 }}>
                                                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                                                    <XAxis dataKey="date" tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} interval="preserveStartEnd" />
                                                    <YAxis tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} width={30} />
                                                    <Tooltip content={<TrendTooltip />} cursor={{ fill: "hsl(var(--muted))" }} />
                                                    <Bar dataKey="atendimentos" name="Atendimentos" fill="hsl(var(--chart-2))" radius={[2, 2, 0, 0]} maxBarSize={24} />
                                                    <Bar dataKey="vendas" name="Vendas" fill="hsl(var(--chart-1))" radius={[2, 2, 0, 0]} maxBarSize={24} />
                                                </BarChart>
                                            </ResponsiveContainer>
                                        )}
                                    </CardContent>
                                </Card>
                            )}
                        </>
                    ) : (
                        summaryLoading && (
                            <div className="metric-grid-sm">
                                {[...Array(6)].map((_, i) => (
                                    <Card key={i} className="border border-border shadow-sm">
                                        <CardContent className="p-5">
                                            <Skeleton className="h-4 w-20 mb-2" />
                                            <Skeleton className="h-8 w-16" />
                                        </CardContent>
                                    </Card>
                                ))}
                            </div>
                        )
                    )}
                </div>
            )}

            {/* ── KPIs Comerciais (legado — quando dashboards feature está OFF) ── */}
            {!hasDashboards && hasQueue && (
                <div className="mt-8">
                    <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground mb-4">Comercial · hoje</p>
                    <div className="metric-grid">
                        <Metric label="Vendas do dia" value={salesToday.length} testId="metric-sales-today" accent="emerald" />
                        <Metric label="Total vendido" value={centsToBRL(totalSoldCents)} testId="metric-total-sold" accent="indigo" />
                        <Metric label="Ticket médio" value={centsToBRL(avgTicketCents)} testId="metric-avg-ticket" accent="purple" />
                        <Metric label="Conversão" value={`${conversion}%`} testId="metric-conversion" accent="amber" />
                    </div>
                </div>
            )}

            {/* ── Metas ativas (widget) ── */}
            {hasMetas && activeGoals.length > 0 && (
                <div className="mt-8">
                    <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                            <Target size={14} strokeWidth={1.5} className="text-muted-foreground" />
                            <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground">Metas ativas</p>
                        </div>
                        <Link to={`/${tenantSlug}/goals`} className="text-xs text-muted-foreground hover:text-foreground transition-colors">Ver todas →</Link>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {activeGoals.map((g) => {
                            const pct = g.progress_percent || 0;
                            const color = pct >= 100 ? "bg-luppa-green" : pct >= 70 ? "bg-luppa-purple" : pct >= 40 ? "bg-amber-500" : "bg-luppa-error/70";
                            return (
                                <Link key={g.id} to={`/${tenantSlug}/goals/${g.id}`}>
                                    <Card className="border border-border shadow-sm hover:shadow-md transition-all cursor-pointer">
                                        <CardContent className="p-4">
                                            <p className="text-sm font-medium truncate mb-2">{g.title}</p>
                                            <div className="flex items-center justify-between text-xs text-muted-foreground mb-1.5">
                                                <span>{GOAL_TYPE_PT[g.type] || g.type}</span>
                                                <span className="font-bold text-foreground">{pct}%</span>
                                            </div>
                                            <div className="w-full bg-border rounded-full h-1.5">
                                                <div className={`h-1.5 rounded-full ${color}`} style={{ width: `${Math.min(pct, 100)}%` }} />
                                            </div>
                                        </CardContent>
                                    </Card>
                                </Link>
                            );
                        })}
                    </div>
                </div>
            )}

            {/* ── Top ranking (widget) ── */}
            {hasRankings && topRanking.length > 0 && (
                <div className="mt-8">
                    <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                            <Trophy size={14} strokeWidth={1.5} className="text-muted-foreground" />
                            <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground">Top vendedores (receita)</p>
                        </div>
                        <Link to={`/${tenantSlug}/rankings`} className="text-xs text-muted-foreground hover:text-foreground transition-colors">Ver ranking completo →</Link>
                    </div>
                    <Card className="border border-border shadow-sm">
                        <CardContent className="p-0">
                            {topRanking.map((item, i) => (
                                <div
                                    key={item.seller_id || i}
                                    className={`flex items-center gap-4 px-4 py-3 ${i < topRanking.length - 1 ? "border-b border-border" : ""} ${i === 0 ? "bg-amber-50/50" : ""}`}
                                >
                                    <span className={`text-sm font-bold w-6 text-center ${i === 0 ? "text-amber-500" : "text-muted-foreground"}`}>{item.position}°</span>
                                    <span className="flex-1 text-sm font-medium truncate">{item.seller_name}</span>
                                    <span className="text-sm font-mono text-muted-foreground">{item.metric_label}</span>
                                </div>
                            ))}
                        </CardContent>
                    </Card>
                </div>
            )}

            {/* ─── Widgets Proatividade ── */}
            {proactivityKpis && (
                <div className="mt-6">
                    <div className="flex items-center gap-2 mb-3">
                        <Zap size={14} className="text-muted-foreground" />
                        <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground">
                            Proatividade · {periodInfo.label}
                        </p>
                    </div>
                    <div className="metric-grid-sm">
                        {[
                            { label: "Abordagens", value: proactivityKpis.total_hoje, color: "" },
                            { label: "Abertas", value: proactivityKpis.abertas, color: "text-luppa-purple" },
                            { label: "Em atend.", value: proactivityKpis.convertidas_atendimento, color: "text-luppa-purple" },
                            { label: "Vendas", value: proactivityKpis.convertidas_venda, color: "text-luppa-green" },
                            { label: "Sem venda", value: proactivityKpis.sem_venda, color: "text-luppa-error" },
                            { label: "Conversão", value: `${proactivityKpis.conversao_venda_pct}%`, color: "text-luppa-purple" },
                        ].map((item, i) => (
                            <Card key={i} className="border border-border shadow-sm min-w-0">
                                <CardContent className="p-4">
                                    <p className="text-xs uppercase tracking-[0.08em] text-muted-foreground truncate">{item.label}</p>
                                    <p className={`font-sans text-2xl font-bold tracking-tighter mt-1 ${item.color}`}>{item.value}</p>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
}
