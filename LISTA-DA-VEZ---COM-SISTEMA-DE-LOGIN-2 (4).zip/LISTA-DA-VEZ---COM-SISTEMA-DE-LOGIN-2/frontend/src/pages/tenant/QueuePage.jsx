import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import api, { extractError } from "@/lib/api";
import { centsToBRL, brlToCents } from "@/lib/money";
import { SELLER_STATUS_PT, fmtDateTime, translateTechnicalValue } from "@/lib/i18n";
import { useAuth } from "@/context/AuthContext";
import { useTenant } from "@/context/TenantContext";
import { useRealtimeStoreEvents } from "@/hooks/useRealtimeStoreEvents";
import { PageHeader, EmptyState, SellerAvatar } from "@/components/Common";
import { GoalCelebrationBanner } from "@/components/GoalCelebrationBanner";
import { MotivosPerdaSelector, encontrarMotivoPerda, useMotivosPerdaOpcoes } from "@/components/MotivosPerdaSelector";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
    Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
    Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter, DialogTrigger,
} from "@/components/ui/dialog";
import {
    AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
    AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
    AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
    Play, LogIn, LogOut, Coffee, RotateCcw, ChevronUp, ChevronDown,
    Plus, CheckCircle2, XCircle, Clock, Wifi, WifiOff, RefreshCw, Trash2, Zap,
    GripVertical, AlertTriangle, Wrench, Sunset, UndoDot, Star, Users, Copy, MoreVertical,
} from "lucide-react";
import { toast } from "sonner";
import {
    DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const MANAGER_ROLES = ["TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER"];
const AWAY_OPTIONS = ["BREAK", "LUNCH", "MEETING", "TRAINING", "ABSENT", "OFFLINE"];
const PREFERENCE_RULE_LABEL = {
    TO_TOP: "Voltar ao topo",
    PREVIOUS_POSITION: "Voltar à posição anterior",
    TO_END: "Ir ao final",
    CONSUME_TURN: "Perder a vez",
};

// ─── Janela de Saída: motivos em português ────────────────────────────────────
const MOTIVOS_SAIDA = [
    { value: "LANCHE_OU_ALMOCO", label: "Lanche ou almoço", icon: Coffee, desc: "Pausa para refeição. Você retornará ao final da fila." },
    { value: "ATIVIDADE_OPERACIONAL", label: "Atividade operacional", icon: Wrench, desc: "Você permanece na fila, mas ficará suspenso temporariamente das chamadas." },
    { value: "ENCERRAR_DIA", label: "Encerrar o dia", icon: Sunset, desc: "Sua jornada será encerrada. Você poderá desfazer por 20 segundos." },
];

// Mapeamento estado interno → rótulo em português para exibição
const ESTADO_PT = {
    AVAILABLE: "Disponível",
    WAITING_IN_QUEUE: "Na Fila Geral",
    SERVING: "Em atendimento",
    BREAK: "Fora — Lanche/Almoço",
    LUNCH: "Fora — Lanche/Almoço",
    OFFLINE: "Fora — Encerrado",
    MEETING: "Fora — Reunião",
    TRAINING: "Fora — Treinamento",
    ABSENT: "Fora — Ausente",
    BLOCKED: "Bloqueado",
};

// Cor do cartão por sub-estado
function getEntryCardClass(entry) {
    if (entry.em_atividade_operacional) return "border-amber-300/60 bg-amber-50/40 opacity-70";
    if (entry.position === 1) return "border-primary/30 bg-primary/10";
    return "border-border bg-card";
}


function fmtDuration(iso) {
    if (!iso) return "—";
    const secs = Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 1000));
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    if (m < 60) return `${m}m ${s}s`;
    const h = Math.floor(m / 60);
    return `${h}h ${m % 60}m`;
}

const EVENT_LABEL = {
    QUEUE_CREATED: "Fila criada", QUEUE_UPDATED: "Fila atualizada",
    SELLER_JOINED: "entrou na fila", SELLER_LEFT: "saiu da fila",
    SELLER_STATUS_CHANGED: "mudou de status", SELLER_ASSIGNED: "atribuído",
    ATTENDANCE_STARTED: "iniciou atendimento", ATTENDANCE_FINISHED: "finalizou atendimento",
    SELLER_RETURNED_TO_END: "voltou ao fim da fila", QUEUE_REORDERED: "Fila reordenada",
    SELLER_SKIPPED: "pulado", ATTENDANCE_CANCELLED: "atendimento cancelado",
};

export default function QueuePage() {
    const { tenantSlug, storeId: routeStoreId } = useParams();
    const { user } = useAuth();
    const { context } = useTenant();
    const role = context?.user_role;
    const isManager = MANAGER_ROLES.includes(role);
    const isSupervisor = role === "SUPERVISOR";

    const [storeId, setStoreId] = useState(routeStoreId || "");
    const [queueId, setQueueId] = useState(null);
    const [state, setState] = useState(null);
    const [loading, setLoading] = useState(true);
    const [busy, setBusy] = useState(false);
    const [lossReasons, setLossReasons] = useState([]);
    const [products, setProducts] = useState([]);
    const [finishTarget, setFinishTarget] = useState(null);
    const [quickOpen, setQuickOpen] = useState(false);
    const [preferenceOpen, setPreferenceOpen] = useState(false);
    const [quickModalKey, setQuickModalKey] = useState(0);

    // ── Janela de Saída ────────────────────────────────────────────
    const [janelaSaida, setJanelaSaida] = useState(null); // { seller_id, seller_name }

    // ── Drag-and-drop ──────────────────────────────────────────────
    const [drag, setDrag] = useState(null); // { seller_id, name, source }
    const [dropZone, setDropZone] = useState(null); // "fila" | "fora" | "disponivel"
    const dragGhostRef = useRef(null);
    const pendingDragRef = useRef(null);
    const undoRef = useRef(null); // referência para o toast de Desfazer ativo
    const [ghostPos, setGhostPos] = useState({ x: 0, y: 0 });

    const stores = context?.stores || [];
    const detailedEnabled = !!context?.features?.vendas_detalhadas;
    const lossReasonsEnabled = !!context?.features?.motivos_nao_venda;
    const registroRapidoEnabled = !!context?.features?.registro_rapido;

    useEffect(() => {
        if (!storeId && stores.length) setStoreId(stores[0].id);
    }, [stores, storeId]);

    useEffect(() => {
        if (lossReasonsEnabled) {
            api.get(`/tenants/${tenantSlug}/loss-reasons`).then(({ data }) => setLossReasons(data.filter((r) => r.active !== false))).catch(() => {});
        }
        if (detailedEnabled) {
            api.get(`/tenants/${tenantSlug}/products?active=true`).then(({ data }) => setProducts(data)).catch(() => {});
        }
    }, [tenantSlug, detailedEnabled, lossReasonsEnabled]);

    const fetchState = useCallback(async (silent = false) => {
        if (!storeId) return;
        if (!silent) setLoading(true);
        try {
            const url = `/tenants/${tenantSlug}/stores/${storeId}/queue${queueId ? `?queue_id=${queueId}` : ""}`;
            const { data } = await api.get(url);
            setState(data);
            if (!queueId && data.queue) setQueueId(data.queue.id);
        } catch (e) {
            if (!silent) toast.error(extractError(e, "Erro ao carregar a fila"));
        } finally {
            if (!silent) setLoading(false);
        }
    }, [tenantSlug, storeId, queueId]);

    useEffect(() => {
        fetchState();
    }, [fetchState]);

    const realtime = useRealtimeStoreEvents({
        tenantSlug,
        storeId,
        enabled: !!context?.features?.tempo_real,
        onRefresh: () => fetchState(true),
    });

    const ownSellerId = useMemo(() => {
        if (!state) return null;
        const all = [
            ...(state.entries || []), ...(state.available_sellers || []),
            ...(state.serving_sellers || []), ...(state.away_sellers || []),
        ];
        const me = all.find((s) => s.user_id === user?.id);
        return me?.seller_id || null;
    }, [state, user]);

    const preferenceEnabled = state?.effective_settings?.preference_enabled !== false;
    const preferenceReturnRule = state?.effective_settings?.preference_return_rule || "PREVIOUS_POSITION";

    const act = async (fn) => {
        if (busy) return;
        setBusy(true);
        try {
            await fn();
            await fetchState(true);
        } catch (e) {
            toast.error(extractError(e, "Não foi possível concluir a ação"));
        } finally {
            setBusy(false);
        }
    };

    // ── Ação com Desfazer de 20s ───────────────────────────────────
    const actWithUndo = async (fn, successLabel, undoFn = null) => {
        if (busy) return;
        setBusy(true);
        try {
            await fn();
            await fetchState(true);
            if (undoRef.current) {
                toast.dismiss(undoRef.current);
                undoRef.current = null;
            }
            if (undoFn) {
                const toastId = toast.custom(
                    (t) => <UndoToast toastId={t} message={successLabel} onUndo={() => act(undoFn)} />,
                    { duration: 20000 }
                );
                undoRef.current = toastId;
            } else {
                toast.success(successLabel);
            }
        } catch (e) {
            toast.error(extractError(e, "Não foi possível concluir a ação"));
        } finally {
            setBusy(false);
        }
    };

    const base = `/tenants/${tenantSlug}/stores/${storeId}`;

    // join com desfazer: undo → leave
    const join = (seller_id) => actWithUndo(
        async () => { await api.post(`${base}/queue/join`, { queue_id: queueId, seller_id }); },
        "Entrou na Fila Geral.",
        async () => { await api.post(`${base}/queue/leave`, { queue_id: queueId, seller_id }); }
    );

    const leave = (seller_id) => act(async () => { await api.post(`${base}/queue/leave`, { queue_id: queueId, seller_id }); toast.success("Saiu da fila."); });
    const startAtt = (seller_id) => act(async () => { await api.post(`${base}/queue/start-attendance`, { queue_id: queueId, seller_id }); toast.success("Atendimento iniciado."); });
    const startPreferenceAtt = (payload) => act(async () => {
        const idemSeller = payload.seller_id || ownSellerId || "self";
        await api.post(`${base}/queue/start-preference-attendance`, { queue_id: queueId, ...payload }, { headers: { "Idempotency-Key": `pref-${Date.now()}-${idemSeller}` } });
        toast.success("Atendimento por preferência iniciado.");
        setPreferenceOpen(false);
    });
    const markAway = (seller_id, new_status) => act(async () => { await api.post(`${base}/queue/mark-away`, { seller_id, new_status, reason: "Pausa/ausência" }); toast.success("Status atualizado."); });
    const returnSeller = (seller_id, join_queue) => act(async () => { await api.post(`${base}/queue/return`, { seller_id, join_queue, queue_id: queueId, reason: "Retorno" }); toast.success(join_queue ? "Retornou à fila." : "Disponível novamente."); });
    const cancelAtt = (attendance_id, reason) => act(async () => { await api.post(`/tenants/${tenantSlug}/attendances/${attendance_id}/cancel`, { reason }); toast.success("Atendimento cancelado."); });

    // ── Novos endpoints — Prompt 2 ──────────────────────────────────────────────

    // sairDaFila com desfazer:
    //   LANCHE_OU_ALMOCO → undo: retornarDaFora
    //   ATIVIDADE_OPERACIONAL → undo: retornarOperacao
    //   ENCERRAR_DIA → undo: nova jornada + retorno à Fila Geral
    const sairDaFila = (seller_id, motivo) => {
        const labels = {
            LANCHE_OU_ALMOCO: "Saiu para lanche/almoço.",
            ATIVIDADE_OPERACIONAL: "Em atividade operacional.",
            ENCERRAR_DIA: "Jornada encerrada.",
        };
        let undoFn = null;
        if (motivo === "LANCHE_OU_ALMOCO") {
            undoFn = async () => { await api.post(`${base}/queue/retornar-da-fora`, { seller_id, queue_id: queueId }); };
        } else if (motivo === "ATIVIDADE_OPERACIONAL") {
            undoFn = async () => { await api.post(`${base}/queue/retornar-operacao`, { seller_id }); };
        } else if (motivo === "ENCERRAR_DIA") {
            undoFn = async () => {
                await api.post(`${base}/queue/nova-jornada`, { seller_id });
                await api.post(`${base}/queue/join`, { queue_id: queueId, seller_id });
            };
        }
        return actWithUndo(
            async () => { await api.post(`${base}/queue/sair-da-fila`, { seller_id, motivo, queue_id: queueId }); },
            labels[motivo] || "Status atualizado.",
            undoFn
        );
    };

    // retornarOperacao com desfazer → undo: atividade operacional
    const retornarOperacao = (seller_id) => actWithUndo(
        async () => { await api.post(`${base}/queue/retornar-operacao`, { seller_id }); },
        "Retornou à operação — pronto para chamadas.",
        async () => { await api.post(`${base}/queue/sair-da-fila`, { seller_id, motivo: "ATIVIDADE_OPERACIONAL", queue_id: queueId }); }
    );

    const novaJornada = (seller_id) => act(async () => {
        await api.post(`${base}/queue/nova-jornada`, { seller_id });
        toast.success("Nova jornada iniciada — vendedor em Disponível.");
    });
    const retornarDaFora = (seller_id) => act(async () => {
        await api.post(`${base}/queue/retornar-da-fora`, { seller_id, queue_id: queueId });
        toast.success("Retornou ao final da Fila Geral.");
    });

    // ── Drag-and-drop ──────────────────────────────────────────────
    const startDrag = useCallback((e, seller) => {
        if (e.button != null && e.button !== 0) return;
        e.preventDefault();
        e.stopPropagation();
        e.currentTarget.setPointerCapture?.(e.pointerId);
        pendingDragRef.current = {
            seller: { seller_id: seller.seller_id, name: seller.name, source: seller._source },
            startX: e.clientX,
            startY: e.clientY,
        };
        setGhostPos({ x: e.clientX, y: e.clientY });
    }, []);

    const moveDrag = useCallback((e) => {
        let activeDrag = drag;
        const pending = pendingDragRef.current;
        if (!activeDrag && pending) {
            const dx = Math.abs(e.clientX - pending.startX);
            const dy = Math.abs(e.clientY - pending.startY);
            if (Math.max(dx, dy) < 8) return;
            activeDrag = pending.seller;
            pendingDragRef.current = null;
            setDrag(activeDrag);
        }
        if (!activeDrag) return;
        e.preventDefault();
        setGhostPos({ x: e.clientX, y: e.clientY });
        // Identifica a zona de destino
        const els = document.elementsFromPoint(e.clientX, e.clientY);
        const zone = els.find(el => el.dataset.dropzone);
        setDropZone(zone ? zone.dataset.dropzone : null);
    }, [drag]);

    const endDrag = useCallback((e) => {
        pendingDragRef.current = null;
        if (!drag) return;
        const source = drag.source;
        const target = dropZone;
        const seller_id = drag.seller_id;
        const name = drag.name;

        setDrag(null);
        setDropZone(null);

        if (!target || target === source) return;

        if (source === "disponivel" && target === "fila") {
            join(seller_id);
        } else if (source === "fila" && target === "fora") {
            // Abre Janela de Saída
            setJanelaSaida({ seller_id, seller_name: name });
        } else if (source === "fora" && target === "fila") {
            // Retorno da fora — usa retornarDaFora (bloqueia se jornada encerrada)
            retornarDaFora(seller_id);
        } else if (source === "disponivel" && target === "fora") {
            toast.error("O vendedor precisa entrar na Fila Geral antes de sair da operação.");
        } else if (source === "atendimento" && target === "fora") {
            toast.error("Não é possível sair enquanto há um atendimento em andamento.");
        }
    }, [drag, dropZone, base, queueId, act, retornarDaFora]); // eslint-disable-line react-hooks/exhaustive-deps

    const reorder = (sellerId, dir) => {
        const ids = (state.entries || []).map((e) => e.seller_id);
        const idx = ids.indexOf(sellerId);
        const swap = dir === "up" ? idx - 1 : idx + 1;
        if (swap < 0 || swap >= ids.length) return;
        [ids[idx], ids[swap]] = [ids[swap], ids[idx]];
        act(async () => { await api.patch(`${base}/queue/reorder`, { queue_id: queueId, ordered_seller_ids: ids }); });
    };

    if (!context) return null;
    const entries = state?.entries || [];
    const queues = state?.queues || [];
    const isSeller = role === "SELLER";
    const ownEntry = entries.find((e) => e.seller_id === ownSellerId);
    const ownServing = (state?.serving_sellers || []).find((s) => s.seller_id === ownSellerId);
    const ownAway = (state?.away_sellers || []).find((s) => s.seller_id === ownSellerId);
    const sellerPreferenceDisabledReason = !preferenceEnabled
        ? "Atendimento por preferência desabilitado nesta unidade."
        : ownServing
            ? "Você já está em atendimento."
            : (ownEntry?.em_atividade_operacional || ownAway?.em_atividade_operacional)
                ? "Você está em pausa."
                : ownAway?.jornada_encerrada
                    ? "Não existe jornada ativa."
                    : !ownEntry
                        ? "Você não está disponível."
                        : "";
    const firstStartableEntry = entries.find((entry) => !entry.em_atividade_operacional);
    const firstStartableSellerId = firstStartableEntry?.seller_id || null;

    return (
        <div data-testid="queue-page">
            <PageHeader eyebrow="Operação" title="Lista da Vez" description="Fila de atendimento em tempo real.">
                <div className="flex flex-wrap gap-2 items-center">
                    <RealtimeIndicator status={realtime.connectionStatus} onReconnect={realtime.reconnect} />
                    {stores.length > 1 && (
                        <Select value={storeId} onValueChange={(v) => { setStoreId(v); setQueueId(null); }}>
                            <SelectTrigger className="w-full sm:w-44" data-testid="queue-store-select"><SelectValue placeholder="Unidade" /></SelectTrigger>
                            <SelectContent>{stores.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent>
                        </Select>
                    )}
                    {queues.length > 1 && (
                        <Select value={queueId || ""} onValueChange={setQueueId}>
                            <SelectTrigger className="w-full sm:w-44" data-testid="queue-select"><SelectValue placeholder="Fila" /></SelectTrigger>
                            <SelectContent>{queues.map((q) => <SelectItem key={q.id} value={q.id}>{q.name}</SelectItem>)}</SelectContent>
                        </Select>
                    )}
                    {isManager && registroRapidoEnabled && (
                        <Button variant="outline" className="gap-2 min-h-[44px]" onClick={() => { setQuickModalKey((v) => v + 1); setQuickOpen(true); }} data-testid="quick-attendance-btn">
                            <Zap size={16} /> Registro Rápido
                        </Button>
                    )}
                    {(isManager || isSeller) && (
                        <Button
                            variant="outline"
                            className="gap-2 min-h-[44px] border-luppa-lilac text-luppa-purple hover:bg-luppa-lilac/40"
                            disabled={isSeller && !!sellerPreferenceDisabledReason}
                            title={isSeller ? (sellerPreferenceDisabledReason || "Iniciar atendimento por preferência") : "Iniciar atendimento por preferência"}
                            onClick={() => setPreferenceOpen(true)}
                            data-testid="preference-attendance-btn"
                        >
                            <Star size={16} /> {isSeller ? "Iniciar preferência" : "Preferência"}
                        </Button>
                    )}
                    {isSeller && sellerPreferenceDisabledReason && (
                        <span className="text-xs text-muted-foreground max-w-48" data-testid="preference-disabled-reason">{sellerPreferenceDisabledReason}</span>
                    )}
                    {isManager && context.features?.multi_filas && (
                        <CreateQueueDialog base={base} onCreated={() => fetchState()} />
                    )}
                </div>
            </PageHeader>

            {loading && !state ? (
                <p className="text-sm text-muted-foreground">Carregando…</p>
            ) : (
                <>
                    {/* Celebração de meta — só aparece para vendedores */}
                    {isSeller && <GoalCelebrationBanner />}

                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6"
                        onPointerMove={moveDrag} onPointerUp={endDrag} onPointerCancel={endDrag} onPointerLeave={endDrag}>
                    {/* Ghost drag element */}
                    {drag && (
                        <div ref={dragGhostRef} style={{ position: "fixed", left: ghostPos.x + 12, top: ghostPos.y - 18, zIndex: 9999, pointerEvents: "none" }}
                            className="bg-card border border-primary shadow-xl rounded-sm px-3 py-2 text-sm font-medium opacity-90 flex items-center gap-2">
                            <GripVertical size={14} className="text-muted-foreground" />
                            {drag.name}
                        </div>
                    )}
                    {/* Fila + Em atendimento — lado a lado */}
                    <div className="lg:col-span-2 grid grid-cols-1 lg:grid-cols-2 gap-4 items-start">
                        {/* Fila principal */}
                        <div data-dropzone="fila"
                            className={`rounded-lg transition-colors ${drag?.source === "disponivel" ? "ring-2 ring-primary/50 bg-primary/5" : ""}`}>
                        <Card className="border border-border shadow-sm">
                            <CardContent className="p-6">
                                <div className="flex items-center justify-between mb-4">
                                    <div>
                                        <p className="micro-label">Fila Geral</p>
                                        <h2 className="font-sans text-xl font-semibold" data-testid="queue-name">{state?.queue?.name}</h2>
                                    </div>
                                    <Badge variant="secondary" data-testid="queue-count">{entries.length} aguardando</Badge>
                                </div>
                                {drag?.source === "disponivel" && (
                                    <div className="mb-3 p-3 rounded-sm border-2 border-dashed border-primary/40 text-center text-xs text-primary font-medium bg-primary/5">
                                        Solte aqui para entrar na Fila Geral
                                    </div>
                                )}
                                {entries.length === 0 && !drag ? (
                                    <EmptyState title="Fila vazia" description="Nenhum vendedor aguardando no momento." />
                                ) : (
                                    <div className="space-y-2">
                                        {entries.map((e, i) => {
                                            const mine = e.seller_id === ownSellerId;
                                            const first = e.position === 1;
                                            const emAtividade = !!e.em_atividade_operacional;
                                            const canStartAttendance = isManager || (mine && e.seller_id === firstStartableSellerId);
                                            const canDrag = (mine || isManager || isSupervisor) && !e.em_atividade_operacional;
                                            return (
                                                <div key={e.id} data-testid={`queue-entry-${e.position}`}
                                                    className={`flex items-center gap-2 sm:gap-4 p-3 rounded-sm border transition-colors ${getEntryCardClass(e)}`}>
                                                    <div className={`w-9 h-9 flex-shrink-0 flex items-center justify-center rounded-full font-bold text-sm ${first ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"}`} data-testid={`queue-pos-${e.position}`}>
                                                        {e.position}
                                                    </div>
                                                    {/* Drag handle */}
                                                    {canDrag && (
                                                        <div className="cursor-grab active:cursor-grabbing touch-none select-none flex-shrink-0"
                                                            title="Arraste para Fora"
                                                            role="button"
                                                            tabIndex={0}
                                                            aria-label={`Arrastar ${e.name} para outra área`}
                                                            data-testid={`queue-drag-handle-${e.position}`}
                                                            onPointerDown={(ev) => startDrag(ev, { ...e, _source: "fila" })}>
                                                            <GripVertical size={16} className="text-muted-foreground/60" />
                                                        </div>
                                                    )}
                                                    <div className="flex-1 min-w-0">
                                                        <div className="flex items-center gap-2 min-w-0">
                                                            <SellerAvatar name={e.name || "?"} src={e.avatar_url} size={28} />
                                                            <p className="font-medium truncate">{e.name} {mine && <span className="text-xs text-primary font-medium">(você)</span>}</p>
                                                        </div>
                                                        <p className="text-xs text-muted-foreground truncate">{e.team_name || "Sem equipe"} · <Clock size={11} className="inline mr-0.5" />{fmtDuration(e.entered_at)}</p>
                                                        {emAtividade && (
                                                            <Badge variant="outline" className="mt-1 text-[10px] border-amber-400 text-amber-700 bg-amber-50 gap-1">
                                                                <Wrench size={10} /> Em atividade operacional
                                                            </Badge>
                                                        )}
                                                    </div>
                                                    <div className="flex items-center gap-1 flex-shrink-0">
                                                        {emAtividade ? (
                                                            // Botão retornar operação
                                                            (mine || isManager || isSupervisor) && (
                                                                <Button size="sm" variant="outline" disabled={busy} onClick={() => retornarOperacao(e.seller_id)} className="gap-1 min-h-[44px] text-amber-700 border-amber-300" data-testid={`retornar-operacao-${e.position}`}>
                                                                    <UndoDot size={14} /> Retornar à operação
                                                                </Button>
                                                            )
                                                        ) : (
                                                            <>
                                                                {(isManager || mine) && (
                                                                    <Button size="sm" className="gap-1 min-h-[44px]" disabled={busy || !canStartAttendance} onClick={() => startAtt(e.seller_id)} data-testid={`start-att-${e.position}`}>
                                                                        <Play size={14} /> Iniciar
                                                                    </Button>
                                                                )}
                                                                {(isManager || isSupervisor || mine) && (
                                                                    <DropdownMenu>
                                                                        <DropdownMenuTrigger asChild>
                                                                            <Button size="icon" variant="ghost" className="min-h-[44px] min-w-[44px]" disabled={busy} data-testid={`queue-entry-menu-${e.position}`}>
                                                                                <MoreVertical size={16} />
                                                                            </Button>
                                                                        </DropdownMenuTrigger>
                                                                        <DropdownMenuContent align="end">
                                                                            {isManager && (
                                                                                <>
                                                                                    <DropdownMenuItem disabled={busy || i === 0} onClick={() => reorder(e.seller_id, "up")} data-testid={`reorder-up-${e.position}`}>
                                                                                        <ChevronUp size={14} className="mr-2" /> Mover para cima
                                                                                    </DropdownMenuItem>
                                                                                    <DropdownMenuItem disabled={busy || i === entries.length - 1} onClick={() => reorder(e.seller_id, "down")} data-testid={`reorder-down-${e.position}`}>
                                                                                        <ChevronDown size={14} className="mr-2" /> Mover para baixo
                                                                                    </DropdownMenuItem>
                                                                                </>
                                                                            )}
                                                                            <DropdownMenuItem
                                                                                onClick={() => setJanelaSaida({ seller_id: e.seller_id, seller_name: e.name })}
                                                                                data-testid={`sair-fila-${e.position}`}>
                                                                                <LogOut size={14} className="mr-2" /> Sair da fila
                                                                            </DropdownMenuItem>
                                                                        </DropdownMenuContent>
                                                                    </DropdownMenu>
                                                                )}
                                                            </>
                                                        )}
                                                    </div>
                                                </div>
                                            );
                                        })}
                                    </div>
                                )}
                            </CardContent>
                        </Card>
                        </div>

                        {/* Em atendimento */}
                        <GroupCard title="Em atendimento" testId="serving-card" count={state?.active_attendances?.length || 0}>
                            {(state?.active_attendances || []).length === 0 ? (
                                <p className="text-sm text-muted-foreground">Nenhum atendimento em andamento.</p>
                            ) : (
                                <div className="space-y-2">
                                    {state.active_attendances.map((a) => {
                                        const mine = a.seller_id === ownSellerId;
                                        return (
                                            <div key={a.id} className="flex items-center gap-3 p-3 rounded-sm border border-border bg-card" data-testid={`attendance-${a.id}`}>
                                                <div className="flex-1 min-w-0">
                                                    <div className="flex items-center gap-2 min-w-0">
                                                        <SellerAvatar name={a.seller?.name || "?"} src={a.seller?.avatar_url} size={26} />
                                                        <p className="font-medium truncate">{a.seller?.name}</p>
                                                    </div>
                                                    <p className="text-xs text-muted-foreground"><Clock size={11} className="inline" /> {fmtDuration(a.started_at)}{a.customer_name ? ` · ${a.customer_name}` : ""}</p>
                                                    {a.is_preference && (
                                                        <Badge variant="outline" className="mt-2 text-[10px] border-luppa-lilac text-luppa-purple bg-luppa-lilac gap-1" data-testid={`preference-badge-${a.id}`}>
                                                            <Star size={10} /> Preferência
                                                        </Badge>
                                                    )}
                                                </div>
                                                {(isManager || mine) && (
                                                    <Button size="sm" className="gap-1 min-h-[44px]" disabled={busy} onClick={() => setFinishTarget(a)} data-testid={`finish-att-btn-${a.id}`}>
                                                        <CheckCircle2 size={14} /> Finalizar
                                                    </Button>
                                                )}
                                                {isManager && (
                                                    <CancelButton onConfirm={(reason) => cancelAtt(a.id, reason)} disabled={busy} testId={`cancel-att-${a.id}`} />
                                                )}
                                            </div>
                                        );
                                    })}
                                </div>
                            )}
                        </GroupCard>
                    </div>

                    {/* Coluna lateral */}
                    <div className="space-y-4">
                        {/* ── Disponíveis ── */}
                        <div data-dropzone="disponivel"
                            className={`rounded-lg transition-colors ${drag?.source === "fila" || drag?.source === "atendimento" ? "ring-2 ring-destructive/20" : ""}`}>
                        <GroupCard title="Disponíveis" testId="available-card" count={state?.available_sellers?.length || 0}>
                            {(state?.available_sellers || []).length === 0 ? (
                                <p className="text-xs text-muted-foreground italic">Nenhum vendedor disponível.</p>
                            ) : (
                                <SellerMiniList
                                    sellers={(state?.available_sellers || []).map(s => ({ ...s, _source: "disponivel" }))}
                                    busy={busy} ownSellerId={ownSellerId}
                                    renderActions={(s) => (
                                        (isManager || isSupervisor || s.seller_id === ownSellerId) ? (
                                            <>
                                                <div className="cursor-grab touch-none select-none" title="Arraste para a Fila Geral"
                                                    role="button"
                                                    tabIndex={0}
                                                    aria-label={`Arrastar ${s.name} para a Fila Geral`}
                                                    data-testid={`available-drag-handle-${s.employee_code || s.seller_id}`}
                                                    onPointerDown={(ev) => startDrag(ev, { ...s, _source: "disponivel" })}>
                                                    <GripVertical size={15} className="text-muted-foreground/60" />
                                                </div>
                                                <Button size="sm" disabled={busy} onClick={() => join(s.seller_id)} className="gap-1 min-h-[44px]" data-testid={`join-${s.employee_code}`}><LogIn size={14} /> Entrar na fila</Button>
                                            </>
                                        ) : null
                                    )}
                                />
                            )}
                        </GroupCard>
                        </div>

                        {/* ── Fora ── */}
                        <div data-dropzone="fora"
                            className={`rounded-lg transition-colors ${drag?.source === "fila" ? "ring-2 ring-amber-400/60 bg-amber-50/20" : ""} ${drag?.source === "disponivel" ? "ring-2 ring-destructive/20 opacity-60" : ""}`}>
                        <GroupCard title="Fora" testId="away-card" count={state?.away_sellers?.length || 0}>
                            {drag?.source === "fila" && (
                                <div className="mb-3 p-3 rounded-sm border-2 border-dashed border-amber-400/60 text-center text-xs text-amber-700 font-medium bg-amber-50/50">
                                    Solte aqui para abrir a Janela de Saída
                                </div>
                            )}
                            {(state?.away_sellers || []).length === 0 && !drag ? (
                                <p className="text-xs text-muted-foreground italic">Nenhum vendedor fora da operação.</p>
                            ) : (
                                <SellerMiniList
                                    sellers={(state?.away_sellers || []).map(s => ({ ...s, _source: "fora" }))}
                                    busy={busy} ownSellerId={ownSellerId} showStatus
                                    renderActions={(s) => {
                                        const canAct = isManager || isSupervisor || s.seller_id === ownSellerId;
                                        const jEncerrada = !!s.jornada_encerrada;
                                        const motivo = s.motivo_saida;
                                        if (!canAct || s.current_status === "BLOCKED") return null;
                                        if (jEncerrada) {
                                            // Jornada encerrada → só nova jornada
                                            return (
                                                <Button size="sm" variant="outline" disabled={busy} onClick={() => novaJornada(s.seller_id)} className="gap-1 min-h-[44px] text-xs" data-testid={`nova-jornada-${s.employee_code}`}>
                                                    <LogIn size={13} /> Nova jornada
                                                </Button>
                                            );
                                        }
                                        // Retornar para o final da fila (LANCHE ou outros)
                                        return (
                                            <>
                                                <div className="cursor-grab touch-none select-none" title="Arraste para a Fila Geral"
                                                    role="button"
                                                    tabIndex={0}
                                                    aria-label={`Arrastar ${s.name} para a Fila Geral`}
                                                    data-testid={`away-drag-handle-${s.employee_code || s.seller_id}`}
                                                    onPointerDown={(ev) => startDrag(ev, { ...s, _source: "fora" })}>
                                                    <GripVertical size={15} className="text-muted-foreground/60" />
                                                </div>
                                                <Button size="sm" disabled={busy} onClick={() => retornarDaFora(s.seller_id)} className="gap-1 min-h-[44px] text-xs" data-testid={`retornar-${s.employee_code}`}>
                                                    <RotateCcw size={13} /> Retornar
                                                </Button>
                                            </>
                                        );
                                    }}
                                />
                            )}
                        </GroupCard>
                        </div>

                        {/* Histórico */}
                        <Card className="border border-border shadow-sm">
                            <CardContent className="p-6">
                                <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground mb-3">Histórico recente</p>
                                <div className="space-y-2 max-h-80 overflow-auto" data-testid="events-feed">
                                    {(state?.recent_events || []).length === 0 ? (
                                        <p className="text-sm text-muted-foreground">Sem eventos.</p>
                                    ) : state.recent_events.map((ev) => (
                                        <div key={ev.id} className="text-xs border-l-2 border-border pl-3 py-1">
                                            <p><span className="font-medium">{ev.seller_name || "Sistema"}</span> {EVENT_LABEL[ev.event_type] || translateTechnicalValue(ev.event_type)}</p>
                                            <p className="text-muted-foreground font-mono text-[10px]">{fmtDateTime(ev.created_at)}</p>
                                        </div>
                                    ))}
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                </div>
                </>
            )}

            {drag && (
                <div className="fixed inset-x-0 bottom-0 z-40 px-3 pb-3 pt-6 bg-gradient-to-t from-background via-background/95 to-transparent md:hidden" data-testid="mobile-drag-drop-overlay">
                    <div className="grid grid-cols-3 gap-2 rounded-xl border border-border bg-card p-2 shadow-2xl">
                        <div
                            data-dropzone="fila"
                            data-testid="mobile-dropzone-fila"
                            className={`min-h-14 rounded-lg border border-dashed flex items-center justify-center text-xs font-medium text-center px-2 ${dropZone === "fila" ? "bg-primary text-primary-foreground border-primary" : "bg-muted/40"}`}
                        >
                            Fila Geral
                        </div>
                        <div
                            data-dropzone="disponivel"
                            data-testid="mobile-dropzone-disponivel"
                            className={`min-h-14 rounded-lg border border-dashed flex items-center justify-center text-xs font-medium text-center px-2 ${dropZone === "disponivel" ? "bg-primary text-primary-foreground border-primary" : "bg-muted/40"}`}
                        >
                            Disponíveis
                        </div>
                        <div
                            data-dropzone="fora"
                            data-testid="mobile-dropzone-fora"
                            className={`min-h-14 rounded-lg border border-dashed flex items-center justify-center text-xs font-medium text-center px-2 ${dropZone === "fora" ? "bg-primary text-primary-foreground border-primary" : "bg-muted/40"}`}
                        >
                            Fora
                        </div>
                    </div>
                </div>
            )}

            {/* ── Janela de Saída (obrigatória ao sair da Fila Geral) ── */}
            {janelaSaida && (
                <JanelaDeSaida
                    sellerName={janelaSaida.seller_name}
                    onConfirm={(motivo) => {
                        setJanelaSaida(null);
                        sairDaFila(janelaSaida.seller_id, motivo);
                    }}
                    onCancel={() => setJanelaSaida(null)}
                />
            )}

            {finishTarget && (
                <FinishModal
                    tenantSlug={tenantSlug}
                    attendance={finishTarget} lossReasons={lossReasons} products={products}
                    setProducts={setProducts}
                    detailedEnabled={detailedEnabled} lossReasonsEnabled={lossReasonsEnabled} base={base}
                    onClose={() => setFinishTarget(null)} onDone={() => { setFinishTarget(null); fetchState(true); }}
                />
            )}
            {quickOpen && (
                <QuickAttendanceModal
                    key={quickModalKey}
                    base={base} storeId={storeId} tenantSlug={tenantSlug}
                    availableSellers={state?.available_sellers || []}
                    lossReasons={lossReasons} lossReasonsEnabled={lossReasonsEnabled}
                    onClose={() => setQuickOpen(false)} onDone={() => { setQuickOpen(false); setQuickModalKey((v) => v + 1); window.setTimeout(() => fetchState(true), 0); }}
                />
            )}
            {preferenceOpen && (
                <PreferenceAttendanceModal
                    entries={entries.filter((e) => !e.em_atividade_operacional)}
                    sellerLocked={isSeller ? ownEntry : null}
                    returnRule={preferenceReturnRule}
                    onClose={() => setPreferenceOpen(false)}
                    onStart={startPreferenceAtt}
                    busy={busy}
                />
            )}
        </div>
    );
}

function PreferenceAttendanceModal({ entries, sellerLocked = null, returnRule = "PREVIOUS_POSITION", onClose, onStart, busy }) {
    const [sellerId, setSellerId] = useState(sellerLocked?.seller_id || "");
    const [customerName, setCustomerName] = useState("");
    const [customerPhone, setCustomerPhone] = useState("");
    const [notes, setNotes] = useState("");
    const seller = sellerLocked || entries.find((e) => e.seller_id === sellerId);
    return (
        <Dialog open onOpenChange={onClose}>
            <DialogContent className="left-4 right-4 top-4 w-auto translate-x-0 translate-y-0 sm:left-[50%] sm:right-auto sm:top-[50%] sm:w-full sm:translate-x-[-50%] sm:translate-y-[-50%] max-w-lg mx-0 max-h-[calc(100dvh-2rem)] overflow-auto p-5 sm:p-8" data-testid="preference-modal">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-2"><Star size={18} /> Atendimento por preferência</DialogTitle>
                    <DialogDescription>Use quando o cliente procura diretamente um vendedor específico.</DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div className="space-y-2">
                            <Label>Cliente</Label>
                            <Input value={customerName} onChange={(e) => setCustomerName(e.target.value)} placeholder="Nome do cliente" data-testid="preference-customer-name" />
                        </div>
                        <div className="space-y-2">
                            <Label>Telefone</Label>
                            <Input value={customerPhone} onChange={(e) => setCustomerPhone(e.target.value)} placeholder="Opcional" data-testid="preference-customer-phone" />
                        </div>
                    </div>
                    {sellerLocked ? (
                        <div className="rounded-md border border-border bg-muted/30 p-3 text-sm" data-testid="preference-self-seller-box">
                            <p><b>Vendedor:</b> {sellerLocked.name}</p>
                            <p><b>Posição atual:</b> {sellerLocked.position}</p>
                        </div>
                    ) : (
                        <div className="space-y-2">
                            <Label>Vendedor procurado</Label>
                            <Select value={sellerId} onValueChange={setSellerId}>
                                <SelectTrigger data-testid="preference-seller-select"><SelectValue placeholder="Selecione o vendedor" /></SelectTrigger>
                                <SelectContent className="max-h-72">
                                    {entries.map((e) => (
                                        <SelectItem key={e.seller_id} value={e.seller_id} data-testid={`preference-seller-option-${e.position}`}>
                                            {e.name} · posição {e.position}
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                    )}
                    {seller && (
                        <div className="rounded-md border border-luppa-lilac bg-luppa-lilac/40 p-3 text-sm" data-testid="preference-impact-box">
                            <p><b>{seller.name}</b> está na posição <b>{seller.position}</b>.</p>
                            <p>Após finalizar este atendimento por preferência, retornará conforme a regra: <b>{PREFERENCE_RULE_LABEL[returnRule] || PREFERENCE_RULE_LABEL.PREVIOUS_POSITION}</b>.</p>
                            <p className="text-muted-foreground mt-1">Os demais vendedores continuarão avançando normalmente.</p>
                        </div>
                    )}
                    <div className="space-y-2">
                        <Label>Observações</Label>
                        <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Opcional" data-testid="preference-notes" />
                    </div>
                </div>
                <DialogFooter className="sticky bottom-0 bg-luppa-white dark:bg-luppa-dark-card pt-3">
                    <Button variant="outline" onClick={onClose} data-testid="preference-cancel">Cancelar</Button>
                    <Button disabled={busy || !sellerId || !customerName.trim()} onClick={() => onStart({ ...(sellerLocked ? {} : { seller_id: sellerId }), customer_name: customerName.trim(), customer_phone: customerPhone || null, notes: notes || null })} data-testid="preference-confirm">
                        Iniciar preferência
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}

const RT_MAP = {
    CONNECTED: { label: "Tempo real ativo", cls: "bg-primary/10 text-primary", Icon: Wifi },
    CONNECTING: { label: "Conectando tempo real…", cls: "bg-chart-3/15 text-foreground/70", Icon: RefreshCw },
    POLLING: { label: "Tempo real indisponível. Atualizando automaticamente.", cls: "bg-chart-3/15 text-foreground/70", Icon: RefreshCw },
    DISABLED_BY_PLAN: { label: "Tempo real desativado no plano. Atualizando automaticamente.", cls: "bg-muted text-muted-foreground", Icon: WifiOff },
    ERROR: { label: "Erro de conexão.", cls: "bg-destructive/10 text-destructive", Icon: WifiOff },
};

function RealtimeIndicator({ status, onReconnect }) {
    const cfg = RT_MAP[status] || RT_MAP.CONNECTING;
    const { Icon } = cfg;
    return (
        <button
            type="button"
            onClick={onReconnect}
            title="Reconectar tempo real"
            data-testid="realtime-indicator"
            data-status={status}
            className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${cfg.cls}`}
        >
            <Icon size={13} className={status === "CONNECTED" ? "" : "animate-pulse"} />
            <span className="hidden sm:inline max-w-[260px] truncate">{cfg.label}</span>
        </button>
    );
}

function GroupCard({ title, count, testId, children }) {
    return (
        <Card className="border border-border shadow-sm" data-testid={testId}>
            <CardContent className="p-6">
                <div className="flex items-center justify-between mb-3">
                    <p className="micro-label">{title}</p>
                    <Badge variant="outline" className="text-[10px]">{count}</Badge>
                </div>
                {children}
            </CardContent>
        </Card>
    );
}

function SellerMiniList({ sellers, showStatus, renderActions }) {
    if (!sellers.length) return <p className="text-sm text-muted-foreground">Ninguém aqui.</p>;
    return (
        <div className="space-y-2">
            {sellers.map((s) => (
                <div key={s.seller_id} className="flex items-center gap-3 p-2 rounded-sm border border-border bg-card">
                    <SellerAvatar name={s.name || "?"} src={s.avatar_url} size={26} />
                    <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate">{s.name}</p>
                        <p className="text-xs text-muted-foreground">{showStatus ? (SELLER_STATUS_PT[s.current_status] || translateTechnicalValue(s.current_status)) : (s.team_name || "Sem equipe")}</p>
                    </div>
                    <div className="flex items-center gap-1">{renderActions(s)}</div>
                </div>
            ))}
        </div>
    );
}

function CancelButton({ onConfirm, disabled, testId }) {
    const [reason, setReason] = useState("");
    const [open, setOpen] = useState(false);
    return (
        <AlertDialog open={open} onOpenChange={setOpen}>
            <AlertDialogTrigger asChild>
                <Button size="sm" variant="ghost" disabled={disabled} data-testid={testId}>
                    <XCircle size={14} className="text-destructive" />
                </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
                <AlertDialogHeader>
                    <AlertDialogTitle>Cancelar atendimento</AlertDialogTitle>
                    <AlertDialogDescription>Informe o motivo do cancelamento.</AlertDialogDescription>
                </AlertDialogHeader>
                <Input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Motivo" data-testid="cancel-reason-input" />
                <AlertDialogFooter>
                    <AlertDialogCancel>Voltar</AlertDialogCancel>
                    <AlertDialogAction disabled={!reason.trim()} onClick={() => onConfirm(reason)} data-testid="cancel-confirm">Confirmar</AlertDialogAction>
                </AlertDialogFooter>
            </AlertDialogContent>
        </AlertDialog>
    );
}

const PAYMENT_OPTIONS = [
    ["PIX", "PIX"], ["CREDIT", "Crédito"], ["DEBIT", "Débito"],
    ["CASH", "Dinheiro"], ["TRANSFER", "Transferência"], ["OTHER", "Outro"],
];

function FinishModal({ tenantSlug, attendance, lossReasons, products, setProducts, detailedEnabled, lossReasonsEnabled, base, onClose, onDone }) {
    const [showMultiple, setShowMultiple] = useState(false);
    const [result, setResult] = useState("SALE");
    const [amount, setAmount] = useState("");
    const [productQuantity, setProductQuantity] = useState("");
    const [lossReasonId, setLossReasonId] = useState("");
    const [classificacaoPerda, setClassificacaoPerda] = useState({
        grupo_motivo_perda_id: "",
        subgrupo_motivo_perda_id: "",
        motivo_perda_id: "",
        descricao_complementar: "",
    });
    const [notes, setNotes] = useState("");
    const [saving, setSaving] = useState(false);
    const { estrutura: estruturaPerda } = useMotivosPerdaOpcoes(tenantSlug, lossReasonsEnabled);

    // Estado da venda detalhada
    const [items, setItems] = useState([]);
    const [orderDiscount, setOrderDiscount] = useState("");
    const [payments, setPayments] = useState([]);

    // Modo detalhado ativo somente quando há itens adicionados
    const useDetailed = detailedEnabled && result === "SALE";
    const hasItems = items.length > 0;

    const addItemFromProduct = (productId) => {
        const p = products.find((x) => x.id === productId);
        if (!p) return;
        setItems((prev) => [...prev, {
            key: `${Date.now()}-${Math.random()}`, product_id: p.id, name: p.name, sku: p.sku || "",
            quantity: 1, unit_price: (p.price_cents / 100).toFixed(2).replace(".", ","), discount: "",
        }]);
    };
    const addManualItem = () => setItems((prev) => [...prev, {
        key: `${Date.now()}-${Math.random()}`, product_id: null, name: "", sku: "", quantity: 1, unit_price: "", discount: "",
    }]);
    const updateItem = (key, patch) => setItems((prev) => prev.map((it) => it.key === key ? { ...it, ...patch } : it));
    const removeItem = (key) => setItems((prev) => prev.filter((it) => it.key !== key));

    const addPayment = () => setPayments((prev) => [...prev, { key: `${Date.now()}-${Math.random()}`, method: "PIX", amount: "" }]);
    const updatePayment = (key, patch) => setPayments((prev) => prev.map((p) => p.key === key ? { ...p, ...patch } : p));
    const removePayment = (key) => setPayments((prev) => prev.filter((p) => p.key !== key));

    const itemsTotalCents = items.reduce((sum, it) => {
        const unit = brlToCents(it.unit_price) || 0;
        const disc = brlToCents(it.discount) || 0;
        const qty = parseInt(it.quantity, 10) || 0;
        return sum + Math.max(0, unit * qty - disc);
    }, 0);
    const orderDiscountCents = brlToCents(orderDiscount) || 0;
    const netCents = Math.max(0, itemsTotalCents - orderDiscountCents);
    const paymentsTotalCents = payments.reduce((s, p) => s + (brlToCents(p.amount) || 0), 0);

    // Auto-criar produtos inexistentes no catálogo após venda
    const autoCreateNewProducts = async (saleItems) => {
        const newItems = saleItems.filter((it) => !it.product_id && it.name?.trim());
        if (!newItems.length) return;
        const created = [];
        for (const it of newItems) {
            try {
                const { data } = await api.post(`/tenants/${tenantSlug}/products`, {
                    name: it.name.trim(),
                    price_cents: brlToCents(it.unit_price) || 0,
                });
                created.push(data);
            } catch { /* produto já existe ou outro erro — ignorar */ }
        }
        if (created.length > 0) {
            setProducts((prev) => {
                const ids = new Set(prev.map((p) => p.id));
                return [...prev, ...created.filter((p) => !ids.has(p.id))];
            });
            toast.info(`${created.length} produto(s) criado(s) automaticamente no catálogo.`);
        }
    };

    const submit = async () => {
        setSaving(true);
        try {
            const payload = { attendance_id: attendance.id, result, notes: notes || null, loss_reason_id: null, sale_amount_cents: null, sale: null, product_quantity: null };
            if (result === "SALE") {
                const qty = parseInt(productQuantity, 10);
                if (qty > 0) payload.product_quantity = qty;
                if (useDetailed && hasItems) {
                    // Modo detalhado com itens — validar cada item
                    for (const it of items) {
                        if (!it.name.trim()) { toast.error("Informe o nome de todos os itens."); setSaving(false); return; }
                        if (!(brlToCents(it.unit_price) > 0)) { toast.error("Informe o preço unitário dos itens."); setSaving(false); return; }
                    }
                    if (netCents <= 0) { toast.error("O valor líquido deve ser maior que zero."); setSaving(false); return; }
                    if (payments.length > 0 && paymentsTotalCents !== netCents) {
                        toast.error("A soma dos pagamentos deve ser igual ao valor líquido."); setSaving(false); return;
                    }
                    payload.sale = {
                        items: items.map((it) => ({
                            product_id: it.product_id, name: it.name, sku: it.sku || null,
                            quantity: parseInt(it.quantity, 10) || 1,
                            unit_price_cents: brlToCents(it.unit_price) || 0,
                            discount_cents: brlToCents(it.discount) || 0,
                        })),
                        discount_amount_cents: orderDiscountCents,
                        payment_methods: payments.filter((p) => brlToCents(p.amount) > 0).map((p) => ({ method: p.method, amount_cents: brlToCents(p.amount) })),
                        notes: notes || null,
                    };
                } else {
                    // Sem itens ou modo simples — apenas valor total
                    const cents = brlToCents(amount);
                    if (!cents || cents <= 0) { toast.error("Informe o valor da venda."); setSaving(false); return; }
                    payload.sale_amount_cents = cents;
                }
            }
            if (result === "NO_SALE") {
                if (estruturaPerda?.hierarquia_ativa) {
                    const { motivo } = encontrarMotivoPerda(estruturaPerda, classificacaoPerda);
                    if (!classificacaoPerda.grupo_motivo_perda_id || !classificacaoPerda.subgrupo_motivo_perda_id || !classificacaoPerda.motivo_perda_id) {
                        toast.error("Selecione Grupo, Subgrupo e Motivo."); setSaving(false); return;
                    }
                    const descricao = (classificacaoPerda.descricao_complementar || "").trim();
                    if (motivo?.exige_descricao_complementar && !descricao) {
                        toast.error("Informe a descrição complementar."); setSaving(false); return;
                    }
                    payload.grupo_motivo_perda_id = classificacaoPerda.grupo_motivo_perda_id;
                    payload.subgrupo_motivo_perda_id = classificacaoPerda.subgrupo_motivo_perda_id;
                    payload.motivo_perda_id = classificacaoPerda.motivo_perda_id;
                    payload.descricao_complementar = descricao || null;
                } else {
                    if (!lossReasonId) { toast.error("Selecione o motivo da perda."); setSaving(false); return; }
                    payload.loss_reason_id = lossReasonId;
                }
            }
            if (result === "INVALID" && !notes.trim()) { toast.error("Justificativa obrigatória."); setSaving(false); return; }

            const idempotencyKey = `${attendance.id}-${result}-${Date.now()}`;
            await api.post(`${base}/queue/finish-attendance`, payload, {
                headers: { "Idempotency-Key": idempotencyKey },
            });

            // Auto-criar produtos novos no catálogo (silencioso, após sucesso da venda)
            if (useDetailed && hasItems) {
                await autoCreateNewProducts(items);
            }

            toast.success("Atendimento finalizado.");
            onDone();
        } catch (e) {
            toast.error(extractError(e, "Erro ao finalizar"));
        } finally {
            setSaving(false);
        }
    };

    if (showMultiple) {
        return <MultipleAttendancesModal tenantSlug={tenantSlug} attendance={attendance} base={base} estruturaPerda={estruturaPerda} lossReasons={lossReasons} onBack={() => setShowMultiple(false)} onClose={onClose} onDone={onDone} />;
    }

    return (
        <Dialog open onOpenChange={onClose}>
            <DialogContent className={useDetailed && hasItems ? "max-w-2xl max-h-[86vh] overflow-auto" : "max-w-md max-h-[86vh] overflow-auto"}>
                <DialogHeader><DialogTitle>Finalizar atendimento</DialogTitle>
                    <DialogDescription>Registre o resultado do atendimento{useDetailed && hasItems ? " com itens, descontos e formas de pagamento." : "."}</DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                    <Button type="button" variant="outline" className="w-full gap-2" onClick={() => setShowMultiple(true)} data-testid="open-multiple-attendances">
                        <Users size={14} /> Registrar múltiplos atendimentos
                    </Button>
                    <RadioGroup value={result} onValueChange={setResult} className="grid grid-cols-2 gap-2">
                        {[["SALE", "Sucesso"], ["NO_SALE", "Não sucesso"], ["FOLLOW_UP", "Cliente retornará"], ["INVALID", "Inválido"]].map(([v, l]) => (
                            <label key={v} className={`flex items-center gap-2 border rounded-sm p-2 cursor-pointer text-sm ${result === v ? "border-primary/50 bg-primary/10" : "border-border"}`}>
                                <RadioGroupItem value={v} data-testid={`result-${v}`} /> {l}
                            </label>
                        ))}
                    </RadioGroup>

                    {result === "SALE" && (
                        <div className="space-y-2">
                            <Label>Quantidade de produtos</Label>
                            <Input type="number" min="1" value={productQuantity} onChange={(e) => setProductQuantity(e.target.value)} placeholder="Ex: 3" data-testid="product-quantity-input" />
                        </div>
                    )}

                    {result === "SALE" && useDetailed && (
                        <div className="space-y-4" data-testid="detailed-sale-section">
                            <div className="space-y-2">
                                <div className="flex items-center justify-between">
                                    <Label>Itens da venda <span className="text-xs text-muted-foreground">(opcional)</span></Label>
                                    <div className="flex gap-2 items-center">
                                        {products.length > 0 && (
                                            <Select value="" onValueChange={addItemFromProduct}>
                                                <SelectTrigger className="w-44 h-8 text-xs" data-testid="add-product-select"><SelectValue placeholder="+ Produto" /></SelectTrigger>
                                                <SelectContent>{products.map((p) => <SelectItem key={p.id} value={p.id}>{p.name} · {centsToBRL(p.price_cents)}</SelectItem>)}</SelectContent>
                                            </Select>
                                        )}
                                        <Button type="button" size="sm" variant="outline" onClick={addManualItem} data-testid="add-manual-item-btn"><Plus size={14} /> Item</Button>
                                    </div>
                                </div>
                                {items.length === 0 ? (
                                    <p className="text-xs text-muted-foreground italic">Nenhum item — informe o valor total abaixo ou adicione itens.</p>
                                ) : (
                                    <div className="space-y-2">
                                        {items.map((it) => {
                                            const lineCents = Math.max(0, (brlToCents(it.unit_price) || 0) * (parseInt(it.quantity, 10) || 0) - (brlToCents(it.discount) || 0));
                                            return (
                                                <div key={it.key} className="grid grid-cols-12 gap-2 items-end border border-border rounded-sm p-2" data-testid="sale-item-row">
                                                    <div className="col-span-4 space-y-1"><Label className="text-[10px]">Item</Label><Input className="h-8" value={it.name} onChange={(e) => updateItem(it.key, { name: e.target.value })} placeholder="Produto" data-testid="item-name-input" /></div>
                                                    <div className="col-span-2 space-y-1"><Label className="text-[10px]">Qtd</Label><Input className="h-8" type="number" min="1" value={it.quantity} onChange={(e) => updateItem(it.key, { quantity: e.target.value })} data-testid="item-qty-input" /></div>
                                                    <div className="col-span-2 space-y-1"><Label className="text-[10px]">Unit. R$</Label><Input className="h-8" inputMode="decimal" value={it.unit_price} onChange={(e) => updateItem(it.key, { unit_price: e.target.value })} placeholder="0,00" data-testid="item-price-input" /></div>
                                                    <div className="col-span-2 space-y-1"><Label className="text-[10px]">Desc. R$</Label><Input className="h-8" inputMode="decimal" value={it.discount} onChange={(e) => updateItem(it.key, { discount: e.target.value })} placeholder="0,00" data-testid="item-discount-input" /></div>
                                                    <div className="col-span-1 text-xs font-mono text-right pb-2">{centsToBRL(lineCents)}</div>
                                                    <div className="col-span-1 pb-1"><Button type="button" size="icon" variant="ghost" onClick={() => removeItem(it.key)} data-testid="remove-item-btn"><Trash2 size={14} className="text-destructive" /></Button></div>
                                                </div>
                                            );
                                        })}
                                    </div>
                                )}
                            </div>

                            {/* Desconto + Resumo apenas quando há itens */}
                            {hasItems && (
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-1"><Label>Desconto geral (R$)</Label><Input inputMode="decimal" value={orderDiscount} onChange={(e) => setOrderDiscount(e.target.value)} placeholder="0,00" data-testid="order-discount-input" /></div>
                                    <div className="space-y-1">
                                        <Label>Resumo</Label>
                                        <div className="text-sm border border-border rounded-sm p-2 space-y-0.5">
                                            <div className="flex justify-between"><span className="text-muted-foreground text-xs">Bruto</span><span className="font-mono text-xs">{centsToBRL(itemsTotalCents)}</span></div>
                                            <div className="flex justify-between font-semibold"><span className="text-xs">Líquido</span><span className="font-mono text-xs" data-testid="sale-net-preview">{centsToBRL(netCents)}</span></div>
                                        </div>
                                    </div>
                                </div>
                            )}

                            {/* Pagamentos apenas quando há itens */}
                            {hasItems && (
                                <div className="space-y-2">
                                    <div className="flex items-center justify-between">
                                        <Label>Formas de pagamento (opcional)</Label>
                                        <Button type="button" size="sm" variant="outline" onClick={addPayment} data-testid="add-payment-btn"><Plus size={14} /> Pagamento</Button>
                                    </div>
                                    {payments.map((p) => (
                                        <div key={p.key} className="grid grid-cols-12 gap-2 items-center" data-testid="payment-row">
                                            <div className="col-span-6">
                                                <Select value={p.method} onValueChange={(v) => updatePayment(p.key, { method: v })}>
                                                    <SelectTrigger className="h-8" data-testid="payment-method-select"><SelectValue /></SelectTrigger>
                                                    <SelectContent>{PAYMENT_OPTIONS.map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}</SelectContent>
                                                </Select>
                                            </div>
                                            <div className="col-span-5"><Input className="h-8" inputMode="decimal" value={p.amount} onChange={(e) => updatePayment(p.key, { amount: e.target.value })} placeholder="0,00" data-testid="payment-amount-input" /></div>
                                            <div className="col-span-1"><Button type="button" size="icon" variant="ghost" onClick={() => removePayment(p.key)}><Trash2 size={14} className="text-destructive" /></Button></div>
                                        </div>
                                    ))}
                                    {payments.length > 0 && paymentsTotalCents !== netCents && (
                                        <p className="text-xs text-luppa-warning dark:text-luppa-warning">Soma dos pagamentos ({centsToBRL(paymentsTotalCents)}) difere do líquido ({centsToBRL(netCents)}).</p>
                                    )}
                                </div>
                            )}
                        </div>
                    )}

                    {/* Campo de valor: modo simples OU modo detalhado sem itens */}
                    {result === "SALE" && (!useDetailed || !hasItems) && (
                        <div className="space-y-2">
                            <Label>Valor da venda (R$)</Label>
                            <Input type="text" inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="199,90" data-testid="sale-amount-input" />
                        </div>
                    )}
                    {result === "NO_SALE" && (
                        estruturaPerda?.hierarquia_ativa ? (
                            <MotivosPerdaSelector
                                estrutura={estruturaPerda}
                                value={classificacaoPerda}
                                onChange={setClassificacaoPerda}
                                prefix="finish-loss"
                            />
                        ) : (
                            <div className="space-y-2">
                                <Label>Motivo da perda {!lossReasonsEnabled && <span className="text-xs text-muted-foreground">(opcional)</span>}</Label>
                                {lossReasonsEnabled ? (
                                    <Select value={lossReasonId} onValueChange={setLossReasonId}>
                                        <SelectTrigger data-testid="loss-reason-select"><SelectValue placeholder="Selecione…" /></SelectTrigger>
                                        <SelectContent>{lossReasons.map((r) => <SelectItem key={r.id} value={r.id} data-testid={`loss-reason-option-${r.id}`}>{r.name}</SelectItem>)}</SelectContent>
                                    </Select>
                                ) : (
                                    <Input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Descreva o motivo…" data-testid="loss-reason-notes" />
                                )}
                            </div>
                        )
                    )}
                    <div className="space-y-2">
                        <Label>{result === "INVALID" ? "Justificativa (obrigatória)" : "Observação"}</Label>
                        <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} data-testid="finish-notes-input" />
                    </div>
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={onClose}>Cancelar</Button>
                    <Button onClick={submit} disabled={saving} data-testid="finish-submit">Finalizar atendimento</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}


function CreateQueueDialog({ base, onCreated }) {
    const [open, setOpen] = useState(false);
    const [name, setName] = useState("");
    const submit = async (e) => {
        e.preventDefault();
        try {
            await api.post(`${base}/queues`, { name, type: "CUSTOM", is_default: false });
            toast.success("Fila criada.");
            setOpen(false); setName(""); onCreated();
        } catch (err) { toast.error(extractError(err, "Erro ao criar fila")); }
    };
    return (
        <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button variant="outline" className="gap-2" data-testid="new-queue-button"><Plus size={16} /> Nova fila</Button></DialogTrigger>
            <DialogContent className="max-w-sm">
                <DialogHeader><DialogTitle>Nova fila</DialogTitle></DialogHeader>
                <form onSubmit={submit} className="space-y-4">
                    <div className="space-y-2"><Label>Nome da fila</Label><Input value={name} onChange={(e) => setName(e.target.value)} required data-testid="queue-name-input" /></div>
                    <DialogFooter><Button type="submit" data-testid="queue-create-submit">Criar</Button></DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}

function MultipleAttendancesModal({ tenantSlug, attendance, base, estruturaPerda, lossReasons, onBack, onClose, onDone }) {
    const [mode, setMode] = useState("AGGREGATED");
    const [total, setTotal] = useState("5");
    const [successes, setSuccesses] = useState("3");
    const [noSales, setNoSales] = useState("2");
    const [amount, setAmount] = useState("600,00");
    const [products, setProducts] = useState("9");
    const [notes, setNotes] = useState("");
    const [lossReasonId, setLossReasonId] = useState("");
    const [classificacaoPerda, setClassificacaoPerda] = useState({ grupo_motivo_perda_id: "", subgrupo_motivo_perda_id: "", motivo_perda_id: "", descricao_complementar: "" });
    const [rows, setRows] = useState([
        { key: "1", result: "SALE", sale_amount: "", product_quantity: "1", notes: "" },
        { key: "2", result: "NO_SALE", sale_amount: "", product_quantity: "0", notes: "" },
    ]);
    const [saving, setSaving] = useState(false);
    const totalNum = mode === "AGGREGATED" ? (parseInt(total, 10) || 0) : rows.length;
    const successNum = mode === "AGGREGATED" ? (parseInt(successes, 10) || 0) : rows.filter((r) => r.result === "SALE").length;
    const noSaleNum = mode === "AGGREGATED" ? (parseInt(noSales, 10) || 0) : rows.filter((r) => r.result === "NO_SALE").length;
    const amountCents = mode === "AGGREGATED" ? (brlToCents(amount) || 0) : rows.reduce((s, r) => s + (r.result === "SALE" ? (brlToCents(r.sale_amount) || 0) : 0), 0);
    const productTotal = mode === "AGGREGATED" ? (parseInt(products, 10) || 0) : rows.reduce((s, r) => s + (r.result === "SALE" ? (parseInt(r.product_quantity, 10) || 0) : 0), 0);
    const conversion = totalNum ? Math.round((successNum / totalNum) * 100) : 0;
    const ticket = successNum ? Math.round(amountCents / successNum) : 0;
    const pa = totalNum ? productTotal / totalNum : 0;
    const needsLoss = noSaleNum > 0;

    const addRow = () => setRows((prev) => [...prev, { key: `${Date.now()}-${Math.random()}`, result: "SALE", sale_amount: "", product_quantity: "1", notes: "" }]);
    const updateRow = (key, patch) => setRows((prev) => prev.map((r) => r.key === key ? { ...r, ...patch } : r));
    const removeRow = (key) => setRows((prev) => prev.length > 1 ? prev.filter((r) => r.key !== key) : prev);
    const duplicateRow = (row) => setRows((prev) => [...prev, { ...row, key: `${Date.now()}-${Math.random()}` }]);

    const submit = async () => {
        const t = totalNum, s = successNum, n = noSaleNum;
        if (t < 1 || t > 50) { toast.error("Informe entre 1 e 50 clientes."); return; }
        if (s + n !== t) { toast.error("Sucessos + não sucessos deve ser igual ao total."); return; }
        if (s === 0 && (amountCents > 0 || productTotal > 0)) { toast.error("Sem sucessos, valor e produtos devem ser zero."); return; }
        if (needsLoss && estruturaPerda?.hierarquia_ativa) {
            const { motivo } = encontrarMotivoPerda(estruturaPerda, classificacaoPerda);
            if (!classificacaoPerda.grupo_motivo_perda_id || !classificacaoPerda.subgrupo_motivo_perda_id || !classificacaoPerda.motivo_perda_id) { toast.error("Selecione Grupo, Subgrupo e Motivo dos não sucessos."); return; }
            if (motivo?.exige_descricao_complementar && !(classificacaoPerda.descricao_complementar || "").trim()) { toast.error("Informe a descrição complementar."); return; }
        } else if (needsLoss && !estruturaPerda?.hierarquia_ativa && !lossReasonId) {
            toast.error("Selecione o motivo comum dos não sucessos."); return;
        }
        if (!window.confirm(`Este lançamento criará ${t} atendimentos individuais e movimentará a fila apenas uma vez. Deseja continuar?`)) return;
        setSaving(true);
        try {
            const payload = {
                attendance_id: attendance.id,
                mode,
                total_customers: mode === "AGGREGATED" ? t : undefined,
                successes: mode === "AGGREGATED" ? s : undefined,
                no_sales: mode === "AGGREGATED" ? n : undefined,
                total_amount_cents: mode === "AGGREGATED" ? amountCents : undefined,
                total_product_quantity: mode === "AGGREGATED" ? productTotal : undefined,
                notes: notes || null,
                loss_reason_id: lossReasonId || null,
                ...classificacaoPerda,
                rows: mode === "DETAILED" ? rows.map((r) => ({ result: r.result, sale_amount_cents: r.result === "SALE" ? (brlToCents(r.sale_amount) || 0) : 0, product_quantity: r.result === "SALE" ? (parseInt(r.product_quantity, 10) || 0) : 0, notes: r.notes || null })) : undefined,
            };
            await api.post(`${base}/queue/finish-multiple-attendances`, payload, { headers: { "Idempotency-Key": `multi-${attendance.id}-${Date.now()}` } });
            toast.success("Múltiplos atendimentos registrados.");
            onDone();
        } catch (e) {
            toast.error(extractError(e, "Erro ao registrar múltiplos atendimentos"));
        } finally {
            setSaving(false);
        }
    };

    return (
        <Dialog open onOpenChange={onClose}>
            <DialogContent className="left-3 right-3 top-3 w-auto translate-x-0 translate-y-0 sm:left-[50%] sm:right-auto sm:top-[50%] sm:w-full sm:translate-x-[-50%] sm:translate-y-[-50%] max-w-3xl max-h-[calc(100dvh-1.5rem)] overflow-auto p-4 sm:p-6" data-testid="multiple-attendances-modal">
                <DialogHeader>
                    <DialogTitle>Registrar múltiplos atendimentos</DialogTitle>
                    <DialogDescription>O lote agrupa o lançamento, mas cada cliente será salvo como atendimento individual.</DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                    <RadioGroup value={mode} onValueChange={setMode} className="grid grid-cols-2 gap-2">
                        <label className={`border rounded-sm p-3 cursor-pointer ${mode === "AGGREGATED" ? "border-primary bg-primary/10" : "border-border"}`}><RadioGroupItem value="AGGREGATED" data-testid="multiple-mode-aggregated" /> Modo agregado</label>
                        <label className={`border rounded-sm p-3 cursor-pointer ${mode === "DETAILED" ? "border-primary bg-primary/10" : "border-border"}`}><RadioGroupItem value="DETAILED" data-testid="multiple-mode-detailed" /> Modo detalhado</label>
                    </RadioGroup>
                    {mode === "AGGREGATED" ? (
                        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                            <div className="space-y-1"><Label>Total clientes</Label><Input type="number" min="1" max="50" value={total} onChange={(e) => setTotal(e.target.value)} data-testid="multiple-total" /></div>
                            <div className="space-y-1"><Label>Sucessos</Label><Input type="number" min="0" value={successes} onChange={(e) => setSuccesses(e.target.value)} data-testid="multiple-successes" /></div>
                            <div className="space-y-1"><Label>Não sucessos</Label><Input type="number" min="0" value={noSales} onChange={(e) => setNoSales(e.target.value)} data-testid="multiple-no-sales" /></div>
                            <div className="space-y-1"><Label>Valor total</Label><Input inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} data-testid="multiple-amount" /></div>
                            <div className="space-y-1"><Label>Produtos</Label><Input type="number" min="0" value={products} onChange={(e) => setProducts(e.target.value)} data-testid="multiple-products" /></div>
                        </div>
                    ) : (
                        <div className="space-y-2" data-testid="multiple-detailed-rows">
                            {rows.map((r, idx) => <div key={r.key} className="grid grid-cols-1 md:grid-cols-12 gap-2 border border-border rounded-sm p-2"><div className="md:col-span-3"><Label>Resultado</Label><Select value={r.result} onValueChange={(v) => updateRow(r.key, { result: v, sale_amount: v === "NO_SALE" ? "" : r.sale_amount, product_quantity: v === "NO_SALE" ? "0" : r.product_quantity })}><SelectTrigger data-testid={`multiple-row-result-${idx}`}><SelectValue /></SelectTrigger><SelectContent><SelectItem value="SALE">Sucesso</SelectItem><SelectItem value="NO_SALE">Não sucesso</SelectItem></SelectContent></Select></div><div className="md:col-span-3"><Label>Valor</Label><Input disabled={r.result !== "SALE"} value={r.sale_amount} onChange={(e) => updateRow(r.key, { sale_amount: e.target.value })} data-testid={`multiple-row-amount-${idx}`} /></div><div className="md:col-span-2"><Label>Produtos</Label><Input disabled={r.result !== "SALE"} type="number" min="0" value={r.product_quantity} onChange={(e) => updateRow(r.key, { product_quantity: e.target.value })} data-testid={`multiple-row-products-${idx}`} /></div><div className="md:col-span-2"><Label>Obs.</Label><Input value={r.notes} onChange={(e) => updateRow(r.key, { notes: e.target.value })} data-testid={`multiple-row-notes-${idx}`} /></div><div className="md:col-span-2 flex gap-1 items-end"><Button type="button" size="icon" variant="ghost" onClick={() => duplicateRow(r)} data-testid={`multiple-row-duplicate-${idx}`}><Copy size={14} /></Button><Button type="button" size="icon" variant="ghost" onClick={() => removeRow(r.key)} data-testid={`multiple-row-remove-${idx}`}><Trash2 size={14} /></Button></div></div>)}
                            <Button type="button" variant="outline" onClick={addRow} data-testid="multiple-add-row"><Plus size={14} /> Adicionar linha</Button>
                        </div>
                    )}
                    {needsLoss && (estruturaPerda?.hierarquia_ativa ? <MotivosPerdaSelector estrutura={estruturaPerda} value={classificacaoPerda} onChange={setClassificacaoPerda} prefix="multiple-loss" /> : <div className="space-y-2"><Label>Motivo comum dos não sucessos</Label><Select value={lossReasonId} onValueChange={setLossReasonId}><SelectTrigger data-testid="multiple-loss-reason"><SelectValue placeholder="Selecione" /></SelectTrigger><SelectContent>{lossReasons.map((r) => <SelectItem key={r.id} value={r.id}>{r.name}</SelectItem>)}</SelectContent></Select></div>)}
                    <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Observação geral do lote" data-testid="multiple-notes" />
                    <div className="rounded-md border border-border bg-muted/30 p-3 text-sm grid grid-cols-2 md:grid-cols-5 gap-2" data-testid="multiple-summary"><span>Clientes: <b>{totalNum}</b></span><span>Sucessos: <b>{successNum}</b></span><span>Conversão: <b>{conversion}%</b></span><span>Receita: <b>{centsToBRL(amountCents)}</b></span><span>PA: <b>{pa.toFixed(1)}</b></span><span>Ticket: <b>{centsToBRL(ticket)}</b></span></div>
                    <p className="text-xs text-muted-foreground">Valores e produtos do modo agregado serão rateados igualmente com resto, preservando exatamente os totais informados.</p>
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={onBack} data-testid="multiple-back">Voltar</Button>
                    <Button onClick={submit} disabled={saving} data-testid="multiple-submit">{saving ? "Salvando..." : "Confirmar lote"}</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}

function QuickAttendanceModal({ base, storeId, tenantSlug, availableSellers, lossReasons, lossReasonsEnabled, onClose, onDone }) {
    const [sellerId, setSellerId] = useState(availableSellers[0]?.seller_id || "");
    const [customerName, setCustomerName] = useState("");
    const [result, setResult] = useState("SALE");
    const [amount, setAmount] = useState("");
    const [productQuantity, setProductQuantity] = useState("");
    const [lossReasonId, setLossReasonId] = useState("");
    const [classificacaoPerda, setClassificacaoPerda] = useState({
        grupo_motivo_perda_id: "",
        subgrupo_motivo_perda_id: "",
        motivo_perda_id: "",
        descricao_complementar: "",
    });
    const [lossNotes, setLossNotes] = useState("");
    const [notes, setNotes] = useState("");
    const [saving, setSaving] = useState(false);
    const { estrutura: estruturaPerda } = useMotivosPerdaOpcoes(tenantSlug, lossReasonsEnabled);

    const submit = async () => {
        if (!sellerId) { toast.error("Selecione um vendedor."); return; }
        setSaving(true);
        try {
            const payload = {
                seller_id: sellerId,
                result,
                customer_name: customerName || null,
                notes: notes || null,
                sale_amount_cents: null,
                loss_reason_id: null,
                grupo_motivo_perda_id: null,
                subgrupo_motivo_perda_id: null,
                motivo_perda_id: null,
                descricao_complementar: null,
                product_quantity: null,
            };
            if (result === "SALE") {
                const cents = brlToCents(amount);
                if (!cents || cents <= 0) { toast.error("Informe o valor da venda."); setSaving(false); return; }
                payload.sale_amount_cents = cents;
                const qty = parseInt(productQuantity, 10);
                if (qty > 0) payload.product_quantity = qty;
            }
            if (result === "NO_SALE") {
                if (estruturaPerda?.hierarquia_ativa) {
                    const { motivo } = encontrarMotivoPerda(estruturaPerda, classificacaoPerda);
                    if (!classificacaoPerda.grupo_motivo_perda_id || !classificacaoPerda.subgrupo_motivo_perda_id || !classificacaoPerda.motivo_perda_id) { toast.error("Selecione Grupo, Subgrupo e Motivo."); setSaving(false); return; }
                    const descricao = (classificacaoPerda.descricao_complementar || "").trim();
                    if (motivo?.exige_descricao_complementar && !descricao) { toast.error("Informe a descrição complementar."); setSaving(false); return; }
                    payload.grupo_motivo_perda_id = classificacaoPerda.grupo_motivo_perda_id;
                    payload.subgrupo_motivo_perda_id = classificacaoPerda.subgrupo_motivo_perda_id;
                    payload.motivo_perda_id = classificacaoPerda.motivo_perda_id;
                    payload.descricao_complementar = descricao || null;
                } else if (lossReasonsEnabled) {
                    if (!lossReasonId) { toast.error("Selecione o motivo da perda."); setSaving(false); return; }
                    payload.loss_reason_id = lossReasonId;
                } else {
                    if (!lossNotes.trim()) { toast.error("Descreva o motivo da não venda."); setSaving(false); return; }
                    payload.notes = lossNotes;
                }
            }
            if (result === "INVALID") {
                if (!notes.trim()) { toast.error("Justificativa obrigatória."); setSaving(false); return; }
            }
            await api.post(`${base}/queue/quick-attendance`, payload);
            toast.success("Atendimento rápido registrado.");
            onDone();
        } catch (e) {
            toast.error(extractError(e, "Erro ao registrar atendimento"));
        } finally {
            setSaving(false);
        }
    };

    return (
        <Dialog open onOpenChange={onClose}>
            <DialogContent className="max-w-md max-h-[86vh] overflow-auto">
                <DialogHeader>
                    <DialogTitle>Registro Rápido</DialogTitle>
                    <DialogDescription>Registre um atendimento de forma rápida sem passar pela fila.</DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                    <div className="space-y-2">
                        <Label>Vendedor</Label>
                        <Select value={sellerId} onValueChange={setSellerId}>
                            <SelectTrigger data-testid="quick-seller-select"><SelectValue placeholder="Selecione…" /></SelectTrigger>
                            <SelectContent>
                                {availableSellers.map((s) => (
                                    <SelectItem key={s.seller_id} value={s.seller_id}>{s.name}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                        {availableSellers.length === 0 && (
                            <p className="text-xs text-luppa-warning">Nenhum vendedor disponível. O vendedor precisa estar com status DISPONÍVEL.</p>
                        )}
                    </div>

                    <div className="space-y-2">
                        <Label>Cliente (opcional)</Label>
                        <Input value={customerName} onChange={(e) => setCustomerName(e.target.value)} placeholder="Nome do cliente" data-testid="quick-customer-name" />
                    </div>

                    <div className="space-y-2">
                        <Label>Resultado</Label>
                        <RadioGroup value={result} onValueChange={setResult} className="grid grid-cols-2 gap-2">
                            {[["SALE", "Sucesso"], ["NO_SALE", "Não sucesso"], ["FOLLOW_UP", "Cliente retornará"], ["INVALID", "Inválido"]].map(([v, l]) => (
                                <label key={v} className={`flex items-center gap-2 border rounded-sm p-2 cursor-pointer text-sm ${result === v ? "border-primary/50 bg-primary/10" : "border-border"}`}>
                                    <RadioGroupItem value={v} data-testid={`quick-result-${v}`} /> {l}
                                </label>
                            ))}
                        </RadioGroup>
                    </div>

                    {result === "SALE" && (
                        <div className="space-y-2">
                            <Label>Quantidade de produtos</Label>
                            <Input type="number" min="1" value={productQuantity} onChange={(e) => setProductQuantity(e.target.value)} placeholder="Ex: 3" data-testid="quick-product-quantity-input" />
                        </div>
                    )}

                    {result === "SALE" && (
                        <div className="space-y-2">
                            <Label>Valor da venda (R$)</Label>
                            <Input inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="199,90" data-testid="quick-amount-input" />
                        </div>
                    )}

                    {result === "NO_SALE" && (
                        estruturaPerda?.hierarquia_ativa ? (
                            <MotivosPerdaSelector
                                estrutura={estruturaPerda}
                                value={classificacaoPerda}
                                onChange={setClassificacaoPerda}
                                prefix="quick-loss"
                            />
                        ) : (
                            <div className="space-y-2">
                                <Label>Motivo da perda</Label>
                                {lossReasonsEnabled ? (
                                    <Select value={lossReasonId} onValueChange={setLossReasonId}>
                                        <SelectTrigger data-testid="quick-loss-reason-select"><SelectValue placeholder="Selecione…" /></SelectTrigger>
                                        <SelectContent>{lossReasons.map((r) => <SelectItem key={r.id} value={r.id} data-testid={`quick-loss-reason-option-${r.id}`}>{r.name}</SelectItem>)}</SelectContent>
                                    </Select>
                                ) : (
                                    <Input value={lossNotes} onChange={(e) => setLossNotes(e.target.value)} placeholder="Descreva o motivo…" data-testid="quick-loss-notes" />
                                )}
                            </div>
                        )
                    )}

                    {(result === "INVALID" || (result !== "NO_SALE" && result !== "SALE")) && (
                        <div className="space-y-2">
                            <Label>{result === "INVALID" ? "Justificativa (obrigatória)" : "Observação"}</Label>
                            <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} data-testid="quick-notes-input" />
                        </div>
                    )}
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={onClose}>Cancelar</Button>
                    <Button onClick={submit} disabled={saving || availableSellers.length === 0} data-testid="quick-submit">
                        {saving ? "Registrando…" : "Registrar atendimento"}
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}


// ─── Toast de Desfazer com contador regressivo ────────────────────────────────
function UndoToast({ toastId, message, onUndo }) {
    const [secs, setSecs] = useState(20);
    useEffect(() => {
        const interval = setInterval(() => {
            setSecs((prev) => {
                if (prev <= 1) { clearInterval(interval); return 0; }
                return prev - 1;
            });
        }, 1000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="flex items-center gap-3 bg-card border border-border shadow-lg rounded-sm px-4 py-3 w-full min-w-[280px]">
            <CheckCircle2 size={15} className="text-primary flex-shrink-0" />
            <p className="text-sm flex-1 font-medium">{message}</p>
            <button
                onClick={() => { toast.dismiss(toastId); onUndo(); }}
                className="text-xs font-semibold text-primary border border-primary/30 rounded px-2 py-1 hover:bg-primary/10 transition-colors flex-shrink-0 whitespace-nowrap"
                data-testid="undo-btn"
            >
                Desfazer ({secs}s)
            </button>
        </div>
    );
}

// ─── Janela de Saída (obrigatória ao sair da Fila Geral) ──────────────────────
function JanelaDeSaida({ sellerName, onConfirm, onCancel }) {
    const [selected, setSelected] = useState(null);

    return (
        <Dialog open onOpenChange={onCancel}>
            <DialogContent className="left-4 right-4 top-4 w-auto translate-x-0 translate-y-0 sm:left-[50%] sm:right-auto sm:top-[50%] sm:w-full sm:translate-x-[-50%] sm:translate-y-[-50%] max-w-md mx-0 max-h-[calc(100dvh-2rem)] overflow-auto" data-testid="janela-saida-modal">
                <DialogHeader>
                    <DialogTitle>Janela de Saída</DialogTitle>
                    <DialogDescription>
                        Selecione o motivo da saída de <strong>{sellerName}</strong> da Fila Geral.
                    </DialogDescription>
                </DialogHeader>
                <div className="space-y-3 py-2">
                    {MOTIVOS_SAIDA.map(({ value, label, icon: Icon, desc }) => (
                        <label
                            key={value}
                            data-testid={`saida-motivo-${value}`}
                            className={`flex items-start gap-3 border rounded-sm p-3 cursor-pointer transition-colors ${
                                selected === value
                                    ? "border-primary/50 bg-primary/10"
                                    : "border-border hover:bg-muted/30"
                            }`}
                        >
                            <input
                                type="radio"
                                className="sr-only"
                                checked={selected === value}
                                onChange={() => setSelected(value)}
                            />
                            <div className={`mt-0.5 p-1.5 rounded-full flex-shrink-0 ${selected === value ? "bg-primary/20" : "bg-muted"}`}>
                                <Icon size={15} className={selected === value ? "text-primary" : "text-muted-foreground"} />
                            </div>
                            <div className="min-w-0">
                                <p className="font-medium text-sm">{label}</p>
                                <p className="text-xs text-muted-foreground leading-relaxed">{desc}</p>
                            </div>
                        </label>
                    ))}
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={onCancel} data-testid="janela-saida-cancelar">
                        Cancelar
                    </Button>
                    <Button
                        disabled={!selected}
                        onClick={() => selected && onConfirm(selected)}
                        data-testid="janela-saida-confirmar"
                    >
                        Confirmar saída
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}
