/**
 * Meu Painel — Dashboard completo do vendedor (PROMPT 10)
 * Renomeado de "Meu Desempenho" para "Meu Painel"
 */
import { useState, useEffect, useCallback } from "react";
import { useParams } from "react-router-dom";
import {
    TrendingUp, TrendingDown, Minus, Trophy, Target, Award,
    MessageSquare, RefreshCw, DollarSign, Users, BarChart2,
    Star, Zap, CheckCircle,
} from "lucide-react";
import {
    ResponsiveContainer, BarChart, Bar, XAxis, YAxis,
    CartesianGrid, Tooltip,
    LineChart, Line, Area, AreaChart,
} from "recharts";
import { toast } from "sonner";
import api, { extractError } from "@/lib/api";
import { Button } from "@/components/ui/button";
import {
    Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
    Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { SELLER_STATUS_PT, SELLER_STATUS_COLORS, fmtDate, fmtDateTime } from "@/lib/i18n";
import { GOAL_STATUS_PT, GOAL_SCOPE_PT } from "@/lib/i18n";
import { useRealtimeTenant } from "@/context/RealtimeTenantContext";

// ─── Constantes ──────────────────────────────────────────────────────────────

// STATUS_LABELS e STATUS_COLORS são importados de @/lib/i18n como SELLER_STATUS_PT e SELLER_STATUS_COLORS

// Status que o vendedor pode alterar por conta própria (spec: Online, Offline, Em pausa, Reunião, Almoço, Ausente)
const SELF_CHANGE_STATUSES = ["AVAILABLE", "OFFLINE", "BREAK", "MEETING", "LUNCH", "ABSENT"];

const PERIOD_OPTIONS = [
    { value: "today", label: "Hoje" },
    { value: "week", label: "Semana" },
    { value: "month", label: "Mês" },
];

const FEEDBACK_TYPE_LABELS = {
    POSITIVE: "Positivo",
    CONSTRUCTIVE: "Construtivo",
    WARNING: "Aviso",
    ACTION_PLAN: "Plano de Ação",
};

const FEEDBACK_TYPE_COLORS = {
    POSITIVE: "bg-luppa-green/10 text-luppa-green border-emerald-200",
    CONSTRUCTIVE: "bg-luppa-purple/10 text-luppa-purple border-luppa-purple/25",
    WARNING: "bg-amber-50 text-amber-700 border-amber-200",
    ACTION_PLAN: "bg-luppa-purple/10 text-luppa-purple border-luppa-purple/25",
};

const GOAL_TYPE_LABELS = {
    REVENUE: "Receita",
    CONVERSION: "Conversão",
    SALES_COUNT: "Qtd. Vendas",
    ATTENDANCES: "Atendimentos",
    AVERAGE_TICKET: "Ticket Médio",
    ITEMS_SOLD: "Produtos vendidos",
};

const GOAL_STATUS_COLORS = {
    SCHEDULED: "bg-sky-50 text-sky-700 border-sky-200",
    ACTIVE: "bg-luppa-purple/10 text-luppa-purple border-luppa-purple/25",
    COMPLETED: "bg-luppa-green/10 text-luppa-green border-emerald-200",
    EXPIRED: "bg-luppa-error/10 text-luppa-error border-luppa-error/25",
    PAUSED: "bg-amber-50 text-amber-700 border-amber-200",
    CANCELLED: "bg-gray-50 text-gray-500 border-gray-200",
};

function goalProgress(goal) {
    return Number(goal.progress_percent ?? goal.progress_pct ?? 0);
}

function goalStatusLabel(goal) {
    return goal.status_label || GOAL_STATUS_PT[goal.status] || goal.status;
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function fmtBRL(cents) {
    return ((cents ?? 0) / 100).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

/** Formato compacto para KPI cards (evita overflow): R$ 12,5 mil / R$ 1,25 mi */
function abbreviateBRL(cents) {
    const reais = (cents ?? 0) / 100;
    if (reais >= 1_000_000)
        return `R$ ${(reais / 1_000_000).toLocaleString("pt-BR", { minimumFractionDigits: 1, maximumFractionDigits: 2 })} mi`;
    if (reais >= 10_000)
        return `R$ ${(reais / 1_000).toLocaleString("pt-BR", { minimumFractionDigits: 0, maximumFractionDigits: 1 })} mil`;
    return fmtBRL(cents);
}

function fmtGoalValue(type, value) {
    if (type === "REVENUE" || type === "AVERAGE_TICKET") return fmtBRL(value);
    if (type === "CONVERSION") return `${(value / 100).toFixed(1)}%`;
    return (value ?? 0).toLocaleString("pt-BR");
}

/** Versão compacta para espaços reduzidos (ex: barra de progresso das metas) */
function fmtGoalCompact(type, value) {
    if (type === "REVENUE" || type === "AVERAGE_TICKET") return abbreviateBRL(value);
    if (type === "CONVERSION") return `${((value ?? 0) / 100).toFixed(0)}%`;
    return (value ?? 0).toLocaleString("pt-BR");
}

function computeDelta(cur, prev) {
    if (!prev || prev === 0) return cur > 0 ? 100 : 0;
    return Math.round(((cur - prev) / prev) * 100);
}

function computePrevDates(period) {
    const now = new Date();
    if (period === "today") {
        const d = new Date(now); d.setDate(d.getDate() - 1);
        const s = d.toISOString().slice(0, 10);
        return { start: s, end: s };
    }
    if (period === "week") {
        const wStart = new Date(now); wStart.setDate(now.getDate() - now.getDay());
        const prevEnd = new Date(wStart); prevEnd.setDate(prevEnd.getDate() - 1);
        const prevStart = new Date(prevEnd); prevStart.setDate(prevStart.getDate() - 6);
        return { start: prevStart.toISOString().slice(0, 10), end: prevEnd.toISOString().slice(0, 10) };
    }
    // month
    const firstOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const lastPrev = new Date(firstOfMonth); lastPrev.setDate(lastPrev.getDate() - 1);
    const firstPrev = new Date(lastPrev.getFullYear(), lastPrev.getMonth(), 1);
    return { start: firstPrev.toISOString().slice(0, 10), end: lastPrev.toISOString().slice(0, 10) };
}

// ─── Sub-componentes ─────────────────────────────────────────────────────────

function StatusBadge({ status }) {
    const cls = SELLER_STATUS_COLORS[status] || "bg-gray-100 text-gray-700 border-gray-200";
    return (
        <span
            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border ${cls}`}
            data-testid="current-status-badge"
        >
            <span className="w-1.5 h-1.5 rounded-full bg-current opacity-70" />
            {SELLER_STATUS_PT[status] || status}
        </span>
    );
}

function StatusChangeModal({ sellerId, currentStatus, tenantSlug, onClose, onSaved }) {
    const [newStatus, setNewStatus] = useState(currentStatus || "AVAILABLE");
    const [reason, setReason] = useState("");
    const [saving, setSaving] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setSaving(true);
        try {
            await api.patch(`/tenants/${tenantSlug}/sellers/${sellerId}/status`, { new_status: newStatus, reason: reason || undefined });
            toast.success("Status atualizado com sucesso.");
            onSaved(newStatus);
            onClose();
        } catch (err) {
            toast.error(extractError(err, "Erro ao atualizar status."));
        } finally {
            setSaving(false);
        }
    };

    return (
        <Dialog open onOpenChange={onClose}>
            <DialogContent className="max-w-sm">
                <DialogHeader><DialogTitle>Alterar Meu Status</DialogTitle></DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <span>Status atual:</span>
                        <StatusBadge status={currentStatus} />
                    </div>
                    <div className="space-y-1.5">
                        <Label>Novo status</Label>
                        <Select value={newStatus} onValueChange={setNewStatus}>
                            <SelectTrigger data-testid="status-select-self">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                {SELF_CHANGE_STATUSES.map((s) => (
                                    <SelectItem key={s} value={s} data-testid={`status-option-${s.toLowerCase()}`}>
                                        {SELLER_STATUS_PT[s]}
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>
                    <div className="space-y-1.5">
                        <Label>Motivo (opcional)</Label>
                        <Input
                            value={reason}
                            onChange={(e) => setReason(e.target.value)}
                            placeholder="Ex.: saindo para almoço"
                            data-testid="status-reason-self"
                        />
                    </div>
                    <DialogFooter>
                        <Button type="button" variant="outline" onClick={onClose}>Cancelar</Button>
                        <Button type="submit" disabled={saving} data-testid="status-confirm-self">
                            {saving ? "Salvando…" : "Confirmar"}
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}

function DeltaChip({ delta }) {
    if (delta === undefined || delta === null) return null;
    const pos = delta > 0;
    const neg = delta < 0;
    const Icon = pos ? TrendingUp : neg ? TrendingDown : Minus;
    const cls = pos ? "text-luppa-green" : neg ? "text-luppa-error" : "text-muted-foreground";
    return (
        <span className={`inline-flex items-center gap-0.5 text-[10px] font-semibold ${cls}`}>
            <Icon size={11} />
            {pos ? "+" : ""}{delta}%
        </span>
    );
}

function KpiCard({ icon: Icon, label, value, sub, delta, colorCls = "text-foreground", testId }) {
    return (
        <div className="metric-card-wrap bg-card border border-border/60 rounded-md p-4" data-testid={testId || `kpi-${label}`}>
            <div className="flex items-center justify-between mb-2 gap-1 min-w-0">
                <p className="metric-label text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">{label}</p>
                {Icon && <Icon size={13} className={`${colorCls} opacity-50 flex-shrink-0`} />}
            </div>
            {/* Valor: metric-num garante que nunca sai do card, sem ellipsis */}
            <span
                className={`metric-num font-semibold leading-tight ${colorCls}`}
                aria-label={String(value)}
            >
                {value}
            </span>
            <div className="flex items-center justify-between mt-1.5 gap-1 min-w-0">
                {sub && <p className="text-[10px] text-muted-foreground truncate flex-1 min-w-0">{sub}</p>}
                <DeltaChip delta={delta} />
            </div>
        </div>
    );
}

function ProgressBar({ pct }) {
    const clamped = Math.min(100, Math.max(0, pct ?? 0));
    const color = clamped >= 100 ? "bg-luppa-green" : clamped >= 60 ? "bg-luppa-purple" : clamped >= 30 ? "bg-amber-400" : "bg-luppa-error/70";
    return (
        <div className="w-full bg-slate-100 rounded-full h-1.5">
            <div className={`h-full rounded-full transition-all ${color}`} style={{ width: `${clamped}%` }} />
        </div>
    );
}

function SectionCard({ icon: Icon, iconColor, title, children, testId }) {
    return (
        <div className="bg-card border border-border/60 rounded-md p-5 space-y-3 h-full min-w-0 overflow-hidden" data-testid={testId}>
            <div className="flex items-center gap-2">
                <Icon size={14} className={iconColor} />
                <p className="text-[10px] uppercase tracking-wider font-semibold text-muted-foreground">{title}</p>
            </div>
            {children}
        </div>
    );
}

function Empty({ icon: Icon, text }) {
    return (
        <div className="py-6 flex flex-col items-center justify-center text-center gap-2">
            <Icon size={24} className="text-slate-200" />
            <p className="text-xs text-muted-foreground">{text}</p>
        </div>
    );
}

// ─── Página principal ─────────────────────────────────────────────────────────

export default function MyPerformancePage() {
    const { tenantSlug } = useParams();
    const { subscribe } = useRealtimeTenant();
    const [period, setPeriod] = useState("month");
    const [mainData, setMainData] = useState(null);
    const [prevKpis, setPrevKpis] = useState(null);
    const [prevRank, setPrevRank] = useState(null);
    const [awards, setAwards] = useState([]);
    const [achProgress, setAchProgress] = useState([]);
    const [feedbacks, setFeedbacks] = useState([]);
    const [overview, setOverview] = useState([]);
    const [weeklyHistory, setWeeklyHistory] = useState([]);
    const [loading, setLoading] = useState(true);
    const [statusModal, setStatusModal] = useState(false);
    const [currentStatus, setCurrentStatus] = useState(null);

    // Busca dados principais (muda conforme período)
    const loadMain = useCallback(async (p) => {
        setLoading(true);
        const { start, end } = computePrevDates(p);
        try {
            const [main, prev] = await Promise.all([
                api.get(`/tenants/${tenantSlug}/my-performance?period=${p}`),
                api.get(`/tenants/${tenantSlug}/my-performance?date_start=${start}&date_end=${end}`),
            ]);
            setMainData(main.data);
            setPrevKpis(prev.data?.kpis || null);
            setPrevRank(prev.data?.ranking_position ?? null);
            if (main.data?.seller?.current_status) {
                setCurrentStatus(main.data.seller.current_status);
            }

        } catch {
            toast.error("Erro ao carregar dados do painel.");
        } finally {
            setLoading(false);
        }
    }, [tenantSlug]);

    // Busca dados complementares (uma vez)
    const loadSupplementary = useCallback(async () => {
        try {
            const [awds, prg, fbs, tod, wk, mo, hist] = await Promise.all([
                api.get(`/tenants/${tenantSlug}/achievement-awards/my`).catch(() => ({ data: [] })),
                api.get(`/tenants/${tenantSlug}/achievement-awards/my-progress`).catch(() => ({ data: [] })),
                api.get(`/tenants/${tenantSlug}/feedbacks?page_size=5`).catch(() => ({ data: { items: [] } })),
                api.get(`/tenants/${tenantSlug}/my-performance?period=today`).catch(() => ({ data: { kpis: {} } })),
                api.get(`/tenants/${tenantSlug}/my-performance?period=week`).catch(() => ({ data: { kpis: {} } })),
                api.get(`/tenants/${tenantSlug}/my-performance?period=month`).catch(() => ({ data: { kpis: {} } })),
                api.get(`/tenants/${tenantSlug}/my-performance/weekly-history?weeks=8`).catch(() => ({ data: { weeks: [] } })),
            ]);
            setAwards(awds.data || []);
            setAchProgress(prg.data || []);
            setFeedbacks(fbs.data?.items || fbs.data || []);
            setOverview([
                { label: "Hoje",   vendas: tod.data?.kpis?.sales_count || 0, conv: tod.data?.kpis?.conversion_rate || 0 },
                { label: "Semana", vendas: wk.data?.kpis?.sales_count || 0,  conv: wk.data?.kpis?.conversion_rate || 0 },
                { label: "Mês",    vendas: mo.data?.kpis?.sales_count || 0,  conv: mo.data?.kpis?.conversion_rate || 0 },
            ]);
            setWeeklyHistory(hist.data?.weeks || []);
        } catch {
            // dados complementares são não-blocantes
        }
    }, [tenantSlug]);

    useEffect(() => { loadMain(period); }, [period, loadMain]);
    useEffect(() => { loadSupplementary(); }, [loadSupplementary]);

    useEffect(() => {
        const refresh = () => loadMain(period);
        const unsubGoals = subscribe("goals.updated", refresh);
        const unsubDashboard = subscribe("dashboard.updated", refresh);
        return () => {
            unsubGoals();
            unsubDashboard();
        };
    }, [subscribe, loadMain, period]);

    // ── Derivações ────────────────────────────────────────────────────────────

    const kpis = mainData?.kpis || {};
    const goals = (mainData?.goals || [])
        .filter(g => g.status !== "CANCELLED")
        .slice(0, 6);
    const rankPos = mainData?.ranking_position ?? null;
    const sellerName = mainData?.seller?.name || "Vendedor";
    const sellerId = mainData?.seller?.id;

    const goalsCompleted = (mainData?.goals || []).filter(g => g.status === "COMPLETED").length;
    const goalsTotal = (mainData?.goals || []).filter(g => g.status !== "CANCELLED").length;
    const goalsPct = goalsTotal > 0 ? Math.round((goalsCompleted / goalsTotal) * 100) : 0;

    // Merge conquistas: novas (achievement_awards) + legadas (badges)
    const legacyBadges = (mainData?.badges || []).map(b => ({
        id: b.id || b.badge_id,
        achievement_name: b.name || b.badge_name || "Conquista",
    }));
    const allAwards = [...awards, ...legacyBadges].slice(0, 8);
    const nextAchievements = achProgress
        .filter(a => (a.progress_pct || 0) < 100)
        .sort((a, b) => (b.progress_pct || 0) - (a.progress_pct || 0))
        .slice(0, 3);

    // Evolução do ranking
    let rankEvolution = null;
    if (rankPos !== null && prevRank !== null) {
        rankEvolution = prevRank - rankPos; // positivo = melhorou
    }

    // ── Loading skeleton ───────────────────────────────────────────────────────
    if (loading && !mainData) {
        return (
            <div className="max-w-7xl space-y-4 animate-pulse" data-testid="my-panel-loading">
                <div className="h-16 bg-muted rounded-sm" />
                <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
                    {[...Array(5)].map((_, i) => <div key={i} className="h-24 bg-muted rounded-sm" />)}
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                    {[...Array(3)].map((_, i) => <div key={i} className="h-48 bg-muted rounded-sm" />)}
                </div>
            </div>
        );
    }

    return (
        <div className="max-w-7xl space-y-5" data-testid="my-panel-page">

            {/* ── Header: nome + status + seletor de período ── */}
            <div className="bg-card border border-border/60 rounded-md px-5 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="min-w-0">
                    <p className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground">Meu Painel</p>
                    <h1 className="text-xl font-bold mt-0.5 truncate">{sellerName}</h1>
                </div>
                <div className="flex items-center gap-3 flex-wrap">
                    {/* Status atual + botão de alteração */}
                    {currentStatus && (
                        <div className="flex items-center gap-2">
                            <StatusBadge status={currentStatus} />
                            <Button
                                size="sm"
                                variant="outline"
                                className="h-7 text-xs gap-1.5"
                                onClick={() => setStatusModal(true)}
                                disabled={!sellerId}
                                data-testid="btn-change-status"
                            >
                                <RefreshCw size={11} />
                                Alterar
                            </Button>
                        </div>
                    )}
                    {/* Seletor de período */}
                    <div className="flex gap-0.5 bg-muted/50 p-0.5 rounded-sm border border-border/50">
                        {PERIOD_OPTIONS.map((opt) => (
                            <button
                                key={opt.value}
                                onClick={() => setPeriod(opt.value)}
                                className={`px-3 py-1 text-xs font-medium rounded-sm transition-all ${
                                    period === opt.value
                                        ? "bg-background shadow-xs text-foreground"
                                        : "text-muted-foreground hover:text-foreground"
                                }`}
                                data-testid={`period-btn-${opt.value}`}
                            >
                                {opt.label}
                            </button>
                        ))}
                    </div>
                </div>
            </div>

            {/* ── KPIs principais (6 cards) ── */}
            <div className="metric-grid-sm" data-testid="kpi-strip">
                <KpiCard
                    icon={Users} label="Atendimentos" testId="kpi-atendimentos"
                    value={(kpis.attendances_finished || 0).toLocaleString("pt-BR")}
                    delta={computeDelta(kpis.attendances_finished, prevKpis?.attendances_finished)}
                    colorCls="text-slate-700"
                />
                <KpiCard
                    icon={TrendingUp} label="Vendas" testId="kpi-vendas"
                    value={(kpis.sales_count || 0).toLocaleString("pt-BR")}
                    delta={computeDelta(kpis.sales_count, prevKpis?.sales_count)}
                    colorCls="text-luppa-purple"
                />
                <KpiCard
                    icon={BarChart2} label="Conversão" testId="kpi-conversao"
                    value={`${kpis.conversion_rate || 0}%`}
                    delta={computeDelta(kpis.conversion_rate, prevKpis?.conversion_rate)}
                    colorCls={(kpis.conversion_rate || 0) >= 50 ? "text-luppa-green" : "text-amber-600"}
                />
                <KpiCard
                    icon={DollarSign} label="Ticket Médio" testId="kpi-ticket"
                    value={abbreviateBRL(kpis.average_ticket_cents || 0)}
                    sub={fmtBRL(kpis.average_ticket_cents || 0)}
                    delta={computeDelta(kpis.average_ticket_cents, prevKpis?.average_ticket_cents)}
                    colorCls="text-luppa-purple"
                />
                <KpiCard
                    icon={DollarSign} label="Total Vendido" testId="kpi-total"
                    value={abbreviateBRL(kpis.sales_total_cents || 0)}
                    sub={goalsTotal > 0 ? `${goalsCompleted}/${goalsTotal} metas · ${goalsPct}%` : fmtBRL(kpis.sales_total_cents || 0)}
                    delta={computeDelta(kpis.sales_total_cents, prevKpis?.sales_total_cents)}
                    colorCls="text-luppa-green"
                />
                <KpiCard
                    icon={CheckCircle} label="PA" testId="kpi-pa"
                    value={(kpis.pa != null ? Number(kpis.pa) : 0).toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    sub={`${kpis.total_produtos_vendidos || 0} produtos`}
                    delta={computeDelta(Math.round((kpis.pa || 0) * 100), Math.round((prevKpis?.pa || 0) * 100))}
                    colorCls="text-violet-600"
                />
            </div>

            {/* ── Linha do meio: Ranking | Metas | Conquistas ── */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">

                {/* Ranking */}
                <SectionCard icon={Trophy} iconColor="text-amber-500" title="Ranking" testId="ranking-section">
                    {rankPos !== null ? (
                        <>
                            <div className="flex flex-col items-center py-4 gap-1 min-w-0">
                                <span className="metric-num-lg font-black text-foreground leading-none">{rankPos}º</span>
                                <p className="text-xs text-muted-foreground">posição na unidade</p>
                                {rankEvolution !== null && (
                                    <span className={`flex items-center gap-1 text-xs font-semibold mt-1 ${rankEvolution > 0 ? "text-luppa-green" : rankEvolution < 0 ? "text-luppa-error" : "text-muted-foreground"}`}>
                                        {rankEvolution > 0
                                            ? <><TrendingUp size={13} /> +{rankEvolution} vs período anterior</>
                                            : rankEvolution < 0
                                            ? <><TrendingDown size={13} /> {rankEvolution} vs período anterior</>
                                            : <><Minus size={13} /> Igual ao período anterior</>}
                                    </span>
                                )}
                            </div>
                            <div className="flex items-center justify-center gap-2 text-[10px] text-muted-foreground border-t border-border pt-2">
                                <Trophy size={11} />
                                Por receita · {PERIOD_OPTIONS.find(p => p.value === period)?.label}
                            </div>
                        </>
                    ) : (
                        <Empty icon={Trophy} text="Ranking não disponível para este período." />
                    )}
                </SectionCard>

                {/* Metas */}
                <SectionCard icon={Target} iconColor="text-luppa-purple" title="Metas" testId="goals-section">
                    {goals.length === 0 ? (
                        <Empty icon={Target} text="Nenhuma meta ativa no período." />
                    ) : (
                        <div className="space-y-3">
                            {goals.map((g) => {
                                const pct = goalProgress(g);
                                const statusClass = GOAL_STATUS_COLORS[g.status] || "bg-gray-50 text-gray-600 border-gray-200";
                                return (
                                <div key={g.id} className="space-y-1.5 min-w-0" data-testid={`goal-item-${g.id}`}>
                                    <div className="flex items-center justify-between gap-2 min-w-0">
                                        <span className="text-xs font-medium truncate flex-1 min-w-0" data-testid={`my-goal-title-${g.id}`}>{g.title}</span>
                                        <span className={`text-[10px] font-bold flex-shrink-0 ${pct >= 100 ? "text-luppa-green" : "text-muted-foreground"}`} data-testid={`my-goal-progress-${g.id}`}>
                                            {Math.round(pct)}%
                                        </span>
                                    </div>
                                    <div className="flex items-center gap-1.5 flex-wrap">
                                        <span className={`inline-flex items-center px-1.5 py-0.5 rounded border text-[9px] font-semibold ${statusClass}`} data-testid={`my-goal-status-${g.id}`}>
                                            {goalStatusLabel(g)}
                                        </span>
                                        <span className="inline-flex items-center px-1.5 py-0.5 rounded border border-border text-[9px] text-muted-foreground" data-testid={`my-goal-scope-${g.id}`}>
                                            {GOAL_SCOPE_PT[g.scope] || g.scope}
                                        </span>
                                    </div>
                                    <ProgressBar pct={pct} />
                                    <div className="flex justify-between text-[10px] text-muted-foreground gap-1 min-w-0">
                                        <span className="truncate min-w-0" data-testid={`my-goal-current-${g.id}`}>{fmtGoalCompact(g.type, g.current_value)} atingido</span>
                                        <span className="flex-shrink-0" data-testid={`my-goal-target-${g.id}`}>/ {fmtGoalCompact(g.type, g.target_value)}</span>
                                    </div>
                                </div>
                                );
                            })}
                        </div>
                    )}
                </SectionCard>

                {/* Conquistas */}
                <SectionCard icon={Award} iconColor="text-violet-500" title="Conquistas" testId="achievements-section">
                    {allAwards.length === 0 && nextAchievements.length === 0 ? (
                        <Empty icon={Award} text="Complete metas para desbloquear conquistas." />
                    ) : (
                        <>
                            {allAwards.length > 0 && (
                                <div>
                                    <p className="text-[9px] uppercase tracking-wider text-muted-foreground mb-2">Desbloqueadas</p>
                                    <div className="flex flex-wrap gap-1.5">
                                        {allAwards.map((a) => (
                                            <span
                                                key={a.id}
                                                title={a.achievement_name}
                                                className="inline-flex items-center gap-1 px-2 py-0.5 bg-amber-50 border border-amber-200 text-amber-800 text-[10px] font-semibold rounded-full max-w-[150px]"
                                                data-testid={`award-badge-${a.id}`}
                                            >
                                                <Star size={8} className="flex-shrink-0" />
                                                <span className="truncate">{a.achievement_name}</span>
                                            </span>
                                        ))}
                                    </div>
                                </div>
                            )}
                            {nextAchievements.length > 0 && (
                                <div className={allAwards.length > 0 ? "border-t border-border pt-3" : ""}>
                                    <p className="text-[9px] uppercase tracking-wider text-muted-foreground mb-2">Próximas</p>
                                    <div className="space-y-2.5">
                                        {nextAchievements.map((a) => (
                                            <div key={a.id} className="space-y-1" data-testid={`next-achievement-${a.id}`}>
                                                <div className="flex justify-between text-[10px] gap-2">
                                                    <span className="font-medium truncate">{a.name}</span>
                                                    <span className="text-muted-foreground flex-shrink-0">{Math.round(a.progress_pct || 0)}%</span>
                                                </div>
                                                <ProgressBar pct={a.progress_pct || 0} />
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </>
                    )}
                </SectionCard>
            </div>

            {/* ── Evolução Semanal ─────────────────────────────────────────── */}
            <SectionCard icon={TrendingUp} iconColor="text-luppa-green" title="Evolução Semanal" testId="weekly-evolution-section">
                {weeklyHistory.length > 0 && weeklyHistory.some(w => w.sales_count > 0 || w.attendances > 0) ? (
                    <div className="space-y-3">
                        <ResponsiveContainer width="100%" height={180}>
                            <AreaChart data={weeklyHistory} margin={{ top: 4, right: 12, bottom: 0, left: -20 }}>
                                <defs>
                                    <linearGradient id="gradVendas" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor="hsl(var(--chart-4))" stopOpacity={0.3} />
                                        <stop offset="95%" stopColor="hsl(var(--chart-4))" stopOpacity={0.02} />
                                    </linearGradient>
                                    <linearGradient id="gradAtt" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor="hsl(var(--chart-1))" stopOpacity={0.2} />
                                        <stop offset="95%" stopColor="hsl(var(--chart-1))" stopOpacity={0.02} />
                                    </linearGradient>
                                </defs>
                                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                                <XAxis
                                    dataKey="label"
                                    tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                                    tickLine={false}
                                />
                                <YAxis
                                    allowDecimals={false}
                                    tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }}
                                    tickLine={false}
                                    axisLine={false}
                                />
                                <Tooltip
                                    contentStyle={{ fontSize: 12, borderRadius: 6, border: "1px solid hsl(var(--border))", background: "hsl(var(--card))" }}
                                    labelStyle={{ fontWeight: 600, color: "hsl(var(--foreground))", marginBottom: 4 }}
                                    formatter={(value, name) => [
                                        value,
                                        name === "sales_count" ? "Vendas" : "Atendimentos",
                                    ]}
                                    labelFormatter={(label, payload) => {
                                        const item = payload?.[0]?.payload;
                                        const curLabel = item?.is_current ? " (semana atual)" : "";
                                        return `Semana ${label}${curLabel}`;
                                    }}
                                />
                                <Area
                                    type="monotone"
                                    dataKey="attendances"
                                    name="attendances"
                                    stroke="hsl(var(--chart-1))"
                                    strokeWidth={1.5}
                                    fill="url(#gradAtt)"
                                    dot={false}
                                    activeDot={{ r: 4 }}
                                />
                                <Area
                                    type="monotone"
                                    dataKey="sales_count"
                                    name="sales_count"
                                    stroke="hsl(var(--chart-4))"
                                    strokeWidth={2}
                                    fill="url(#gradVendas)"
                                    dot={(props) => {
                                        const { cx, cy, payload } = props;
                                        return payload.is_current
                                            ? <circle key={`dot-${payload.label}`} cx={cx} cy={cy} r={4} fill="hsl(var(--chart-4))" stroke="white" strokeWidth={2} />
                                            : <circle key={`dot-${payload.label}`} cx={cx} cy={cy} r={2.5} fill="hsl(var(--chart-4))" />;
                                    }}
                                    activeDot={{ r: 5 }}
                                />
                            </AreaChart>
                        </ResponsiveContainer>

                        {/* Legenda + sumário */}
                        <div className="flex items-center justify-between border-t border-border pt-2.5">
                            <div className="flex items-center gap-4">
                                <span className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
                                    <span className="w-3 h-0.5 bg-[hsl(var(--chart-4))] inline-block rounded" />
                                    Vendas
                                </span>
                                <span className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
                                    <span className="w-3 h-0.5 bg-[hsl(var(--chart-1))] inline-block rounded" />
                                    Atendimentos
                                </span>
                            </div>
                            {(() => {
                                const current = weeklyHistory.find(w => w.is_current);
                                const prev = weeklyHistory.slice(-2)[0];
                                if (!current || !prev || current === prev) return null;
                                const diff = current.sales_count - prev.sales_count;
                                if (diff === 0) return <span className="text-[10px] text-muted-foreground">Igual à semana anterior</span>;
                                return (
                                    <span className={`flex items-center gap-1 text-[10px] font-semibold ${diff > 0 ? "text-luppa-green" : "text-luppa-error"}`}>
                                        {diff > 0 ? <TrendingUp size={11} /> : <TrendingDown size={11} />}
                                        {Math.abs(diff)} venda{Math.abs(diff) !== 1 ? "s" : ""} {diff > 0 ? "a mais" : "a menos"} que semana passada
                                    </span>
                                );
                            })()}
                        </div>
                    </div>
                ) : (
                    <Empty icon={TrendingUp} text="Nenhuma venda registrada nas últimas 8 semanas." />
                )}
            </SectionCard>

            {/* ── Linha inferior: Feedbacks | Visão de Desempenho ── */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">

                {/* Feedbacks */}
                <SectionCard icon={MessageSquare} iconColor="text-slate-500" title="Últimos Feedbacks" testId="feedbacks-section">
                    {feedbacks.length === 0 ? (
                        <Empty icon={MessageSquare} text="Nenhum feedback recebido ainda." />
                    ) : (
                        <div className="space-y-2">
                            {feedbacks.slice(0, 4).map((f) => (
                                <div key={f.id} className="border border-border rounded-sm p-3 space-y-1" data-testid={`feedback-item-${f.id}`}>
                                    <div className="flex items-start justify-between gap-2">
                                        <p className="text-xs font-semibold leading-tight">{f.title}</p>
                                        <span className={`text-[9px] px-1.5 py-0.5 rounded border font-semibold flex-shrink-0 ${FEEDBACK_TYPE_COLORS[f.type] || "bg-muted text-muted-foreground"}`}>
                                            {FEEDBACK_TYPE_LABELS[f.type] || f.type}
                                        </span>
                                    </div>
                                    <p className="text-[11px] text-muted-foreground line-clamp-2">{f.content}</p>
                                    <div className="flex items-center justify-between pt-0.5">
                                        <p className="text-[10px] text-muted-foreground font-medium">{f.author_name}</p>
                                        <div className="flex items-center gap-2">
                                            {f.period_start && (
                                                <p className="text-[10px] text-muted-foreground">
                                                    {fmtDate(f.period_start + "T12:00:00")} →{" "}
                                                    {fmtDate(f.period_end + "T12:00:00")}
                                                </p>
                                            )}
                                            {f.is_acknowledged && (
                                                <CheckCircle size={11} className="text-luppa-green flex-shrink-0" />
                                            )}
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </SectionCard>

                {/* Gráfico de desempenho: Hoje / Semana / Mês */}
                <SectionCard icon={Zap} iconColor="text-luppa-purple" title="Visão de Desempenho" testId="performance-overview">
                    {overview.some(d => d.vendas > 0) ? (
                        <>
                            <ResponsiveContainer width="100%" height={180}>
                                <BarChart data={overview} margin={{ top: 4, right: 8, bottom: 0, left: -20 }}>
                                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                                    <XAxis dataKey="label" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
                                    <YAxis tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} allowDecimals={false} />
                                    <Tooltip formatter={(v, name) => [v, name === "vendas" ? "Vendas" : "Conversão %"]} />
                                    <Bar dataKey="vendas" name="Vendas" fill="hsl(var(--chart-4))" radius={[3, 3, 0, 0]} maxBarSize={40} />
                                    <Bar dataKey="conv" name="Conversão %" fill="hsl(var(--chart-1))" radius={[3, 3, 0, 0]} maxBarSize={40} />
                                </BarChart>
                            </ResponsiveContainer>
                            <p className="text-[10px] text-center text-muted-foreground">
                                Azul: Qtd. Vendas · Verde: Conversão %
                            </p>
                            <div className="grid grid-cols-3 gap-2 border-t border-border pt-3">
                                {overview.map((d) => (
                                    <div key={d.label} className="text-center">
                                        <p className="text-sm font-bold text-foreground">{d.vendas}</p>
                                        <p className="text-[10px] text-muted-foreground">{d.label}</p>
                                        <p className="text-[10px] text-primary font-medium">{d.conv}%</p>
                                    </div>
                                ))}
                            </div>
                        </>
                    ) : (
                        <Empty icon={BarChart2} text="Nenhuma venda registrada nos períodos analisados." />
                    )}
                </SectionCard>
            </div>

            {/* Modal de alteração de status */}
            {statusModal && sellerId && (
                <StatusChangeModal
                    sellerId={sellerId}
                    currentStatus={currentStatus}
                    tenantSlug={tenantSlug}
                    onClose={() => setStatusModal(false)}
                    onSaved={(s) => setCurrentStatus(s)}
                />
            )}
        </div>
    );
}
