import React, { useEffect, useState, useCallback } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeft, Check, X, UserCheck, Download, RefreshCw } from "lucide-react";
import api from "@/lib/api";
import { PageHeader } from "@/components/Common";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { usePermissions } from "@/hooks/usePermissions";

const STATUS_COLORS = { OPEN: "bg-luppa-warning/15 text-luppa-warning", IN_REVIEW: "bg-luppa-purple/15 text-luppa-purple", PROCESSING: "bg-luppa-purple/15 text-luppa-purple", RESOLVED: "bg-luppa-green/15 text-luppa-green", REJECTED: "bg-luppa-error/15 text-luppa-error", CANCELLED: "bg-gray-100 text-gray-700" };
const STATUS_PT = { OPEN: "Aberta", IN_REVIEW: "Em revisão", PROCESSING: "Processando", RESOLVED: "Resolvida", REJECTED: "Rejeitada", CANCELLED: "Cancelada" };
const TYPE_PT = { ACCESS: "Acesso", CORRECTION: "Correção", ANONYMIZATION: "Anonimização", DELETION: "Exclusão", PORTABILITY: "Portabilidade", CONSENT_WITHDRAWAL: "Retirada de consentimento", RESTRICTION: "Restrição", INFORMATION: "Informação" };

export default function PrivacyRequestDetailPage() {
    const { tenantSlug, requestId } = useParams();
    const navigate = useNavigate();
    const { hasPermission } = usePermissions();
    const [req, setReq] = useState(null);
    const [loading, setLoading] = useState(true);
    const [notes, setNotes] = useState("");
    const [acting, setActing] = useState(false);
    const [exportDone, setExportDone] = useState(false);

    const canResolve = hasPermission("privacy.requests.resolve");
    const canExport = hasPermission("privacy.requests.export");
    const canAnonymize = hasPermission("privacy.requests.anonymize");

    const load = useCallback(async () => {
        setLoading(true);
        try {
            const res = await api.get(`/tenants/${tenantSlug}/privacy/requests/${requestId}`);
            setReq(res.data);
        } catch {
            toast.error("Erro ao carregar solicitação.");
        } finally {
            setLoading(false);
        }
    }, [tenantSlug, requestId]);

    useEffect(() => { load(); }, [load]);

    const changeStatus = async (status, reason = "") => {
        setActing(true);
        try {
            const endpoint = status === "RESOLVED"
                ? `/tenants/${tenantSlug}/privacy/requests/${requestId}/resolve`
                : `/tenants/${tenantSlug}/privacy/requests/${requestId}/reject`;
            const body = status === "RESOLVED" ? { notes: reason || notes } : { reason: reason || notes };
            await api.post(endpoint, body);
            toast.success(`Solicitação ${status === "RESOLVED" ? "resolvida" : "rejeitada"}!`);
            load();
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Erro ao atualizar status.");
        } finally {
            setActing(false);
        }
    };

    const handleInReview = async () => {
        setActing(true);
        try {
            await api.put(`/tenants/${tenantSlug}/privacy/requests/${requestId}`, { status: "IN_REVIEW", notes });
            toast.success("Solicitação em revisão.");
            load();
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Erro.");
        } finally {
            setActing(false);
        }
    };

    const handleExport = async () => {
        if (!req) return;
        setActing(true);
        try {
            const res = await api.post(`/tenants/${tenantSlug}/privacy/data-exports`, {
                subject_user_id: req.data_subject_user_id,
                file_format: "JSON"
            });
            toast.success("Exportação iniciada! Disponível em Exportações de Dados.");
            setExportDone(true);
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Erro ao exportar dados.");
        } finally {
            setActing(false);
        }
    };

    if (loading) return <div className="space-y-4"><Skeleton className="h-10 w-40" /><Skeleton className="h-64" /></div>;
    if (!req) return <div className="text-center py-10 text-muted-foreground">Solicitação não encontrada.</div>;

    const isOpen = ["OPEN", "IN_REVIEW", "WAITING_VERIFICATION"].includes(req.status);

    return (
        <div data-testid="privacy-request-detail-page">
            <div className="flex items-center gap-3 mb-6">
                <button onClick={() => navigate(`/${tenantSlug}/privacy/requests`)}
                    className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors">
                    <ArrowLeft size={14} /> Voltar
                </button>
            </div>

            <div className="max-w-2xl space-y-5">
                <Card className="border border-border shadow-sm">
                    <CardContent className="p-5">
                        <div className="flex items-center justify-between mb-4">
                            <div>
                                <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground">{TYPE_PT[req.request_type] || req.request_type}</p>
                                <h2 className="text-lg font-medium mt-0.5">{req.data_subject_name || "Titular não identificado"}</h2>
                            </div>
                            <span className={`text-xs px-3 py-1 rounded-full font-medium ${STATUS_COLORS[req.status] || "bg-gray-100 text-gray-600"}`}>
                                {STATUS_PT[req.status] || req.status}
                            </span>
                        </div>
                        <div className="grid grid-cols-2 gap-3 text-sm">
                            <div><p className="text-xs text-muted-foreground mb-0.5">E-mail</p><p>{req.data_subject_email || "—"}</p></div>
                            <div><p className="text-xs text-muted-foreground mb-0.5">Prioridade</p><p>{req.priority}</p></div>
                            <div><p className="text-xs text-muted-foreground mb-0.5">Criada em</p><p>{req.created_at?.slice(0, 10)}</p></div>
                            <div><p className="text-xs text-muted-foreground mb-0.5">Prazo</p><p>{req.due_at?.slice(0, 10) || "—"}</p></div>
                        </div>
                        {req.description && (
                            <div className="mt-4 pt-4 border-t border-border">
                                <p className="text-xs text-muted-foreground mb-1">Descrição</p>
                                <p className="text-sm">{req.description}</p>
                            </div>
                        )}
                        {req.resolution_notes && (
                            <div className="mt-4 pt-4 border-t border-border">
                                <p className="text-xs text-muted-foreground mb-1">Notas de Resolução</p>
                                <p className="text-sm">{req.resolution_notes}</p>
                            </div>
                        )}
                    </CardContent>
                </Card>

                {isOpen && canResolve && (
                    <Card className="border border-border shadow-sm">
                        <CardContent className="p-5">
                            <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground mb-3">Ações</p>
                            <textarea
                                className="w-full border border-border rounded-sm px-3 py-2 text-sm mb-3"
                                rows={2}
                                placeholder="Notas ou motivo..."
                                value={notes}
                                onChange={e => setNotes(e.target.value)}
                                data-testid="request-notes-input"
                            />
                            <div className="flex flex-wrap gap-2">
                                <Button size="sm" variant="outline" onClick={handleInReview} disabled={acting} data-testid="btn-in-review">
                                    <RefreshCw size={13} className="mr-1.5" /> Em revisão
                                </Button>
                                {canExport && req.data_subject_user_id && (
                                    <Button size="sm" variant="outline" onClick={handleExport} disabled={acting || exportDone} data-testid="btn-export-subject">
                                        <Download size={13} className="mr-1.5" /> Exportar Dados
                                    </Button>
                                )}
                                <Button size="sm" onClick={() => changeStatus("RESOLVED")} disabled={acting} data-testid="btn-resolve-request">
                                    <Check size={13} className="mr-1.5" /> Resolver
                                </Button>
                                <Button size="sm" variant="destructive" onClick={() => changeStatus("REJECTED")} disabled={acting} data-testid="btn-reject-request">
                                    <X size={13} className="mr-1.5" /> Rejeitar
                                </Button>
                            </div>
                        </CardContent>
                    </Card>
                )}
            </div>
        </div>
    );
}
