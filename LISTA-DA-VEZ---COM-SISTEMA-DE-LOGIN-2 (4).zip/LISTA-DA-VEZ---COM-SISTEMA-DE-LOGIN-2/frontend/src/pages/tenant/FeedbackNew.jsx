import { useState, useEffect, useCallback } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
    ArrowLeft, Send, Trophy, Target, TrendingUp,
    BarChart2, DollarSign, Users, RefreshCw, AlertCircle,
} from "lucide-react";
import { toast } from "sonner";
import api, { extractError } from "@/lib/api";
import { usePermissions } from "@/hooks/usePermissions";
import { fmtDate, fmtBRL, GOAL_STATUS_PT } from "@/lib/i18n";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

const FEEDBACK_TYPES = [
    { value: "POSITIVE", label: "Positivo — Reconhecimento de bom desempenho" },
    { value: "CONSTRUCTIVE", label: "Construtivo — Sugestão de melhoria" },
    { value: "WARNING", label: "Aviso — Ponto de atenção importante" },
    { value: "ACTION_PLAN", label: "Plano de Ação — Requer ação do vendedor" },
];

const GOAL_TYPE_LABELS = {
    REVENUE: "Receita",
    CONVERSION: "Conversão",
    SALES_COUNT: "Qtd. Vendas",
    ATTENDANCES: "Atendimentos",
    AVERAGE_TICKET: "Ticket Médio",
    ITEMS_SOLD: "Produtos vendidos",
};

const GOAL_STATUS_CLASSES = {
    ACTIVE: "bg-luppa-purple/10 text-luppa-purple",
    COMPLETED: "bg-luppa-green/10 text-luppa-green",
    EXPIRED: "bg-slate-100 text-slate-500",
    CANCELLED: "bg-luppa-error/10 text-luppa-error",
};

const GOAL_STATUS_LABELS = GOAL_STATUS_PT;

function fmtGoalValue(type, value) {
    if (type === "REVENUE" || type === "AVERAGE_TICKET") return fmtBRL(value);
    if (type === "CONVERSION") return `${(value / 100).toFixed(1)}%`;
    return (value ?? 0).toLocaleString("pt-BR");
}

function ProgressBar({ pct }) {
    const clamped = Math.min(100, Math.max(0, pct));
    const color = clamped >= 100 ? "bg-luppa-green" : clamped >= 60 ? "bg-luppa-purple" : "bg-amber-400";
    return (
        <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
            <div className={`h-full rounded-full transition-all ${color}`} style={{ width: `${clamped}%` }} />
        </div>
    );
}

function KpiCard({ icon: Icon, label, value, sub, color = "text-slate-700" }) {
    return (
        <div className="bg-card border border-border/60 rounded-md p-3">
            <div className="flex items-center justify-between mb-1">
                <p className="text-[11px] text-muted-foreground font-medium uppercase tracking-wide">{label}</p>
                <Icon size={13} className={`${color} opacity-70`} />
            </div>
            <p className={`text-lg font-bold ${color}`} data-testid={`ctx-kpi-${label.toLowerCase().replace(/\s/g, "-")}`}>{value}</p>
            {sub && <p className="text-[10px] text-muted-foreground mt-0.5">{sub}</p>}
        </div>
    );
}

function PanelSkeleton() {
    return (
        <div className="bg-card border border-border/60 rounded-md p-5 space-y-4 animate-pulse" data-testid="panel-loading">
            <div className="h-4 bg-slate-100 rounded w-1/2" />
            <div className="grid grid-cols-2 gap-2">
                {[...Array(6)].map((_, i) => <div key={i} className="h-16 bg-slate-50 rounded border" />)}
            </div>
            <div className="h-4 bg-slate-100 rounded w-1/3" />
            <div className="space-y-2">
                {[...Array(3)].map((_, i) => <div key={i} className="h-12 bg-slate-50 rounded border" />)}
            </div>
        </div>
    );
}

function PanelEmpty() {
    return (
        <div className="bg-card border border-dashed border-border rounded-md p-8 flex flex-col items-center justify-center text-center gap-3" data-testid="panel-empty">
            <BarChart2 size={32} className="text-slate-300" />
            <div>
                <p className="text-sm font-medium text-slate-500">Painel de Desempenho</p>
                <p className="text-xs text-muted-foreground mt-1">
                    Selecione um vendedor e o período de referência para visualizar os indicadores de desempenho.
                </p>
            </div>
        </div>
    );
}

function SellerPerformancePanel({ loading, data }) {
    if (loading) return <PanelSkeleton />;
    if (!data) return <PanelEmpty />;

    const { kpis, goals, ranking } = data;

    return (
        <div className="bg-card border border-border/60 rounded-md p-5 space-y-5" data-testid="seller-performance-panel">
            {/* Header */}
            <div>
                <p className="text-xs uppercase tracking-[0.16em] text-muted-foreground">Desempenho no Período</p>
                <p className="font-semibold mt-0.5">{data.seller_name}</p>
                <p className="text-xs text-muted-foreground">
                    {fmtDate(data.period_start + "T12:00:00")} →{" "}
                    {fmtDate(data.period_end + "T12:00:00")}
                </p>
            </div>

            {/* KPIs grid */}
            <div>
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Indicadores</p>
                <div className="grid grid-cols-2 gap-2">
                    <KpiCard icon={Users} label="Atendimentos" value={kpis.total_atendimentos.toLocaleString("pt-BR")} color="text-slate-700" />
                    <KpiCard icon={TrendingUp} label="Vendas" value={kpis.vendas.toLocaleString("pt-BR")} color="text-luppa-purple" />
                    <KpiCard
                        icon={BarChart2}
                        label="Conversão"
                        value={`${kpis.conversao_pct}%`}
                        sub={`${kpis.finalizados} finalizados`}
                        color={kpis.conversao_pct >= 50 ? "text-luppa-green" : kpis.conversao_pct >= 25 ? "text-amber-600" : "text-luppa-error"}
                    />
                    <KpiCard icon={DollarSign} label="Ticket Médio" value={fmtBRL(kpis.ticket_medio_cents)} color="text-luppa-purple" />
                    <div className="col-span-2">
                        <KpiCard icon={DollarSign} label="Receita Total" value={fmtBRL(kpis.receita_total_cents)} color="text-luppa-green" />
                    </div>
                </div>
            </div>

            {/* Ranking */}
            <div>
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Ranking</p>
                <div className="flex items-center gap-3 p-3 bg-amber-50 border border-amber-200 rounded-sm" data-testid="ranking-position">
                    <Trophy size={20} className={ranking.position === 1 ? "text-amber-500" : ranking.position === 2 ? "text-slate-400" : ranking.position === 3 ? "text-amber-700" : "text-slate-400"} />
                    <div>
                        <p className="font-bold text-base">
                            {ranking.position}º lugar
                        </p>
                        <p className="text-xs text-muted-foreground">
                            de {ranking.total_sellers} vendedor{ranking.total_sellers !== 1 ? "es" : ""} na unidade · por Receita
                        </p>
                    </div>
                </div>
            </div>

            {/* Metas */}
            <div>
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Metas no Período</p>
                {goals.length === 0 ? (
                    <div className="text-center py-4 text-xs text-muted-foreground border border-dashed border-border rounded-sm">
                        Nenhuma meta encontrada para este período.
                    </div>
                ) : (
                    <div className="space-y-2" data-testid="goals-list">
                        {goals.map((g) => (
                            <div key={g.id} className="border border-border rounded-sm p-3 space-y-2" data-testid={`goal-item-${g.id}`}>
                                <div className="flex items-start justify-between gap-2">
                                    <div className="min-w-0">
                                        <p className="text-xs font-medium truncate">{g.title}</p>
                                        <p className="text-[10px] text-muted-foreground">
                                            {GOAL_TYPE_LABELS[g.type] || g.type} · {g.scope === "SELLER" ? "Individual" : "Unidade"}
                                        </p>
                                    </div>
                                    <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded flex-shrink-0 ${GOAL_STATUS_CLASSES[g.status] || ""}`}>
                                        {GOAL_STATUS_LABELS[g.status] || g.status}
                                    </span>
                                </div>
                                <ProgressBar pct={g.progress_pct} />
                                <div className="flex justify-between text-[10px] text-muted-foreground">
                                    <span>{fmtGoalValue(g.type, g.current_value)} atingido</span>
                                    <span className="font-medium">{g.progress_pct}% de {fmtGoalValue(g.type, g.target_value)}</span>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}

export default function FeedbackNew() {
    const { tenantSlug } = useParams();
    const nav = useNavigate();
    const { hasPermission } = usePermissions();
    const [sellers, setSellers] = useState([]);
    const [loading, setLoading] = useState(false);
    const [contextData, setContextData] = useState(null);
    const [contextLoading, setContextLoading] = useState(false);
    const [form, setForm] = useState({
        seller_id: "",
        type: "CONSTRUCTIVE",
        title: "",
        content: "",
        hasActionPlan: false,
        ap_description: "",
        ap_due_date: "",
        period_start: "",
        period_end: "",
    });

    useEffect(() => {
        api.get(`/tenants/${tenantSlug}/sellers`).then((r) => setSellers(r.data)).catch(() => {});
    }, [tenantSlug]);

    const fetchContext = useCallback(async (seller_id, date_from, date_to) => {
        setContextLoading(true);
        setContextData(null);
        try {
            const res = await api.get(`/tenants/${tenantSlug}/feedbacks/seller-context`, {
                params: { seller_id, date_from, date_to },
            });
            setContextData(res.data);
        } catch (e) {
            toast.error("Não foi possível carregar os dados de desempenho.");
            setContextLoading(false);
        } finally {
            setContextLoading(false);
        }
    }, [tenantSlug]);

    useEffect(() => {
        if (form.seller_id && form.period_start && form.period_end) {
            fetchContext(form.seller_id, form.period_start, form.period_end);
        } else {
            setContextData(null);
        }
    }, [form.seller_id, form.period_start, form.period_end, fetchContext]);

    const set = (k, v) => setForm((prev) => ({ ...prev, [k]: v }));

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!form.seller_id) { toast.error("Selecione um vendedor."); return; }
        if (!form.period_start) { toast.error("Informe a data inicial do período."); return; }
        if (!form.period_end) { toast.error("Informe a data final do período."); return; }
        if (form.period_end < form.period_start) { toast.error("A data final deve ser maior ou igual à data inicial."); return; }
        if (!form.title.trim()) { toast.error("Título é obrigatório."); return; }
        if (!form.content.trim()) { toast.error("Conteúdo é obrigatório."); return; }
        if (form.type === "ACTION_PLAN" && !form.ap_description.trim()) {
            toast.error("Descrição do plano de ação é obrigatória."); return;
        }

        const payload = {
            seller_id: form.seller_id,
            type: form.type,
            title: form.title.trim(),
            content: form.content.trim(),
            period_start: form.period_start || undefined,
            period_end: form.period_end || undefined,
        };
        if (form.hasActionPlan || form.type === "ACTION_PLAN") {
            payload.action_plan = {
                description: form.ap_description.trim(),
                due_date: form.ap_due_date || undefined,
            };
        }

        setLoading(true);
        try {
            const res = await api.post(`/tenants/${tenantSlug}/feedbacks`, payload);
            toast.success("Feedback enviado com sucesso!");
            nav(`/${tenantSlug}/feedbacks/${res.data.id}`);
        } catch (e) {
            toast.error(extractError(e));
        } finally {
            setLoading(false);
        }
    };

    const requiresActionPlan = form.type === "ACTION_PLAN";
    const showPanel = !!(form.seller_id && form.period_start && form.period_end);

    return (
        <div className={showPanel ? "max-w-7xl" : "max-w-2xl"}>
            {/* Header */}
            <div className="flex items-center gap-3 mb-6">
                <Button variant="ghost" size="icon" onClick={() => nav(-1)} data-testid="btn-back">
                    <ArrowLeft size={16} />
                </Button>
                <div>
                    <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">Feedbacks</p>
                    <h1 className="text-2xl font-semibold mt-0.5">Novo Feedback</h1>
                </div>
            </div>

            <div className={showPanel ? "grid grid-cols-1 xl:grid-cols-[1fr_420px] gap-6 items-start" : ""}>
                {/* Form */}
                <form
                    onSubmit={handleSubmit}
                    className="bg-card border border-border/60 rounded-md p-6 space-y-5"
                    data-testid="feedback-new-form"
                >
                    {/* Vendedor */}
                    <div className="space-y-1.5">
                        <Label htmlFor="seller_id">Vendedor *</Label>
                        <Select value={form.seller_id} onValueChange={(v) => set("seller_id", v)}>
                            <SelectTrigger id="seller_id" data-testid="input-seller-id">
                                <SelectValue placeholder="Selecione o vendedor…" />
                            </SelectTrigger>
                            <SelectContent>
                                {sellers.map((s) => (
                                    <SelectItem key={s.id} value={s.id}>
                                        {s.user?.name || s.employee_code || s.id}
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>

                    {/* Período de Referência */}
                    <div className="space-y-2">
                        <Label>Período de Referência *</Label>
                        <p className="text-xs text-muted-foreground -mt-1">
                            Defina o período para visualizar o desempenho do vendedor e embasar o feedback.
                        </p>
                        <div className="grid grid-cols-2 gap-3">
                            <div className="space-y-1.5">
                                <Label htmlFor="period_start" className="text-xs text-muted-foreground">Data Inicial</Label>
                                <Input
                                    id="period_start"
                                    type="date"
                                    value={form.period_start}
                                    onChange={(e) => set("period_start", e.target.value)}
                                    data-testid="input-period-start"
                                />
                            </div>
                            <div className="space-y-1.5">
                                <Label htmlFor="period_end" className="text-xs text-muted-foreground">Data Final</Label>
                                <Input
                                    id="period_end"
                                    type="date"
                                    value={form.period_end}
                                    min={form.period_start || undefined}
                                    onChange={(e) => set("period_end", e.target.value)}
                                    data-testid="input-period-end"
                                />
                            </div>
                        </div>
                        {form.seller_id && form.period_start && form.period_end && (
                            <div className="flex items-center gap-1.5 text-xs text-luppa-purple mt-1">
                                <BarChart2 size={12} />
                                {contextLoading
                                    ? "Carregando desempenho do vendedor…"
                                    : contextData
                                    ? "Painel de desempenho carregado na lateral."
                                    : "Verifique o painel de desempenho ao lado."}
                            </div>
                        )}
                    </div>

                    {/* Tipo */}
                    <div className="space-y-1.5">
                        <Label htmlFor="type">Tipo *</Label>
                        <Select value={form.type} onValueChange={(v) => set("type", v)}>
                            <SelectTrigger id="type" data-testid="input-type">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                {FEEDBACK_TYPES.map((t) => (
                                    <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>

                    {/* Título */}
                    <div className="space-y-1.5">
                        <Label htmlFor="title">Título *</Label>
                        <Input
                            id="title"
                            value={form.title}
                            onChange={(e) => set("title", e.target.value)}
                            placeholder="Resumo do feedback…"
                            data-testid="input-title"
                            maxLength={120}
                        />
                    </div>

                    {/* Conteúdo */}
                    <div className="space-y-1.5">
                        <Label htmlFor="content">Conteúdo *</Label>
                        <Textarea
                            id="content"
                            value={form.content}
                            onChange={(e) => set("content", e.target.value)}
                            placeholder="Descreva o feedback em detalhes…"
                            rows={4}
                            data-testid="input-content"
                        />
                    </div>

                    {/* Plano de Ação */}
                    {!requiresActionPlan && (
                        <div className="flex items-center gap-2">
                            <input
                                type="checkbox"
                                id="hasActionPlan"
                                checked={form.hasActionPlan}
                                onChange={(e) => set("hasActionPlan", e.target.checked)}
                                className="rounded border-border"
                                data-testid="toggle-action-plan"
                            />
                            <Label htmlFor="hasActionPlan" className="font-normal cursor-pointer">
                                Incluir plano de ação
                            </Label>
                        </div>
                    )}

                    {(form.hasActionPlan || requiresActionPlan) && (
                        <div className="border border-luppa-purple/25 rounded-sm p-4 space-y-4 bg-luppa-purple/10/30">
                            <p className="text-xs font-semibold text-luppa-purple uppercase tracking-wide">Plano de Ação</p>
                            <div className="space-y-1.5">
                                <Label htmlFor="ap_description">Descrição da ação *</Label>
                                <Textarea
                                    id="ap_description"
                                    value={form.ap_description}
                                    onChange={(e) => set("ap_description", e.target.value)}
                                    placeholder="O que o vendedor deve fazer?"
                                    rows={3}
                                    data-testid="input-ap-description"
                                />
                            </div>
                            <div className="space-y-1.5">
                                <Label htmlFor="ap_due_date">Prazo (opcional)</Label>
                                <Input
                                    id="ap_due_date"
                                    type="date"
                                    value={form.ap_due_date}
                                    onChange={(e) => set("ap_due_date", e.target.value)}
                                    data-testid="input-ap-due-date"
                                />
                            </div>
                        </div>
                    )}

                    <div className="flex gap-3 pt-2">
                        <Button type="submit" disabled={loading} data-testid="btn-submit-feedback">
                            <Send size={14} className="mr-2" />
                            {loading ? "Enviando…" : "Enviar Feedback"}
                        </Button>
                        <Button type="button" variant="outline" onClick={() => nav(-1)}>
                            Cancelar
                        </Button>
                    </div>
                </form>

                {/* Performance Panel */}
                {showPanel && (
                    <div className="xl:sticky xl:top-4">
                        <SellerPerformancePanel loading={contextLoading} data={contextData} />
                    </div>
                )}
            </div>
        </div>
    );
}
