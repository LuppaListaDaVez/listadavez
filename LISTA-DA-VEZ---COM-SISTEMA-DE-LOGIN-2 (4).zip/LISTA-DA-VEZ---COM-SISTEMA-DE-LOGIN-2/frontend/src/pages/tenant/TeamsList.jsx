import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import api, { extractError } from "@/lib/api";
import { useTenant } from "@/context/TenantContext";
import { usePermissions } from "@/hooks/usePermissions";
import { PageHeader, EmptyState } from "@/components/Common";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
    Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
    Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
    Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
    AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
    AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Plus, Pencil, Users, Trophy, TrendingUp } from "lucide-react";
import { toast } from "sonner";

const PERIOD_LABELS = { week: "Esta semana", month: "Este mês", all: "Geral" };
const MEDAL_CLASSES = [
    { bg: "bg-amber-100/80", text: "text-amber-600", bar: "bg-amber-400" },
    { bg: "bg-muted",        text: "text-muted-foreground", bar: "bg-muted-foreground/60" },
    { bg: "bg-muted/70",     text: "text-muted-foreground/80", bar: "bg-muted-foreground/40" },
];

// ── Helpers ──────────────────────────────────────────────────────────────────
function fmtCurrency(cents) {
    return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" })
        .format((cents || 0) / 100);
}

function UserAvatar({ src, name, size = 7 }) {
    const initials = (name || "?").split(" ").slice(0, 2).map((n) => n[0]).join("").toUpperCase();
    if (src) {
        return (
            <img src={src} alt={name}
                className={`w-${size} h-${size} rounded-full object-cover border border-border`} />
        );
    }
    return (
        <div className={`w-${size} h-${size} rounded-full bg-primary/10 text-primary flex items-center justify-center text-[11px] font-semibold border border-border`}>
            {initials}
        </div>
    );
}

// ── Ranking Visual ───────────────────────────────────────────────────────────
function TeamRanking({ tenantSlug }) {
    const [rankings, setRankings] = useState([]);
    const [period, setPeriod] = useState("month");
    const [loading, setLoading] = useState(true);

    const load = async (p) => {
        setLoading(true);
        try {
            const { data } = await api.get(`/tenants/${tenantSlug}/teams/rankings?period=${p}`);
            setRankings(data);
        } catch { setRankings([]); }
        finally { setLoading(false); }
    };

    useEffect(() => { load(period); }, [period]);

    const maxSales = rankings[0]?.sales || 1;

    return (
        <Card className="border border-border shadow-sm mt-8">
            <CardHeader className="px-6 py-4 border-b border-border flex flex-row items-center justify-between gap-4">
                <CardTitle className="text-sm font-semibold flex items-center gap-2">
                    <Trophy size={15} className="text-amber-500" />
                    Ranking de Equipes
                </CardTitle>
                <div className="flex gap-1">
                    {Object.entries(PERIOD_LABELS).map(([k, label]) => (
                        <button
                            key={k}
                            onClick={() => setPeriod(k)}
                            data-testid={`ranking-period-${k}`}
                            className={`text-xs px-3 py-1 rounded-full transition-colors ${
                                period === k
                                    ? "bg-primary text-primary-foreground font-medium"
                                    : "bg-muted text-muted-foreground hover:bg-muted/80"
                            }`}
                        >
                            {label}
                        </button>
                    ))}
                </div>
            </CardHeader>
            <CardContent className="p-5">
                {loading ? (
                    <p className="text-sm text-muted-foreground text-center py-4">Carregando ranking…</p>
                ) : rankings.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-8 gap-2 text-muted-foreground">
                        <TrendingUp size={28} strokeWidth={1.2} />
                        <p className="text-sm">Nenhuma venda registrada neste período.</p>
                        <p className="text-xs">As equipes aparecerão aqui quando houver atendimentos fechados como vendidos.</p>
                    </div>
                ) : (
                    <div className="space-y-3">
                        {rankings.map((item) => {
                            const isTop = item.rank === 1;
                            const medalStyle = MEDAL_CLASSES[item.rank - 1] || { bg: "bg-muted/30", text: "text-muted-foreground", bar: "bg-muted-foreground/30" };
                            const pct = Math.max(6, Math.round((item.sales / maxSales) * 100));
                            return (
                                <div
                                    key={item.team_id}
                                    data-testid={`ranking-row-${item.rank}`}
                                    className={`flex items-center gap-4 p-3 rounded-lg border transition-all ${
                                        isTop
                                            ? "border-amber-200 bg-amber-50/60 dark:bg-amber-900/10 dark:border-amber-800"
                                            : "border-border bg-muted/20"
                                    }`}
                                >
                                    {/* Medal / Rank */}
                                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold shrink-0 ${medalStyle.bg} ${medalStyle.text}`}>
                                        {item.rank <= 3 ? ["🥇", "🥈", "🥉"][item.rank - 1] : item.rank}
                                    </div>

                                    {/* Info */}
                                    <div className="flex-1 min-w-0">
                                        <div className="flex items-center justify-between mb-1.5">
                                            <div>
                                                <span className={`text-sm font-semibold ${isTop ? "text-amber-700 dark:text-amber-400" : ""}`}>
                                                    {item.team_name}
                                                </span>
                                                {item.store_name && (
                                                    <span className="text-xs text-muted-foreground ml-2">· {item.store_name}</span>
                                                )}
                                            </div>
                                            <div className="text-right shrink-0 ml-4">
                                                <span className="text-sm font-bold" data-testid={`ranking-sales-${item.rank}`}>
                                                    {item.sales}
                                                    <span className="text-xs font-normal text-muted-foreground ml-1">
                                                        {item.sales === 1 ? "venda" : "vendas"}
                                                    </span>
                                                </span>
                                                {item.revenue_cents > 0 && (
                                                    <p className="text-xs text-muted-foreground">{fmtCurrency(item.revenue_cents)}</p>
                                                )}
                                            </div>
                                        </div>
                                        {/* Barra de progresso */}
                                        <div className="h-1.5 w-full bg-muted rounded-full overflow-hidden">
                                            <div
                                                className={`h-full rounded-full transition-all duration-500 ${medalStyle.bar}`}
                                                style={{ width: `${pct}%` }}
                                            />
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                )}
            </CardContent>
        </Card>
    );
}

// ── Página Principal ─────────────────────────────────────────────────────────
export default function TeamsList() {
    const { tenantSlug } = useParams();
    const { context } = useTenant();
    const { hasPermission } = usePermissions();
    const canCreate = hasPermission("teams.create");
    const canEdit = hasPermission("teams.update");

    const [teams, setTeams] = useState([]);
    const [loading, setLoading] = useState(true);
    const [createOpen, setCreateOpen] = useState(false);
    const [editTarget, setEditTarget] = useState(null);

    const load = async () => {
        setLoading(true);
        try {
            const { data } = await api.get(`/tenants/${tenantSlug}/teams`);
            setTeams(data);
        } catch (e) {
            toast.error(extractError(e, "Erro ao carregar equipes"));
        } finally { setLoading(false); }
    };

    useEffect(() => { load(); }, [tenantSlug]);

    const toggleStatus = async (team) => {
        const newStatus = team.status === "ACTIVE" ? "INACTIVE" : "ACTIVE";
        try {
            await api.patch(`/tenants/${tenantSlug}/teams/${team.id}/status`, { status: newStatus });
            toast.success(`Equipe ${newStatus === "ACTIVE" ? "ativada" : "inativada"}.`);
            load();
        } catch (e) { toast.error(extractError(e, "Erro ao atualizar status")); }
    };

    const storeName = (storeId) =>
        (context?.stores || []).find((s) => s.id === storeId)?.name || storeId;

    return (
        <div>
            <PageHeader eyebrow="Gestão" title="Equipes" description="Organize vendedores em equipes por unidade.">
                {canCreate && (
                    <Button onClick={() => setCreateOpen(true)} data-testid="new-team-button" className="gap-2">
                        <Plus size={16} strokeWidth={1.5} /> Nova equipe
                    </Button>
                )}
            </PageHeader>

            {loading ? (
                <p className="text-sm text-muted-foreground">Carregando…</p>
            ) : teams.length === 0 ? (
                <EmptyState
                    title="Sem equipes cadastradas"
                    description="Crie uma equipe para organizar seus vendedores."
                    action={canCreate && <Button onClick={() => setCreateOpen(true)}>Nova equipe</Button>}
                />
            ) : (
                <Card className="border border-border shadow-sm">
                    <CardContent className="p-0">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Nome</TableHead>
                                    <TableHead>Unidade</TableHead>
                                    <TableHead>Membros</TableHead>
                                    <TableHead>Status</TableHead>
                                    <TableHead className="text-right">Ações</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {teams.map((team) => (
                                    <TableRow key={team.id} data-testid={`team-row-${team.id}`}>
                                        <TableCell>
                                            <div>
                                                <p className="font-medium">{team.name}</p>
                                                {team.description && (
                                                    <p className="text-xs text-muted-foreground mt-0.5 max-w-xs truncate">{team.description}</p>
                                                )}
                                            </div>
                                        </TableCell>
                                        <TableCell className="text-sm text-muted-foreground">
                                            {storeName(team.store_id)}
                                        </TableCell>
                                        <TableCell>
                                            <div className="flex items-center gap-1.5">
                                                <Users size={13} className="text-muted-foreground" />
                                                <span className="text-sm font-medium" data-testid={`team-member-count-${team.id}`}>
                                                    {team.member_count ?? 0}
                                                </span>
                                            </div>
                                        </TableCell>
                                        <TableCell>
                                            <Badge variant={team.status === "ACTIVE" ? "default" : "outline"}>
                                                {team.status === "ACTIVE" ? "Ativo" : "Inativo"}
                                            </Badge>
                                        </TableCell>
                                        <TableCell className="text-right">
                                            <div className="flex justify-end gap-1">
                                                {canEdit && (
                                                    <Button size="sm" variant="ghost"
                                                        onClick={() => setEditTarget(team)}
                                                        data-testid={`edit-team-${team.id}`}
                                                        title="Editar equipe e membros">
                                                        <Pencil size={15} />
                                                    </Button>
                                                )}
                                                <AlertDialog>
                                                    <AlertDialogTrigger asChild>
                                                        <Button size="sm" variant="ghost"
                                                            data-testid={`toggle-team-${team.id}`}
                                                            className={team.status === "ACTIVE"
                                                                ? "text-luppa-error hover:text-luppa-error"
                                                                : "text-luppa-green hover:text-luppa-green"}>
                                                            {team.status === "ACTIVE" ? "Inativar" : "Ativar"}
                                                        </Button>
                                                    </AlertDialogTrigger>
                                                    <AlertDialogContent>
                                                        <AlertDialogHeader>
                                                            <AlertDialogTitle>
                                                                {team.status === "ACTIVE" ? "Inativar" : "Ativar"} equipe?
                                                            </AlertDialogTitle>
                                                            <AlertDialogDescription>
                                                                {team.status === "ACTIVE"
                                                                    ? `A equipe "${team.name}" será inativada.`
                                                                    : `A equipe "${team.name}" será reativada.`}
                                                            </AlertDialogDescription>
                                                        </AlertDialogHeader>
                                                        <AlertDialogFooter>
                                                            <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                                            <AlertDialogAction
                                                                onClick={() => toggleStatus(team)}
                                                                data-testid={`confirm-toggle-team-${team.id}`}>
                                                                Confirmar
                                                            </AlertDialogAction>
                                                        </AlertDialogFooter>
                                                    </AlertDialogContent>
                                                </AlertDialog>
                                            </div>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>
            )}

            {/* Ranking de equipes */}
            <TeamRanking tenantSlug={tenantSlug} />

            {createOpen && (
                <CreateTeamDialog
                    tenantSlug={tenantSlug}
                    stores={context?.stores || []}
                    onClose={() => setCreateOpen(false)}
                    onCreated={() => { setCreateOpen(false); load(); }}
                />
            )}

            {editTarget && (
                <EditTeamDialog
                    tenantSlug={tenantSlug}
                    team={editTarget}
                    stores={context?.stores || []}
                    onClose={() => setEditTarget(null)}
                    onSaved={() => { setEditTarget(null); load(); }}
                />
            )}
        </div>
    );
}

// ── Diálogo Criar ────────────────────────────────────────────────────────────
function CreateTeamDialog({ tenantSlug, stores, onClose, onCreated }) {
    const [form, setForm] = useState({ name: "", description: "", store_id: stores[0]?.id || "" });
    const [saving, setSaving] = useState(false);
    const setF = (k, v) => setForm((p) => ({ ...p, [k]: v }));

    const submit = async (e) => {
        e.preventDefault();
        if (!form.store_id) { toast.error("Selecione uma unidade."); return; }
        setSaving(true);
        try {
            await api.post(`/tenants/${tenantSlug}/teams`, form);
            toast.success("Equipe criada.");
            onCreated();
        } catch (err) {
            toast.error(extractError(err, "Erro ao criar equipe"));
        } finally { setSaving(false); }
    };

    return (
        <Dialog open onOpenChange={onClose}>
            <DialogContent className="max-w-md">
                <DialogHeader>
                    <DialogTitle>Nova equipe</DialogTitle>
                    <DialogDescription>Crie uma equipe para organizar vendedores.</DialogDescription>
                </DialogHeader>
                <form onSubmit={submit} className="space-y-4">
                    <div className="space-y-2">
                        <Label>Nome</Label>
                        <Input value={form.name} onChange={(e) => setF("name", e.target.value)} required
                            data-testid="team-name-input" placeholder="Ex: Equipe Manhã" />
                    </div>
                    <div className="space-y-2">
                        <Label>Descrição <span className="text-muted-foreground text-xs">(opcional)</span></Label>
                        <Textarea value={form.description} onChange={(e) => setF("description", e.target.value)}
                            data-testid="team-description-input" placeholder="Descreva a equipe…" rows={2} />
                    </div>
                    {stores.length > 1 && (
                        <div className="space-y-2">
                            <Label>Unidade</Label>
                            <Select value={form.store_id} onValueChange={(v) => setF("store_id", v)}>
                                <SelectTrigger data-testid="team-store-select"><SelectValue placeholder="Selecione" /></SelectTrigger>
                                <SelectContent>
                                    {stores.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                                </SelectContent>
                            </Select>
                        </div>
                    )}
                    <DialogFooter>
                        <Button type="button" variant="outline" onClick={onClose}>Cancelar</Button>
                        <Button type="submit" disabled={saving} data-testid="create-team-submit">
                            {saving ? "Criando…" : "Criar equipe"}
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}

// ── Diálogo Editar ───────────────────────────────────────────────────────────
function EditTeamDialog({ tenantSlug, team, stores, onClose, onSaved }) {
    const [form, setForm] = useState({ name: team.name || "", description: team.description || "" });
    const [sellers, setSellers] = useState([]);
    const [selectedIds, setSelectedIds] = useState(new Set());
    const [loadingMembers, setLoadingMembers] = useState(true);
    const [saving, setSaving] = useState(false);
    const setF = (k, v) => setForm((p) => ({ ...p, [k]: v }));

    useEffect(() => {
        (async () => {
            setLoadingMembers(true);
            try {
                const [{ data: allSellers }, { data: members }] = await Promise.all([
                    api.get(`/tenants/${tenantSlug}/sellers`),
                    api.get(`/tenants/${tenantSlug}/teams/${team.id}/members`),
                ]);
                setSellers(allSellers.filter((s) => s.store_id === team.store_id));
                setSelectedIds(new Set(members.map((m) => m.id)));
            } catch (e) {
                toast.error(extractError(e, "Erro ao carregar membros"));
            } finally { setLoadingMembers(false); }
        })();
    }, [team.id]);

    const toggleMember = (sellerId, checked) => {
        setSelectedIds((prev) => {
            const next = new Set(prev);
            checked ? next.add(sellerId) : next.delete(sellerId);
            return next;
        });
    };

    const submit = async (e) => {
        e.preventDefault();
        setSaving(true);
        try {
            await api.put(`/tenants/${tenantSlug}/teams/${team.id}`, {
                name: form.name,
                description: form.description,
            });
            await api.put(`/tenants/${tenantSlug}/teams/${team.id}/members`, {
                seller_profile_ids: [...selectedIds],
            });
            toast.success("Equipe atualizada.");
            onSaved();
        } catch (err) {
            toast.error(extractError(err, "Erro ao salvar equipe"));
        } finally { setSaving(false); }
    };

    const storeName = stores.find((s) => s.id === team.store_id)?.name || team.store_id;

    return (
        <Dialog open onOpenChange={onClose}>
            <DialogContent className="max-w-lg">
                <DialogHeader>
                    <DialogTitle>Editar equipe</DialogTitle>
                    <DialogDescription>Unidade: <strong>{storeName}</strong></DialogDescription>
                </DialogHeader>
                <form onSubmit={submit} className="space-y-5">
                    <div className="space-y-4">
                        <div className="space-y-2">
                            <Label>Nome da equipe</Label>
                            <Input value={form.name} onChange={(e) => setF("name", e.target.value)} required
                                data-testid="edit-team-name" />
                        </div>
                        <div className="space-y-2">
                            <Label>Descrição <span className="text-muted-foreground text-xs">(opcional)</span></Label>
                            <Textarea value={form.description} onChange={(e) => setF("description", e.target.value)}
                                data-testid="edit-team-description" rows={2} />
                        </div>
                    </div>

                    <div className="space-y-3">
                        <div className="flex items-center justify-between">
                            <Label className="text-sm font-semibold">
                                Participantes
                                <span className="ml-2 text-xs font-normal text-muted-foreground">
                                    ({selectedIds.size} selecionado{selectedIds.size !== 1 ? "s" : ""})
                                </span>
                            </Label>
                        </div>
                        {loadingMembers ? (
                            <p className="text-sm text-muted-foreground">Carregando vendedores…</p>
                        ) : sellers.length === 0 ? (
                            <p className="text-sm text-muted-foreground border rounded-md px-3 py-4 text-center bg-muted/30">
                                Nenhum vendedor cadastrado nesta unidade.
                            </p>
                        ) : (
                            <div className="border rounded-md divide-y max-h-64 overflow-y-auto" data-testid="team-members-list">
                                {sellers.map((seller) => {
                                    const checked = selectedIds.has(seller.id);
                                    const name = seller.user?.name || seller.user_id;
                                    const email = seller.user?.email || "";
                                    const avatar = seller.user?.avatar_url || null;
                                    return (
                                        <label
                                            key={seller.id}
                                            className={`flex items-center gap-3 px-4 py-2.5 cursor-pointer hover:bg-muted/30 transition-colors ${checked ? "bg-primary/5" : ""}`}
                                            data-testid={`team-member-checkbox-${seller.id}`}
                                        >
                                            <Checkbox
                                                checked={checked}
                                                onCheckedChange={(v) => toggleMember(seller.id, !!v)}
                                            />
                                            <UserAvatar src={avatar} name={name} size={7} />
                                            <div className="min-w-0">
                                                <p className="text-sm font-medium leading-none">{name}</p>
                                                <p className="text-xs text-muted-foreground mt-0.5 truncate">{email}</p>
                                            </div>
                                        </label>
                                    );
                                })}
                            </div>
                        )}
                    </div>

                    <DialogFooter>
                        <Button type="button" variant="outline" onClick={onClose}>Cancelar</Button>
                        <Button type="submit" disabled={saving} data-testid="save-team-submit">
                            {saving ? "Salvando…" : "Salvar alterações"}
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}
