import React, { useEffect, useState, useCallback } from "react";
import { useParams } from "react-router-dom";
import { CheckCircle, XCircle, Clock, Plus } from "lucide-react";
import api from "@/lib/api";
import { PageHeader } from "@/components/Common";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { usePermissions } from "@/hooks/usePermissions";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";

const PURPOSE_PT = { ACCOUNT_ACCESS: "Acesso à conta", SALES_ATTENDANCE: "Atendimento de vendas", CUSTOMER_CONTACT: "Contato com cliente", MARKETING: "Marketing", NOTIFICATIONS: "Notificações", ANALYTICS: "Análises", SUPPORT: "Suporte", LEGAL_OBLIGATION: "Obrigação Legal", SECURITY: "Segurança" };
const BASIS_PT = { CONSENT: "Consentimento", CONTRACT: "Contrato", LEGAL_OBLIGATION: "Obrig. Legal", LEGITIMATE_INTEREST: "Interesse Legítimo", REGULAR_EXERCISE_OF_RIGHTS: "Exercício de Direitos", PROTECTION_OF_CREDIT: "Prot. de Crédito" };
const STATUS_COLORS = { GRANTED: "bg-luppa-green/15 text-luppa-green", WITHDRAWN: "bg-luppa-error/15 text-luppa-error", EXPIRED: "bg-gray-100 text-gray-600" };
const STATUS_PT = { GRANTED: "Concedido", WITHDRAWN: "Retirado", EXPIRED: "Expirado" };

export default function ConsentsPage() {
    const { tenantSlug } = useParams();
    const { hasFeature, hasPermission } = usePermissions();
    const [consents, setConsents] = useState([]);
    const [events, setEvents] = useState([]);
    const [loading, setLoading] = useState(true);
    const [showNew, setShowNew] = useState(false);
    const [newForm, setNewForm] = useState({ purpose: "ACCOUNT_ACCESS", legal_basis: "CONSENT", version: "1.0", subject_user_id: "" });

    const canManage = hasPermission("privacy.consents.manage");
    const featureActive = hasFeature("lgpd");

    const load = useCallback(async () => {
        setLoading(true);
        try {
            const [cRes, eRes] = await Promise.allSettled([
                api.get(`/tenants/${tenantSlug}/privacy/consents`),
                api.get(`/tenants/${tenantSlug}/privacy/consent-events`),
            ]);
            if (cRes.status === "fulfilled") setConsents(cRes.value.data || []);
            if (eRes.status === "fulfilled") setEvents(eRes.value.data || []);
        } catch {
            toast.error("Erro ao carregar consentimentos.");
        } finally {
            setLoading(false);
        }
    }, [tenantSlug]);

    useEffect(() => { load(); }, [load]);

    const handleWithdraw = async (id) => {
        try {
            await api.post(`/tenants/${tenantSlug}/privacy/consents/${id}/withdraw`);
            toast.success("Consentimento retirado.");
            load();
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Erro.");
        }
    };

    const handleCreate = async () => {
        try {
            await api.post(`/tenants/${tenantSlug}/privacy/consents`, { ...newForm, subject_type: "USER" });
            toast.success("Consentimento registrado!");
            setShowNew(false);
            load();
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Erro ao criar consentimento.");
        }
    };

    if (!featureActive) return (
        <div><PageHeader eyebrow="Privacidade" title="Consentimentos" />
            <Card className="mt-6 border"><CardContent className="p-10 text-center"><p className="text-sm text-muted-foreground">Módulo LGPD indisponível.</p></CardContent></Card>
        </div>
    );

    return (
        <div data-testid="consents-page">
            <div className="flex items-start justify-between mb-6">
                <PageHeader eyebrow="Privacidade" title="Consentimentos" description="Registro de bases legais e histórico de consentimentos." />
                {canManage && (
                    <Button size="sm" onClick={() => setShowNew(true)} data-testid="new-consent-btn" className="mt-1">
                        <Plus size={14} className="mr-2" />Registrar
                    </Button>
                )}
            </div>

            <div className="grid lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                    <Card className="border border-border shadow-sm">
                        <CardContent className="p-0">
                            {loading ? (
                                <div className="p-5 space-y-3"><Skeleton className="h-14" /><Skeleton className="h-14" /></div>
                            ) : consents.length === 0 ? (
                                <div className="p-10 text-center"><p className="text-sm text-muted-foreground">Nenhum consentimento registrado.</p></div>
                            ) : consents.map(c => (
                                <div key={c.id} data-testid={`consent-${c.id}`} className="flex items-center justify-between py-3 px-4 border-b border-border last:border-0">
                                    <div>
                                        <div className="flex items-center gap-2 mb-0.5">
                                            <p className="text-sm font-medium">{PURPOSE_PT[c.purpose] || c.purpose}</p>
                                            <span className={`text-xs px-2 py-0.5 rounded-full ${STATUS_COLORS[c.status] || "bg-gray-100 text-gray-600"}`}>{STATUS_PT[c.status] || c.status}</span>
                                        </div>
                                        <p className="text-xs text-muted-foreground">Base: {BASIS_PT[c.legal_basis] || c.legal_basis} · v{c.version} · {c.collected_at?.slice(0, 10)}</p>
                                    </div>
                                    {canManage && c.status === "GRANTED" && (
                                        <button onClick={() => handleWithdraw(c.id)} data-testid={`withdraw-consent-${c.id}`}
                                            className="text-xs text-luppa-error hover:text-luppa-error transition-colors ml-2 flex-shrink-0">
                                            Retirar
                                        </button>
                                    )}
                                </div>
                            ))}
                        </CardContent>
                    </Card>
                </div>

                <div className="space-y-4">
                    <Card className="border border-border shadow-sm">
                        <CardContent className="p-4">
                            <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground mb-3">Histórico</p>
                            {events.slice(0, 8).map(ev => (
                                <div key={ev.id} className="flex items-start gap-2 py-1.5 border-b border-border last:border-0">
                                    {ev.event_type === "CONSENT_GRANTED" ? <CheckCircle size={12} className="text-luppa-green mt-0.5 flex-shrink-0" /> : <XCircle size={12} className="text-luppa-error mt-0.5 flex-shrink-0" />}
                                    <div>
                                        <p className="text-xs">{ev.event_type === "CONSENT_GRANTED" ? "Concedido" : "Retirado"}</p>
                                        <p className="text-xs text-muted-foreground">{ev.created_at?.slice(0, 10)}</p>
                                    </div>
                                </div>
                            ))}
                            {events.length === 0 && <p className="text-xs text-muted-foreground text-center py-2">Sem histórico.</p>}
                        </CardContent>
                    </Card>
                </div>
            </div>

            <Dialog open={showNew} onOpenChange={setShowNew}>
                <DialogContent>
                    <DialogHeader><DialogTitle>Registrar Consentimento</DialogTitle></DialogHeader>
                    <div className="space-y-3 py-2">
                        <div>
                            <label className="text-xs text-muted-foreground">Finalidade</label>
                            <select className="w-full border border-border rounded-sm px-3 py-2 text-sm mt-1 bg-background" value={newForm.purpose} onChange={e => setNewForm(f => ({ ...f, purpose: e.target.value }))}>
                                {Object.entries(PURPOSE_PT).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                            </select>
                        </div>
                        <div>
                            <label className="text-xs text-muted-foreground">Base Legal</label>
                            <select className="w-full border border-border rounded-sm px-3 py-2 text-sm mt-1 bg-background" value={newForm.legal_basis} onChange={e => setNewForm(f => ({ ...f, legal_basis: e.target.value }))}>
                                {Object.entries(BASIS_PT).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                            </select>
                        </div>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setShowNew(false)}>Cancelar</Button>
                        <Button onClick={handleCreate}>Registrar</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}
