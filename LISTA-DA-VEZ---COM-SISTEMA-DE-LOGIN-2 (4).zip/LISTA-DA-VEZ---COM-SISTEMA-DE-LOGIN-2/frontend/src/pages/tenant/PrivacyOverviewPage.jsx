import React, { useEffect, useState, useCallback } from "react";
import { useParams, Link } from "react-router-dom";
import { Shield, AlertCircle, FileText, CheckCircle, Clock, Database, Lock, Archive } from "lucide-react";
import api from "@/lib/api";
import { PageHeader } from "@/components/Common";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { usePermissions } from "@/hooks/usePermissions";

const STATUS_COLORS = {
    OPEN: "bg-luppa-warning/15 text-luppa-warning",
    IN_REVIEW: "bg-luppa-purple/15 text-luppa-purple",
    PROCESSING: "bg-luppa-purple/15 text-luppa-purple",
    RESOLVED: "bg-luppa-green/15 text-luppa-green",
    REJECTED: "bg-luppa-error/15 text-luppa-error",
    CANCELLED: "bg-gray-100 text-gray-700",
};

const STATUS_PT = {
    OPEN: "Aberta", IN_REVIEW: "Em revisão", PROCESSING: "Processando",
    RESOLVED: "Resolvida", REJECTED: "Rejeitada", CANCELLED: "Cancelada",
};

function KPICard({ icon: Icon, label, value, sub, color = "text-foreground" }) {
    return (
        <Card className="border border-border shadow-sm">
            <CardContent className="p-5">
                <div className="flex items-center justify-between mb-3">
                    <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground">{label}</p>
                    <Icon size={15} strokeWidth={1.5} className="text-muted-foreground" />
                </div>
                <p className={`text-3xl font-light tabular-nums ${color}`}>{value}</p>
                {sub && <p className="text-xs text-muted-foreground mt-1">{sub}</p>}
            </CardContent>
        </Card>
    );
}

export default function PrivacyOverviewPage() {
    const { tenantSlug } = useParams();
    const { hasFeature } = usePermissions();
    const [stats, setStats] = useState(null);
    const [recentRequests, setRecentRequests] = useState([]);
    const [holds, setHolds] = useState([]);
    const [loading, setLoading] = useState(true);

    const load = useCallback(async () => {
        setLoading(true);
        try {
            const [statsRes, reqRes, holdsRes] = await Promise.allSettled([
                api.get(`/tenants/${tenantSlug}/privacy/requests/stats`),
                api.get(`/tenants/${tenantSlug}/privacy/requests?limit=5`),
                api.get(`/tenants/${tenantSlug}/legal-holds`),
            ]);
            if (statsRes.status === "fulfilled") setStats(statsRes.value.data);
            if (reqRes.status === "fulfilled") setRecentRequests(reqRes.value.data.slice(0, 5));
            if (holdsRes.status === "fulfilled") setHolds(holdsRes.value.data);
        } finally {
            setLoading(false);
        }
    }, [tenantSlug]);

    useEffect(() => { load(); }, [load]);

    const featureLGPD = hasFeature("lgpd");

    return (
        <div data-testid="privacy-overview-page">
            <PageHeader
                eyebrow="Privacidade"
                title="Privacidade & LGPD"
                description="Gerencie solicitações de titulares, consentimentos e conformidade com a LGPD."
            />
            {!featureLGPD ? (
                <Card className="mt-6 border border-border shadow-sm">
                    <CardContent className="p-10 text-center">
                        <Shield size={32} strokeWidth={1} className="mx-auto mb-3 text-muted-foreground" />
                        <p className="text-sm text-muted-foreground">Módulo LGPD não disponível no plano atual.</p>
                    </CardContent>
                </Card>
            ) : loading ? (
                <div className="space-y-4 mt-6">
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4"><Skeleton className="h-28" /><Skeleton className="h-28" /><Skeleton className="h-28" /><Skeleton className="h-28" /></div>
                </div>
            ) : (
                <div className="space-y-6 mt-6">
                    {/* KPIs */}
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                        <KPICard icon={FileText} label="Total de solicitações" value={stats?.total ?? 0} />
                        <KPICard icon={AlertCircle} label="Abertas" value={stats?.open ?? 0} color={stats?.open > 0 ? "text-luppa-warning" : ""} />
                        <KPICard icon={Clock} label="Em revisão" value={stats?.in_review ?? 0} />
                        <KPICard icon={CheckCircle} label="Resolvidas" value={stats?.resolved ?? 0} color="text-luppa-green" />
                    </div>

                    {/* Atalhos */}
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                        {[
                            { to: `/${tenantSlug}/privacy/requests`, icon: FileText, label: "Solicitações LGPD", desc: "Gerenciar pedidos de titulares" },
                            { to: `/${tenantSlug}/privacy/consents`, icon: CheckCircle, label: "Consentimentos", desc: "Registro de bases legais" },
                            { to: `/${tenantSlug}/privacy/data-map`, icon: Database, label: "Mapa de Dados", desc: "Categorias e finalidades" },
                            { to: `/${tenantSlug}/settings/data-protection`, icon: Shield, label: "Configurações", desc: "DPO e preferências de privacidade" },
                        ].map(item => (
                            <Link key={item.to} to={item.to}>
                                <Card className="border border-border shadow-sm hover:border-foreground/30 transition-colors cursor-pointer h-full">
                                    <CardContent className="p-4">
                                        <item.icon size={18} strokeWidth={1.5} className="mb-3 text-muted-foreground" />
                                        <p className="text-sm font-medium mb-1">{item.label}</p>
                                        <p className="text-xs text-muted-foreground">{item.desc}</p>
                                    </CardContent>
                                </Card>
                            </Link>
                        ))}
                    </div>

                    {/* Solicitações recentes */}
                    <Card className="border border-border shadow-sm">
                        <CardContent className="p-5">
                            <div className="flex items-center justify-between mb-4">
                                <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground">Solicitações Recentes</p>
                                <Link to={`/${tenantSlug}/privacy/requests`} className="text-xs text-muted-foreground hover:text-foreground transition-colors">ver todas →</Link>
                            </div>
                            {recentRequests.length === 0 ? (
                                <p className="text-sm text-muted-foreground text-center py-4">Nenhuma solicitação registrada.</p>
                            ) : (
                                <div className="space-y-2">
                                    {recentRequests.map(req => (
                                        <div key={req.id} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                                            <div>
                                                <p className="text-sm font-medium">{req.request_type} — {req.data_subject_name || "—"}</p>
                                                <p className="text-xs text-muted-foreground">{req.description?.slice(0, 60)}{req.description?.length > 60 ? "..." : ""}</p>
                                            </div>
                                            <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${STATUS_COLORS[req.status] || "bg-gray-100 text-gray-700"}`}>
                                                {STATUS_PT[req.status] || req.status}
                                            </span>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </CardContent>
                    </Card>

                    {/* Legal Holds ativos */}
                    {holds.filter(h => h.status === "ACTIVE").length > 0 && (
                        <Card className="border border-amber-200 bg-amber-50 shadow-sm">
                            <CardContent className="p-5">
                                <div className="flex items-center gap-2 mb-3">
                                    <Lock size={14} strokeWidth={1.5} className="text-amber-600" />
                                    <p className="text-xs uppercase tracking-[0.1em] text-amber-700">Legal Holds Ativos</p>
                                </div>
                                {holds.filter(h => h.status === "ACTIVE").map(hold => (
                                    <div key={hold.id} className="flex justify-between items-center py-2 border-b border-amber-200 last:border-0">
                                        <div>
                                            <p className="text-sm font-medium text-amber-900">{hold.name}</p>
                                            <p className="text-xs text-amber-700">{hold.data_category} — {hold.reason?.slice(0, 60)}</p>
                                        </div>
                                        <span className="text-xs bg-amber-200 text-amber-800 px-2 py-0.5 rounded-full">ATIVO</span>
                                    </div>
                                ))}
                            </CardContent>
                        </Card>
                    )}
                </div>
            )}
        </div>
    );
}
