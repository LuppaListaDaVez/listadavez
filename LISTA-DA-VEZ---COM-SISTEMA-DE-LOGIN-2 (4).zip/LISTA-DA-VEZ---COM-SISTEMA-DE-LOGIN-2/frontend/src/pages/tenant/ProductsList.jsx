import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import api, { extractError } from "@/lib/api";
import { centsToBRL, brlToCents, centsToInput } from "@/lib/money";
import { usePermissions } from "@/hooks/usePermissions";
import { PageHeader, EmptyState } from "@/components/Common";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Pencil } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

const EMPTY = { sku: "", name: "", description: "", category: "", price: "" };

export default function ProductsList() {
    const { tenantSlug } = useParams();
    const { hasPermission } = usePermissions();
    const canCreate = hasPermission("products.create");
    const canEdit = hasPermission("products.update");
    const canToggle = hasPermission("products.status_change");
    const [items, setItems] = useState([]);
    const [open, setOpen] = useState(false);
    const [editing, setEditing] = useState(null);
    const [form, setForm] = useState(EMPTY);
    const [saving, setSaving] = useState(false);

    const load = async () => {
        try { const { data } = await api.get(`/tenants/${tenantSlug}/products`); setItems(data); }
        catch (e) { toast.error(extractError(e, "Erro ao carregar produtos")); }
    };
    useEffect(() => { load(); /* eslint-disable-next-line */ }, [tenantSlug]);

    const openNew = () => { setEditing(null); setForm(EMPTY); setOpen(true); };
    const openEdit = (p) => {
        setEditing(p);
        setForm({ sku: p.sku || "", name: p.name, description: p.description || "", category: p.category || "", price: centsToInput(p.price_cents) });
        setOpen(true);
    };

    const submit = async (e) => {
        e.preventDefault();
        if (saving) return;
        const price_cents = brlToCents(form.price);
        if (!price_cents || price_cents <= 0) { toast.error("Informe um preço válido."); return; }
        setSaving(true);
        try {
            const payload = { sku: form.sku || null, name: form.name, description: form.description || null, category: form.category || null, price_cents };
            if (editing) await api.put(`/tenants/${tenantSlug}/products/${editing.id}`, payload);
            else await api.post(`/tenants/${tenantSlug}/products`, payload);
            toast.success(editing ? "Produto atualizado." : "Produto criado.");
            setOpen(false); setForm(EMPTY); setEditing(null); load();
        } catch (err) { toast.error(extractError(err, "Erro ao salvar produto")); }
        finally { setSaving(false); }
    };

    const toggle = async (p) => {
        try { await api.patch(`/tenants/${tenantSlug}/products/${p.id}/status`, { active: !p.active }); load(); }
        catch (e) { toast.error(extractError(e, "Erro")); }
    };

    return (
        <div data-testid="products-page">
            <PageHeader eyebrow="Comercial" title="Produtos" description="Catálogo de produtos para o registro de vendas.">
                {canCreate && (
                    <Button className="gap-2" onClick={openNew} data-testid="new-product-button"><Plus size={16} /> Novo produto</Button>
                )}
            </PageHeader>

            {items.length === 0 ? (
                <EmptyState title="Sem produtos" description="Cadastre produtos para usá-los nas vendas detalhadas." />
            ) : (
                <Card className="border border-border shadow-sm"><CardContent className="p-0">
                    <Table>
                        <TableHeader><TableRow>
                            <TableHead>SKU</TableHead>
                            <TableHead>Nome</TableHead>
                            <TableHead>Categoria</TableHead>
                            <TableHead>Preço</TableHead>
                            <TableHead>Status</TableHead>
                            {(canEdit || canToggle) && <TableHead className="text-right">Ações</TableHead>}
                        </TableRow></TableHeader>
                        <TableBody>
                            {items.map((p) => (
                                <TableRow key={p.id} data-testid={`product-row-${p.sku || p.id}`}>
                                    <TableCell className="font-mono text-xs">{p.sku || "—"}</TableCell>
                                    <TableCell className="font-medium">
                                        <span>{p.name}</span>
                                        {p.description && (
                                            <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1" data-testid={`product-description-${p.sku || p.id}`}>{p.description}</p>
                                        )}
                                    </TableCell>
                                    <TableCell className="text-sm text-muted-foreground">{p.category || "—"}</TableCell>
                                    <TableCell className="font-mono text-sm" data-testid={`product-price-${p.sku || p.id}`}>{centsToBRL(p.price_cents)}</TableCell>
                                    <TableCell><Badge variant={p.active ? "default" : "outline"}>{p.active ? "ATIVO" : "INATIVO"}</Badge></TableCell>
                                    {(canEdit || canToggle) && (
                                        <TableCell className="text-right space-x-2">
                                            {canEdit && (
                                                <Button size="sm" variant="ghost" onClick={() => openEdit(p)} data-testid={`product-edit-${p.sku || p.id}`}><Pencil size={14} /></Button>
                                            )}
                                            {canToggle && (
                                                <Button size="sm" variant="outline" onClick={() => toggle(p)} data-testid={`product-toggle-${p.sku || p.id}`}>{p.active ? "Inativar" : "Ativar"}</Button>
                                            )}
                                        </TableCell>
                                    )}
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </CardContent></Card>
            )}

            <Dialog open={open} onOpenChange={setOpen}>
                <DialogContent>
                    <DialogHeader><DialogTitle>{editing ? "Editar produto" : "Novo produto"}</DialogTitle>
                        <DialogDescription>Defina nome, categoria e preço (em reais) do produto.</DialogDescription>
                    </DialogHeader>
                    <form onSubmit={submit} className="space-y-4">
                        <div className="space-y-2"><Label>SKU</Label><Input value={form.sku} onChange={(e) => setForm({ ...form, sku: e.target.value })} placeholder="TENIS-001" data-testid="product-sku-input" /></div>
                        <div className="space-y-2"><Label>Nome</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required data-testid="product-name-input" /></div>
                        <div className="space-y-2">
                            <Label>Descrição</Label>
                            <Textarea
                                value={form.description}
                                onChange={(e) => setForm({ ...form, description: e.target.value })}
                                placeholder="Descreva o produto (opcional)"
                                rows={3}
                                data-testid="product-description-input"
                            />
                        </div>
                        <div className="space-y-2"><Label>Categoria</Label><Input value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} data-testid="product-category-input" /></div>
                        <div className="space-y-2"><Label>Preço (R$)</Label><Input type="text" inputMode="decimal" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} placeholder="199,90" required data-testid="product-price-input" /></div>
                        <DialogFooter><Button type="submit" disabled={saving} data-testid="product-submit">{saving ? "Salvando…" : (editing ? "Salvar" : "Criar")}</Button></DialogFooter>
                    </form>
                </DialogContent>
            </Dialog>
        </div>
    );
}
