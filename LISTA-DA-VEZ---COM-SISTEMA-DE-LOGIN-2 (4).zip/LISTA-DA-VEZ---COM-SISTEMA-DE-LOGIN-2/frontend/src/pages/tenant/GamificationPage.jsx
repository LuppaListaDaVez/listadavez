import React, { useEffect, useState, useCallback } from "react";
import { useParams } from "react-router-dom";
import api, { extractError } from "@/lib/api";
import { usePermissions } from "@/hooks/usePermissions";
import { useRealtimeTenant } from "@/context/RealtimeTenantContext";
import { useAuth } from "@/context/AuthContext";
import { PageHeader } from "@/components/Common";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
    Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
    Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
    Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
    AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
    AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
    Trophy, Plus, Pencil, Star, Users, TrendingUp, Award, CheckCircle,
    Clock, XCircle, Zap, Target, Medal,
} from "lucide-react";
import { toast } from "sonner";

// ─── Constants ───────────────────────────────────────────────────────────────
const CATEGORIES = ["VENDAS", "PERFORMANCE", "EQUIPE", "OPERACIONAL", "ESPECIAL", "OUTRO"];
const DIFFICULTIES = [
    { value: "EASY",      label: "Fácil",     color: "text-luppa-green" },
    { value: "MEDIUM",    label: "Médio",     color: "text-amber-600"   },
    { value: "HARD",      label: "Difícil",   color: "text-luppa-error"    },
    { value: "LEGENDARY", label: "Lendário",  color: "text-luppa-purple"  },
];
const RECURRENCES = [
    { value: "ONCE",    label: "Uma vez"       },
    { value: "DAILY",   label: "Diária"        },
    { value: "WEEKLY",  label: "Semanal"       },
    { value: "MONTHLY", label: "Mensal"        },
    { value: "ALWAYS",  label: "Sempre"        },
];
const PERIOD_TYPES = [
    { value: "__none__", label: "Sem período (geral)" },
    { value: "DAILY",    label: "Hoje"                },
    { value: "WEEKLY",   label: "Esta semana"         },
    { value: "MONTHLY",  label: "Este mês"            },
    { value: "CUSTOM",   label: "Período personalizado" },
];
const APPROVALS = [
    { value: "AUTOMATIC",         label: "Automático" },
    { value: "MANUAL",            label: "Manual (admin concede)" },
    { value: "REQUIRES_APPROVAL", label: "Requer aprovação" },
];
const METRIC_LABELS = {
    REVENUE: "Receita total",
    SALES_COUNT: "Quantidade de vendas",
    ATTENDANCE_COUNT: "Atendimentos",
    CONVERSION: "Conversão (%)",
    AVERAGE_TICKET: "Ticket médio",
    ITEMS_SOLD: "Produtos vendidos",
};
const OPERATOR_LABELS = {
    GTE: "≥ maior ou igual",
    GT: "> maior que",
    EQ: "= igual a",
    LTE: "≤ menor ou igual",
    LT: "< menor que",
};
const STATUS_VARIANTS = {
    DRAFT:    { label: "Rascunho", variant: "outline"   },
    ACTIVE:   { label: "Ativo",    variant: "default"   },
    PAUSED:   { label: "Pausado",  variant: "secondary" },
    ARCHIVED: { label: "Arquivado",variant: "outline"   },
};

const ICONS = [
    { value: "trophy", icon: <Trophy size={16} /> },
    { value: "star",   icon: <Star   size={16} /> },
    { value: "award",  icon: <Award  size={16} /> },
    { value: "zap",    icon: <Zap    size={16} /> },
    { value: "target", icon: <Target size={16} /> },
    { value: "medal",  icon: <Medal  size={16} /> },
];

// Métricas monetárias — valores armazenados em centavos
const MONEY_METRICS = new Set(["REVENUE", "AVERAGE_TICKET"]);

/** Converte centavos → R$ string para exibição no form */
function centsToFormBRL(cents) {
    if (!cents && cents !== 0) return "";
    return (cents / 100).toFixed(2).replace(".", ",");
}

/** Converte entrada BRL do form → centavos para salvar */
function formBRLToCents(raw) {
    if (!raw && raw !== 0) return 0;
    const str = String(raw).replace(/\./g, "").replace(",", ".");
    const n = parseFloat(str);
    return isNaN(n) ? 0 : Math.round(n * 100);
}

/** Formata centavos como string de progresso para MONEY_METRICS */
function fmtProgress(value, metric) {
    if (MONEY_METRICS.has(metric)) return fmtCurrency(value);
    return String(value);
}

function IconComp({ name, size = 16 }) {
    const map = { trophy: Trophy, star: Star, award: Award, zap: Zap, target: Target, medal: Medal };
    const C = map[name] || Award;
    return <C size={size} />;
}
function fmtPoints(n) { return `${n} pts`; }
function fmtCurrency(c) {
    return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format((c || 0) / 100);
}

// ─── UserAvatar ───────────────────────────────────────────────────────────────
function UserAvatar({ src, name, size = 8 }) {
    const initials = (name || "?").split(" ").slice(0, 2).map((n) => n[0]).join("").toUpperCase();
    if (src)
        return <img src={src} alt={name} className={`w-${size} h-${size} rounded-full object-cover border border-border`} />;
    return (
        <div className={`w-${size} h-${size} rounded-full bg-primary/10 text-primary flex items-center justify-center text-xs font-semibold border border-border`}>
            {initials}
        </div>
    );
}

// ─── Painel ───────────────────────────────────────────────────────────────────
function DashboardPanel({ tenantSlug }) {
    const [stats, setStats] = useState(null);
    const [topAwards, setTopAwards] = useState([]);
    const [pendingCount, setPendingCount] = useState(0);

    useEffect(() => {
        (async () => {
            const [{ data: achs }, { data: awards }, { data: reqs }] = await Promise.all([
                api.get(`/tenants/${tenantSlug}/achievements`),
                api.get(`/tenants/${tenantSlug}/achievement-awards?limit=200`),
                api.get(`/tenants/${tenantSlug}/achievement-requests?status=PENDING`).catch(() => ({ data: [] })),
            ]);
            const active = achs.filter((a) => a.status === "ACTIVE").length;
            setStats({ total: achs.length, active, awarded: awards.length });
            setPendingCount(Array.isArray(reqs) ? reqs.length : 0);
            // Top achievements by award count
            const byAch = {};
            awards.forEach((a) => {
                byAch[a.achievement_id] = byAch[a.achievement_id] || { name: a.achievement_name, icon: a.icon, count: 0 };
                byAch[a.achievement_id].count++;
            });
            setTopAwards(Object.values(byAch).sort((a, b) => b.count - a.count).slice(0, 5));
        })().catch(() => {});
    }, [tenantSlug]);

    return (
        <div className="space-y-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                    { label: "Total Conquistas", value: stats?.total ?? "–", icon: <Trophy size={18} className="text-amber-500" /> },
                    { label: "Ativas",            value: stats?.active ?? "–", icon: <CheckCircle size={18} className="text-luppa-green" /> },
                    { label: "Concedidas",        value: stats?.awarded ?? "–", icon: <Award size={18} className="text-luppa-purple" /> },
                    { label: "Pendentes",         value: pendingCount,          icon: <Clock size={18} className="text-luppa-warning" /> },
                ].map((card) => (
                    <Card key={card.label} className="border border-border shadow-sm">
                        <CardContent className="p-4 flex items-center gap-3">
                            {card.icon}
                            <div>
                                <p className="text-xs text-muted-foreground">{card.label}</p>
                                <p className="text-2xl font-bold">{card.value}</p>
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>
            {topAwards.length > 0 && (
                <Card className="border border-border shadow-sm">
                    <CardHeader className="px-6 py-4 border-b border-border">
                        <CardTitle className="text-sm font-semibold">Conquistas mais alcançadas</CardTitle>
                    </CardHeader>
                    <CardContent className="p-0">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Conquista</TableHead>
                                    <TableHead className="text-right">Vezes concedida</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {topAwards.map((a, i) => (
                                    <TableRow key={i}>
                                        <TableCell>
                                            <div className="flex items-center gap-2">
                                                <IconComp name={a.icon} size={15} />
                                                <span className="text-sm font-medium">{a.name}</span>
                                            </div>
                                        </TableCell>
                                        <TableCell className="text-right font-semibold">{a.count}</TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}

// ─── Lista de Conquistas (CRUD) ───────────────────────────────────────────────
function AchievementsTab({ tenantSlug }) {
    const [achievements, setAchievements] = useState([]);
    const [loading, setLoading] = useState(true);
    const [formTarget, setFormTarget] = useState(null); // null=closed, {}=create, {...}=edit
    const [grantTarget, setGrantTarget] = useState(null);
    const [sellers, setSellers] = useState([]);

    const load = useCallback(async () => {
        setLoading(true);
        try {
            const { data } = await api.get(`/tenants/${tenantSlug}/achievements`);
            setAchievements(data);
        } catch (e) { toast.error(extractError(e, "Erro ao carregar conquistas")); }
        finally { setLoading(false); }
    }, [tenantSlug]);

    useEffect(() => { load(); }, [load]);

    useEffect(() => {
        api.get(`/tenants/${tenantSlug}/sellers`)
            .then(({ data }) => setSellers(data))
            .catch(() => {});
    }, [tenantSlug]);

    const changeStatus = async (id, status) => {
        try {
            await api.patch(`/tenants/${tenantSlug}/achievements/${id}/status`, { status });
            toast.success(`Conquista ${STATUS_VARIANTS[status]?.label || status}.`);
            load();
        } catch (e) { toast.error(extractError(e, "Erro")); }
    };

    return (
        <div className="space-y-4">
            <div className="flex justify-end">
                <Button onClick={() => setFormTarget({})} className="gap-2" data-testid="new-achievement-btn">
                    <Plus size={16} /> Nova conquista
                </Button>
            </div>
            {loading ? (
                <p className="text-sm text-muted-foreground">Carregando…</p>
            ) : achievements.length === 0 ? (
                <div className="flex flex-col items-center py-16 text-muted-foreground gap-3">
                    <Trophy size={32} strokeWidth={1.2} />
                    <p className="text-sm">Nenhuma conquista cadastrada. Crie a primeira agora!</p>
                </div>
            ) : (
                <Card className="border border-border shadow-sm">
                    <CardContent className="p-0">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Conquista</TableHead>
                                    <TableHead>Categoria</TableHead>
                                    <TableHead>Regra</TableHead>
                                    <TableHead>Pontos</TableHead>
                                    <TableHead>Status</TableHead>
                                    <TableHead className="text-right">Ações</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {achievements.map((a) => {
                                    const st = STATUS_VARIANTS[a.status] || { label: a.status, variant: "outline" };
                                    const diff = DIFFICULTIES.find((d) => d.value === a.difficulty);
                                    return (
                                        <TableRow key={a.id} data-testid={`achievement-row-${a.id}`}>
                                            <TableCell>
                                                <div className="flex items-center gap-2">
                                                    <span className="text-primary"><IconComp name={a.icon} size={16} /></span>
                                                    <div>
                                                        <p className="font-medium text-sm">{a.name}</p>
                                                        {diff && <p className={`text-xs ${diff.color}`}>{diff.label}</p>}
                                                    </div>
                                                </div>
                                            </TableCell>
                                            <TableCell className="text-xs text-muted-foreground">{a.category || "–"}</TableCell>
                                            <TableCell className="text-xs text-muted-foreground">
                                                {a.rule
                                                    ? `${METRIC_LABELS[a.rule.metric] || a.rule.metric} ${OPERATOR_LABELS[a.rule.operator] || a.rule.operator} ${a.rule.target_value}`
                                                    : <span className="text-amber-500">Sem regra</span>}
                                            </TableCell>
                                            <TableCell className="font-semibold text-sm">{fmtPoints(a.points)}</TableCell>
                                            <TableCell>
                                                <Badge variant={st.variant}>{st.label}</Badge>
                                            </TableCell>
                                            <TableCell className="text-right">
                                                <div className="flex justify-end gap-1">
                                                    <Button size="sm" variant="ghost" onClick={() => setFormTarget(a)} title="Editar" data-testid={`edit-achievement-${a.id}`}>
                                                        <Pencil size={14} />
                                                    </Button>
                                                    <Button size="sm" variant="ghost" onClick={() => setGrantTarget(a)} title="Conceder manualmente" data-testid={`grant-achievement-${a.id}`}>
                                                        <Award size={14} />
                                                    </Button>
                                                    {a.status === "DRAFT" && (
                                                        <Button size="sm" variant="ghost" className="text-luppa-green" onClick={() => changeStatus(a.id, "ACTIVE")} data-testid={`activate-achievement-${a.id}`}>Ativar</Button>
                                                    )}
                                                    {a.status === "ACTIVE" && (
                                                        <Button size="sm" variant="ghost" className="text-amber-500" onClick={() => changeStatus(a.id, "PAUSED")} data-testid={`pause-achievement-${a.id}`}>Pausar</Button>
                                                    )}
                                                    {a.status === "PAUSED" && (
                                                        <Button size="sm" variant="ghost" className="text-luppa-green" onClick={() => changeStatus(a.id, "ACTIVE")}>Ativar</Button>
                                                    )}
                                                    {a.status !== "ARCHIVED" && (
                                                        <AlertDialog>
                                                            <AlertDialogTrigger asChild>
                                                                <Button size="sm" variant="ghost" className="text-luppa-error" data-testid={`archive-achievement-${a.id}`}>Arquivar</Button>
                                                            </AlertDialogTrigger>
                                                            <AlertDialogContent>
                                                                <AlertDialogHeader>
                                                                    <AlertDialogTitle>Arquivar conquista?</AlertDialogTitle>
                                                                    <AlertDialogDescription>"{a.name}" será arquivada e não poderá mais ser editada.</AlertDialogDescription>
                                                                </AlertDialogHeader>
                                                                <AlertDialogFooter>
                                                                    <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                                                    <AlertDialogAction onClick={() => changeStatus(a.id, "ARCHIVED")}>Arquivar</AlertDialogAction>
                                                                </AlertDialogFooter>
                                                            </AlertDialogContent>
                                                        </AlertDialog>
                                                    )}
                                                </div>
                                            </TableCell>
                                        </TableRow>
                                    );
                                })}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>
            )}

            {formTarget !== null && (
                <AchievementFormDialog
                    tenantSlug={tenantSlug}
                    achievement={Object.keys(formTarget).length > 0 ? formTarget : null}
                    onClose={() => setFormTarget(null)}
                    onSaved={() => { setFormTarget(null); load(); }}
                />
            )}

            {grantTarget && (
                <GrantAchievementDialog
                    tenantSlug={tenantSlug}
                    achievement={grantTarget}
                    sellers={sellers}
                    onClose={() => setGrantTarget(null)}
                    onGranted={() => { setGrantTarget(null); toast.success("Conquista concedida!"); }}
                />
            )}
        </div>
    );
}

// ─── Formulário de Conquista ──────────────────────────────────────────────────
const defaultForm = () => ({
    name: "", description: "", category: "", icon: "award",
    points: 50, difficulty: "MEDIUM", visibility: "PUBLIC",
    scope: "SELLER", period_type: "", recurrence: "ONCE",
    approval_mode: "AUTOMATIC", reward: "",
    rule_metric: "SALES_COUNT", rule_operator: "GTE", rule_target_value: 1,
});

function AchievementFormDialog({ tenantSlug, achievement, onClose, onSaved }) {
    const [form, setForm] = useState(achievement
        ? {
            ...defaultForm(),
            ...achievement,
            period_type: achievement.period_type || "",
            rule_metric: achievement.rule?.metric || "SALES_COUNT",
            rule_operator: achievement.rule?.operator || "GTE",
            // Para REVENUE/AVERAGE_TICKET: converter de centavos para R$ na exibição
            rule_target_value: MONEY_METRICS.has(achievement.rule?.metric)
                ? centsToFormBRL(achievement.rule?.target_value ?? 0)
                : (achievement.rule?.target_value ?? 1),
        }
        : defaultForm()
    );
    const [saving, setSaving] = useState(false);
    const setF = (k, v) => setForm((p) => ({ ...p, [k]: v }));

    const submit = async (e) => {
        e.preventDefault();
        setSaving(true);
        const payload = {
            ...form,
            period_type: form.period_type || null,
            // Para REVENUE/AVERAGE_TICKET: converter R$ → centavos
            rule_target_value: MONEY_METRICS.has(form.rule_metric)
                ? formBRLToCents(form.rule_target_value)
                : Number(form.rule_target_value),
        };
        try {
            if (achievement?.id) {
                await api.put(`/tenants/${tenantSlug}/achievements/${achievement.id}`, payload);
            } else {
                await api.post(`/tenants/${tenantSlug}/achievements`, payload);
            }
            toast.success(achievement?.id ? "Conquista atualizada." : "Conquista criada.");
            onSaved();
        } catch (err) {
            toast.error(extractError(err, "Erro ao salvar conquista"));
        } finally { setSaving(false); }
    };

    return (
        <Dialog open onOpenChange={onClose}>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                    <DialogTitle>{achievement?.id ? "Editar conquista" : "Nova conquista"}</DialogTitle>
                    <DialogDescription>Preencha os campos abaixo para configurar a conquista.</DialogDescription>
                </DialogHeader>
                <form onSubmit={submit} className="space-y-5">
                    {/* Seção: Info */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="md:col-span-2 space-y-2">
                            <Label>Nome <span className="text-luppa-error">*</span></Label>
                            <Input value={form.name} onChange={(e) => setF("name", e.target.value)} required data-testid="achievement-name-input" placeholder="Ex: Primeira Venda" />
                        </div>
                        <div className="md:col-span-2 space-y-2">
                            <Label>Descrição</Label>
                            <Textarea value={form.description || ""} onChange={(e) => setF("description", e.target.value)} rows={2} placeholder="Descreva a conquista…" data-testid="achievement-description-input" />
                        </div>
                        <div className="space-y-2">
                            <Label>Categoria</Label>
                            <Select value={form.category || ""} onValueChange={(v) => setF("category", v)}>
                                <SelectTrigger data-testid="achievement-category-select"><SelectValue placeholder="Selecione" /></SelectTrigger>
                                <SelectContent>
                                    {CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="space-y-2">
                            <Label>Ícone</Label>
                            <div className="flex gap-2 flex-wrap">
                                {ICONS.map(({ value, icon }) => (
                                    <button key={value} type="button"
                                        onClick={() => setF("icon", value)}
                                        className={`w-9 h-9 rounded-md border flex items-center justify-center transition-colors ${form.icon === value ? "bg-primary text-primary-foreground border-primary" : "border-border hover:bg-muted"}`}
                                    >{icon}</button>
                                ))}
                            </div>
                        </div>
                        <div className="space-y-2">
                            <Label>Pontos</Label>
                            <Input type="number" min={0} value={form.points} onChange={(e) => setF("points", Number(e.target.value))} data-testid="achievement-points-input" />
                        </div>
                        <div className="space-y-2">
                            <Label>Dificuldade</Label>
                            <Select value={form.difficulty || "MEDIUM"} onValueChange={(v) => setF("difficulty", v)}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>
                                    {DIFFICULTIES.map((d) => (
                                        <SelectItem key={d.value} value={d.value}>{d.label}</SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="space-y-2">
                            <Label>Período</Label>
                            <Select
                                value={form.period_type || "__none__"}
                                onValueChange={(v) => setF("period_type", v === "__none__" ? "" : v)}
                            >
                                <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                                <SelectContent>
                                    {PERIOD_TYPES.map((p) => <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="space-y-2">
                            <Label>Recorrência</Label>
                            <Select value={form.recurrence} onValueChange={(v) => setF("recurrence", v)}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>
                                    {RECURRENCES.map((r) => <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>)}
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="space-y-2">
                            <Label>Aprovação</Label>
                            <Select value={form.approval_mode} onValueChange={(v) => setF("approval_mode", v)}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>
                                    {APPROVALS.map((a) => <SelectItem key={a.value} value={a.value}>{a.label}</SelectItem>)}
                                </SelectContent>
                            </Select>
                        </div>
                    </div>

                    {/* Seção: Regra */}
                    <div className="border rounded-lg p-4 space-y-4 bg-muted/20">
                        <p className="text-sm font-semibold">Regra de desbloqueio</p>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div className="space-y-2">
                                <Label>Métrica</Label>
                                <Select value={form.rule_metric} onValueChange={(v) => setF("rule_metric", v)}>
                                    <SelectTrigger data-testid="achievement-metric-select"><SelectValue /></SelectTrigger>
                                    <SelectContent>
                                        {Object.entries(METRIC_LABELS).map(([k, v]) => (
                                            <SelectItem key={k} value={k}>{v}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="space-y-2">
                                <Label>Operador</Label>
                                <Select value={form.rule_operator} onValueChange={(v) => setF("rule_operator", v)}>
                                    <SelectTrigger data-testid="achievement-operator-select"><SelectValue /></SelectTrigger>
                                    <SelectContent>
                                        {Object.entries(OPERATOR_LABELS).map(([k, v]) => (
                                            <SelectItem key={k} value={k}>{v}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="space-y-2">
                                <Label>Valor da meta{MONEY_METRICS.has(form.rule_metric) ? " (R$)" : ""}</Label>
                                <Input
                                    type={MONEY_METRICS.has(form.rule_metric) ? "text" : "number"}
                                    inputMode={MONEY_METRICS.has(form.rule_metric) ? "decimal" : "numeric"}
                                    min={0}
                                    value={form.rule_target_value}
                                    onChange={(e) => setF("rule_target_value", e.target.value)}
                                    placeholder={MONEY_METRICS.has(form.rule_metric) ? "Ex: 1000,00" : "Ex: 10"}
                                    data-testid="achievement-target-input"
                                />
                            </div>
                        </div>
                        {MONEY_METRICS.has(form.rule_metric) ? (
                            <p className="text-xs text-muted-foreground">Informe o valor em R$. Ex: 1000 = R$ 1.000,00</p>
                        ) : null}
                    </div>

                    <DialogFooter>
                        <Button type="button" variant="outline" onClick={onClose}>Cancelar</Button>
                        <Button type="submit" disabled={saving} data-testid="save-achievement-btn">
                            {saving ? "Salvando…" : achievement?.id ? "Salvar alterações" : "Criar conquista"}
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}

// ─── Conceder conquista manualmente ──────────────────────────────────────────
function GrantAchievementDialog({ tenantSlug, achievement, sellers, onClose, onGranted }) {
    const [sellerId, setSellerId] = useState("");
    const [reason, setReason] = useState("");
    const [saving, setSaving] = useState(false);

    const submit = async (e) => {
        e.preventDefault();
        if (!sellerId) { toast.error("Selecione um vendedor."); return; }
        setSaving(true);
        try {
            await api.post(`/tenants/${tenantSlug}/achievements/${achievement.id}/grant`, {
                seller_id: sellerId, reason,
            });
            onGranted();
        } catch (err) {
            toast.error(extractError(err, "Erro ao conceder conquista"));
        } finally { setSaving(false); }
    };

    return (
        <Dialog open onOpenChange={onClose}>
            <DialogContent className="max-w-md">
                <DialogHeader>
                    <DialogTitle>Conceder conquista</DialogTitle>
                    <DialogDescription>Concedendo <strong>{achievement.name}</strong> manualmente.</DialogDescription>
                </DialogHeader>
                <form onSubmit={submit} className="space-y-4">
                    <div className="space-y-2">
                        <Label>Vendedor</Label>
                        <Select value={sellerId} onValueChange={setSellerId}>
                            <SelectTrigger data-testid="grant-seller-select"><SelectValue placeholder="Selecione um vendedor" /></SelectTrigger>
                            <SelectContent>
                                {sellers.map((s) => (
                                    <SelectItem key={s.id} value={s.id}>
                                        {s.user?.name || s.user_id}
                                    </SelectItem>
                                ))}
                            </SelectContent>
                        </Select>
                    </div>
                    <div className="space-y-2">
                        <Label>Motivo <span className="text-muted-foreground text-xs">(opcional)</span></Label>
                        <Textarea value={reason} onChange={(e) => setReason(e.target.value)} rows={2} placeholder="Descreva o motivo da concessão…" />
                    </div>
                    <DialogFooter>
                        <Button type="button" variant="outline" onClick={onClose}>Cancelar</Button>
                        <Button type="submit" disabled={saving} data-testid="confirm-grant-btn">
                            {saving ? "Concedendo…" : "Conceder"}
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}

// ─── Ranking ──────────────────────────────────────────────────────────────────
function RankingTab({ tenantSlug }) {
    const [ranking, setRanking] = useState([]);
    const [period, setPeriod] = useState("month");
    const [loading, setLoading] = useState(true);

    const load = useCallback(async (p) => {
        setLoading(true);
        try {
            const { data } = await api.get(`/tenants/${tenantSlug}/achievement-rankings?period=${p}`);
            setRanking(data);
        } catch { setRanking([]); }
        finally { setLoading(false); }
    }, [tenantSlug]);

    useEffect(() => { load(period); }, [period]);

    const MEDALS = ["🥇", "🥈", "🥉"];
    const MEDAL_CLASSES = [
        { bg: "bg-amber-100/80", text: "text-amber-600", bar: "bg-amber-400" },
        { bg: "bg-muted",        text: "text-muted-foreground", bar: "bg-muted-foreground/60" },
        { bg: "bg-muted/70",     text: "text-muted-foreground/80", bar: "bg-muted-foreground/40" },
    ];
    const maxPts = ranking[0]?.points || 1;

    return (
        <div className="space-y-4">
            <div className="flex gap-2">
                {[["week","Esta semana"],["month","Este mês"],["all","Geral"]].map(([k, label]) => (
                    <button key={k} onClick={() => setPeriod(k)} data-testid={`ranking-period-${k}`}
                        className={`text-xs px-3 py-1.5 rounded-full transition-colors ${
                            period === k ? "bg-primary text-primary-foreground font-medium" : "bg-muted text-muted-foreground hover:bg-muted/80"
                        }`}>{label}</button>
                ))}
            </div>
            {loading ? (
                <p className="text-sm text-muted-foreground">Carregando…</p>
            ) : ranking.length === 0 ? (
                <div className="flex flex-col items-center py-16 text-muted-foreground gap-3">
                    <TrendingUp size={32} strokeWidth={1.2} />
                    <p className="text-sm">Nenhum ponto registrado neste período.</p>
                </div>
            ) : (
                <div className="space-y-3">
                    {ranking.map((row) => {
                        const pct = Math.max(6, Math.round((row.points / maxPts) * 100));
                        const medalStyle = MEDAL_CLASSES[row.rank - 1] || { bg: "bg-muted/30", text: "text-muted-foreground", bar: "bg-muted-foreground/30" };
                        return (
                            <div key={row.seller_id} data-testid={`achievement-ranking-row-${row.rank}`}
                                className={`flex items-center gap-4 p-3 rounded-lg border ${row.rank === 1 ? "border-amber-200 bg-amber-50/60 dark:bg-amber-900/10 dark:border-amber-800" : "border-border bg-muted/20"}`}>
                                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold shrink-0 ${medalStyle.bg} ${medalStyle.text}`}>
                                    {row.rank <= 3 ? MEDALS[row.rank - 1] : row.rank}
                                </div>
                                <UserAvatar src={row.avatar_url} name={row.name} />
                                <div className="flex-1 min-w-0">
                                    <div className="flex items-center justify-between mb-1.5">
                                        <span className="text-sm font-semibold">{row.name}</span>
                                        <div className="text-right shrink-0 ml-4">
                                            <span className="text-sm font-bold">{row.points} pts</span>
                                            <p className="text-xs text-muted-foreground">{row.achievements_count} conquista{row.achievements_count !== 1 ? "s" : ""}</p>
                                        </div>
                                    </div>
                                    <div className="h-1.5 w-full bg-muted rounded-full overflow-hidden">
                                        <div className={`h-full rounded-full transition-all duration-500 ${medalStyle.bar}`}
                                            style={{ width: `${pct}%` }} />
                                    </div>
                                </div>
                            </div>
                        );
                    })}
                </div>
            )}
        </div>
    );
}

// ─── Minhas Conquistas (Seller) ───────────────────────────────────────────────
function MyAchievementsTab({ tenantSlug }) {
    const [awards, setAwards] = useState([]);
    const [progress, setProgress] = useState([]);
    const [loading, setLoading] = useState(true);
    // IDs já conhecidos — persiste em sessionStorage para não repetir animação
    const knownIdsKey = `known_awards_${tenantSlug}`;

    useEffect(() => {
        (async () => {
            setLoading(true);
            const [{ data: aw }, { data: pr }] = await Promise.all([
                api.get(`/tenants/${tenantSlug}/achievement-awards/my`),
                api.get(`/tenants/${tenantSlug}/achievement-awards/my-progress`).catch(() => ({ data: [] })),
            ]);
            setAwards(aw);
            setProgress(pr);
            setLoading(false);

            // ── Detectar novas conquistas e celebrar ──────────────────────────
            try {
                // Respeita prefers-reduced-motion
                const prefersReduced = window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches;

                const stored = JSON.parse(sessionStorage.getItem(knownIdsKey) || "[]");
                const storedSet = new Set(stored);
                const newAwards = aw.filter((a) => !storedSet.has(a.id));

                if (newAwards.length > 0) {
                    // Salva novos IDs para não repetir
                    sessionStorage.setItem(knownIdsKey, JSON.stringify(aw.map((a) => a.id)));

                    // Só exibe animação se não é o primeiro load (stored tinha algo antes)
                    if (stored.length > 0 && !prefersReduced) {
                        const confetti = (await import("canvas-confetti")).default;
                        const style = getComputedStyle(document.documentElement);
                        const primary = `hsl(${style.getPropertyValue("--primary").trim()})`;
                        const chart3  = `hsl(${style.getPropertyValue("--chart-3").trim()})`;
                        confetti({ particleCount: 120, spread: 80, origin: { y: 0.4 }, colors: [primary, chart3, "#FFD700"] });
                        setTimeout(() => {
                            confetti({ particleCount: 50, spread: 50, origin: { x: 0.1, y: 0.5 } });
                            confetti({ particleCount: 50, spread: 50, origin: { x: 0.9, y: 0.5 } });
                        }, 300);
                    } else if (stored.length === 0) {
                        // Primeiro acesso: apenas registra os IDs sem animação
                        sessionStorage.setItem(knownIdsKey, JSON.stringify(aw.map((a) => a.id)));
                    }

                    // Toast para cada conquista nova (independente de reduced-motion)
                    newAwards.slice(0, 3).forEach((a, i) => {
                        setTimeout(() => {
                            toast.success(`Conquista desbloqueada: ${a.achievement_name}!`, {
                                duration: 6000,
                                icon: "🏆",
                            });
                        }, i * 400);
                    });
                } else if (stored.length === 0) {
                    // Primeiro acesso: registra silenciosamente
                    sessionStorage.setItem(knownIdsKey, JSON.stringify(aw.map((a) => a.id)));
                }
            } catch { /* animação é não-crítica */ }
        })().catch(() => setLoading(false));
    }, [tenantSlug]);

    const inProgress = progress.filter((p) => !p.earned && p.target_value);
    const earned = awards;

    return (
        <div className="space-y-6">
            {loading ? <p className="text-sm text-muted-foreground">Carregando…</p> : (
                <>
                    {/* Em andamento */}
                    {inProgress.length > 0 && (
                        <div>
                            <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                                <Target size={14} className="text-luppa-purple" /> Em andamento
                            </h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                {inProgress.map((p, i) => {
                                    const ach = p.achievement;
                                    return (
                                        <Card key={i} className="border border-border shadow-sm">
                                            <CardContent className="p-4">
                                                <div className="flex items-start gap-3">
                                                    <div className="text-muted-foreground mt-0.5"><IconComp name={ach.icon} size={16} /></div>
                                                    <div className="flex-1 min-w-0">
                                                        <p className="text-sm font-medium">{ach.name}</p>
                                                        <p className="text-xs text-muted-foreground mb-2">{ach.description}</p>
                                                        <div className="flex items-center gap-2">
                                                            <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                                                                <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${p.progress_pct}%` }} />
                                                            </div>
                                                            <span className="text-xs text-muted-foreground shrink-0">{p.progress_pct}%</span>
                                                        </div>
                                                        <p className="text-xs text-muted-foreground mt-1">
                                                            {fmtProgress(p.current_value, p.metric)} / {fmtProgress(p.target_value, p.metric)} {METRIC_LABELS[p.metric] || p.metric}
                                                        </p>
                                                    </div>
                                                </div>
                                            </CardContent>
                                        </Card>
                                    );
                                })}
                            </div>
                        </div>
                    )}

                    {/* Desbloqueadas */}
                    {earned.length > 0 ? (
                        <div>
                            <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                                <Trophy size={14} className="text-amber-500" /> Desbloqueadas
                            </h3>
                            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                                {earned.map((a) => (
                                    <Card key={a.id} className="border border-border shadow-sm hover:shadow-md transition-shadow">
                                        <CardContent className="p-4 flex flex-col items-center gap-2 text-center">
                                            <div className="w-12 h-12 rounded-full bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 flex items-center justify-center text-amber-600">
                                                <IconComp name={a.icon} size={20} />
                                            </div>
                                            <p className="text-xs font-semibold leading-tight">{a.achievement_name}</p>
                                            <Badge variant="secondary" className="text-[10px]">+{a.points_awarded} pts</Badge>
                                        </CardContent>
                                    </Card>
                                ))}
                            </div>
                        </div>
                    ) : (
                        <div className="flex flex-col items-center py-12 text-muted-foreground gap-3">
                            <Award size={32} strokeWidth={1.2} />
                            <p className="text-sm">Você ainda não desbloqueou conquistas. Continue vendendo!</p>
                        </div>
                    )}
                </>
            )}
        </div>
    );
}

// ─── Aprovações ───────────────────────────────────────────────────────────────
function ApprovalsTab({ tenantSlug }) {
    const [reqs, setReqs] = useState([]);
    const [loading, setLoading] = useState(true);

    const load = async () => {
        setLoading(true);
        try {
            const { data } = await api.get(`/tenants/${tenantSlug}/achievement-requests?status=PENDING`);
            setReqs(Array.isArray(data) ? data : []);
        } catch { setReqs([]); }
        finally { setLoading(false); }
    };

    useEffect(() => { load(); }, [tenantSlug]);

    const review = async (id, action) => {
        try {
            await api.post(`/tenants/${tenantSlug}/achievement-requests/${id}/${action}`, { review_note: "" });
            toast.success(action === "approve" ? "Aprovada!" : "Recusada.");
            load();
        } catch (e) { toast.error(extractError(e, "Erro")); }
    };

    return (
        <div>
            {loading ? (
                <p className="text-sm text-muted-foreground">Carregando…</p>
            ) : reqs.length === 0 ? (
                <div className="flex flex-col items-center py-12 text-muted-foreground gap-3">
                    <CheckCircle size={32} strokeWidth={1.2} className="text-luppa-green" />
                    <p className="text-sm">Nenhuma solicitação pendente.</p>
                </div>
            ) : (
                <Card className="border border-border shadow-sm">
                    <CardContent className="p-0">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Conquista</TableHead>
                                    <TableHead>Vendedor</TableHead>
                                    <TableHead>Motivo</TableHead>
                                    <TableHead className="text-right">Ações</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {reqs.map((r) => (
                                    <TableRow key={r.id} data-testid={`request-row-${r.id}`}>
                                        <TableCell className="text-sm font-medium">{r.achievement_id}</TableCell>
                                        <TableCell className="text-xs text-muted-foreground">{r.seller_id}</TableCell>
                                        <TableCell className="text-xs text-muted-foreground">{r.reason || "–"}</TableCell>
                                        <TableCell className="text-right">
                                            <div className="flex justify-end gap-1">
                                                <Button size="sm" variant="ghost" className="text-luppa-green" onClick={() => review(r.id, "approve")} data-testid={`approve-request-${r.id}`}>
                                                    <CheckCircle size={14} />
                                                </Button>
                                                <Button size="sm" variant="ghost" className="text-luppa-error" onClick={() => review(r.id, "reject")} data-testid={`reject-request-${r.id}`}>
                                                    <XCircle size={14} />
                                                </Button>
                                            </div>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>
            )}
        </div>
    );
}

// ─── Página Principal ─────────────────────────────────────────────────────────
export default function GamificationPage() {
    const { tenantSlug } = useParams();
    const { hasPermission, role } = usePermissions();
    const { subscribe } = useRealtimeTenant();
    const { user } = useAuth();

    // Real-time: quando o backend publica ACHIEVEMENT_UNLOCKED, dispara confete
    useEffect(() => {
        const unsub = subscribe("ACHIEVEMENT_UNLOCKED", async (event) => {
            const p = event.payload || {};
            // Só celebra se for para este usuário
            if (p.user_id && user?.id && p.user_id !== user.id) return;

            try {
                const prefersReduced = window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches;
                if (!prefersReduced) {
                    const confetti = (await import("canvas-confetti")).default;
                    const style = getComputedStyle(document.documentElement);
                    const primary = `hsl(${style.getPropertyValue("--primary").trim()})`;
                    confetti({ particleCount: 130, spread: 90, origin: { y: 0.35 }, colors: [primary, "#FFD700", "#4CAF50"] });
                }
                toast.success(`Conquista desbloqueada: ${p.achievement_name || "Nova conquista"}!`, {
                    duration: 7000,
                    icon: "🏆",
                });
            } catch { /* não-crítico */ }
        });
        return unsub;
    }, [subscribe, user?.id]);

    const isManager = ["TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER"].includes(role);

    const tabs = [
        ...(isManager ? [{ value: "dashboard", label: "Painel", icon: <TrendingUp size={14} /> }] : []),
        ...(isManager ? [{ value: "achievements", label: "Conquistas", icon: <Trophy size={14} /> }] : []),
        { value: "mine",        label: "Minhas Conquistas", icon: <Star size={14} /> },
        { value: "ranking",     label: "Ranking",           icon: <Medal size={14} /> },
        ...(isManager ? [{ value: "approvals", label: "Aprovações", icon: <CheckCircle size={14} /> }] : []),
    ];

    const defaultTab = isManager ? "dashboard" : "mine";

    return (
        <div>
            <PageHeader eyebrow="Gamificação" title="Conquistas" description="Configure conquistas e acompanhe o desempenho da equipe." />
            <Tabs defaultValue={defaultTab} className="w-full">
                <TabsList className="mb-6 flex-wrap h-auto gap-1">
                    {tabs.map((t) => (
                        <TabsTrigger key={t.value} value={t.value} className="flex items-center gap-1.5 text-xs" data-testid={`tab-${t.value}`}>
                            {t.icon} {t.label}
                        </TabsTrigger>
                    ))}
                </TabsList>

                {isManager && (
                    <TabsContent value="dashboard">
                        <DashboardPanel tenantSlug={tenantSlug} />
                    </TabsContent>
                )}
                {isManager && (
                    <TabsContent value="achievements">
                        <AchievementsTab tenantSlug={tenantSlug} />
                    </TabsContent>
                )}
                <TabsContent value="mine">
                    <MyAchievementsTab tenantSlug={tenantSlug} />
                </TabsContent>
                <TabsContent value="ranking">
                    <RankingTab tenantSlug={tenantSlug} />
                </TabsContent>
                {isManager && (
                    <TabsContent value="approvals">
                        <ApprovalsTab tenantSlug={tenantSlug} />
                    </TabsContent>
                )}
            </Tabs>
        </div>
    );
}
