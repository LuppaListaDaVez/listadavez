import React, { useState } from "react";
import { Link, useParams } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ArrowLeft, Mail, CheckCircle } from "lucide-react";
import api from "@/lib/api";

export default function ForgotPasswordPage() {
    const { tenantSlug } = useParams();
    const [email, setEmail] = useState("");
    const [loading, setLoading] = useState(false);
    const [sent, setSent] = useState(false);
    const [error, setError] = useState(null);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError(null);
        setLoading(true);
        try {
            await api.post(`/tenants/${tenantSlug}/auth/password-reset/request`, { email });
            setSent(true);
        } catch (err) {
            const detail = err?.response?.data?.detail;
            setError(typeof detail === "string" ? detail : "Ocorreu um erro. Tente novamente.");
        } finally {
            setLoading(false);
        }
    };

    if (sent) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-background px-4">
                <div className="w-full max-w-sm text-center space-y-4">
                    <CheckCircle className="mx-auto h-12 w-12 text-luppa-green" />
                    <h1 className="font-sans text-2xl font-semibold">Verifique seu e-mail</h1>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                        Se o endereço <strong>{email}</strong> estiver cadastrado, você receberá um link
                        de redefinição de senha em breve.
                    </p>
                    <p className="text-xs text-muted-foreground">
                        Não recebeu? Verifique a pasta de spam ou&nbsp;
                        <button
                            className="underline hover:text-foreground transition-colors"
                            onClick={() => { setSent(false); setEmail(""); }}
                            data-testid="forgot-password-try-again"
                        >
                            tente novamente
                        </button>.
                    </p>
                    <Link
                        to={`/${tenantSlug}/login`}
                        className="inline-flex items-center gap-1 text-sm text-primary hover:underline mt-2"
                        data-testid="forgot-password-back-to-login"
                    >
                        <ArrowLeft className="h-4 w-4" /> Voltar para o login
                    </Link>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen flex items-center justify-center bg-background px-4">
            <div className="w-full max-w-sm space-y-6">
                <div>
                    <Link
                        to={`/${tenantSlug}/login`}
                        className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
                        data-testid="forgot-password-back-link"
                    >
                        <ArrowLeft className="h-4 w-4" /> Voltar ao login
                    </Link>
                    <h1 className="font-sans text-2xl font-semibold mt-4">Esqueceu sua senha?</h1>
                    <p className="text-sm text-muted-foreground mt-1">
                        Informe seu e-mail e enviaremos um link de redefinição.
                    </p>
                </div>

                <Card className="border border-border shadow-sm">
                    <CardContent className="p-6">
                        <form onSubmit={handleSubmit} className="space-y-4">
                            {error && (
                                <Alert variant="destructive">
                                    <AlertDescription data-testid="forgot-password-error">{error}</AlertDescription>
                                </Alert>
                            )}
                            <div className="space-y-2">
                                <Label htmlFor="email">E-mail</Label>
                                <div className="relative">
                                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                    <Input
                                        id="email"
                                        type="email"
                                        className="pl-9"
                                        placeholder="seu@email.com"
                                        value={email}
                                        onChange={(e) => setEmail(e.target.value)}
                                        data-testid="forgot-password-email-input"
                                        required
                                    />
                                </div>
                            </div>
                            <Button
                                type="submit"
                                className="w-full"
                                disabled={loading}
                                data-testid="forgot-password-submit-button"
                            >
                                {loading ? "Enviando…" : "Enviar link de redefinição"}
                            </Button>
                        </form>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
