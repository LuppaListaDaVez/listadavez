import React, { useState, useEffect, useCallback } from "react";
import { useParams } from "react-router-dom";
import {
    ResponsiveContainer, BarChart, Bar, XAxis, YAxis,
    Tooltip, CartesianGrid, Cell, LabelList,
} from "recharts";
import api from "@/lib/api";
import { centsToBRL } from "@/lib/money";
import { PageHeader, SellerAvatar } from "@/components/Common";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
    Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { useTenant } from "@/context/TenantContext";
import { usePermissions } from "@/hooks/usePermissions";
import { RefreshCw, Trophy, Medal } from "lucide-react";
import { toast } from "sonner";

const CRITERIA_OPTIONS = [
    { value: "REVENUE", label: "Receita" },
    { value: "CONVERSION", label: "Conversão" },
    { value: "AVERAGE_TICKET", label: "Ticket Médio" },
    { value: "SALES_COUNT", label: "Qtd. Vendas" },
    { value: "ATTENDANCE_COUNT", label: "Atendimentos" },
    { value: "ITEMS_SOLD", label: "Produtos Vendidos" },
];

const BAR_COLORS = [
    "hsl(var(--chart-1))",
    "hsl(var(--chart-4))",
    "hsl(var(--chart-3))",
    "hsl(var(--chart-2))",
    "hsl(var(--chart-5))",
];

function MedalIcon({ pos }) {
    if (pos === 1) return <Trophy size={16} className="text-amber-500" />;
    if (pos === 2) return <Medal size={16} className="text-zinc-400" />;
    if (pos === 3) return <Medal size={16} className="text-amber-700" />;
    return <span className="text-xs text-muted-foreground font-mono w-4 text-center">{pos}</span>;
}

function CustomTooltip({ active, payload, label }) {
    if (!active || !payload?.length) return null;
    const d = payload[0]?.payload;
    return (
        <div className="bg-card border border-border/60 rounded-md shadow-xs p-3 text-sm">
            <p className="font-semibold mb-1">{label}</p>
            <p className="text-muted-foreground">Métrica: <span className="font-bold text-foreground">{d?.metric_label}</span></p>
            <p className="text-muted-foreground">Atendimentos: <span className="text-foreground">{d?.atendimentos}</span></p>
            <p className="text-muted-foreground">Vendas: <span className="text-foreground">{d?.vendas}</span></p>
        </div>
    );
}

export default function RankingsPage() {
    const { tenantSlug } = useParams();
    const { context } = useTenant();
    const { hasPermission } = usePermissions();
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);

    const today = new Date().toISOString().slice(0, 10);
    const monthStart = `${today.slice(0, 7)}-01`;

    const [criteria, setCriteria] = useState("REVENUE");
    const [storeId, setStoreId] = useState("");
    const [periodStart, setPeriodStart] = useState(monthStart);
    const [periodEnd, setPeriodEnd] = useState(today);

    const stores = context?.stores || [];
    const canGenerate = hasPermission("rankings.generate");

    const load = useCallback(async () => {
        setLoading(true);
        try {
            const params = new URLSearchParams({ criteria, period_start: periodStart, period_end: periodEnd });
            if (storeId) params.set("store_id", storeId);
            const { data: res } = await api.get(`/tenants/${tenantSlug}/rankings?${params}`);
            setData(res);
        } catch {
            toast.error("Erro ao carregar ranking.");
        } finally {
            setLoading(false);
        }
    }, [tenantSlug, criteria, storeId, periodStart, periodEnd]);

    useEffect(() => { load(); }, [load]);

    const items = data?.items || [];
    const top10 = items.slice(0, 10);
    const chartData = top10.map((item) => ({
        ...item,
        name: item.seller_name?.split(" ")[0] || "—",
        displayValue: item.value,
    }));

    return (
        <div data-testid="rankings-page">
            <div className="flex items-start justify-between mb-6">
                <PageHeader eyebrow="Rankings" title="Rankings de Performance" description="Classificação dos vendedores por critério de performance no período." />
            </div>

            {/* Filtros */}
            <div className="bg-card border border-border/60 rounded-md p-4 mb-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 items-end">
                    <div className="space-y-1">
                        <Label className="text-xs text-muted-foreground">Critério</Label>
                        <Select value={criteria} onValueChange={setCriteria}>
                            <SelectTrigger className="h-8 text-sm" data-testid="filter-criteria">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                                {CRITERIA_OPTIONS.map((c) => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}
                            </SelectContent>
                        </Select>
                    </div>
                    <div className="space-y-1">
                        <Label className="text-xs text-muted-foreground">Data início</Label>
                        <Input type="date" value={periodStart} onChange={(e) => setPeriodStart(e.target.value)} className="h-8 text-sm" />
                    </div>
                    <div className="space-y-1">
                        <Label className="text-xs text-muted-foreground">Data fim</Label>
                        <Input type="date" value={periodEnd} onChange={(e) => setPeriodEnd(e.target.value)} className="h-8 text-sm" />
                    </div>
                    {stores.length > 1 && (
                        <div className="space-y-1">
                            <Label className="text-xs text-muted-foreground">Unidade</Label>
                            <Select value={storeId || "__all__"} onValueChange={(v) => setStoreId(v === "__all__" ? "" : v)}>
                                <SelectTrigger className="h-8 text-sm" data-testid="filter-store">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="__all__">Todas</SelectItem>
                                    {stores.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                                </SelectContent>
                            </Select>
                        </div>
                    )}
                </div>
                <div className="flex justify-end mt-3">
                    <Button variant="outline" size="sm" onClick={load} data-testid="btn-refresh">
                        <RefreshCw size={13} strokeWidth={1.5} className="mr-1.5" /> Atualizar
                    </Button>
                </div>
            </div>

            {/* Gráfico */}
            <Card className="border border-border shadow-sm mb-6" data-testid="ranking-chart">
                <CardContent className="p-6">
                    <p className="text-xs uppercase tracking-[0.12em] text-muted-foreground mb-1">
                        {CRITERIA_OPTIONS.find((c) => c.value === criteria)?.label} por Vendedor
                    </p>
                    <p className="text-xs text-muted-foreground mb-5">
                        {periodStart} → {periodEnd} · {items.length} vendedor{items.length !== 1 ? "es" : ""}
                    </p>
                    {loading ? (
                        <Skeleton className="h-64 w-full" />
                    ) : chartData.length === 0 ? (
                        <p className="text-center text-sm text-muted-foreground py-12">Sem dados para o período selecionado.</p>
                    ) : (
                        <ResponsiveContainer width="100%" height={260}>
                            <BarChart data={chartData} margin={{ top: 16, right: 16, bottom: 8, left: 0 }}>
                                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                                <XAxis dataKey="name" tick={{ fontSize: 12, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} />
                                <YAxis tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} axisLine={false} tickLine={false} width={50}
                                    tickFormatter={(v) => v >= 10000 ? `${(v / 100).toFixed(0)}` : v}
                                />
                                <Tooltip content={<CustomTooltip />} cursor={{ fill: "hsl(var(--muted))" }} />
                                <Bar dataKey="displayValue" radius={[3, 3, 0, 0]} maxBarSize={52}>
                                    <LabelList dataKey="metric_label" position="top" style={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} />
                                    {chartData.map((_, i) => (
                                        <Cell key={i} fill={BAR_COLORS[i % BAR_COLORS.length]} />
                                    ))}
                                </Bar>
                            </BarChart>
                        </ResponsiveContainer>
                    )}
                </CardContent>
            </Card>

            {/* Tabela de ranking */}
            <div className="bg-card border border-border/60 rounded-md overflow-hidden">
                <div className="overflow-x-auto">
                <table className="w-full text-sm" data-testid="table-rankings">
                    <thead>
                        <tr className="border-b border-border bg-muted/40">
                            {["#", "Vendedor", "Unidade", "Métrica", "Atendimentos", "Vendas"].map((h) => (
                                <th key={h} className="text-left px-4 py-3 text-xs font-medium uppercase tracking-[0.08em] text-muted-foreground">{h}</th>
                            ))}
                        </tr>
                    </thead>
                    <tbody>
                        {loading ? (
                            Array.from({ length: 5 }).map((_, i) => (
                                <tr key={i} className="border-b border-border">
                                    {[1, 2, 3, 4, 5, 6].map((j) => <td key={j} className="px-4 py-3"><Skeleton className="h-4 w-full" /></td>)}
                                </tr>
                            ))
                        ) : items.length === 0 ? (
                            <tr>
                                <td colSpan={6} className="text-center py-12 text-muted-foreground">
                                    <Trophy size={32} strokeWidth={1} className="mx-auto mb-2 text-muted-foreground/40" />
                                    <p>Nenhum dado encontrado para o período.</p>
                                </td>
                            </tr>
                        ) : (
                            items.map((item) => (
                                <tr key={item.seller_id || item.position} className={`border-b border-border transition-colors ${item.position <= 3 ? "bg-amber-50/40" : "hover:bg-muted/30"}`}>
                                    <td className="px-4 py-3 w-10">
                                        <div className="flex items-center justify-center">
                                            <MedalIcon pos={item.position} />
                                        </div>
                                    </td>
                                    <td className="px-4 py-3 font-medium">
                                        <SellerAvatar
                                            name={item.seller_name || "—"}
                                            src={item.seller_avatar_url}
                                            size={28}
                                            showName
                                        />
                                    </td>
                                    <td className="px-4 py-3 text-muted-foreground">{item.store_name || "—"}</td>
                                    <td className="px-4 py-3 font-bold font-mono">{item.metric_label}</td>
                                    <td className="px-4 py-3">{item.atendimentos}</td>
                                    <td className="px-4 py-3">{item.vendas}</td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    );
}
