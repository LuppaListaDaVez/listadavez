import React, { useEffect, useState, useCallback } from "react";
import { useParams } from "react-router-dom";
import { Archive, Plus, Download, Trash2, Eye } from "lucide-react";
import api from "@/lib/api";
import { PageHeader } from "@/components/Common";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { usePermissions } from "@/hooks/usePermissions";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";

const STATUS_COLORS = { COMPLETED: "bg-luppa-green/15 text-luppa-green", RUNNING: "bg-luppa-purple/15 text-luppa-purple", PENDING: "bg-gray-100 text-gray-600", FAILED: "bg-luppa-error/15 text-luppa-error", EXPIRED: "bg-gray-100 text-gray-500", DELETED: "bg-luppa-error/10 text-luppa-error/70" };
const STATUS_PT = { COMPLETED: "Concluído", RUNNING: "Rodando", PENDING: "Pendente", FAILED: "Falhou", EXPIRED: "Expirado", DELETED: "Excluído" };
const TYPE_PT = { TENANT_FULL: "Completo", TENANT_CONFIG: "Config", TENANT_OPERATIONAL_DATA: "Operacional", REPORT_EXPORT_ARCHIVE: "Relatório" };

function formatBytes(bytes) {
    if (!bytes) return "—";
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export default function BackupsPage() {
    const { tenantSlug } = useParams();
    const { hasFeature, hasPermission } = usePermissions();
    const [backups, setBackups] = useState([]);
    const [loading, setLoading] = useState(true);
    const [creating, setCreating] = useState(false);
    const [restorePreview, setRestorePreview] = useState(null);
    const [restoreOpen, setRestoreOpen] = useState(false);
    const [restoreConfirm, setRestoreConfirm] = useState("");
    const [restoreReason, setRestoreReason] = useState("");
    const [executing, setExecuting] = useState(false);

    const canCreate = hasPermission("backup.create");
    const canDownload = hasPermission("backup.download");
    const canDelete = hasPermission("backup.delete");
    const canRestore = hasPermission("backup.restore_preview");
    const canRestoreExecute = hasPermission("backup.restore_execute");
    const featureActive = hasFeature("backup_restore");

    const load = useCallback(async () => {
        setLoading(true);
        try {
            const res = await api.get(`/tenants/${tenantSlug}/backups`);
            setBackups(Array.isArray(res.data) ? res.data : []);
        } catch {
            toast.error("Erro ao carregar backups.");
        } finally {
            setLoading(false);
        }
    }, [tenantSlug]);

    useEffect(() => { load(); }, [load]);

    const handleCreate = async () => {
        setCreating(true);
        try {
            await api.post(`/tenants/${tenantSlug}/backups`, { backup_type: "TENANT_FULL" });
            toast.success("Backup criado com sucesso!");
            load();
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Erro ao criar backup.");
        } finally {
            setCreating(false);
        }
    };

    const handleDelete = async (id) => {
        try {
            await api.delete(`/tenants/${tenantSlug}/backups/${id}`);
            toast.success("Backup excluído.");
            load();
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Erro ao excluir.");
        }
    };

    const handleDownload = async (id) => {
        try {
            const res = await api.get(`/tenants/${tenantSlug}/backups/${id}/download`);
            const content = JSON.stringify(res.data, null, 2);
            const blob = new Blob([content], { type: "application/json" });
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url; a.download = `backup-${id}.json`; a.click();
            URL.revokeObjectURL(url);
            toast.success("Download iniciado!");
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Erro ao baixar.");
        }
    };

    const handleRestorePreview = async (backup) => {
        try {
            const res = await api.post(`/tenants/${tenantSlug}/restore/preview`, {
                snapshot_id: backup.id, mode: "RESTORE_CONFIG_ONLY"
            });
            setRestorePreview({ job: res.data, backup });
            setRestoreOpen(true);
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Erro ao gerar preview de restore.");
        }
    };

    const handleRestoreExecute = async () => {
        if (!restorePreview) return;
        setExecuting(true);
        try {
            await api.post(`/tenants/${tenantSlug}/restore/execute`, {
                snapshot_id: restorePreview.backup.id,
                restore_job_id: restorePreview.job.id,
                mode: "RESTORE_CONFIG_ONLY",
                confirmation: restoreConfirm,
                reason: restoreReason,
            });
            toast.success("Restore executado com sucesso!");
            setRestoreOpen(false);
            setRestorePreview(null);
            setRestoreConfirm("");
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Erro ao executar restore.");
        } finally {
            setExecuting(false);
        }
    };

    if (!featureActive) return (
        <div><PageHeader eyebrow="Governança" title="Backups" />
            <Card className="mt-6 border"><CardContent className="p-10 text-center"><p className="text-sm text-muted-foreground">Módulo Backup & Restore indisponível.</p></CardContent></Card>
        </div>
    );

    return (
        <div data-testid="backups-page">
            <div className="flex items-start justify-between mb-6">
                <PageHeader eyebrow="Governança" title="Backups" description="Backups tenant-scoped com checksum e retenção controlada." />
                {canCreate && (
                    <Button size="sm" onClick={handleCreate} disabled={creating} data-testid="create-backup-btn" className="mt-1">
                        <Plus size={14} className="mr-2" />{creating ? "Criando..." : "Criar Backup"}
                    </Button>
                )}
            </div>

            <Card className="border border-border shadow-sm">
                <CardContent className="p-0">
                    {loading ? (
                        <div className="p-5 space-y-3"><Skeleton className="h-16" /><Skeleton className="h-16" /></div>
                    ) : backups.length === 0 ? (
                        <div className="p-10 text-center">
                            <Archive size={28} strokeWidth={1} className="mx-auto mb-2 text-muted-foreground" />
                            <p className="text-sm text-muted-foreground">Nenhum backup disponível.</p>
                        </div>
                    ) : backups.map(b => (
                        <div key={b.id} data-testid={`backup-${b.id}`} className="flex items-center justify-between py-3 px-4 border-b border-border last:border-0">
                            <div>
                                <div className="flex items-center gap-2 mb-0.5">
                                    <p className="text-sm font-medium">{TYPE_PT[b.backup_type] || b.backup_type}</p>
                                    <span className={`text-xs px-2 py-0.5 rounded-full ${STATUS_COLORS[b.status] || "bg-gray-100 text-gray-600"}`}>{STATUS_PT[b.status] || b.status}</span>
                                </div>
                                <p className="text-xs text-muted-foreground">
                                    {b.created_at?.slice(0, 10)} · {formatBytes(b.size_bytes)} · {b.checksum?.slice(0, 12)}...
                                </p>
                            </div>
                            <div className="flex items-center gap-2">
                                {canRestore && b.status === "COMPLETED" && (
                                    <button onClick={() => handleRestorePreview(b)} className="text-xs text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1" data-testid={`restore-preview-${b.id}`}>
                                        <Eye size={12} />Restore
                                    </button>
                                )}
                                {canDownload && b.status === "COMPLETED" && (
                                    <button onClick={() => handleDownload(b.id)} className="text-xs text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1" data-testid={`download-backup-${b.id}`}>
                                        <Download size={12} />Download
                                    </button>
                                )}
                                {canDelete && b.status !== "DELETED" && (
                                    <button onClick={() => handleDelete(b.id)} className="text-xs text-luppa-error/70 hover:text-luppa-error transition-colors flex items-center gap-1" data-testid={`delete-backup-${b.id}`}>
                                        <Trash2 size={12} />
                                    </button>
                                )}
                            </div>
                        </div>
                    ))}
                </CardContent>
            </Card>

            {/* Restore Dialog */}
            <Dialog open={restoreOpen} onOpenChange={() => { setRestoreOpen(false); setRestoreConfirm(""); }}>
                <DialogContent className="max-w-lg">
                    <DialogHeader><DialogTitle>Restore de Configurações</DialogTitle></DialogHeader>
                    {restorePreview && (
                        <div className="space-y-3 py-2 text-sm">
                            <div className="bg-amber-50 border border-amber-200 rounded p-3">
                                <p className="text-xs text-amber-800 font-medium mb-1">Atenção — Operação Crítica</p>
                                <p className="text-xs text-amber-700">{restorePreview.job.preview_summary?.warning}</p>
                            </div>
                            <div className="grid grid-cols-2 gap-2">
                                <div><p className="text-xs text-muted-foreground">Modo</p><p>{restorePreview.job.mode}</p></div>
                                <div><p className="text-xs text-muted-foreground">Registros</p><p>{restorePreview.job.preview_summary?.total_records ?? 0}</p></div>
                            </div>
                            <div>
                                <label className="text-xs text-muted-foreground">Motivo do restore</label>
                                <input className="w-full border border-border rounded-sm px-3 py-2 text-sm mt-1" value={restoreReason} onChange={e => setRestoreReason(e.target.value)} placeholder="Descreva o motivo..." />
                            </div>
                            {canRestoreExecute && (
                                <div>
                                    <label className="text-xs text-muted-foreground">Digite <strong>CONFIRMO_RESTORE</strong> para confirmar</label>
                                    <input className="w-full border border-border rounded-sm px-3 py-2 text-sm mt-1 font-mono" value={restoreConfirm} onChange={e => setRestoreConfirm(e.target.value)} placeholder="CONFIRMO_RESTORE" data-testid="restore-confirmation-input" />
                                </div>
                            )}
                        </div>
                    )}
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setRestoreOpen(false)}>Cancelar</Button>
                        {canRestoreExecute && (
                            <Button
                                variant="destructive"
                                onClick={handleRestoreExecute}
                                disabled={restoreConfirm !== "CONFIRMO_RESTORE" || executing}
                                data-testid="execute-restore-btn"
                            >
                                {executing ? "Executando..." : "Executar Restore"}
                            </Button>
                        )}
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}
