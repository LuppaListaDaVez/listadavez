import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import api, { extractError } from "@/lib/api";
import { PageHeader, EmptyState } from "@/components/Common";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import {
    AlertTriangle, ChevronDown, ChevronRight, Eye, Pencil, Plus,
    Search, Trash2, ArrowUp, ArrowDown, Power,
} from "lucide-react";

const TIPO_PLURAL = { grupo: "grupos", subgrupo: "subgrupos", motivo: "motivos" };
const VAZIO = "__vazio__";

const novoForm = (tipo, extra = {}) => ({
    tipo,
    identificador: "",
    nome: "",
    descricao: "",
    ativo: true,
    grupo_motivo_perda_id: "",
    subgrupo_motivo_perda_id: "",
    exige_descricao_complementar: false,
    limite_descricao_complementar: 300,
    ...extra,
});

export default function LossReasonsList() {
    const { tenantSlug } = useParams();
    const [grupos, setGrupos] = useState([]);
    const [loading, setLoading] = useState(true);
    const [termo, setTermo] = useState("");
    const [status, setStatus] = useState("todos");
    const [abertos, setAbertos] = useState({});
    const [form, setForm] = useState(null);
    const [uso, setUso] = useState(null);
    const [salvando, setSalvando] = useState(false);

    const carregar = useCallback(async () => {
        setLoading(true);
        try {
            const params = new URLSearchParams();
            if (termo.trim()) params.set("termo", termo.trim());
            const { data } = await api.get(`/tenants/${tenantSlug}/motivos-perda/estrutura?${params}`);
            setGrupos(data.grupos || []);
        } catch (e) {
            toast.error(extractError(e, "Erro ao carregar motivos de perda"));
        } finally {
            setLoading(false);
        }
    }, [tenantSlug, termo]);

    useEffect(() => { carregar(); }, [carregar]);

    const gruposFiltrados = useMemo(() => {
        const porStatus = (item) => status === "todos" || (status === "ativos" ? item.ativo : !item.ativo);
        return grupos
            .filter(porStatus)
            .map((g) => ({
                ...g,
                subgrupos: (g.subgrupos || []).filter(porStatus).map((s) => ({
                    ...s,
                    motivos: (s.motivos || []).filter(porStatus),
                })),
            }));
    }, [grupos, status]);

    const subgruposDisponiveis = useMemo(() => {
        const gid = form?.grupo_motivo_perda_id;
        return grupos.find((g) => g.identificador === gid)?.subgrupos || [];
    }, [grupos, form]);

    const abrirForm = (tipo, item = null, extra = {}) => {
        if (!item) {
            setForm(novoForm(tipo, extra));
            return;
        }
        const base = novoForm(tipo, { ...item, ativo: item.ativo !== false });
        if (tipo === "motivo") {
            const grupo = grupos.find((g) => (g.subgrupos || []).some((s) => s.identificador === item.subgrupo_motivo_perda_id));
            base.grupo_motivo_perda_id = grupo?.identificador || item.grupo_motivo_perda_id || "";
        }
        setForm(base);
    };

    const salvar = async (e) => {
        e.preventDefault();
        if (salvando) return;
        setSalvando(true);
        try {
            const tipo = form.tipo;
            const editando = !!form.identificador;
            const payload = montarPayload(form, editando);
            const rota = `/tenants/${tenantSlug}/motivos-perda/${TIPO_PLURAL[tipo]}${editando ? `/${form.identificador}` : ""}`;
            if (editando) await api.put(rota, payload);
            else await api.post(rota, payload);
            toast.success(editando ? "Alteração salva." : "Item criado.");
            setForm(null);
            await carregar();
        } catch (e) {
            toast.error(extractError(e, "Não foi possível salvar"));
        } finally {
            setSalvando(false);
        }
    };

    const alterarStatus = async (tipo, item) => {
        try {
            await api.patch(`/tenants/${tenantSlug}/motivos-perda/${TIPO_PLURAL[tipo]}/${item.identificador}/status`, { ativo: !item.ativo });
            toast.success(item.ativo ? "Item desativado." : "Item ativado.");
            await carregar();
        } catch (e) { toast.error(extractError(e, "Não foi possível alterar o status")); }
    };

    const mover = async (tipo, item, direcao) => {
        try {
            await api.patch(`/tenants/${tenantSlug}/motivos-perda/${TIPO_PLURAL[tipo]}/${item.identificador}/mover`, { direcao });
            await carregar();
        } catch (e) { toast.error(extractError(e, "Não foi possível ordenar")); }
    };

    const excluir = async (tipo, item) => {
        if (!window.confirm(`Confirmar exclusão de "${item.nome}"?`)) return;
        try {
            const { data } = await api.delete(`/tenants/${tenantSlug}/motivos-perda/${TIPO_PLURAL[tipo]}/${item.identificador}`);
            toast.success(data.mensagem || (data.excluido ? "Item excluído." : "Item desativado."));
            await carregar();
        } catch (e) { toast.error(extractError(e, "Não foi possível excluir")); }
    };

    const visualizarUso = async (tipo, item) => {
        try {
            const { data } = await api.get(`/tenants/${tenantSlug}/motivos-perda/${TIPO_PLURAL[tipo]}/${item.identificador}/uso`);
            setUso({ tipo, item, dados: data });
        } catch (e) { toast.error(extractError(e, "Erro ao carregar uso")); }
    };

    const alternarAberto = (id) => setAbertos((prev) => ({ ...prev, [id]: !prev[id] }));

    return (
        <div data-testid="motivos-perda-page">
            <PageHeader eyebrow="Configurações" title="Motivos de perda" description="Estrutura livre: Grupo → Subgrupo → Motivo, criada por cada empresa.">
                <Button className="gap-2" onClick={() => abrirForm("grupo")} data-testid="motivos-perda-novo-grupo">
                    <Plus size={16} /> Criar grupo
                </Button>
            </PageHeader>

            <Alert className="mb-5" data-testid="motivos-perda-info-transicao">
                <AlertTriangle size={15} />
                <AlertDescription>
                    Nenhum grupo, subgrupo ou motivo é criado automaticamente. Durante a transição, os motivos antigos continuam funcionando até existir uma combinação ativa completa.
                </AlertDescription>
            </Alert>

            <div className="flex flex-col md:flex-row gap-3 mb-5">
                <div className="relative flex-1">
                    <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                    <Input
                        className="pl-9"
                        value={termo}
                        onChange={(e) => setTermo(e.target.value)}
                        onKeyDown={(e) => { if (e.key === "Enter") carregar(); }}
                        placeholder="Pesquisar na hierarquia"
                        data-testid="motivos-perda-pesquisa"
                    />
                </div>
                <Select value={status} onValueChange={setStatus}>
                    <SelectTrigger className="w-full md:w-44" data-testid="motivos-perda-filtro-status"><SelectValue /></SelectTrigger>
                    <SelectContent>
                        <SelectItem value="todos" data-testid="motivos-perda-filtro-todos">Todos</SelectItem>
                        <SelectItem value="ativos" data-testid="motivos-perda-filtro-ativos">Ativos</SelectItem>
                        <SelectItem value="inativos" data-testid="motivos-perda-filtro-inativos">Inativos</SelectItem>
                    </SelectContent>
                </Select>
                <Button variant="outline" onClick={carregar} data-testid="motivos-perda-aplicar-pesquisa">Aplicar</Button>
            </div>

            {loading ? (
                <p className="text-sm text-muted-foreground">Carregando…</p>
            ) : grupos.length === 0 ? (
                <EmptyState title="Nenhuma estrutura cadastrada" description="Cadastre ao menos um grupo, um subgrupo e um motivo ativo para utilizar a classificação de perdas." />
            ) : (
                <div className="space-y-3">
                    {gruposFiltrados.map((grupo) => (
                        <Card key={grupo.identificador} className="border border-border shadow-sm" data-testid={`grupo-motivo-card-${grupo.identificador}`}>
                            <CardContent className="p-4">
                                <LinhaElemento
                                    tipo="grupo"
                                    item={grupo}
                                    aberto={!!abertos[grupo.identificador]}
                                    temFilhos={(grupo.subgrupos || []).length > 0}
                                    onToggle={() => alternarAberto(grupo.identificador)}
                                    onNovo={() => abrirForm("subgrupo", null, { grupo_motivo_perda_id: grupo.identificador })}
                                    onEditar={() => abrirForm("grupo", grupo)}
                                    onStatus={() => alterarStatus("grupo", grupo)}
                                    onMover={(d) => mover("grupo", grupo, d)}
                                    onUso={() => visualizarUso("grupo", grupo)}
                                    onExcluir={() => excluir("grupo", grupo)}
                                />
                                {!!abertos[grupo.identificador] && (
                                    <div className="mt-3 ml-2 md:ml-8 space-y-2 border-l border-border pl-3 md:pl-5">
                                        {(grupo.subgrupos || []).length === 0 ? <p className="text-sm text-muted-foreground">Nenhum subgrupo neste grupo.</p> : grupo.subgrupos.map((subgrupo) => (
                                            <div key={subgrupo.identificador} className="rounded-md border border-border/70 bg-muted/20 p-3" data-testid={`subgrupo-motivo-card-${subgrupo.identificador}`}>
                                                <LinhaElemento
                                                    tipo="subgrupo"
                                                    item={subgrupo}
                                                    aberto={!!abertos[subgrupo.identificador]}
                                                    temFilhos={(subgrupo.motivos || []).length > 0}
                                                    onToggle={() => alternarAberto(subgrupo.identificador)}
                                                    onNovo={() => abrirForm("motivo", null, { grupo_motivo_perda_id: grupo.identificador, subgrupo_motivo_perda_id: subgrupo.identificador })}
                                                    onEditar={() => abrirForm("subgrupo", subgrupo)}
                                                    onStatus={() => alterarStatus("subgrupo", subgrupo)}
                                                    onMover={(d) => mover("subgrupo", subgrupo, d)}
                                                    onUso={() => visualizarUso("subgrupo", subgrupo)}
                                                    onExcluir={() => excluir("subgrupo", subgrupo)}
                                                />
                                                {!!abertos[subgrupo.identificador] && (
                                                    <div className="mt-3 ml-2 md:ml-8 space-y-2">
                                                        {(subgrupo.motivos || []).length === 0 ? <p className="text-sm text-muted-foreground">Nenhum motivo neste subgrupo.</p> : subgrupo.motivos.map((motivo) => (
                                                            <div key={motivo.identificador} className="rounded-md border border-border/60 bg-card p-3" data-testid={`motivo-perda-card-${motivo.identificador}`}>
                                                                <LinhaElemento
                                                                    tipo="motivo"
                                                                    item={motivo}
                                                                    onEditar={() => abrirForm("motivo", motivo)}
                                                                    onStatus={() => alterarStatus("motivo", motivo)}
                                                                    onMover={(d) => mover("motivo", motivo, d)}
                                                                    onUso={() => visualizarUso("motivo", motivo)}
                                                                    onExcluir={() => excluir("motivo", motivo)}
                                                                />
                                                            </div>
                                                        ))}
                                                    </div>
                                                )}
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </CardContent>
                        </Card>
                    ))}
                </div>
            )}

            {form && (
                <FormularioElemento
                    form={form}
                    setForm={setForm}
                    grupos={grupos}
                    subgruposDisponiveis={subgruposDisponiveis}
                    onClose={() => setForm(null)}
                    onSubmit={salvar}
                    salvando={salvando}
                />
            )}

            {uso && <UsoDialog uso={uso} onClose={() => setUso(null)} />}
        </div>
    );
}

function montarPayload(form, editando) {
    if (form.tipo === "grupo") {
        return editando
            ? { nome: form.nome, descricao: form.descricao || null }
            : { nome: form.nome, descricao: form.descricao || null, ativo: form.ativo };
    }
    if (form.tipo === "subgrupo") {
        return editando
            ? { grupo_motivo_perda_id: form.grupo_motivo_perda_id, nome: form.nome, descricao: form.descricao || null }
            : { grupo_motivo_perda_id: form.grupo_motivo_perda_id, nome: form.nome, descricao: form.descricao || null, ativo: form.ativo };
    }
    return editando
        ? {
            subgrupo_motivo_perda_id: form.subgrupo_motivo_perda_id,
            nome: form.nome,
            descricao: form.descricao || null,
            exige_descricao_complementar: form.exige_descricao_complementar,
            limite_descricao_complementar: Number(form.limite_descricao_complementar) || 300,
        }
        : {
            subgrupo_motivo_perda_id: form.subgrupo_motivo_perda_id,
            nome: form.nome,
            descricao: form.descricao || null,
            ativo: form.ativo,
            exige_descricao_complementar: form.exige_descricao_complementar,
            limite_descricao_complementar: Number(form.limite_descricao_complementar) || 300,
        };
}

function LinhaElemento({ tipo, item, aberto, temFilhos, onToggle, onNovo, onEditar, onStatus, onMover, onUso, onExcluir }) {
    const label = { grupo: "Grupo", subgrupo: "Subgrupo", motivo: "Motivo" }[tipo];
    return (
        <div className="flex flex-col lg:flex-row lg:items-center gap-3">
            <div className="flex items-start gap-3 flex-1 min-w-0">
                {onToggle ? (
                    <button onClick={onToggle} className="mt-1 h-7 w-7 rounded-md border border-border flex items-center justify-center hover:bg-muted" data-testid={`${tipo}-toggle-${item.identificador}`}>
                        {aberto ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                    </button>
                ) : <div className="w-7" />}
                <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                        <Badge variant="outline">{label}</Badge>
                        <h3 className="font-semibold truncate" data-testid={`${tipo}-nome-${item.identificador}`}>{item.nome}</h3>
                        <Badge variant={item.ativo ? "default" : "outline"}>{item.ativo ? "Ativo" : "Inativo"}</Badge>
                        {tipo === "motivo" && item.exige_descricao_complementar && <Badge variant="secondary">Exige descrição</Badge>}
                    </div>
                    {item.descricao && <p className="text-sm text-muted-foreground mt-1">{item.descricao}</p>}
                    <p className="text-xs text-muted-foreground mt-1">
                        {item.quantidade_registros_vinculados || 0} registro(s) vinculado(s){temFilhos ? " · contém itens internos" : ""}
                    </p>
                </div>
            </div>
            <div className="flex flex-wrap gap-1.5 lg:justify-end">
                {onNovo && <Button size="sm" variant="outline" onClick={onNovo} data-testid={`${tipo}-novo-filho-${item.identificador}`}><Plus size={13} /> Novo</Button>}
                <Button size="icon" variant="ghost" onClick={() => onMover("cima")} data-testid={`${tipo}-mover-cima-${item.identificador}`}><ArrowUp size={14} /></Button>
                <Button size="icon" variant="ghost" onClick={() => onMover("baixo")} data-testid={`${tipo}-mover-baixo-${item.identificador}`}><ArrowDown size={14} /></Button>
                <Button size="icon" variant="ghost" onClick={onUso} data-testid={`${tipo}-visualizar-uso-${item.identificador}`}><Eye size={14} /></Button>
                <Button size="icon" variant="ghost" onClick={onEditar} data-testid={`${tipo}-editar-${item.identificador}`}><Pencil size={14} /></Button>
                <Button size="icon" variant="ghost" onClick={onStatus} data-testid={`${tipo}-status-${item.identificador}`}><Power size={14} /></Button>
                <Button size="icon" variant="ghost" onClick={onExcluir} data-testid={`${tipo}-excluir-${item.identificador}`}><Trash2 size={14} className="text-destructive" /></Button>
            </div>
        </div>
    );
}

function FormularioElemento({ form, setForm, grupos, subgruposDisponiveis, onClose, onSubmit, salvando }) {
    const editando = !!form.identificador;
    const titulo = `${editando ? "Editar" : "Criar"} ${form.tipo}`;
    return (
        <Dialog open onOpenChange={onClose}>
            <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto" data-testid="motivos-perda-form-dialog">
                <DialogHeader>
                    <DialogTitle>{titulo}</DialogTitle>
                    <DialogDescription>Informe os dados do elemento da hierarquia de motivos de perda.</DialogDescription>
                </DialogHeader>
                <form onSubmit={onSubmit} className="space-y-4">
                    {(form.tipo === "subgrupo" || form.tipo === "motivo") && (
                        <div className="space-y-2">
                            <Label>Grupo</Label>
                            <Select value={form.grupo_motivo_perda_id || VAZIO} onValueChange={(v) => setForm({ ...form, grupo_motivo_perda_id: v === VAZIO ? "" : v, subgrupo_motivo_perda_id: "" })}>
                                <SelectTrigger data-testid="motivos-perda-form-grupo"><SelectValue placeholder="Selecione" /></SelectTrigger>
                                <SelectContent className="max-h-72">
                                    <SelectItem value={VAZIO} data-testid="motivos-perda-form-grupo-vazio">Selecione</SelectItem>
                                    {grupos.map((g) => <SelectItem key={g.identificador} value={g.identificador} data-testid={`motivos-perda-form-grupo-${g.identificador}`}>{g.nome}</SelectItem>)}
                                </SelectContent>
                            </Select>
                        </div>
                    )}
                    {form.tipo === "motivo" && (
                        <div className="space-y-2">
                            <Label>Subgrupo</Label>
                            <Select value={form.subgrupo_motivo_perda_id || VAZIO} disabled={!form.grupo_motivo_perda_id} onValueChange={(v) => setForm({ ...form, subgrupo_motivo_perda_id: v === VAZIO ? "" : v })}>
                                <SelectTrigger data-testid="motivos-perda-form-subgrupo"><SelectValue placeholder="Selecione" /></SelectTrigger>
                                <SelectContent className="max-h-72">
                                    <SelectItem value={VAZIO} data-testid="motivos-perda-form-subgrupo-vazio">Selecione</SelectItem>
                                    {subgruposDisponiveis.map((s) => <SelectItem key={s.identificador} value={s.identificador} data-testid={`motivos-perda-form-subgrupo-${s.identificador}`}>{s.nome}</SelectItem>)}
                                </SelectContent>
                            </Select>
                        </div>
                    )}
                    <div className="space-y-2">
                        <Label>Nome</Label>
                        <Input value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} required data-testid="motivos-perda-form-nome" />
                    </div>
                    <div className="space-y-2">
                        <Label>Descrição</Label>
                        <Textarea value={form.descricao || ""} onChange={(e) => setForm({ ...form, descricao: e.target.value })} data-testid="motivos-perda-form-descricao" />
                    </div>
                    {!editando && (
                        <label className="flex items-center gap-2 text-sm cursor-pointer">
                            <Checkbox checked={form.ativo} onCheckedChange={(v) => setForm({ ...form, ativo: !!v })} data-testid="motivos-perda-form-ativo" />
                            Ativo
                        </label>
                    )}
                    {form.tipo === "motivo" && (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <label className="flex items-center gap-2 text-sm cursor-pointer pt-7">
                                <Checkbox checked={form.exige_descricao_complementar} onCheckedChange={(v) => setForm({ ...form, exige_descricao_complementar: !!v })} data-testid="motivos-perda-form-exige-descricao" />
                                Exige descrição complementar
                            </label>
                            <div className="space-y-2">
                                <Label>Limite da descrição</Label>
                                <Input type="number" min="1" max="2000" value={form.limite_descricao_complementar} onChange={(e) => setForm({ ...form, limite_descricao_complementar: e.target.value })} data-testid="motivos-perda-form-limite-descricao" />
                            </div>
                        </div>
                    )}
                    <DialogFooter>
                        <Button type="button" variant="outline" onClick={onClose} data-testid="motivos-perda-form-cancelar">Cancelar</Button>
                        <Button type="submit" disabled={salvando} data-testid="motivos-perda-form-salvar">{salvando ? "Salvando…" : "Salvar"}</Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
}

function UsoDialog({ uso, onClose }) {
    const d = uso.dados;
    return (
        <Dialog open onOpenChange={onClose}>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" data-testid="motivos-perda-uso-dialog">
                <DialogHeader>
                    <DialogTitle>Visualizar uso — {uso.item.nome}</DialogTitle>
                    <DialogDescription>Resumo dos atendimentos vinculados a este elemento.</DialogDescription>
                </DialogHeader>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    <MiniKpi label="Atendimentos" value={d.quantidade_atendimentos || 0} />
                    <MiniKpi label="Unidades" value={(d.unidades || []).length} />
                    <MiniKpi label="Vendedores" value={(d.vendedores || []).length} />
                    <MiniKpi label="Última utilização" value={d.ultima_utilizacao ? new Date(d.ultima_utilizacao).toLocaleDateString("pt-BR") : "—"} />
                </div>
                <div className="space-y-2">
                    <p className="text-sm font-medium">Atendimentos relacionados</p>
                    {(d.atendimentos || []).length === 0 ? <p className="text-sm text-muted-foreground">Nenhum atendimento vinculado.</p> : (
                        <div className="rounded-md border border-border overflow-hidden">
                            {(d.atendimentos || []).slice(0, 20).map((a) => (
                                <div key={a.id} className="flex items-center justify-between gap-3 px-3 py-2 border-b border-border last:border-0 text-sm" data-testid={`motivos-perda-uso-atendimento-${a.id}`}>
                                    <span className="font-mono text-xs">{a.id}</span>
                                    <span>{a.finished_at ? new Date(a.finished_at).toLocaleString("pt-BR") : "—"}</span>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
                <DialogFooter><Button onClick={onClose} data-testid="motivos-perda-uso-fechar">Fechar</Button></DialogFooter>
            </DialogContent>
        </Dialog>
    );
}

function MiniKpi({ label, value }) {
    return (
        <div className="rounded-md border border-border p-3 bg-muted/20">
            <p className="text-xs text-muted-foreground">{label}</p>
            <p className="font-semibold mt-1" data-testid={`motivos-perda-kpi-${label.toLowerCase().replace(/\s+/g, "-")}`}>{value}</p>
        </div>
    );
}