import React, { useEffect, useState, useCallback } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Plus, Filter, ChevronRight, User, Clock } from "lucide-react";
import api from "@/lib/api";
import { PageHeader } from "@/components/Common";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { usePermissions } from "@/hooks/usePermissions";
import {
    Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";

const STATUS_PT = { OPEN: "Aberta", IN_REVIEW: "Em revisão", PROCESSING: "Processando", RESOLVED: "Resolvida", REJECTED: "Rejeitada", CANCELLED: "Cancelada", WAITING_VERIFICATION: "Aguardando" };
const TYPE_PT = { ACCESS: "Acesso", CORRECTION: "Correção", ANONYMIZATION: "Anonimização", DELETION: "Exclusão", PORTABILITY: "Portabilidade", CONSENT_WITHDRAWAL: "Retirada de consentimento", RESTRICTION: "Restrição", INFORMATION: "Informação" };
const STATUS_COLORS = { OPEN: "bg-luppa-warning/15 text-luppa-warning", IN_REVIEW: "bg-luppa-purple/15 text-luppa-purple", PROCESSING: "bg-luppa-purple/15 text-luppa-purple", RESOLVED: "bg-luppa-green/15 text-luppa-green", REJECTED: "bg-luppa-error/15 text-luppa-error", CANCELLED: "bg-gray-100 text-gray-700", WAITING_VERIFICATION: "bg-luppa-warning/15 text-luppa-warning" };

function NewRequestModal({ open, onClose, onCreated, tenantSlug }) {
    const [form, setForm] = useState({ request_type: "ACCESS", data_subject_type: "USER", description: "", priority: "NORMAL", data_subject_name: "", data_subject_email: "" });
    const [saving, setSaving] = useState(false);

    const submit = async () => {
        setSaving(true);
        try {
            await api.post(`/tenants/${tenantSlug}/privacy/requests`, form);
            toast.success("Solicitação criada!");
            onCreated();
            onClose();
        } catch (e) {
            toast.error(e?.response?.data?.detail || "Erro ao criar solicitação.");
        } finally {
            setSaving(false);
        }
    };

    return (
        <Dialog open={open} onOpenChange={onClose}>
            <DialogContent className="max-w-lg">
                <DialogHeader><DialogTitle>Nova Solicitação LGPD</DialogTitle></DialogHeader>
                <div className="space-y-3 py-2">
                    <div>
                        <label className="text-xs text-muted-foreground">Tipo</label>
                        <select className="w-full border border-border rounded-sm px-3 py-2 text-sm mt-1 bg-background" value={form.request_type} onChange={e => setForm(f => ({ ...f, request_type: e.target.value }))}>
                            {Object.entries(TYPE_PT).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                        </select>
                    </div>
                    <div>
                        <label className="text-xs text-muted-foreground">Nome do Titular</label>
                        <input className="w-full border border-border rounded-sm px-3 py-2 text-sm mt-1" value={form.data_subject_name} onChange={e => setForm(f => ({ ...f, data_subject_name: e.target.value }))} placeholder="Nome completo" />
                    </div>
                    <div>
                        <label className="text-xs text-muted-foreground">E-mail do Titular</label>
                        <input type="email" className="w-full border border-border rounded-sm px-3 py-2 text-sm mt-1" value={form.data_subject_email} onChange={e => setForm(f => ({ ...f, data_subject_email: e.target.value }))} placeholder="email@exemplo.com" />
                    </div>
                    <div>
                        <label className="text-xs text-muted-foreground">Prioridade</label>
                        <select className="w-full border border-border rounded-sm px-3 py-2 text-sm mt-1 bg-background" value={form.priority} onChange={e => setForm(f => ({ ...f, priority: e.target.value }))}>
                            <option value="LOW">Baixa</option><option value="NORMAL">Normal</option><option value="HIGH">Alta</option><option value="URGENT">Urgente</option>
                        </select>
                    </div>
                    <div>
                        <label className="text-xs text-muted-foreground">Descrição</label>
                        <textarea className="w-full border border-border rounded-sm px-3 py-2 text-sm mt-1" rows={3} value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} placeholder="Descreva a solicitação..." />
                    </div>
                </div>
                <DialogFooter>
                    <Button variant="outline" onClick={onClose}>Cancelar</Button>
                    <Button onClick={submit} disabled={saving} data-testid="submit-privacy-request-btn">
                        {saving ? "Salvando..." : "Criar Solicitação"}
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}

function RequestCard({ req, onClick }) {
    return (
        <div data-testid={`privacy-request-${req.id}`}
            onClick={onClick}
            className="flex items-center justify-between py-3 px-4 border-b border-border last:border-0 hover:bg-muted/30 cursor-pointer transition-colors"
        >
            <div className="min-w-0 flex-1 pr-4">
                <div className="flex items-center gap-2 mb-0.5">
                    <span className="text-sm font-medium">{TYPE_PT[req.request_type] || req.request_type}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${STATUS_COLORS[req.status] || "bg-gray-100 text-gray-600"}`}>{STATUS_PT[req.status] || req.status}</span>
                    {req.priority === "HIGH" && <span className="text-xs bg-luppa-warning/15 text-luppa-warning px-1.5 py-0.5 rounded">ALTA</span>}
                    {req.priority === "URGENT" && <span className="text-xs bg-luppa-error/15 text-luppa-error px-1.5 py-0.5 rounded">URGENTE</span>}
                </div>
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1"><User size={10} />{req.data_subject_name || "—"}</span>
                    <span className="flex items-center gap-1"><Clock size={10} />{req.created_at?.slice(0, 10)}</span>
                </div>
                {req.description && <p className="text-xs text-muted-foreground mt-0.5 truncate">{req.description.slice(0, 80)}</p>}
            </div>
            <ChevronRight size={14} className="text-muted-foreground flex-shrink-0" />
        </div>
    );
}

export default function PrivacyRequestsPage() {
    const { tenantSlug } = useParams();
    const navigate = useNavigate();
    const { hasFeature } = usePermissions();
    const [requests, setRequests] = useState([]);
    const [loading, setLoading] = useState(true);
    const [filterStatus, setFilterStatus] = useState("");
    const [filterType, setFilterType] = useState("");
    const [showNew, setShowNew] = useState(false);

    const load = useCallback(async () => {
        setLoading(true);
        try {
            const params = new URLSearchParams();
            if (filterStatus) params.set("status", filterStatus);
            if (filterType) params.set("request_type", filterType);
            const res = await api.get(`/tenants/${tenantSlug}/privacy/requests?${params.toString()}`);
            setRequests(Array.isArray(res.data) ? res.data : []);
        } catch {
            toast.error("Erro ao carregar solicitações.");
        } finally {
            setLoading(false);
        }
    }, [tenantSlug, filterStatus, filterType]);

    useEffect(() => { load(); }, [load]);

    if (!hasFeature("lgpd")) return (
        <div><PageHeader eyebrow="Privacidade" title="Solicitações LGPD" />
            <Card className="mt-6 border"><CardContent className="p-10 text-center"><p className="text-sm text-muted-foreground">Módulo LGPD indisponível.</p></CardContent></Card>
        </div>
    );

    return (
        <div data-testid="privacy-requests-page">
            <div className="flex items-start justify-between mb-6">
                <PageHeader eyebrow="Privacidade" title="Solicitações LGPD" description="Gerencie pedidos de acesso, correção, portabilidade e exclusão de dados." />
                <Button size="sm" onClick={() => setShowNew(true)} data-testid="new-privacy-request-btn" className="mt-1">
                    <Plus size={14} className="mr-2" />Nova Solicitação
                </Button>
            </div>

            {/* Filtros */}
            <div className="flex gap-3 mb-5 flex-wrap">
                <select className="border border-border rounded-sm px-3 py-1.5 text-sm bg-background" value={filterStatus} onChange={e => setFilterStatus(e.target.value)} data-testid="filter-status">
                    <option value="">Todos os status</option>
                    {Object.entries(STATUS_PT).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </select>
                <select className="border border-border rounded-sm px-3 py-1.5 text-sm bg-background" value={filterType} onChange={e => setFilterType(e.target.value)} data-testid="filter-type">
                    <option value="">Todos os tipos</option>
                    {Object.entries(TYPE_PT).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </select>
            </div>

            <Card className="border border-border shadow-sm">
                <CardContent className="p-0">
                    {loading ? (
                        <div className="p-5 space-y-3"><Skeleton className="h-14" /><Skeleton className="h-14" /><Skeleton className="h-14" /></div>
                    ) : requests.length === 0 ? (
                        <div className="p-10 text-center">
                            <Filter size={24} strokeWidth={1} className="mx-auto mb-2 text-muted-foreground" />
                            <p className="text-sm text-muted-foreground">Nenhuma solicitação encontrada.</p>
                        </div>
                    ) : (
                        requests.map(req => (
                            <RequestCard
                                key={req.id}
                                req={req}
                                onClick={() => navigate(`/${tenantSlug}/privacy/requests/${req.id}`)}
                            />
                        ))
                    )}
                </CardContent>
            </Card>

            <NewRequestModal
                open={showNew}
                onClose={() => setShowNew(false)}
                onCreated={load}
                tenantSlug={tenantSlug}
            />
        </div>
    );
}
