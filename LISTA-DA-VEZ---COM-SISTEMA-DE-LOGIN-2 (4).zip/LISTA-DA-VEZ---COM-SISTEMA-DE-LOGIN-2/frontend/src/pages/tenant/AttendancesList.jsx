import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import api from "@/lib/api";
import { PageHeader, EmptyState, SellerAvatar } from "@/components/Common";
import { fmtDateTime, fmtBRL } from "@/lib/i18n";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
    Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
    Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";

const STATUS_VARIANT = {
    IN_PROGRESS: "default", FINISHED: "secondary", CANCELLED: "outline",
};
const STATUS_LABEL_PT = {
    IN_PROGRESS: "Em andamento", FINISHED: "Finalizado", CANCELLED: "Cancelado",
};
const RESULT_LABEL = {
    SALE: "Sucesso", NO_SALE: "Não sucesso", FOLLOW_UP: "Retornará", INVALID: "Inválido",
};

function brl(cents) {
    return fmtBRL(cents);
}

export default function AttendancesList() {
    const { tenantSlug } = useParams();
    const [items, setItems] = useState([]);
    const [loading, setLoading] = useState(true);
    const [status, setStatus] = useState("ALL");

    const load = async () => {
        setLoading(true);
        try {
            const q = status === "ALL" ? "" : `?status=${status}`;
            const { data } = await api.get(`/tenants/${tenantSlug}/attendances${q}`);
            setItems(Array.isArray(data) ? data : (data.items || []));
        } catch { setItems([]); }
        setLoading(false);
    };
    useEffect(() => { load(); /* eslint-disable-next-line */ }, [tenantSlug, status]);

    return (
        <div data-testid="attendances-page">
            <PageHeader eyebrow="Operação" title="Atendimentos" description="Histórico de atendimentos da Lista da Vez.">
                <Select value={status} onValueChange={setStatus}>
                    <SelectTrigger className="w-44" data-testid="att-status-filter"><SelectValue /></SelectTrigger>
                    <SelectContent>
                        <SelectItem value="ALL">Todos</SelectItem>
                        <SelectItem value="IN_PROGRESS">Em andamento</SelectItem>
                        <SelectItem value="FINISHED">Finalizados</SelectItem>
                        <SelectItem value="CANCELLED">Cancelados</SelectItem>
                    </SelectContent>
                </Select>
            </PageHeader>

            {loading ? <p className="text-sm text-muted-foreground">Carregando…</p> :
             items.length === 0 ? <EmptyState title="Sem atendimentos" description="Os atendimentos aparecerão aqui." /> :
             <Card className="border border-border shadow-sm"><CardContent className="p-0">
                <Table>
                    <TableHeader><TableRow>
                        <TableHead>Vendedor</TableHead>
                        <TableHead>Unidade</TableHead>
                        <TableHead>Resultado</TableHead>
                        <TableHead>Valor</TableHead>
                        <TableHead className="text-right">Qtd. produtos</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Início</TableHead>
                    </TableRow></TableHeader>
                    <TableBody>
                        {items.map((a) => (
                            <TableRow key={a.id} data-testid={`attendance-row-${a.id}`}>
                                <TableCell>
                                    <SellerAvatar
                                        name={a.seller_name || "—"}
                                        src={a.seller_avatar_url}
                                        size={26}
                                        showName
                                    />
                                </TableCell>
                                <TableCell className="text-sm text-muted-foreground">{a.store_name || "—"}</TableCell>
                                <TableCell>{a.result ? RESULT_LABEL[a.result] || a.result : "—"}</TableCell>
                                <TableCell className="font-mono text-sm">{a.result === "SALE" ? brl(a.sale_amount_cents) : "—"}</TableCell>
                                <TableCell className="text-right font-mono text-sm tabular-nums" data-testid={`att-product-qty-${a.id}`}>
                                    {a.result === "SALE" ? (a.product_quantity ?? 0) : "—"}
                                </TableCell>
                                <TableCell><Badge variant={STATUS_VARIANT[a.status] || "outline"}>{STATUS_LABEL_PT[a.status] || a.status}</Badge></TableCell>
                                <TableCell className="text-xs font-mono text-muted-foreground">{fmtDateTime(a.started_at)}</TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
             </CardContent></Card>}
        </div>
    );
}

