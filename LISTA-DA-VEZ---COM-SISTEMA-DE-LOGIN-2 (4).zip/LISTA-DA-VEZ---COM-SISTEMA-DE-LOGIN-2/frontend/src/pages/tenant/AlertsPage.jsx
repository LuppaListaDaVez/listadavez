import React, { useEffect, useState, useCallback } from "react";
import { useParams } from "react-router-dom";
import { AlertTriangle, CheckCircle2, Clock, Filter, RefreshCw, Plus, Zap } from "lucide-react";
import api from "@/lib/api";
import { PageHeader } from "@/components/Common";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { useTenant } from "@/context/TenantContext";
import { fmtDateTime } from "@/lib/i18n";

const SEVERITY_COLOR = {
    INFO: "text-luppa-purple bg-luppa-purple/10 border-luppa-purple/25",
    WARNING: "text-amber-700 bg-amber-50 border-amber-200",
    CRITICAL: "text-luppa-error bg-luppa-error/10 border-luppa-error/25",
};

const STATUS_LABEL = {
    OPEN: "Aberto", ACKNOWLEDGED: "Ciente", RESOLVED: "Resolvido", DISMISSED: "Ignorado",
};

const ALERT_TYPE_LABEL = {
    LOW_CONVERSION: "Baixa conversão",
    HIGH_LOSS_RATE: "Alta taxa de perda",
    QUEUE_WAITING_TOO_LONG: "Fila aguardando",
    ATTENDANCE_STALLED: "Atendimento parado",
    SELLER_INACTIVE: "Vendedor inativo",
    GOAL_AT_RISK: "Meta em risco",
    FEEDBACK_OVERDUE: "Feedback pendente",
    PROACTIVE_LOW_ACTIVITY: "Baixa proatividade",
    SYSTEM_WARNING: "Alerta de sistema",
};


export default function AlertsPage() {
    const { tenantSlug } = useParams();
    const { context } = useTenant();
    const [alerts, setAlerts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [filters, setFilters] = useState({ status: "", severity: "" });
    const role = context?.user_role;
    const canResolve = ["TENANT_ADMIN", "STORE_MANAGER", "SUPERVISOR"].includes(role);
    const canGenerate = ["TENANT_ADMIN"].includes(role);

    const load = useCallback(async () => {
        setLoading(true);
        try {
            const params = new URLSearchParams();
            Object.entries(filters).forEach(([k, v]) => { if (v) params.set(k, v); });
            const res = await api.get(`/tenants/${tenantSlug}/alerts?${params}`);
            setAlerts(res.data);
        } catch {
            toast.error("Erro ao carregar alertas");
        } finally {
            setLoading(false);
        }
    }, [tenantSlug, filters]);

    useEffect(() => { load(); }, [load]);

    const handleAck = async (alertId) => {
        try {
            await api.post(`/tenants/${tenantSlug}/alerts/${alertId}/acknowledge`);
            toast.success("Marcado como ciente");
            await load();
        } catch (e) { toast.error(e?.response?.data?.detail || "Erro"); }
    };

    const handleResolve = async (alertId) => {
        try {
            await api.post(`/tenants/${tenantSlug}/alerts/${alertId}/resolve`);
            toast.success("Alerta resolvido");
            await load();
        } catch (e) { toast.error(e?.response?.data?.detail || "Erro"); }
    };

    const handleGenerate = async () => {
        try {
            await api.post(`/tenants/${tenantSlug}/alerts/generate`);
            toast.success("Verificação de alertas iniciada");
            setTimeout(load, 1000);
        } catch (e) { toast.error(e?.response?.data?.detail || "Erro"); }
    };

    const openCount = alerts.filter(a => a.status === "OPEN").length;
    const criticalCount = alerts.filter(a => a.severity === "CRITICAL" && a.status === "OPEN").length;

    return (
        <div data-testid="alerts-page">
            <div className="flex items-start justify-between mb-6">
                <PageHeader
                    eyebrow="Operacional"
                    title="Alertas Inteligentes"
                    description="Alertas operacionais automáticos e monitoramento em tempo real."
                />
                <div className="flex gap-2 mt-1">
                    {canGenerate && (
                        <Button variant="outline" size="sm" onClick={handleGenerate} data-testid="generate-alerts-btn">
                            <Zap size={14} className="mr-2" /> Verificar agora
                        </Button>
                    )}
                    <Button variant="outline" size="sm" onClick={load} data-testid="alerts-refresh-btn">
                        <RefreshCw size={14} className="mr-2" /> Atualizar
                    </Button>
                </div>
            </div>

            {/* Summary */}
            <div className="metric-grid mb-6">
                {[
                    { label: "Total", value: alerts.length, color: "" },
                    { label: "Abertos", value: openCount, color: "text-amber-700" },
                    { label: "Críticos", value: criticalCount, color: "text-luppa-error" },
                    { label: "Resolvidos", value: alerts.filter(a => a.status === "RESOLVED").length, color: "text-luppa-green" },
                ].map((k, i) => (
                    <div key={i} className="metric-card-wrap border border-border/60 rounded-md p-4 bg-card">
                        <p className="metric-label text-xs uppercase tracking-[0.08em] text-muted-foreground mb-1">{k.label}</p>
                        <span className={`metric-num font-semibold ${k.color}`} data-testid={`alerts-kpi-${k.label.toLowerCase()}`}>{k.value}</span>
                    </div>
                ))}
            </div>

            {/* Filters */}
            <div className="flex gap-3 mb-4 flex-wrap">
                <select
                    className="border border-border rounded-sm px-3 py-1.5 text-sm bg-background"
                    value={filters.status}
                    onChange={e => setFilters(f => ({ ...f, status: e.target.value }))}
                    data-testid="alert-filter-status"
                >
                    <option value="">Todos os status</option>
                    {Object.entries(STATUS_LABEL).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
                </select>
                <select
                    className="border border-border rounded-sm px-3 py-1.5 text-sm bg-background"
                    value={filters.severity}
                    onChange={e => setFilters(f => ({ ...f, severity: e.target.value }))}
                    data-testid="alert-filter-severity"
                >
                    <option value="">Todas as severidades</option>
                    <option value="INFO">Informação</option>
                    <option value="WARNING">Aviso</option>
                    <option value="CRITICAL">Crítico</option>
                </select>
            </div>

            {/* List */}
            {loading ? (
                <div className="space-y-3">{[1,2,3].map(i => <Skeleton key={i} className="h-20 w-full" />)}</div>
            ) : alerts.length === 0 ? (
                <Card className="border border-border shadow-sm">
                    <CardContent className="p-10 text-center">
                        <CheckCircle2 size={32} strokeWidth={1} className="mx-auto mb-3 text-luppa-green" />
                        <p className="text-sm text-muted-foreground">Nenhum alerta encontrado.</p>
                    </CardContent>
                </Card>
            ) : (
                <div className="space-y-3" data-testid="alerts-list">
                    {alerts.map(a => (
                        <Card key={a.id} className={`border shadow-sm ${SEVERITY_COLOR[a.severity] || ""}`} data-testid={`alert-item-${a.id}`}>
                            <CardContent className="p-4">
                                <div className="flex items-start justify-between gap-4">
                                    <div className="min-w-0 flex-1">
                                        <div className="flex items-center gap-2 mb-1">
                                            <AlertTriangle size={14} strokeWidth={1.5} />
                                            <p className="font-semibold text-sm">{a.title}</p>
                                            <span className="text-xs px-1.5 py-0.5 rounded-full bg-background/60 font-medium">
                                                {ALERT_TYPE_LABEL[a.alert_type] || a.alert_type}
                                            </span>
                                        </div>
                                        <p className="text-sm opacity-80">{a.message}</p>
                                        <div className="flex items-center gap-3 mt-2 text-xs opacity-70">
                                            <span>{fmtDateTime(a.created_at)}</span>
                                            <span className="font-medium">{STATUS_LABEL[a.status]}</span>
                                        </div>
                                    </div>
                                    {a.status === "OPEN" && (
                                        <div className="flex gap-2 flex-shrink-0">
                                            <button
                                                onClick={() => handleAck(a.id)}
                                                className="text-xs px-2 py-1 rounded-sm border border-current/30 hover:bg-background/40 transition-colors"
                                                data-testid={`alert-ack-${a.id}`}
                                            >
                                                <Clock size={12} className="inline mr-1" /> Ciente
                                            </button>
                                            {canResolve && (
                                                <button
                                                    onClick={() => handleResolve(a.id)}
                                                    className="text-xs px-2 py-1 rounded-sm border border-current/30 hover:bg-background/40 transition-colors"
                                                    data-testid={`alert-resolve-${a.id}`}
                                                >
                                                    <CheckCircle2 size={12} className="inline mr-1" /> Resolver
                                                </button>
                                            )}
                                        </div>
                                    )}
                                </div>
                            </CardContent>
                        </Card>
                    ))}
                </div>
            )}
        </div>
    );
}
