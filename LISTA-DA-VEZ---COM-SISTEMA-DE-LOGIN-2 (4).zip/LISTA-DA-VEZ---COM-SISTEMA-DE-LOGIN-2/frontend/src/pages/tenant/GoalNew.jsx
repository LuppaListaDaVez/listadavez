import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import api from "@/lib/api";
import { centsToBRL } from "@/lib/money";
import { PageHeader } from "@/components/Common";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
    Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { useTenant } from "@/context/TenantContext";
import { toast } from "sonner";
import { ArrowLeft } from "lucide-react";

const GOAL_TYPES = [
    { value: "REVENUE", label: "Receita (R$)", hint: "Ex: R$ 10.000,00 → enviar 1000000" },
    { value: "CONVERSION", label: "Conversão (%)", hint: "Ex: 70% → enviar 7000" },
    { value: "AVERAGE_TICKET", label: "Ticket Médio (R$)", hint: "Ex: R$ 200,00 → enviar 20000" },
    { value: "ATTENDANCES", label: "Atendimentos (nº)", hint: "Ex: 100 atendimentos" },
    { value: "SALES_COUNT", label: "Qtd. Vendas (nº)", hint: "Ex: 20 vendas" },
    { value: "ITEMS_SOLD", label: "Produtos Vendidos (qtd.)", hint: "Ex: 50 produtos" },
];
const GOAL_SCOPES = [
    { value: "TENANT", label: "Tenant (toda a empresa)" },
    { value: "STORE", label: "Unidade" },
    { value: "TEAM", label: "Equipe" },
    { value: "SELLER", label: "Vendedor Individual" },
];
const GOAL_PERIODS = [
    { value: "DAILY", label: "Diário" },
    { value: "WEEKLY", label: "Semanal" },
    { value: "MONTHLY", label: "Mensal" },
    { value: "CUSTOM", label: "Personalizado" },
];

function today() {
    return new Date().toISOString().slice(0, 10);
}
function monthStart() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-01`;
}
function monthEnd() {
    const d = new Date();
    return new Date(d.getFullYear(), d.getMonth() + 1, 0).toISOString().slice(0, 10);
}

// Converte o valor exibido em centavos/basis-points para salvar
function toStoreValue(displayVal, type) {
    const n = parseFloat(String(displayVal).replace(",", "."));
    if (isNaN(n)) return 0;
    if (type === "REVENUE" || type === "AVERAGE_TICKET") return Math.round(n * 100);
    if (type === "CONVERSION") return Math.round(n * 100); // 70.00% → 7000 bp
    return Math.round(n);
}
// Converte centavos/bp para exibição
function fromStoreValue(storeVal, type) {
    if (!storeVal) return "";
    if (type === "REVENUE" || type === "AVERAGE_TICKET") return (storeVal / 100).toFixed(2);
    if (type === "CONVERSION") return (storeVal / 100).toFixed(2);
    return String(storeVal);
}

export default function GoalNew() {
    const { tenantSlug, goalId } = useParams();
    const navigate = useNavigate();
    const { context } = useTenant();

    const isEdit = !!goalId;
    const [loading, setLoading] = useState(false);
    const [sellers, setSellers] = useState([]);
    const [teams, setTeams] = useState([]);

    const [form, setForm] = useState({
        title: "",
        description: "",
        type: "REVENUE",
        scope: "STORE",
        store_id: "",
        team_id: "",
        seller_id: "",
        period: "MONTHLY",
        period_start: monthStart(),
        period_end: monthEnd(),
        target_display: "",
    });

    const stores = context?.stores || [];

    useEffect(() => {
        (async () => {
            try {
                const [s, t] = await Promise.all([
                    api.get(`/tenants/${tenantSlug}/sellers`),
                    api.get(`/tenants/${tenantSlug}/teams`),
                ]);
                setSellers(s.data || []);
                setTeams(t.data || []);
            } catch { /* ignore */ }
        })();

        if (isEdit) {
            (async () => {
                try {
                    const { data } = await api.get(`/tenants/${tenantSlug}/goals/${goalId}`);
                    setForm({
                        title: data.title || "",
                        description: data.description || "",
                        type: data.type || "REVENUE",
                        scope: data.scope || "STORE",
                        store_id: data.store_id || "",
                        team_id: data.team_id || "",
                        seller_id: data.seller_id || "",
                        period: data.period || "MONTHLY",
                        period_start: data.period_start || monthStart(),
                        period_end: data.period_end || monthEnd(),
                        target_display: fromStoreValue(data.target_value, data.type),
                    });
                } catch {
                    toast.error("Erro ao carregar meta.");
                }
            })();
        }
    }, [tenantSlug, goalId, isEdit]);

    const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

    const handleSubmit = async (e) => {
        e.preventDefault();
        const target_value = toStoreValue(form.target_display, form.type);
        if (!target_value || target_value <= 0) {
            toast.error("Informe um valor alvo válido.");
            return;
        }
        if (!form.title.trim()) {
            toast.error("Título é obrigatório.");
            return;
        }

        const payload = {
            title: form.title.trim(),
            description: form.description || undefined,
            type: form.type,
            scope: form.scope,
            store_id: form.store_id || undefined,
            team_id: form.team_id || undefined,
            seller_id: form.seller_id || undefined,
            period: form.period,
            period_start: form.period_start,
            period_end: form.period_end,
            target_value,
        };

        setLoading(true);
        try {
            if (isEdit) {
                await api.put(`/tenants/${tenantSlug}/goals/${goalId}`, {
                    title: payload.title,
                    description: payload.description,
                    target_value: payload.target_value,
                    period_end: payload.period_end,
                });
                toast.success("Meta atualizada com sucesso.");
            } else {
                const { data } = await api.post(`/tenants/${tenantSlug}/goals`, payload);
                toast.success("Meta criada com sucesso.");
                navigate(`/${tenantSlug}/goals/${data.id}`);
                return;
            }
            navigate(`/${tenantSlug}/goals`);
        } catch (err) {
            toast.error(err?.response?.data?.detail || "Erro ao salvar meta.");
        } finally {
            setLoading(false);
        }
    };

    const typeInfo = GOAL_TYPES.find((t) => t.value === form.type);

    return (
        <div data-testid="goal-form">
            <div className="flex items-center gap-3 mb-6">
                <button onClick={() => navigate(-1)} className="text-muted-foreground hover:text-foreground">
                    <ArrowLeft size={16} strokeWidth={1.5} />
                </button>
                <PageHeader eyebrow="Metas" title={isEdit ? "Editar Meta" : "Nova Meta"} />
            </div>

            <Card className="border border-border shadow-sm max-w-2xl">
                <CardContent className="p-6">
                    <form onSubmit={handleSubmit} className="space-y-5">
                        <div className="space-y-1">
                            <Label>Título *</Label>
                            <Input value={form.title} onChange={(e) => set("title", e.target.value)} placeholder="Ex: Meta mensal da loja" required data-testid="input-title" />
                        </div>

                        <div className="space-y-1">
                            <Label>Descrição</Label>
                            <Textarea value={form.description} onChange={(e) => set("description", e.target.value)} rows={2} placeholder="Opcional" />
                        </div>

                        {!isEdit && (
                            <>
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="space-y-1">
                                        <Label>Tipo da Meta *</Label>
                                        <Select value={form.type} onValueChange={(v) => set("type", v)} data-testid="select-type">
                                            <SelectTrigger><SelectValue /></SelectTrigger>
                                            <SelectContent>
                                                {GOAL_TYPES.map((t) => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
                                            </SelectContent>
                                        </Select>
                                        {typeInfo && <p className="text-xs text-muted-foreground">{typeInfo.hint}</p>}
                                    </div>
                                    <div className="space-y-1">
                                        <Label>Escopo *</Label>
                                        <Select value={form.scope} onValueChange={(v) => set("scope", v)}>
                                            <SelectTrigger><SelectValue /></SelectTrigger>
                                            <SelectContent>
                                                {GOAL_SCOPES.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                </div>

                                {form.scope === "STORE" && (
                                    <div className="space-y-1">
                                        <Label>Unidade</Label>
                                        <Select value={form.store_id || "__none__"} onValueChange={(v) => set("store_id", v === "__none__" ? "" : v)}>
                                            <SelectTrigger><SelectValue placeholder="Selecionar unidade" /></SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="__none__">Nenhuma</SelectItem>
                                                {stores.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                )}

                                {form.scope === "TEAM" && (
                                    <div className="space-y-1">
                                        <Label>Equipe</Label>
                                        <Select value={form.team_id || "__none__"} onValueChange={(v) => set("team_id", v === "__none__" ? "" : v)}>
                                            <SelectTrigger><SelectValue placeholder="Selecionar equipe" /></SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="__none__">Nenhuma</SelectItem>
                                                {teams.map((t) => <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>)}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                )}

                                {form.scope === "SELLER" && (
                                    <div className="space-y-1">
                                        <Label>Vendedor</Label>
                                        <Select value={form.seller_id || "__none__"} onValueChange={(v) => set("seller_id", v === "__none__" ? "" : v)}>
                                            <SelectTrigger><SelectValue placeholder="Selecionar vendedor" /></SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="__none__">Nenhum</SelectItem>
                                                {sellers.map((s) => <SelectItem key={s.id} value={s.id}>{s.user?.name || s.name || s.id}</SelectItem>)}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                )}

                                <div className="space-y-1">
                                    <Label>Período</Label>
                                    <Select value={form.period} onValueChange={(v) => set("period", v)}>
                                        <SelectTrigger><SelectValue /></SelectTrigger>
                                        <SelectContent>
                                            {GOAL_PERIODS.map((p) => <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}
                                        </SelectContent>
                                    </Select>
                                </div>
                            </>
                        )}

                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-1">
                                <Label>Data início *</Label>
                                <Input type="date" value={form.period_start} onChange={(e) => set("period_start", e.target.value)} required data-testid="input-period-start" />
                            </div>
                            <div className="space-y-1">
                                <Label>Data fim *</Label>
                                <Input type="date" value={form.period_end} onChange={(e) => set("period_end", e.target.value)} required data-testid="input-period-end" />
                            </div>
                        </div>

                        <div className="space-y-1">
                            <Label>
                                Valor Alvo *
                                {form.type === "REVENUE" || form.type === "AVERAGE_TICKET" ? " (R$)" : ""}
                                {form.type === "CONVERSION" ? " (%)" : ""}
                            </Label>
                            <Input
                                type="number"
                                step={form.type === "REVENUE" || form.type === "AVERAGE_TICKET" || form.type === "CONVERSION" ? "0.01" : "1"}
                                value={form.target_display}
                                onChange={(e) => set("target_display", e.target.value)}
                                placeholder={typeInfo?.hint || ""}
                                required
                                data-testid="input-target"
                            />
                        </div>

                        <div className="flex gap-3 pt-2">
                            <Button type="submit" disabled={loading} data-testid="btn-submit">
                                {loading ? "Salvando..." : isEdit ? "Salvar alterações" : "Criar meta"}
                            </Button>
                            <Button type="button" variant="outline" onClick={() => navigate(-1)}>Cancelar</Button>
                        </div>
                    </form>
                </CardContent>
            </Card>
        </div>
    );
}
