import React, { useState, useEffect, useCallback } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import api from "@/lib/api";
import { centsToBRL } from "@/lib/money";
import { PageHeader } from "@/components/Common";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, RefreshCw, Edit, XCircle, CheckCircle } from "lucide-react";
import { toast } from "sonner";
import { usePermissions } from "@/hooks/usePermissions";
import { GOAL_STATUS_PT, GOAL_TYPE_PT, GOAL_SCOPE_PT, fmtDate } from "@/lib/i18n";
import { useRealtimeTenant } from "@/context/RealtimeTenantContext";

// TYPE_LABELS e SCOPE_LABELS agora usam os maps centralizados do i18n
const TYPE_LABELS = GOAL_TYPE_PT;
const SCOPE_LABELS = GOAL_SCOPE_PT;
const STATUS_STYLES = {
    SCHEDULED: "bg-sky-100 text-sky-800",
    ACTIVE: "bg-luppa-purple/15 text-luppa-purple",
    COMPLETED: "bg-luppa-green/15 text-emerald-800",
    PAUSED: "bg-amber-100 text-amber-800",
    CANCELLED: "bg-gray-100 text-gray-500",
    EXPIRED: "bg-luppa-error/15 text-luppa-error",
};

function goalStatusLabel(goal) {
    return goal.status_label || GOAL_STATUS_PT[goal.status] || goal.status;
}

function formatValue(value, type) {
    if (type === "REVENUE" || type === "AVERAGE_TICKET") return centsToBRL(value);
    if (type === "CONVERSION") return `${(value / 100).toFixed(1)}%`;
    return value?.toString() || "0";
}

function ProgressBar({ pct, size = "md" }) {
    const h = size === "lg" ? "h-3" : "h-2";
    const clamped = Math.min(pct, 100);
    const color = pct >= 100 ? "bg-luppa-green" : pct >= 70 ? "bg-luppa-purple" : pct >= 40 ? "bg-amber-500" : "bg-luppa-error/70";
    return (
        <div className="space-y-1">
            <div className={`w-full bg-border rounded-full ${h}`}>
                <div className={`${h} rounded-full transition-all duration-500 ${color}`} style={{ width: `${clamped}%` }} />
            </div>
            {pct > 100 && (
                <p className="text-xs text-luppa-green font-semibold">{pct}% — acima da meta!</p>
            )}
        </div>
    );
}


export default function GoalDetail() {
    const { tenantSlug, goalId } = useParams();
    const navigate = useNavigate();
    const { hasPermission } = usePermissions();
    const { subscribe } = useRealtimeTenant();
    const [goal, setGoal] = useState(null);
    const [loading, setLoading] = useState(true);
    const [recalcLoading, setRecalcLoading] = useState(false);

    const load = useCallback(async () => {
        setLoading(true);
        try {
            const { data } = await api.get(`/tenants/${tenantSlug}/goals/${goalId}`);
            setGoal(data);
        } catch {
            toast.error("Erro ao carregar meta.");
        } finally {
            setLoading(false);
        }
    }, [tenantSlug, goalId]);

    useEffect(() => { load(); }, [load]);

    // Atualiza em tempo real quando esta meta específica é recalculada
    useEffect(() => {
        const unsub = subscribe("goals.updated", (event) => {
            const updatedId = event?.payload?.goal_id;
            if (!updatedId || updatedId === goalId) {
                api.get(`/tenants/${tenantSlug}/goals/${goalId}`)
                    .then(({ data }) => setGoal(data))
                    .catch(() => {});
            }
        });
        return unsub;
    }, [subscribe, tenantSlug, goalId]);

    const handleRecalculate = async () => {
        setRecalcLoading(true);
        try {
            await api.post(`/tenants/${tenantSlug}/goals/${goalId}/recalculate`);
            toast.success("Meta recalculada.");
            load();
        } catch {
            toast.error("Erro ao recalcular.");
        } finally {
            setRecalcLoading(false);
        }
    };

    const handleCancel = async () => {
        if (!window.confirm("Tem certeza que deseja cancelar esta meta?")) return;
        try {
            await api.patch(`/tenants/${tenantSlug}/goals/${goalId}/status`, { action: "CANCEL" });
            toast.success("Meta cancelada.");
            load();
        } catch {
            toast.error("Erro ao cancelar meta.");
        }
    };

    const canEdit = hasPermission("goals.update");
    const canCancel = hasPermission("goals.cancel");
    const canRecalc = hasPermission("goals.recalculate");

    if (loading) {
        return (
            <div>
                <Skeleton className="h-10 w-64 mb-4" />
                <Skeleton className="h-48 w-full" />
            </div>
        );
    }

    if (!goal) return null;

    const pct = goal.progress_percent || 0;
    const current = formatValue(goal.current_value, goal.type);
    const target = formatValue(goal.target_value, goal.type);

    return (
        <div data-testid="goal-detail">
            <div className="flex items-center gap-3 mb-6">
                <Link to={`/${tenantSlug}/goals`} className="text-muted-foreground hover:text-foreground">
                    <ArrowLeft size={16} strokeWidth={1.5} />
                </Link>
                <PageHeader eyebrow="Meta" title={goal.title} />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Progresso principal */}
                <Card className="border border-border shadow-sm lg:col-span-2">
                    <CardContent className="p-6">
                        <div className="flex items-center justify-between mb-4">
                            <div className="flex gap-2 flex-wrap">
                                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${STATUS_STYLES[goal.status] || "bg-gray-100"}`} data-testid="goal-detail-status">{goalStatusLabel(goal)}</span>
                                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs bg-accent text-foreground/70" data-testid="goal-detail-type">{TYPE_LABELS[goal.type] || goal.type}</span>
                                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs bg-accent text-foreground/70" data-testid="goal-detail-scope">{SCOPE_LABELS[goal.scope] || goal.scope}</span>
                            </div>
                            <div className="flex gap-2">
                                {canEdit && goal.status === "ACTIVE" && (
                                    <Link to={`/${tenantSlug}/goals/${goal.id}/edit`}>
                                        <Button variant="outline" size="sm" data-testid="btn-edit-goal">
                                            <Edit size={13} strokeWidth={1.5} className="mr-1" /> Editar
                                        </Button>
                                    </Link>
                                )}
                                {canRecalc && goal.status === "ACTIVE" && (
                                    <Button variant="outline" size="sm" onClick={handleRecalculate} disabled={recalcLoading} data-testid="btn-recalculate">
                                        <RefreshCw size={13} strokeWidth={1.5} className="mr-1" /> {recalcLoading ? "..." : "Recalcular"}
                                    </Button>
                                )}
                                {canCancel && goal.status === "ACTIVE" && (
                                    <Button variant="outline" size="sm" className="text-luppa-error hover:text-luppa-error" onClick={handleCancel} data-testid="btn-cancel">
                                        <XCircle size={13} strokeWidth={1.5} className="mr-1" /> Cancelar
                                    </Button>
                                )}
                            </div>
                        </div>

                        {/* Progress visual */}
                        <div className="mb-6">
                            <div className="flex justify-between items-end mb-2">
                                <div className="metric-card-wrap">
                                    <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground">Progresso</p>
                                    <span className={`metric-num-lg font-bold tracking-tighter mt-1 text-foreground`} data-testid="progress-pct">{pct}%</span>
                                </div>
                                <div className="text-right">
                                    <p className="text-xs text-muted-foreground">atual / alvo</p>
                                    <p className="font-mono text-lg" data-testid="goal-detail-values"><span className="font-bold">{current}</span> <span className="text-muted-foreground">/ {target}</span></p>
                                </div>
                            </div>
                            <ProgressBar pct={pct} size="lg" />
                        </div>

                        {goal.status === "COMPLETED" && (
                            <div className="flex items-center gap-2 text-luppa-green bg-luppa-green/10 border border-emerald-200 rounded-sm p-3">
                                <CheckCircle size={16} />
                                <p className="text-sm font-medium">Meta atingida em {fmtDate(goal.completed_at)}!</p>
                            </div>
                        )}

                        {goal.description && (
                            <p className="text-sm text-muted-foreground mt-4 pt-4 border-t border-border">{goal.description}</p>
                        )}
                    </CardContent>
                </Card>

                {/* Dados da meta */}
                <Card className="border border-border shadow-sm">
                    <CardContent className="p-6">
                        <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground mb-4">Detalhes</p>
                        <dl className="space-y-3 text-sm">
                            {[
                                { label: "Período", value: `${fmtDate(goal.period_start)} → ${fmtDate(goal.period_end)}` },
                                { label: "Frequência", value: goal.period },
                                { label: "Tipo", value: TYPE_LABELS[goal.type] || goal.type },
                                { label: "Escopo", value: SCOPE_LABELS[goal.scope] || goal.scope },
                                { label: "Criado em", value: fmtDate(goal.created_at) },
                                ...(goal.completed_at ? [{ label: "Concluído em", value: fmtDate(goal.completed_at) }] : []),
                                ...(goal.cancelled_at ? [{ label: "Cancelado em", value: fmtDate(goal.cancelled_at) }] : []),
                            ].map((row) => (
                                <div key={row.label} className="flex justify-between gap-4">
                                    <dt className="text-muted-foreground flex-shrink-0">{row.label}</dt>
                                    <dd className="font-medium text-right">{row.value}</dd>
                                </div>
                            ))}
                        </dl>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
