import React, { useEffect, useState, useCallback } from "react";
import { useParams } from "react-router-dom";
import { Database, Shield, AlertTriangle } from "lucide-react";
import api from "@/lib/api";
import { PageHeader } from "@/components/Common";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { usePermissions } from "@/hooks/usePermissions";

const CATEGORY_PT = { USER_ACCOUNT: "Contas de Usuário", SELLER_PROFILE: "Perfil de Vendedor", CUSTOMER_VISIT: "Visita de Cliente", ATTENDANCE: "Atendimento", SALE: "Venda", FEEDBACK: "Feedback", NOTIFICATION: "Notificação", AUDIT_LOG: "Log de Auditoria", SECURITY_LOG: "Log de Segurança", REPORT_EXPORT: "Exportação de Relatório", BACKUP: "Backup" };
const BASIS_PT = { CONSENT: "Consentimento", CONTRACT: "Contrato", LEGAL_OBLIGATION: "Obrig. Legal", LEGITIMATE_INTEREST: "Interesse Legítimo", REGULAR_EXERCISE_OF_RIGHTS: "Exercício de Direitos" };

export default function DataMapPage() {
    const { tenantSlug } = useParams();
    const { hasFeature } = usePermissions();
    const [records, setRecords] = useState([]);
    const [loading, setLoading] = useState(true);

    const load = useCallback(async () => {
        setLoading(true);
        try {
            const res = await api.get(`/tenants/${tenantSlug}/privacy/data-map`);
            setRecords(Array.isArray(res.data) ? res.data : []);
        } catch {
            toast.error("Erro ao carregar mapa de dados.");
        } finally {
            setLoading(false);
        }
    }, [tenantSlug]);

    useEffect(() => { load(); }, [load]);

    if (!hasFeature("lgpd")) return (
        <div><PageHeader eyebrow="Privacidade" title="Mapa de Dados" />
            <Card className="mt-6 border"><CardContent className="p-10 text-center"><p className="text-sm text-muted-foreground">Módulo LGPD indisponível.</p></CardContent></Card>
        </div>
    );

    return (
        <div data-testid="data-map-page">
            <PageHeader
                eyebrow="Privacidade"
                title="Mapa de Dados Pessoais"
                description="Categorias de dados tratados, finalidades e bases legais."
            />
            <div className="mt-6">
                {loading ? (
                    <div className="space-y-3"><Skeleton className="h-24" /><Skeleton className="h-24" /><Skeleton className="h-24" /></div>
                ) : records.length === 0 ? (
                    <Card className="border border-border shadow-sm">
                        <CardContent className="p-10 text-center">
                            <Database size={28} strokeWidth={1} className="mx-auto mb-2 text-muted-foreground" />
                            <p className="text-sm text-muted-foreground">Nenhum registro no mapa de dados.</p>
                        </CardContent>
                    </Card>
                ) : (
                    <div className="grid gap-3">
                        {records.map(rec => (
                            <Card key={rec.id || rec.data_category} data-testid={`data-record-${rec.data_category}`} className="border border-border shadow-sm">
                                <CardContent className="p-5">
                                    <div className="flex items-start justify-between mb-3">
                                        <div className="flex items-center gap-2">
                                            <Database size={15} strokeWidth={1.5} className="text-muted-foreground flex-shrink-0" />
                                            <div>
                                                <p className="text-sm font-medium">{CATEGORY_PT[rec.data_category] || rec.data_category}</p>
                                                <p className="text-xs text-muted-foreground">{rec.data_subject_type}</p>
                                            </div>
                                        </div>
                                        <div className="flex items-center gap-1.5">
                                            {rec.contains_sensitive_data && (
                                                <span className="flex items-center gap-1 text-xs bg-luppa-warning/15 text-luppa-warning px-2 py-0.5 rounded-full">
                                                    <AlertTriangle size={10} />Sensível
                                                </span>
                                            )}
                                            <span className="text-xs bg-luppa-purple/10 text-luppa-purple px-2 py-0.5 rounded-full">
                                                {BASIS_PT[rec.legal_basis] || rec.legal_basis}
                                            </span>
                                        </div>
                                    </div>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                        <div>
                                            <p className="text-xs text-muted-foreground mb-1">Finalidade</p>
                                            <p className="text-xs">{rec.purpose}</p>
                                        </div>
                                        <div>
                                            <p className="text-xs text-muted-foreground mb-1">Sistemas</p>
                                            <p className="text-xs">{(rec.systems || []).join(", ") || "—"}</p>
                                        </div>
                                        <div>
                                            <p className="text-xs text-muted-foreground mb-1">Compartilhamento</p>
                                            <p className="text-xs">{rec.sharing_description || "—"}</p>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
}
