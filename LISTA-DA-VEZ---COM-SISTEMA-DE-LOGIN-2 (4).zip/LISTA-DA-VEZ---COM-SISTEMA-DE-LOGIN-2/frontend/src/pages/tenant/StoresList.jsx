import React, { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import api, { extractError } from "@/lib/api";
import { PageHeader, EmptyState } from "@/components/Common";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
    Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
    Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
    AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
    AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Plus, Pencil, PowerOff, Power } from "lucide-react";
import { toast } from "sonner";

const EMPTY_FORM = { name: "", code: "", city: "", state: "", country: "Brasil", timezone: "America/Sao_Paulo", address: "", phone: "" };

export default function StoresList() {
    const { tenantSlug } = useParams();
    const [stores, setStores] = useState([]);
    const [loading, setLoading] = useState(true);
    const [editTarget, setEditTarget] = useState(null);

    const load = async () => {
        setLoading(true);
        const { data } = await api.get(`/tenants/${tenantSlug}/stores`);
        setStores(data);
        setLoading(false);
    };

    useEffect(() => { load(); }, [tenantSlug]);

    const toggleStatus = async (store) => {
        const newStatus = store.status === "ACTIVE" ? "INACTIVE" : "ACTIVE";
        try {
            await api.patch(`/tenants/${tenantSlug}/stores/${store.id}/status`, { status: newStatus });
            toast.success(`Unidade ${newStatus === "ACTIVE" ? "ativada" : "inativada"}.`);
            load();
        } catch (e) { toast.error(extractError(e, "Erro ao atualizar status")); }
    };

    return (
        <div>
            <PageHeader eyebrow="Unidades" title="Lista de Unidades" description="Filiais físicas vinculadas à empresa.">
                <Link to={`/${tenantSlug}/stores/new`}>
                    <Button data-testid="new-store-button" className="gap-2">
                        <Plus size={16} strokeWidth={1.5} /> Nova unidade
                    </Button>
                </Link>
            </PageHeader>

            {loading ? (
                <p className="text-sm text-muted-foreground">Carregando…</p>
            ) : stores.length === 0 ? (
                <EmptyState
                    title="Sem unidades cadastradas"
                    description="Adicione a primeira unidade física para começar."
                    action={
                        <Link to={`/${tenantSlug}/stores/new`}>
                            <Button data-testid="empty-new-store-button">Nova unidade</Button>
                        </Link>
                    }
                />
            ) : (
                <Card className="border border-border shadow-sm">
                    <CardContent className="p-0">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Nome</TableHead>
                                    <TableHead>Código</TableHead>
                                    <TableHead>Cidade / UF</TableHead>
                                    <TableHead>Status</TableHead>
                                    <TableHead className="text-right">Ações</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {stores.map((s) => (
                                    <TableRow key={s.id} data-testid={`store-row-${s.code}`}>
                                        <TableCell className="font-medium">{s.name}</TableCell>
                                        <TableCell className="font-mono text-xs">{s.code}</TableCell>
                                        <TableCell>{[s.city, s.state].filter(Boolean).join(" / ") || "—"}</TableCell>
                                        <TableCell>
                                            <Badge variant={s.status === "ACTIVE" ? "default" : "outline"}>{s.status === "ACTIVE" ? "Ativo" : "Inativo"}</Badge>
                                        </TableCell>
                                        <TableCell className="text-right">
                                            <div className="flex justify-end gap-1">
                                                <Button size="sm" variant="ghost" onClick={() => setEditTarget(s)} data-testid={`edit-store-${s.code}`}>
                                                    <Pencil size={15} />
                                                </Button>
                                                <AlertDialog>
                                                    <AlertDialogTrigger asChild>
                                                        <Button size="sm" variant="ghost" data-testid={`toggle-store-${s.code}`}>
                                                            {s.status === "ACTIVE" ? <PowerOff size={15} className="text-luppa-error" /> : <Power size={15} className="text-luppa-green" />}
                                                        </Button>
                                                    </AlertDialogTrigger>
                                                    <AlertDialogContent>
                                                        <AlertDialogHeader>
                                                            <AlertDialogTitle>{s.status === "ACTIVE" ? "Inativar unidade?" : "Ativar unidade?"}</AlertDialogTitle>
                                                            <AlertDialogDescription>
                                                                {s.status === "ACTIVE"
                                                                    ? "A unidade ficará inativa e não aparecerá nas operações."
                                                                    : "A unidade voltará a estar disponível nas operações."}
                                                            </AlertDialogDescription>
                                                        </AlertDialogHeader>
                                                        <AlertDialogFooter>
                                                            <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                                            <AlertDialogAction onClick={() => toggleStatus(s)} data-testid={`confirm-toggle-store-${s.code}`}>
                                                                Confirmar
                                                            </AlertDialogAction>
                                                        </AlertDialogFooter>
                                                    </AlertDialogContent>
                                                </AlertDialog>
                                            </div>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>
            )}

            {editTarget && (
                <EditStoreDialog
                    tenantSlug={tenantSlug} store={editTarget}
                    onClose={() => setEditTarget(null)} onSaved={() => { setEditTarget(null); load(); }}
                />
            )}
        </div>
    );
}

function EditStoreDialog({ tenantSlug, store, onClose, onSaved }) {
    const [form, setForm] = useState({
        name: store.name || "",
        code: store.code || "",
        city: store.city || "",
        state: store.state || "",
        country: store.country || "Brasil",
        timezone: store.timezone || "America/Sao_Paulo",
        address: store.address || "",
        phone: store.phone || "",
    });
    const [saving, setSaving] = useState(false);
    const setF = (k, v) => setForm((p) => ({ ...p, [k]: v }));

    const submit = async (e) => {
        e.preventDefault();
        setSaving(true);
        try {
            await api.put(`/tenants/${tenantSlug}/stores/${store.id}`, form);
            toast.success("Unidade atualizada.");
            onSaved();
        } catch (err) {
            toast.error(extractError(err, "Erro ao atualizar unidade"));
        } finally { setSaving(false); }
    };

    return (
        <Dialog open onOpenChange={onClose}>
            <DialogContent className="max-w-2xl">
                <DialogHeader>
                    <DialogTitle>Editar unidade</DialogTitle>
                    <DialogDescription>Atualize os dados da unidade {store.name}.</DialogDescription>
                </DialogHeader>
                <form onSubmit={submit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Field label="Nome">
                        <Input value={form.name} onChange={(e) => setF("name", e.target.value)} required data-testid="edit-store-name" />
                    </Field>
                    <Field label="Código">
                        <Input value={form.code} onChange={(e) => setF("code", e.target.value.toUpperCase())} required data-testid="edit-store-code" />
                    </Field>
                    <Field label="Cidade">
                        <Input value={form.city} onChange={(e) => setF("city", e.target.value)} data-testid="edit-store-city" />
                    </Field>
                    <Field label="UF">
                        <Input value={form.state} onChange={(e) => setF("state", e.target.value.toUpperCase())} maxLength={2} data-testid="edit-store-state" />
                    </Field>
                    <Field label="País">
                        <Input value={form.country} onChange={(e) => setF("country", e.target.value)} data-testid="edit-store-country" />
                    </Field>
                    <Field label="Fuso horário">
                        <Input value={form.timezone} onChange={(e) => setF("timezone", e.target.value)} data-testid="edit-store-timezone" />
                    </Field>
                    <Field label="Endereço">
                        <Input value={form.address} onChange={(e) => setF("address", e.target.value)} data-testid="edit-store-address" />
                    </Field>
                    <Field label="Telefone">
                        <Input value={form.phone} onChange={(e) => setF("phone", e.target.value)} data-testid="edit-store-phone" />
                    </Field>
                    <div className="md:col-span-2">
                        <DialogFooter>
                            <Button type="button" variant="outline" onClick={onClose}>Cancelar</Button>
                            <Button type="submit" disabled={saving} data-testid="save-store-submit">
                                {saving ? "Salvando…" : "Salvar alterações"}
                            </Button>
                        </DialogFooter>
                    </div>
                </form>
            </DialogContent>
        </Dialog>
    );
}

function Field({ label, children }) {
    return (
        <div className="space-y-2">
            <Label>{label}</Label>
            {children}
        </div>
    );
}
