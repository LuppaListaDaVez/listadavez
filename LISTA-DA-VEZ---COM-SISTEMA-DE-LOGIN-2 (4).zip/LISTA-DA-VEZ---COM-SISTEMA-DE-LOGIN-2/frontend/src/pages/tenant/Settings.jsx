import React, { useEffect, useState } from "react";
import { useTenant } from "@/context/TenantContext";
import { PageHeader } from "@/components/Common";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Lock, Building2, Hash, Activity } from "lucide-react";
import api, { extractError } from "@/lib/api";
import { toast } from "sonner";

const STATUS_LABEL = {
    ACTIVE: "Ativo",
    TRIAL: "Período de Teste",
    SUSPENDED: "Suspenso",
    CANCELLED: "Cancelado",
    PENDING_ACTIVATION: "Aguardando ativação",
};

const STATUS_VARIANT = {
    ACTIVE: "default",
    TRIAL: "secondary",
    SUSPENDED: "outline",
    CANCELLED: "destructive",
    PENDING_ACTIVATION: "secondary",
};

export default function Settings() {
    const { context } = useTenant();
    const tenant = context?.tenant;
    const role = context?.membership?.role;
    const tenantSlug = tenant?.slug;
    const [storeSettings, setStoreSettings] = useState(null);
    const [defaultStoreId, setDefaultStoreId] = useState(null);
    const canEditQueueSettings = ["TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER"].includes(role);

    useEffect(() => {
        let active = true;
        async function loadPreferenceSetting() {
            if (!tenantSlug || !canEditQueueSettings) return;
            try {
                const { data: stores } = await api.get(`/tenants/${tenantSlug}/stores`);
                const store = stores?.[0];
                if (!store?.id || !active) return;
                setDefaultStoreId(store.id);
                const { data } = await api.get(`/tenants/${tenantSlug}/stores/${store.id}/settings`);
                if (active) setStoreSettings(data);
            } catch (e) {
                if (active) toast.error(extractError(e, "Erro ao carregar configurações de preferência"));
            }
        }
        loadPreferenceSetting();
        return () => { active = false; };
    }, [tenantSlug, canEditQueueSettings]);

    const setPreferenceEnabled = async (value) => {
        if (!defaultStoreId || !storeSettings) return;
        const next = {
            ...storeSettings,
            queue_settings: { ...(storeSettings.queue_settings || {}), preference_enabled: value },
        };
        setStoreSettings(next);
        try {
            const { data } = await api.put(`/tenants/${tenantSlug}/stores/${defaultStoreId}/settings`, {
                queue_settings: next.queue_settings,
            });
            setStoreSettings(data);
            toast.success(value ? "Atendimento por preferência habilitado." : "Atendimento por preferência desabilitado.");
        } catch (e) {
            toast.error(extractError(e, "Erro ao salvar preferência"));
        }
    };

    return (
        <div>
            <PageHeader eyebrow="Empresa" title="Configurações" description="Informações e configurações da empresa." />

            <div className="max-w-3xl space-y-6">
                <Card className="border border-border shadow-sm">
                    <CardContent className="p-6 space-y-5">
                        <h3 className="font-sans text-base font-semibold">Informações da empresa</h3>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                            <InfoRow icon={Building2} label="Nome" value={tenant?.name || "—"} testId="settings-tenant-name" />
                            <InfoRow icon={Hash} label="Identificador (slug)" value={tenant?.slug ? `/${tenant.slug}` : "—"} mono testId="settings-tenant-slug" />
                            <div className="space-y-1.5" data-testid="settings-tenant-status">
                                <div className="flex items-center gap-1.5 text-xs text-muted-foreground font-medium uppercase tracking-wide">
                                    <Activity size={11} />
                                    Status
                                </div>
                                <Badge variant={STATUS_VARIANT[tenant?.status] || "secondary"}>
                                    {STATUS_LABEL[tenant?.status] || tenant?.status || "—"}
                                </Badge>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                {canEditQueueSettings && (
                    <Card className="border border-border shadow-sm">
                        <CardContent className="p-6 space-y-4">
                            <div>
                                <h3 className="font-sans text-base font-semibold">Atendimento por preferência</h3>
                                <p className="text-sm text-muted-foreground mt-1">Controle rápido da unidade padrão. Ajustes completos continuam disponíveis em Configurações da unidade.</p>
                            </div>
                            <div className="flex items-center justify-between gap-4 rounded-md border border-border p-4">
                                <Label htmlFor="settings-preference-enabled" className="text-sm font-medium">Atendimento por preferência habilitado</Label>
                                <Switch
                                    id="settings-preference-enabled"
                                    checked={(storeSettings?.queue_settings?.preference_enabled ?? true) !== false}
                                    onCheckedChange={setPreferenceEnabled}
                                    disabled={!storeSettings}
                                    data-testid="q-preference-enabled"
                                />
                            </div>
                        </CardContent>
                    </Card>
                )}

                <Card className="border border-border/60 shadow-sm bg-muted/30">
                    <CardContent className="p-6">
                        <div className="flex items-start gap-3">
                            <div className="mt-0.5 rounded-full bg-muted p-2 flex-shrink-0">
                                <Lock size={14} className="text-muted-foreground" />
                            </div>
                            <div>
                                <p className="font-medium text-sm">Configurações avançadas</p>
                                <p className="text-sm text-muted-foreground mt-1 leading-relaxed">
                                    As configurações avançadas desta empresa são gerenciadas pelo administrador da plataforma.
                                    Entre em contato com o suporte caso precise alterar parâmetros técnicos.
                                </p>
                            </div>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}

function InfoRow({ icon: Icon, label, value, mono = false, testId }) {
    return (
        <div className="space-y-1.5" data-testid={testId}>
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground font-medium uppercase tracking-wide">
                <Icon size={11} />
                {label}
            </div>
            <p className={`text-sm font-medium ${mono ? "font-mono" : ""}`}>{value}</p>
        </div>
    );
}
