import React, { useState, useEffect } from "react";
import { useNavigate, useParams, useSearchParams, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useAuth } from "@/context/AuthContext";
import api, { extractError } from "@/lib/api";
import { AlertCircle } from "lucide-react";

export default function TenantLogin() {
    const { tenantSlug } = useParams();
    const [searchParams] = useSearchParams();
    const { loginTenant } = useAuth();
    const nav = useNavigate();
    const [tenant, setTenant] = useState(null);
    const [notFound, setNotFound] = useState(false);
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [err, setErr] = useState(searchParams.get("google_error") || null);
    const [loading, setLoading] = useState(false);

    const reason = searchParams.get("reason");

    // REMINDER: DO NOT HARDCODE THE URL, OR ADD ANY FALLBACKS OR REDIRECT URLS, THIS BREAKS THE AUTH
    const handleGoogleLogin = () => {
        const redirectUrl = window.location.origin + `/${tenantSlug}/auth/callback`;
        window.location.href = `https://auth.emergentagent.com/?redirect=${encodeURIComponent(redirectUrl)}`;
    };

    useEffect(() => {
        (async () => {
            try {
                const { data } = await api.get(`/tenants/${tenantSlug}/public`);
                setTenant(data);
            } catch (e) {
                if (e?.response?.status === 404) setNotFound(true);
                else setTenant({ name: tenantSlug, slug: tenantSlug });
            }
        })();
    }, [tenantSlug]);

    const submit = async (e) => {
        e.preventDefault();
        setErr(null);
        setLoading(true);
        try {
            await loginTenant(tenantSlug, email, password);
            nav(`/${tenantSlug}/dashboard`);
        } catch (e) {
            const errData = e?.response?.data?.detail;
            const errCode = typeof errData === "object" ? errData?.error : null;
            if (errCode === "USE_TENANT_LOGIN") {
                setErr("Use esta página para entrar. O acesso Super Admin é em outra área.");
            } else if (e?.response?.status === 429) {
                const detail = e?.response?.data?.detail;
                const retry = (typeof detail === "object" ? detail?.retry_after_seconds : null) || 60;
                setErr(`Muitas tentativas. Aguarde ${retry}s e tente novamente.`);
            } else {
                setErr(extractError(e, "Credenciais inválidas."));
            }
            setLoading(false);
        }
    };

    if (notFound) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-luppa-bg dark:bg-luppa-dark-bg">
                <div className="max-w-md text-center space-y-3 px-6">
                    <p className="micro-label">Erro 404</p>
                    <h1 className="text-4xl font-semibold tracking-[-0.03em]">Empresa não encontrada.</h1>
                    <p className="text-sm text-muted-foreground">Verifique o endereço e tente novamente.</p>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen flex bg-luppa-bg dark:bg-luppa-dark-bg">
            {/* ── Painel esquerdo ── */}
            <div className="flex-1 flex flex-col justify-center px-6 sm:px-10 py-12 max-w-lg mx-auto w-full">
                {/* Logo */}
                <div className="mb-10">
                    <img
                        src="/luppa-logo.webp"
                        alt="Luppa"
                        style={{ height: 28, mixBlendMode: "darken" }}
                        draggable="false"
                    />
                </div>

                {/* Heading */}
                <div className="mb-8">
                    <h1 className="text-3xl sm:text-4xl font-semibold tracking-[-0.03em] leading-tight">
                        {tenant?.name || "Bem-vindo de volta"}
                    </h1>
                    <p className="text-base text-muted-foreground mt-2">
                        Entre para gerenciar sua operação.
                    </p>
                </div>

                {/* Alertas */}
                {reason === "session_mismatch" && (
                    <Alert className="mb-6 rounded-[12px] border-luppa-border bg-luppa-surface-alt">
                        <AlertDescription data-testid="session-mismatch-notice">
                            Por segurança, faça login novamente para acessar esta empresa.
                        </AlertDescription>
                    </Alert>
                )}
                {err && (
                    <Alert variant="destructive" className="mb-6 rounded-[12px]">
                        <AlertCircle size={14} className="mt-0.5 flex-shrink-0" />
                        <AlertDescription data-testid="tenant-login-error">{err}</AlertDescription>
                    </Alert>
                )}

                {/* Formulário */}
                <form onSubmit={submit} className="space-y-4">
                    <div className="space-y-1.5">
                        <Label htmlFor="email" className="text-sm font-medium">E-mail</Label>
                        <Input
                            id="email"
                            type="email"
                            autoComplete="email"
                            placeholder="voce@empresa.com"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            data-testid="tenant-login-email-input"
                            required
                        />
                    </div>
                    <div className="space-y-1.5">
                        <div className="flex items-center justify-between">
                            <Label htmlFor="password" className="text-sm font-medium">Senha</Label>
                            <Link
                                to={`/${tenantSlug}/forgot-password`}
                                className="text-xs text-muted-foreground hover:text-luppa-green transition-colors"
                                data-testid="login-forgot-password-link"
                            >
                                Esqueceu a senha?
                            </Link>
                        </div>
                        <Input
                            id="password"
                            type="password"
                            autoComplete="current-password"
                            placeholder="••••••••"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            data-testid="tenant-login-password-input"
                            required
                        />
                    </div>

                    <Button
                        type="submit"
                        className="w-full h-11 text-base mt-2"
                        disabled={loading}
                        data-testid="tenant-login-submit-button"
                    >
                        {loading ? (
                            <span className="flex items-center gap-2">
                                <span className="h-4 w-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                                Entrando…
                            </span>
                        ) : "Entrar"}
                    </Button>
                </form>

                {/* Divisor */}
                <div className="relative my-5">
                    <div className="absolute inset-0 flex items-center">
                        <span className="w-full border-t border-luppa-border dark:border-white/10" />
                    </div>
                    <div className="relative flex justify-center">
                        <span className="bg-luppa-bg dark:bg-luppa-dark-bg px-3 text-xs text-muted-foreground uppercase tracking-wider">
                            ou
                        </span>
                    </div>
                </div>

                {/* Google */}
                <Button
                    type="button"
                    variant="outline"
                    className="w-full h-11 gap-3"
                    onClick={handleGoogleLogin}
                    data-testid="tenant-google-login-button"
                >
                    <svg viewBox="0 0 24 24" className="w-4 h-4 flex-shrink-0" aria-hidden="true">
                        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/>
                        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                    </svg>
                    Continuar com Google
                </Button>

                {/* Demo hint removido — credenciais não exibidas na interface */}
            </div>

            {/* ── Painel verde direito ── */}
            <div className="hidden lg:flex flex-col justify-between flex-1 max-w-[520px] bg-luppa-green p-12 relative overflow-hidden">
                <div className="absolute inset-0 opacity-10" style={{
                    backgroundImage: "radial-gradient(circle at 30% 40%, rgba(255,255,255,0.4) 0%, transparent 60%), radial-gradient(circle at 80% 80%, rgba(255,255,255,0.2) 0%, transparent 50%)"
                }} />
                <div className="relative z-10">
                    <div className="inline-flex items-center gap-2 bg-white/10 border border-white/20 rounded-[8px] px-3 py-1.5 text-white text-sm">
                        <span className="h-1.5 w-1.5 rounded-full bg-luppa-green-light animate-pulse" />
                        Plataforma ao vivo
                    </div>
                </div>
                <div className="relative z-10 space-y-4">
                    <h2 className="text-3xl font-semibold text-white leading-tight tracking-[-0.02em]">
                        Gerencie sua fila de vendas com eficiência.
                    </h2>
                    <p className="text-white/70 text-base leading-relaxed">
                        Controle atendimentos, acompanhe metas e impulsione o desempenho do seu time em tempo real.
                    </p>
                </div>
                <div className="relative z-10 flex items-center gap-3 bg-white/10 border border-white/15 rounded-[16px] px-4 py-3">
                    <div className="h-8 w-8 rounded-full bg-white/20 flex items-center justify-center overflow-hidden flex-shrink-0">
                        <img src="/luppa-logo.webp" alt="Luppa" style={{ height: 20, filter: "brightness(0) invert(1)" }} draggable="false" />
                    </div>
                    <div>
                        <p className="text-white text-sm font-medium">Luppa</p>
                        <p className="text-white/60 text-xs">Gestão inteligente de equipes</p>
                    </div>
                </div>
            </div>
        </div>
    );
}
