import React, { useState, useEffect, useCallback } from "react";
import { useParams, Link } from "react-router-dom";
import api from "@/lib/api";
import { centsToBRL } from "@/lib/money";
import { PageHeader } from "@/components/Common";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
    Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Plus, RefreshCw, Target } from "lucide-react";
import { toast } from "sonner";
import { usePermissions } from "@/hooks/usePermissions";
import { GOAL_STATUS_PT, GOAL_TYPE_PT, GOAL_SCOPE_PT, fmtDate } from "@/lib/i18n";
import { useRealtimeTenant } from "@/context/RealtimeTenantContext";

const TYPE_LABELS = GOAL_TYPE_PT;
const SCOPE_LABELS = GOAL_SCOPE_PT;
const SCOPE_BADGE_CLASS = {
    TENANT: "bg-violet-100 text-violet-700",
    STORE:  "bg-luppa-purple/15 text-luppa-purple",
    TEAM:   "bg-amber-100 text-amber-700",
    SELLER: "bg-luppa-green/10 text-luppa-green",
};
const STATUS_STYLES = {
    SCHEDULED: "bg-sky-100 text-sky-800",
    ACTIVE: "bg-luppa-purple/15 text-luppa-purple",
    COMPLETED: "bg-luppa-green/15 text-emerald-800",
    PAUSED: "bg-amber-100 text-amber-800",
    CANCELLED: "bg-gray-100 text-gray-500",
    EXPIRED: "bg-luppa-error/15 text-luppa-error",
};

function goalStatusLabel(goal) {
    return goal.status_label || GOAL_STATUS_PT[goal.status] || goal.status;
}

function formatTarget(goal) {
    const { type, target_value, current_value } = goal;
    if (type === "REVENUE" || type === "AVERAGE_TICKET") {
        return { target: centsToBRL(target_value), current: centsToBRL(current_value) };
    }
    if (type === "CONVERSION") {
        return {
            target: `${(target_value / 100).toFixed(1)}%`,
            current: `${(current_value / 100).toFixed(1)}%`,
        };
    }
    return { target: target_value, current: current_value };
}

function ProgressBar({ pct }) {
    const clamped = Math.min(pct, 100);
    const color = pct >= 100 ? "bg-luppa-green" : pct >= 70 ? "bg-luppa-purple" : pct >= 40 ? "bg-amber-500" : "bg-luppa-error/70";
    return (
        <div className="flex items-center gap-2">
            <div className="flex-1 bg-border rounded-full h-1.5">
                <div className={`h-1.5 rounded-full transition-all ${color}`} style={{ width: `${clamped}%` }} />
            </div>
            <span className={`text-xs font-semibold tabular-nums whitespace-nowrap ${pct >= 100 ? "text-luppa-green" : "text-muted-foreground"}`}>
                {pct}%
            </span>
        </div>
    );
}

export default function GoalsList() {
    const { tenantSlug } = useParams();
    const { hasPermission } = usePermissions();
    const { subscribe } = useRealtimeTenant();
    const [goals, setGoals] = useState([]);
    const [loading, setLoading] = useState(true);
    const [statusFilter, setStatusFilter] = useState("__all__");

    const load = useCallback(async () => {
        setLoading(true);
        try {
            const params = new URLSearchParams();
            if (statusFilter && statusFilter !== "__all__") params.set("status", statusFilter);
            const { data } = await api.get(`/tenants/${tenantSlug}/goals?${params}`);
            setGoals(data);
        } catch {
            toast.error("Erro ao carregar metas.");
        } finally {
            setLoading(false);
        }
    }, [tenantSlug, statusFilter]);

    useEffect(() => { load(); }, [load]);

    // Auto-atualiza em tempo real quando qualquer meta é recalculada
    useEffect(() => {
        const unsub = subscribe("goals.updated", () => {
            // Recarrega silenciosamente (sem setLoading) para não piscar a UI
            const params = new URLSearchParams();
            if (statusFilter && statusFilter !== "__all__") params.set("status", statusFilter);
            api.get(`/tenants/${tenantSlug}/goals?${params}`)
                .then(({ data }) => setGoals(data))
                .catch(() => {});
        });
        return unsub;
    }, [subscribe, tenantSlug, statusFilter]);

    const handleRecalculate = async (goalId) => {
        try {
            await api.post(`/tenants/${tenantSlug}/goals/${goalId}/recalculate`);
            toast.success("Meta recalculada com sucesso.");
            load();
        } catch {
            toast.error("Erro ao recalcular meta.");
        }
    };

    const handleCancel = async (goalId) => {
        if (!window.confirm("Tem certeza que deseja cancelar esta meta?")) return;
        try {
            await api.patch(`/tenants/${tenantSlug}/goals/${goalId}/status`, { action: "CANCEL" });
            toast.success("Meta cancelada.");
            load();
        } catch {
            toast.error("Erro ao cancelar meta.");
        }
    };

    const canCreate = hasPermission("goals.create");
    const canEdit = hasPermission("goals.update");
    const canCancel = hasPermission("goals.cancel");
    const canRecalc = hasPermission("goals.recalculate");

    const active = goals.filter((g) => g.status === "ACTIVE" || g.status === "SCHEDULED");
    const completed = goals.filter((g) => g.status === "COMPLETED");
    // avgProgress usa a lista visível (não apenas ACTIVE) para refletir o filtro atual
    const avgProgress = goals.length ? Math.round(goals.reduce((s, g) => s + Math.min(g.progress_percent, 100), 0) / goals.length) : 0;

    return (
        <div data-testid="goals-page">
            <div className="flex items-start justify-between mb-6">
                <PageHeader eyebrow="Metas" title="Metas Comerciais" description="Acompanhe o progresso das metas por vendedor, equipe ou unidade." />
                {canCreate && (
                    <Link to={`/${tenantSlug}/goals/new`}>
                        <Button size="sm" data-testid="btn-create-goal">
                            <Plus size={14} className="mr-1.5" /> Nova Meta
                        </Button>
                    </Link>
                )}
            </div>

            {/* KPI cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
                {[
                    { label: "Metas ativas", value: active.length, testId: "kpi-active" },
                    { label: "Concluídas", value: completed.length, testId: "kpi-completed" },
                    { label: "Progresso médio", value: `${avgProgress}%`, testId: "kpi-avg-progress" },
                    { label: "Total", value: goals.length, testId: "kpi-total" },
                ].map((k) => (
                    <div key={k.label} className="border border-border/60 rounded-md p-4 bg-card">
                        <p className="text-xs uppercase tracking-[0.1em] text-muted-foreground">{k.label}</p>
                        <p className="font-bold text-2xl mt-1" data-testid={k.testId}>{k.value}</p>
                    </div>
                ))}
            </div>

            <div className="flex items-center justify-between mb-4">
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="h-8 text-sm w-40" data-testid="filter-status">
                        <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="__all__">Todos os status</SelectItem>
                        <SelectItem value="SCHEDULED">Agendada</SelectItem>
                        <SelectItem value="ACTIVE">Em andamento</SelectItem>
                        <SelectItem value="COMPLETED">Atingida</SelectItem>
                        <SelectItem value="EXPIRED">Encerrada sem atingir</SelectItem>
                        <SelectItem value="PAUSED">Pausada</SelectItem>
                        <SelectItem value="CANCELLED">Canceladas</SelectItem>
                    </SelectContent>
                </Select>
                <Button variant="outline" size="sm" onClick={load} data-testid="btn-refresh">
                    <RefreshCw size={13} strokeWidth={1.5} className="mr-1.5" /> Atualizar
                </Button>
            </div>

            <div className="border border-border/60 rounded-md bg-card overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm" data-testid="table-goals">
                        <thead>
                            <tr className="border-b border-border bg-muted/40">
                                {["Título", "Tipo", "Escopo", "Período", "Valor Alvo", "Progresso", "Status", "Ações"].map((h) => (
                                    <th key={h} className="text-left px-4 py-3 text-xs font-medium uppercase tracking-[0.08em] text-muted-foreground whitespace-nowrap">{h}</th>
                                ))}
                            </tr>
                        </thead>
                        <tbody>
                            {loading ? (
                                Array.from({ length: 4 }).map((_, i) => (
                                    <tr key={i} className="border-b border-border">
                                        {Array.from({ length: 8 }).map((_, j) => (
                                            <td key={j} className="px-4 py-3"><Skeleton className="h-4 w-full" /></td>
                                        ))}
                                    </tr>
                                ))
                            ) : goals.length === 0 ? (
                                <tr>
                                    <td colSpan={8} className="text-center py-16">
                                        <div className="flex flex-col items-center gap-2 text-muted-foreground">
                                            <Target size={32} strokeWidth={1} />
                                            <p className="text-sm">Nenhuma meta encontrada.</p>
                                            {canCreate && (
                                                <Link to={`/${tenantSlug}/goals/new`}>
                                                    <Button size="sm" variant="outline" className="mt-1">Criar primeira meta</Button>
                                                </Link>
                                            )}
                                        </div>
                                    </td>
                                </tr>
                            ) : (
                                goals.map((g) => {
                                    const { target, current } = formatTarget(g);
                                    return (
                                        <tr key={g.id} className="border-b border-border hover:bg-muted/30 transition-colors">
                                            <td className="px-4 py-3 font-medium max-w-[180px]">
                                                <Link to={`/${tenantSlug}/goals/${g.id}`} className="hover:underline" data-testid={`goal-title-${g.id}`}>{g.title}</Link>
                                            </td>
                                            <td className="px-4 py-3 text-muted-foreground whitespace-nowrap" data-testid={`goal-type-${g.id}`}>{TYPE_LABELS[g.type] || g.type}</td>
                                            <td className="px-4 py-3 text-muted-foreground whitespace-nowrap">
                                                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${SCOPE_BADGE_CLASS[g.scope] || "bg-gray-100 text-gray-600"}`} data-testid={`goal-scope-${g.id}`}>
                                                    {SCOPE_LABELS[g.scope] || g.scope}
                                                </span>
                                            </td>
                                            <td className="px-4 py-3 text-muted-foreground whitespace-nowrap text-xs" data-testid={`goal-period-${g.id}`}>
                                                {fmtDate(g.period_start)} → {fmtDate(g.period_end)}
                                            </td>
                                            <td className="px-4 py-3 font-mono whitespace-nowrap" data-testid={`goal-values-${g.id}`}>
                                                <span className="text-muted-foreground">{current}</span>
                                                <span className="text-muted-foreground mx-1">/</span>
                                                <span className="font-semibold">{target}</span>
                                            </td>
                                            <td className="px-4 py-3 min-w-[120px]">
                                                <div className="space-y-1">
                                                    <ProgressBar pct={g.progress_percent} />
                                                    <p className="text-xs font-mono text-muted-foreground" data-testid={`goal-progress-${g.id}`}>{g.progress_percent}%</p>
                                                </div>
                                            </td>
                                            <td className="px-4 py-3">
                                                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${STATUS_STYLES[g.status] || "bg-gray-100"}`} data-testid={`goal-status-${g.id}`}>{goalStatusLabel(g)}</span>
                                            </td>
                                            <td className="px-4 py-3">
                                                <div className="flex gap-1.5">
                                                    <Link to={`/${tenantSlug}/goals/${g.id}`}>
                                                        <Button variant="ghost" size="sm" className="h-7 px-2 text-xs" data-testid={`goal-view-${g.id}`}>Ver</Button>
                                                    </Link>
                                                    {canRecalc && g.status === "ACTIVE" && (
                                                        <Button variant="ghost" size="sm" className="h-7 px-2 text-xs" onClick={() => handleRecalculate(g.id)} data-testid={`goal-recalculate-${g.id}`}>Recalc.</Button>
                                                    )}
                                                    {canCancel && g.status === "ACTIVE" && (
                                                        <Button variant="ghost" size="sm" className="h-7 px-2 text-xs text-luppa-error" onClick={() => handleCancel(g.id)} data-testid={`goal-cancel-${g.id}`}>Cancelar</Button>
                                                    )}
                                                </div>
                                            </td>
                                        </tr>
                                    );
                                })
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}
