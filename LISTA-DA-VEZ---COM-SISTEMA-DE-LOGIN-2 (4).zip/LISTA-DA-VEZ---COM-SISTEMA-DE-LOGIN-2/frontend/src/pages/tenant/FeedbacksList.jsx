import { useState, useEffect, useCallback } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import {
    ThumbsUp, AlertTriangle, MessageSquare, ClipboardList,
    Plus, Filter, CheckCircle, Clock, ChevronRight,
} from "lucide-react";
import { toast } from "sonner";
import api, { extractError } from "@/lib/api";
import { usePermissions } from "@/hooks/usePermissions";
import { fmtDate } from "@/lib/i18n";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const TYPE_CONFIG = {
    POSITIVE: { label: "Positivo", icon: ThumbsUp, className: "bg-luppa-green/10 text-luppa-green border-emerald-200" },
    CONSTRUCTIVE: { label: "Construtivo", icon: MessageSquare, className: "bg-luppa-purple/10 text-luppa-purple border-luppa-purple/25" },
    WARNING: { label: "Aviso", icon: AlertTriangle, className: "bg-amber-50 text-amber-700 border-amber-200" },
    ACTION_PLAN: { label: "Plano de Ação", icon: ClipboardList, className: "bg-luppa-purple/10 text-luppa-purple border-luppa-purple/25" },
};

const AP_STATUS = {
    PENDING: { label: "Pendente", className: "bg-slate-100 text-slate-600" },
    IN_PROGRESS: { label: "Em andamento", className: "bg-luppa-purple/15 text-luppa-purple" },
    COMPLETED: { label: "Concluído", className: "bg-luppa-green/15 text-luppa-green" },
};

export default function FeedbacksList() {
    const { tenantSlug } = useParams();
    const nav = useNavigate();
    const { hasPermission, hasFeature, role } = usePermissions();
    const [feedbacks, setFeedbacks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [typeFilter, setTypeFilter] = useState("ALL");
    const [ackFilter, setAckFilter] = useState("ALL");

    const isSeller = role === "SELLER";
    const canCreate = hasPermission("feedbacks.create");

    const loadFeedbacks = useCallback(async () => {
        try {
            const params = {};
            if (typeFilter !== "ALL") params.type = typeFilter;
            if (ackFilter === "UNREAD") params.is_acknowledged = false;
            if (ackFilter === "READ") params.is_acknowledged = true;
            const res = await api.get(`/tenants/${tenantSlug}/feedbacks`, { params });
            // P0: resposta paginada {items: [...], pagination: {...}}
            const raw = Array.isArray(res.data) ? res.data : (res.data.items || []);
            setFeedbacks(raw);
        } catch (e) {
            toast.error(extractError(e));
        } finally {
            setLoading(false);
        }
    }, [tenantSlug, typeFilter, ackFilter]);

    useEffect(() => { loadFeedbacks(); }, [loadFeedbacks]);

    const total = feedbacks.length;
    const unread = feedbacks.filter((f) => !f.is_acknowledged).length;
    const withPlan = feedbacks.filter((f) => f.action_plan && f.action_plan.status !== "COMPLETED").length;

    if (!hasFeature("feedbacks")) {
        return (
            <div className="text-center py-20 text-muted-foreground">
                <p className="text-sm">Recurso de Feedbacks não está ativado neste plano.</p>
            </div>
        );
    }

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex items-start justify-between">
                <div>
                    <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground">Gestão</p>
                    <h1 className="text-2xl font-semibold mt-1">
                        {isSeller ? "Meus Feedbacks" : "Feedbacks"}
                    </h1>
                </div>
                {canCreate && (
                    <Button onClick={() => nav(`/${tenantSlug}/feedbacks/new`)} data-testid="btn-feedback-new">
                        <Plus size={16} className="mr-2" /> Novo Feedback
                    </Button>
                )}
            </div>

            {/* KPIs */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {[
                    { label: "Total", value: total, testId: "kpi-fb-total" },
                    { label: isSeller ? "Não lidos" : "Não confirmados", value: unread, testId: "kpi-fb-unread" },
                    { label: "Planos pendentes", value: withPlan, testId: "kpi-fb-plans" },
                ].map((k) => (
                    <div key={k.label} className="bg-card border border-border/60 rounded-md p-4">
                        <p className="text-xs text-muted-foreground">{k.label}</p>
                        <p className="text-2xl font-semibold mt-1" data-testid={k.testId}>{k.value}</p>
                    </div>
                ))}
            </div>

            {/* Filtros */}
            <div className="flex items-center gap-3 flex-wrap">
                <Filter size={14} className="text-muted-foreground" />
                <Select value={typeFilter} onValueChange={setTypeFilter}>
                    <SelectTrigger className="w-40 h-8 text-xs" data-testid="filter-type">
                        <SelectValue placeholder="Tipo" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="ALL">Todos os tipos</SelectItem>
                        {Object.entries(TYPE_CONFIG).map(([k, v]) => (
                            <SelectItem key={k} value={k}>{v.label}</SelectItem>
                        ))}
                    </SelectContent>
                </Select>
                <Select value={ackFilter} onValueChange={setAckFilter}>
                    <SelectTrigger className="w-40 h-8 text-xs" data-testid="filter-ack">
                        <SelectValue placeholder="Leitura" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="ALL">Todos</SelectItem>
                        <SelectItem value="UNREAD">Não confirmados</SelectItem>
                        <SelectItem value="READ">Confirmados</SelectItem>
                    </SelectContent>
                </Select>
            </div>

            {/* Lista */}
            {loading ? (
                <p className="text-sm text-muted-foreground py-10 text-center">Carregando…</p>
            ) : feedbacks.length === 0 ? (
                <div className="bg-card border border-border/60 rounded-md p-10 text-center text-muted-foreground" data-testid="feedbacks-empty">
                    <MessageSquare size={32} className="mx-auto mb-3 opacity-30" />
                    <p className="text-sm">Nenhum feedback encontrado.</p>
                </div>
            ) : (
                <div className="space-y-2" data-testid="feedbacks-list">
                    {feedbacks.map((fb) => {
                        const cfg = TYPE_CONFIG[fb.type] || TYPE_CONFIG.CONSTRUCTIVE;
                        const Icon = cfg.icon;
                        return (
                            <Link
                                key={fb.id}
                                to={`/${tenantSlug}/feedbacks/${fb.id}`}
                                data-testid={`feedback-row-${fb.id}`}
                                className="block bg-card border border-border/60 rounded-md p-4 hover:border-foreground/20 transition-colors"
                            >
                                <div className="flex items-start justify-between gap-4">
                                    <div className="flex items-start gap-3 min-w-0">
                                        <div className={`mt-0.5 flex-shrink-0 p-1.5 rounded border ${cfg.className}`}>
                                            <Icon size={14} />
                                        </div>
                                        <div className="min-w-0">
                                            <div className="flex items-center gap-2 flex-wrap">
                                                <p className="font-medium text-sm truncate">{fb.title}</p>
                                                {!fb.is_acknowledged && (
                                                    <span className="inline-flex items-center gap-1 text-[10px] font-medium px-1.5 py-0.5 rounded bg-luppa-error/10 text-luppa-error border border-luppa-error/25">
                                                        Não lido
                                                    </span>
                                                )}
                                            </div>
                                            <p className="text-xs text-muted-foreground mt-0.5">
                                                {isSeller
                                                    ? `De: ${fb.author_name}`
                                                    : `Para: ${fb.seller_name || fb.seller_id}`
                                                } · {fmtDate(fb.created_at)}
                                            </p>
                                            {fb.action_plan && (
                                                <div className="flex items-center gap-1.5 mt-1.5">
                                                    <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${AP_STATUS[fb.action_plan.status]?.className || ""}`}>
                                                        Plano: {AP_STATUS[fb.action_plan.status]?.label || fb.action_plan.status}
                                                    </span>
                                                    {fb.action_plan.due_date && (
                                                        <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                                                            <Clock size={10} /> Prazo: {fmtDate(fb.action_plan.due_date + "T12:00:00")}
                                                        </span>
                                                    )}
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-2 flex-shrink-0">
                                        {fb.is_acknowledged && (
                                            <CheckCircle size={14} className="text-luppa-green" />
                                        )}
                                        <ChevronRight size={14} className="text-muted-foreground" />
                                    </div>
                                </div>
                            </Link>
                        );
                    })}
                </div>
            )}
        </div>
    );
}
