import React, { useEffect, useState, useCallback } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import {
    Plus, Filter, Download, Activity, TrendingUp, ShoppingBag,
    XCircle, ArrowRight, RefreshCw, User, Store,
} from "lucide-react";
import { useTenant } from "@/context/TenantContext";
import api from "@/lib/api";
import { PageHeader } from "@/components/Common";
import { centsToBRL } from "@/lib/money";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";

const STATUS_LABEL = {
    OPEN: "Aberta",
    CONVERTED_TO_ATTENDANCE: "Em atendimento",
    CONVERTED_TO_SALE: "Venda realizada",
    NO_SALE: "Sem venda",
    CANCELLED: "Cancelada",
};

const STATUS_COLOR = {
    OPEN: "bg-luppa-purple/15 text-luppa-purple",
    CONVERTED_TO_ATTENDANCE: "bg-luppa-purple/15 text-luppa-purple",
    CONVERTED_TO_SALE: "bg-luppa-green/15 text-emerald-800",
    NO_SALE: "bg-luppa-error/15 text-luppa-error",
    CANCELLED: "bg-gray-100 text-gray-600",
};

const SOURCE_LABEL = {
    STORE_FLOOR: "Piso da loja",
    WINDOW: "Vitrine",
    RETURNING_CUSTOMER: "Cliente retornante",
    REFERRAL: "Indicação",
    PHONE: "Telefone",
    WHATSAPP: "WhatsApp",
    INSTAGRAM: "Instagram",
    OTHER: "Outro",
};

function SummaryCard({ label, value, sub, color, testId }) {
    return (
        <div className="metric-card-wrap border border-border/60 rounded-md p-4 bg-card">
            <p className="metric-label text-xs uppercase tracking-[0.1em] text-muted-foreground mb-1">{label}</p>
            <span className={`metric-num font-semibold ${color || ""}`} data-testid={testId}>{value}</span>
            {sub && <p className="text-xs text-muted-foreground mt-1">{sub}</p>}
        </div>
    );
}

export default function ProactivityPage() {
    const { tenantSlug } = useParams();
    const { context } = useTenant();
    const nav = useNavigate();
    const [approaches, setApproaches] = useState([]);
    const [summary, setSummary] = useState(null);
    const [loading, setLoading] = useState(true);
    const [stores, setStores] = useState([]);
    const [sellers, setSellers] = useState([]);

    const [filters, setFilters] = useState({ store_id: "", seller_id: "", status: "", date_from: "", date_to: "" });
    const [showFilters, setShowFilters] = useState(false);

    const role = context?.user_role;
    const canCreate = ["TENANT_ADMIN", "STORE_MANAGER", "SUPERVISOR", "SELLER"].includes(role);
    const canExport = ["TENANT_ADMIN", "REGIONAL_MANAGER", "STORE_MANAGER"].includes(role);

    const fetch = useCallback(async () => {
        setLoading(true);
        try {
            const params = new URLSearchParams();
            Object.entries(filters).forEach(([k, v]) => { if (v) params.set(k, v); });
            const [appsRes, sumRes] = await Promise.all([
                api.get(`/tenants/${tenantSlug}/proactive-approaches?${params}`),
                api.get(`/tenants/${tenantSlug}/proactivity/summary?${params}`),
            ]);
            setApproaches(appsRes.data);
            setSummary(sumRes.data);
        } catch (e) {
            toast.error("Erro ao carregar abordagens");
        } finally {
            setLoading(false);
        }
    }, [tenantSlug, filters]);

    useEffect(() => {
        fetch();
        api.get(`/tenants/${tenantSlug}/stores`).then(r => setStores(r.data)).catch(() => {});
        api.get(`/tenants/${tenantSlug}/sellers`).then(r => setSellers(r.data)).catch(() => {});
    }, [fetch, tenantSlug]);

    const handleExport = async () => {
        try {
            const params = new URLSearchParams({ report_type: "proactivity" });
            Object.entries(filters).forEach(([k, v]) => { if (v) params.set(k === "date_from" ? "date_start" : k === "date_to" ? "date_end" : k, v); });
            const res = await api.get(`/tenants/${tenantSlug}/reports/export/csv?${params}`, { responseType: "blob" });
            const url = window.URL.createObjectURL(res.data);
            const a = document.createElement("a");
            a.href = url;
            a.download = `proatividade.csv`;
            a.click();
        } catch { toast.error("Erro ao exportar"); }
    };

    return (
        <div data-testid="proactivity-page">
            <div className="flex items-start justify-between">
                <PageHeader
                    eyebrow="Módulo"
                    title="Abordagem Proativa"
                    description="Registre e acompanhe abordagens iniciadas pelos vendedores."
                />
                <div className="flex gap-2 mt-1">
                    {canExport && (
                        <Button variant="outline" size="sm" onClick={handleExport} data-testid="proactivity-export-btn">
                            <Download size={14} className="mr-2" /> Exportar
                        </Button>
                    )}
                    <Button variant="outline" size="sm" onClick={() => setShowFilters(f => !f)} data-testid="proactivity-filter-btn">
                        <Filter size={14} className="mr-2" /> Filtros
                    </Button>
                    {canCreate && (
                        <Button size="sm" onClick={() => nav(`/${tenantSlug}/proactivity/new`)} data-testid="proactivity-new-btn">
                            <Plus size={14} className="mr-2" /> Nova abordagem
                        </Button>
                    )}
                </div>
            </div>

            {/* Filtros */}
            {showFilters && (
                <Card className="border border-border shadow-sm mb-6">
                    <CardContent className="p-4">
                        <div className="metric-grid-sm">
                            <div>
                                <label className="text-xs text-muted-foreground mb-1 block">Status</label>
                                <select
                                    className="w-full border border-border rounded-sm px-2 py-1.5 text-sm bg-background"
                                    value={filters.status}
                                    onChange={e => setFilters(f => ({ ...f, status: e.target.value }))}
                                    data-testid="filter-status"
                                >
                                    <option value="">Todos</option>
                                    {Object.entries(STATUS_LABEL).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
                                </select>
                            </div>
                            {role !== "SELLER" && (
                                <div>
                                    <label className="text-xs text-muted-foreground mb-1 block">Unidade</label>
                                    <select
                                        className="w-full border border-border rounded-sm px-2 py-1.5 text-sm bg-background"
                                        value={filters.store_id}
                                        onChange={e => setFilters(f => ({ ...f, store_id: e.target.value }))}
                                        data-testid="filter-store"
                                    >
                                        <option value="">Todas</option>
                                        {stores.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                                    </select>
                                </div>
                            )}
                            {role !== "SELLER" && (
                                <div>
                                    <label className="text-xs text-muted-foreground mb-1 block">Vendedor</label>
                                    <select
                                        className="w-full border border-border rounded-sm px-2 py-1.5 text-sm bg-background"
                                        value={filters.seller_id}
                                        onChange={e => setFilters(f => ({ ...f, seller_id: e.target.value }))}
                                        data-testid="filter-seller"
                                    >
                                        <option value="">Todos</option>
                                        {sellers.map(s => <option key={s.id} value={s.id}>{s.user?.name || s.name || s.id}</option>)}
                                    </select>
                                </div>
                            )}
                            <div>
                                <label className="text-xs text-muted-foreground mb-1 block">De</label>
                                <input
                                    type="date"
                                    className="w-full border border-border rounded-sm px-2 py-1.5 text-sm"
                                    value={filters.date_from}
                                    onChange={e => setFilters(f => ({ ...f, date_from: e.target.value }))}
                                    data-testid="filter-date-from"
                                />
                            </div>
                            <div>
                                <label className="text-xs text-muted-foreground mb-1 block">Até</label>
                                <input
                                    type="date"
                                    className="w-full border border-border rounded-sm px-2 py-1.5 text-sm"
                                    value={filters.date_to}
                                    onChange={e => setFilters(f => ({ ...f, date_to: e.target.value }))}
                                    data-testid="filter-date-to"
                                />
                            </div>
                        </div>
                        <div className="flex gap-2 mt-3">
                            <Button size="sm" onClick={fetch} data-testid="filter-apply-btn">
                                <RefreshCw size={12} className="mr-1" /> Aplicar
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => { setFilters({ store_id: "", seller_id: "", status: "", date_from: "", date_to: "" }); }} data-testid="filter-clear-btn">
                                Limpar
                            </Button>
                        </div>
                    </CardContent>
                </Card>
            )}

            {/* Summary cards */}
            {summary && (
                <div className="metric-grid-sm mb-6">
                    <SummaryCard label="Total" value={summary.total_approaches} testId="summary-total" />
                    <SummaryCard label="Abertas" value={summary.open} color="text-luppa-purple" testId="summary-open" />
                    <SummaryCard label="Em atendimento" value={summary.converted_to_attendance} color="text-luppa-purple" testId="summary-att" />
                    <SummaryCard label="Vendas" value={summary.converted_to_sale} color="text-luppa-green" testId="summary-sales" />
                    <SummaryCard label="Sem venda" value={summary.no_sale} color="text-luppa-error" testId="summary-no-sale" />
                    <SummaryCard
                        label="Receita proativa"
                        value={centsToBRL(summary.proactive_revenue_cents || 0)}
                        sub={`Conversão: ${summary.conversion_to_sale_pct || 0}%`}
                        color="text-luppa-purple"
                        testId="summary-revenue"
                    />
                </div>
            )}

            {/* List */}
            {loading ? (
                <div className="space-y-3">
                    {[1, 2, 3].map(i => <Skeleton key={i} className="h-16 w-full" />)}
                </div>
            ) : approaches.length === 0 ? (
                <Card className="border border-border shadow-sm">
                    <CardContent className="p-12 text-center">
                        <Activity size={32} strokeWidth={1} className="mx-auto mb-4 text-muted-foreground" />
                        <p className="text-sm text-muted-foreground">Nenhuma abordagem proativa encontrada.</p>
                        {canCreate && (
                            <Button className="mt-4" size="sm" onClick={() => nav(`/${tenantSlug}/proactivity/new`)} data-testid="empty-new-btn">
                                <Plus size={14} className="mr-2" /> Registrar primeira abordagem
                            </Button>
                        )}
                    </CardContent>
                </Card>
            ) : (
                <div className="space-y-2" data-testid="proactivity-list">
                    {approaches.map(a => (
                        <Link key={a.id} to={`/${tenantSlug}/proactivity/${a.id}`} data-testid={`approach-item-${a.id}`}>
                            <Card className="border border-border shadow-sm hover:shadow-md transition-all cursor-pointer">
                                <CardContent className="p-4">
                                    <div className="flex items-center justify-between">
                                        <div className="flex items-center gap-3 min-w-0">
                                            <div className="w-8 h-8 rounded-sm bg-accent flex items-center justify-center flex-shrink-0">
                                                <Activity size={14} strokeWidth={1.5} className="text-foreground/70" />
                                            </div>
                                            <div className="min-w-0">
                                                <p className="text-sm font-medium truncate">
                                                    {a.customer_name || "Cliente não identificado"}
                                                </p>
                                                <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
                                                    {a.seller_name && (
                                                        <span className="flex items-center gap-1"><User size={10} /> {a.seller_name}</span>
                                                    )}
                                                    {a.store_name && (
                                                        <span className="flex items-center gap-1"><Store size={10} /> {a.store_name}</span>
                                                    )}
                                                    <span>{SOURCE_LABEL[a.source] || a.source}</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="flex items-center gap-3 flex-shrink-0">
                                            <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${STATUS_COLOR[a.status] || "bg-gray-100 text-gray-600"}`}>
                                                {STATUS_LABEL[a.status] || a.status}
                                            </span>
                                            {a.status === "CONVERTED_TO_SALE" && (
                                                <span className="text-xs font-mono text-luppa-green">
                                                    <ShoppingBag size={12} className="inline mr-1" />
                                                    Venda
                                                </span>
                                            )}
                                            <ArrowRight size={14} className="text-muted-foreground" />
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>
                        </Link>
                    ))}
                </div>
            )}
        </div>
    );
}
