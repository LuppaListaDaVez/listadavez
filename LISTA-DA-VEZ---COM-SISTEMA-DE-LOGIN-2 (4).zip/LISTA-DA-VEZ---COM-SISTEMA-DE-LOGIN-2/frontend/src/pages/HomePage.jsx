import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/context/AuthContext";
import { extractError } from "@/lib/api";
import { Eye, EyeOff, LogIn } from "lucide-react";

export default function HomePage() {
    const { login } = useAuth();
    const navigate = useNavigate();

    const [email, setEmail]       = useState("");
    const [password, setPassword] = useState("");
    const [showPass, setShowPass] = useState(false);
    const [loading, setLoading]   = useState(false);
    const [error, setError]       = useState("");

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError("");
        setLoading(true);
        try {
            const data = await login(email.trim().toLowerCase(), password);
            if (data?.user?.is_super_admin) {
                navigate("/super-admin/dashboard");
            } else {
                // Usuário autenticado mas não é super admin — redirecionar ao tenant
                const slug = data?.tenant_slug || data?.user?.tenant_slug;
                if (slug) navigate(`/${slug}/dashboard`);
                else setError("Para acessar, use o link específico da sua empresa.");
            }
        } catch (err) {
            const detail = err?.response?.data;
            if (detail?.error === "USE_TENANT_LOGIN") {
                setError("Para acessar, use o link específico da sua empresa. Verifique com o administrador o endereço de acesso.");
            } else if (detail?.error === "RATE_LIMIT_EXCEEDED") {
                setError("Muitas tentativas de acesso. Aguarde alguns instantes e tente novamente.");
            } else {
                setError(extractError(err, "E-mail ou senha inválidos."));
            }
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-background flex flex-col items-center justify-center px-4 py-12">

            {/* Card de login */}
            <div className="w-full max-w-md space-y-8">

                {/* Branding */}
                <div className="text-center space-y-2">
                    <h1 className="font-sans text-3xl font-bold tracking-tight">
                        Lista da Vez
                    </h1>
                    <p className="text-sm text-muted-foreground">
                        Acesse sua conta para gerenciar atendimentos e acompanhar sua operação.
                    </p>
                </div>

                {/* Formulário */}
                <div className="border border-border/60 bg-card rounded-xl shadow-sm p-8 space-y-5">
                    <form onSubmit={handleSubmit} className="space-y-5" data-testid="home-login-form">

                        <div className="space-y-1.5">
                            <Label htmlFor="email" className="text-sm font-medium">E-mail</Label>
                            <Input
                                id="email"
                                type="email"
                                autoComplete="email"
                                placeholder="seu@email.com"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                required
                                disabled={loading}
                                data-testid="home-email-input"
                            />
                        </div>

                        <div className="space-y-1.5">
                            <Label htmlFor="password" className="text-sm font-medium">Senha</Label>
                            <div className="relative">
                                <Input
                                    id="password"
                                    type={showPass ? "text" : "password"}
                                    autoComplete="current-password"
                                    placeholder="••••••••"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    required
                                    disabled={loading}
                                    className="pr-10"
                                    data-testid="home-password-input"
                                />
                                <button
                                    type="button"
                                    tabIndex={-1}
                                    onClick={() => setShowPass((v) => !v)}
                                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                                    aria-label={showPass ? "Ocultar senha" : "Mostrar senha"}
                                >
                                    {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                                </button>
                            </div>
                        </div>

                        {/* Mensagem de erro */}
                        {error && (
                            <p
                                className="text-sm text-destructive bg-destructive/8 border border-destructive/20 rounded-md px-3 py-2.5 leading-snug"
                                data-testid="home-login-error"
                                role="alert"
                            >
                                {error}
                            </p>
                        )}

                        <Button
                            type="submit"
                            className="w-full gap-2"
                            disabled={loading || !email || !password}
                            data-testid="home-login-submit"
                        >
                            {loading ? (
                                <>Entrando…</>
                            ) : (
                                <><LogIn size={15} strokeWidth={2} /> Entrar</>
                            )}
                        </Button>

                    </form>
                </div>

                {/* Rodapé discreto */}
                <p className="text-center text-xs text-muted-foreground/60">
                    © {new Date().getFullYear()} Lista da Vez
                </p>
            </div>
        </div>
    );
}

