import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import api from "@/lib/api";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
    const [user, setUser] = useState(null);
    const [memberships, setMemberships] = useState([]);
    const [loading, setLoading] = useState(true);

    const refreshMe = useCallback(async () => {
        const token = localStorage.getItem("access_token");
        if (!token) {
            setUser(null);
            setMemberships([]);
            setLoading(false);
            return null;
        }
        try {
            const { data } = await api.get("/auth/me");
            setUser(data.user);
            setMemberships(data.memberships || []);
            localStorage.setItem("user", JSON.stringify(data.user));
            return data;
        } catch {
            setUser(null);
            setMemberships([]);
            localStorage.removeItem("access_token");
            localStorage.removeItem("refresh_token");
            localStorage.removeItem("user");
            localStorage.removeItem("auth_tenant_slug");
            return null;
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        // CRITICAL: Se retornando do OAuth callback, pular o check /me.
        // GoogleAuthCallback irá trocar o session_id e estabelecer a sessão primeiro.
        if (window.location.hash?.includes("session_id=")) {
            setLoading(false);
            return;
        }
        refreshMe();
    }, [refreshMe]);

    // Login de tenant (endpoint tenant-scoped — Etapa 13)
    const loginTenant = async (tenantSlug, email, password) => {
        const { data } = await api.post(`/tenants/${tenantSlug}/auth/login`, {
            email,
            password,
        });
        localStorage.setItem("access_token", data.access_token);
        localStorage.setItem("refresh_token", data.refresh_token);
        localStorage.setItem("user", JSON.stringify(data.user));
        // Marca a sessão como pertencente a este tenant
        localStorage.setItem("auth_tenant_slug", tenantSlug);
        setUser(data.user);
        setMemberships([
            {
                tenant_id: data.tenant_id,
                tenant_slug: data.tenant_slug,
                role: data.membership?.role,
                store_ids: data.membership?.store_ids || [],
            },
        ]);
        return data;
    };

    // Login global — apenas Super Admin
    const login = async (email, password) => {
        const { data } = await api.post("/auth/login", { email, password });
        localStorage.setItem("access_token", data.access_token);
        localStorage.setItem("refresh_token", data.refresh_token);
        localStorage.setItem("user", JSON.stringify(data.user));
        // Super Admin não tem auth_tenant_slug
        localStorage.removeItem("auth_tenant_slug");
        setUser(data.user);
        setMemberships(data.memberships || []);
        return data;
    };

    // Ativa sessão diretamente a partir de tokens recebidos (ex: aceite de convite)
    const loginWithTokens = useCallback((data, tenantSlug) => {
        localStorage.setItem("access_token", data.access_token);
        localStorage.setItem("refresh_token", data.refresh_token);
        localStorage.setItem("user", JSON.stringify(data.user));
        localStorage.setItem("auth_tenant_slug", tenantSlug);
        setUser(data.user);
        setMemberships([
            {
                tenant_id: data.tenant_id,
                tenant_slug: tenantSlug,
                role: data.membership?.role,
                store_ids: data.membership?.store_ids || [],
            },
        ]);
    }, []);

    const logout = async () => {
        const refresh_token = localStorage.getItem("refresh_token");
        try {
            await api.post("/auth/logout", { refresh_token });
        } catch {
            /* noop */
        }
        localStorage.removeItem("access_token");
        localStorage.removeItem("refresh_token");
        localStorage.removeItem("user");
        localStorage.removeItem("auth_tenant_slug");
        setUser(null);
        setMemberships([]);
    };

    // Limpa sessão tenant sem fazer chamada API (para casos de mismatch)
    const clearTenantSession = useCallback(() => {
        localStorage.removeItem("access_token");
        localStorage.removeItem("refresh_token");
        localStorage.removeItem("user");
        localStorage.removeItem("auth_tenant_slug");
        setUser(null);
        setMemberships([]);
    }, []);

    return (
        <AuthContext.Provider
            value={{
                user,
                memberships,
                loading,
                login,
                loginTenant,
                loginWithTokens,
                logout,
                refreshMe,
                clearTenantSession,
            }}
        >
            {children}
        </AuthContext.Provider>
    );
}

export const useAuth = () => {
    const ctx = useContext(AuthContext);
    if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
    return ctx;
};
