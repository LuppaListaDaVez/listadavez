import React, { createContext, useContext, useEffect, useState, useCallback, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import api from "@/lib/api";
import { useAuth } from "@/context/AuthContext";

const TenantContext = createContext(null);

export function TenantProvider({ children }) {
    const { tenantSlug } = useParams();
    const { user, loading: authLoading, clearTenantSession } = useAuth();
    const [context, setContext] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const navigate = useNavigate();
    const prevSlugRef = useRef(null);

    const load = useCallback(async () => {
        if (!tenantSlug) {
            setLoading(false);
            return;
        }
        setLoading(true);
        setError(null);
        try {
            const { data } = await api.get(`/tenants/${tenantSlug}/context`);
            setContext(data);
        } catch (e) {
            const status = e?.response?.status;
            const errCode = e?.response?.data?.detail?.error || e?.response?.data?.error;

            if (errCode === "TENANT_SESSION_MISMATCH") {
                // Limpar sessão e redirecionar
                clearTenantSession();
                setContext(null);
                setError("session_mismatch");
                return;
            }
            if (status === 404) setError("not_found");
            else if (status === 403) setError("forbidden");
            else if (status === 401) setError("unauthorized");
            else setError("unknown");
            setContext(null);
        } finally {
            setLoading(false);
        }
    }, [tenantSlug, clearTenantSession]);

    // Detectar troca de tenantSlug na URL (isolamento cross-tenant)
    useEffect(() => {
        if (authLoading) return;
        if (!user) {
            setLoading(false);
            return;
        }

        const authTenantSlug = localStorage.getItem("auth_tenant_slug");

        // Se o usuário está logado como tenant e o slug mudou → forçar re-login
        if (
            authTenantSlug &&
            tenantSlug &&
            authTenantSlug !== tenantSlug
        ) {
            // Não limpar a sessão aqui — apenas redirecionar para login do novo slug
            // O backend vai validar o token quando a API for chamada e retornar TENANT_SESSION_MISMATCH
            setContext(null);
            setError("session_mismatch");
            setLoading(false);
            return;
        }

        // Detectar troca de slug dentro da mesma navegação (prevSlug diferente)
        if (prevSlugRef.current && prevSlugRef.current !== tenantSlug) {
            setContext(null);
        }
        prevSlugRef.current = tenantSlug;

        load();
    }, [load, user, authLoading, tenantSlug]);

    return (
        <TenantContext.Provider
            value={{ tenantSlug, context, loading, error, reload: load }}
        >
            {children}
        </TenantContext.Provider>
    );
}

export const useTenant = () => {
    const ctx = useContext(TenantContext);
    if (!ctx) throw new Error("useTenant must be used inside TenantProvider");
    return ctx;
};
