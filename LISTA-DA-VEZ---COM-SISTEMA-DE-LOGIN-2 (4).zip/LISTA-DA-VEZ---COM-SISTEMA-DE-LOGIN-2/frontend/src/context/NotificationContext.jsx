/**
 * NotificationContext — estado global de notificações (Prompt 11)
 * Carrega da API + recebe updates em tempo real via RealtimeTenantContext.
 */
import {
    createContext, useContext, useState, useEffect, useCallback, useRef,
} from "react";
import { useParams } from "react-router-dom";
import { toast } from "sonner";
import { Bell, Target, AlertTriangle, Star, Settings, MessageSquare,
         Trophy, Megaphone, TrendingUp, Zap } from "lucide-react";
import api from "@/lib/api";
import { useRealtimeTenant } from "./RealtimeTenantContext";
import { usePermissions } from "@/hooks/usePermissions";

const NotificationContext = createContext(null);

// Ícones por tipo de notificação
export const NOTIF_TYPE_CONFIG = {
    FEEDBACK_RECEIVED:  { icon: MessageSquare, color: "text-blue-600",    bg: "bg-blue-50",    label: "Feedback" },
    GOAL_COMPLETED:     { icon: Target,        color: "text-emerald-600",  bg: "bg-emerald-50", label: "Meta atingida" },
    GOAL_EXPIRED:       { icon: AlertTriangle, color: "text-amber-600",    bg: "bg-amber-50",   label: "Meta expirada" },
    GOAL_EXCEEDED:      { icon: Trophy,        color: "text-yellow-600",   bg: "bg-yellow-50",  label: "Meta superada" },
    BADGE_EARNED:       { icon: Star,          color: "text-purple-600",   bg: "bg-purple-50",  label: "Conquista" },
    RANKING_CHANGED:    { icon: TrendingUp,    color: "text-green-600",    bg: "bg-green-50",   label: "Ranking" },
    PERSONAL_RECORD:    { icon: Zap,           color: "text-orange-600",   bg: "bg-orange-50",  label: "Recorde" },
    COMPANY_RECORD:     { icon: Zap,           color: "text-red-600",      bg: "bg-red-50",     label: "Recorde empresa" },
    CAMPAIGN_STARTED:   { icon: Megaphone,     color: "text-indigo-600",   bg: "bg-indigo-50",  label: "Campanha iniciada" },
    CAMPAIGN_UPDATED:   { icon: Megaphone,     color: "text-blue-600",     bg: "bg-blue-50",    label: "Campanha atualizada" },
    CAMPAIGN_ENDED:     { icon: Megaphone,     color: "text-slate-600",    bg: "bg-slate-50",   label: "Campanha encerrada" },
    AWARD:              { icon: Trophy,        color: "text-yellow-700",   bg: "bg-yellow-50",  label: "Premiação" },
    RECOGNITION:        { icon: Star,          color: "text-amber-600",    bg: "bg-amber-50",   label: "Reconhecimento" },
    ADMIN_ANNOUNCEMENT: { icon: Megaphone,     color: "text-rose-600",     bg: "bg-rose-50",    label: "Aviso admin" },
    GENERAL_ANNOUNCEMENT: { icon: Bell,        color: "text-sky-600",      bg: "bg-sky-50",     label: "Comunicado" },
    SCHEDULED_MESSAGE:  { icon: MessageSquare, color: "text-violet-600",   bg: "bg-violet-50",  label: "Mensagem" },
    MOTIVATION_EVENT:   { icon: Zap,           color: "text-teal-600",     bg: "bg-teal-50",    label: "Evento" },
    STATUS_CHANGED:     { icon: Settings,      color: "text-slate-600",    bg: "bg-slate-50",   label: "Status" },
    SYSTEM:             { icon: Settings,      color: "text-slate-600",    bg: "bg-slate-50",   label: "Sistema" },
};

export function NotificationProvider({ children }) {
    const { tenantSlug } = useParams();
    const { hasFeature } = usePermissions();
    const { subscribe } = useRealtimeTenant();

    const [unreadCount, setUnreadCount] = useState(0);
    const [notifications, setNotifications] = useState([]);
    const [loading, setLoading] = useState(false);
    const seenToastIds = useRef(new Set());

    const enabled = hasFeature("notificacoes");

    const fetchNotifications = useCallback(async (opts = {}) => {
        if (!tenantSlug || !enabled) return;
        if (opts.showLoading) setLoading(true);
        try {
            const res = await api.get(`/tenants/${tenantSlug}/notifications`, {
                params: { page_size: 50 },
            });
            setNotifications(res.data.notifications || []);
            setUnreadCount(res.data.unread_count || 0);
        } catch { /* silencioso */ } finally {
            if (opts.showLoading) setLoading(false);
        }
    }, [tenantSlug, enabled]);

    const fetchCount = useCallback(async () => {
        if (!tenantSlug || !enabled) return;
        try {
            const res = await api.get(`/tenants/${tenantSlug}/notifications/unread-count`);
            setUnreadCount(res.data.count || 0);
        } catch { /* silencioso */ }
    }, [tenantSlug, enabled]);

    // Carga inicial
    useEffect(() => { fetchNotifications({ showLoading: true }); }, [fetchNotifications]);

    // Polling de fallback (60s)
    useEffect(() => {
        if (!enabled) return;
        const id = setInterval(fetchCount, 60_000);
        return () => clearInterval(id);
    }, [fetchCount, enabled]);

    // Realtime via WS
    useEffect(() => {
        const unsub = subscribe("notification.created", (event) => {
            try {
                const notif = event.payload;
                if (!notif?.id) return;
                if (seenToastIds.current.has(notif.id)) return;
                seenToastIds.current.add(notif.id);

                // Limitar crescimento do Set de deduplicação (evitar leak de memória)
                if (seenToastIds.current.size > 500) {
                    const arr = [...seenToastIds.current];
                    seenToastIds.current = new Set(arr.slice(-250));
                }

                // Prepend na lista
                const newNotif = { ...notif, is_read: false };
                setNotifications(prev => [newNotif, ...prev.filter(n => n.id !== notif.id)]);
                setUnreadCount(prev => prev + 1);

                // Toast — defer para fora do callback do WS para não conflitar com renders concorrentes
                const cfg = NOTIF_TYPE_CONFIG[notif.type] || NOTIF_TYPE_CONFIG.SYSTEM;
                const Icon = cfg?.icon;
                setTimeout(() => {
                    try {
                        toast(notif.title || "Nova notificação", {
                            description: notif.body,
                            icon: Icon ? <Icon size={16} className={cfg.color} /> : undefined,
                            duration: 6000,
                            position: "top-right",
                        });
                    } catch { /* toast não crítico — ignora */ }
                }, 0);
            } catch { /* handler não pode quebrar o WS */ }
        });
        return unsub;
    }, [subscribe]);

    const markAsRead = useCallback(async (id) => {
        try {
            await api.patch(`/tenants/${tenantSlug}/notifications/${id}/read`);
            setNotifications(prev => prev.map(n => n.id === id ? { ...n, is_read: true } : n));
            setUnreadCount(prev => Math.max(0, prev - 1));
        } catch { /* silencioso */ }
    }, [tenantSlug]);

    const markAllRead = useCallback(async () => {
        try {
            await api.post(`/tenants/${tenantSlug}/notifications/mark-all-read`);
            setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
            setUnreadCount(0);
        } catch { /* silencioso */ }
    }, [tenantSlug]);

    return (
        <NotificationContext.Provider value={{
            unreadCount, notifications, loading,
            fetchNotifications, markAsRead, markAllRead,
        }}>
            {children}
        </NotificationContext.Provider>
    );
}

export function useNotifications() {
    const ctx = useContext(NotificationContext);
    if (!ctx) return {
        unreadCount: 0, notifications: [], loading: false,
        fetchNotifications: () => {}, markAsRead: () => {}, markAllRead: () => {},
    };
    return ctx;
}
