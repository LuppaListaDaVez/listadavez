/**
 * RealtimeTenantContext — WebSocket único por tenant (Prompt 11)
 * Gerencia UMA conexão WS em /api/ws/tenants/{slug} e distribui eventos via pub/sub interno.
 */
import { createContext, useContext, useEffect, useRef, useCallback, useState } from "react";
import { useParams } from "react-router-dom";

const RealtimeTenantContext = createContext(null);

const PING_INTERVAL_MS = 30_000;
const BACKOFF_MS = [1000, 2000, 5000, 15000];

export function RealtimeTenantProvider({ children }) {
    const { tenantSlug } = useParams();

    const wsRef = useRef(null);
    const pingRef = useRef(null);
    const reconnectRef = useRef(null);
    const attemptRef = useRef(0);
    const closedRef = useRef(false);
    const handlersRef = useRef({}); // { eventType: Set<handler> }
    const seenIdsRef = useRef(new Set());
    const scheduleRef = useRef(null); // forward reference for scheduleReconnect

    const [isConnected, setIsConnected] = useState(false);

    // ── subscribe/unsubscribe ──────────────────────────────────────────────
    const subscribe = useCallback((eventType, handler) => {
        if (!handlersRef.current[eventType]) handlersRef.current[eventType] = new Set();
        handlersRef.current[eventType].add(handler);
        return () => handlersRef.current[eventType]?.delete(handler);
    }, []);

    const dispatch = useCallback((event) => {
        const et = event.event_type;
        if (!et) return;

        // Deduplicação por id do payload
        const eventId = event.payload?.id;
        if (eventId) {
            if (seenIdsRef.current.has(eventId)) return;
            seenIdsRef.current.add(eventId);
        }

        handlersRef.current[et]?.forEach(h => { try { h(event); } catch { /* ignore */ } });
        handlersRef.current["*"]?.forEach(h => { try { h(event); } catch { /* ignore */ } });
    }, []);

    // ── WebSocket connection ───────────────────────────────────────────────
    const connect = useCallback(() => {
        if (!tenantSlug || closedRef.current) return;

        const token = localStorage.getItem("access_token");
        if (!token) return;

        const backendUrl = process.env.REACT_APP_BACKEND_URL || "";
        const wsBase = backendUrl.replace(/^http/, "ws");
        const url = `${wsBase}/api/ws/tenants/${tenantSlug}?token=${token}`;

        let ws;
        try {
            ws = new WebSocket(url);
        } catch {
            scheduleRef.current?.();
            return;
        }
        wsRef.current = ws;

        ws.onopen = () => {
            attemptRef.current = 0;
            setIsConnected(true);
            // Start ping
            if (pingRef.current) clearInterval(pingRef.current);
            pingRef.current = setInterval(() => {
                if (ws.readyState === WebSocket.OPEN) ws.send("ping");
            }, PING_INTERVAL_MS);
        };

        ws.onmessage = (ev) => {
            try {
                const data = JSON.parse(ev.data);
                if (data.event_type === "connection.ready" || data.event_type === "pong") return;
                dispatch(data);
            } catch { /* ignore malformed */ }
        };

        ws.onerror = () => { /* handled in onclose */ };

        ws.onclose = (e) => {
            wsRef.current = null;
            setIsConnected(false);
            if (pingRef.current) { clearInterval(pingRef.current); pingRef.current = null; }
            if (closedRef.current) return;
            if (e?.code === 4403) return; // auth failed — don't retry
            scheduleRef.current?.();
        };
    }, [tenantSlug, dispatch]);

    const scheduleReconnect = useCallback(() => {
        if (closedRef.current) return;
        const delay = BACKOFF_MS[Math.min(attemptRef.current, BACKOFF_MS.length - 1)];
        attemptRef.current += 1;
        reconnectRef.current = setTimeout(() => {
            if (!closedRef.current) connect();
        }, delay);
    }, [connect]);

    // Keep scheduleRef in sync
    useEffect(() => { scheduleRef.current = scheduleReconnect; }, [scheduleReconnect]);

    useEffect(() => {
        closedRef.current = false;
        attemptRef.current = 0;
        seenIdsRef.current = new Set();
        connect();
        return () => {
            closedRef.current = true;
            if (pingRef.current) clearInterval(pingRef.current);
            if (reconnectRef.current) clearTimeout(reconnectRef.current);
            if (wsRef.current) {
                const ws = wsRef.current;
                wsRef.current = null;
                try {
                    if (ws.readyState === WebSocket.CONNECTING) {
                        ws.onopen = () => { try { ws.close(); } catch { /* noop */ } };
                        ws.onerror = () => {};
                        ws.onclose = () => {};
                    } else {
                        ws.close();
                    }
                } catch { /* noop */ }
            }
        };
    }, [connect]);

    return (
        <RealtimeTenantContext.Provider value={{ subscribe, isConnected }}>
            {children}
        </RealtimeTenantContext.Provider>
    );
}

export function useRealtimeTenant() {
    const ctx = useContext(RealtimeTenantContext);
    if (!ctx) return { subscribe: () => () => {}, isConnected: false };
    return ctx;
}
