# Relatório Final de Auditoria Técnica — Lista da Vez (pós-migração Postgres)
*Data: 27 Ago 2026*

## 1. Arquitetura real do sistema

```
┌─────────────┐      HTTPS/JSON      ┌──────────────────┐      SQL (asyncpg)      ┌─────────────────────┐
│  React SPA  │ ───────────────────► │  FastAPI backend  │ ──────────────────────► │ PostgreSQL (Supabase)│
│  (porta 3000)│ ◄─────────────────── │  (porta 8001)     │ ◄────────────────────── │  pooler us-east-2    │
└─────────────┘                      └──────────────────┘                          └─────────────────────┘
                                             │
                                             ├─ pg_shim/  (camada de compatibilidade Mongo→SQL)
                                             ├─ routes_*.py (73 routers FastAPI)
                                             ├─ queue_engine.py, sales_service.py, goals_service.py...
                                             └─ Supervisor gerencia frontend + backend (hot-reload)
```

**Stack real (não é Next.js, não usa Supabase Auth/RLS nativo):**
- Frontend: React 19 SPA (Create React App) + TailwindCSS + ShadCN UI, servido pelo dev server na porta 3000.
- Backend: FastAPI (Python 3.11), rotas prefixadas com `/api`.
- Persistência: PostgreSQL via Supabase (Session Pooler), acessado por `asyncpg` — **não** via SQLAlchemy ORM, **não** via Supabase Auth/PostgREST/RLS.
- Autenticação: JWT (HS256) próprio (`security.py`) + login social via Emergent-managed Google Auth. Sessões/refresh tokens em tabelas próprias (`auth_sessions`, `refresh_tokens`).
- Isolamento multi-tenant: **lógico, na aplicação** — todo documento carrega `tenant_id` e toda query do backend filtra por `tenant_id` do contexto autenticado (`resolve_tenant_context`/`require_roles`). Não existe Row Level Security nativa do Postgres.

### 1.1 `pg_shim` — por que existe e como funciona
Antes da migração, ~25 mil linhas de código acessavam MongoDB diretamente via `db.<collection>.find_one()`, `insert_one()`, `update_one()`, pipelines de agregação, etc. Reescrever tudo isso para SQL/ORM era um risco alto de regressão. A solução adotada foi um adaptador (`/app/backend/pg_shim/`) que:

- Expõe a **mesma API assíncrona do Motor/PyMongo** (`find`, `find_one`, `insert_one`, `update_one`, `find_one_and_update`, `aggregate`, `create_index`, `distinct`, etc.) — nenhum código de negócio precisou mudar.
- Persiste cada "coleção" Mongo como uma tabela Postgres real `doc_<collection>` com schema genérico:
  ```sql
  CREATE TABLE doc_<collection> (
      row_seq BIGSERIAL PRIMARY KEY,   -- identidade física da linha (NOVO — ver seção 4.2)
      id TEXT,                          -- id lógico do documento (campo "id" do JSON, quando existe)
      tenant_id TEXT,
      doc JSONB NOT NULL,
      created_at TIMESTAMPTZ DEFAULT now(),
      updated_at TIMESTAMPTZ DEFAULT now()
  )
  ```
- Filtros Mongo (`$in`, `$or`, `$ne`, `$exists`, `$gt/$gte/$lt/$lte`...) e pipelines de agregação (`$match`, `$group`, `$project`, `$lookup`, `$facet`, `$bucket`, `$unwind`, operadores de data) são reimplementados em Python puro em `pg_shim/expr.py` e `pg_shim/pipeline.py`. Filtros simples de igualdade têm pushdown para SQL (`WHERE (doc->>'campo') = $1`) por performance; o restante é filtrado em memória após o `SELECT`.
- Índices únicos/esparsos usam índices parciais reais do Postgres (`CREATE UNIQUE INDEX ... WHERE (doc->>'campo') IS NOT NULL`), preservando a semântica de `sparse=True` do Mongo (permite múltiplos `NULL`).
- TTL (expiração automática, ex.: tokens, locks) é reimplementado como uma tarefa em background (`start_ttl_sweeper`, a cada 5 min) que roda `DELETE ... WHERE (doc->>'campo')::timestamptz < now()`.

## 2. Regras de proteção contra duplicidade (por entidade)

| Entidade | Chave de duplicidade | Mecanismo | Comportamento sob concorrência (10x testado) |
|---|---|---|---|
| **Produtos** (`products`) | `(tenant_id, sku)` — apenas quando `sku` não é nulo | Índice único parcial (`sparse=True`) + `try/except DuplicateKeyError → 409` em create/update | 1 sucesso + 9×409 quando SKU é igual. **Produtos sem SKU: todos os 10 são criados normalmente** (comportamento correto — produto sem SKU nunca é "duplicado" pela regra de negócio) |
| **Vendedores** (`seller_profiles` + `users`) | E-mail (`users.email`, único global) **e** `(tenant_id, user_id)` em `seller_profiles` (um perfil de vendedor por usuário por tenant) | Índices únicos + `try/except DuplicateKeyError` em 3 pontos: criação de usuário, criação de `tenant_membership` (corrigido nesta sessão — ver seção 4.1) e criação de `seller_profile` | 1×201 + 9×409, sem 500 (corrigido nesta sessão) |
| **Planos** (`plans`, super-admin) | `name` (único global — recurso raramente usado, 1 super-admin por vez) | Índice único **novo** (`db.plans.create_index("name", unique=True)`) + `try/except DuplicateKeyError → 409` **(adicionado nesta sessão)** | 1×201 + 9×409 |
| **Push subscriptions** (`push_subscriptions`) | `(tenant_id, user_id, endpoint)` | Índice único esparso **novo** + fluxo "buscar existente → inserir → se colidir, retornar existente" **(adicionado nesta sessão)** | Todas as 10 requisições retornam 200 com a MESMA subscription (nenhuma duplicata criada) |
| **Fila** (`queue_entries`) | Um vendedor não pode ter duas entradas `WAITING` simultâneas | `seller_lock` (lock distribuído via índice único em `queue_locks`) em `join_queue` | 1 sucesso + 9×409 `QUEUE_OPERATION_CONFLICT` |
| **Atendimento — início** (`attendances`) | Um vendedor não pode ter dois atendimentos `IN_PROGRESS` simultâneos | `seller_lock` em `start_attendance` | 1 sucesso + 9×409 |
| **Atendimento — finalização** (`attendances` + `sales`) | Um `attendance_id` só pode ser finalizado uma vez (1 venda no máximo) | **Bug real encontrado e corrigido nesta sessão** — `seller_lock` adicionado em `finish_attendance` (ver seção 4.1) | Antes da correção: 10 requisições concorrentes criavam **10 vendas duplicadas** para o mesmo atendimento (apenas 1 delas "vencia" a transição de status, mas todas já tinham inserido a venda). Depois da correção: exatamente 1 venda criada, resto 409 |
| **Convites de tenant** (`invite_tokens`) | Nenhuma trava — achado de baixa prioridade | Sem lock; `resend-invite` revoga tokens antigos e cria um novo, mas sob 10 chamadas simultâneas do MESMO super-admin múltiplos tokens válidos podem coexistir | Documentado como achado de **baixa prioridade** (ação restrita a super-admin, ação rara, não gera dado de negócio incorreto — apenas mais de um link de convite válido ao mesmo tempo) |

## 3. Testes de concorrência 10x — resultado final

Script: `/app/scripts/audit_concurrency_stress.py` (roda fora de `/app/backend` para não disparar hot-reload). Executado contra o ambiente real (Supabase), sem mocks.

```
PASS — 1. Produto SKU duplicado (10x)                     → statuses=[201, 409×9]           db_count=1
PASS — 2. Produto SKU NULL (10x, todos devem passar)      → statuses=[201×10]                db_count=10
PASS — 3. Vendedor e-mail duplicado (10x)                 → statuses=[201, 409×9]  (sem 500)  users=1 seller_profiles=1
PASS — 4. Plano nome duplicado (10x)                       → statuses=[201, 409×9]            db_count=1
PASS — 5. Push subscription mesmo endpoint (10x)           → statuses=[200×10]                db_count=1
PASS — 6. Fila join concorrente mesmo vendedor (10x)       → statuses=[200, 409×9]            waiting_entries=1
PASS — 7. Start-attendance concorrente mesmo vendedor (10x)→ statuses=[200, 409×9]            in_progress_db=1
PASS — 8. Finish-attendance concorrente mesmo attendance_id (10x) → statuses=[200, 409×9]     sales_created=1
PASS — 9. Resend-invite concorrente (10x) — informativo    → statuses=[200×10] (achado baixa prioridade documentado)
```
9/9 cenários passam (item 9 é informativo/aceito, não bloqueante).

## 4. Bugs reais encontrados e corrigidos nesta sessão de fechamento

### 4.1 Venda duplicada em `finish-attendance` concorrente (CRÍTICO)
**Causa raiz**: `queue_engine.finish_attendance` validava `status == "IN_PROGRESS"` e criava a venda (`sales_service.create_sale`) **antes** da transição atômica `find_one_and_update({"status":"IN_PROGRESS"}, ...)`. Sob concorrência, todas as requisições liam o mesmo status válido, todas criavam venda, e só a transição final decidia (com atraso) qual delas "ganhava" — mas as vendas órfãs já tinham sido persistidas.
**Correção**: todo o bloco crítico (validação + criação da venda + transição atômica) passou a rodar dentro de `async with seller_lock(tenant_id, seller_id, "FINISH_ATTENDANCE")`, com reconfirmação do status logo após adquirir o lock — mesmo padrão já usado em `join_queue`, `start_attendance` e `finish_multiple_attendances`. `finish_attendance` era o único fluxo crítico sem essa trava.
**Validado**: 10 requisições concorrentes → exatamente 1 venda criada (antes: 10).

### 4.2 Locks/documentos sem campo `id` nunca eram limpos (pg_shim)
**Causa raiz**: `pg_shim/collection.py` usava a coluna física `id` (extraída de `doc->>'id'`) como identificador de linha para `UPDATE`/`DELETE` (`WHERE id = $1`). Para coleções cujos documentos não usam `"id"` como chave (ex.: `queue_locks`, que usa `lock_key`/`lock_id`), essa coluna fica `NULL` para todas as linhas — e `WHERE id = NULL` nunca casa com nada em SQL. Resultado: `delete_one`/`delete_many`/`update_one` sobre essas coleções eram **no-ops silenciosos** (não geravam erro, apenas não faziam nada).
**Impacto real observado**: locks de vendedor expirados (`queue_locks`, TTL de 30s) nunca eram removidos pela limpeza automática (`_cleanup_expired_locks`, chamada a cada tentativa de lock com conflito) — só eram eventualmente removidos pelo TTL sweeper de fundo (intervalo de 5 min). Um lock órfão (ex.: por reinício do processo a meio de uma requisição) podia bloquear operações de fila/atendimento daquele vendedor por até 5 minutos.
**Correção**: `_select_for_update`, `_write_conn`, `find_one_and_delete`, `delete_one`, `delete_many` passaram a usar a coluna física `row_seq` (BIGSERIAL, sempre não-nula, chave primária real da tabela) em vez de `id` para localizar a linha a atualizar/apagar. `id` continua sendo usado normalmente para inserts e para os índices únicos de negócio.
**Escopo do impacto**: das ~76 coleções, apenas `queue_locks` e `historico_administrativo_motivos_perda` não usam `"id"` como campo — a segunda é um log append-only (nunca sofre update/delete), então o único impacto real era em `queue_locks`.
**Validado**: teste de unidade manual confirma que um lock expirado inserido manualmente agora é removido corretamente por `_cleanup_expired_locks()`; regressão via `testing_agent` (iteração 75) confirma que coleções com `id` (produtos) continuam funcionando normalmente em update/patch.

### 4.3 500 não tratado em criação de vendedor concorrente
**Causa raiz**: `routes_sellers.create_seller` capturava `DuplicateKeyError` na criação do usuário e do `seller_profile`, mas **não** na criação do `tenant_membership` — sob corrida, duas requisições podiam ambas ver "sem membership" e ambas tentar inserir, causando `DuplicateKeyError` não tratada → 500.
**Correção**: insert de `tenant_membership` também envolvido em `try/except DuplicateKeyError: pass` (idempotente — se já existe, está tudo certo).
**Validado**: 10 requisições concorrentes com mesmo e-mail → 1×201, 9×409, **zero 500** (antes: múltiplos 500 misturados com 409).

## 5. Investigação — login "frio" lento após restart

**Medição real (3 restarts consecutivos do backend nesta sessão):**
| Etapa | Duração típica |
|---|---|
| Processo sobe, conecta pool Postgres | ~5-10s |
| Criação/verificação de ~150 índices (73 coleções) | ~50-90s |
| Re-seed idempotente (verifica/cria dados demo) | ~2min-2min30s |
| **Total até "Boot complete"** | **~3min-3min45s** |

**Causa raiz confirmada**: o re-seed (`seed.py`, roda em todo boot) faz centenas de round-trips sequenciais de verificação (`find_one` por usuário/tenant/feature/plano antes de decidir se cria) contra o Supabase remoto (us-east-2), cada round-trip custando ~150-250ms de latência de rede — não é lentidão de CPU, é soma de latência de rede sequencial. Depois do boot completo (~3-4 min), operações normais (login, dashboard, fila) ficam em ~1-2s, dentro do esperado.
**Não é um bug de dado incorreto** — apenas uma janela de indisponibilidade/lentidão logo após reiniciar o processo. Não corrigido nesta sessão por ser uma otimização de performance de baixo risco/baixo retorno imediato (P1, não bloqueante); qualquer otimização (paralelizar verificações do seed, ou pular re-seed quando já há um `tenants` com contagem esperada) exigiria testes de regressão cuidadosos do próprio seed idempotente e foi deixada como item de backlog explícito.

## 6. Débito técnico documentado (não corrigido nesta sessão, por decisão do usuário)

- **Suíte pytest legada** (`/app/backend/tests/`, 37 arquivos): vários usam IDs hardcoded de antes do re-seed (`STORE_ID`, `JOAO_SELLER_ID` etc.) e por isso falham com 404 "Unidade não encontrada" mesmo sem bug real no backend. Refactor incremental iniciado nesta sessão (`test_sale_no_product.py` já convertido para fixtures dinâmicas, 3/4 passando + 1 skip esperado); os demais ~30 arquivos permanecem como backlog P1, sem bloquear o restante da auditoria (decisão explícita do usuário).
- **`plans.name`** usa índice único **global** (não por tenant) — correto pois planos são um recurso exclusivo de super-admin, sem escopo de tenant.
- **Resend de convite sem lock** — baixa prioridade, ação restrita a super-admin.

## 7. Dados de teste
Todos os registros `AUDIT_TEST*`/`AUDIT75_*` criados durante esta auditoria (produtos, usuários, seller_profiles, planos, tokens de convite de teste) foram removidos do banco ao final. Nenhum dado real de demo foi apagado.
