# PRD — Lista da Vez SaaS
*Última atualização: 13 Ago 2026*

## Problema Original
Importar e configurar repositório multi-tenant SaaS ("Lista da Vez") do GitHub. Instalar dependências, configurar variáveis de ambiente, executar migrations e iniciar frontend + backend sem alterar regras de negócio, schema do banco ou lógica de autenticação.

## Personas
- **Super Admin**: Administrador global da plataforma (único)
- **Tenant Admin**: Administrador de cada empresa/tenant
- **Tenant User**: Funcionário/vendedor dentro de um tenant

## Arquitetura
- **Frontend**: React 19, TailwindCSS, ShadcnUI — porta 3000
- **Backend**: FastAPI (Python 3.11), Motor (Async MongoDB) — porta 8001
- **Banco**: MongoDB (MONGO_URL via .env)
- **Auth**: JWT HS256 + Emergent-managed Google OAuth
- **Multi-tenant**: Path-based (`/:tenantSlug`)
- **Processo**: Supervisor (frontend + backend)

## O que foi implementado

### Preparação para apresentação — Painel, Fila Mobile e Loja Demonstração (Ago 2026)
- **Tradução de apresentação**: criado `translateTechnicalValue` em `frontend/src/lib/i18n.js` para converter enums/status/eventos técnicos em PT-BR apenas na camada visual, preservando valores originais no MongoDB.
- **Painel principal (`TenantDashboard.jsx`)**: cards maiores e mais legíveis, grids responsivos, filtro de unidade/vendedor/período, botão **Atualizar**, indicação de última atualização e auto-refresh suave de 5 minutos sem desmontar os cards.
- **Gráfico no painel**: widget “Fluxo de oportunidades por horário” incorporado ao dashboard usando o endpoint real `/reports/opportunity-flow`, com KPIs de oportunidades, convertidas, conversão e receita quando permitido.
- **Fila mobile (`QueuePage.jsx`)**: handles de 3 pontos ganharam `data-testid`, acessibilidade e threshold de arraste; em celular, uma faixa fixa de dropzones aparece durante o drag para permitir mover da Fila Geral para Fora/Disponíveis/Fila sem depender de áreas fora da tela.
- **Janela de Saída mobile**: modal responsivo corrigido para não cortar conteúdo/botões em 390px.
- **Seed idempotente de apresentação (`seed_presentation_demo`)**: tenant demo passa a se chamar **Loja Demonstração**, com 3 unidades (Centro, Norte, Sul), 7 vendedores em estados variados e histórico realista de 7 dias com atendimentos, múltiplos, não sucessos, vendas e atendimento ativo. Reexecutar o seed não duplica dados.
- **Auth/CORS hardening**: backend CORS interno agora exige `CORS_ORIGINS`, habilita credenciais e login tenant passa a definir cookies HttpOnly mantendo tokens JSON. Seed de usuários atualiza hash somente quando necessário.
- **Validação**: build frontend OK; `py_compile` backend OK; seed rodou duas vezes sem duplicar (`106` atendimentos seeded antes/depois); API dashboard/opportunity-flow retornou 200; smoke visual do dashboard aprovado; drag mobile validado abrindo/cancelando Janela de Saída; suíte local `test_prompt72_demo_dashboard_queue.py` passou `9/9` contra backend direto.
- **Observação de preview**: o proxy público/Cloudflare do ambiente de preview intercepta `OPTIONS` antes do FastAPI e retorna CORS wildcard; internamente o backend responde corretamente com origem explícita e `Access-Control-Allow-Credentials: true`. O app usa fluxo same-origin `/api` e está funcional no preview.

### Ajuste visual — Fontes dos cards do Painel Principal (Ago 2026)
- **TenantDashboard**: labels e valores dos cards de métricas receberam classes específicas (`dashboard-metric-label` e `dashboard-metric-num`) com `clamp()` baseado no container, deixando os números e títulos mais visíveis sem quebrar o grid responsivo.
- **Validação**: build frontend OK; screenshot desktop do `/demo/dashboard` aprovado; verificado `overflow_horizontal=false` após carregamento dos dados.

### Ajuste visual — Largura útil ampliada do Painel Principal (Ago 2026)
- **Container desktop**: `page-container` quando contém `tenant-dashboard` agora usa largura fluida até `1800px`, com área útil medida de ~`1750px` em viewport 1920px e padding lateral responsivo entre 24px e 32px.
- **Alinhamento único**: cabeçalho verde, cards, filtros, KPIs, gráfico e blocos inferiores compartilham o mesmo eixo horizontal no painel.
- **Redistribuição de cards**: `metric-grid-wide` usa `auto-fit` para esticar cards quando houver menos itens e manter 8 KPIs em uma linha quando houver espaço.
- **Legibilidade**: título do cabeçalho, labels e números do dashboard foram ampliados; valores monetários agora permanecem em uma linha sem quebra ruim.
- **Validação**: desktop 1920px medido com `shellWidth=1750`, `heroWidth=1750`, `kpiRows=1`, `overflow=false`; mobile 390px medido com `shellWidth=358`, `overflow=false`; build frontend OK.

### Ajuste visual — Proporção de KPIs conforme referência (Ago 2026)
- **Cards do Painel Geral**: proporção visual dos KPIs ajustada para ficar mais próxima da referência enviada, com cards mais altos, labels mais fortes e números simples em destaque grande.
- **Valores longos protegidos**: `Metric` agora diferencia valores curtos, longos e extra-longos para manter moeda e ticket médio em uma linha, sem corte ou sobreposição.
- **Responsividade preservada**: desktop validado sem overflow e com valores cabendo nos cards; mobile 390px validado sem rolagem horizontal e com cards empilhados harmonicamente.
- **Validação**: `yarn build` OK; screenshot desktop/mobile aprovado.

### Refinamento visual — Hierarquia e preenchimento dos cards KPI (Ago 2026)
- **Escala dos KPIs**: números curtos dos cards do dashboard foram ampliados para serem o elemento dominante, com títulos também maiores e mais legíveis.
- **Distribuição interna**: cards usam espaçamento vertical compacto com título no topo e valor ancorado na região inferior, reduzindo sensação de vazio sem encostar conteúdo nas bordas.
- **Tamanho adaptativo**: valores monetários e textos longos usam classes de escala segura (`dashboard-metric-num-long`/`xlong`) para permanecer em uma única linha.
- **Validação**: desktop 1920px, tablet 768px e mobile 390px testados sem overflow horizontal; valores monetários, porcentagem, PA e quantidade cabem nos cards; build frontend OK.

### Correção visual — Overflow em Total Vendido e Ticket Médio (Ago 2026)
- **Valores monetários**: o componente `Metric` passou a identificar valores com `R$` e aplicar escalas específicas (`dashboard-metric-num-money` e `dashboard-metric-num-money-lg`) para caberem em uma única linha.
- **Equilíbrio geral**: números dos KPIs foram reduzidos moderadamente para um tamanho intermediário, mantendo destaque sem parecerem grandes demais.
- **Espaçamento interno**: padding horizontal dos cards foi calibrado para dar respiro lateral a moedas como `R$ 53.957,50` e `R$ 5.395,75`, sem aumentar largura individual nem alterar grid.
- **Validação**: desktop 1920px e mobile 390px testados; `TOTAL VENDIDO`, `TICKET MÉDIO` e KPIs numéricos cabem nos cards; `overflow=false`; build frontend OK.

### Ajuste layout desktop — Cards financeiros centralizados (Ago 2026)
- **Aplicação somente desktop**: em telas `>=1280px`, o grid comercial usa 12 colunas para manter seis indicadores operacionais na primeira linha: Atendimentos, Em andamento, Vendas, Conversão, PA e Qtd. Produtos.
- **Centralização financeira**: `Total Vendido` e `Ticket Médio` ocupam a segunda linha central, cada um com 25% da largura útil, deixando aproximadamente 25% de espaço livre em cada lateral, sem criar cards vazios nem duplicar componentes.
- **Preservação mobile/tablet**: abaixo de 1280px, o comportamento responsivo e a ordem DOM original permanecem iguais.
- **Validação**: testado em 1280×720, 1366×768, 1440×900, 1920×1080, tablet 768×900 e mobile 390×844; sem overflow horizontal; cards financeiros com mesma largura/altura e valores em uma linha; build frontend OK.

### Ajuste layout desktop — Financeiros no topo em 50/50 (Ago 2026)
- **Inversão desktop**: em telas `>=1280px`, `Total Vendido` e `Ticket Médio` agora ocupam a primeira linha do grid comercial, lado a lado, cada um com 6 de 12 colunas (`50%`).
- **Operacionais na segunda linha**: `Atendimentos`, `Em andamento`, `Vendas`, `Conversão`, `PA` e `Qtd. Produtos` ocupam a segunda linha, cada um com 2 de 12 colunas, preenchendo toda a largura sem espaços laterais.
- **Sem alterações funcionais**: nenhum cálculo, valor, consulta, filtro, formatação monetária, permissão ou componente de dados foi modificado; apenas CSS Grid reposiciona os cards existentes.
- **Responsividade preservada**: abaixo de 1280px, a ordem e o comportamento responsivo existentes permanecem inalterados.
- **Validação**: testado em 1280×720, 1366×768, 1440×900, 1920×1080, tablet 768×900 e mobile 390×844; sem overflow horizontal; financeiros com mesma largura/altura e valores completos em uma linha; build frontend OK.

### Correção definitiva — Metas no Painel do Vendedor (Ago 2026)
- **Fonte única backend**: `goals_service.py` passou a decorar e recalcular metas antes das respostas de `/goals`, `/goals/{id}` e `/my-performance`, eliminando dependência de recálculo manual pelo frontend/vendedor.
- **Status PT-BR obrigatórios**: respostas agora incluem `status_label` com os rótulos exatos `Agendada`, `Em andamento`, `Atingida`, `Encerrada sem atingir`, `Pausada`, `Cancelada`; filtros aceitam status interno e PT-BR.
- **Escopos aplicáveis ao vendedor**: criada fonte central `list_applicable_goals_for_seller`, usada tanto no Painel do Vendedor quanto na lista de metas, cobrindo metas individuais, de unidade e de equipe, sem vazar metas individuais de outros vendedores.
- **Progresso consistente**: respostas incluem `progress_pct` como alias de `progress_percent`; `MyPerformancePage.jsx` passou a usar `progress_percent/progress_pct` corretamente, resolvendo progresso zerado/desatualizado no módulo de Metas.
- **Timezone de unidade**: cálculo de período usa timezone da unidade/equipe/vendedor quando disponível (`America/Sao_Paulo` na demo), evitando limites UTC incorretos para início/fim de metas.
- **Tempo real**: `MyPerformancePage.jsx` assina `goals.updated` e `dashboard.updated`; fluxos de atendimento/venda recalculam metas e emitem `goals.updated` após atualização. Em múltiplos atendimentos, removido evento prematuro antes do recálculo.
- **UI somente leitura para vendedor**: vendedor visualiza metas aplicáveis em `/demo/my-performance` e `/demo/goals` sem botões de criar/editar/cancelar/recalcular quando não possui permissão.
- **Limpeza de temporários**: metas temporárias de testes com prefixo `TEST_`/`Teste 100%`/`Teste 120%`/`Teste Meta` foram removidas da demo para não contaminar o painel.
- **Validação**: `testing_agent` iteration 71 passou backend `7/7` + frontend; build frontend OK; `pytest test_prompt4_goals_progress.py + test_etapa9_goals_rankings_gamification.py` passou `10/10` executados; `test_multiple_attendances.py` passou `2/2`.

### Correção — Atendimento por Preferência disponível para Vendedor (Ago 2026)
- **Causa raiz**: o endpoint `start-preference-attendance` restringia início a perfis gerenciais e a UI ocultava a ação do perfil `SELLER`; além disso, existia inconsistência possível entre `queue_entries` e `seller_profiles.current_status`, fazendo a UI mostrar vendedor na fila enquanto o backend via `DISPONIVEL`.
- **Backend (`routes_queue.py`)**: perfil `SELLER` agora pode iniciar preferência para si próprio; o vendedor autenticado é determinado pela sessão (`_own_seller_id`) e qualquer tentativa de enviar `seller_id` de outro vendedor retorna 403.
- **Backend (`queue_engine.py`)**: `start_preference_attendance` e `sair_da_fila` normalizam o caso seguro `current_status=AVAILABLE + queue_entry WAITING` para `WAITING_IN_QUEUE`, evitando bloqueios falsos em preferência e Atividade Operacional.
- **Configuração**: adicionado `preference_enabled=true` como padrão efetivo e validação backend `PREFERENCE_DISABLED`; toggle exposto em `/demo/settings` e `/demo/store-settings` com `data-testid="q-preference-enabled"`.
- **Frontend (`QueuePage.jsx`)**: vendedor vê botão **Iniciar preferência**; quando inválido, botão permanece visível/desabilitado com motivo claro (`preference-disabled-reason`), incluindo “Você está em pausa.” para Atividade Operacional.
- **Modal do vendedor**: vendedor não seleciona o próprio nome; modal exibe `preference-self-seller-box` com vendedor autenticado, posição atual e regra de retorno aplicada.
- **Validação**: `testing_agent` iteration 70 passou; regressão backend `6/6` em `test_preference_attendance_final_retest.py`; suíte local `tests/test_preference_attendance.py` passou `11/11`; mobile 390x844 aprovado sem overflow.

### Prompt 21 — Múltiplos Atendimentos — P0 funcional (Ago 2026)
- **Conceito de lote**: criada coleção `multiple_attendance_batches` para agrupar o lançamento sem contar o lote como atendimento; cada cliente gera um registro individual em `attendances` com `multiple_batch_id`, `multiple_sequence`, `is_multiple=true`, `multiple_mode`, `allocation_mode` e `allocation_method`.
- **Endpoint principal**: `POST /api/tenants/{slug}/stores/{store_id}/queue/finish-multiple-attendances` finaliza um atendimento ativo como lote múltiplo, reutilizando o atendimento ativo como sequência 1 e criando apenas os demais registros necessários.
- **Modos implementados**: `AGGREGATED` com totais e rateio técnico; `DETAILED` com linhas individuais de resultado/valor/produtos/observação.
- **Rateio agregado**: valores em centavos e produtos inteiros distribuídos por `EQUAL_WITH_REMAINDER`, preservando soma exata; vendas/atendimentos ficam marcados com `is_estimated_allocation=true` e sem criação de produtos fictícios.
- **Cenário obrigatório validado**: lote com 5 clientes, 3 sucessos, 2 não sucessos, R$ 600,00 e 9 produtos gerou exatamente 5 atendimentos, 3 vendas, receita `60000`, `item_count=9`, conversão 60% e PA 1,8.
- **Fila**: o vendedor tem a vez movimentada apenas uma vez ao final do lote; o atendimento ativo original não é duplicado; não há posição fantasma por cliente.
- **Validações**: limite inicial de 50 clientes, total > 0, `sucessos + não sucessos = total`, números não negativos, produtos inteiros, sem sucessos não permite receita/produtos, motivo obrigatório quando há não sucesso.
- **Idempotência**: endpoint usa `Idempotency-Key` com resposta completa serializável; retries não criam lote/atendimentos/vendas duplicados.
- **Vendas e métricas**: cada sucesso cria venda válida vinculada ao atendimento individual; `item_count` técnico é usado para produtos rateados sem `sale_items` fictícios; rankings passam a considerar `sales.item_count` quando não houver itens detalhados.
- **PA oficial atualizado para múltiplos**: relatório de PA passou a calcular produtos totais ÷ atendimentos válidos, alinhado ao Prompt 21 e ao cenário obrigatório.
- **Relatórios existentes**: `Fluxo de Oportunidades por Horário` reconhece `attendance_type=MULTIPLE` e conta atendimentos individualizados, não o lote; options inclui “Múltiplos atendimentos”.
- **Frontend (`QueuePage.jsx`)**: modal de finalização ganhou botão **Registrar múltiplos atendimentos**, formulário agregado/detalhado, resumo em tempo real, confirmação, limite 50 e validação responsiva.
- **UX mobile**: modal múltiplo usa posição segura em celular (`390x844` validado), sem overflow horizontal e com clique funcional no modo detalhado.
- **ResizeObserver**: `src/index.js` ignora o erro conhecido “ResizeObserver loop completed” para evitar overlay de runtime durante interação com o modal.
- **Índices**: adicionados `multiple_attendance_batches(tenant_id,idempotency_key)` e `attendances(tenant_id,multiple_batch_id)`.
- **Validação**: `testing_agent` iteration 66 apontou filtro MULTIPLE/mobile; corrigido e retestado na iteration 67 com backend `5/5`, frontend desktop/mobile aprovado, `tests/test_multiple_attendances.py` `2/2`, build frontend OK com warnings antigos.

### Prompt 20 — Atendimento por Preferência (Ago 2026)
- **Fluxo operacional**: criado endpoint `POST /api/tenants/{slug}/stores/{store_id}/queue/start-preference-attendance` para iniciar atendimento quando o cliente procura um vendedor específico, usando `source/origin/attendance_type = PREFERENCE` e `is_preference=true`.
- **Validações backend**: vendedor precisa pertencer ao tenant/unidade, estar ativo, na Fila Geral, em jornada ativa, sem atividade operacional/pausa e sem atendimento ativo; controle por `seller_lock` impede dois inícios simultâneos para o mesmo vendedor.
- **Snapshot da fila**: ao iniciar, o atendimento registra posição anterior, vendedor anterior, vendedor posterior, tamanho da fila, versão da fila, fila/unidade e regra vigente de retorno.
- **Regras de retorno**: suporte a `TO_TOP`, `PREVIOUS_POSITION` (padrão), `TO_END` e `CONSUME_TURN`; “Perder a vez” reutiliza a lógica atual de retorno ao fim da fila e grava `preference_turn_consumed=true`.
- **Finalização e cancelamento**: usam os fluxos existentes de `finish-attendance`/cancelamento, com reposicionamento atômico no backend, registro da posição final, método aplicado, versão final e falhas de reinserção quando vendedor/fila ficam indisponíveis.
- **Idempotência**: início por preferência usa `Idempotency-Key` e agora grava resposta completa serializável, compatível com índice legado `key`, evitando duplicidade em clique duplo/retry.
- **Tempo real e auditoria**: publica eventos de preferência/fila (`attendance.preference_started`, `queue.updated`, `PREFERENCE_RETURN_APPLIED`) e registra auditoria do início e retorno aplicado.
- **Configuração administrativa**: `StoreSettings.jsx` e `routes_store_settings.py` adicionam “Retorno após atendimento por preferência”, com valor salvo em `queue_settings.preference_return_rule`; alterações futuras não afetam atendimentos já iniciados.
- **Interface da fila**: `QueuePage.jsx` adiciona botão **Preferência**, modal responsivo com cliente, telefone, vendedor procurado, impacto na fila e confirmação; atendimento ativo recebe badge **Preferência**.
- **Relatório específico**: `GET /api/tenants/{slug}/reports/preference-attendances` + exportações CSV/XLSX; página **Relatórios → Atendimentos por Preferência** com KPIs, gráficos por regra/vendedor, tabela e exportação.
- **Índices**: adicionados/reutilizados índices para `attendances(tenant_id,is_preference,started_at)`, `attendances(tenant_id,seller_id,status)` e `queue_entries(tenant_id,queue_id,seller_id,status)`.
- **Validação**: `testing_agent` iteration 65 encontrou idempotência e mobile; corrigido em seguida. Regressão local `/app/backend/tests/test_preference_attendance.py` passou `10/10`, build frontend passou, modal mobile validado sem overflow horizontal.

### Relatório — Fluxo de Oportunidades por Horário (Ago 2026)
- **Backend (`opportunity_flow_service.py`)**: agregação real em MongoDB usando `attendances.started_at` como horário de referência da oportunidade; cada atendimento iniciado válido conta como 1 oportunidade.
- **Status documentados**: entram `IN_PROGRESS` e `FINISHED`; `CANCELLED` fica fora do relatório; vendas válidas usam `COMPLETED`, `CONFIRMED` e `FINISHED` quando vinculadas ao atendimento.
- **Conversão correta**: `oportunidades convertidas ÷ oportunidades × 100`, contando cada atendimento convertido uma única vez, mesmo com múltiplas vendas, com proteção contra NaN/infinito e limite máximo de 100%.
- **Receita por oportunidade**: vendas vinculadas permanecem agrupadas no horário de início do atendimento, mesmo quando registradas depois; vendas sem atendimento ficam em `data_quality.sales_without_attendance`.
- **Timezone e granularidade**: período interpretado em `America/Sao_Paulo` da unidade/empresa; granularidade automática por hora/dia/semana/mês; intervalos vazios preenchidos com zero e horas futuras excluídas da média.
- **Segurança e permissões**: escopo por tenant e unidades acessíveis no backend; filtros por unidade/equipe/vendedor/tipo validados no servidor; campos financeiros condicionados a permissões `sales.view_*`.
- **Exportação**: endpoints CSV e XLSX reutilizam a mesma agregação do relatório para evitar divergências.
- **Frontend (`OpportunityFlowReport.jsx`)**: página em **Relatórios → Fluxo por Horário** com filtros, KPIs, gráfico combinado colunas+linha, gráfico secundário de receita, mapa de horários, tabela analítica, legenda interativa e exportação.
- **Índices adicionados**: `attendances(tenant_id, started_at)`, `attendances(tenant_id, store_id, started_at)`, `attendances(tenant_id, seller_id, started_at)`, `sales(tenant_id, attendance_id, status)`, `sales(tenant_id, created_at, attendance_id)`.
- **Limitação documentada**: atendimentos atuais não guardam `team_id` histórico; filtros por equipe usam a equipe atual do vendedor sem migração destrutiva.
- **Validação**: `testing_agent` iteration 64 passou backend + frontend; pytest do relatório passou `13/13`; build frontend passou com warnings antigos; desktop e mobile sem overflow horizontal.
- **Correção colateral**: `RealtimeTenantContext.jsx` ajustado para não fechar WebSocket ainda em conexão durante desmontagem, eliminando warning recorrente observado nos testes.

### Prompt 3 — Motivos de perda hierárquicos livres — P0 funcional (Ago 2026)
- **Arquitetura criada**: novas coleções MongoDB em português (`grupos_motivos_perda`, `subgrupos_motivos_perda`, `motivos_perda`, `historico_administrativo_motivos_perda`) com identificadores, empresa, ordem, ativo, datas e usuário responsável.
- **Servidor**: novo `routes_motivos_perda.py` + `motivos_perda_service.py` com CRUD, validação de duplicidade normalizada, ativação/desativação, ordenação por botões, exclusão segura, visualização de uso e isolamento por empresa.
- **Estrutura livre**: nenhum grupo/subgrupo/motivo predefinido foi criado pelo sistema; estrutura validada com exemplo `Roupa → Calça → Faltou tamanho`.
- **Finalização de atendimento**: `QueuePage.jsx`, `queue_engine.py`, `routes_queue.py` e `models.py` agora aceitam `grupo_motivo_perda_id`, `subgrupo_motivo_perda_id`, `motivo_perda_id`, `descricao_complementar` para resultado **Não sucesso**.
- **Histórico preservado**: atendimentos finalizados armazenam IDs e nomes históricos (`grupo_motivo_perda_nome_historico`, `subgrupo_motivo_perda_nome_historico`, `motivo_perda_nome_historico`) para não sofrerem alteração retroativa.
- **Descrição complementar configurável**: cada motivo pode exigir descrição e definir limite; servidor rejeita espaços vazios e textos acima do limite.
- **Administração**: tela `/demo/loss-reasons` redesenhada como **Configurações → Motivos de perda**, com pesquisar, filtrar ativos/inativos, expandir/recolher, criar/editar/ordenar/ativar/desativar/excluir/ver uso.
- **Transição preservada**: motivos antigos continuam funcionando quando ainda não existe uma combinação ativa completa na nova hierarquia.
- **Relatórios**: relatórios de atendimentos e motivos de perda exibem hierarquia nova quando disponível, com fallback para motivos antigos.
- **Validação**: `testing_agent` iteration 62 passou backend + frontend; suíte `/app/backend/tests/test_prompt3_loss_reasons_hierarchy.py` passou `12/12`; build frontend passou com apenas warnings antigos já existentes.

### Correção — Desfazer ao Encerrar o dia na Janela de Saída (Ago 2026)
- **Frontend (`QueuePage.jsx`)**: motivo **Encerrar o dia** agora exibe o mesmo toast **Desfazer (20s)** usado em Lanche/Almoço e Atividade Operacional.
- **Fluxo de undo**: ao desfazer Encerrar o dia, o sistema chama `nova-jornada` e em seguida `join`, devolvendo o vendedor à Fila Geral e limpando `jornada_encerrada`.
- **UX**: descrição do motivo atualizada para informar o desfazer por 20 segundos; modal da Janela de Saída recebeu rolagem interna para não cortar o botão Confirmar saída.
- **Validação**: `testing_agent` iteration 63 passou frontend + backend; regressão `/app/backend/tests/test_queue_exit_undo_regression.py` passou `4/4`.

### Correção — Botão Iniciar com topo em Atividade Operacional (Ago 2026)
- **Frontend (`QueuePage.jsx`)**: o botão **Iniciar** do perfil Vendedor agora considera o primeiro vendedor realmente disponível na Fila Geral, ignorando posições anteriores marcadas como **Em atividade operacional**.
- **Backend (`queue_engine.py`)**: vendedores podem iniciar o próprio atendimento fora da posição 1 quando todos os vendedores anteriores estão com `em_atividade_operacional=true`; a regra continua bloqueando quando existe vendedor anterior apto.
- **Regressões protegidas**: adicionado teste `/app/backend/tests/test_queue_operational_skip_start.py` cobrindo liberação do próximo disponível, bloqueio quando o anterior não está operacional e bloqueio do vendedor operacional iniciar a si mesmo.
- **Validação**: `testing_agent` iteration 61 passou backend + frontend; pytest local da regressão passou `3/3`.

### Prompt 4 — Correção Sistêmica do Progresso de Metas (Ago 2026)
- **`_compute_goal_progress`**: nova função única (substitui `_compute_current_value`) em `goals_service.py` usando aggregation pipelines MongoDB (sem fetch em memória). Cobre REVENUE, SALES_COUNT, ATTENDANCES, ITEMS_SOLD, AVERAGE_TICKET, CONVERSION para todos os escopos (TENANT, STORE, TEAM, SELLER).
- **Sem cap a 100%**: `_compute_progress_pct` retorna valor real (ex: 120% quando meta superada). Frontend capeia barra visual em 100% mas exibe texto real.
- **Triggers de recálculo**: `create_goal`, `update_goal` (target_value), `recalculate_goal`, `finish_attendance`, `cancel_attendance` (novo), `proactive_approach_service`.
- **WebSocket `goals.updated`**: emitido após cada `_refresh_goal` → frontend auto-atualiza sem refresh.
- **Frontend auto-refresh**: `GoalsList` e `GoalDetail` subscrevem `goals.updated` via `useRealtimeTenant`.
- **`achievement_service`**: `calculate_metric_for_seller` corrigida — usa `finished_at` (consistente), `item_count` de `sales` (correto), aggregation pipelines.

### Prompt 2 — Redesenho Completo da Fila da Vez (Ago 2026)
- **Backend**: Máquina de estados em PT-BR — `DISPONIVEL`, `NA_FILA_GERAL`, `EM_ATENDIMENTO`, `FORA`, `EM_ATIVIDADE_OPERACIONAL`
- **Novos endpoints**: `/sair-da-fila`, `/retornar-da-fora`, `/nova-jornada`, `/retornar-operacao`
- **Janela de Saída obrigatória**: modal com 3 motivos (Lanche/Almoço, Atividade Operacional, Encerrar o Dia), com ícone + descrição, confirmação obrigatória — `data-testid="janela-saida-modal"`
- **Drag-and-Drop**: arrastar da zona Disponível → Fila Geral (com Desfazer); Fila → Fora (abre Janela de Saída); Fora → Fila (retorna ao fim); Disponível → Fora bloqueado com toast de erro
- **Desfazer (Undo) 20s**: componente `UndoToast` com contador regressivo ao vivo; botão `data-testid="undo-btn"` aparece após: entrar na fila (undo → sair), sair por Lanche (undo → retornar), sair por Atividade Operacional (undo → retornar operação), retornar à operação (undo → atividade operacional) e Encerrar Dia (undo → nova jornada + retornar à Fila Geral)
- **Subestado Atividade Operacional**: badge visual laranja na fila, botão "Retornar à operação", bloqueio de atendimento nesse subestado

### Responsividade Global de Cards (Jul 2026 — Prompt CORREÇÃO SISTÊMICA)
- Classes CSS centralizadas: `.metric-card-wrap` (container-type: inline-size), `.metric-num` (clamp 14px→30px via cqi), `.metric-num-lg` (clamp 24px→48px), `.metric-grid*` (auto-fill minmax) — em `index.css`
- Componente `MetricCard` global adicionado em `Common.jsx`
- `Metric` (TenantDashboard.jsx), `KpiCard` (MyPerformancePage.jsx), `SummaryCard` (ProactivityPage, PAReport), `KPI` (ProactivityReport), `SummaryCard` (AlertsPage) — todos refatorados para usar `metric-num`
- Grids fixos (`grid-cols-8`, `grid-cols-6`, `grid-cols-5`) substituídos por `.metric-grid` / `.metric-grid-sm` com `auto-fill`
- `GoalDetail.jsx`: `text-5xl` → `metric-num-lg`
- `MyPerformancePage.jsx`: `text-5xl font-black truncate` (ranking) → `metric-num-lg` sem truncate
- Relatórios (AttendancesReport, ConversionReport, ProductsReport, PAReport, ProactivityReport, MyProactivityPage) — todos atualizados
- **Email editável**: `TenantUserUpdate` (models.py) + `update_user` (routes_tenant.py) — validação de duplicidade, isolamento por tenant. Frontend: campo editável em UsersList.jsx
- **SellerAvatar**: componente global em Common.jsx com foto, iniciais como fallback, tamanho configurável; aplicado globalmente em AttendancesList, QueuePage (fila, disponíveis, fora/pausa, em atendimento), RankingsPage e SalesList. Backend: `queue_engine._enrich()` usa `users.avatar_url` corretamente; `ranking_service.py` refatorado com bulk fetch (sem N+1) retornando `seller_avatar_url`; `routes_sales._enrich()` retorna `seller_avatar_url`
- **Venda sem produto**: `sales_service.py` permite `net=0`; `queue_engine.py` usa `use_detailed=True` sempre que `sale` é fornecido, independente de itens
- **Qtd. produtos no Painel**: backend já retornava `total_produtos_vendidos`; card adicionado em TenantDashboard.jsx (`metric-total-products`)
- **Coluna Qtd. produtos em Atendimentos**: `routes_attendances.py` retorna `product_quantity`; coluna `att-product-qty-{id}` adicionada em AttendancesList.jsx
- **Metas de unidade/equipe para vendedores**: `routes_goals.py` usa `$or` (SELLER individual + STORE + TEAM); badges de escopo coloridos em GoalsList.jsx; notificação automática via `_notify_sellers_for_collective_goal`
- **Animação de conquista**: `GamificationPage.jsx` — confete via `canvas-confetti` ao detectar novos desbloqueios; persiste IDs em sessionStorage para não repetir; respeita `prefers-reduced-motion`; toast com nome da conquista
- Tokens de design Luppa implementados em `tailwind.config.js` e `index.css` (cores, fontes Geist, CSS vars)
- Componentes ShadCN atualizados (button, badge, card, input, dialog, dropdown-menu)
- Navegação convertida de sidebar para topbar
- `TenantLayout.jsx` e `SuperAdminLayout.jsx` redesenhados: header creme (#EBEBEA) + corpo escuro (#1A1A1A)
- Logo `luppa-logo.webp` integrada em todos os pontos: topbar, loading, mobile drawer
- Páginas de login (`TenantLogin.jsx`, `SuperAdminLogin.jsx`): texto "Luppa" substituído pela imagem da logo
- Credenciais de demo removidas da UI pública (não aparecem mais na tela de login)

### Setup Inicial (Jul 2026)
- Repositório importado e configurado
- .env criado para frontend e backend
- Migrations/seed aplicados (`SEED_DEMO_DATA=true`)
- Aplicação iniciada via Supervisor

### Correções (Jul 2026)
- Fix `navigator.clipboard.writeText()` → fallback `execCommand('copy')` no `TenantsList.jsx`
- Instalação de `aiosmtplib==5.1.2` (faltava no requirements.txt)
- Diagnóstico SMTP Gmail: IP GCP (104.198.214.223) + credenciais

### Correção Sistema de E-mail v2 (Jul 2026)
**Causas raiz corrigidas:**
1. `email_service.py` L345/L419: modo log retornava `DELIVERED` → corrigido para `LOGGED`
2. `external_notification_service.py`: SMTP aceito retornava `DELIVERED` → corrigido para `ACCEPTED`
3. `external_notification_service.py`: `{"status":"sent"}` retornado após falha → corrigido para `"failed"`
4. Nomenclatura unificada: `SMTP_PASSWORD`/`SMTP_TLS` (novos) com aliases `SMTP_PASS`/`SMTP_SECURE` (compatibilidade)
5. Endpoint de teste SMTP bloqueia durante impersonação (HTTP 403)
6. Retentativas com backoff exponencial (1s, 2s, 4s…), sem retry para erros permanentes
7. Nenhuma credencial nos logs ou respostas

**Arquivos criados/modificados:**
- `email_config.py` (NOVO): configuração centralizada e tipada
- `email_service.py`: reescrito com statuses corretos e retry
- `external_notification_service.py`: reescrito com retornos corretos
- `routes_super_admin.py`: SmtpConfigPayload atualizado + bloqueio de impersonação
- `server.py`: checks com novos nomes de variáveis
- `.env.example` (NOVO): documentação completa
- `tests/test_email_service_v2.py` (NOVO): 32 testes unitários
- `tests/test_smtp_email_endpoints.py` (NOVO pelo testing agent): 24 testes de integração
- `routes_super_admin.py`: endpoint `POST /api/super-admin/tenants/{id}/impersonate` — gera JWT com `is_impersonation=true` e `role=TENANT_ADMIN` (duração 4h)
- `ImpersonationBanner.jsx`: banner laranja com `startImpersonation()` / `stopImpersonation()` usando sessionStorage
- `TenantLayout.jsx`: banner integrado + fix de import `NotificationProvider` (bug pré-existente)
- `TenantsList.jsx`: botão "Entrar como" para tenants ACTIVE/TRIAL + item no dropdown
- `routes_google_auth.py`: endpoints `/api/auth/google/callback` e `/api/tenants/{slug}/auth/google/callback`
- `GoogleAuthCallback.jsx`: componente de callback para ambos os fluxos
- `App.js`: detecção de `#session_id=` no hash + rotas `/super-admin/auth/callback` e `/:slug/auth/callback`
- `SuperAdminLogin.jsx`: botão "Entrar com Google" (data-testid: `sa-google-login-button`)
- `TenantLogin.jsx`: botão "Entrar com Google" (data-testid: `tenant-google-login-button`)
- `AuthContext.jsx`: pula check `/me` quando há `session_id` no hash

### Quantidade de Produtos e Nomenclatura de Atendimento (Feb 2026)
- Adicionado campo `product_quantity: Optional[int]` em `FinishAttendanceRequest` e `QuickAttendanceRequest` (`models.py`)
- `queue_engine.py`: `finish_attendance` e `quick_attendance` aceitam e persistem `product_quantity` no MongoDB (somente quando `result == "SALE"`)
- `routes_queue.py`: repassa `product_quantity` para ambas as funções do engine
- `QueuePage.jsx`: labels "Venda" → "Sucesso" e "Não venda" → "Não sucesso" nos modais `FinishModal` e `QuickAttendanceModal`
- Campo "Quantidade de produtos" exibido antes do "Valor da venda" quando resultado = Sucesso (ambos os modais)

## Backlog Priorizado

### P0 — Bloqueado aguardando usuário
- Configurar provedor de e-mail real (Gmail falha por IP GCP — tentar Resend ou outro SMTP não-Gmail)

## AJUSTE VISUAL — Recoloração de marca Luppa (2026-09-21)

Usuário forneceu especificação visual completa (11 telas) via arquivo HTML. Análise via `design_agent` + comparação de código revelou que a paleta/tipografia Luppa (verde #006A4F, creme, lilás #E3DFFF, etc.) e a estrutura da tela de Fila JÁ estavam alinhadas ao arquivo — não foi uma reconstrução, só ajustes pontuais:
1. Badge "Preferência" na fila: amarelo → lilás (token `luppa-lilac`/`luppa-purple` já existente).
2. Botões de ação primários da fila (Iniciar, Entrar na fila, Retornar, Finalizar, Sair da fila, Registro Rápido, Preferência): 32-36px → `min-h-[44px]` (touch target da especificação).
3. Recoloração mecânica (script regex) de badges/status/ícones em **47 arquivos** (páginas + `badge.jsx`/`toast.jsx`) — cores genéricas do Tailwind (blue/purple/indigo/teal/yellow/orange/red/rose/pink) mapeadas para tokens Luppa: `luppa-green` (sucesso), `luppa-error` (erro/vermelho/rosa), `luppa-warning` (amarelo/laranja), `luppa-purple` (azul/roxo/índigo — neutro/info). `amber-*` foi mantido intencionalmente (já é visualmente ≈ luppa-warning).
Validado via `testing_agent` (iteração 78): 100% das telas testadas (tenant + super-admin) sem cores quebradas, sem regressão funcional, build sem erros.

### P1 — Próximas tarefas
- Refactor incremental dos ~30 arquivos pytest legados restantes em `/app/backend/tests/` (remover IDs hardcoded, usar fixtures dinâmicas) — `test_sale_no_product.py` já convertido nesta sessão como modelo.
- Otimizar cold-start do backend (re-seed idempotente faz ~200+ round-trips sequenciais contra Supabase remoto, ~3-4min pós-restart) — requer testes cuidadosos para não regredir a idempotência do seed.
- Adicionar lock/trava no `resend-invite` de super-admin (achado de baixa prioridade da auditoria — hoje sem lock, 10 chamadas simultâneas podem deixar mais de 1 convite ativo).
- Definir se o bloco **Metas** do Meu Painel deve manter resumo com 6 metas ou permitir expansão/listagem completa dentro do painel.
- Manter regressões de preferência do vendedor no CI para prevenir retorno da inconsistência fila/perfil
- Prompt 21 P1: agrupamento visual/expansão de lotes em histórico e relatórios, com badge “Atendimento múltiplo” em todas as listagens
- Prompt 21 P1: feed resumido único para lote múltiplo com ocultação de receita conforme permissão financeira
- Prompt 21 P2: edição/cancelamento de lote com recálculo idempotente de vendas, metas, conquistas, rankings e relatórios
- Prompt 20 P2: implementar verificação/reconciliação administrativa de inconsistências da fila (duplicidade, lacunas, retorno pendente)
- Prompt 20 P2: ampliar relatório com filtros por cliente/jornada e drill-down por evento de auditoria
- Validar/desenhar perfil de relatório sem permissão financeira, caso o negócio precise permitir relatório sem receita/ticket médio (matriz RBAC atual dá `sales.view_*` aos perfis com `reports.view_*`)
- Prompt 3 P1: criar etapa administrativa **Organizar motivos existentes** para migração manual dos motivos legados
- Prompt 3 P1: criar painel **Análise de perdas** com filtros dependentes por Grupo/Subgrupo/Motivo
- Prompt 3 P1: aprofundamento Grupo → Subgrupo → Motivo → Atendimentos e comparação por unidade/vendedor
- Implementar alerta quando vendedor atingir 80% de uma meta
- Revisão fina de termos técnicos restantes em páginas administrativas pouco usadas
- Landing page ou Tenant Selector na raiz `/`
- Desabilitar `SEED_DEMO_DATA` antes de produção
- Atualizar senha Super Admin antes de produção

### P2 — Futuro
- Exportação de relatório de metas por período/vendedor em Excel/PDF
- Redis para produção (`REDIS_URL`) — atualmente usa adapter in-memory
- Corrigir warnings React `exhaustive-deps` (performance)
- Configurar Playwright E2E corretamente

## Credenciais de Teste
Ver `/app/memory/test_credentials.md`

## Endpoints-Chave
- `POST /api/auth/login` — Super Admin login
- `POST /api/auth/google/callback` — Super Admin Google login
- `POST /api/tenants/{slug}/auth/login` — Tenant login
- `POST /api/tenants/{slug}/auth/google/callback` — Tenant Google login
- `GET /api/tenants/{slug}/reports/opportunity-flow` — Relatório Fluxo de Oportunidades por Horário
- `GET /api/tenants/{slug}/reports/opportunity-flow/options` — Filtros encadeados do relatório
- `GET /api/tenants/{slug}/reports/opportunity-flow/export.csv` — Exportação CSV do relatório
- `GET /api/tenants/{slug}/reports/opportunity-flow/export.xlsx` — Exportação XLSX do relatório
- `POST /api/tenants/{slug}/stores/{store_id}/queue/start-preference-attendance` — Iniciar Atendimento por Preferência
- `POST /api/tenants/{slug}/stores/{store_id}/queue/finish-multiple-attendances` — Finalizar atendimento ativo como lote de múltiplos atendimentos
- `GET /api/tenants/{slug}/reports/preference-attendances` — Relatório Atendimentos por Preferência
- `GET /api/tenants/{slug}/reports/preference-attendances/export.csv` — Exportação CSV de preferência
- `GET /api/tenants/{slug}/reports/preference-attendances/export.xlsx` — Exportação XLSX de preferência
- `GET /api/tenants/{slug}/motivos-perda/estrutura` — Estrutura administrativa Grupo/Subgrupo/Motivo
- `GET /api/tenants/{slug}/motivos-perda/opcoes` — Opções ativas para finalizar Não sucesso
- `POST /api/tenants/{slug}/motivos-perda/grupos|subgrupos|motivos` — Cadastro livre da hierarquia
- `PATCH /api/tenants/{slug}/motivos-perda/{tipo}/{id}/mover` — Ordenação
- `GET /api/tenants/{slug}/motivos-perda/{tipo}/{id}/uso` — Visualizar uso
- `PUT /api/super-admin/system/smtp-config` — Salvar config SMTP
- `POST /api/super-admin/system/smtp-config/test` — Testar SMTP
- `POST /api/super-admin/tenants/{id}/resend-invite` — Reenviar convite

## MIGRAÇÃO DE BANCO — MongoDB → PostgreSQL/Supabase (2026-08-26)

**Pedido do usuário**: migrar persistência de MongoDB para PostgreSQL (Supabase, pooler us-east-2). Dados antigos poderiam ser descartados (sem necessidade de preservação/migração de dados existentes).

**Risco declarado ao usuário antes de iniciar**: a stack oficialmente suportada pela Emergent é MongoDB; Postgres/Supabase como banco principal não tem suporte documentado (backup/preview/deploy da plataforma não testados nesse cenário). Usuário aceitou o risco.

**Estratégia implementada**: dado o volume (73 coleções, ~25k linhas, zero camada ORM, tudo com acesso direto via dicts em `db.<collection>.<metodo>()`), foi construído `/app/backend/pg_shim/` — um adaptador de compatibilidade que replica a API assíncrona do Motor/PyMongo (find_one, find, insert_one, update_one, delete_one, find_one_and_update, find_one_and_delete, aggregate, create_index, distinct, replace_one, etc.) mas persiste os dados em tabelas PostgreSQL reais (uma tabela `doc_<collection>` por coleção, padrão `id TEXT, tenant_id TEXT, doc JSONB` + índices reais — únicos, parciais/sparse via expression indexes, GIN geral). Filtros Mongo (`$in`,`$or`,`$ne`,`$exists`, etc.) e pipelines de agregação (`$match`,`$group`,`$project`,`$lookup`,`$facet`,`$bucket`,`$unwind`, operadores de data) foram reimplementados em Python puro (`pg_shim/expr.py`, `pg_shim/pipeline.py`), com pushdown de filtros simples para SQL por performance. **Nenhuma linha de código de negócio foi alterada** (queue_engine.py, goals_service.py, achievement_service.py, todas as rotas, seed.py) — só `db.py` foi substituído.

**Infra**: `DATABASE_URL`/`SYNC_DATABASE_URL` adicionados a `backend/.env` (Supabase Session Pooler :5432). Alembic configurado (`alembic/versions/0001_initial_doc_store.py`) cria as 73 tabelas. `requirements.txt` atualizado (sqlalchemy, asyncpg, alembic, psycopg2-binary). Seed roda normalmente e popula dados demo frescos no Postgres (3 tenants, 13 usuários, 3 lojas, 106 atendimentos, 61 vendas).

**Validado (testing_agent, 21 endpoints + 3 e2e + smoke frontend, 100% passando)**: login (super admin/tenant admin/vendedor), dashboard KPIs, rankings (ITEMS_SOLD/REVENUE), relatório de fluxo de oportunidades (agregação complexa com $lookup/$facet), metas, achievements, motivos de perda, produtos, vendas, atendimentos, isolamento multi-tenant.

**Corrigido**: `scripts/backfill_p0_5.py` tinha 2 usos de `doc["_id"]` (padrão Mongo legado) causando KeyError no boot — corrigido para usar `doc["id"]`.

**Limitação conhecida/aceita**: latência maior por operação (Supabase remoto us-east-2 vs Mongo local) — cada round-trip ~150-250ms. Login "frio" logo após um restart pode levar 20-45s devido à contenção com o re-seed idempotente (que roda a cada boot e faz ~200+ round-trips sequenciais de verificação); após ~3 min de boot completo, operações normais ficam em ~1-2s. Não é um problema de uso contínuo, apenas do momento imediatamente pós-restart/deploy.

**Não migrado/não testado exaustivamente nesta rodada**: módulos de baixo tráfego (LGPD/privacidade, backup/restore, automação, MFA, alertas) já usam o mesmo pg_shim (portanto tecnicamente em Postgres), mas não foram exercitados no smoke de regressão; recomenda-se teste dedicado antes de depender deles em produção.

**MongoDB**: client Motor removido de `db.py`; pacotes `motor`/`pymongo` mantidos instalados (pymongo usado só para `ReturnDocument`/`DuplicateKeyError`, sem conexão real). `MONGO_URL`/`DB_NAME` preservados no `.env` (não usados, não removidos por regra de proteção de variáveis).


## AUDITORIA TÉCNICA COMPLETA — pós-migração Postgres (2026-08-27)

Auditoria solicitada pelo usuário cobrindo código, banco, duplicidade, concorrência, segurança/isolamento multi-tenant e fluxos críticos, com testes reais (não só revisão). Confirmado com o usuário: sem Next.js/Supabase Auth/RLS nativo real (isolamento é por tenant_id na aplicação); banco atual (dados demo) liberado para testes destrutivos com prefixo AUDIT_TEST.

**Bugs reais encontrados e corrigidos (com teste de concorrência real via asyncio.gather + testing_agent independente, 6/6 passou):**
1. **Duplicidade de produtos por SKU** — `create_product` fazia check-then-insert sem constraint no banco; 5 requisições simultâneas com o mesmo SKU criavam 2 produtos duplicados. Corrigido: índice único parcial `(tenant_id, sku)` no Postgres + `except DuplicateKeyError → 409` em `routes_products.py` (create e update).
2. **Duplicidade de vendedores por e-mail** — `create_seller` não capturava `DuplicateKeyError` no insert de `users`/`seller_profiles`; race concorrente causava 500 não tratado. Corrigido em `routes_sellers.py`.
3. **`pg_shim` incompleto** — `find_one(..., sort=...)` (usado por `resend-invite`) não era suportado pelo adaptador, causando 500. Corrigido em `pg_shim/collection.py`.
4. **Bug sistêmico de datas** — código legado passava objetos `datetime` Python brutos (não `.isoformat()`) para `expires_at` de convites/tokens (padrão válido no MongoDB/BSON, mas quebra ao serializar para JSONB). Corrigido na raiz: encoder JSON do `pg_shim` agora usa `.isoformat()`, e `pg_shim/expr.py` normaliza comparações `datetime` ↔ string ISO em `$gt/$gte/$lt/$lte/$eq/$ne`.
5. **`_write_conn` só tratava `UniqueViolationError` no INSERT**, não no UPDATE — corrigido para tratar em ambos.
6. **`scripts/backfill_p0_5.py`** — 3 usos de `doc["_id"]` (padrão Mongo legado) — corrigidos para `doc["id"]` (já havia 2 fixes na sessão de migração; mais 1 confirmado e corrigido nesta auditoria).
7. **Frontend — duplo clique/duplo submit** sem proteção em 5 telas (Features, Plans, LossReasons, Products, Sellers) — adicionado estado `saving`/`salvando` com `disabled` + texto "Salvando…"/"Criando…".

**Validado como correto (sem necessidade de correção):**
- Trava distribuída de fila (`seller_lock` via índice único em `queue_locks`) — 6 requisições simultâneas de "entrar na fila" resultam em exatamente 1 entrada, resto 409 `QUEUE_OPERATION_CONFLICT`.
- Isolamento multi-tenant — token de um tenant não acessa/lista recursos de outro tenant, nem via ID direto na URL (testado com tenant "demo" vs "demo-b").
- Nenhum campo sensível (`password_hash`) é exposto via API — sempre removido explicitamente no código antes da resposta (independente de projection do Mongo/Postgres).
- Rate limiting real em memória (AUTH_LOGIN 50/15min, SUPER_ADMIN_LOGIN 10/30min, lockout de conta 5 falhas/15min) — funcionando corretamente (não é bug; causou cascata de falsos-positivos ao rodar a suíte pytest legada inteira de uma vez).
- Build de produção do frontend (`yarn build`) passa limpo.
- Rotas administrativas sensíveis (`routes_admin_security.py`, `routes_admin_privacy.py`, `routes_super_admin.py`) protegidas via `dependencies=[Depends(require_super_admin)]` no nível do router.

**Não corrigido (baixa prioridade, documentado):**
- `plans.name` e `features` (super-admin, uso raro) não têm todos os caminhos de duplicidade tratados com `try/except` (constraint já existe para features; plans não tem unique index) — risco muito baixo (tela raramente usada, 1 super admin por vez).
- `push_subscriptions` (notificações push) tem check-then-insert sem constraint única — pior caso é notificação duplicada ocasional, não é dado crítico.
- Suíte pytest legada (`/app/backend/tests/`, 37 arquivos) tem múltiplos IDs hardcoded de antes do re-seed (ex.: `JOAO_SELLER_ID`) e expectativas antigas (versão da API, CORS wildcard, e-mail SMTP) — não são bugs, são débito técnico de testes desatualizados.

**Dados de teste**: todos os registros `AUDIT_TEST*`/`audit_test*`/`audit-test*` criados durante a auditoria (produtos, usuários, seller_profiles, tenant de teste, audit_logs, invite_tokens) foram removidos do banco ao final. Nenhum dado real foi apagado.

**Aprendizado operacional**: editar arquivos dentro de `/app/backend` (incl. `/app/backend/tests/`) dispara hot-reload do uvicorn, que recomeça o boot completo (~2-3 min por causa do re-seed idempotente contra Postgres remoto). Scripts de teste ad-hoc devem ficar fora de `/app/backend` (ex. `/app/scripts/` ou `/app/tests/`) para não disparar reloads durante iteração.

## FECHAMENTO DA AUDITORIA TÉCNICA — checklist final do usuário (2026-08-27)

Relatório completo com evidências em `/app/memory/AUDIT_REPORT.md`. Resumo dos 8 pontos solicitados:

1. **NULL SKU validado**: índice único parcial `(tenant_id,sku) WHERE sku IS NOT NULL` já permitia múltiplos produtos sem SKU corretamente — confirmado com 10 criações concorrentes, todas bem-sucedidas (nenhum falso 409).
2. **Regras de duplicidade de vendedor documentadas**: e-mail único global (`users.email`) + um `seller_profile` por `(tenant_id,user_id)`. Ver seção 2 do relatório.
3. **`plans` e `push_subscriptions` protegidos**: índice único novo em `plans.name` (+ 409 tratado) e em `push_subscriptions(tenant_id,user_id,endpoint)` (+ fallback retorna subscription existente em vez de duplicar).
4. **Refactor pytest**: `test_sale_no_product.py` convertido para fixtures dinâmicas (sem IDs hardcoded) — 3 passed + 1 skip esperado. Demais ~30 arquivos ficam como backlog P1 incremental (decisão do usuário: não bloquear o restante da auditoria).
5. **Arquitetura documentada**: seção 1 do relatório — stack real (React SPA + FastAPI + Postgres/Supabase via `pg_shim`, sem Next.js/RLS nativo), como o `pg_shim` funciona.
6. **Concorrência 10x**: script `/app/scripts/audit_concurrency_stress.py` cobrindo produtos (SKU duplicado e NULL), vendedores, planos, push, fila (join), início/fim de atendimento e reenvio de convite — **9/9 passou** após 3 correções de bugs reais (ver item 7).
7. **Cold start investigado**: medido em ~3-3min45s pós-restart (criação de índices + re-seed idempotente com round-trips sequenciais contra Supabase remoto). Causa raiz confirmada e documentada; otimização deixada como backlog (risco de regressão no seed idempotente).
8. **Relatório final entregue**: `/app/memory/AUDIT_REPORT.md` (documento completo) + resumo no chat.

**3 bugs reais adicionais encontrados e corrigidos durante o fechamento:**
- **Venda duplicada em `finish-attendance` concorrente** (crítico): faltava `seller_lock` no fluxo de finalização de atendimento — 10 requisições simultâneas no mesmo `attendance_id` criavam 10 vendas órfãs (só 1 "vencia" a transição de status). Corrigido em `queue_engine.finish_attendance`.
- **`pg_shim` nunca limpava locks/documentos sem campo `id`** (ex. `queue_locks`, que usa `lock_key`/`lock_id`): `UPDATE`/`DELETE` usavam `WHERE id = $1` com `id` sempre `NULL` para essas coleções → no-op silencioso. Corrigido: `pg_shim/collection.py` agora usa a coluna física `row_seq` (sempre não-nula) como identificador de linha para update/delete.
- **500 não tratado em criação de vendedor concorrente**: insert de `tenant_membership` não capturava `DuplicateKeyError`. Corrigido em `routes_sellers.create_seller`.

**Validação**: `testing_agent` iteração 75 passou 8/8 (regressão dos fluxos normais após as 3 correções + validação das 2 novas proteções); script de concorrência 10x self-testado 9/9; pytest `test_sale_no_product.py` (3 passed/1 skip) e `test_preference_attendance.py` (10/11, 1 falha pré-existente não relacionada). Dados `AUDIT_TEST*`/`AUDIT75_*` limpos do banco.

## CORREÇÃO — Fluxo de Oportunidades vazio para tenant "empresateste" (22 Set 2026)

**Causa raiz**: `pg_shim/expr.py` (adaptador Postgres) ignorava completamente o parâmetro `timezone` dos operadores de data estilo Mongo (`$dateToString`, `$hour`, `$dayOfWeek`, `$isoWeek`, `$isoWeekYear`, `$year`, `$month`, `$dayOfMonth`, `$minute`, `$second`), sempre calculando em UTC. O relatório `opportunity_flow_service.py` gera os intervalos de horário (buckets) em horário LOCAL (`America/Sao_Paulo`, UTC-3) via `_iter_intervalos`, mas a agregação no banco continuava classificando em UTC — desalinhamento de 3h que escondia oportunidades do mesmo dia (o corte "até agora" em horário local ficava sempre atrás do horário UTC correspondente aos dados). Tenant `empresateste` tinha atendimentos reais hoje, mas todos ficavam fora da janela de buckets exibida.
**Fix**: nova função `_apply_tz(dt, tz_name)` em `expr.py` (usa `zoneinfo.ZoneInfo`) aplicada em `_date_convert` ($dateToString/$dateFromString) e no bloco `$hour`/`$dayOfWeek`/etc antes de extrair hora/dia/formatar. Único arquivo que usa esses operadores com timezone é `opportunity_flow_service.py` (blast radius contido).
**Validação**: reprodução real via API confirmou `empresateste` passando de `totals.opportunities=0` para `4` (dados reais de hoje). Tenant `demo` sem regressão (16 oportunidades, revenue 225750 inalterado). `testing_agent` iteração 82: 24/24 testes backend passaram (granularidades hora/dia/semana/mês, filtros, export CSV/XLSX, comparação de período, heatmap, PA, dashboard, rankings, conversão, login) — nova suíte `/app/backend/tests/test_iter82_timezone_regression.py`.
**Achado colateral (não corrigido, baixa prioridade)**: `_MetricsMiddleware` (BaseHTTPMiddleware) ocasionalmente lança `RuntimeError: No response returned` sob desconexão de cliente/exaustão do pool asyncpg, surfaceado como 502 pelo Cloudflare — pré-existente, não é regressão deste fix.
