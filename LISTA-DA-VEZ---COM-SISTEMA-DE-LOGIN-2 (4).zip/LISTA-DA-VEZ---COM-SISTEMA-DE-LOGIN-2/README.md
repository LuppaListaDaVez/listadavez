# Lista da Vez SaaS — README Técnico (P0)

> **Versão:** 1.0.0-p0 — Gate de Produção Piloto  
> **Stack:** React + FastAPI + MongoDB | Arquitetura SaaS Multitenant

---

## Índice

1. [Visão Geral](#visão-geral)
2. [Variáveis de Ambiente Obrigatórias](#variáveis-de-ambiente-obrigatórias)
3. [Sessão Tenant-Scoped](#sessão-tenant-scoped)
4. [TENANT_SESSION_MISMATCH](#tenant_session_mismatch)
5. [Teste de Isolamento Multitenant](#teste-de-isolamento-multitenant)
6. [Teste de IDOR](#teste-de-idor)
7. [Rate Limiting](#rate-limiting)
8. [Idempotência (Idempotency-Key)](#idempotência-idempotency-key)
9. [Paginação](#paginação)
10. [Índices do Banco de Dados](#índices-do-banco-de-dados)
11. [Logs Estruturados e Request ID](#logs-estruturados-e-request-id)
12. [Health Checks](#health-checks)
13. [Backup e Restore](#backup-e-restore)
14. [Seed Demo](#seed-demo)
15. [Testes de Segurança P0](#testes-de-segurança-p0)
16. [CORS e Headers HTTP](#cors-e-headers-http)

---

## Visão Geral

**Lista da Vez** é uma plataforma SaaS multitenant para gestão de filas de vendas, atendimento e performance de equipes de varejo.

- **Frontend:** React (path-based routing por `/:tenantSlug`)
- **Backend:** FastAPI (Python 3.11+)
- **Banco:** MongoDB (PyMongo async)
- **Autenticação:** JWT HS256 com sessões tenant-scoped

---

## Variáveis de Ambiente Obrigatórias

O backend valida estas variáveis no boot e falha rapidamente se alguma estiver ausente:

```env
# ── Obrigatórias (falham em boot se ausentes) ──────────────────────────────
JWT_SECRET=<mínimo 32 chars aleatórios>
MONGO_URL=mongodb://...
DB_NAME=lista_da_vez

# ── Segurança (produção) ───────────────────────────────────────────────────
CORS_ORIGINS=https://seu-dominio.com,https://app.seu-dominio.com
ENVIRONMENT=production

# ── Proxy / Rate Limiting ──────────────────────────────────────────────────
# false (padrão): ignora X-Forwarded-For/X-Real-IP → usa request.client.host
#   Recomendado quando NÃO há proxy reverso na frente (previne falsificação de IP)
# true: confia nos headers de proxy → use somente atrás de Nginx/AWS ALB confiável
TRUST_PROXY_HEADERS=false

# ── Super Admin ────────────────────────────────────────────────────────────
SUPER_ADMIN_EMAIL=admin@suaempresa.com
SUPER_ADMIN_PASSWORD=SenhaForte!2024

# ── Seed / Demo ────────────────────────────────────────────────────────────
# true  → cria tenant demo, usuários demo e dados de exemplo (padrão para dev)
# false → pula dados demo (use em PRODUÇÃO)
SEED_DEMO_DATA=false
```

> **ATENÇÃO:** Em produção, defina `SEED_DEMO_DATA=false` para não criar usuários demo com senhas padrão.

---

## Sessão Tenant-Scoped

Todo token de acesso tenant contém:

```json
{
  "sub": "user_id",
  "user_id": "user_id",
  "email": "usuario@empresa.com",
  "auth_context": "TENANT",
  "tenant_id": "ten_xxx",
  "tenant_slug": "minha-empresa",
  "membership_id": "mem_xxx",
  "role": "TENANT_ADMIN",
  "session_id": "ses_xxx",
  "type": "access",
  "jti": "uuid",
  "iat": 1700000000,
  "exp": 1700000900
}
```

Token de Super Admin tem `auth_context = "SUPER_ADMIN"` e **não** contém `tenant_id`.

O **frontend** armazena o `authenticatedTenantSlug` e ao detectar troca de slug:
- Para WebSocket e polling
- Limpa dados cacheados
- Redireciona para `/{novoSlug}/login`

---

## TENANT_SESSION_MISMATCH

Se um token do tenant A tentar acessar um endpoint do tenant B:

```http
HTTP/1.1 401 Unauthorized

{
  "error": "TENANT_SESSION_MISMATCH",
  "message": "Sua sessão não pertence a esta empresa. Faça login novamente.",
  "action": "REAUTH_REQUIRED",
  "request_id": "req_abc123"
}
```

O evento é registrado em `security_events` para auditoria.

---

## Teste de Isolamento Multitenant

```bash
API=https://seu-dominio.com/api

# 1. Login no tenant A
TOKEN_A=$(curl -s -X POST "$API/tenants/empresa-a/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@empresa-a.com","password":"Senha123!"}' \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['access_token'])")

# 2. Tenta acessar tenant B com token A → deve retornar 401 TENANT_SESSION_MISMATCH
curl -s -X GET "$API/tenants/empresa-b/stores" \
  -H "Authorization: Bearer $TOKEN_A" | python3 -m json.tool
```

---

## Teste de IDOR

```bash
# 1. Obter ID de venda do tenant A
SALE_ID=$(curl -s -X GET "$API/tenants/empresa-a/sales?page_size=1" \
  -H "Authorization: Bearer $TOKEN_A" \
  | python3 -c "import sys,json; d=json.load(sys.stdin); print(d['items'][0]['id'])")

# 2. Login no tenant B
TOKEN_B=$(curl -s -X POST "$API/tenants/empresa-b/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@empresa-b.com","password":"Senha123!"}' \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['access_token'])")

# 3. Tenta acessar venda do tenant A com token B → deve retornar 403/404
curl -s -X GET "$API/tenants/empresa-b/sales/$SALE_ID" \
  -H "Authorization: Bearer $TOKEN_B" | python3 -m json.tool
```

---

## Rate Limiting

Implementado com sliding window em memória. Limites por grupo:

| Grupo               | Limite | Janela |
|---------------------|--------|--------|
| AUTH_LOGIN          | 50     | 15 min |
| AUTH_REFRESH        | 20     | 5 min  |
| SUPER_ADMIN_LOGIN   | 10     | 30 min |
| QUEUE_ACTIONS       | 120    | 1 min  |
| SALES_CREATE        | 60     | 1 min  |
| ATTENDANCE_START    | 60     | 1 min  |
| ATTENDANCE_FINISH   | 60     | 1 min  |
| ATTENDANCE_CANCEL   | 30     | 1 min  |
| REPORT_EXPORT       | 10     | 1 hora |
| NOTIFICATIONS       | 120    | 1 min  |
| GENERAL_API         | 600    | 1 min  |

Resposta ao exceder:

```json
{
  "error": "RATE_LIMIT_EXCEEDED",
  "message": "Muitas tentativas. Tente novamente em alguns instantes.",
  "retry_after_seconds": 60
}
```

Header `Retry-After` sempre presente na resposta 429.

> **Segurança — Detecção de IP:**  
> Por padrão (`TRUST_PROXY_HEADERS=false`) o rate limiting usa sempre o IP da conexão TCP direta (`request.client.host`), ignorando `X-Forwarded-For` e `X-Real-IP`.  
> Isso previne que atacantes falsifiquem o IP via header e burlem o limite.  
> Defina `TRUST_PROXY_HEADERS=true` **somente** se a aplicação estiver atrás de um proxy reverso confiável (Nginx, AWS ALB) que controla esses headers.

---

## Idempotência (Idempotency-Key)

Operações críticas aceitam o header `Idempotency-Key` para prevenir duplicatas:

**Operações cobertas:**
- `POST /queue/finish-attendance` (inclui criação de venda)

**Uso:**

```bash
curl -X POST "$API/tenants/demo/stores/$STORE_ID/queue/finish-attendance" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Idempotency-Key: $(uuidgen)" \
  -H "Content-Type: application/json" \
  -d '{"attendance_id":"att_xxx","result":"SALE","sale_amount_cents":10000}'
```

**Comportamento:**
- Mesma key + mesmo payload → retorna mesma resposta (sem criar duplicata)
- Mesma key + payload diferente → `409 IDEMPOTENCY_KEY_CONFLICT`
- TTL da key: 24 horas

---

## Paginação

Todos os endpoints de listagem suportam paginação. Limite máximo: **100 itens por página**.

**Parâmetros:**

| Parâmetro  | Padrão | Máximo | Descrição              |
|------------|--------|--------|------------------------|
| `page`     | 1      | —      | Número da página       |
| `page_size`| 50     | 100    | Itens por página       |

**Resposta:**

```json
{
  "items": [...],
  "pagination": {
    "page": 1,
    "page_size": 50,
    "total": 200,
    "has_next": true
  }
}
```

**Endpoints paginados:**
- `GET /tenants/{slug}/sales`
- `GET /tenants/{slug}/attendances`
- `GET /tenants/{slug}/feedbacks`
- `GET /tenants/{slug}/notifications`

---

## Índices do Banco de Dados

Índices compostos criados idempotentemente no boot via `db.py`:

### tenant_memberships
- `(tenant_id, user_id)` — unique
- `(tenant_id, role)`
- `(tenant_id, status)`

### stores
- `(tenant_id,)` — único por tenant
- `(tenant_id, status)`
- `(tenant_id, slug)` — sparse

### sales
- `(tenant_id, store_id, created_at)`
- `(tenant_id, seller_id, created_at)`
- `(tenant_id, source)` — sparse
- `(tenant_id, status)`

### attendances
- `(tenant_id, store_id, created_at)`
- `(tenant_id, seller_id, created_at)`
- `(tenant_id, status)`

### notifications
- `(tenant_id, user_id, read_at)`
- `(tenant_id, user_id, created_at)`
- `(tenant_id, event_type)` — sparse

### goals / rankings
- `(tenant_id, store_id)`
- `(tenant_id, seller_id)`
- `(tenant_id, period)`
- `(tenant_id, status)`

### audit_logs
- `(tenant_id, entity, created_at)`
- `(tenant_id, action, created_at)`
- `(tenant_id, user_id, created_at)`

---

## Logs Estruturados e Request ID

Toda requisição recebe um `X-Request-Id` único (retornado no header de resposta).

**Formato de log:**

```
2025-01-01 12:00:00 - lista-da-vez.requests - INFO -
HTTP POST /api/tenants/demo/stores 201 45ms
req=a1b2c3 tenant=demo user=usr_abc1 session=ses_xyz1
```

**Campos presentes em cada log:**
- `request_id` — ID único da requisição
- `method` — HTTP method
- `path` — URL path
- `status_code` — HTTP status
- `duration_ms` — tempo de resposta em ms
- `tenant` — slug ou id do tenant
- `user` — primeiros 8 chars do user_id (anonimizado)
- `session` — primeiros 8 chars do session_id (anonimizado)

**O que NÃO é logado:**
- Senhas
- Tokens de acesso / refresh
- Authorization header
- Dados pessoais sensíveis (CPF, telefone, e-mail completo)

---

## Health Checks

| Endpoint             | Descrição                             | Retorno      |
|----------------------|---------------------------------------|--------------|
| `GET /api/health`    | Status geral do serviço               | `200 ok`     |
| `GET /api/health/live` | Liveness probe (Kubernetes)         | `200 ok`     |
| `GET /api/health/ready` | Readiness probe + banco de dados   | `200` ou **`503`** |

O endpoint `/ready` retorna **HTTP 503** quando o banco de dados está inacessível:

```json
{
  "status": "degraded",
  "db": "unreachable"
}
```

---

## Backup e Restore

O serviço de backup (`backup_service.py`) suporta:

- **Backup manual:** via API `POST /tenants/{slug}/backups`
- **Backup automático:** configurável via política de retenção
- **Tipos:** `full`, `incremental`
- **Restore:** `POST /tenants/{slug}/backups/{id}/restore` (exige confirmação `CONFIRMO_RESTORE`)

**Logs de backup:**
- Registrados em `backup_snapshots`
- Campos: `status`, `checksum`, `tenant_id`, `started_at`, `completed_at`

**Para testar restore manualmente:**

```bash
# 1. Cria backup
curl -X POST "$API/tenants/demo/backups" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"backup_type": "full", "notes": "backup manual"}'

# 2. Restore com confirmação
curl -X POST "$API/tenants/demo/backups/$BACKUP_ID/restore" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"confirmation_text": "CONFIRMO_RESTORE"}'
```

---

## Seed Demo

O seed é controlado pela variável `SEED_DEMO_DATA`:

| Valor                | Comportamento                                                |
|----------------------|--------------------------------------------------------------|
| `true` (padrão dev)  | Cria tenant demo, usuários e dados de exemplo               |
| `false` (produção)   | Apenas dados essenciais: features, planos, super admin      |

**Dados sempre criados** (independente de `SEED_DEMO_DATA`):
- Feature catalog
- Planos de subscription
- Super Admin (via `SUPER_ADMIN_EMAIL` + `SUPER_ADMIN_PASSWORD`)

> **PRODUÇÃO:** Configure `SEED_DEMO_DATA=false` para garantir que nenhum usuário demo com senha padrão exista no ambiente de produção.

---

## Testes de Segurança P0

```bash
cd /app/backend
pip install pytest httpx
pytest tests/test_p0_security.py -v
```

**Testes incluídos:**
1. Health check retorna 200/503 corretamente
2. X-Request-Id presente em toda resposta
3. Headers de segurança (HSTS, X-Content-Type-Options, X-Frame-Options)
4. Cross-tenant retorna TENANT_SESSION_MISMATCH
5. IDOR: token B não acessa recursos do tenant A
6. Rate limit 429 após muitas tentativas de login
7. Idempotency-Key conflito retorna 409
8. Paginação com metadados e limite máximo 100
9. Erros sem stack trace
10. Request ID em respostas de erro
11. password_hash não exposto em rotas de usuário
12. Unauthenticated retorna 401, não 500
13. Token de Super Admin tem auth_context=SUPER_ADMIN

---

## CORS e Headers HTTP

**Headers de segurança** adicionados em toda resposta:

```
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Referrer-Policy: no-referrer
Permissions-Policy: camera=(), microphone=(), geolocation=()
Strict-Transport-Security: max-age=31536000; includeSubDomains
X-Request-Id: <unique-per-request>
```

**CORS:**
- Controlado pela variável `CORS_ORIGINS` (lista separada por vírgula)
- Em desenvolvimento, default é `*`
- **Em produção, sempre defina `CORS_ORIGINS` explicitamente**
- `credentials: false` (tokens via header Authorization, não cookies)

```env
# Produção
CORS_ORIGINS=https://app.suaempresa.com,https://suaempresa.com
```
