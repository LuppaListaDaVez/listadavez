"""
Audit iteration 75 — verifies new duplication protections and regression checks
after this session's fixes:

  A. Products with NULL sku can be created multiple times (no false 409).
  B. Products with duplicate SKU still return 409 (regression, already-fixed path).
  C. Super-admin plans: duplicate name -> 409 (NEW protection).
  D. Push subscriptions: same (tenant_id,user_id,endpoint) returns existing (NEW).
  E. REGRESSION: normal single-request queue flow join -> start -> finish (SALE)
     creates exactly 1 sale, attendance status FINISHED (validates seller_lock
     didn't break the happy path).
  F. REGRESSION: normal seller creation with a brand-new email succeeds (201).
  G. REGRESSION (pg_shim row_seq): PUT product update + PATCH seller status
     still work after moving row identifier from doc->>'id' to row_seq column.

Notes:
  - Runs against the public URL (REACT_APP_BACKEND_URL).
  - Reuses test_credentials.md accounts. Uses TEST_/AUDIT75_ prefix for cleanup.
  - Not under /app/backend/tests so uvicorn --reload doesn't watch this file.
"""
import os
import time
import uuid
import asyncio
import pytest
import requests
import httpx

BASE_URL = os.environ.get("REACT_APP_BACKEND_URL", "").rstrip("/")
if not BASE_URL:
    with open("/app/frontend/.env") as f:
        for line in f:
            if line.startswith("REACT_APP_BACKEND_URL="):
                BASE_URL = line.split("=", 1)[1].strip().rstrip("/")

TIMEOUT = 90
SUPER_ADMIN = {"email": "admin@listadavez.com", "password": "Admin@123456"}
TENANT = {"slug": "demo", "email": "admin@demo.com", "password": "Admin@123456"}
JOAO = {"email": "joao@demo.com", "password": "Admin@123456"}


def _login(url, payload, name, attempts=4):
    last = None
    for i in range(attempts):
        try:
            r = requests.post(url, json=payload, timeout=TIMEOUT)
            if r.status_code == 200:
                return r
            last = r
            print(f"[login] {name} attempt {i+1}: {r.status_code} {r.text[:120]}")
        except Exception as e:
            print(f"[login] {name} attempt {i+1}: exc {e}")
        time.sleep(6)
    return last


@pytest.fixture(scope="session")
def super_admin_token():
    r = _login(f"{BASE_URL}/api/auth/login", SUPER_ADMIN, "super-admin")
    assert r is not None and r.status_code == 200, f"super admin login: {getattr(r,'status_code',None)}"
    return r.json()["access_token"]


@pytest.fixture(scope="session")
def tenant_token():
    r = _login(f"{BASE_URL}/api/tenants/{TENANT['slug']}/auth/login",
               {"email": TENANT["email"], "password": TENANT["password"]}, "tenant-admin")
    assert r is not None and r.status_code == 200, f"tenant admin: {getattr(r,'status_code',None)}"
    return r.json()["access_token"]


@pytest.fixture(scope="session")
def joao_token():
    r = _login(f"{BASE_URL}/api/tenants/{TENANT['slug']}/auth/login", JOAO, "joao")
    assert r is not None and r.status_code == 200, f"joao: {getattr(r,'status_code',None)}"
    return r.json()["access_token"]


def _h(tok):
    return {"Authorization": f"Bearer {tok}"}


# ─────────────────────────────────────────────────────────────────────────────
# A. NULL SKU: multiple products with null sku must NOT collide
# ─────────────────────────────────────────────────────────────────────────────
class TestNullSkuAllowed:
    def test_multiple_products_with_null_sku(self, tenant_token):
        url = f"{BASE_URL}/api/tenants/{TENANT['slug']}/products"
        created_ids = []
        for i in range(3):
            payload = {"name": f"AUDIT75_null_sku_{uuid.uuid4().hex[:6]}_{i}", "price_cents": 1500}
            # explicitly do not send sku
            r = requests.post(url, json=payload, headers=_h(tenant_token), timeout=TIMEOUT)
            assert r.status_code in (200, 201), \
                f"expected 2xx for NULL-sku product #{i}, got {r.status_code} {r.text[:200]}"
            data = r.json()
            assert data.get("sku") in (None, ""), f"sku should be null, got {data.get('sku')}"
            created_ids.append(data["id"])
        assert len(set(created_ids)) == 3, "3 distinct products expected"

        # cleanup
        for pid in created_ids:
            try:
                requests.delete(f"{url}/{pid}", headers=_h(tenant_token), timeout=TIMEOUT)
            except Exception:
                pass


# ─────────────────────────────────────────────────────────────────────────────
# B. Duplicate SKU sequential -> second returns 409 (regression)
# ─────────────────────────────────────────────────────────────────────────────
class TestDuplicateSkuStillBlocked:
    def test_sequential_duplicate_sku_returns_409(self, tenant_token):
        url = f"{BASE_URL}/api/tenants/{TENANT['slug']}/products"
        sku = f"AUDIT75_SKU_{uuid.uuid4().hex[:8]}"
        p1 = requests.post(url, json={"name": "AUDIT75_dup1", "sku": sku, "price_cents": 1000},
                           headers=_h(tenant_token), timeout=TIMEOUT)
        assert p1.status_code in (200, 201), f"first create failed: {p1.status_code} {p1.text[:200]}"
        pid = p1.json()["id"]

        p2 = requests.post(url, json={"name": "AUDIT75_dup2", "sku": sku, "price_cents": 1000},
                           headers=_h(tenant_token), timeout=TIMEOUT)
        assert p2.status_code == 409, f"expected 409 on duplicate sku, got {p2.status_code} {p2.text[:200]}"

        # cleanup
        try:
            requests.delete(f"{url}/{pid}", headers=_h(tenant_token), timeout=TIMEOUT)
        except Exception:
            pass


# ─────────────────────────────────────────────────────────────────────────────
# C. Super-admin plans: duplicate name -> 409 (NEW)
# ─────────────────────────────────────────────────────────────────────────────
class TestPlanDuplicateName:
    def test_duplicate_plan_name_returns_409(self, super_admin_token):
        url = f"{BASE_URL}/api/super-admin/plans"
        name = f"AUDIT75_PLAN_{uuid.uuid4().hex[:8]}"
        payload = {
            "name": name,
            "description": "Audit test plan",
            "status": "ACTIVE",
            "limits": {},
        }
        r1 = requests.post(url, json=payload, headers=_h(super_admin_token), timeout=TIMEOUT)
        assert r1.status_code in (200, 201), f"first plan create: {r1.status_code} {r1.text[:200]}"
        plan_id = r1.json().get("id")

        r2 = requests.post(url, json=payload, headers=_h(super_admin_token), timeout=TIMEOUT)
        assert r2.status_code == 409, f"expected 409 on duplicate plan name, got {r2.status_code} {r2.text[:200]}"
        body = r2.json()
        detail = body.get("detail") or body.get("message") or ""
        assert "plano" in detail.lower() or "already" in detail.lower() or "existe" in detail.lower(), \
            f"unexpected error detail: {detail}"

        # cleanup best-effort
        if plan_id:
            try:
                requests.delete(f"{url}/{plan_id}", headers=_h(super_admin_token), timeout=TIMEOUT)
            except Exception:
                pass


# ─────────────────────────────────────────────────────────────────────────────
# D. Push subscription: same endpoint twice -> returns existing (200)
# ─────────────────────────────────────────────────────────────────────────────
class TestPushSubscriptionDedup:
    def test_same_endpoint_returns_existing(self, tenant_token):
        url = f"{BASE_URL}/api/tenants/{TENANT['slug']}/push-subscriptions"
        endpoint_str = f"https://push.example.com/audit75/{uuid.uuid4().hex}"
        payload = {
            "endpoint": endpoint_str,
            "keys": {"p256dh": "abc", "auth": "xyz"},
            "device_label": "AUDIT75 device",
            "browser": "chrome",
            "platform": "linux",
        }
        r1 = requests.post(url, json=payload, headers=_h(tenant_token), timeout=TIMEOUT)
        if r1.status_code == 403 and "feature" in r1.text.lower():
            pytest.skip("push_notifications feature not enabled for demo tenant")
        assert r1.status_code in (200, 201), f"first push sub: {r1.status_code} {r1.text[:200]}"
        first = r1.json()
        first_id = first.get("id")
        assert first_id, f"no id in response: {first}"

        r2 = requests.post(url, json=payload, headers=_h(tenant_token), timeout=TIMEOUT)
        assert r2.status_code in (200, 201), f"second push sub: {r2.status_code} {r2.text[:200]}"
        second = r2.json()
        assert second.get("id") == first_id, \
            f"expected same sub returned, got different id: first={first_id} second={second.get('id')}"

        # cleanup
        try:
            requests.delete(f"{url}/{first_id}", headers=_h(tenant_token), timeout=TIMEOUT)
        except Exception:
            pass


# ─────────────────────────────────────────────────────────────────────────────
# E. Regression: normal queue flow (join -> start -> finish SALE)
# ─────────────────────────────────────────────────────────────────────────────
class TestQueueNormalFlowRegression:
    def _get_seller_and_store(self, tenant_token, email):
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT['slug']}/sellers",
                         headers=_h(tenant_token), timeout=TIMEOUT)
        assert r.status_code == 200, f"sellers list: {r.status_code}"
        for s in r.json():
            if s.get("email") == email or (s.get("user") or {}).get("email") == email:
                return s["id"], s.get("store_id")
        return None, None

    def test_normal_finish_attendance_creates_one_sale(self, tenant_token, joao_token):
        seller_id, store_id = self._get_seller_and_store(tenant_token, "joao@demo.com")
        if not seller_id or not store_id:
            pytest.skip("could not locate joao's seller_id/store_id")

        # ensure joao is out of queue and no active attendance
        # try to leave first (any errors ignored)
        try:
            requests.post(
                f"{BASE_URL}/api/tenants/{TENANT['slug']}/stores/{store_id}/queue/leave",
                headers=_h(joao_token), json={"seller_id": seller_id}, timeout=TIMEOUT,
            )
        except Exception:
            pass
        time.sleep(0.5)

        # 1. join queue
        r_join = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT['slug']}/stores/{store_id}/queue/join",
            headers=_h(joao_token), json={"seller_id": seller_id}, timeout=TIMEOUT,
        )
        # 200/201 expected; 409 if already in queue (state issue)
        assert r_join.status_code in (200, 201, 409), \
            f"queue/join: {r_join.status_code} {r_join.text[:200]}"

        # 2. start attendance (admin starts on behalf)
        r_start = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT['slug']}/stores/{store_id}/queue/start-attendance",
            headers=_h(tenant_token),
            json={"seller_id": seller_id, "customer_name": "AUDIT75 Cliente"},
            timeout=TIMEOUT,
        )
        if r_start.status_code == 409:
            pytest.skip(f"start-attendance state conflict (pre-existing state): {r_start.text[:200]}")
        assert r_start.status_code in (200, 201), \
            f"start-attendance: {r_start.status_code} {r_start.text[:200]}"
        start_body = r_start.json()
        attendance = start_body.get("attendance") or start_body
        attendance_id = attendance.get("id")
        assert attendance_id, f"no attendance id: {start_body}"

        # 3. finish with SALE
        sale_amount = 25000
        r_finish = requests.post(
            f"{BASE_URL}/api/tenants/{TENANT['slug']}/stores/{store_id}/queue/finish-attendance",
            headers=_h(tenant_token),
            json={
                "attendance_id": attendance_id,
                "result": "SALE",
                "sale_amount_cents": sale_amount,
            },
            timeout=TIMEOUT,
        )
        assert r_finish.status_code in (200, 201), \
            f"finish-attendance: {r_finish.status_code} {r_finish.text[:300]}"
        body = r_finish.json()
        # response shape: {attendance, sale, state}
        att_out = body.get("attendance") or {}
        sale_out = body.get("sale") or {}
        assert att_out.get("status") == "FINISHED", f"attendance status: {att_out.get('status')} body={body}"
        assert sale_out, f"no sale in response: {body}"
        assert sale_out.get("gross_amount_cents") == sale_amount or \
               sale_out.get("total_cents") == sale_amount or \
               sale_out.get("amount_cents") == sale_amount, \
            f"sale amount mismatch: sale={sale_out}"

        # verify exactly 1 sale for this attendance via sales list filter (if endpoint)
        # (skip if no filter endpoint)


# ─────────────────────────────────────────────────────────────────────────────
# F. Regression: normal seller creation (new email) succeeds
# ─────────────────────────────────────────────────────────────────────────────
class TestSellerCreationRegression:
    def test_create_seller_new_email(self, tenant_token):
        r = requests.get(f"{BASE_URL}/api/tenants/{TENANT['slug']}/stores",
                         headers=_h(tenant_token), timeout=TIMEOUT)
        assert r.status_code == 200
        stores = r.json()
        assert stores
        store_id = stores[0]["id"]

        email = f"audit75_seller_{uuid.uuid4().hex[:8]}@demo.com"
        payload = {
            "name": "AUDIT75 Seller",
            "email": email,
            "password": "Admin@123456",
            "store_id": store_id,
        }
        r = requests.post(f"{BASE_URL}/api/tenants/{TENANT['slug']}/sellers",
                          json=payload, headers=_h(tenant_token), timeout=TIMEOUT)
        assert r.status_code in (200, 201), \
            f"seller create: {r.status_code} {r.text[:200]}"
        body = r.json()
        assert body.get("id"), f"no seller id: {body}"


# ─────────────────────────────────────────────────────────────────────────────
# G. Regression: pg_shim row_seq — PUT product update + PATCH seller status
# ─────────────────────────────────────────────────────────────────────────────
class TestPgShimRowSeqRegression:
    def test_update_product_via_put(self, tenant_token):
        url = f"{BASE_URL}/api/tenants/{TENANT['slug']}/products"
        sku = f"AUDIT75_ROWSEQ_{uuid.uuid4().hex[:8]}"
        r = requests.post(url, json={"name": "AUDIT75_rowseq", "sku": sku, "price_cents": 1000},
                          headers=_h(tenant_token), timeout=TIMEOUT)
        assert r.status_code in (200, 201), f"create: {r.status_code} {r.text[:200]}"
        pid = r.json()["id"]

        new_name = "AUDIT75_rowseq_updated"
        r2 = requests.put(f"{url}/{pid}",
                          json={"name": new_name, "sku": sku, "price_cents": 1500},
                          headers=_h(tenant_token), timeout=TIMEOUT)
        assert r2.status_code in (200, 204), f"PUT product: {r2.status_code} {r2.text[:200]}"

        # verify via GET
        r3 = requests.get(f"{url}/{pid}", headers=_h(tenant_token), timeout=TIMEOUT)
        assert r3.status_code == 200
        got = r3.json()
        assert got.get("name") == new_name, f"name not updated: {got.get('name')}"
        assert got.get("price_cents") == 1500, f"price not updated: {got.get('price_cents')}"

        # cleanup
        try:
            requests.delete(f"{url}/{pid}", headers=_h(tenant_token), timeout=TIMEOUT)
        except Exception:
            pass

    def test_patch_product_status(self, tenant_token):
        # products have no DELETE — use PATCH .../status (still exercises pg_shim row_seq UPDATE)
        url = f"{BASE_URL}/api/tenants/{TENANT['slug']}/products"
        sku = f"AUDIT75_STAT_{uuid.uuid4().hex[:8]}"
        r = requests.post(url, json={"name": "AUDIT75_stat", "sku": sku, "price_cents": 500},
                          headers=_h(tenant_token), timeout=TIMEOUT)
        assert r.status_code in (200, 201)
        pid = r.json()["id"]

        r_patch = requests.patch(f"{url}/{pid}/status",
                                 json={"active": False},
                                 headers=_h(tenant_token), timeout=TIMEOUT)
        assert r_patch.status_code in (200, 204), f"PATCH status: {r_patch.status_code} {r_patch.text[:200]}"

        r_get = requests.get(f"{url}/{pid}", headers=_h(tenant_token), timeout=TIMEOUT)
        assert r_get.status_code == 200
        got = r_get.json()
        assert got.get("active") is False or got.get("status") == "INACTIVE", \
            f"status not updated: {got}"
