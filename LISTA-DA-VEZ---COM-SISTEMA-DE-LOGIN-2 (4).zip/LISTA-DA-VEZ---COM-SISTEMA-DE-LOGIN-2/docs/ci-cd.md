# CI/CD — Lista da Vez SaaS

> Documentação do pipeline de integração e entrega contínua.

---

## Visão Geral

O pipeline CI/CD usa **GitHub Actions** (`.github/workflows/ci.yml`).

### Fluxo de branches
```
feature/* → develop → staging → main (produção)
```

### Quando o pipeline executa
- **Push para:** `main`, `staging`, `develop`
- **Pull Request para:** `main`, `staging`

---

## Stages do Pipeline

### Job 1: `backend-tests` — Testes + Lint
**Tempo estimado:** ~3-5 min

```
Setup Python 3.11
↓
Instalar dependências (requirements.txt)
↓
Lint com flake8 (linha max 120 chars) [não bloqueia]
↓
pytest tests/test_p0_security.py (20 testes)
↓
pytest tests/test_p0_5_compatibility.py (19 testes)
↓
pytest tests/test_p1_export_jobs.py (8 testes)
```

**Bloqueia deploy se:** qualquer teste falhar.

**Serviços necessários:** MongoDB 7 (service container automático)

### Job 2: `frontend-build` — Build Check
**Tempo estimado:** ~4-6 min

```
Setup Node 18
↓
yarn install --frozen-lockfile
↓
yarn build (React produção)
↓
Verificar tamanho dos chunks
```

**Bloqueia deploy se:** build falhar.

### Job 3: `docker-build` — Build + Health Check
**Tempo estimado:** ~8-12 min
**Executa apenas em push** (não em PRs)

```
Build imagem backend (multi-stage)
↓
Build imagem frontend (multi-stage)
↓
Iniciar backend em Docker com MongoDB de teste
↓
Aguardar inicialização (máx 30s)
↓
curl /api/health/live → deve retornar 200
```

**Bloqueia deploy se:** build da imagem falhar ou health check falhar.

### Job 4: `secrets-scan` — Varredura de Secrets
**Tempo estimado:** ~1 min

```
Verificar que .env não está versionado
↓
Grep por patterns de secrets óbvios no código
[aviso apenas, não bloqueia]
```

---

## Configurar no GitHub

### Secrets necessários (GitHub → Settings → Secrets → Actions)

| Nome | Valor | Usado em |
|---|---|---|
| `JWT_SECRET` | `openssl rand -hex 32` | backend-tests, docker-build |
| `MONGO_URL` | `mongodb://localhost:27017` | Já hardcoded no CI (não é secret) |

> Para deploy automático em produção, adicionar:
> `DEPLOY_SSH_KEY`, `DEPLOY_HOST`, `DEPLOY_USER`, etc.

### Variáveis de ambiente CI (não-secretas)
Configuradas diretamente no workflow (`.github/workflows/ci.yml`):
- `PYTHON_VERSION: "3.11"`
- `NODE_VERSION: "18"`

---

## Deploy Manual (staging)

Até ter deploy automático configurado, o deploy em staging é manual:

```bash
# 1. Fazer build das imagens
docker build -f Dockerfile -t lista-da-vez-backend:$(git rev-parse --short HEAD) .
docker build -f Dockerfile.frontend \
  --build-arg REACT_APP_BACKEND_URL=$BACKEND_URL \
  -t lista-da-vez-frontend:$(git rev-parse --short HEAD) .

# 2. Tagear como latest
docker tag lista-da-vez-backend:$(git rev-parse --short HEAD) lista-da-vez-backend:latest
docker tag lista-da-vez-frontend:$(git rev-parse --short HEAD) lista-da-vez-frontend:latest

# 3. Deploy no staging
docker compose -f docker-compose.staging.yml --env-file .env.staging pull || true
docker compose -f docker-compose.staging.yml --env-file .env.staging up -d

# 4. Verificar saúde
sleep 15
curl -f $BACKEND_URL/api/health/ready
```

---

## Critérios de Bloqueio de Deploy

Um deploy NUNCA deve acontecer se:
- Qualquer teste unitário falhou
- Build do frontend falhou
- Health check da imagem Docker falhou
- Arquivo `.env` foi detectado no commit
- `JWT_SECRET` tem menos de 32 chars

Um deploy pode acontecer com avisos (não bloqueadores):
- Lint warnings (flake8)
- Secrets scan com warnings
- `REDIS_URL` não configurado (usa in-memory)

---

## Evolução Futura do Pipeline

Quando o sistema crescer, adicionar:

```yaml
# Estágios adicionais recomendados
- name: Testes de integração (Playwright/Selenium)
- name: SAST (Bandit para Python, ESLint security para JS)
- name: Análise de vulnerabilidades de dependências (Safety/Snyk)
- name: Build e push para registry (ECR/GCR/DockerHub)
- name: Deploy automático em staging após merge para `staging`
- name: Deploy automático em produção após merge para `main` + aprovação manual
- name: Smoke tests pós-deploy
- name: Notificação Slack em sucesso/falha
```

---

## Troubleshooting do Pipeline

### "Tests failed" — nenhum detalhe
```bash
# Rodar localmente para ver output completo
cd backend
MONGO_URL=mongodb://localhost:27017 DB_NAME=listadavez_test \
JWT_SECRET=test-secret-1234567890abcdef12345678 ENVIRONMENT=test \
python -m pytest tests/ -v --tb=long
```

### "Frontend build failed"
```bash
# Verificar versão do Node
node --version   # deve ser 18+
yarn --version   # deve ser 1.22+

cd frontend
yarn install --frozen-lockfile
REACT_APP_BACKEND_URL=http://localhost:8001 yarn build
```

### "Docker health check failed"
```bash
# Ver logs do container de teste
docker logs backend-ci --tail 50

# Verificar que server.py não tem erro de importação
cd backend
python -c "import server" 2>&1 | head -20
```
