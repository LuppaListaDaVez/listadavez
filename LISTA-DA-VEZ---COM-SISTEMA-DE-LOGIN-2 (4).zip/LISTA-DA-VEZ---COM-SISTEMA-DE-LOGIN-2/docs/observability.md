# Observabilidade — Lista da Vez SaaS

> Guia de logs, métricas, alertas e investigação de incidentes.

---

## 1. Logs Estruturados

### Formato de log
```
TIMESTAMP - LOGGER_NAME - LEVEL - MENSAGEM
2026-06-29 19:44:30,471 - lista-da-vez.export_jobs - INFO - EXPORT_JOB_DONE id=ecde90cb type=attendances rows=1
```

### Loggers do sistema
| Logger | Arquivo | O que loga |
|---|---|---|
| `lista-da-vez` | `server.py` | Boot, startup, exceções globais |
| `lista-da-vez.health` | `routes_health.py` | Health checks |
| `lista-da-vez.export_jobs` | `export_job_service.py` | Export jobs |
| `lista-da-vez.outbox` | `outbox_service.py` | Outbox events |
| `lista-da-vez.queue_lock` | `queue_lock_service.py` | Locks de fila |
| `lista-da-vez.security` | `security.py` | Auth, tokens, sessões |

### Arquivos de log (ambiente Kubernetes/Supervisor)
```bash
# Logs do backend (stdout + stderr)
tail -f /var/log/supervisor/backend.out.log
tail -f /var/log/supervisor/backend.err.log

# Logs do frontend (nginx quando em Docker)
docker logs lista-da-vez-frontend --tail 50 -f
```

---

## 2. Request ID e Correlation ID

Cada request HTTP recebe um `X-Request-Id` único. Presente em:
- Response header: `X-Request-Id`
- Logs de exceção global: `req=REQUEST_ID`
- Resposta 500: `{ "request_id": "..." }`

### Investigar erro por request_id
```bash
# Cliente reportou erro com request_id
grep "req=abc123" /var/log/supervisor/backend.out.log
grep "req=abc123" /var/log/supervisor/backend.err.log

# Ver stack trace completo
grep -A 20 "req=abc123" /var/log/supervisor/backend.err.log
```

---

## 3. Métricas do Sistema

### Endpoint de observabilidade
```bash
# Requer token Super Admin
curl -H "Authorization: Bearer $SUPER_ADMIN_TOKEN" \
     $BACKEND_URL/api/admin/observability | python3 -m json.tool
```

**Resposta:**
```json
{
  "total_requests": 1520,
  "error_5xx_count": 3,
  "avg_response_ms": 45,
  "rate_limit_hits": 12,
  "websocket": {
    "active_connections": 8,
    "by_store": {"store_id_1": 3, "store_id_2": 5},
    "mode": "in_memory",
    "events_published": 245,
    "events_failed": 0
  },
  "cache": { "size": 42, "hits": 890, "misses": 120 },
  "outbox": { "pending": 0, "published": 245, "failed": 0, "dead_letter": 0 },
  "db_response_ms": 12,
  "db_status": "connected"
}
```

---

## 4. Health Checks

| Endpoint | Retorna | Uso |
|---|---|---|
| `GET /api/health` | `{"status":"ok"}` | Status básico |
| `GET /api/health/live` | `{"status":"ok"}` | Kubernetes liveness probe |
| `GET /api/health/ready` | Inclui db, redis, export_dispatcher | Kubernetes readiness probe |
| `GET /api/health/db` | Status detalhado do MongoDB | Debug de conectividade |

```bash
# Verificação completa de saúde
curl -s $BACKEND_URL/api/health/ready | python3 -m json.tool
```

---

## 5. Padrões de Log para Monitorar

### Eventos de segurança (monitorar com alertas)
```bash
grep "SECURITY_WARNING\|IDOR\|TENANT_MISMATCH\|UNAUTHORIZED" /var/log/supervisor/backend.out.log

# Tentativas de login falho excessivas
grep "login_failed" /var/log/supervisor/backend.out.log | \
  awk '{print $1}' | sort | uniq -c | sort -rn | head -10
```

### Erros de workers
```bash
grep "OUTBOX_FAILED\|EXPORT_JOB_FAILED\|DISPATCHER_ERROR" /var/log/supervisor/backend.err.log
```

### Rate limits
```bash
grep "RATE_LIMIT\|429" /var/log/supervisor/backend.out.log | tail -20
```

### Tenant leakage (crítico)
```bash
grep "TENANT_MISMATCH\|CROSS_TENANT\|tenant_leakage" /var/log/supervisor/backend.out.log
```

---

## 6. Alertas Recomendados

Configure os alertas abaixo no seu sistema de monitoramento (Datadog, Grafana, CloudWatch, etc.):

| Alerta | Condição | Severidade | Ação |
|---|---|---|---|
| **Backend indisponível** | `/api/health/live` retorna não-2xx por 2min | CRÍTICO | Rollback imediato |
| **Banco indisponível** | `/api/health/ready` retorna 503 por 1min | CRÍTICO | Verificar MongoDB |
| **Taxa de erro 5xx alta** | > 5% das requests em 5min | ALTO | Verificar logs |
| **Latência alta** | avg_response_ms > 2000ms por 5min | MÉDIO | Verificar DB queries |
| **Rate limits excessivos** | > 50 hits em 1min | MÉDIO | Investigar IP de origem |
| **Outbox DEAD_LETTER** | dead_letter > 0 | BAIXO | Verificar WebSocket |
| **Export jobs travados** | QUEUED > 10 por > 10min | MÉDIO | Verificar dispatcher |
| **Disco cheio** | `/tmp` > 80% | ALTO | Limpar exports antigos |
| **WebSocket connections** | active_connections = 0 enquanto há usuários | MÉDIO | Verificar realtime |

---

## 7. Investigar Erro 500

```bash
# 1. O cliente reportou um erro — peça o request_id do header X-Request-Id

# 2. Buscar nos logs
REQUEST_ID="UUID_DO_ERRO"
grep "$REQUEST_ID" /var/log/supervisor/backend.err.log
grep "$REQUEST_ID" /var/log/supervisor/backend.out.log

# 3. Se não encontrar, buscar por timestamp aproximado
grep "2026-06-29 19:4" /var/log/supervisor/backend.err.log

# 4. Reproduzir em staging com os mesmos dados
# (autenticar como o usuário afetado e repetir a operação)

# 5. Verificar se é erro de banco
grep "pymongo\|MongoError" /var/log/supervisor/backend.err.log | tail -10

# 6. Verificar health
curl -s $BACKEND_URL/api/health/ready
```

---

## 8. Investigar Tenant Leakage

```bash
# Verificar logs de mismatch
grep "TENANT_MISMATCH\|tenant_id" /var/log/supervisor/backend.err.log | grep -i "error\|warn"

# No MongoDB: verificar se dado de tenant A aparece com tenant_id de tenant B
# db.attendances.findOne({ tenant_id: "TENANT_A_ID", store_id: { $in: ["STORE_DE_TENANT_B"] } })

# Se confirmado: INCIDENTE CRÍTICO
# 1. Notificar equipe imediatamente
# 2. Isolar os tenants afetados (desabilitar se necessário)
# 3. Identificar a query ou endpoint com bug
# 4. Rollback se necessário
# 5. Auditar dados afetados
```

---

## 9. Investigar Job Travado

```bash
# Export job em PROCESSING por muito tempo
# MongoDB:
# db.export_jobs.find({
#   status: "PROCESSING",
#   started_at: { $lt: new Date(Date.now() - 600000).toISOString() }
# })

# Ver logs do dispatcher
grep "EXPORT_JOB" /var/log/supervisor/backend.out.log | tail -20
grep "EXPORT_JOB_FAILED\|EXPORT_DISPATCHER_ERROR" /var/log/supervisor/backend.err.log | tail -10

# Se travado, requeue manualmente
# db.export_jobs.updateMany({status: "PROCESSING"}, {$set: {status: "QUEUED", started_at: null}})
```

---

## 10. Investigar WebSocket Indisponível

```bash
# Verificar adapter
curl -s -H "Authorization: Bearer $SUPER_ADMIN_TOKEN" \
     $BACKEND_URL/api/admin/observability | \
     python3 -c "import sys,json; d=json.load(sys.stdin); print('WebSocket mode:', d['websocket']['mode'])"

# Se modo redis: verificar conectividade Redis
redis-cli -u $REDIS_URL ping

# Logs do adapter
grep "REALTIME\|redis\|pubsub" /var/log/supervisor/backend.err.log | tail -20

# Fallback: reiniciar com REALTIME_MODE=in_memory temporariamente
# (apenas se Redis estiver fora e for aceitável perder Pub/Sub distribuído)
```
