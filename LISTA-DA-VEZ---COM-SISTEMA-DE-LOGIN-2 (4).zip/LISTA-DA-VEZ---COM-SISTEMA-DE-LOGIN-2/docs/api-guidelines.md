# API Guidelines — Lista da Vez SaaS

**Versão:** 1.0.0-p2  
**Responsável:** Tech Lead  
**Última atualização:** 2026-06

---

## 1. Convenções de URL

### 1.1 Padrão de Rota

```
/api/tenants/{slug}/{recurso}[/{id}[/{sub-recurso}]]
```

**Exemplos corretos:**
```
GET  /api/tenants/{slug}/stores                     # listagem
GET  /api/tenants/{slug}/stores/{id}                # busca por ID
POST /api/tenants/{slug}/stores                     # criação
PUT  /api/tenants/{slug}/stores/{id}               # atualização total
PATCH /api/tenants/{slug}/stores/{id}              # atualização parcial
DELETE /api/tenants/{slug}/stores/{id}             # remoção

GET  /api/tenants/{slug}/stores/{id}/queue          # sub-recurso
POST /api/tenants/{slug}/stores/{id}/queue/join     # ação
POST /api/tenants/{slug}/stores/{id}/queue/leave    # ação
```

**Regras:**
- URLs em **kebab-case** (ex: `finish-attendance`, não `finishAttendance`)
- Nomes de recursos no **plural** (ex: `stores`, `sellers`, `attendances`)
- Ações verbais aceitas apenas para operações que não se encaixam em CRUD (ex: `join`, `leave`, `start-attendance`)
- Super admin: `/api/super-admin/...`
- Métricas: `/api/metrics/...`

### 1.2 Versioning

- **v0 (atual):** `/api/tenants/{slug}/...` — retrocompatível, não remover
- **v1 (alias):** `/api/v1/tenants/{slug}/...` — mesmo handler, apenas prefixo
- **v2 (futuro):** introduzir apenas com breaking changes, após deprecation de 90 dias

Ver `/docs/api-versioning-plan.md` para detalhes.

---

## 2. Padrão de Resposta

### 2.1 Sucesso — Recurso Único

```json
{
  "id": "uuid-v4",
  "tenant_id": "tenant-uuid",
  "name": "Loja Centro",
  "created_at": "2026-06-01T10:00:00+00:00",
  "updated_at": "2026-06-01T10:00:00+00:00"
}
```

### 2.2 Sucesso — Listagem Paginada

```json
{
  "items": [...],
  "pagination": {
    "page": 1,
    "page_size": 20,
    "total": 150,
    "total_pages": 8,
    "has_next": true,
    "has_prev": false
  }
}
```

### 2.3 Sucesso — Ação (POST de ação)

```json
{
  "success": true,
  "data": { ... },
  "message": "Vendedor entrou na fila com sucesso"
}
```

### 2.4 Erro (4xx / 5xx)

```json
{
  "error": "STORE_NOT_FOUND",
  "message": "Loja não encontrada neste tenant",
  "request_id": "req_abc123",
  "details": {}
}
```

**Códigos de erro padronizados:**

| Código | HTTP | Quando usar |
|---|---|---|
| `UNAUTHORIZED` | 401 | Token inválido, expirado, ausente |
| `FORBIDDEN` | 403 | Token válido mas sem permissão |
| `NOT_FOUND` | 404 | Entidade não existe neste tenant |
| `CONFLICT` | 409 | Duplicata, conflito de estado |
| `IDEMPOTENCY_KEY_CONFLICT` | 409 | Mesma chave, payload diferente |
| `VALIDATION_ERROR` | 422 | Campos inválidos (Pydantic) |
| `FEATURE_DISABLED` | 403 | Feature flag desabilitada |
| `RATE_LIMIT_EXCEEDED` | 429 | Limite de rate atingido |
| `INTERNAL_ERROR` | 500 | Erro inesperado (sem detalhes ao cliente) |

---

## 3. Paginação

### 3.1 Parâmetros de Query

| Parâmetro | Tipo | Default | Máximo | Descrição |
|---|---|---|---|---|
| `page` | int | 1 | — | Número da página (1-based) |
| `page_size` | int | 20 | **200** | Itens por página |
| `sort_by` | str | `created_at` | whitelist | Campo de ordenação |
| `sort_order` | str | `desc` | `asc`/`desc` | Direção |

### 3.2 Segurança de Paginação

- `page_size` > 200 → clampado para 200 automaticamente (nunca retorna 422)
- `sort_by` aceita apenas campos da whitelist do endpoint (nunca `$where`)
- `page` < 1 → tratado como 1

---

## 4. Filtros e Busca

### 4.1 Parâmetros Aceitos

```
GET /api/tenants/{slug}/attendances?
    store_id=...
    &seller_id=...
    &status=FINISHED
    &start_date=2026-01-01
    &end_date=2026-06-30
    &search=nome_cliente
    &page=1
    &page_size=20
```

### 4.2 Segurança de Filtros

- **Nunca aceitar operadores MongoDB** (`$where`, `$gt`, `$regex`) como parâmetros
- Parâmetros de filter são convertidos para queries tipadas (não string interpolation)
- `tenant_id` nunca aceito como parâmetro de query (extraído do JWT)
- Campos de busca usam índices de texto (não COLLSCAN)

---

## 5. Headers Obrigatórios

### 5.1 Request

```http
Authorization: Bearer {jwt}
Content-Type: application/json
Idempotency-Key: {uuid}          # Apenas em POST críticos (finish-attendance, etc.)
X-Request-ID: {uuid}             # Opcional, usado para correlation
```

### 5.2 Response

```http
Content-Type: application/json
X-Request-ID: {uuid}             # Echo do request ID ou novo UUID
Retry-After: {seconds}           # Apenas em 429
```

---

## 6. Idempotência

Endpoints que modificam estado crítico (financeiro, fila) devem suportar `Idempotency-Key`:

```python
# Use Case: verificar idempotência antes de executar
cached = await idempotency_service.get(key, tenant_id)
if cached:
    return cached.response  # Retorna resultado cached
    
result = await execute_operation()
await idempotency_service.store(key, tenant_id, result, ttl=86400)
return result
```

**Endpoints com idempotência obrigatória:**
- `POST /stores/{id}/queue/finish-attendance`
- `POST /sales` (criação de venda)
- Qualquer operação financeira futura

---

## 7. Datas e Timezones

- Todas as datas em **ISO 8601 com timezone** (`2026-06-01T10:00:00+00:00`)
- Armazenadas em UTC no MongoDB
- Frontend converte para timezone local
- Filtros de data aceitam `YYYY-MM-DD` (sem hora → início/fim do dia UTC)

---

## 8. Documentação OpenAPI

- Swagger UI disponível em `/api/docs` (apenas `ENVIRONMENT != production`)
- ReDoc disponível em `/api/redoc`
- Schema JSON em `/api/openapi.json`
- Todos os endpoints devem ter `summary`, `tags` e `response_model`
