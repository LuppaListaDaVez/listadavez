# Production Readiness Checklist — Lista da Vez SaaS
**Versão**: 1.0.0-p3  
**Data**: 2026-02  

---

## Resumo Executivo

O sistema **Lista da Vez** está **PRONTO para produção** com score 8.7/10.  
Arquitetura multitenant, segurança enterprise, 149+ testes passando, LGPD-compliant.

---

## Checklist de Deploy

### Infraestrutura

- [ ] Configurar variáveis de ambiente de produção (ver `.env.example`)
  - `MONGO_URL` — MongoDB Atlas ou self-hosted com replica set
  - `DB_NAME` — nome do banco (ex: `lista_da_vez_prod`)
  - `JWT_SECRET` — 64+ chars aleatórios (use: `openssl rand -hex 32`)
  - `ENVIRONMENT=production`
  - `CORS_ORIGINS` — lista explícita de domínios (sem wildcard)
  - `SEED_DEMO_DATA=false` — **OBRIGATÓRIO em produção**
  - `REDIS_URL` — Redis 7+ (Upstash, ElastiCache, ou self-hosted)
  - `REALTIME_MODE=redis`
- [ ] Configurar MongoDB com replica set (necessário para transações)
- [ ] Configurar Redis com persistence (AOF ou RDB)
- [ ] Configurar HTTPS com certificado TLS válido
- [ ] Configurar load balancer com health check em `/api/health/ready`
- [ ] Configurar auto-scaling (HPA K8s ou similar) — ver `docs/autoscaling.md`

### Banco de Dados

- [ ] Executar migrações: `python scripts/run_migrations.py`
- [ ] Verificar índices: `python scripts/verify_indexes.py`
- [ ] Criar índices ausentes: `python scripts/verify_indexes.py --create-missing`
- [ ] Configurar backups automáticos (diário no mínimo)
- [ ] Testar restore de backup antes do go-live

### Segurança

- [ ] Revisar `CORS_ORIGINS` — apenas domínios necessários
- [ ] Confirmar `SEED_DEMO_DATA=false`
- [ ] Revogar todas as sessões de desenvolvimento antes do go-live
- [ ] Habilitar WAF (Web Application Firewall) no load balancer
- [ ] Configurar alertas de segurança (SIEM ou equivalent)
- [ ] Revisar rate limits — adequar para volume esperado de produção

### Observabilidade

- [ ] Configurar coleta de métricas Prometheus em `/api/metrics/prometheus`
- [ ] Configurar dashboards Grafana (ver `docs/observability.md`)
- [ ] Configurar alertas (P95 > 1s, error rate > 2%, 5xx spike)
- [ ] Configurar log shipping (ELK, Loki, ou similar)
- [ ] Testar health checks: `GET /api/health/ready`

### CI/CD

- [ ] Configurar secrets no repositório GitHub (MONGO_URL, JWT_SECRET, etc.)
- [ ] Testar pipeline CI completo: `make test` ou via GitHub Actions
- [ ] Configurar deployment automatizado via CD (ex: ArgoCD, GitHub Actions)
- [ ] Configurar rollback automático se health check falhar

---

## Variáveis de Ambiente Obrigatórias

```env
# Banco de dados
MONGO_URL=mongodb+srv://user:pass@cluster.mongodb.net/
DB_NAME=lista_da_vez_prod

# Autenticação
JWT_SECRET=<64+ chars gerados com openssl rand -hex 32>
JWT_ALGORITHM=HS256
JWT_EXPIRATION_HOURS=8

# Ambiente
ENVIRONMENT=production
SEED_DEMO_DATA=false
CORS_ORIGINS=https://app.seudominio.com,https://www.seudominio.com

# Redis
REDIS_URL=redis://user:pass@redis-host:6379/0
REALTIME_MODE=redis

# Segurança
CSP_EXTRA_SOURCES=  # deixar vazio em produção
```

---

## Comandos de Verificação Pré-Deploy

```bash
# 1. Verificar saúde do backend
curl https://api.seudominio.com/api/health/ready

# 2. Verificar índices MongoDB
python scripts/verify_indexes.py

# 3. Rodar suíte de testes
cd backend && pytest tests/ -v --timeout=60

# 4. Checar configuração de CORS
curl -H "Origin: https://app.seudominio.com" \
     -H "Access-Control-Request-Method: GET" \
     -X OPTIONS https://api.seudominio.com/api/health -v
```

---

## SLOs Definidos

| Métrica | Target | Alertar se |
|---------|--------|------------|
| Availability | ≥ 99.5% | < 99% em 5min |
| P50 latência | < 200ms | > 500ms |
| P95 latência | < 1000ms | > 2000ms |
| Error rate (5xx) | < 0.5% | > 2% |
| WebSocket uptime | ≥ 99% | < 95% em 10min |

---

## Documentação de Referência

- `docs/architecture-guide.md` — Arquitetura e decisões técnicas
- `docs/security-checklist.md` — Checklist de segurança completo
- `docs/operational-runbook.md` — Runbook operacional
- `docs/go-no-go-checklist.md` — Resultado da auditoria P3
- `docs/autoscaling.md` — Estratégia de auto-scaling
- `docs/sharding-strategy.md` — Estratégia de sharding MongoDB

---

*Lista da Vez SaaS v1.0.0-p3 — Production Readiness*
