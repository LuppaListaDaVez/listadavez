# Workers e Filas — Lista da Vez SaaS

> Guia operacional para os workers, jobs assíncronos e filas do sistema.

---

## Arquitetura de Workers

O sistema tem **3 workers internos** rodando como `asyncio.Task` dentro do processo FastAPI, mais um adapter de realtime opcional com Redis.

```
FastAPI Process
├── HTTP Request Handlers (uvicorn workers)
├── [Task] Outbox Dispatcher         → entrega eventos WebSocket confiáveis
├── [Task] Export Job Dispatcher     → gera CSVs de relatórios assíncronos
├── [Task] Cache Eviction Loop       → remove entradas de cache expiradas
└── [Adapter] Realtime Event Bus     → InMemory ou Redis Pub/Sub
```

---

## 1. Outbox Dispatcher

**Arquivo:** `backend/outbox_service.py`
**Task:** `run_dispatcher()`
**Intervalo:** 2 segundos
**Coleção MongoDB:** `event_outbox`

### O que faz
Implementa o **Outbox Pattern** para garantir entrega confiável de eventos WebSocket:
1. Evento é gravado na coleção `event_outbox` na mesma transação do dado principal
2. O dispatcher lê eventos `PENDING` e os publica via WebSocket/Redis Pub/Sub
3. Em caso de falha, o evento é marcado como `FAILED` (máx 3 tentativas)
4. Após 3 falhas, vai para `DEAD_LETTER`

### Status dos eventos
| Status | Descrição |
|---|---|
| `PENDING` | Aguardando processamento |
| `PUBLISHED` | Publicado com sucesso |
| `FAILED` | Falhou (max 3 tentativas) |
| `DEAD_LETTER` | Descartado após máximo de tentativas |

### Monitoramento
```bash
# Ver eventos pendentes
curl -H "Authorization: Bearer $SUPER_ADMIN_TOKEN" \
     $BACKEND_URL/api/admin/observability | python3 -m json.tool | grep -A5 outbox

# Contar dead letters
# MongoDB:
db.event_outbox.countDocuments({status: "DEAD_LETTER"})
db.event_outbox.countDocuments({status: "PENDING"})
```

### Como reprocessar evento travado
```javascript
// MongoDB shell
db.event_outbox.updateMany(
  { status: "FAILED", attempt_count: { $lt: 3 } },
  { $set: { status: "PENDING" } }
)
```

---

## 2. Export Job Dispatcher

**Arquivo:** `backend/export_job_service.py`
**Task:** `run_export_dispatcher()`
**Intervalo:** 5 segundos
**Coleção MongoDB:** `export_jobs`

### O que faz
Processa jobs de exportação de CSV de forma assíncrona:
1. Usuário cria job via `POST /api/tenants/{slug}/reports/export/async`
2. Job fica em status `QUEUED`
3. Dispatcher processa até 5 jobs por ciclo
4. CSV é gerado e salvo em `/tmp/exports/` (ou storage configurado)
5. Status muda para `DONE` (ou `FAILED`)
6. Arquivo expira após 24h (TTL automático via índice MongoDB)

### Status dos jobs
| Status | Descrição |
|---|---|
| `QUEUED` | Aguardando processamento |
| `PROCESSING` | Sendo gerado agora |
| `DONE` | CSV disponível para download |
| `FAILED` | Erro durante geração |

### Tipos de relatório suportados
- `attendances` — Atendimentos
- `conversion` — Taxa de conversão por vendedor
- `loss-reasons` — Motivos de não-venda
- `seller-performance` — Performance por vendedor
- `products` — Produtos mais vendidos
- `proactivity` — Abordagens proativas

### Limites
- **Máximo de linhas por export:** 50.000 registros
- **TTL do arquivo:** 24 horas
- **Cleanup:** Automático via índice MongoDB `expireAfterSeconds=0`

### Monitoramento
```bash
# Listar jobs recentes
curl -H "Authorization: Bearer $TOKEN" \
     $BACKEND_URL/api/tenants/SLUG/reports/export/jobs

# Status de job específico
curl -H "Authorization: Bearer $TOKEN" \
     $BACKEND_URL/api/tenants/SLUG/reports/export/jobs/JOB_ID
```

### Como reprocessar export falho
```javascript
// MongoDB shell — requeue job específico
db.export_jobs.updateOne(
  { id: "JOB_ID", status: "FAILED" },
  { $set: { status: "QUEUED", error: null } }
)
```

---

## 3. Cache Eviction Loop

**Arquivo:** `backend/cache_service.py`
**Intervalo:** 60 segundos

Cache in-memory com TTL por entry. Remove entradas expiradas automaticamente. Sem intervenção necessária.

---

## 4. Realtime Event Bus (WebSocket)

**Arquivo:** `backend/realtime.py`
**Configuração:** `REALTIME_MODE=in_memory|redis`

### Modo `in_memory` (default)
- Funciona em processo único
- WebSocket connections são armazenadas em memória
- **Não funciona com múltiplas réplicas**
- Adequado para: 1 instância, desenvolvimento, staging inicial

### Modo `redis`
- Usa Redis Pub/Sub para broadcast entre instâncias
- Requer `REDIS_URL` configurado
- **Funciona com múltiplas réplicas**
- Adequado para: produção com load balancer

### Verificar status do Realtime
```bash
curl -H "Authorization: Bearer $SUPER_ADMIN_TOKEN" \
     $BACKEND_URL/api/admin/observability | python3 -m json.tool | grep -A8 websocket
```

---

## Quantos Workers Recomendar

### Staging (1 instância)
```
uvicorn --workers 2 --worker-class uvicorn.workers.UvicornWorker
```
- 2 workers uvicorn
- Modo in-memory suficiente
- Export jobs dispatcher: 1 por processo (2 no total, ok)

### Produção Inicial (100 empresas)
```
uvicorn --workers 4 --worker-class uvicorn.workers.UvicornWorker
```
- 4 workers uvicorn (ou gunicorn com 4 workers uvicorn)
- **Obrigatório:** REALTIME_MODE=redis
- Redis para Pub/Sub cross-worker
- Monitore export_jobs: se `QUEUED > 20` por mais de 30s, investigar

### Produção Escala (>500 empresas)
- Separar workers em processo dedicado (container separado)
- Deploy separado do web server
- Fila de jobs via Celery + Redis ou MongoDB queue

---

## Graceful Shutdown

Ao receber SIGTERM, uvicorn aguarda até 30s para requests em andamento finalizarem. Os workers de background (`asyncio.Task`) são cancelados automaticamente pelo Python.

**Workers que podem ser interrompidos com segurança:**
- Outbox Dispatcher — retoma na próxima inicialização
- Export Job Dispatcher — retoma na próxima inicialização (jobs requeued)
- Cache Eviction — sem estado persistente

**Para drain manual antes de shutdown:**
```bash
# Aguardar export jobs em PROCESSING terminarem
watch -n 2 'curl -s $BACKEND_URL/api/health/ready | python3 -m json.tool'
```

---

## Logs dos Workers

```bash
# Ver logs do outbox dispatcher
grep "OUTBOX_" /var/log/supervisor/backend.out.log | tail -20

# Ver logs do export dispatcher
grep "EXPORT_" /var/log/supervisor/backend.out.log | tail -20

# Ver todos os erros de workers
grep "ERROR" /var/log/supervisor/backend.err.log | tail -50
```
