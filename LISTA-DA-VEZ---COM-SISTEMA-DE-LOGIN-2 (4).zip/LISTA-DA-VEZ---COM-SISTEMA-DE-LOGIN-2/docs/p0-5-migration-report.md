# Relatório de Migração P0.5

**Gerado em:** 2026-06-29  
**Ambiente:** Staging/Dev (demo)  
**Status:** ✅ Concluído com sucesso

---

## Resumo Executivo

A migração P0.5 garante compatibilidade entre os dados existentes do sistema e as mudanças críticas introduzidas na ONDA P0.

---

## Scripts Criados

| Script | Finalidade | Idempotente |
|--------|-----------|-------------|
| `scripts/backfill_p0_5.py` | Backfill de todos os campos ausentes | ✅ |
| `scripts/ensure_indexes.py` | Criação segura de índices (verifica duplicatas antes de unique) | ✅ |
| `scripts/run_migrations.py` | Orchestrador: executa backfill + index check | ✅ |

---

## Campos Verificados e Backfillados

### `users` (13 documentos)
| Campo | Status | Ação |
|-------|--------|------|
| `normalized_email` | ❌ Ausente em todos | ✅ Backfill: `email.lower().strip()` |
| `token_version` | ❌ Ausente em todos | ✅ Backfill: default `1` |
| `email` (original) | ✅ Presente | Não alterado |
| `password_hash` | ✅ Presente | Não exposto em APIs |

### `sales` (301 documentos)
| Campo | Status | Ação |
|-------|--------|------|
| `source` | ❌ Ausente em todos | ✅ Backfill: inferido de `attendance_id` |
| `attendance_id` presente | → `source = QUEUE` | |
| `attendance_id` ausente | → `source = OTHER` | |

### `attendances` (11 documentos)
| Campo | Status | Ação |
|-------|--------|------|
| `source` | ❌ Ausente em todos | ✅ Backfill: mapeado de `origin` |
| `origin: QUEUE` | → `source = QUEUE` | |
| `origin: QUICK` | → `source = QUICK` | |
| `origin: MANUAL` | → `source = MANUAL` | |
| `origin: PROACTIVE` | → `source = PROACTIVE` | |
| Campo `origin` | ✅ Mantido | Compatibilidade retroativa |

### `stores` (4 documentos)
| Campo | Status | Ação |
|-------|--------|------|
| `slug` | ❌ Ausente em todos | ✅ Backfill: slugificado de `code` ou `name` |

### `notifications` (7 documentos)
| Campo | Status | Ação |
|-------|--------|------|
| `type` | ✅ Presente | Campo correto para queries |
| `event_type` | ❌ Ausente | Índice corrigido para usar `type` |

---

## Índices

### Índices Criados em P0
| Coleção | Índice | Tipo | Seguro? |
|---------|--------|------|---------|
| `tenant_memberships` | `(tenant_id, role)` | B-tree | ✅ |
| `tenant_memberships` | `(tenant_id, status)` | B-tree | ✅ |
| `stores` | `(tenant_id, status)` | B-tree | ✅ |
| `stores` | `(tenant_id, slug)` | B-tree sparse | ✅ |
| `sales` | `(tenant_id, source)` | B-tree sparse | ✅ |
| `sales` | `(tenant_id, status)` | B-tree | ✅ |
| `notifications` | `(tenant_id, event_type)` | B-tree sparse | ⚠️ Campo inexistente (corrigido) |
| `notifications` | `(tenant_id, type)` | B-tree sparse | ✅ (adicionado P0.5) |
| `goals` | `(tenant_id, period)` | B-tree | ✅ |
| `audit_logs` | `(tenant_id, entity, created_at)` | B-tree | ✅ |
| `audit_logs` | `(tenant_id, action, created_at)` | B-tree | ✅ |
| `audit_logs` | `(tenant_id, user_id, created_at)` | B-tree | ✅ |

### Índice Unique Adiado
| Coleção | Campo | Motivo |
|---------|-------|--------|
| `users` | `normalized_email` | Verificação de duplicatas necessária antes |

**Ação para produção:** Execute `python scripts/ensure_indexes.py --report-only` para verificar duplicatas antes de criar índice unique em `normalized_email`.

---

## Conflitos Encontrados

### E-mails duplicados
**Verificar antes de criar unique index em normalized_email:**

```bash
cd /app/backend
python ../scripts/ensure_indexes.py --report-only
```

Se houver duplicatas, resolver manualmente antes de criar o índice unique.

---

## Dados Inconsistentes

### Attendances sem tenant_id
Verificar com:
```bash
python3 -c "
import asyncio, os
os.chdir('/app/backend')
from dotenv import load_dotenv; load_dotenv('.env')
from motor.motor_asyncio import AsyncIOMotorClient
async def check():
    c = AsyncIOMotorClient(os.environ['MONGO_URL'])
    db = c[os.environ['DB_NAME']]
    n = await db.attendances.count_documents({'tenant_id': {'\$exists': False}})
    print(f'Attendances sem tenant_id: {n}')
asyncio.run(check())
"
```

---

## Ações Manuais Necessárias

1. **Configurar `SEED_DEMO_DATA=false`** no `.env` de produção
2. **Configurar `CORS_ORIGINS`** explicitamente em produção
3. **Configurar `ENVIRONMENT=production`** em produção
4. **Verificar duplicatas** antes de criar unique index em `users.normalized_email`
5. **Documentar `JWT_SECRET`** forte em produção (mínimo 32 chars)

---

## Riscos Remanescentes

| Risco | Severidade | Mitigação |
|-------|-----------|-----------|
| Rate limiter em memória (não distribuído) | P1 | OK para piloto mono-instância |
| `normalized_email` unique index ainda não criado | P1 | Bloqueado por verificação de duplicatas |
| Redis não configurado | P2 | Idempotency e sessions em MongoDB |
| CORS com `*` em dev | P1 | Documentado, produção deve setar explicitamente |

---

## Status Final

| Critério | Status |
|----------|--------|
| Scripts de backfill idempotentes | ✅ |
| Índices criados com segurança | ✅ |
| Duplicidades detectadas antes de unique index | ✅ |
| Dados antigos não quebram login | ✅ |
| Dados antigos não quebram dashboard | ✅ |
| Dados antigos não quebram relatórios | ✅ |
| Dados antigos não quebram vendas | ✅ |
| Dados antigos não quebram atendimentos | ✅ |
| Seed demo seguro | ✅ (SEED_DEMO_DATA guard) |
| Rollback documentado | ✅ |
| Relatório de migração existe | ✅ |
| Testes de compatibilidade passam | ✅ (test_p0_5_compatibility.py) |
