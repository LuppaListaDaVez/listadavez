# Variáveis de Ambiente — Lista da Vez SaaS

> Este documento descreve todas as variáveis de ambiente da aplicação,
> organizadas por categoria e por ambiente (dev / staging / produção).
>
> Copie `backend/.env.example` para `backend/.env` e preencha os valores.
> **Nunca commite o arquivo `.env`.**

---

## Resumo por Ambiente

| Variável | Dev | Staging | Produção |
|---|---|---|---|
| `MONGO_URL` | obrigatória | obrigatória | obrigatória |
| `DB_NAME` | obrigatória | obrigatória | obrigatória |
| `JWT_SECRET` | obrigatória (min 32 chars) | obrigatória | obrigatória |
| `ENVIRONMENT` | `development` | `staging` | `production` |
| `CORS_ORIGINS` | `*` permitido | lista explícita | lista explícita (**obrigatória**) |
| `SEED_DEMO_DATA` | `true` ok | `true` com aviso | `false` (aviso se `true`) |
| `REDIS_URL` | opcional | recomendado | recomendado |
| `SMTP_HOST` | opcional | opcional | recomendado |
| `BACKUP_ENCRYPTION_KEY` | opcional | recomendado | recomendado |

---

## 1. Core — Banco de Dados

| Variável | Obrigatória | Exemplo | Descrição |
|---|---|---|---|
| `MONGO_URL` | Sim | `mongodb://localhost:27017` | Connection string do MongoDB |
| `DB_NAME` | Sim | `listadavez` | Nome do banco de dados |

**Em produção com autenticação:**
```
MONGO_URL=mongodb://usuario:senha@host:27017/listadavez?authSource=admin
```

---

## 2. Autenticação JWT

| Variável | Obrigatória | Exemplo | Descrição |
|---|---|---|---|
| `JWT_SECRET` | Sim | `openssl rand -hex 32` | Secret para assinar tokens JWT (mínimo 32 chars) |
| `JWT_ALGORITHM` | Não | `HS256` | Algoritmo JWT (padrão: HS256) |
| `ACCESS_TOKEN_EXPIRES_MIN` | Não | `30` | Expiração do access token em minutos |
| `REFRESH_TOKEN_EXPIRES_DAYS` | Não | `7` | Expiração do refresh token em dias |

**Gerar um JWT_SECRET seguro:**
```bash
openssl rand -hex 32
```

---

## 3. Aplicação

| Variável | Obrigatória | Valores | Descrição |
|---|---|---|---|
| `ENVIRONMENT` | Não | `development` / `staging` / `production` | Controla comportamento de segurança |
| `LOG_LEVEL` | Não | `DEBUG` / `INFO` / `WARNING` / `ERROR` | Nível de log (padrão: `INFO`) |
| `FRONTEND_URL` | Não | `https://app.seudominio.com.br` | URL do frontend (usada em redirects) |
| `BACKEND_URL` | Não | `https://api.seudominio.com.br` | URL do backend |

---

## 4. CORS

| Variável | Obrigatória em Prod | Exemplo | Descrição |
|---|---|---|---|
| `CORS_ORIGINS` | Sim | `https://app.seudominio.com.br` | Origens permitidas, separadas por vírgula |

**Regras:**
- Em `ENVIRONMENT=production`, **`*` é rejeitado** — boot falha.
- Múltiplas origens: `https://app.seudominio.com.br,https://admin.seudominio.com.br`
- Em desenvolvimento, `*` é aceito (com warning nos logs).

---

## 5. Super Admin e Seed Demo

| Variável | Obrigatória | Exemplo | Descrição |
|---|---|---|---|
| `SUPER_ADMIN_EMAIL` | Sim | `superadmin@listadavez.com.br` | E-mail do super admin criado no seed |
| `SUPER_ADMIN_PASSWORD` | Sim | `MinhaS3nha@Forte` | Senha do super admin |
| `SEED_DEMO_DATA` | Não | `true` / `false` | Se `true`, cria tenant demo com credenciais de teste |
| `TENANT_ADMIN_EMAIL` | Não | `admin@demo.com.br` | E-mail do admin demo |
| `TENANT_ADMIN_PASSWORD` | Não | `Admin@123456` | Senha do admin demo |

**Em produção:**
- `SEED_DEMO_DATA=false` (padrão).
- Se `SEED_DEMO_DATA=true`, um warning é emitido nos logs.
- Seed é idempotente — não recria registros existentes.

---

## 6. Redis e Realtime

| Variável | Obrigatória | Exemplo | Descrição |
|---|---|---|---|
| `REALTIME_MODE` | Não | `in_memory` / `redis` | Adapter de realtime (padrão: `in_memory`) |
| `REDIS_URL` | Não | `redis://localhost:6379/0` | URL do Redis (com autenticação: `redis://:senha@host:6379/0`) |

**Comportamento sem Redis:**
- Outbox, export jobs e realtime usam adapter in-memory.
- **Não funciona em múltiplas instâncias** — cada instância terá estado isolado.
- Recomendado para produção com mais de 1 réplica: configure Redis.

---

## 7. Storage (Exports e Backups)

| Variável | Obrigatória | Exemplo | Descrição |
|---|---|---|---|
| `STORAGE_PROVIDER` | Não | `local` / `s3_compatible` | Provider de storage (padrão: `local`) |
| `S3_BUCKET` | Não | `lista-da-vez-exports` | Nome do bucket S3 |
| `S3_REGION` | Não | `us-east-1` | Região AWS S3 |
| `S3_ACCESS_KEY` | Não | — | Access key S3 |
| `S3_SECRET_KEY` | Não | — | Secret key S3 |
| `S3_ENDPOINT_URL` | Não | `https://s3.amazonaws.com` | Endpoint S3-compatible (para MinIO, Cloudflare R2, etc.) |

---

## 8. E-mail / SMTP

| Variável | Obrigatória | Exemplo | Descrição |
|---|---|---|---|
| `SMTP_HOST` | Não | `smtp.sendgrid.net` | Host SMTP |
| `SMTP_PORT` | Não | `587` | Porta SMTP |
| `SMTP_USER` | Não | `apikey` | Usuário SMTP |
| `SMTP_PASSWORD` | Não | — | Senha SMTP |
| `SMTP_FROM` | Não | `noreply@listadavez.com.br` | E-mail remetente |
| `SMTP_TLS` | Não | `true` | Usar TLS (padrão: `true`) |

---

## 9. Push Notifications

| Variável | Obrigatória | Exemplo | Descrição |
|---|---|---|---|
| `PUSH_PROVIDER` | Não | `firebase` | Provider de push |
| `PUSH_API_KEY` | Não | — | API key do provider |

---

## 10. Backup

| Variável | Obrigatória | Exemplo | Descrição |
|---|---|---|---|
| `BACKUP_ENCRYPTION_KEY` | Não | `openssl rand -hex 32` | Chave de criptografia dos backups |
| `BACKUP_S3_BUCKET` | Não | `lista-da-vez-backups` | Bucket S3 para backups |
| `BACKUP_RETENTION_DAYS` | Não | `30` | Dias de retenção dos backups |

---

## Comportamento de Boot

O sistema valida variáveis no startup (`server.py: _validate_required_env()`):

```
Boot → Valida MONGO_URL, DB_NAME, JWT_SECRET
     → Se ENVIRONMENT=production:
         - JWT_SECRET < 32 chars → FALHA
         - CORS_ORIGINS=* → FALHA
         - SEED_DEMO_DATA=true → WARNING
     → Se REDIS_URL ausente → WARNING (in-memory fallback)
     → Se SMTP_HOST ausente em prod → WARNING
     → Se BACKUP_ENCRYPTION_KEY ausente em prod → WARNING
```
