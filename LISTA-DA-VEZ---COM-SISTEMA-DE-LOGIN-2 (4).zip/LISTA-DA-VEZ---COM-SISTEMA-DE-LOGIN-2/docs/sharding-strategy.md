# Estratégia de Sharding e Particionamento — Lista da Vez

**Versão:** P2-B  
**Data:** 2026-06-29  
**Decisão atual:** Manter MongoDB sem sharding até ~500 tenants / 50M documentos  

---

## Análise de Crescimento por Coleção

### Coleções de Alto Volume (candidatas a sharding/TTL)

| Coleção | Crescimento Estimado | Shard Key Sugerida | Prioridade |
|---|---|---|---|
| `attendances` | ~200/dia por loja | `{tenant_id, created_at}` | P1 |
| `sales` | ~150/dia por loja | `{tenant_id, store_id}` | P1 |
| `queue_events` | ~500/dia por loja | `{tenant_id, store_id}` | P2 |
| `notifications` | ~100/dia por usuário | `{tenant_id, user_id}` | P2 |
| `audit_logs` | ~1000/dia por tenant | `{tenant_id, created_at}` | P3 |
| `security_events` | ~50/dia por tenant | `{tenant_id, created_at}` | P3 |
| `api_request_logs` | ~10k/dia | `{tenant_id, created_at}` | P2 + TTL 30d |

### Coleções de Baixo Volume (sem sharding necessário)

- `tenants` — máximo 500 docs
- `users` — máximo 50k docs
- `tenant_memberships` — máximo 500k docs
- `stores` — máximo 5k docs
- `queues` — máximo 5k docs
- `feature_flags` — máximo 10k docs

---

## Limites do Sistema Atual (sem sharding)

Com instância MongoDB única (M10 Atlas ou equivalente):

| Métrica | Limite Confortável | Limite Absoluto |
|---|---|---|
| Documentos em `attendances` | ~10M | ~50M |
| Documentos em `sales` | ~10M | ~50M |
| Tenants ativos | ~500 | ~2.000 |
| Usuários simultâneos | ~5.000 | ~20.000 |
| RPS na API | ~2.000 | ~10.000 |

**Ação:** Monitorar tamanho das coleções mensalmente. Ativar sharding quando `attendances` ou `sales` atingirem 5M documentos.

---

## Estratégia de Sharding (quando necessário)

### Pré-requisitos

1. MongoDB 6.0+ com replica set (mínimo 3 nós)
2. Config servers (3 instâncias)
3. Mongos router
4. Índices compatíveis com shard key

### Shard Keys por Coleção

```js
// attendances — compound shard key
sh.shardCollection("listadavez.attendances", { tenant_id: 1, created_at: 1 })

// sales — compound shard key
sh.shardCollection("listadavez.sales", { tenant_id: 1, store_id: 1 })

// notifications — hashed para distribuição uniforme
sh.shardCollection("listadavez.notifications", { tenant_id: "hashed" })

// audit_logs — range para queries de período
sh.shardCollection("listadavez.audit_logs", { tenant_id: 1, created_at: 1 })

// queue_events — compound com store_id
sh.shardCollection("listadavez.queue_events", { tenant_id: 1, store_id: 1 })
```

### Regras de Shard Key

1. **Sempre incluir `tenant_id`** — todas as queries filtram por tenant.
2. **Usar `created_at` como segunda chave** para coleções com range queries de período.
3. **Usar `store_id`** quando queries são sempre por loja.
4. **Hashed sharding** apenas quando não há range queries por tempo.

---

## Estratégia de TTL (Retenção Automática)

```js
// api_request_logs — 30 dias
db.api_request_logs.createIndex({ created_at: 1 }, { expireAfterSeconds: 2592000 })

// security_events (baixo risco) — 90 dias (alto risco: nunca expirar)
// Gerenciado pela retention_policy_service.py

// outbox events PUBLISHED — 7 dias
db.event_outbox.createIndex(
  { published_at: 1 },
  { expireAfterSeconds: 604800, partialFilterExpression: { status: "PUBLISHED" } }
)
```

---

## Plano de Migração para Sharding

### Fase 1 — Preparação (AGORA)
- [x] Todos os índices existentes incluem `tenant_id` como primeiro campo
- [x] Nenhuma query é feita sem `tenant_id` (BaseRepository garante)
- [x] `created_at` indexado em coleções de alto volume

### Fase 2 — Trigger (quando `attendances` > 5M)
1. Provisionar replica set de 3 nós
2. Adicionar config servers e mongos
3. Ativar sharding no banco
4. `sh.shardCollection()` nas coleções P1
5. Validar distribuição de chunks
6. Monitorar chunk migrations por 7 dias

### Fase 3 — Expansão (quando `sales` > 5M)
- Aplicar sharding nas coleções P2
- Revisar shard keys com base em padrões reais de query

---

## Scripts de Análise de Cardinalidade

```python
# Rodar mensalmente para monitorar crescimento
import asyncio
from motor.motor_asyncio import AsyncIOMotorClient

async def analyze_collections():
    client = AsyncIOMotorClient("mongodb://localhost:27017")
    db = client["test_database"]
    
    collections = ["attendances", "sales", "notifications", "audit_logs", 
                   "queue_events", "api_request_logs", "event_outbox"]
    
    for col_name in collections:
        col = db[col_name]
        total = await col.count_documents({})
        stats = await db.command("collStats", col_name)
        size_mb = stats.get("size", 0) / 1024 / 1024
        print(f"{col_name:25} docs={total:>10,} size={size_mb:>8.1f}MB")
    
    client.close()

asyncio.run(analyze_collections())
```

---

## Recomendação Atual

**Não aplicar sharding agora.** O sistema atual suporta 500 empresas confortavelmente com:
- Índices corretos (já implementados)
- TTL nas coleções de alto volume (retention_policy_service.py)
- Arquivamento de dados antigos (backup-restore-runbook.md)
- MongoDB M10 Atlas (ou equivalente de ~16GB RAM)

Revisitar quando qualquer coleção atingir **5M documentos**.
