# Multitenancy Checklist — Lista da Vez SaaS

**Versão:** 1.0.0-p2  
**Responsável:** Tech Lead / Principal Engineer  
**Última atualização:** 2026-06

Checklist obrigatório para qualquer feature, endpoint ou script que toque dados tenant-scoped.

---

## 1. Modelo de Isolamento

O sistema usa **soft isolation por tenant_id**: todos os documentos tenant-scoped contêm o campo `tenant_id`. Não há banco de dados separado por tenant.

```
tenant: { id, slug, name, ... }
  └─ store: { tenant_id, id, ... }
       └─ queue: { tenant_id, store_id, ... }
       └─ seller_profile: { tenant_id, user_id, store_id, ... }
       └─ attendance: { tenant_id, store_id, seller_id, ... }
       └─ sale: { tenant_id, store_id, seller_id, ... }
  └─ goal: { tenant_id, store_id?, ... }
  └─ notification: { tenant_id, user_id, ... }
  └─ export_job: { tenant_id, created_by, ... }
```

---

## 2. Checklist para Novo Endpoint Tenant-Scoped

### 2.1 Path e JWT
- [ ] Path inclui `/{tenant_slug}/` (ex: `/api/tenants/{slug}/recurso`)
- [ ] Middleware valida `jwt.tenant_slug == path_slug` → 401 se diferente
- [ ] `tenant_id` extraído via `TenantRepository.get_by_slug(slug)` — nunca do body
- [ ] Tenant com status `INACTIVE` ou `SUSPENDED` → 403

### 2.2 Queries no Banco
- [ ] TODA query inclui `{"tenant_id": tenant_id}` no filtro
- [ ] Nunca usar `db.collection.find_one({"id": entity_id})` sem tenant_id
- [ ] Usar `BaseRepository.find_by_id_for_tenant(tenant_id, entity_id)` para lookups por ID
- [ ] Aggregation pipelines incluem `$match: {tenant_id: tenant_id}` como primeiro estágio
- [ ] Lookup (`$lookup`) em coleções tenant-scoped inclui tenant_id no pipeline

### 2.3 Resposta
- [ ] Resposta nunca inclui `tenant_id` de outros tenants
- [ ] Resposta nunca inclui dados de stores/sellers/attendances de outros tenants
- [ ] Lista de resultados sempre filtrada por tenant_id (sem "vazar" via paginação)
- [ ] Endpoint retorna 404 (não 403) para entidades que existem mas são de outro tenant

### 2.4 Feature Flags
- [ ] Features opcionais verificadas via `feature_flag_service.is_enabled(tenant_id, flag_key)`
- [ ] Feature desabilitada → 403 com `{"error": "FEATURE_DISABLED", "feature": "..."}`
- [ ] Flags documentadas em `feature_flags.py`

---

## 3. Checklist para Novo Script de Seed/Migração

- [ ] Script verifica `ENVIRONMENT != "production"` antes de executar
- [ ] Script não usa dados reais (emails, CPFs, CNPJs reais)
- [ ] Script é idempotente (re-executável sem duplicar dados)
- [ ] Script aceita parâmetro `--dry-run` para simulação
- [ ] Script documenta quais tenants são afetados
- [ ] Credenciais geradas são salvas em `/app/fixtures/` (nunca em código)
- [ ] Fixture file está no `.gitignore`

---

## 4. Coleções e seus Campos tenant_id

| Coleção | Campo de isolamento | Índice |
|---|---|---|
| tenants | `id` (é o tenant) | `slug` único |
| stores | `tenant_id` | `(tenant_id, id)` |
| seller_profiles | `tenant_id` | `(tenant_id, user_id)` |
| queues | `tenant_id` | `(tenant_id, store_id)` |
| queue_entries | `tenant_id` | `(tenant_id, store_id, status)` |
| attendances | `tenant_id` | `(tenant_id, store_id, status)` |
| sales | `tenant_id` | `(tenant_id, store_id, created_at)` |
| goals | `tenant_id` | `(tenant_id, status)` |
| notifications | `tenant_id` | `(tenant_id, user_id, read)` |
| export_jobs | `tenant_id` | `(tenant_id, created_by)` |
| feedbacks | `tenant_id` | `(tenant_id, seller_id)` |
| tenant_memberships | `tenant_id` | `(tenant_id, user_id)` |
| tenant_features | `tenant_id` | `(tenant_id, feature_key)` |
| store_settings | `tenant_id` | `(tenant_id, store_id)` |

**Coleções globais (sem tenant_id):**
- `plans`, `features`, `audit_logs`

---

## 5. Testes Obrigatórios para Feature Tenant-Scoped

Antes de mergear qualquer feature com dados tenant-scoped:

```python
# 1. Cross-tenant: token do tenant A não acessa dados do tenant B
def test_cross_tenant_isolation(client, token_a, token_b):
    r = client.get(f"/api/tenants/tenant-b/meu-recurso",
                   headers={"Authorization": f"Bearer {token_a}"})
    assert r.status_code in (401, 403, 404)

# 2. IDOR: ID de entidade do tenant B não retorna dados via tenant A
def test_idor_entity_b_via_tenant_a(client, token_a, entity_b_id):
    r = client.get(f"/api/tenants/tenant-a/meu-recurso/{entity_b_id}",
                   headers={"Authorization": f"Bearer {token_a}"})
    assert r.status_code in (400, 403, 404)  # nunca 200

# 3. Listagem não vaza dados de outros tenants
def test_listing_only_own_tenant_data(client, token_a):
    r = client.get(f"/api/tenants/tenant-a/meu-recurso",
                   headers={"Authorization": f"Bearer {token_a}"})
    assert r.status_code == 200
    for item in r.json():
        assert item.get("tenant_id") != "tenant-b-id"
```

---

## 6. Limites por Tenant (Planos)

| Recurso | Plano Basic | Plano Pro | Plano Enterprise |
|---|---|---|---|
| Lojas | 1 | 5 | Ilimitado |
| Vendedores | 10 | 50 | Ilimitado |
| Retenção de dados | 30 dias | 90 dias | 365 dias |
| Export jobs simultâneos | 1 | 3 | 10 |
| Notificações/mês | 100 | 1000 | Ilimitado |

---

## 7. Isolamento em Produção com 500+ Tenants

Para escala enterprise, o isolamento por `tenant_id` continua funcional, mas:
- **Índices compostos** são críticos: `(tenant_id, campo_filtrado)` em todas as coleções
- **Read concern** deve ser `majority` para operações críticas
- **Aggregation pipelines** devem sempre iniciar com `$match: {tenant_id}`
- Ver `/docs/500-companies-readiness-plan.md` para plano completo
