# API Versioning Plan — Lista da Vez SaaS

**Versão:** 1.0.0-p2  
**Responsável:** Tech Lead  
**Última atualização:** 2026-06

---

## 1. Estado Atual

### 1.1 Versão Atual (v0 — implícita)

Todas as rotas existem sem prefixo de versão:

```
/api/tenants/{slug}/stores
/api/tenants/{slug}/queue
/api/tenants/{slug}/attendances
...
```

### 1.2 Alias v1 (implementado na P2)

Criamos `/api/v1/...` como alias das rotas v0 em `interfaces/v1/router.py`:

```python
# interfaces/v1/router.py
v1_router = APIRouter(prefix="/api/v1")
# Inclui todos os routers existentes com o prefixo /api/v1
```

Este alias garante:
- Nenhuma breaking change (v0 continua funcionando)
- Clientes podem migrar para v1 gradualmente
- Testes e documentação podem referenciar `/api/v1/...`

---

## 2. Estratégia de Versioning

### 2.1 Decisão: Path-based Versioning

Escolhemos **path-based versioning** (`/api/v1/...`) ao invés de:
- Header versioning (`Api-Version: 1`) — complexo de debugar
- Query param (`?version=1`) — não RESTful
- Accept header (`Accept: application/vnd.listadavez.v1+json`) — mais complexo

**Justificativa:** Path-based é mais explícito, testável e suportado por todos os clients.

### 2.2 Política de Deprecação

```
v0 (atual):    STABLE — manter indefinidamente para retrocompatibilidade
v1 (alias):    STABLE — mesmo contrato que v0, prefixo diferente
v2 (futuro):   introduzir apenas com breaking changes reais
```

**Breaking change** = qualquer mudança que quebra clients existentes:
- Remover campo de response
- Alterar tipo de campo
- Mudar comportamento de endpoint existente
- Renomear rota

**Non-breaking change** (pode ser feito sem nova versão):
- Adicionar campo opcional em response
- Adicionar novo endpoint
- Adicionar parâmetro opcional

### 2.3 Ciclo de Vida de Versão

```
v0: STABLE → DEPRECATED (6 meses de aviso) → REMOVED
v1: CURRENT → eventual STABLE → eventual DEPRECATED
v2: quando necessário → CURRENT
```

---

## 3. Contratos de Resposta Padronizados (v1)

### 3.1 Schemas Implementados (`interfaces/v1/schemas.py`)

```python
class ApiResponse(BaseModel):
    """Response padrão para operações de sucesso."""
    success: bool = True
    data: Any
    message: Optional[str] = None
    request_id: Optional[str] = None

class ApiError(BaseModel):
    """Response padrão para erros."""
    error: str          # Código de erro (ex: STORE_NOT_FOUND)
    message: str        # Mensagem human-readable
    request_id: str
    details: Optional[Dict] = None

class PaginationMeta(BaseModel):
    """Metadados de paginação."""
    page: int
    page_size: int
    total: int
    total_pages: int
    has_next: bool
    has_prev: bool
```

### 3.2 Domain Error Handler

```python
# domain_error_handler: mapeia DomainError → HTTP 4xx
NotFoundError → 404
ConflictError → 409
ForbiddenError → 403
ValidationError → 422
```

---

## 4. Roadmap de Versioning

### v1 (atual — alias de v0)
- ✅ Prefixo `/api/v1/...` implementado
- ✅ Schemas padronizados: `ApiResponse`, `ApiError`, `PaginationMeta`
- ✅ Domain error handler global
- ✅ Retrocompatibilidade com v0 garantida

### v2 (futuro — quando necessário)
**Possíveis breaking changes que justificariam v2:**
- Resposta de listagem: migrar de `[item1, item2]` para `{items: [...], pagination: {...}}`
  - (Em progresso: alguns endpoints já retornam formato paginado)
- Datas: migrar de ISO string para objeto `{utc: "...", local: "...", tz: "..."}`
- Autenticação: migrar de JWT em Header para Cookie HttpOnly (maior segurança)

**Prazo estimado para v2:** Somente após 6 meses de v1 estável e com necessidade real.

---

## 5. Documentação de API

### 5.1 OpenAPI Schema
- Swagger UI: `GET /api/docs` (apenas em `ENVIRONMENT != production`)
- ReDoc: `GET /api/redoc`
- JSON schema: `GET /api/openapi.json`

### 5.2 Exemplos de Request/Response
- Ver `/docs/api-guidelines.md` para padrões completos

### 5.3 Changelog de API
Todo breaking change deve ser documentado em `/CHANGELOG.md` com:
```markdown
## v2.0.0 (YYYY-MM-DD)
### Breaking Changes
- Endpoint GET /api/v1/tenants/{slug}/stores agora retorna formato paginado
  Antes: `[{store1}, {store2}]`
  Depois: `{items: [{store1}, {store2}], pagination: {...}}`
```

---

## 6. Compatibilidade de Clientes

### 6.1 SDKs e Integrações Conhecidas
- **Frontend React:** usa `/api/` (v0) — migrar para `/api/v1/` gradualmente
- **Scripts de carga:** `load_test_enterprise.py` usa `/api/` (v0) — compatível
- **Testes automatizados:** `test_p2_5_*.py` testam ambos `/api/` e `/api/v1/`

### 6.2 Comunicação de Breaking Changes
- Anúncio em dashboard do tenant: 90 dias antes
- Email para contatos técnicos: 90 dias antes
- Período de suporte dual (v1 + v2): mínimo 6 meses
