# 500 Companies Readiness Plan — Lista da Vez SaaS

**Versão:** 1.0.0-p2  
**Responsável:** Principal Engineer / SRE  
**Última atualização:** 2026-06

---

## 1. Baseline Atual

| Dimensão | Estado Atual (P2) | Capacidade Estimada |
|---|---|---|
| Tenants ativos | 2 demo + 20 enterprise (seed) | ~50-100 (sem otimização) |
| Lojas | 60 | ~300 |
| Vendedores | 360 | ~3.000 |
| Atendimentos/dia | ~500 (seed) | ~50.000 |
| Conexões WS simultâneas | ~10 (single instance) | ~200 (single instance) |
| MongoDB | Single node, sem auth | --- |
| Redis | Single node, sem auth | --- |

---

## 2. Arquitetura Alvo (500 Empresas)

```
                    ┌─────────────────────────────────┐
Internet ──►  CDN   │  Load Balancer / Kubernetes      │
                    │  Ingress (nginx)                  │
                    └─┬───────────────────────────────┘
                      │
         ┌────────────┼────────────────┐
         ▼            ▼                ▼
   Frontend Pod  Backend Pod 1   Backend Pod 2 ... Pod N
   (React SPA)   (FastAPI)       (FastAPI)
   Stateless     ┌────────┐      ┌────────┐
                 │  App   │      │  App   │
                 └────┬───┘      └────┬───┘
                      │               │
         ┌────────────┼───────────────┤
         ▼            ▼               ▼
   MongoDB Replica   Redis Cluster    Object Storage
   Set (3 nodes)     (3 shards)      (backups/exports)
```

### 2.1 Backend (FastAPI)
- **Pods:** 3-5 instâncias (horizontal scaling)
- **CPU:** 2 vCPU / pod, 4 vCPU nos picos
- **RAM:** 1 GB / pod
- **Autoscaling:** HPA baseado em CPU (70%) e custom metric `queue_rps`
- **Ver:** `/docs/autoscaling.md`

### 2.2 MongoDB
- **Topology:** Replica Set 3 nós (1 primary + 2 secondary)
- **Read preference:** `secondaryPreferred` para queries de leitura
- **Write concern:** `majority` para operações críticas
- **Índices:** Ver `/docs/database-index-guidelines.md`
- **Sharding (futuro P4):** Shard key `tenant_id` quando > 500 tenants com alto volume

### 2.3 Redis
- **Topology:** Redis Cluster (3 masters + 3 replicas) ou Redis Sentinel
- **Uso:** Rate limiting + Pub/Sub realtime + Idempotency keys + Outbox stream
- **Memória estimada (500 tenants):** ~2 GB
- **Expiração:** TTL configurado em todas as chaves

### 2.4 WebSocket (500 Tenants)
- **Conexões estimadas:** 500 tenants × 5 lojas × 10 vendedores = 25.000 conexões WS
- **Por Pod:** ~5.000 conexões simultâneas (viável com asyncio)
- **Distribuição:** Redis Pub/Sub garante que eventos chegam a todos os pods
- **Timeout:** Heartbeat 30s + timeout 45s reduz conexões zumbis

---

## 3. Banco de Dados — Capacidade e Índices

### 3.1 Volumes Estimados (500 tenants × 12 meses)

| Coleção | Docs/Tenant/Mês | Total 500 Tenants/Ano |
|---|---|---|
| `attendances` | 1.000 | 6.000.000 |
| `sales` | 300 | 1.800.000 |
| `notifications` | 500 | 3.000.000 |
| `queue_entries` | 2.000 | 12.000.000 |
| `export_jobs` | 50 | 300.000 |

### 3.2 Índices Críticos para 500 Tenants
Todos os índices compostos em `/docs/database-index-guidelines.md` devem existir.

**Índice mais crítico:**
```javascript
db.attendances.createIndex(
  {"tenant_id": 1, "store_id": 1, "status": 1, "created_at": -1},
  {background: true}
)
```

### 3.3 Retenção de Dados
- Implementar TTL automático por coleção (ver `/docs/database-index-guidelines.md`)
- Deletar dados de tenants cancelados após período de retenção contratual

---

## 4. Rate Limiting para 500 Tenants

Com 500 tenants ativos simultâneos:

| Endpoint | Limite Atual | Limite Alvo 500 Tenants |
|---|---|---|
| Login por tenant | 50/15min/IP | 100/15min/IP (admins distribuídos) |
| API geral | sem limite | 1000/min/tenant |
| Export async | sem limite | 3/hora/tenant (Pro) / 10/hora (Enterprise) |
| WebSocket connect | sem limite | 50 conexões/tenant/store |

---

## 5. Workers e Background Tasks

Com 500 tenants, processos em background escalam:

| Worker | Atual | Alvo 500 Tenants |
|---|---|---|
| Export CSV | Background task inline | Celery worker dedicado |
| Outbox Redis | Background task inline | Celery worker dedicado |
| Ranking calculation | On-demand | Scheduled job a cada 15min |
| Notification delivery | Background task | Celery com prioridade |
| Data cleanup (TTL) | Manual | Scheduled job diário |

**Ver:** `/docs/workers-and-queues.md`

---

## 6. Observabilidade com 500 Tenants

### 6.1 Métricas Essenciais (Prometheus)
```
http_request_duration_seconds{tenant, endpoint}   # Latência por tenant
queue_operations_total{tenant, operation}          # Ops de fila
websocket_connections_active{tenant}               # Conexões WS
outbox_pending_count                               # Saúde do outbox
error_rate{tenant, endpoint}                       # Taxa de erro por tenant
```

### 6.2 Alertas Críticos
- `http_request_duration_seconds{p95} > 1s` — latência degradada
- `error_rate > 5%` — falhas sistêmicas
- `websocket_connections_active / total_sellers < 0.3` — queda de conectividade
- `outbox_pending_count > 1000` — worker parado

### 6.3 Dashboards Grafana
- Dashboard por tenant (top 10 tenants por volume)
- Dashboard de sistema (CPU, RAM, MongoDB IOPS, Redis memory)
- Dashboard de WebSocket (conexões, mensagens/s, reconexões)

---

## 7. Backup e Recovery

| Métrica | Alvo |
|---|---|
| RPO (Recovery Point Objective) | 1 hora |
| RTO (Recovery Time Objective) | 4 horas |
| Backup frequência | A cada 6 horas |
| Retenção de backups | 90 dias |
| Teste de restore | Mensal |

**Ver:** `/docs/backup-restore-runbook.md`

---

## 8. Plano de Evolução por Fase

| Fase | Milestone | Tenants | Ação Principal |
|---|---|---|---|
| Atual (P2) | Arquitetura base | ~50 | Clean Arch, índices, tests |
| P3 | Auditoria e qualidade | ~100 | Observabilidade, circuit breakers |
| P4 | Escala horizontal | ~250 | Celery workers, MongoDB RS |
| P5 | Escala enterprise | ~500 | Redis Cluster, multi-shard |
| P6 | Escala global | ~1000+ | CDN, read replicas por região |

---

## 9. Riscos Remanescentes

| Risco | Severidade | Probabilidade | Mitigação |
|---|---|---|---|
| MongoDB COLLSCAN em queries sem índice | ALTO | MÉDIO | Criar todos os índices da guia |
| Redis single point of failure | ALTO | BAIXO | Redis Sentinel/Cluster em prod |
| WS sem reconexão automática em todos os casos | MÉDIO | BAIXO | Testar edge cases de rede |
| Export CSV bloqueante em arquivo muito grande | MÉDIO | MÉDIO | Streaming CSV ou limit de linhas |
| Background tasks perdidas em SIGTERM | MÉDIO | BAIXO | Graceful shutdown implementado |
| tenant_id não indexado em coleção nova | ALTO | MÉDIO | Checklist obrigatório de índice |

---

## 10. SLOs Alvo (500 Empresas)

| Operação | P50 | P95 | P99 | Disponibilidade |
|---|---|---|---|---|
| Dashboard summary | < 100ms | < 500ms | < 1s | 99.9% |
| Queue state | < 50ms | < 200ms | < 500ms | 99.95% |
| Login | < 200ms | < 400ms | < 1s | 99.9% |
| WebSocket event delivery | < 100ms | < 300ms | < 1s | 99.5% |
| Export CSV (async) | N/A | < 30s | < 60s | 99.5% |
| API geral | < 100ms | < 500ms | < 2s | 99.9% |
