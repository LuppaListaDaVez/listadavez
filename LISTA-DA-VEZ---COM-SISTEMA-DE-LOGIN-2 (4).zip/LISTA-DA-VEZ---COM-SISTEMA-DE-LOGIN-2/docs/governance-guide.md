# Guia de Governança Técnica — Lista da Vez

**Versão:** P2  
**Data:** 2026-06-29  

---

## Checklist para Todo Novo Endpoint

Antes de abrir PR com qualquer novo endpoint, responda:

| # | Pergunta | Se SIM | Se NÃO |
|---|---|---|---|
| 1 | Qual `tenant_id` filtra os dados? | Documentar e usar no BaseRepository | Não é tenant-scoped? Confirmar com arquiteto |
| 2 | Qual `permission_key` protege? | Adicionar `has_permission()` | Endpoint público? Documentar razão |
| 3 | Qual `feature_flag` controla? | `await is_enabled(tenant_id, "flag_key")` | Feature sempre disponível? OK |
| 4 | Precisa de idempotência? | Adicionar `Idempotency-Key` + `idempotency_service` | OK |
| 5 | Precisa de rate limit? | `make_rate_limit_dep("GROUP")` no router | OK se endpoint interno |
| 6 | Precisa de audit log? | `await create_audit_log(...)` | Ação sem impacto? OK |
| 7 | Precisa de security event? | `await record_security_event(...)` | OK se não é auth/acesso |
| 8 | Precisa de índice? | Criar em `ensure_indexes.py` | OK se query já tem índice |
| 9 | Precisa de paginação? | Usar `PaginationParams` e `page_size` | Lista sempre pequena (< 100)? OK |
| 10 | Pode expor dados pessoais? | Aplicar data masking | OK |
| 11 | Precisa de teste cross-tenant? | Adicionar no `test_p2_enterprise.py` | OK |
| 12 | Precisa de evento realtime? | `await event_bus.publish_event(...)` | OK |
| 13 | Precisa de rollback? | Documentar no endpoint e criar runbook | OK |

---

## Padrão de Nomenclatura (Naming Guide)

### Backend

```python
# Arquivos
routes_queue.py           # router FastAPI por domínio
queue_engine.py           # lógica de negócio do domínio
queue_repository.py       # acesso a dados do domínio
application/queue/        # use cases do domínio

# Funções/métodos
async def join_queue(...)              # verbo + substantivo
async def find_by_id_for_tenant(...)   # explícito sobre escopo
async def execute(ctx, inp, **kwargs)  # use cases

# Variáveis
tenant_id = "..."      # snake_case, nunca tenantId
seller_id = "..."      # explícito, nunca apenas "id"
actor_user_id = "..."  # quem está executando a ação

# Erros de domínio
class QueueConflictError(ConflictError): ...  # Entity + Error + Tipo
```

### Frontend

```js
// Arquivos
api/queue.js              // cliente de API por domínio
hooks/useRealtimeStoreEvents.js  // hook com prefixo "use"
pages/tenant/QueuePage.jsx       // Page suffix para páginas

// Funções
queueApi.join(...)         // dominio + metodo
reportsApi.createExportJob(...)

// Componentes
<AsyncExportButton />     // PascalCase, descrição clara
<RealtimeIndicator />     // sem abreviações ambíguas

// Data-testid
data-testid="queue-join-button"     // kebab-case, ação clara
data-testid="realtime-indicator"    // elemento, não estilo
```

---

## Padrão de Resposta API v1

### Sucesso
```json
{
  "data": { ... },
  "meta": { "page": 1, "page_size": 20, "total": 150, "pages": 8 },
  "request_id": "req_abc123"
}
```

### Erro
```json
{
  "error": "QUEUE_SELLER_ALREADY_IN_QUEUE",
  "message": "Vendedor já está na fila.",
  "request_id": "req_abc123",
  "details": {}
}
```

### Paginação (sempre)
- `page` começa em 1
- `page_size` padrão 20, máximo 200
- `total` obrigatório
- Nunca retornar lista sem limite

---

## Regras de Segurança Obrigatórias

```python
# 1. SEMPRE filtrar por tenant_id
# ERRADO:
doc = await db.attendances.find_one({"id": att_id})

# CERTO:
doc = await attendance_repo.find_by_id_for_tenant(tenant_id, att_id)

# 2. NUNCA aceitar tenant_id do body do request
# ERRADO:
@router.post("/data")
async def create(body: CreateRequest):
    tenant_id = body.tenant_id  # IDOR!

# CERTO:
@router.post("/data")
async def create(body: CreateRequest, ctx = Depends(resolve_tenant_context)):
    tenant_id = ctx["tenant"]["id"]  # do token, nunca do body

# 3. SEMPRE validar permissão antes de operar
if not await has_permission(tenant_id, user_id, P_QUEUE_JOIN_SELF):
    raise ForbiddenError()

# 4. NUNCA expor stack traces em produção
# Configurado no exception handler global do server.py
```

---

## Padrão de Teste Obrigatório por Tipo de Endpoint

| Tipo de Endpoint | Testes Obrigatórios |
|---|---|
| CRUD simples | Create, Read, Update, Delete + 404 + 403 |
| Tenant-scoped | + cross-tenant test (401/403) |
| Com paginação | + page_size=0, page_size=999, page=999 |
| Com rate limit | + 429 após limite |
| Com idempotência | + mesmo resultado na 2a chamada |
| Com realtime | + evento publicado no WS |
| Auth | + JWT inválido, + sessão revogada |

---

## Estrutura de Diretórios (P2)

```
backend/
├── domain/                    # Regras puras — sem banco, sem FastAPI
│   ├── base.py                # DomainError, TenantId, EntityId
│   ├── queue/                 # Erros do domínio de fila
│   ├── sales/                 # Erros do domínio de vendas
│   └── tenant/                # Erros do domínio de tenant/auth
├── application/               # Casos de uso — orquestração
│   ├── base.py                # BaseUseCase, UseCaseContext
│   ├── queue/                 # JoinQueueUseCase, FinishAttendanceUseCase
│   ├── sales/                 # CreateSaleUseCase
│   ├── notifications/         # CreateNotificationUseCase
│   ├── goals/                 # CreateGoalUseCase
│   └── rankings/              # GenerateRankingUseCase
├── infrastructure/
│   └── repositories/          # BaseRepository + 6 repos especializados
├── interfaces/
│   └── v1/                    # API v1 router, schemas, error handler
├── routes_*.py                # Rotas FastAPI (migração incremental)
└── *_service.py               # Services (migração incremental para use cases)
```
