# Rollback — Runbook

> **Lista da Vez SaaS** — Procedimentos de rollback para frontend, backend, workers, ambiente, migrações e banco.

---

## Critérios para Acionar Rollback

Acionar rollback quando:
- Taxa de erro 5xx > 5% por mais de 2 minutos consecutivos
- `/api/health/ready` retornando 503
- Login de usuários falhando sistematicamente
- Dashboard / relatórios inacessíveis
- Worker stuck (export_jobs em QUEUED > 10 minutos sem processar)
- Tenant leakage confirmado (dado de um tenant visível para outro)

**NÃO acionar rollback quando:**
- Erros 4xx (problema de cliente, não de deploy)
- Lentidão isolada em relatórios pesados (investigar antes)
- Alerta de quota/limite externo (Redis, S3)

---

## Índice
1. [Rollback de Frontend](#1-rollback-de-frontend)
2. [Rollback de Backend](#2-rollback-de-backend)
3. [Rollback de Worker](#3-rollback-de-worker)
4. [Rollback de Variável de Ambiente](#4-rollback-de-variável-de-ambiente)
5. [Rollback de Migration / Índice](#5-rollback-de-migration--índice)
6. [Rollback com Backup](#6-rollback-com-backup)
7. [Como Comunicar Incidente](#7-como-comunicar-incidente)

---

## 1. Rollback de Frontend

### Via Docker (imagem anterior)
```bash
# Listar imagens disponíveis
docker images lista-da-vez-frontend

# Redeployar imagem anterior (substituir por tag do commit anterior)
docker compose -f docker-compose.staging.yml stop frontend
docker tag lista-da-vez-frontend:COMMIT_HASH_ANTERIOR lista-da-vez-frontend:latest
docker compose -f docker-compose.staging.yml up -d frontend

# Verificar
curl -f http://localhost:3000/ -o /dev/null -w "%{http_code}"
```

### Via git (redeployar versão anterior)
```bash
# Identificar commit anterior ao problema
git log --oneline frontend/ | head -10

# Reverter para commit específico (em branch separada)
git checkout COMMIT_HASH -- frontend/
git commit -m "chore: rollback frontend para COMMIT_HASH"
git push

# Acionar pipeline CI/CD para rebuild
```

### Verificação pós-rollback
```bash
# Frontend acessível
curl -f $FRONTEND_URL -o /dev/null && echo "Frontend: OK"

# React app carregando (não retornando 404 nas rotas)
curl -f $FRONTEND_URL/demo/login -o /dev/null && echo "Rota demo/login: OK"
```

---

## 2. Rollback de Backend

### Via Docker
```bash
# Listar imagens disponíveis
docker images lista-da-vez-backend

# Rollback para imagem anterior
docker compose -f docker-compose.staging.yml stop backend
docker tag lista-da-vez-backend:COMMIT_HASH_ANTERIOR lista-da-vez-backend:latest
docker compose -f docker-compose.staging.yml up -d backend
sleep 15

# Verificar
curl -f $BACKEND_URL/api/health/live && echo "Liveness: OK"
curl -f $BACKEND_URL/api/health/ready && echo "Readiness: OK"
```

### Via supervisor (ambiente de desenvolvimento)
```bash
# Reverter arquivo específico via git
git checkout COMMIT_HASH -- backend/server.py
sudo supervisorctl restart backend
sleep 5
curl -f $BACKEND_URL/api/health
```

### Verificação pós-rollback
```bash
# Health check completo
curl -s $BACKEND_URL/api/health/ready | python3 -m json.tool

# Teste de autenticação
curl -s -X POST $BACKEND_URL/api/tenants/demo/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@demo.com","password":"Admin@123456"}' | \
  python3 -c "import sys,json; d=json.load(sys.stdin); print('Auth:', 'OK' if d.get('access_token') else 'FAIL')"
```

---

## 3. Rollback de Worker

Os workers (outbox, export_jobs) são parte do processo backend.
Rollback do backend faz rollback dos workers automaticamente.

### Verificar workers após rollback
```bash
# Logs do outbox
grep "OUTBOX_" /var/log/supervisor/backend.out.log | tail -5

# Logs do export dispatcher
grep "EXPORT_DISPATCHER" /var/log/supervisor/backend.out.log | tail -5

# Jobs travados (PROCESSING por mais de 10 min)
# MongoDB:
# db.export_jobs.find({
#   status: "PROCESSING",
#   started_at: { $lt: new Date(Date.now() - 10*60*1000).toISOString() }
# })
```

### Requeue de jobs travados após rollback
```javascript
// MongoDB shell
db.export_jobs.updateMany(
  { status: "PROCESSING" },
  { $set: { status: "QUEUED", started_at: null } }
)
```

---

## 4. Rollback de Variável de Ambiente

Se um deploy mudou uma variável de ambiente e causou problema:

```bash
# 1. Identificar a variável problemática nos logs
grep "SECURITY_WARNING\|RuntimeError\|ERROR" /var/log/supervisor/backend.err.log | tail -20

# 2. Restaurar valor anterior da variável
# Editar .env ou gerenciador de secrets

# 3. Reiniciar para aplicar
docker compose restart backend
# ou
sudo supervisorctl restart backend

# 4. Verificar boot sem erros
tail -20 /var/log/supervisor/backend.err.log

# 5. Health check
curl -f $BACKEND_URL/api/health/ready
```

---

## 5. Rollback de Migration / Índice

### Índices (criação é segura, remoção é o rollback)
```javascript
// Ver índices da coleção
db.export_jobs.getIndexes()

// Remover índice específico pelo nome
db.export_jobs.dropIndex("expires_at_1")

// Remover índice composto
db.attendances.dropIndex("tenant_id_1_store_id_1_created_at_-1")
```

### Backfill P0.5 (é idempotente, não pode ser "desfeito" facilmente)
O backfill adiciona campos que não existiam. Para reverter:
```javascript
// Remover campo adicionado pelo backfill (use com EXTREMA cautela)
db.users.updateMany(
  { normalized_email: { $exists: true } },
  { $unset: { normalized_email: "" } }
)
```
> ⚠️ Reverter backfill pode quebrar queries que dependem do campo. Consulte a equipe antes.

---

## 6. Rollback com Backup

Se o rollback de código não resolver, restaurar dados:

1. Siga o [Backup/Restore Runbook](backup-restore-runbook.md) — seção 5 (Restore em Produção)
2. Identifique o backup do momento antes do deploy problemático
3. Aplique o restore com aprovação
4. Faça rollback do código também (para a versão que estava rodando naquele backup)

---

## 7. Como Comunicar Incidente

### Template de comunicação

```
🔴 INCIDENTE — Lista da Vez [ENVIRONMENT]

Horário: 
Impacto: [ex: "Login indisponível para todos os tenants"]
Status: INVESTIGANDO / RESOLVIDO

Causa raiz identificada: 
Ação em andamento: 
Estimativa de resolução: 

Próxima atualização em: [horário]
```

### Canais (configurar conforme equipe)
- Slack #incidents
- E-mail para clientes afetados (se > 30 min)
- Status page (se existir)

### Após resolução
```
✅ INCIDENTE RESOLVIDO — Lista da Vez [ENVIRONMENT]

Duração: 
Causa: 
Resolução: 
Ação preventiva: 
Post-mortem em: [data]
```
