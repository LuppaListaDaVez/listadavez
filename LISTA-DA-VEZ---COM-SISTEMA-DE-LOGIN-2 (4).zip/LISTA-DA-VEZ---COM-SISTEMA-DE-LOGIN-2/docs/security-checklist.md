# Security Checklist — Lista da Vez SaaS

**Versão:** 1.0.0-p2  
**Responsável:** Security Engineer / Tech Lead  
**Última atualização:** 2026-06

Este documento é o checklist obrigatório de segurança para cada endpoint, feature e componente do sistema.

---

## 1. Checklist por Endpoint (Obrigatório)

Para cada endpoint criado ou modificado, validar todos os itens:

### 1.1 Autenticação
- [ ] Endpoint requer JWT válido (exceto rotas públicas documentadas)
- [ ] JWT verificado com `HS256` e secret do `.env` (nunca hardcoded)
- [ ] Campo `type` do JWT verificado (`access` vs `refresh`)
- [ ] Campo `tenant_slug` do JWT verificado contra slug do path
- [ ] Token expirado → 401 (não 500)
- [ ] JWT com algoritmo `none` → 401

### 1.2 Autorização (RBAC)
- [ ] Permission key definida em `permissions.py`
- [ ] `has_permission(membership, perm_key)` chamado antes de qualquer operação
- [ ] SELLER não acessa operações de ADMIN/MANAGER
- [ ] SELLER não acessa dados de outros sellers (salvo feature `ver_todos_vendedores`)
- [ ] Cross-tenant: token de tenant A não acessa dados de tenant B

### 1.3 Isolamento de Tenant
- [ ] Toda query inclui `tenant_id` explicitamente
- [ ] IDs de entidades validados contra `tenant_id` (IDOR prevention)
- [ ] Resposta nunca inclui `tenant_id` de outro tenant
- [ ] Sem vazamento de slug, name, ou metadados de outros tenants

### 1.4 Validação de Input
- [ ] Pydantic schema valida todos os campos de entrada
- [ ] Campos `tenant_id` não aceitos via body/query (extraídos do JWT)
- [ ] `page_size` clampado a máximo 200
- [ ] `sort` aceita apenas campos permitidos (whitelist)
- [ ] `filter` não aceita operadores MongoDB (`$where`, `$gt`, etc.)
- [ ] Tamanho máximo de strings validado (ex: `notes` ≤ 2000 chars)

### 1.5 Rate Limiting
- [ ] Endpoint de login: `AUTH_LOGIN` group (50 req/15min por IP+email+tenant)
- [ ] Endpoints críticos: rate limit adequado configurado
- [ ] 429 retorna `Retry-After` header
- [ ] Rate limit usa Redis (não in-memory em produção)

### 1.6 Idempotência
- [ ] Operações financeiras/críticas suportam `Idempotency-Key`
- [ ] Chave duplicada + mesmo payload → resultado cached (200)
- [ ] Chave duplicada + payload diferente → 409 CONFLICT
- [ ] TTL da chave de idempotência: 24h

### 1.7 Erros e Logs
- [ ] Erros 4xx não vaza stack trace Python
- [ ] Erros 4xx não vaza paths de arquivo do servidor
- [ ] Erros de domain retornam estrutura padronizada `{error, message, request_id}`
- [ ] `request_id` presente em todos os logs estruturados
- [ ] `tenant_id` presente em todos os logs de erro

---

## 2. Vetores de Ataque e Mitigações Implementadas

### 2.1 IDOR (Insecure Direct Object Reference)
**Risco:** Atacante usa ID de entidade de outro tenant para acessar dados.  
**Mitigação:** `BaseRepository.find_by_id_for_tenant(tenant_id, entity_id)` — query sempre inclui tenant_id. Nunca usar `find_by_id(id)` sem tenant_id para entidades scoped.

### 2.2 Cross-Tenant Information Disclosure
**Risco:** Token de tenant A retorna dados de tenant B.  
**Mitigação:** Middleware valida `jwt.tenant_slug == path_tenant_slug`. Toda query tem `tenant_id` no filtro.

### 2.3 Broken Authentication
**Risco:** JWT expirado, forjado ou com algoritmo `none` aceito.  
**Mitigação:** `python-jose` verifica assinatura, expiração e algoritmo. Algoritmo configurado explicitamente como `HS256`.

### 2.4 NoSQL Injection
**Risco:** Parâmetros de query com operadores MongoDB (`$where`, `$gt`).  
**Mitigação:** Pydantic valida tipos. Queries construídas programaticamente (não string interpolation). Campos de filtro usam whitelist.

### 2.5 Credential Brute Force
**Risco:** Atacante tenta senhas em volume.  
**Mitigação:** Rate limiter Redis: 50 req/15min por IP+email+tenant. 429 com `Retry-After`. Senhas com bcrypt.

### 2.6 Mass Assignment
**Risco:** Body aceita campos não esperados que sobrescrevem campos críticos.  
**Mitigação:** Pydantic schemas explícitos. `tenant_id` e `id` nunca aceitos via body.

### 2.7 Sensitive Data Exposure
**Risco:** `password_hash`, `token_version`, dados PII expostos em respostas.  
**Mitigação:** Projections excluem campos sensíveis. Testes verificam ausência de `password_hash`.

---

## 3. Itens de Segurança por Camada

### 3.1 Backend
- ✅ CORS: lista explícita em produção (não `*`)
- ✅ HSTS configurado
- ✅ JWT HS256 com secret ≥ 32 chars
- ✅ Senhas: bcrypt com salt automático
- ✅ `SEED_DEMO_DATA` bloqueado em `ENVIRONMENT=production`
- ✅ Env vars validadas no boot (`_validate_required_env()`)
- ✅ Rate limiter Redis em todos os endpoints de auth
- ✅ Handler global de exceção (sem stack trace em produção)

### 3.2 Frontend
- ✅ Token armazenado em localStorage (com consideração de XSS)
- ✅ `tenant_slug` validado no frontend antes de requisições
- ✅ Rotas protegidas por `PrivateRoute`
- ⚠️ CSP headers não configurados (backlog P3)
- ⚠️ SameSite cookie não aplicável (JWT em header) — documentado

### 3.3 Infraestrutura
- ✅ MongoDB sem autenticação apenas em desenvolvimento local
- ✅ Redis sem senha em desenvolvimento (configurar em produção)
- ✅ Secrets via env vars (nunca em código)
- ⚠️ TLS entre serviços internos: via Kubernetes (a verificar por ambiente)

---

## 4. Vulnerabilidades Conhecidas e Aceitas (Risk Register)

| Vulnerabilidade | Risco | Mitigação Atual | Ação Pendente |
|---|---|---|---|
| MongoDB sem auth em dev | BAIXO (ambiente fechado) | Só em dev | Autenticação em staging/prod |
| JWT em localStorage (XSS) | MÉDIO | Sem eval, sem innerHTML | CSP headers em P3 |
| Rate limit por IP (não por usuário) | MÉDIO | 50 req/15min suficiente | Rate limit por usuário em P4 |
| Sem 2FA | MÉDIO | Senha forte + bcrypt | 2FA em backlog |
| Redis sem TLS interno | BAIXO | Rede interna K8s | TLS em P3 se necessário |

---

## 5. Testes de Segurança Obrigatórios

Todos estes testes existem e passam em `/app/backend/tests/test_p2_5_security.py`:

- [x] IDOR: token de tenant A não acessa store/attendance/sale/goal/ranking de tenant B
- [x] Cross-tenant isolation: 10+ endpoints verificados
- [x] Role access: SELLER não cria loja, não modifica features, não acessa métricas
- [x] Filter injection: `$where`, `$gt`, `__class__` não causam 500
- [x] Paginação: `page_size=9999` clampado
- [x] NoSQL injection em email: não retorna dados indevidos
- [x] Endpoints protegidos sem token: 401/403
- [x] JWT inválido/forjado: 401
- [x] JWT algoritmo `none`: 401
- [x] Stack trace não vaza em erros 4xx

---

## 6. Procedimento de Resposta a Incidente de Segurança

1. **Detecção**: Alerta via Prometheus (error_rate > 5%) ou log estruturado
2. **Contenção**: Rate limit imediato via Redis (`redis-cli set rl:EMERGENCY_BLOCK:{ip} 1 ex 3600`)
3. **Análise**: Buscar `request_id` nos logs para rastrear a requisição
4. **Correção**: Hotfix via CI/CD com gate de segurança obrigatório
5. **Post-mortem**: Adicionar ao `/docs/security-incidents.md`
