# Data Privacy Guidelines — Lista da Vez SaaS (LGPD)

**Versão:** 1.0.0-p2  
**Responsável:** DPO / Tech Lead  
**Base Legal:** Lei Geral de Proteção de Dados (LGPD - Lei 13.709/2018)  
**Última atualização:** 2026-06

---

## 1. Dados Pessoais no Sistema

### 1.1 Dados Coletados e Finalidade

| Dado | Tabela | Titular | Finalidade | Base Legal |
|---|---|---|---|---|
| Nome completo | `users`, `seller_profiles` | Vendedor/Admin | Identificação na plataforma | Execução de contrato |
| E-mail | `users` | Vendedor/Admin | Autenticação e comunicação | Execução de contrato |
| Telefone | `users`, `tenants` | Vendedor/Empresa | Contato e notificações | Execução de contrato |
| Nome do cliente (atendimento) | `attendances` | Cliente da loja | Personalização do atendimento | Legítimo interesse / Consentimento |
| Telefone do cliente | `attendances` | Cliente da loja | Follow-up de venda | Consentimento |
| Dados de performance | `sales`, `attendances`, `goals` | Vendedor | Gestão de equipes | Execução de contrato |
| IP de acesso | `rate_limit` (Redis), logs | Usuário | Segurança/Rate limit | Legítimo interesse |

### 1.2 Dados Sensíveis (Atenção Extra)
- Dados de clientes finais da loja (`attendances.customer_name`, `customer_phone`) — titular não é usuário do sistema
- Performance individual de vendedores — pode ser usado em gestão trabalhista

---

## 2. Princípios LGPD Aplicados

### 2.1 Minimização
- Coletamos apenas dados necessários para a funcionalidade
- `attendances.customer_name` e `customer_phone` são **opcionais**
- Não coletamos CPF, data de nascimento, ou outros dados desnecessários do cliente final

### 2.2 Finalidade
- Dados usados apenas para as finalidades declaradas
- Performance de vendedores não compartilhada com terceiros
- Dados de clientes não cruzados entre tenants

### 2.3 Retenção
- Dados de atendimento: retidos pelo prazo configurado no plano
- Dados de usuários: retidos durante vigência do contrato + 5 anos (obrigação legal)
- Logs de sistema: 90 dias (segurança) / 2 anos (auditoria)
- Backups: 90 dias de retenção

### 2.4 Isolamento
- Dados de cada empresa (tenant) completamente isolados (`tenant_id`)
- Funcionários de empresa A nunca veem dados de empresa B

---

## 3. Direitos do Titular (LGPD)

Implementados em `/api/tenants/{slug}/lgpd/`:

| Direito | Endpoint | Status |
|---|---|---|
| Acesso aos dados | `GET /lgpd/export` | ✅ Implementado |
| Correção | Via interface padrão de edição | ✅ Parcial |
| Exclusão | `DELETE /lgpd/users/{id}/data` | ✅ Implementado (soft delete) |
| Portabilidade | Export CSV disponível | ✅ Implementado |
| Revogação de consentimento | `POST /lgpd/opt-out` | ⚠️ Backlog |
| Confirmação de tratamento | `GET /lgpd/data-summary` | ⚠️ Backlog |

### 3.1 Processo de Exclusão (Right to be Forgotten)

```
1. Usuário solicita via interface
2. Admin do tenant confirma
3. Sistema executa soft delete (status=DELETED, dados anonimizados)
4. Audit log registra exclusão com timestamp
5. Dados anonimizados permanecem para integridade de relatórios históricos:
   - attendances: seller_id → "ANONYMIZED", customer_name → null
   - sales: seller_id → "ANONYMIZED"
6. Backup job marca registros para exclusão no próximo ciclo
```

---

## 4. Dados de Terceiros (Clientes Finais das Lojas)

**Situação especial:** O sistema coleta opcionalmente nome e telefone de clientes finais das lojas (titulares que não são usuários do sistema).

**Responsabilidades:**
- **Tenant (empresa cliente):** Controlador dos dados dos seus clientes finais
- **Lista da Vez:** Operador (processa dados conforme instrução do tenant)
- **Contrato DPA:** Deve ser assinado com cada tenant para formalizar relação Controlador-Operador

**Recomendação para tenants:**
- Obter consentimento do cliente final antes de registrar nome/telefone
- Feature `customer_data_collection` pode ser desabilitada se tenant não quiser coletar

---

## 5. Segurança de Dados

### 5.1 Dados em Repouso
- MongoDB: sem criptografia nativa em dev (TDE recomendado em produção)
- Backups: criptografados com chave AES-256 gerenciada pelo tenant

### 5.2 Dados em Trânsito
- HTTPS obrigatório em produção (TLS 1.2+)
- WebSocket via WSS (TLS)
- Comunicação interna: via rede privada Kubernetes

### 5.3 Acesso Administrativo
- Super admin acessa todos os tenants — registro em `audit_logs`
- Acesso de suporte a dados de tenant: requer autorização do tenant
- Logs de acesso retidos por 2 anos

---

## 6. Feature Flag LGPD

```python
FEATURE_LGPD = "lgpd"  # Controla funcionalidades de privacidade
```

Quando desabilitada: rotas `/lgpd/...` retornam 403  
Quando habilitada: funcionalidades de privacidade disponíveis para o tenant

---

## 7. Incidente de Dados (Data Breach)

**Procedimento (72h para notificar ANPD):**

1. **Detecção** (H+0): Identificar dados afetados e extensão
2. **Contenção** (H+2): Revogar acessos comprometidos, fechar vulnerabilidade
3. **Análise** (H+12): Mapear titulares afetados e dados expostos
4. **Notificação** (H+48): Notificar ANPD e titulares afetados
5. **Remediação** (H+72): Correção definitiva e relatório

**Contato ANPD:** https://www.gov.br/anpd/pt-br  
**Notificação interna:** DPO + CEO + CTO

---

## 8. Checklist para Novos Campos com Dados Pessoais

- [ ] Campo é realmente necessário? (Minimização)
- [ ] Finalidade documentada neste guia
- [ ] Base legal identificada (contrato/consentimento/legítimo interesse)
- [ ] Titular pode solicitar exclusão?
- [ ] Incluído no export LGPD (`/lgpd/export`)?
- [ ] Campo sensível (CPF, saúde, origem racial)? → Requer DPO approval
- [ ] Dado de cliente final (não usuário do sistema)? → Requer DPA com tenant
