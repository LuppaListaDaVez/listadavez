# Runbook Operacional — Lista da Vez SaaS

> Guia completo para operar o sistema em produção e staging.

---

## Índice
1. [Como Subir o Sistema](#1-como-subir-o-sistema)
2. [Validar Health](#2-validar-health)
3. [Verificar Logs](#3-verificar-logs)
4. [Verificar Banco de Dados](#4-verificar-banco-de-dados)
5. [Verificar Redis](#5-verificar-redis)
6. [Verificar Workers](#6-verificar-workers)
7. [Verificar WebSocket](#7-verificar-websocket)
8. [Executar Backup](#8-executar-backup)
9. [Testar Restore](#9-testar-restore)
10. [Fazer Rollback](#10-fazer-rollback)
11. [Investigar Erro 500](#11-investigar-erro-500)
12. [Investigar Tenant Leakage](#12-investigar-tenant-leakage)
13. [Investigar Job Travado](#13-investigar-job-travado)
14. [Investigar Exportação Falha](#14-investigar-exportação-falha)
15. [Investigar WebSocket Indisponível](#15-investigar-websocket-indisponível)

---

## 1. Como Subir o Sistema

### Staging
```bash
# Pré-requisito: preencher .env.staging com valores corretos
cp backend/.env.example .env.staging
# editar .env.staging com valores reais

# Subir stack completa
docker compose -f docker-compose.staging.yml --env-file .env.staging up -d

# Acompanhar logs de startup
docker compose -f docker-compose.staging.yml logs -f backend | head -50
```

### Desenvolvimento local
```bash
# Opção 1: Docker Compose (tudo em container)
docker compose -f docker-compose.dev.yml up

# Opção 2: Processos locais (hot reload manual)
# Terminal 1: Backend
cd backend && uvicorn server:app --host 0.0.0.0 --port 8001 --reload

# Terminal 2: Frontend
cd frontend && yarn start
```

### Verificar se subiu corretamente
```bash
# Backend
curl $BACKEND_URL/api/health/ready

# Frontend
curl -o /dev/null -w "%{http_code}" $FRONTEND_URL

# Espera: backend retorna {"status":"ok","db":"connected"}, frontend retorna 200
```

---

## 2. Validar Health

```bash
# Health básico (status do processo)
curl $BACKEND_URL/api/health
# Esperado: {"status":"ok","service":"lista-da-vez-api","version":"1.0.0-p1.5"}

# Liveness (processo vivo?)
curl $BACKEND_URL/api/health/live
# Esperado: {"status":"ok"}

# Readiness (banco + Redis + dispatcher OK?)
curl -s $BACKEND_URL/api/health/ready | python3 -m json.tool
# Esperado: {"status":"ok","db":"connected","redis":"connected" ou "not_configured"}

# Health completo do banco
curl $BACKEND_URL/api/health/db

# Observabilidade (requer Super Admin token)
curl -H "Authorization: Bearer $SUPER_ADMIN_TOKEN" \
     $BACKEND_URL/api/admin/observability | python3 -m json.tool
```

---

## 3. Verificar Logs

```bash
# Logs do backend em tempo real
tail -f /var/log/supervisor/backend.out.log

# Apenas erros
tail -f /var/log/supervisor/backend.err.log

# Últimos 100 logs
tail -n 100 /var/log/supervisor/backend.out.log

# Logs por worker
grep "OUTBOX_" /var/log/supervisor/backend.out.log | tail -10
grep "EXPORT_" /var/log/supervisor/backend.out.log | tail -10
grep "SECURITY_" /var/log/supervisor/backend.out.log | tail -10

# Docker Compose (staging)
docker compose -f docker-compose.staging.yml logs backend --tail 50
docker compose -f docker-compose.staging.yml logs --tail 20
```

---

## 4. Verificar Banco de Dados

```bash
# Conectar ao MongoDB
mongosh "$MONGO_URL"

# Status do banco
> db.stats()

# Verificar coleções principais
> db.tenants.countDocuments()
> db.users.countDocuments()
> db.attendances.countDocuments()
> db.export_jobs.countDocuments()

# Verificar índices (existência)
> db.attendances.getIndexes()
> db.users.getIndexes()

# Verificar jobs pendentes
> db.export_jobs.countDocuments({status: "QUEUED"})
> db.event_outbox.countDocuments({status: "PENDING"})

# Verificar latência de query
> db.attendances.find({tenant_id: "TENANT_ID"}).limit(10).explain("executionStats")
```

---

## 5. Verificar Redis

```bash
# Conectar ao Redis
redis-cli -u $REDIS_URL

# Ping
> PING
# Esperado: PONG

# Informações gerais
> INFO server
> INFO memory

# Verificar canais Pub/Sub ativos
> PUBSUB CHANNELS "*"

# Monitorar em tempo real (CUIDADO: verboso em produção)
> MONITOR
```

---

## 6. Verificar Workers

```bash
# Ver se outbox dispatcher está vivo (deve logar a cada ~2s em atividade)
grep "OUTBOX_DISPATCHER_STARTED\|OUTBOX_DISPATCHED\|OUTBOX_" \
     /var/log/supervisor/backend.out.log | tail -5

# Ver se export dispatcher está vivo
grep "EXPORT_DISPATCHER_STARTED\|EXPORT_JOB_" \
     /var/log/supervisor/backend.out.log | tail -5

# Jobs em QUEUED (fila de exports)
curl -s $BACKEND_URL/api/health/ready | python3 -c \
     "import sys,json; d=json.load(sys.stdin); print('Export jobs queued:', d.get('export_jobs_queued',0))"

# Jobs PROCESSING há mais de 10 min (possível travamento)
# MongoDB:
# db.export_jobs.find({
#   status: "PROCESSING",
#   started_at: { $lt: new Date(Date.now() - 600000).toISOString() }
# }).toArray()
```

---

## 7. Verificar WebSocket

```bash
# Status via observabilidade
curl -s -H "Authorization: Bearer $SUPER_ADMIN_TOKEN" \
     $BACKEND_URL/api/admin/observability | \
     python3 -c "import sys,json; d=json.load(sys.stdin)['websocket']; \
     print(f'Mode: {d[\"mode\"]} | Connections: {d[\"active_connections\"]} | Published: {d[\"events_published\"]} | Failed: {d[\"events_failed\"]}')"

# Testar WebSocket manualmente (wscat ou websocat)
# npm install -g wscat
TOKEN=$(curl -s -X POST $BACKEND_URL/api/tenants/SLUG/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"...","password":"..."}' | python3 -c "import sys,json; print(json.load(sys.stdin)['access_token'])")

wscat -c "$BACKEND_URL/api/ws/STORE_ID?token=$TOKEN"
# Esperado: conecta sem erro 401/403
```

---

## 8. Executar Backup

Ver [backup-restore-runbook.md](backup-restore-runbook.md) — Seção 1.

```bash
# Backup rápido sem criptografia (dev/staging)
mongodump --uri="$MONGO_URL" --db="$DB_NAME" --gzip \
  --archive="/tmp/backup_$(date +%Y%m%dT%H%M%S)Z.gz"
```

---

## 9. Testar Restore

Ver [backup-restore-runbook.md](backup-restore-runbook.md) — Seção 4.

```bash
# Restore em staging (apaga dados staging)
mongorestore --uri="$STAGING_MONGO_URL" --archive="/tmp/backup_XXXX.gz" --gzip --drop
```

---

## 10. Fazer Rollback

Ver [rollback-runbook.md](rollback-runbook.md) para procedimento completo.

```bash
# Rollback rápido do backend (Docker)
docker stop lista-da-vez-backend
docker tag lista-da-vez-backend:COMMIT_ANTERIOR lista-da-vez-backend:latest
docker compose -f docker-compose.staging.yml up -d backend
curl -f $BACKEND_URL/api/health/ready
```

---

## 11. Investigar Erro 500

```bash
# 1. Pegar request_id do header X-Request-Id (reportado pelo usuário ou nos logs do cliente)
# 2. Buscar no log
grep "REQUEST_ID" /var/log/supervisor/backend.err.log

# 3. Ver stack trace
grep -A 30 "UNHANDLED_EXCEPTION.*REQUEST_ID" /var/log/supervisor/backend.err.log

# 4. Verificar health geral
curl -s $BACKEND_URL/api/health/ready
```

---

## 12. Investigar Tenant Leakage

```bash
# Buscar indício nos logs
grep -i "tenant_mismatch\|cross_tenant\|idor" /var/log/supervisor/backend.out.log | tail -20

# Se confirmado: INCIDENTE CRÍTICO — notificar equipe imediatamente
# Isolar tenants afetados até identificar e corrigir o bug
# Acionar rollback se necessário
```

---

## 13. Investigar Job Travado

```bash
# Jobs em QUEUED por muito tempo
# MongoDB:
# db.export_jobs.find({status: "QUEUED", created_at: { $lt: new Date(Date.now() - 300000).toISOString() }})

# Ver logs do dispatcher
grep "EXPORT_DISPATCHER_ERROR\|EXPORT_JOB_FAILED" /var/log/supervisor/backend.err.log | tail -10

# Se dispatcher não está logando, pode ter crashado
grep "EXPORT_DISPATCHER_STARTED" /var/log/supervisor/backend.out.log | tail -3
# Se última entrada é antiga, reiniciar backend
sudo supervisorctl restart backend
```

---

## 14. Investigar Exportação Falha

```bash
# 1. Usuário reportou que o CSV não ficou pronto
# Pegar o job_id da URL

# 2. Verificar status via API
curl -H "Authorization: Bearer $TOKEN" \
     $BACKEND_URL/api/tenants/SLUG/reports/export/jobs/JOB_ID | python3 -m json.tool

# 3. Se status=FAILED, ver campo error no job

# 4. Logs detalhados
grep "JOB_ID_PREFIX" /var/log/supervisor/backend.err.log

# 5. Requeue manualmente se quiser reprocessar
# MongoDB:
# db.export_jobs.updateOne({id: "JOB_ID"}, {$set: {status: "QUEUED", error: null, started_at: null}})
```

---

## 15. Investigar WebSocket Indisponível

```bash
# 1. Verificar modo atual
curl -s -H "Authorization: Bearer $SUPER_ADMIN_TOKEN" $BACKEND_URL/api/admin/observability | \
  python3 -c "import sys,json; d=json.load(sys.stdin); print(d['websocket']['mode'], d['websocket']['events_failed'])"

# 2. Se modo redis: verificar Redis
redis-cli -u $REDIS_URL ping

# 3. Se Redis indisponível: mudar para in_memory temporariamente
# Editar variável REALTIME_MODE=in_memory e reiniciar
sudo supervisorctl restart backend

# 4. Verificar logs de conexão WebSocket
grep "websocket\|WS_\|REALTIME" /var/log/supervisor/backend.err.log | tail -20
```

---

## Contatos e Escalação

```
Nível 1 (SLA 30min): Engenheiro de plantão
Nível 2 (SLA 2h):    Tech Lead
Nível 3 (SLA 4h):    CTO / Arquiteto

Incidentes críticos (tenant leakage, dados perdidos):
  → Escalação imediata para Nível 3
  → Notificar clientes afetados
```

---

## Procedimentos P3 — Adicionados na Auditoria Final

### Verificação de Índices MongoDB

```bash
# Verificar todos os 35 índices críticos
cd /app && python scripts/verify_indexes.py

# Criar índices ausentes (após novo deploy ou restauração de BD)
cd /app && python scripts/verify_indexes.py --create-missing
```

**Saída esperada**: `✅ Índices presentes : 35 / ❌ Índices ausentes  : 0`

### Validação de Headers de Segurança

```bash
# Verificar headers de segurança em produção
curl -I https://api.seudominio.com/api/health | grep -E "CSP|X-Frame|HSTS|X-Content"
```

**Headers esperados**:
- `Content-Security-Policy: default-src 'self'; ...`
- `X-Frame-Options: DENY`
- `Strict-Transport-Security: max-age=31536000`
- `X-Content-Type-Options: nosniff`

### Diagnóstico do ErrorBoundary (Frontend)

Se um usuário reportar "Algo deu errado" na tela:
1. Verificar logs do browser (console) para identificar o componente com erro
2. Reproduzir com `NODE_ENV=development` para ver o stack trace completo
3. O ErrorBoundary **não** mascara erros de rede — erros de rede aparecem no toast
4. Erros de renderização de componente React são capturados pelo ErrorBoundary

### Checklist Pós-Deploy

```bash
# 1. Verificar saúde
curl https://api.seudominio.com/api/health/ready

# 2. Verificar índices
python scripts/verify_indexes.py

# 3. Smoke test de autenticação
curl -X POST https://api.seudominio.com/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"tenant_slug":"demo","email":"admin@demo.com","password":"Admin@123456"}'

# 4. Verificar métricas Prometheus
curl https://api.seudominio.com/api/metrics/prometheus | head -20
```
