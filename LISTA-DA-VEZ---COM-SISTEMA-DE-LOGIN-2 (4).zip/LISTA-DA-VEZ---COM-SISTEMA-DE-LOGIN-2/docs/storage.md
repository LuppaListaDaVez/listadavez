# Storage — Lista da Vez SaaS

> Guia de configuração e operação do storage para exports de relatórios e backups.

---

## Visão Geral

O sistema usa dois tipos de storage:

| Tipo | Onde | Provider Dev | Provider Produção |
|---|---|---|---|
| **Export Jobs** | CSVs gerados de relatórios | `local` (`/tmp/exports/`) | `local` ou `s3_compatible` |
| **Backups** | Snapshots do MongoDB | Local (`/tmp/backups/`) | S3-compatible |

---

## 1. Export Jobs — CSVs de Relatórios

### Funcionamento
1. Usuário solicita export: `POST /api/tenants/{slug}/reports/export/async`
2. Job `QUEUED` é criado na coleção `export_jobs`
3. Background worker gera CSV em `/tmp/exports/{job_id}_{filename}.csv`
4. Job fica `DONE` — usuário baixa via `GET .../jobs/{id}/download`
5. Arquivo expira após **24 horas** (TTL automático no MongoDB + cleanup de arquivo)

### Diretório de exports
```
/tmp/exports/
├── ecde90cb-..._atendimentos_20260629_1944.csv
├── abcd1234-..._conversao_20260630_0800.csv
└── ...
```

### Limites
- **Máximo de linhas:** 50.000 por export
- **TTL:** 24 horas
- **Formato:** CSV UTF-8

### Configuração local (desenvolvimento)
```bash
# Criado automaticamente pelo export_job_service.py
mkdir -p /tmp/exports
```

### Configuração S3 (produção recomendada)
> **Status atual:** Storage S3 ainda não está integrado no código de produção.
> Os exports em produção usam `/tmp/exports/` (ephemeral se container for reiniciado).
>
> **Plano de migração P2:** Adicionar adapter S3 para `export_job_service.py`.

```bash
# Variáveis de ambiente necessárias (P2)
STORAGE_PROVIDER=s3_compatible
S3_BUCKET=lista-da-vez-exports
S3_REGION=us-east-1
S3_ACCESS_KEY=AKIAIOSFODNN7EXAMPLE
S3_SECRET_KEY=CHANGE_ME
S3_ENDPOINT_URL=https://s3.amazonaws.com
```

### Risco em produção (estado atual)
Em containers efêmeros, `/tmp/exports/` é **perdido** no restart:
- Jobs `DONE` com arquivo deletado retornam HTTP 410 (Gone) no download — comportamento correto.
- Jobs `QUEUED`/`PROCESSING` são reprocessados na próxima inicialização.
- **Mitigação imediata:** Usar volume persistente montado em `/tmp/exports`.

```yaml
# docker-compose.staging.yml (já configurado)
volumes:
  - export_staging_tmp:/tmp/exports
```

---

## 2. Backups do MongoDB

### Funcionamento atual
O sistema tem módulo de backup (`routes_backup.py` — Etapa 14).
Os backups são armazenados localmente por padrão.

### Diretório de backups
```
/tmp/backups/
├── backup_2026-06-29T18:00:00Z.gz
├── backup_2026-06-30T18:00:00Z.gz
└── ...
```

### Backup manual (mongodump)
```bash
# Backup completo
mongodump \
  --uri="$MONGO_URL" \
  --db="$DB_NAME" \
  --gzip \
  --out="/tmp/backups/backup_$(date +%Y%m%dT%H%M%S)Z"

# Backup com criptografia (OpenSSL)
mongodump --uri="$MONGO_URL" --db="$DB_NAME" --archive | \
  openssl enc -aes-256-cbc -salt -pbkdf2 \
  -pass "pass:$BACKUP_ENCRYPTION_KEY" \
  -out "/tmp/backups/backup_$(date +%Y%m%dT%H%M%S)Z.enc"
```

### Configuração S3 (recomendado em produção)
```bash
# Copiar backup para S3
aws s3 cp /tmp/backups/backup_$(date +%Y%m%d)* \
  s3://$BACKUP_S3_BUCKET/mongodb/ \
  --storage-class STANDARD_IA

# Listar backups no S3
aws s3 ls s3://$BACKUP_S3_BUCKET/mongodb/ --recursive | sort
```

---

## 3. Segurança de Storage

### Regras obrigatórias

- **Arquivos privados:** Exports e backups devem ser privados (sem URL pública)
- **Download autenticado:** Exports só acessíveis via endpoint autenticado
- **Bucket de backup não público:** Configurar bloqueio de acesso público no S3
- **Criptografia em trânsito:** TLS/HTTPS para uploads e downloads S3
- **Criptografia em repouso:** Usar SSE-S3 ou SSE-KMS no bucket S3

### Configurar bloqueio de acesso público no S3
```bash
aws s3api put-public-access-block \
  --bucket $BACKUP_S3_BUCKET \
  --public-access-block-configuration \
  "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true"
```

---

## 4. Limpeza e Retenção

### Export Jobs (automática)
- TTL: 24 horas (índice MongoDB `expireAfterSeconds=0` no campo `expires_at`)
- Cleanup do arquivo: feito pelo `cleanup_expired_jobs()` em `export_job_service.py`
- Intervalo de cleanup: ~1 hora

### Backups (manual por enquanto)
```bash
# Remover backups mais antigos que 30 dias (produção)
find /tmp/backups/ -name "backup_*.gz" -mtime +30 -delete

# Com S3 (configurar lifecycle policy no bucket)
aws s3api put-bucket-lifecycle-configuration \
  --bucket $BACKUP_S3_BUCKET \
  --lifecycle-configuration file://backup-lifecycle.json
```

**`backup-lifecycle.json`:**
```json
{
  "Rules": [{
    "ID": "expire-old-backups",
    "Status": "Enabled",
    "Filter": { "Prefix": "mongodb/" },
    "Expiration": { "Days": 30 }
  }]
}
```

---

## 5. Verificação de Storage

```bash
# Verificar exports pendentes
ls -lah /tmp/exports/ | head -20
du -sh /tmp/exports/

# Verificar uso de disco
df -h /tmp

# Jobs com arquivo ausente (pode acontecer após restart sem volume)
# MongoDB:
db.export_jobs.find({
  status: "DONE",
  file_path: { $ne: null }
}).forEach(j => {
  const fs = require('fs');
  if (!fs.existsSync(j.file_path)) {
    print("Arquivo ausente: " + j.id + " " + j.file_path);
  }
});
```
