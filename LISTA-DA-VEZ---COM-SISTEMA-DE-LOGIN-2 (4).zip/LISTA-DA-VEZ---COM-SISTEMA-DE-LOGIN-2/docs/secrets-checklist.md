# Checklist de Secrets — Lista da Vez SaaS

> Execute este checklist antes de qualquer deploy em staging ou produção.
> Marque cada item como concluído.

---

## PRÉ-DEPLOY: Checklist Obrigatório

### 1. Repositório

- [ ] O arquivo `backend/.env` **não está** versionado no git
- [ ] O arquivo `frontend/.env` **não está** versionado no git
- [ ] Executar: `git ls-files | grep "\.env$"` → deve retornar vazio
- [ ] `.gitignore` inclui `.env` e `*.env` (não `.env.example`)
- [ ] `.dockerignore` inclui `.env*` (exceto `.env.example`)
- [ ] Nenhum secret hardcoded em código Python ou JavaScript
- [ ] Nenhum `print()` ou `logger.info()` com valor de secret

### 2. Variáveis de Ambiente

- [ ] `JWT_SECRET` tem pelo menos 32 caracteres (`openssl rand -hex 32`)
- [ ] `JWT_SECRET` não é o valor `CHANGE_ME` ou similar
- [ ] `SUPER_ADMIN_PASSWORD` não é `Admin@123456` ou similar
- [ ] `MONGO_URL` usa autenticação (usuário + senha)
- [ ] `CORS_ORIGINS` é uma lista explícita (não `*`)
- [ ] `ENVIRONMENT` está definido como `production`
- [ ] `SEED_DEMO_DATA` está definido como `false`
- [ ] `LOG_LEVEL` está definido como `INFO` ou `WARNING`
- [ ] Nenhuma variável usando valor default inseguro

### 3. Docker

- [ ] `docker inspect <imagem>` — `.env` não aparece como layer
- [ ] Variáveis sensíveis são injetadas via `--env-file` ou secrets do orquestrador
- [ ] A imagem não executa como `root` (`USER appuser` no Dockerfile)
- [ ] Build da imagem não inclui `tests/`, `scripts/`, `docs/`, `memory/`
- [ ] `COPY backend/` não inclui `.env` (verificar com `.dockerignore`)

### 4. Infraestrutura

- [ ] MongoDB está com autenticação ativada
- [ ] Redis está com senha (`requirepass`)
- [ ] Banco de dados não está exposto publicamente (apenas rede interna)
- [ ] Redis não está exposto publicamente
- [ ] HTTPS ativo no frontend e backend
- [ ] Certificado SSL válido (não autoassinado em produção)
- [ ] HSTS habilitado no nginx/proxy

### 5. Credenciais Demo

- [ ] Super Admin demo (`superadmin@sistema.com` / `Admin@123456`) **não existe** em produção
  - Ou a senha foi trocada para algo forte e único
- [ ] Tenant demo (`demo`) foi desativado ou removido em produção
  - Ou as credenciais foram trocadas
- [ ] `TENANT_ADMIN_EMAIL`/`TENANT_ADMIN_PASSWORD` não são valores de dev

### 6. CI/CD (GitHub Actions)

- [ ] Secrets do GitHub Actions (`JWT_SECRET`, `MONGO_URL`) configurados como "Repository secrets"
- [ ] Pipeline nunca imprime valores de variáveis de ambiente nos logs
- [ ] Secrets não aparecem em artifacts ou cache do CI
- [ ] Deploy só executa se todos os testes passarem

### 7. Backup

- [ ] `BACKUP_ENCRYPTION_KEY` está configurado
- [ ] Backup não é armazenado no mesmo servidor que os dados
- [ ] Acesso ao bucket de backup é restrito (IAM/política)
- [ ] Backup mais recente foi testado (restore em staging)

### 8. Monitoramento

- [ ] Alertas de erro 5xx configurados
- [ ] Alerta de health check configurado (`/api/health/ready`)
- [ ] Logs estruturados fluindo para sistema de observabilidade
- [ ] Nenhum token/senha aparece nos logs

---

## Comandos Úteis

```bash
# Verificar se .env está no git
git ls-files | grep "\.env$"

# Gerar secrets seguros
openssl rand -hex 32     # JWT_SECRET, BACKUP_ENCRYPTION_KEY
openssl rand -base64 24  # Senhas de usuário

# Verificar variáveis na imagem Docker (não devem aparecer secrets)
docker inspect lista-da-vez-backend:latest | grep -i env

# Verificar usuário da imagem Docker
docker run --rm lista-da-vez-backend:latest whoami

# Verificar que .env não foi copiado para imagem
docker run --rm lista-da-vez-backend:latest ls -la /app/.env 2>&1 || echo "OK: .env não está na imagem"
```

---

## Rotação de Secrets

Ao rotacionar um secret em produção:

1. Gere o novo valor
2. Configure no gerenciador de secrets (Vault, AWS SM, GitHub Secrets)
3. Faça rolling restart do backend (para evitar downtime)
4. Verifique que o sistema continua operacional via `/api/health/ready`
5. Revogue o valor antigo
6. Documente a rotação no log de mudanças

**Para `JWT_SECRET`:** Ao rotacionar, todos os tokens existentes serão invalidados (usuários precisarão fazer login novamente). Planeje janela de manutenção.
