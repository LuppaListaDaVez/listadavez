# Autoscaling e Deploy Horizontal — Lista da Vez

**Versão:** P2-B  
**Data:** 2026-06-29  

---

## Pré-requisitos para Escala Horizontal

O sistema foi projetado desde P1.5 para ser stateless. Checklist:

| Requisito | Status | Detalhe |
|---|---|---|
| App stateless | ✅ | Sem estado local por instância |
| Sessões sem memória local | ✅ | JWT stateless + token_version no MongoDB |
| WebSocket distribuído | ✅ | Redis Pub/Sub (REALTIME_MODE=redis) |
| Rate limiter distribuído | ✅ | Redis Sorted Sets (P1-WS+Redis) |
| Cache tenant-scoped | ✅ | TTL-based, sem invalidação cross-instância necessária |
| Jobs separados do web | ✅ | Export dispatcher no próprio processo (pode ser separado) |
| Storage externo | ⚠️ | Export files em disco local — migrar para S3/GCS em P3 |
| Health ready/live | ✅ | /api/health/live + /api/health/ready |
| Graceful shutdown | ✅ | WS close_all() + Redis flush (P2-B) |

---

## Arquitetura Alvo para 500 Empresas

```
                                    ┌─────────────────────┐
                        HTTPS       │   Load Balancer      │
   Clientes ──────────────────────► │   (Nginx/ALB/GCP LB) │
                                    └──────────┬──────────┘
                                               │
                    ┌──────────────────────────┼────────────────────────┐
                    │                          │                         │
             ┌──────▼──────┐          ┌────────▼──────┐        ┌────────▼──────┐
             │  API App 1  │          │  API App 2    │        │  API App N    │
             │  (FastAPI)  │          │  (FastAPI)    │        │  (FastAPI)    │
             │  Port 8001  │          │  Port 8001    │        │  Port 8001    │
             └──────┬──────┘          └───────┬───────┘        └───────┬───────┘
                    │                          │                         │
                    └──────────────────────────┼─────────────────────────┘
                                               │
                    ┌──────────────────────────┼─────────────────────────┐
                    │                          │                          │
             ┌──────▼──────┐          ┌────────▼──────┐        ┌─────────▼──────┐
             │   MongoDB   │          │  Redis Cluster │        │  Storage (S3)  │
             │ (Replica Set│          │  (Rate Limit + │        │  (Export files)│
             │  3 nodes)   │          │   WebSocket)   │        │                │
             └─────────────┘          └───────────────┘        └────────────────┘
```

---

## Configuração por Ambiente

### Desenvolvimento Local
```bash
replicas: 1
workers: 1 (uvicorn single process)
redis: local (127.0.0.1:6379)
mongodb: local
storage: local disk (/tmp/exports)
```

### Staging
```bash
replicas: 2
workers: 2 (uvicorn com --workers 2)
redis: Redis 7 (standalone)
mongodb: MongoDB 6 (standalone + replica set 1+2)
storage: local disk (shared volume)
```

### Produção (100-500 empresas)
```bash
replicas: 3-6 (autoscaling por CPU/RPS)
workers: 4 por réplica (uvicorn com --workers 4)
redis: Redis 7 Cluster (3 shards, HA)
mongodb: MongoDB Atlas M20+ (3 nós)
storage: AWS S3 ou Google Cloud Storage
```

---

## Configuração do Uvicorn para Múltiplas Workers

```bash
# NÃO use --reload em produção
uvicorn server:app \
  --host 0.0.0.0 \
  --port 8001 \
  --workers 4 \
  --timeout-keep-alive 75 \
  --timeout-graceful-shutdown 30 \
  --log-level info \
  --access-log
```

**Nota:** O `--workers 4` cria 4 processos, cada um com seu próprio event loop. O Redis garante que rate limits e WebSocket events sejam compartilhados entre todos.

---

## Kubernetes HPA (Horizontal Pod Autoscaler)

```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: listadavez-api-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: listadavez-api
  minReplicas: 2
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
  behavior:
    scaleUp:
      stabilizationWindowSeconds: 60
      policies:
      - type: Pods
        value: 2
        periodSeconds: 60
    scaleDown:
      stabilizationWindowSeconds: 300  # 5 min antes de reduzir
```

---

## Variáveis de Ambiente para Produção

```bash
# Obrigatórias
MONGO_URL=mongodb+srv://user:pass@cluster.mongodb.net/
DB_NAME=listadavez_prod
JWT_SECRET=<256-bit random string>
ENVIRONMENT=production
CORS_ORIGINS=https://app.listadavez.com.br
REDIS_URL=redis://user:pass@redis-cluster:6379/0
REALTIME_MODE=redis
SEED_DEMO_DATA=false

# Storage (P3)
# STORAGE_PROVIDER=s3
# AWS_S3_BUCKET=listadavez-exports
# AWS_REGION=sa-east-1
```

---

## Checklist de Deploy Zero-Downtime

1. ✅ `/api/health/ready` configurado no readiness probe do K8s
2. ✅ `/api/health/live` configurado no liveness probe
3. ✅ Graceful shutdown com `terminationGracePeriodSeconds: 60`
4. ✅ WebSocket connections recebem `server.shutdown` event antes do close
5. ✅ Redis rate limiter não perde estado entre deploys
6. ⚠️ Export jobs em andamento podem ser perdidos no shutdown (P3: migrar para queue persistente)

---

## SLOs Definidos

| Endpoint | P95 Alvo | P99 Alvo | Uptime |
|---|---|---|---|
| API geral | < 500ms | < 2.000ms | 99.5% |
| Dashboard summary | < 1.500ms | < 3.000ms | 99.5% |
| Queue operations | < 500ms | < 1.000ms | 99.9% |
| Login | < 1.000ms | < 2.000ms | 99.9% |
| WebSocket connect | < 2.000ms | < 5.000ms | 99.0% |
| Export job create | < 800ms | < 2.000ms | 99.0% |
| Error rate 5xx | < 0.5% | | |

**Fonte de métricas:** `/api/metrics/prometheus` → Grafana Agent → Grafana Dashboard
