# Plano de Rollback — Migrações P0 e P0.5

**Data:** 2026-06-29  
**Versão:** 1.0.0-p0.5

---

## Princípios de Rollback

1. **Sempre fazer backup antes de qualquer migração**
2. **Scripts de rollback devem ser testados em staging**
3. **Mudanças de índice são reversíveis**
4. **Backfills de campo NÃO são revertidos automaticamente** (campos adicionados, dados não apagados)

---

## Rollback por Componente

### 1. Reverter variáveis de ambiente

```bash
# Restaurar .env original
cp /app/backend/.env.bak /app/backend/.env
sudo supervisorctl restart backend
```

### 2. Remover índice problemático

```bash
cd /app/backend && python3 - << 'EOF'
import asyncio, os
from dotenv import load_dotenv; load_dotenv('.env')
from motor.motor_asyncio import AsyncIOMotorClient

async def drop_index():
    db = AsyncIOMotorClient(os.environ['MONGO_URL'])[os.environ['DB_NAME']]
    # Substituir INDEX_NAME pelo nome do índice problemático
    # Listar índices:
    print(await db.COLLECTION_NAME.index_information())
    # Remover:
    # await db.COLLECTION_NAME.drop_index("INDEX_NAME")

asyncio.run(drop_index())
EOF
```

### 3. Reverter backfill parcial

Os backfills adicionam campos mas NÃO apagam dados existentes. Se um backfill criou campo errado, corrigir via update:

```bash
# Exemplo: resetar source errado em sales
python3 -c "
import asyncio, os
from dotenv import load_dotenv; load_dotenv('/app/backend/.env')
from motor.motor_asyncio import AsyncIOMotorClient

async def fix():
    db = AsyncIOMotorClient(os.environ['MONGO_URL'])[os.environ['DB_NAME']]
    # CUIDADO: isso apaga o campo source de TODOS os sales
    # Use apenas se o backfill foi feito errado
    result = await db.sales.update_many(
        {'source': 'OTHER'},  # filtro preciso
        {'\$unset': {'source': ''}}
    )
    print(f'Modificados: {result.modified_count}')

asyncio.run(fix())
"
```

### 4. Restaurar backup do MongoDB

```bash
# Listar snapshots disponíveis via API
curl -s -X GET "$API/api/tenants/{slug}/backups" \
  -H "Authorization: Bearer $TOKEN" | python3 -m json.tool

# Iniciar restore (exige confirmação)
curl -s -X POST "$API/api/tenants/{slug}/backups/{backup_id}/restore" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"confirmation_text": "CONFIRMO_RESTORE"}'
```

### 5. Reverter mudanças de código

```bash
# Ver commits recentes
git log --oneline -10

# Reverter para commit anterior ao P0
# ATENÇÃO: só fazer via interface Emergent (Rollback feature)
# NÃO usar git reset --hard em produção sem backup
```

### 6. Validar consistência após rollback

```bash
# Verificar se banco está acessível
curl "$API/api/health/ready"

# Verificar login
curl -X POST "$API/api/tenants/demo/auth/login" \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@demo.com","password":"Admin@123456"}'

# Verificar dados básicos
TOKEN=$(...)  # do login acima
curl "$API/api/tenants/demo/stores" -H "Authorization: Bearer $TOKEN"
```

---

## Mudanças Não Reversíveis

| Mudança | Reversibilidade | Ação se necessário |
|---------|----------------|-------------------|
| Índices criados | Reversível (drop_index) | Ver passo 2 acima |
| Campos adicionados via backfill | Não revertidos automaticamente | Ver passo 3 |
| Eventos de auditoria criados | Não revertidos (log imutável) | Aceitar como histórico |
| Versão do servidor (v1.0.0-p0) | Reversível via rollback Emergent | Usar feature de rollback |

---

## Checklist Pré-Rollback

- [ ] Backup realizado e validado
- [ ] Usuários impactados notificados
- [ ] Motivo do rollback documentado
- [ ] Script de rollback testado em staging
- [ ] Plano de re-deploy documentado
- [ ] Monitoramento ativo durante rollback
