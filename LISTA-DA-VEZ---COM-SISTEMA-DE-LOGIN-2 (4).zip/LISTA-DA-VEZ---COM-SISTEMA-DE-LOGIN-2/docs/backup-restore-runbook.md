# Backup e Restore — Runbook

> **Lista da Vez SaaS** — Runbook operacional para backup e restore do MongoDB.

---

## Índice
1. [Backup Manual](#1-backup-manual)
2. [Backup Automático](#2-backup-automático)
3. [Verificar Backup](#3-verificar-backup)
4. [Restore em Staging](#4-restore-em-staging)
5. [Restore em Produção](#5-restore-em-produção)
6. [Restore Parcial](#6-restore-parcial)
7. [Testar Backup Periodicamente](#7-testar-backup-periodicamente)
8. [Registrar Incidente](#8-registrar-incidente)

---

## 1. Backup Manual

### Backup simples (sem criptografia)
```bash
export BACKUP_DIR="/tmp/backups"
export BACKUP_FILE="backup_$(date +%Y%m%dT%H%M%S)Z"

mkdir -p $BACKUP_DIR

mongodump \
  --uri="$MONGO_URL" \
  --db="$DB_NAME" \
  --gzip \
  --archive="$BACKUP_DIR/${BACKUP_FILE}.archive.gz"

echo "Backup criado: $BACKUP_DIR/${BACKUP_FILE}.archive.gz"
ls -lah $BACKUP_DIR/${BACKUP_FILE}*
```

### Backup com criptografia (recomendado para produção)
```bash
export BACKUP_DIR="/tmp/backups"
export BACKUP_FILE="backup_$(date +%Y%m%dT%H%M%S)Z"

mkdir -p $BACKUP_DIR

mongodump \
  --uri="$MONGO_URL" \
  --db="$DB_NAME" \
  --archive \
  --gzip | \
  openssl enc -aes-256-cbc -salt -pbkdf2 -iter 100000 \
    -pass "pass:$BACKUP_ENCRYPTION_KEY" \
    -out "$BACKUP_DIR/${BACKUP_FILE}.enc"

# Gerar checksum
sha256sum "$BACKUP_DIR/${BACKUP_FILE}.enc" > "$BACKUP_DIR/${BACKUP_FILE}.sha256"

echo "Backup criptografado: $BACKUP_DIR/${BACKUP_FILE}.enc"
cat "$BACKUP_DIR/${BACKUP_FILE}.sha256"
```

### Enviar para S3
```bash
# Após criar backup
aws s3 cp "$BACKUP_DIR/${BACKUP_FILE}.enc" \
  "s3://$BACKUP_S3_BUCKET/mongodb/${BACKUP_FILE}.enc"

aws s3 cp "$BACKUP_DIR/${BACKUP_FILE}.sha256" \
  "s3://$BACKUP_S3_BUCKET/mongodb/${BACKUP_FILE}.sha256"

echo "Upload S3 concluído."
```

---

## 2. Backup Automático

### Configuração via cron (em produção com servidor dedicado)
```bash
# Adicionar ao crontab do servidor (crontab -e)
# Backup diário às 3h00
0 3 * * * /usr/local/bin/backup-listadavez.sh >> /var/log/backup-listadavez.log 2>&1
```

**`/usr/local/bin/backup-listadavez.sh`:**
```bash
#!/bin/bash
set -euo pipefail

source /etc/listadavez/backup.env

BACKUP_DIR="/tmp/backups"
BACKUP_FILE="backup_$(date +%Y%m%dT%H%M%S)Z"
RETENTION_DAYS="${BACKUP_RETENTION_DAYS:-30}"

mkdir -p "$BACKUP_DIR"

mongodump --uri="$MONGO_URL" --db="$DB_NAME" --archive --gzip | \
  openssl enc -aes-256-cbc -salt -pbkdf2 -iter 100000 \
    -pass "pass:$BACKUP_ENCRYPTION_KEY" \
    -out "$BACKUP_DIR/${BACKUP_FILE}.enc"

sha256sum "$BACKUP_DIR/${BACKUP_FILE}.enc" > "$BACKUP_DIR/${BACKUP_FILE}.sha256"

aws s3 cp "$BACKUP_DIR/${BACKUP_FILE}.enc" \
  "s3://$BACKUP_S3_BUCKET/mongodb/${BACKUP_FILE}.enc"
aws s3 cp "$BACKUP_DIR/${BACKUP_FILE}.sha256" \
  "s3://$BACKUP_S3_BUCKET/mongodb/${BACKUP_FILE}.sha256"

# Limpar locais antigos
find "$BACKUP_DIR" -name "backup_*.enc" -mtime +1 -delete

# Reterar via S3 Lifecycle Policy (configurar no bucket)
echo "[$(date)] Backup concluído: ${BACKUP_FILE}"
```

---

## 3. Verificar Backup

### Verificar integridade (checksum)
```bash
export BACKUP_FILE="backup_2026-06-29T030000Z"
export BACKUP_DIR="/tmp/backups"

# Baixar do S3 se necessário
aws s3 cp "s3://$BACKUP_S3_BUCKET/mongodb/${BACKUP_FILE}.enc" "$BACKUP_DIR/"
aws s3 cp "s3://$BACKUP_S3_BUCKET/mongodb/${BACKUP_FILE}.sha256" "$BACKUP_DIR/"

# Verificar checksum
sha256sum -c "$BACKUP_DIR/${BACKUP_FILE}.sha256"
echo "Integridade: OK se sem erros acima"
```

### Verificar conteúdo sem restaurar
```bash
# Descriptografar e listar coleções (sem restaurar)
openssl enc -d -aes-256-cbc -pbkdf2 -iter 100000 \
  -pass "pass:$BACKUP_ENCRYPTION_KEY" \
  -in "$BACKUP_DIR/${BACKUP_FILE}.enc" | \
  mongorestore --archive --gzip --dryRun --verbose
```

### Listar backups disponíveis
```bash
# Local
ls -lah /tmp/backups/*.enc | sort -k6,7

# S3
aws s3 ls "s3://$BACKUP_S3_BUCKET/mongodb/" | sort | tail -20
```

---

## 4. Restore em Staging

> ⚠️ Restore em staging não requer aprovação, mas **apaga os dados existentes** do banco staging.

### Passo a passo

```bash
# 1. Baixar backup
export BACKUP_FILE="backup_2026-06-29T030000Z"
aws s3 cp "s3://$BACKUP_S3_BUCKET/mongodb/${BACKUP_FILE}.enc" /tmp/

# 2. Verificar integridade
aws s3 cp "s3://$BACKUP_S3_BUCKET/mongodb/${BACKUP_FILE}.sha256" /tmp/
sha256sum -c "/tmp/${BACKUP_FILE}.sha256"

# 3. Confirmar MONGO_URL aponta para STAGING (não produção!)
echo "STAGING MONGO_URL: $STAGING_MONGO_URL"

# 4. Drop do banco staging (IRREVERSÍVEL para o staging)
mongosh "$STAGING_MONGO_URL" --eval "db.dropDatabase()"

# 5. Restaurar
openssl enc -d -aes-256-cbc -pbkdf2 -iter 100000 \
  -pass "pass:$BACKUP_ENCRYPTION_KEY" \
  -in "/tmp/${BACKUP_FILE}.enc" | \
  mongorestore \
    --uri="$STAGING_MONGO_URL" \
    --archive \
    --gzip \
    --nsFrom="${DB_NAME}.*" \
    --nsTo="${STAGING_DB_NAME}.*"

# 6. Verificar
mongosh "$STAGING_MONGO_URL" --eval "db.stats()"

# 7. Reiniciar backend staging para resetar cache
docker compose -f docker-compose.staging.yml restart backend
```

---

## 5. Restore em Produção

> 🔴 **REQUER APROVAÇÃO** de pelo menos 1 outro membro da equipe antes de executar.
> Registre o incidente antes de iniciar.

### Pré-requisitos
- [ ] Incidente registrado (ver seção 8)
- [ ] Aprovação de 2ª pessoa registrada
- [ ] Backup recente verificado (checksum OK)
- [ ] Janela de manutenção comunicada
- [ ] Modo manutenção ativo no frontend (503 page)

### Passo a passo

```bash
# 1. PARAR o backend (evitar writes durante restore)
docker compose -f docker-compose.staging.yml stop backend

# 2. Backup do estado atual (pré-restore)
mongodump --uri="$PROD_MONGO_URL" --db="$DB_NAME" \
  --archive --gzip | \
  openssl enc -aes-256-cbc -salt -pbkdf2 -iter 100000 \
    -pass "pass:$BACKUP_ENCRYPTION_KEY" \
    -out "/tmp/pre-restore-$(date +%Y%m%dT%H%M%S)Z.enc"

# 3. Download do backup a restaurar
aws s3 cp "s3://$BACKUP_S3_BUCKET/mongodb/${BACKUP_FILE}.enc" /tmp/
sha256sum -c "/tmp/${BACKUP_FILE}.sha256"  # verificar checksum

# 4. Drop (IRREVERSÍVEL)
mongosh "$PROD_MONGO_URL" --eval "db.dropDatabase()"

# 5. Restore
openssl enc -d -aes-256-cbc -pbkdf2 -iter 100000 \
  -pass "pass:$BACKUP_ENCRYPTION_KEY" \
  -in "/tmp/${BACKUP_FILE}.enc" | \
  mongorestore \
    --uri="$PROD_MONGO_URL" \
    --archive --gzip

# 6. Recriar índices (backfill idempotente)
cd /app && python3 scripts/ensure_indexes.py

# 7. Reiniciar backend
docker compose restart backend
sleep 10

# 8. Verificar health
curl -f $BACKEND_URL/api/health/ready

# 9. Smoke test manual (login, dashboard, relatórios)

# 10. Desativar modo manutenção
```

---

## 6. Restore Parcial

Para restaurar apenas uma coleção específica (ex: `users`):

```bash
# Restaurar somente a coleção 'users' de um backup
openssl enc -d -aes-256-cbc -pbkdf2 -iter 100000 \
  -pass "pass:$BACKUP_ENCRYPTION_KEY" \
  -in "/tmp/${BACKUP_FILE}.enc" | \
  mongorestore \
    --uri="$MONGO_URL" \
    --archive --gzip \
    --nsInclude="${DB_NAME}.users"
```

---

## 7. Testar Backup Periodicamente

**Frequência recomendada:** Mensal em staging, trimestral em ambiente dedicado.

```bash
# Script de teste de backup (rodar mensalmente)
#!/bin/bash
echo "=== TESTE DE BACKUP $(date) ==="

# 1. Identificar backup mais recente
LATEST=$(aws s3 ls "s3://$BACKUP_S3_BUCKET/mongodb/" | sort | tail -1 | awk '{print $4}')
echo "Testando backup: $LATEST"

# 2. Baixar
aws s3 cp "s3://$BACKUP_S3_BUCKET/mongodb/$LATEST" /tmp/test-backup.enc

# 3. Verificar checksum
CHECKSUM_FILE="${LATEST%.enc}.sha256"
aws s3 cp "s3://$BACKUP_S3_BUCKET/mongodb/$CHECKSUM_FILE" /tmp/test-backup.sha256
sha256sum -c /tmp/test-backup.sha256 || { echo "FALHOU: Checksum inválido"; exit 1; }

# 4. Dry run do restore
openssl enc -d -aes-256-cbc -pbkdf2 -iter 100000 \
  -pass "pass:$BACKUP_ENCRYPTION_KEY" \
  -in /tmp/test-backup.enc | \
  mongorestore --uri="$TEST_MONGO_URL" --archive --gzip --dryRun 2>&1

echo "=== TESTE CONCLUÍDO COM SUCESSO ==="
```

---

## 8. Registrar Incidente

Ao iniciar um restore em produção, registre:

```
DATA/HORA DO INCIDENTE: 
DESCRIÇÃO: 
IMPACTO: 
SOLICITANTE: 
APROVAÇÃO DE 2ª PESSOA: 
BACKUP UTILIZADO: 
CHECKSUM VERIFICADO: SIM/NÃO
INÍCIO DO RESTORE: 
FIM DO RESTORE: 
VERIFICAÇÃO PÓS-RESTORE: 
STATUS: CONCLUÍDO/FALHOU
OBSERVAÇÕES: 
```

Salvar em: `/docs/incidents/YYYY-MM-DD-restore.md`
