# Observability Gaps — Lista da Vez SaaS

**Versão:** 1.0.0-p2  
**Responsável:** SRE / Principal Engineer  
**Última atualização:** 2026-06

Este documento registra honestamente as lacunas de observabilidade identificadas durante a auditoria P2, com plano de ação priorizado.

---

## 1. O Que Está Implementado

### ✅ Métricas Prometheus (`/api/metrics/prometheus`)
- Contador de requests HTTP por endpoint e status
- Tempo de resposta por endpoint (histograma)
- Contador de erros por tipo
- Métricas de fila (operações de join/leave/start/finish)
- WebSocket connections ativas
- Outbox status (pending/failed)

### ✅ Health Check (`/api/health/ready`)
- MongoDB: connectivity check
- Redis: connectivity check
- App: status geral (ready/degraded)

### ✅ Logs Estruturados
- Logs em formato JSON em produção
- `tenant_id` nos logs de operações críticas
- Logs de erros com stack trace (apenas backend, não exposed)
- Supervisor logs em `/var/log/supervisor/`

### ✅ request_id
- Gerado e propagado em headers de resposta
- Presente nos logs de erro para correlação

---

## 2. Lacunas Identificadas

### 🔴 Críticas (P3 — antes de produção real)

#### 2.1 correlation_id Cross-Service
**Problema:** Não temos correlation_id propagado entre requests encadeados (ex: request HTTP → outbox worker → WS delivery).  
**Impacto:** Impossível rastrear a jornada completa de um evento em produção.  
**Solução:** Adicionar `X-Correlation-ID` header em requests e propagar via contexto async.

#### 2.2 Alertas Prometheus Não Configurados
**Problema:** Temos métricas mas sem alertas automáticos (AlertManager não configurado).  
**Impacto:** Incidentes detectados manualmente ou por clientes.  
**Solução:** Configurar AlertManager com regras básicas:
```yaml
- alert: HighErrorRate
  expr: sum(rate(http_requests_total{status=~"5.."}[5m])) / sum(rate(http_requests_total[5m])) > 0.05
  for: 2m
  
- alert: HighLatency
  expr: histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m])) > 1
  for: 5m
```

#### 2.3 Logs Sem Correlação no Frontend
**Problema:** Erros do React (componente crash, API fail) não são enviados para um sistema centralizado.  
**Impacto:** Bugs de produção no frontend descobertos tarde.  
**Solução:** Implementar `window.onerror` + envio para `/api/internal/log-client-error`.

### 🟡 Importantes (P4 — early production)

#### 2.4 Sem Distributed Tracing
**Problema:** Sem OpenTelemetry ou Jaeger para rastrear requests end-to-end.  
**Impacto:** Dificuldade em diagnosticar latência em operações multi-step.  
**Solução:** Adicionar OpenTelemetry SDK (`opentelemetry-sdk`, `opentelemetry-instrumentation-fastapi`).

#### 2.5 Métricas de Tenant Não Granulares
**Problema:** Métricas Prometheus não têm label `tenant_id` na maioria dos contadores.  
**Impacto:** Impossível identificar qual tenant está causando degradação.  
**Solução:** Adicionar `tenant_id` como label em métricas críticas (atenção ao cardinality explosion com 500 tenants).

#### 2.6 Export Job Progress Tracking
**Problema:** Export jobs não reportam progresso (0% → 100% de golpe).  
**Impacto:** Usuário não sabe se job está travado ou apenas lento.  
**Solução:** Adicionar campo `progress_percent` e atualizar a cada 10% de linhas processadas.

#### 2.7 WebSocket Reconnection Metrics
**Problema:** Não monitoramos taxa de reconexão de WS (indicativo de instabilidade).  
**Impacto:** Instabilidade de rede não detectada.  
**Solução:** Adicionar counter `websocket_reconnections_total{tenant, reason}`.

#### 2.8 Outbox Dead Letter Monitoring
**Problema:** Eventos que falham 3x vão para `outbox:failed` mas sem alerta.  
**Impacto:** Eventos realtime perdidos silenciosamente.  
**Solução:** Alert se `outbox_failed_count > 0`.

### 🟢 Desejáveis (Backlog)

#### 2.9 Grafana Dashboards
**Problema:** Temos métricas Prometheus mas sem visualização.  
**Solução:** Criar dashboards Grafana (templates disponíveis para FastAPI + MongoDB).

#### 2.10 Uptime Monitoring
**Problema:** Sem monitoramento externo de disponibilidade.  
**Solução:** Integrar com UptimeRobot, Pingdom ou similar para `/api/health/ready`.

#### 2.11 Audit Log Centralizado
**Problema:** `audit_logs` no MongoDB mas sem interface de busca para admins.  
**Solução:** Endpoint `/api/super-admin/audit-logs?filter=...` com paginação.

#### 2.12 Error Budget Tracking
**Problema:** Sem SLO tracking automático (% do tempo dentro dos SLOs).  
**Solução:** Implementar após AlertManager configurado.

---

## 3. Plano de Ação Priorizado

| # | Lacuna | Prioridade | Esforço | Fase |
|---|---|---|---|---|
| 1 | Alertas Prometheus | P0 | 2h | P3 |
| 2 | correlation_id cross-service | P1 | 1 dia | P3 |
| 3 | Client error logging | P1 | 4h | P3 |
| 4 | Outbox dead letter alert | P1 | 2h | P3 |
| 5 | Distributed tracing (OTel) | P2 | 3 dias | P4 |
| 6 | Tenant-granular metrics | P2 | 1 dia | P4 |
| 7 | Export progress tracking | P2 | 4h | P4 |
| 8 | Grafana dashboards | P3 | 1 semana | Backlog |
| 9 | Uptime monitoring | P3 | 2h | Backlog |
| 10 | Audit log interface | P3 | 2 dias | Backlog |
