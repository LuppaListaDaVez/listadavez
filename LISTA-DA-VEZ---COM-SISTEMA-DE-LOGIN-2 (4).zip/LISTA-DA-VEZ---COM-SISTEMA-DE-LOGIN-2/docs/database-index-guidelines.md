# Database Index Guidelines — Lista da Vez SaaS

**Versão:** 1.0.0-p2  
**Responsável:** Tech Lead / SRE  
**Última atualização:** 2026-06

---

## 1. Princípios Gerais

1. **Índice composto: sempre começa pelo `tenant_id`** — toda coleção tenant-scoped
2. **Seguir o ESR Rule:** Equality → Sort → Range na ordem dos campos do índice
3. **Nunca COLLSCAN em produção** para queries frequentes (> 10 req/min)
4. **Índices únicos** para campos de unicidade de negócio (`slug`, `email`, `employee_code`)
5. **TTL Index** para dados com expiração (idempotency_keys, export_jobs antigos)
6. **Projections** nas queries frequentes para evitar busca desnecessária de campos

---

## 2. Índices por Coleção

### 2.1 `tenants`
```javascript
{ "slug": 1 }                    // unique — login por slug
{ "status": 1 }                  // filtro de tenants ativos
```

### 2.2 `users`
```javascript
{ "normalized_email": 1 }        // unique — login case-insensitive
{ "is_super_admin": 1 }          // busca de super admin
```

### 2.3 `tenant_memberships`
```javascript
{ "tenant_id": 1, "user_id": 1 } // unique — um membership por user/tenant
{ "tenant_id": 1, "role": 1 }    // filtro por role dentro do tenant
```

### 2.4 `stores`
```javascript
{ "tenant_id": 1, "id": 1 }      // busca por ID no tenant
{ "tenant_id": 1, "code": 1 }    // unique por tenant — código da loja
{ "tenant_id": 1, "status": 1 }  // filtro de lojas ativas
```

### 2.5 `seller_profiles`
```javascript
{ "tenant_id": 1, "user_id": 1 } // unique — um profile por user/tenant
{ "tenant_id": 1, "store_id": 1, "current_status": 1 }  // estado da fila
{ "tenant_id": 1, "employee_code": 1 }  // busca por código do vendedor
```

### 2.6 `queues`
```javascript
{ "tenant_id": 1, "store_id": 1, "is_default": 1 }  // fila padrão da loja
{ "tenant_id": 1, "store_id": 1, "status": 1 }      // filas ativas
```

### 2.7 `queue_entries`
```javascript
{ "tenant_id": 1, "queue_id": 1, "status": 1, "position": 1 }  // estado da fila (HOT)
{ "tenant_id": 1, "seller_id": 1, "status": 1 }                 // entrada do vendedor
```

### 2.8 `attendances`
```javascript
{ "tenant_id": 1, "store_id": 1, "status": 1, "created_at": -1 }  // listagem
{ "tenant_id": 1, "seller_id": 1, "status": 1 }                    // atendimento ativo
{ "tenant_id": 1, "created_at": -1 }                               // dashboard hoje
```

### 2.9 `sales`
```javascript
{ "tenant_id": 1, "store_id": 1, "created_at": -1 }  // relatório de vendas
{ "tenant_id": 1, "seller_id": 1, "created_at": -1 } // vendas do vendedor
{ "tenant_id": 1, "status": 1 }                       // vendas ativas
```

### 2.10 `goals`
```javascript
{ "tenant_id": 1, "status": 1, "period_end": 1 }  // metas ativas
{ "tenant_id": 1, "store_id": 1, "type": 1 }       // metas por loja/tipo
```

### 2.11 `notifications`
```javascript
{ "tenant_id": 1, "user_id": 1, "read": 1, "created_at": -1 }  // notificações não lidas
{ "tenant_id": 1, "created_at": -1 }                             // limpeza por retenção
```

### 2.12 `export_jobs`
```javascript
{ "tenant_id": 1, "created_by": 1, "created_at": -1 }  // jobs do usuário
{ "tenant_id": 1, "status": 1 }                          // jobs pendentes (worker)
{ "created_at": 1 }                                      // TTL: limpeza automática
```

### 2.13 `idempotency_keys`
```javascript
{ "tenant_id": 1, "key": 1 }  // unique — consulta rápida
{ "created_at": 1 }           // TTL index: expira após 24h
```

### 2.14 `rate_limit` (Redis — não MongoDB)
Chave: `rl:{group}:{ip}:{email}:{tenant_slug}`  
TTL: `window_seconds + 10s`

---

## 3. Regras para Novos Índices

### Quando criar
- Query executa mais de 10x/min em produção
- EXPLAIN mostra COLLSCAN em coleção com > 1000 docs
- Query usa `$sort` em campo sem índice (sort stage in memory)
- Query usa `$lookup` em coleção grande

### Quando NÃO criar
- Campo com baixa cardinalidade em coleção pequena (< 100 docs)
- Índice já coberto por índice composto mais abrangente
- Campo nunca usado em query de produção

### Como adicionar índice com segurança
```python
# Sempre usar createIndex com background=True em produção
# (não bloqueia operações de leitura/escrita)
await db.attendances.create_index(
    [("tenant_id", 1), ("store_id", 1), ("status", 1)],
    background=True,
    name="idx_attendances_tenant_store_status"
)
```

---

## 4. Monitoramento de Performance de Queries

### Queries Lentas (> 100ms)
Configurar `slowOpThresholdMs: 100` no MongoDB e alertar via Prometheus.

### EXPLAIN em Staging
Antes de qualquer deploy com nova query:
```javascript
db.attendances.find({
  "tenant_id": "...",
  "store_id": "...",
  "status": "FINISHED"
}).explain("executionStats")
// Verificar: stage=IXSCAN (não COLLSCAN)
// Verificar: nReturned / totalKeysExamined ≈ 1.0
```

### Índices Não Utilizados
Revisar mensalmente com `$indexStats` e remover índices com `accesses.ops = 0`.

---

## 5. TTL e Retenção de Dados

| Coleção | TTL | Critério |
|---|---|---|
| `idempotency_keys` | 24h | `created_at` |
| `export_jobs` | 7 dias | `created_at` |
| `notifications` | 90 dias (Pro) / 30 dias (Basic) | `created_at` |
| `attendances` | 365 dias (Enterprise) / 90 dias (Pro) | Configurável por tenant |
| `audit_logs` | 2 anos | `created_at` |

Scripts de TTL executam via background task diária (`/api/internal/cleanup`).
