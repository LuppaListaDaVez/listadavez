# Architecture Guide — Lista da Vez SaaS

**Versão:** 1.0.0-p2  
**Mantido por:** Tech Lead / Principal Engineer  
**Última atualização:** 2026-06

---

## 1. Visão Geral

**Lista da Vez** é um SaaS multitenant para gestão de filas de vendas, atendimento, metas e rankings em redes varejistas. Cada tenant (empresa cliente) é completamente isolado dos demais.

```
Browser / Mobile
      │
      ▼
   Kubernetes Ingress / Nginx
      │
      ├──► React SPA (port 3000)
      │      └── Roteamento: /:tenantSlug/...
      │
      └──► FastAPI Backend (port 8001)
             ├── /api/...           (rotas v0, retrocompatíveis)
             ├── /api/v1/...        (alias v1, mesma lógica)
             └── /api/metrics/...   (Prometheus)
                    │
                    ├── MongoDB (motor async)
                    ├── Redis (rate limit + pub/sub + outbox)
                    └── Background Tasks (asyncio)
```

---

## 2. Clean Architecture Incremental

O sistema adota **Clean Architecture Incremental**: a migração é progressiva, preservando estabilidade enquanto separa responsabilidades.

### 2.1 Camadas

```
backend/
├── domain/           # Entidades, value objects, domain errors
│   ├── base.py       # DomainError, NotFoundError, ConflictError, ForbiddenError
│   ├── queue/        # QueueConflictError, QueueLockedError
│   ├── sales/        # (em evolução)
│   └── tenant/       # StoreNotFoundError, InsufficientPermissionsError
│
├── application/      # Use Cases: orquestram domain + infra
│   ├── base.py       # BaseUseCase (ABC), UseCaseContext
│   ├── queue/        # JoinQueueUseCase, FinishAttendanceUseCase
│   ├── sales/        # CreateSaleUseCase
│   ├── notifications/# CreateNotificationUseCase
│   ├── goals/        # CreateGoalUseCase
│   └── rankings/     # GenerateRankingUseCase
│
├── infrastructure/   # Implementações concretas
│   └── repositories/ # BaseRepository + 6 repositórios tenant-scoped
│       ├── base.py               # find_by_id_for_tenant, paginação clampada
│       ├── tenant_repository.py
│       ├── user_repository.py
│       ├── store_repository.py
│       ├── queue_repository.py
│       ├── attendance_repository.py
│       └── sales_repository.py
│
├── interfaces/       # Entrada/Saída
│   └── v1/
│       ├── router.py   # v1_router (alias das rotas)
│       └── schemas.py  # ApiResponse, ApiError, PaginationMeta
│
└── [legacy — migração incremental]
    ├── routes_*.py         # Controladores (migrando para interfaces/v1)
    ├── queue_engine.py     # Motor de fila (delegado pelos Use Cases)
    ├── permission_service.py
    ├── feature_flag_service.py
    └── services/*.py       # Services legados (em decomposição gradual)
```

### 2.2 Regras de Camada

| Camada | Pode importar de | Não pode importar de |
|---|---|---|
| `domain` | nada externo | application, infrastructure, interfaces |
| `application` | domain, infrastructure | interfaces, routes |
| `infrastructure` | domain | application, interfaces |
| `interfaces` | application, domain | infrastructure diretamente |
| `routes_*` | application, services legados | domain diretamente (idealmente) |

### 2.3 Invariantes de Arquitetura

- **Toda operação em dados tenant-scoped DEVE passar tenant_id explicitamente**
- **Use Case SEMPRE valida tenant + permissão antes de persistir**
- **Repository NUNCA expõe find_by_id sem tenant_id para entidades tenant-scoped**
- **Domain errors SEMPRE mapeados para HTTP 4xx via handler global**

---

## 3. Multitenancy

### 3.1 Modelo de Isolamento

- **Isolamento por tenant_id em cada documento** (soft isolation no MongoDB)
- Toda query em coleção tenant-scoped exige `{"tenant_id": tenant_id, ...}`
- JWT carrega `tenant_slug` — validado em cada request pelo middleware de auth
- Sem row-level security do banco (MongoDB não suporta) — compensado por repositórios seguros

### 3.2 Path-Based Tenant Routing

```
GET /api/tenants/{slug}/stores      → slug extraído do path
Authorization: Bearer {jwt}         → jwt.tenant_slug deve == path slug
```

Se `jwt.tenant_slug != path_slug` → 401 Unauthorized

### 3.3 Coleções tenant-scoped

Toda coleção (exceto `plans`, `features`, `audit_logs` globais) tem campo `tenant_id`.

---

## 4. Fluxo de uma Requisição

```
1. Nginx → FastAPI
2. CORS middleware
3. Rate Limit middleware (por IP+email+tenant)
4. Auth middleware: verifica JWT, extrai tenant_slug, user_id, role
5. Route handler: valida path tenant_slug vs JWT tenant_slug
6. Use Case (se extraído): valida permissão, regra de negócio
7. Repository: query com tenant_id obrigatório
8. Response: ApiResponse padronizado
9. Outbox event (se necessário): publicado em Redis pub/sub
10. WebSocket: evento propagado para clientes conectados no mesmo tenant
```

---

## 5. WebSocket e Realtime

- **Protocolo:** WebSocket nativo (`/api/ws/tenants/{slug}/stores/{store_id}`)
- **Distribuído:** Redis pub/sub (canal por `tenant_id`)
- **Heartbeat:** ping a cada 30s do cliente
- **Graceful shutdown:** `close_all()` no adapter + `on_shutdown()` no server.py
- **Feature flag:** `tempo_real` deve estar habilitada para conectar

---

## 6. Decisões Técnicas Registradas

| Decisão | Justificativa | Data |
|---|---|---|
| MongoDB ao invés de PostgreSQL | Flexibilidade de schema em produto em evolução | P0 |
| Isolamento por tenant_id ao invés de database por tenant | Custo e complexidade operacional menor | P0 |
| Redis Sorted Sets para rate limit | Sliding window precisa sem locks | P1.5 |
| Outbox pattern para realtime | Garante entrega even if WS desconectado | P1.5 |
| Clean Architecture incremental (não big-bang) | Sem parar feature development | P2 |
| JWT stateless (sem session store) | Horizontal scaling simples | P0 |

---

## 7. Extensão da Arquitetura (Checklist para Novos Módulos)

Ao criar um novo módulo/feature, responder:

1. **Qual tenant_id filtra os dados?** (Documentar)
2. **Qual permission key protege?** (Registrar em `permissions.py`)
3. **Qual feature flag controla?** (Registrar em `feature_flags.py`)
4. **Precisa de idempotência?** (Adicionar Idempotency-Key)
5. **Precisa de rate limit?** (Adicionar ao `rate_limit_service.py`)
6. **Precisa de audit log?** (Adicionar chamada ao `audit_service.py`)
7. **Precisa de índice MongoDB?** (Ver `database-index-guidelines.md`)
8. **Precisa de paginação?** (Usar `BaseRepository.find_many_for_tenant`)
9. **Precisa de teste cross-tenant?** (Sempre sim para dados do tenant)
10. **Precisa de evento outbox/WS?** (Para mudanças de estado visíveis em realtime)

---

## 8. Evolução Futura (P3+)

- **P3:** Auditoria final de qualidade e resiliência
- **P4:** Migração completa para Use Cases (todos os routes_*.py)
- **P5:** Multi-database isolation (tenant por database) para clientes enterprise
- **P6:** CQRS parcial (read models separados para dashboard/relatórios)
- **P7:** Event Sourcing para audit trail imutável
