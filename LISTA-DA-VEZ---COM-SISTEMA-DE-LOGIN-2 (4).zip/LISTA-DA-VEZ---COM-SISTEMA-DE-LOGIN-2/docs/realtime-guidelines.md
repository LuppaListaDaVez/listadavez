# Realtime Guidelines — Lista da Vez SaaS

**Versão:** 1.0.0-p2  
**Responsável:** Tech Lead / SRE  
**Última atualização:** 2026-06

---

## 1. Visão Geral

O sistema usa **WebSocket** para comunicação realtime entre backend e frontend, com **Outbox Pattern** para garantia de entrega e **Redis Pub/Sub** para propagação em múltiplas instâncias.

```
Backend Operation
      │
      ├──► MongoDB (persistência)
      │
      └──► Outbox Event (Redis Stream)
                │
                ▼
         EventBus (Redis Pub/Sub)
                │
                ├──► Instância 1 → WS clientes conectados
                ├──► Instância 2 → WS clientes conectados
                └──► Instância 3 → WS clientes conectados
```

---

## 2. WebSocket — Protocolo e Endpoints

### 2.1 Endpoint de Conexão

```
WS /api/ws/tenants/{slug}/stores/{store_id}?token={jwt}
```

**Autenticação:** JWT via query param `token` (header não suportado em WS)  
**Validação:** `jwt.tenant_slug == slug` e store pertence ao tenant  
**Feature flag:** `tempo_real` deve estar habilitada

### 2.2 Mensagens do Servidor → Cliente

```json
// Evento de atualização da fila
{
  "type": "QUEUE_UPDATE",
  "store_id": "...",
  "tenant_id": "...",
  "data": { "waiting": [...], "serving": [...] }
}

// Heartbeat (keepalive)
{
  "type": "pong",
  "timestamp": "2026-06-01T10:00:00Z"
}

// Shutdown graceful
{
  "type": "server.shutdown",
  "message": "Server shutting down"
}
```

### 2.3 Mensagens do Cliente → Servidor

```json
// Ping (keepalive)
{ "type": "ping" }

// Solicitar estado atual
{ "type": "get_state" }
```

---

## 3. Heartbeat e Reconexão

### 3.1 Backend
- Ping automático a cada **30s** para todos os clientes conectados
- Cliente que não responde em 45s: conexão fechada
- Limite de conexões simultâneas: configurável (default: sem limite por instância)

### 3.2 Frontend (`useRealtimeStoreEvents.js`)
- Cliente envia **ping a cada 30s** para manter WS vivo em proxies
- Reconexão automática com **exponential backoff**: 1s, 2s, 4s, 8s, 16s (max)
- Após 5 falhas de reconexão: fallback para polling HTTP (5s)
- Indicador visual: `"Tempo real ativo"` (verde) / `"Reconectando..."` (amarelo) / `"Offline"` (vermelho)

---

## 4. Outbox Pattern

### 4.1 Quando Usar Outbox

Todo evento realtime que deve ser **garantidamente entregue** (mesmo se WS desconectado):
- Mudança de estado da fila (join/leave/start/finish)
- Novo atendimento iniciado
- Venda registrada
- Notificação crítica

### 4.2 Fluxo do Outbox

```
1. Operação persiste no MongoDB
2. Evento escrito no Redis Stream (outbox)
3. Worker consome o stream e publica no Pub/Sub
4. Pub/Sub propaga para todas as instâncias
5. Cada instância envia para WS clientes conectados
```

### 4.3 Garantias
- **At-least-once delivery**: evento pode ser entregue mais de uma vez
- **Idempotência no cliente**: frontend ignora eventos duplicados por timestamp
- **Dead letter**: após 3 falhas, evento vai para `outbox:failed`
- **Monitoramento**: métricas `outbox_pending`, `outbox_failed` em Prometheus

---

## 5. Graceful Shutdown

```python
# server.py — on_shutdown handler
@app.on_event("shutdown")
async def on_shutdown():
    await event_bus.close_all()  # Fecha todas as conexões WS com server.shutdown
    logger.info("SHUTDOWN_COMPLETE: all WS connections closed")
```

Sequência de shutdown:
1. Kubernetes envia SIGTERM
2. FastAPI inicia shutdown (30s timeout)
3. `close_all()` envia `{"type": "server.shutdown"}` para todos os clientes
4. Frontend recebe e inicia reconexão automática (nova instância)
5. Conexões fechadas ordenadamente

---

## 6. Escala Horizontal

### 6.1 Problema com Multi-instância
Sem Redis: cliente conectado na instância 1 não recebe eventos de operações na instância 2.

### 6.2 Solução Redis Pub/Sub
```
Instância 1 recebe operação
  → publica em Redis channel: f"tenant:{tenant_id}:store:{store_id}"
  → TODAS as instâncias assinam o canal
  → Cada instância propaga para seus clientes WS conectados
```

### 6.3 Configuração
```env
REALTIME_MODE=redis           # redis | in_memory
REDIS_URL=redis://localhost:6379/0
```

### 6.4 Fallback In-Memory
Se Redis indisponível: `REALTIME_MODE=in_memory` (funciona em single-instance apenas).

---

## 7. Métricas de WebSocket (Prometheus)

```
websocket_connections_total    # Conexões ativas
websocket_messages_sent_total  # Mensagens enviadas
websocket_errors_total         # Erros de conexão
outbox_pending_count           # Eventos pendentes no outbox
outbox_failed_count            # Eventos com falha
```

---

## 8. Checklist para Nova Feature com Realtime

- [ ] Feature flag `tempo_real` verificada antes de conectar WS
- [ ] Evento outbox criado após operação persistida no MongoDB
- [ ] Tipo de evento documentado neste guia (seção 2.2)
- [ ] Frontend trata evento com idempotência (ignora duplicatas)
- [ ] Teste: verificar que evento chega via WS após operação
- [ ] Teste: verificar que operação funciona se WS desconectado (outbox entrega depois)
- [ ] Métrica incrementada no evento (Prometheus counter)

---

## 9. Debugging de Problemas Realtime

### Clientes não recebem atualizações
1. Verificar feature flag `tempo_real`: `GET /api/tenants/{slug}/features`
2. Verificar Redis conectado: `GET /api/health/ready` → `redis: connected`
3. Verificar canal Redis: `redis-cli subscribe "tenant:{id}:store:{id}"`
4. Verificar logs: `grep "WEBSOCKET" /var/log/supervisor/backend.*.log`

### Alta latência de entrega
1. Verificar `outbox_pending_count` no Prometheus
2. Verificar worker do outbox em execução: `ps aux | grep outbox`
3. Redis latência: `redis-cli latency history event`
