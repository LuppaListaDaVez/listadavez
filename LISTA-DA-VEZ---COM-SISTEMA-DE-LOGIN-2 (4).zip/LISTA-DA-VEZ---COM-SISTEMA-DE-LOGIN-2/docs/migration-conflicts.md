# Conflitos de Migração — P0.5

**Gerado em:** 2026-06-29

## Verificações de Duplicatas

### E-mails duplicados (normalized_email)

Execute para verificar antes de criar unique index:

```bash
cd /app/backend && python3 - << 'EOF'
import asyncio, os
from dotenv import load_dotenv; load_dotenv('.env')
from motor.motor_asyncio import AsyncIOMotorClient

async def check():
    db = AsyncIOMotorClient(os.environ['MONGO_URL'])[os.environ['DB_NAME']]
    pipeline = [
        {'$match': {'normalized_email': {'$exists': True}}},
        {'$group': {'_id': '$normalized_email', 'count': {'$sum': 1}, 'ids': {'$push': '$id'}}},
        {'$match': {'count': {'$gt': 1}}},
    ]
    dups = await db.users.aggregate(pipeline).to_list(100)
    if dups:
        print(f'CONFLITOS: {len(dups)} e-mails duplicados encontrados')
        for d in dups:
            print(f'  email: {d["_id"]} | count: {d["count"]} | ids: {d["ids"]}')
    else:
        print('Nenhum conflito de e-mail encontrado. Seguro criar unique index.')

asyncio.run(check())
EOF
```

### Stores com slug duplicado

```bash
cd /app/backend && python3 - << 'EOF'
import asyncio, os
from dotenv import load_dotenv; load_dotenv('.env')
from motor.motor_asyncio import AsyncIOMotorClient

async def check():
    db = AsyncIOMotorClient(os.environ['MONGO_URL'])[os.environ['DB_NAME']]
    pipeline = [
        {'$match': {'slug': {'$exists': True}}},
        {'$group': {
            '_id': {'tenant_id': '$tenant_id', 'slug': '$slug'},
            'count': {'$sum': 1},
            'ids': {'$push': '$id'}
        }},
        {'$match': {'count': {'$gt': 1}}},
    ]
    dups = await db.stores.aggregate(pipeline).to_list(100)
    if dups:
        print(f'CONFLITOS: {len(dups)} slugs duplicados em stores')
        for d in dups:
            print(f'  tenant: {d["_id"]["tenant_id"]} slug: {d["_id"]["slug"]} count: {d["count"]}')
    else:
        print('Nenhum conflito de slug em stores.')

asyncio.run(check())
EOF
```

---

## Como Resolver Conflitos de E-mail

Se dois usuários tiverem o mesmo e-mail normalizado (ex: `User@exemplo.com` e `user@exemplo.com`):

1. Identificar qual usuário é o ativo (último login)
2. Desativar ou remover o usuário duplicado inativo
3. Rodar o backfill novamente
4. Criar o unique index somente após resolução

```bash
# Ver usuários com mesmo e-mail normalizado
python scripts/ensure_indexes.py --report-only
```

---

## Status de Conflitos no Ambiente Demo

| Tipo | Quantidade | Ação |
|------|-----------|------|
| E-mails duplicados | 0 (aguarda verificação pós-backfill) | Verificar após backfill |
| Slugs duplicados | 0 | Nenhuma ação |
| Sales sem source | 301 → 0 após backfill | ✅ Resolvido |
| Attendances sem source | 11 → 0 após backfill | ✅ Resolvido |
| Stores sem slug | 4 → 0 após backfill | ✅ Resolvido |
| Users sem normalized_email | 13 → 0 após backfill | ✅ Resolvido |
