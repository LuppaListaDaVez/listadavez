# Technical Debt — Lista da Vez SaaS

**Versão:** 1.0.0-p2  
**Responsável:** Tech Lead / Principal Engineer  
**Última atualização:** 2026-06

Este documento registra honestamente a dívida técnica identificada durante a auditoria P2. **Não esconder dívida técnica.**

---

## Legenda

- 🔴 **CRÍTICO** — Bloqueia escala ou representa risco de segurança
- 🟡 **IMPORTANTE** — Impacta manutenibilidade ou performance
- 🟢 **DESEJÁVEL** — Melhoria de qualidade sem impacto imediato

---

## 1. Arquitetura e Código

### 🟡 TD-001: `server.py` com 800+ linhas
**O quê:** `server.py` ainda concentra muitas rotas e lógica que deveriam estar em `routes_*.py` ou Use Cases.  
**Risco:** Alta complexidade ciclomática, difícil de testar e manter.  
**Plano:** Migrar gradualmente para módulos dedicados em P3/P4. Não refatorar de uma vez (risco de regressão).

### 🟡 TD-002: Mistura de `services/` legados com Use Cases novos
**O quê:** Temos `queue_engine.py`, `attendance_service.py`, `sale_service.py` legados E Use Cases novos em `application/`.  
**Risco:** Duplicação de lógica, possível inconsistência de comportamento.  
**Plano:** P4 — migrar toda lógica de serviços legados para Use Cases. Map: `queue_engine.py → JoinQueueUseCase, FinishAttendanceUseCase`.

### 🟡 TD-003: Routes legadas não usam BaseRepository
**O quê:** `routes_attendances.py`, `routes_sales.py` ainda acessam MongoDB diretamente (`db.attendances.find(...)`) sem passar pelo Repository.  
**Risco:** Queries potencialmente sem tenant_id (IDOR se novo developer não seguir padrão).  
**Plano:** P3 — Auditar todas as queries diretas e migrar para Repository. Adicionar lint rule.  
**Mitigação atual:** Middleware de auth valida tenant no nível do request antes de chegar nas rotas.

### 🟢 TD-004: `models.py` monolítico (1200+ linhas)
**O quê:** Todos os Pydantic models em um único arquivo.  
**Risco:** Difícil navegar, conflitos em merges paralelos.  
**Plano:** P4 — extrair para `models/tenant.py`, `models/queue.py`, etc. mantendo `models.py` como facade.

### 🟡 TD-005: Inconsistência de resposta entre endpoints legados e v1
**O quê:** Endpoints legados retornam `[{...}, {...}]` direto, enquanto novos retornam `{items: [...], pagination: {...}}`.  
**Risco:** Frontend precisa tratar dois formatos diferentes.  
**Plano:** P3 — Documentar quais endpoints usam qual formato. P4 — unificar em v2.

---

## 2. Testes

### 🟡 TD-006: Cobertura de testes em Use Cases insuficiente
**O quê:** Use Cases em `application/` não têm testes unitários com mocks de Repository.  
**Risco:** Regressões em lógica de negócio crítica não detectadas.  
**Plano:** P3 — Criar `tests/unit/test_use_cases.py` com mocks de Repository.

### 🟡 TD-007: Testes de concorrência com 3 skips (fila vazia)
**O quê:** `test_p2_5_concurrency.py` tem 3 testes que pulam quando a fila está vazia.  
**Risco:** Cobertura de concorrência incompleta em CI.  
**Plano:** P3 — Criar fixture que pré-popula a fila antes dos testes de concorrência.

### 🟢 TD-008: Sem testes de contrato de API (Pact)
**O quê:** Sem testes de contrato entre frontend e backend.  
**Risco:** Breaking change silencioso em APIs consumidas pelo frontend.  
**Plano:** Backlog — Implementar Pact testing quando múltiplos clientes consumirem a API.

---

## 3. Infraestrutura e Configuração

### 🔴 TD-009: MongoDB sem autenticação em desenvolvimento
**O quê:** MongoDB local sem usuário/senha.  
**Risco:** Acesso não autorizado em ambientes com rede compartilhada.  
**Plano:** P3 — Configurar autenticação em staging. Prod já deve ter autenticação.  
**Mitigação atual:** Ambiente de dev fechado (localhost only).

### 🔴 TD-010: Redis sem autenticação em desenvolvimento
**O quê:** Redis local sem senha.  
**Risco:** Rate limit pode ser resetado por atacante com acesso à rede.  
**Plano:** P3 — Configurar `requirepass` no Redis de staging/prod.  
**Mitigação atual:** Redis na rede interna do K8s em produção.

### 🟡 TD-011: Sem TLS entre serviços internos
**O quê:** Comunicação FastAPI → MongoDB e FastAPI → Redis sem TLS na rede interna.  
**Risco:** Sniffing de dados em redes não confiáveis.  
**Plano:** P4 — Habilitar TLS nas conexões internas. Em K8s, mTLS via service mesh (Istio/Linkerd).

### 🟢 TD-012: requirements.txt sem pin de versões minor
**O quê:** Algumas dependências sem versão exata (apenas `>=`).  
**Risco:** Atualização automática pode introduzir breaking changes.  
**Plano:** P3 — Pinnar todas as versões exatas via `pip-compile`.

---

## 4. Frontend

### 🟡 TD-013: Token armazenado em localStorage (XSS risk)
**O quê:** JWT em `localStorage` é acessível por JavaScript.  
**Risco:** XSS pode roubar token.  
**Plano:** P4 — Migrar para Cookie HttpOnly com SameSite=Strict.  
**Mitigação atual:** CSP headers e sem `eval()` no código.

### 🟢 TD-014: Sem otimização de bundle (code splitting incompleto)
**O quê:** Alguns componentes grandes não têm lazy loading.  
**Risco:** LCP (Largest Contentful Paint) degradado em conexões lentas.  
**Plano:** P3 — Auditoria com `webpack-bundle-analyzer`.

### 🟢 TD-015: Sem tratamento de erro global no React
**O quê:** Sem `ErrorBoundary` global para capturar crashes de componente.  
**Risco:** Tela branca para o usuário em crashes inesperados.  
**Plano:** P3 — Adicionar `<ErrorBoundary>` no App.js com fallback UI.

---

## 5. Operações

### 🟡 TD-016: Sem runbook de escalabilidade para pico
**O quê:** Sem procedimento documentado para adicionar pods em pico de tráfego.  
**Risco:** Demora para reagir a picos de carga.  
**Plano:** P3 — Criar procedimento em `/docs/operational-runbook.md`. HPA já documentado em `/docs/autoscaling.md`.

### 🟡 TD-017: Backup não verificado em staging
**O quê:** Script de backup existe mas restore não foi testado em ambiente real.  
**Risco:** Backup corrompido ou inaplicável descoberto tarde.  
**Plano:** P3 — Teste mensal de restore em ambiente de staging (ver `/docs/backup-restore-runbook.md`).

---

## 6. Dívida Removida (P2)

Os itens abaixo foram identificados e corrigidos durante a P2:

- ✅ Polling de 5s substituído por WebSocket real
- ✅ Rate limiter in-memory substituído por Redis
- ✅ find_by_id sem tenant_id substituído por find_by_id_for_tenant
- ✅ Chamadas HTTP genéricas do frontend extraídas para API clients por domínio
- ✅ Event Bus sem graceful shutdown → close_all() implementado
- ✅ seed_enterprise_dataset.py usando `source=DIRECT` inválido → corrigido para DIRECT→QUEUE
- ✅ test_p1_export_jobs.py com BASE_URL vazia quando REACT_APP_BACKEND_URL não definido → corrigido

---

## 7. Métrica de Dívida Técnica

| Categoria | Items Críticos | Items Importantes | Items Desejáveis |
|---|---|---|---|
| Arquitetura | 0 | 5 | 1 |
| Testes | 0 | 2 | 1 |
| Infraestrutura | 2 | 2 | 1 |
| Frontend | 0 | 1 | 2 |
| Operações | 0 | 2 | 0 |
| **Total** | **2** | **12** | **5** |

**Score de saúde:** 2 itens críticos (Redis e MongoDB sem auth em dev — mitigados em prod).  
**Avaliação:** Dívida técnica gerenciável. Nenhum item bloqueia P3.
